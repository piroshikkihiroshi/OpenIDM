package jp.co.webcrew.phoenix.sstag.util;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.sstag.bean.SelectItemBean;
import jp.co.webcrew.phoenix.sstag.db.SelectMstDb;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;
import jp.co.webcrew.phoenix.vtable.bean.ClmMetaMstBean;

public class ClmMetaMstUtil {

    /** ロガー */
    private static final Logger log = Logger.getLogger(ClmMetaMstUtil.class);

    private static Map<String, Class<? extends ClmMetaMstUtil>> classMap = new HashMap<String, Class<? extends ClmMetaMstUtil>>();

    static {
        classMap.put("1", Type1.class);
        classMap.put("2", Type2.class);
        classMap.put("3", Type3.class);
        classMap.put("4", Type4.class);
        classMap.put("5", Type5.class);
        classMap.put("6", Type6.class);
        classMap.put("7", Type7.class);
        classMap.put("8", Type8.class);
        classMap.put("9", Type9.class);
        classMap.put("11", Type11.class);
        classMap.put("12", Type12.class);
        classMap.put("13", Type13.class);
        classMap.put("14", Type14.class);
        classMap.put("15", Type15.class);
        classMap.put("16", Type16.class);
        classMap.put("17", Type17.class);
        classMap.put("18", Type18.class);
        classMap.put("19", Type19.class);
        classMap.put("20", Type20.class);
        classMap.put("21", Type21.class);
        classMap.put("22", Type22.class);
        classMap.put("23", Type23.class);
        classMap.put("24", Type24.class);
        classMap.put("25", Type25.class);
        classMap.put("26", Type26.class);
        classMap.put("27", Type27.class);
        classMap.put("28", Type28.class);
        classMap.put("29", Type29.class);
        classMap.put("30", Type30.class);
        classMap.put("51", Type51.class);
        classMap.put("52", Type52.class);
        classMap.put("53", Type53.class);
        classMap.put("54", Type54.class);
        classMap.put("55", Type55.class);
        classMap.put("56", Type56.class);
        classMap.put("57", Type57.class);
        classMap.put("58", Type58.class);
        classMap.put("G1", TypeG1.class);
        classMap.put("G2", TypeG2.class);
        classMap.put("G3", TypeG3.class);
        classMap.put("G4", TypeG4.class);
        classMap.put("G5", TypeG5.class);
        classMap.put("P1", TypeP1.class);
        classMap.put("P2", TypeP2.class);
        classMap.put("P3", TypeP3.class);
        classMap.put("P4", TypeP4.class);
        classMap.put("P6", TypeP6.class);
        classMap.put("P7", TypeP7.class);
        classMap.put("P9", TypeP9.class);
    }

    public static ClmMetaMstUtil getInstance(HttpServletRequest request, ClmDataBean clmData)
            throws InstantiationException {
        Class<? extends ClmMetaMstUtil> tmp = classMap.get(clmData.getMeta().getType());
        if (tmp == null) {
            throw new InstantiationException("不明なtype[" + clmData.getMeta().getType() + "]です。");
        }
        ClmMetaMstUtil clmMetaMstUtil;
        try {
            clmMetaMstUtil = tmp.newInstance();
        } catch (IllegalAccessException e) {
            throw new InstantiationException(e.getMessage());
        }
        clmMetaMstUtil.request = request;
        clmMetaMstUtil.clmMetaMst = clmData.getMeta();
        clmMetaMstUtil.clmData = clmData;
        return clmMetaMstUtil;
    }

    protected HttpServletRequest request;

    protected ClmMetaMstBean clmMetaMst;

    protected ClmDataBean clmData;

    protected ClmMetaMstUtil() {
    }

    protected String getRawDelimiter() {
        return "\n";
    }

    protected String getValueDelimiter() {
        return " ";
    }

    protected String getDispDelimiter() {
        return " ";
    }

    public String getKeyData() {
        return clmData.getKeyData();
    }

    public String getRaw() {
        return PhoenixUtil.concat(getRaws(), getRawDelimiter());
    }

    public String[] getRaws() {
        return SstagUtil.splitNewLine(clmData.getData());
    }

    public String getValue() throws SQLException {
        return ValueUtil.sanitize(getValueNoenc());
    }

    public String[] getValues() throws SQLException {
        return SstagUtil.sanitize(getValuesNoenc());
    }

    public String getValueNoenc() throws SQLException {
        return clmMetaMst.getPrefix() + PhoenixUtil.dataCat(getValuesNoenc(), getValueDelimiter())
                + clmMetaMst.getSuffix();
    }

    public String[] getValuesNoenc() throws SQLException {
        return getRaws();
    }

    public String getDisp() throws SQLException {
        return ValueUtil.sanitize(getDispNoenc());
    }

    public String[] getDisps() throws SQLException {
        return SstagUtil.sanitize(getDispsNoenc());
    }

    public String getDispNoenc() throws SQLException {
        return clmMetaMst.getPrefix() + PhoenixUtil.dataCat(getDispsNoenc(), getDispDelimiter())
                + clmMetaMst.getSuffix();
    }

    public String[] getDispsNoenc() throws SQLException {
        return getValuesNoenc();
    }

    public String[] getFormValue() {
        return SstagUtil.splitNewLine(clmData.getData());
    }

    public List<SelectItemBean> getSelectMst() throws SQLException {

        // カラムメタ情報に登録されている選択肢マスタを使用する。
        List<SelectItemBean> selectItemList = null;
        if (clmMetaMst.getSelMstSiteId() != 0 && !PhoenixUtil.isEmpty(clmMetaMst.getSelMstId())) {
            selectItemList = SelectMstDb.getItemList(request, clmMetaMst.getSelMstSiteId(), clmMetaMst.getSelMstId());
        }

        return selectItemList;

    }

    /**
     * 数値 type=1
     * 
     * @author kurinami
     */
    protected static class Type1 extends ClmMetaMstUtil {

        @Override
        public String[] getValuesNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            if (clmMetaMst.getOutStyleComma().equals(ClmMetaMstBean.OUT_STYLE_COMMA_YES)) {
                for (int i = 0; i < values.length; i++) {
                    values[i] = new DecimalFormat().format(ValueUtil.todouble(values[i]));
                }
            }
            return values;
        }

    }

    /**
     * テキスト type=2
     * 
     * @author kurinami
     */
    protected static class Type2 extends ClmMetaMstUtil {

    }

    /**
     * 複数行テキスト type=3
     * 
     * @author kurinami
     */
    protected static class Type3 extends ClmMetaMstUtil {

        @Override
        public String[] getRaws() {
            return new String[] { clmData.getData() };
        }

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();
            return toBr(disps);
        }

        @Override
        public String[] getDisps() throws SQLException {
            String[] disps = SstagUtil.sanitize(super.getDispsNoenc());
            return toBr(disps);
        }

        @Override
        public String getDispNoenc() throws SQLException {
            return clmMetaMst.getPrefix() + PhoenixUtil.concat(getDispsNoenc(), getDispDelimiter())
                    + clmMetaMst.getSuffix();
        }

        @Override
        public String getDisp() throws SQLException {
            return clmMetaMst.getPrefix() + PhoenixUtil.concat(getDisps(), getDispDelimiter()) + clmMetaMst.getSuffix();
        }

        private String[] toBr(String[] disps) {
            for (int i = 0; i < disps.length; i++) {
                disps[i] = disps[i].replaceAll("\r\n", "<br />");
                disps[i] = disps[i].replaceAll("\r", "<br />");
                disps[i] = disps[i].replaceAll("\n", "<br />");
            }
            return disps;
        }

    }

    /**
     * タグテキスト(HTML,xml等) type=4
     * 
     * @author kurinami
     */
    protected static class Type4 extends ClmMetaMstUtil {

        @Override
        public String[] getRaws() {
            return new String[] { clmData.getData() };
        }

        @Override
        public String getValue() throws SQLException {
            return getValueNoenc();
        }

        @Override
        public String[] getValues() throws SQLException {
            return getValuesNoenc();
        }

        @Override
        public String getDisp() throws SQLException {
            return getDispNoenc();
        }

        @Override
        public String[] getDisps() throws SQLException {
            return getDispsNoenc();
        }

    }

    /**
     * 画像 type=5
     * 
     * @author kurinami
     */
    protected static class Type5 extends ClmMetaMstUtil {

        @Override
        public String getValueNoenc() throws SQLException {
            String[] data = super.getValuesNoenc();
            if (PhoenixUtil.isEmpty(data)) {
                return "";
            } else {
                return data[0];
            }
        }

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();
            return makeParam(disps);
        }

        @Override
        public String[] getDisps() throws SQLException {
            String[] disps = SstagUtil.sanitize(super.getDispsNoenc());
            return makeParam(disps);
        }

        @Override
        public String getDispNoenc() throws SQLException {
            String[] disps = getDispsNoenc();
            return makeImgTag(disps);
        }

        @Override
        public String getDisp() throws SQLException {
            String[] disps = getDisps();
            return makeImgTag(disps);
        }

        protected String[] makeParam(String[] disps) {

            if (disps.length > 0 && !PhoenixUtil.isEmpty(disps[0])) {
                disps[0] = "src=\"" + disps[0] + "\"";
            }
            if (disps.length > 1 && !PhoenixUtil.isEmpty(disps[1])) {
                disps[1] = "width=\"" + disps[1] + "\"";
            }
            if (disps.length > 2 && !PhoenixUtil.isEmpty(disps[2])) {
                disps[2] = "height=\"" + disps[2] + "\"";
            }
            if (disps.length > 3 && !PhoenixUtil.isEmpty(disps[3])) {
                disps[3] = "alt=\"" + disps[3] + "\"";
            }
            if (disps.length > 4 && !PhoenixUtil.isEmpty(disps[4])) {
                disps[4] = "href=\"" + disps[4] + "\"";
            }
            if (disps.length > 5 && !PhoenixUtil.isEmpty(disps[5])) {
                disps[5] = "target=\"" + disps[5] + "\"";
            }

            return disps;
        }

        protected String makeImgTag(String[] disps) {

            if (PhoenixUtil.isEmpty(disps)) {
                return "";
            }

            StringBuffer sb = new StringBuffer();

            sb.append("<img ");
            sb.append(disps[0]);

            if (disps.length > 1 && !PhoenixUtil.isEmpty(disps[1])) {
                sb.append(" ");
                sb.append(disps[1]);
            }

            if (disps.length > 2 && !PhoenixUtil.isEmpty(disps[2])) {
                sb.append(" ");
                sb.append(disps[2]);
            }

            if (disps.length > 3 && !PhoenixUtil.isEmpty(disps[3])) {
                sb.append(" ");
                sb.append(disps[3]);
            }

            sb.append(" />");

            if (disps.length > 4 && !PhoenixUtil.isEmpty(disps[4])) {
                StringBuffer subSb = new StringBuffer();
                subSb.append("<a ");
                subSb.append(disps[4]);

                if (disps.length > 5 && !PhoenixUtil.isEmpty(disps[5])) {
                    subSb.append(" ");
                    subSb.append(disps[5]);
                }

                subSb.append(">");

                sb.insert(0, subSb.toString());
                sb.append("</a>");
            }

            return sb.toString();
        }

    }

    /**
     * 画像URL type=6
     * 
     * @author kurinami
     */
    protected static class Type6 extends Type5 {

        @Override
        protected String[] makeParam(String[] disps) {

            if (disps.length > 0 && !PhoenixUtil.isEmpty(disps[0])) {
                disps[0] = "src=\"" + disps[0] + "\"";
            }

            if (disps.length > 2 && !PhoenixUtil.isEmpty(disps[2])) {
                disps[2] = "width=\"" + disps[2] + "\"";
            }
            if (disps.length > 3 && !PhoenixUtil.isEmpty(disps[3])) {
                disps[3] = "height=\"" + disps[3] + "\"";
            }
            if (disps.length > 4 && !PhoenixUtil.isEmpty(disps[4])) {
                disps[4] = "alt=\"" + disps[4] + "\"";
            }
            if (disps.length > 5 && !PhoenixUtil.isEmpty(disps[5])) {
                disps[5] = "href=\"" + disps[5] + "\"";
            }
            if (disps.length > 6 && !PhoenixUtil.isEmpty(disps[6])) {
                disps[6] = "target=\"" + disps[6] + "\"";
            }

            return disps;
        }

        @Override
        protected String makeImgTag(String[] disps) {

            if (PhoenixUtil.isEmpty(disps)) {
                return "";
            }

            StringBuffer sb = new StringBuffer();

            sb.append("<img ");
            sb.append(disps[0]);
            sb.append(" border=\"0\"");

            if (disps.length > 2 && !PhoenixUtil.isEmpty(disps[2])) {
                sb.append(" ");
                sb.append(disps[2]);
            }

            if (disps.length > 3 && !PhoenixUtil.isEmpty(disps[3])) {
                sb.append(" ");
                sb.append(disps[3]);
            }

            if (disps.length > 4 && !PhoenixUtil.isEmpty(disps[4])) {
                sb.append(" ");
                sb.append(disps[4]);
            }

            sb.append(" />");

            if (disps.length > 5 && !PhoenixUtil.isEmpty(disps[5])) {
                StringBuffer subSb = new StringBuffer();
                subSb.append("<a ");
                subSb.append(disps[5]);

                if (disps.length > 6 && !PhoenixUtil.isEmpty(disps[6])) {
                    subSb.append(" ");
                    subSb.append(disps[6]);
                }

                subSb.append(">");

                sb.insert(0, subSb.toString());
                sb.append("</a>");
            }

            return sb.toString();
        }

    }

    /**
     * 日付 type=7
     * 
     * @author kurinami
     */
    protected static class Type7 extends ClmMetaMstUtil {

        private static final String SOURCE_DATE_FORMAT = "yyyyMMdd";

        private static final String DEFAULT_DATE_FORMAT = "yyyy/MM/dd";

        @Override
        public String[] getValuesNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            SimpleDateFormat sourceSdf = getSourceFormat();
            SimpleDateFormat targetSdf = getTargetFormat();
            for (int i = 0; i < values.length; i++) {
                if (!PhoenixUtil.isEmpty(values[i])) {
                    try {
                        Date date = sourceSdf.parse(values[i]);
                        values[i] = targetSdf.format(date);
                    } catch (ParseException e) {
                        log.error("日付解析エラー[" + values[i] + "]", e);
                    }
                }
            }
            return values;
        }

        protected String getSourceFormatPattern() {
            return SOURCE_DATE_FORMAT;
        }

        protected String getDefaultFormatPattern() {
            return DEFAULT_DATE_FORMAT;
        }

        private SimpleDateFormat getSourceFormat() {
            return new SimpleDateFormat(getSourceFormatPattern());
        }

        private SimpleDateFormat getTargetFormat() {
            return toDateFormat(clmMetaMst.getOutStyleDate(), clmMetaMst.getOutStyleTime());
        }

        private SimpleDateFormat toDateFormat(String outStyleDate, String outStyleTime) {

            Locale locale = Locale.US;
            StringBuffer sb = new StringBuffer();

            for (int i = 0; i < outStyleDate.length(); i++) {
                switch (outStyleDate.charAt(i)) {
                case 'm':
                    sb.append('M');
                    break;
                case 'w':
                    sb.append('E');
                    break;
                case 'W':
                    sb.append('E');
                    locale = new Locale("ja", "JP", "JP");
                    break;
                case 'G':
                    sb.append("GGGG");
                    locale = new Locale("ja", "JP", "JP");
                    break;
                case 'Y':
                    sb.append("yy");
                    locale = new Locale("ja", "JP", "JP");
                    break;
                default:
                    sb.append(outStyleDate.charAt(i));
                }
            }

            if (!PhoenixUtil.isEmpty(outStyleDate) && !PhoenixUtil.isEmpty(outStyleTime)) {
                sb.append(" ");
            }

            for (int i = 0; i < outStyleTime.length(); i++) {
                switch (outStyleTime.charAt(i)) {
                case 'H':
                    sb.append('H');
                    break;
                case 'h':
                    sb.append('K');
                    break;
                case 'M':
                    sb.append('m');
                    break;
                case 'S':
                    sb.append('s');
                    break;
                case 'A':
                case 'a':
                    sb.append('a');
                    break;
                case 'P':
                case 'p':
                    break;
                case 'Z':
                    sb.append('a');
                    locale = new Locale("ja", "JP", "JP");
                    break;
                default:
                    sb.append(outStyleTime.charAt(i));
                }
            }

            if (sb.length() > 0) {
                return new SimpleDateFormat(sb.toString(), locale);
            } else {
                return new SimpleDateFormat(getDefaultFormatPattern());
            }
        }

        @Override
        public String[] getFormValue() {
            String[] formValue = super.getFormValue();
            if (PhoenixUtil.isArrayEmpty(formValue)) {
                return new String[] {};
            } else if (formValue.length == 1 && formValue[0].length() == "yyyyMMdd".length()) {
                String year = formValue[0].substring(0, 4);
                String month = formValue[0].substring(4, 6);
                String day = formValue[0].substring(6, 8);
                return new String[] { year, month, day };
            } else {
                return formValue;
            }
        }

    }

    /**
     * 時刻 type=8
     * 
     * @author kurinami
     */
    protected static class Type8 extends Type7 {

        private static final String SOURCE_TIME_FORMAT = "HHmmss";

        private static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";

        @Override
        protected String getSourceFormatPattern() {
            return SOURCE_TIME_FORMAT;
        }

        @Override
        protected String getDefaultFormatPattern() {
            return DEFAULT_TIME_FORMAT;
        }

        @Override
        public String[] getFormValue() {
            String[] formValue = super.getFormValue();
            if (PhoenixUtil.isArrayEmpty(formValue)) {
                return new String[] {};
            } else if (formValue.length == 1 && formValue[0].length() == "HHmmss".length()) {
                String hour = formValue[0].substring(0, 2);
                String minute = formValue[0].substring(2, 4);
                String second = formValue[0].substring(4, 6);
                return new String[] { hour, minute, second };
            } else {
                return formValue;
            }
        }
    }

    /**
     * タイムスタンプ(日時） type=9
     * 
     * @author kurinami
     */
    protected static class Type9 extends Type7 {

        private static final String SOURCE_DATETIME_FORMAT = "yyyyMMddHHmmss";

        private static final String DEFAULT_DATETIME_FORMAT = "yyyy年 MM月 dd日 HH時 mm分 ss秒";

        @Override
        protected String getSourceFormatPattern() {
            return SOURCE_DATETIME_FORMAT;
        }

        @Override
        protected String getDefaultFormatPattern() {
            return DEFAULT_DATETIME_FORMAT;
        }

        @Override
        public String[] getFormValue() {
            String[] formValue = super.getFormValue();
            if (PhoenixUtil.isArrayEmpty(formValue)) {
                return new String[] {};
            } else if (formValue.length == 1 && formValue[0].length() == "yyyyMMddHHmmss".length()) {
                String year = formValue[0].substring(0, 4);
                String month = formValue[0].substring(4, 6);
                String day = formValue[0].substring(6, 8);
                String hour = formValue[0].substring(8, 10);
                String minute = formValue[0].substring(10, 12);
                String second = formValue[0].substring(12, 14);
                return new String[] { year, month, day, hour, minute, second };
            } else {
                return formValue;
            }
        }
    }

    /**
     * 氏名(氏+名) type=11
     * 
     * @author kurinami
     */
    protected static class Type11 extends ClmMetaMstUtil {

        @Override
        protected String getValueDelimiter() {
            return getDelimiter();
        }

        @Override
        protected String getDispDelimiter() {
            return getDelimiter();
        }

        protected String getDelimiter() {
            return "　";
        }

    }

    /**
     * フリガナ(シ+メイ) type=12
     * 
     * @author kurinami
     */
    protected static class Type12 extends Type11 {

        @Override
        protected String getDelimiter() {
            // 全角→半角変換の場合のみ半角空白
            if (clmMetaMst.getWcharConv() == ClmMetaMstBean.WCHAR_CONV_NARROW) {
                return " ";
            } else {
                return "　";
            }
        }

    }

    /**
     * 西暦生年月日(年+月+日） type=13
     * 
     * @author kurinami
     */
    protected static class Type13 extends Type7 {
    }

    /**
     * 和暦混合生年月日(年+月+日） type=14
     * 
     * @author kurinami
     */
    protected static class Type14 extends Type7 {
    }

    /**
     * 和暦元号選択(明治、大正、昭和、平成） type=15
     * 
     * @author kurinami
     */
    protected static class Type15 extends ClmMetaMstUtil {
    }

    /**
     * 年齢 type=16
     * 
     * @author kurinami
     */
    protected static class Type16 extends ClmMetaMstUtil {

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();
            for (int i = 0; i < disps.length; i++) {
                if (!PhoenixUtil.isEmpty(disps[i])) {
                    disps[i] += "歳";
                }
            }
            return disps;
        }

    }

    /**
     * 性別 type=17
     * 
     * @author kurinami
     */
    protected static class Type17 extends ClmMetaMstUtil {

        @Override
        public String[] getValuesNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            String[] result = new String[values.length];
            for (int i = 0; i < result.length; i++) {
                if (values[i].equalsIgnoreCase("1")) {
                    result[i] = "m";
                } else if (values[i].equalsIgnoreCase("0")) {
                    result[i] = "f";
                } else {
                    result[i] = "";
                }
            }
            return result;
        }

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();
            String[] result = new String[disps.length];
            for (int i = 0; i < result.length; i++) {
                if (disps[i].equalsIgnoreCase("m")) {
                    result[i] = "男性";
                } else if (disps[i].equalsIgnoreCase("f")) {
                    result[i] = "女性";
                } else {
                    result[i] = "";
                }
            }
            return result;
        }

    }

    /**
     * 個人住所 type=18
     * 
     * @author kurinami
     */
    protected static class Type18 extends ClmMetaMstUtil {
        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_PREF_MST);
        }

        @Override
        public String[] getValuesNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            if (values.length > 1 && !PhoenixUtil.isEmpty(values[1])) {
                List<SelectItemBean> selectItemList = getSelectMst();
                for (SelectItemBean selectItem : selectItemList) {
                    if (selectItem.getValue().equals(values[1])) {
                        values[1] = selectItem.getName();
                        break;
                    }
                }

            }
            return values;
        }

        @Override
        public String getValueNoenc() throws SQLException {
            String[] values = getValuesNoenc();
            if (!PhoenixUtil.isEmpty(values) && !PhoenixUtil.isEmpty(values[0])) {
                values[0] = "〒" + values[0];
            }
            return clmMetaMst.getPrefix() + PhoenixUtil.dataCat(values, "\n") + clmMetaMst.getSuffix();
        }

        @Override
        public String getDispNoenc() throws SQLException {
            String[] disps = getDispsNoenc();
            if (!PhoenixUtil.isEmpty(disps) && !PhoenixUtil.isEmpty(disps[0])) {
                disps[0] = "〒" + disps[0];
            }
            return clmMetaMst.getPrefix() + PhoenixUtil.dataCat(disps, "<br />") + clmMetaMst.getSuffix();
        }

        @Override
        public String getDisp() throws SQLException {
            String[] disps = getDisps();
            if (!PhoenixUtil.isEmpty(disps) && !PhoenixUtil.isEmpty(disps[0])) {
                disps[0] = "〒" + disps[0];
            }
            return clmMetaMst.getPrefix() + PhoenixUtil.dataCat(disps, "<br />") + clmMetaMst.getSuffix();
        }

        @Override
        public String[] getFormValue() {
            String[] formValue = super.getFormValue();
            if (PhoenixUtil.isEmpty(formValue)) {
                return formValue;
            }

            String[] result = new String[formValue.length + 1];
            String[] zipValue = PhoenixUtil.split(formValue[0], "-");
            result[0] = zipValue.length > 0 ? zipValue[0] : "";
            result[1] = zipValue.length > 1 ? zipValue[1] : "";
            for (int i = 1; i < formValue.length; i++) {
                result[i + 1] = formValue[i];
            }
            return result;
        }
    }

    /**
     * 会社住所 type=19
     * 
     * @author kurinami
     */
    protected static class Type19 extends Type18 {
    }

    /**
     * 国コード type=20
     * 
     * @author kurinami
     */
    protected static class Type20 extends Type51 {
        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_COUNTRY_MST);
        }
    }

    /**
     * 都道府県 type=21
     * 
     * @author kurinami
     */
    protected static class Type21 extends Type51 {
        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_PREF_MST);
        }
    }

    /**
     * エリアコード type=22
     * 
     * @author kurinami
     */
    protected static class Type22 extends Type51 {
        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_AREA_MST);
        }
    }

    /**
     * 郵便番号 type=23
     * 
     * @author kurinami
     */
    protected static class Type23 extends Type24 {

        @Override
        public String getDispNoenc() throws SQLException {
            String disp = PhoenixUtil.dataCat(getDispsNoenc(), getDispDelimiter());
            disp = PhoenixUtil.isEmpty(disp) ? "" : "〒" + disp;
            return clmMetaMst.getPrefix() + disp + clmMetaMst.getSuffix();
        }

    }

    /**
     * 電話番号 type=24
     * 
     * @author kurinami
     */
    protected static class Type24 extends ClmMetaMstUtil {

        @Override
        protected String getRawDelimiter() {
            return "";
        }

        @Override
        protected String getValueDelimiter() {
            return "-";
        }

        @Override
        protected String getDispDelimiter() {
            return "-";
        }

    }

    /**
     * E-mail type=25
     * 
     * @author kurinami
     */
    protected static class Type25 extends ClmMetaMstUtil {

    }

    /**
     * E-mail(確認入力付き） type=26
     * 
     * @author kurinami
     */
    protected static class Type26 extends ClmMetaMstUtil {

        @Override
        public String[] getFormValue() {
            String[] formValue = super.getFormValue();
            if (PhoenixUtil.isEmpty(formValue)) {
                return formValue;
            }
            return new String[] { formValue[0], formValue[0] };
        }
    }

    /**
     * 秘匿入力 type=27
     * 
     * @author kurinami
     */
    protected static class Type27 extends ClmMetaMstUtil {

        @Override
        public String[] getValuesNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            for (int i = 0; i < values.length; i++) {
                values[i] = ValueUtil.lpad("", '*', values[i].length());
            }
            return values;
        }

    }

    /**
     * 秘匿入力（確認入力付き) type=28
     * 
     * @author kurinami
     */
    protected static class Type28 extends Type27 {

        @Override
        public String[] getFormValue() {
            String[] formValue = super.getFormValue();
            if (PhoenixUtil.isEmpty(formValue)) {
                return formValue;
            }
            return new String[] { formValue[0], formValue[0] };
        }
    }

    /**
     * リンク (テキスト+URL) type=29
     * 
     * @author kurinami
     */
    protected static class Type29 extends ClmMetaMstUtil {

        @Override
        public String getValueNoenc() throws SQLException {
            String[] values = getValuesNoenc();
            return makeLinkTag(values);
        }

        @Override
        public String getValue() throws SQLException {
            String[] values = getValues();
            return makeLinkTag(values);
        }

        @Override
        public String getDispNoenc() throws SQLException {
            String[] disps = getDispsNoenc();
            return makeLinkTag(disps);
        }

        @Override
        public String getDisp() throws SQLException {
            String[] disps = getDisps();
            return makeLinkTag(disps);
        }

        private String makeLinkTag(String[] values) {

            if (PhoenixUtil.isEmpty(values)) {
                return "";
            }

            StringBuffer sb = new StringBuffer();

            sb.append("<a href=\"");
            if (values.length > 1 && !PhoenixUtil.isEmpty(values[1])) {
                sb.append(values[1]);
            }
            sb.append("\"");
            if (values.length > 2 && !PhoenixUtil.isEmpty(values[2])) {
                sb.append(" target=\"");
                sb.append(values[2]);
                sb.append("\"");
            }
            sb.append(">");
            if (values.length > 0 && !PhoenixUtil.isEmpty(values[0])) {
                sb.append(values[0]);
            }
            sb.append("</a>");

            return sb.toString();
        }
    }

    /**
     * 通貨単位 type=30
     * 
     * @author kurinami
     */
    protected static class Type30 extends Type51 {
        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_CURRENCY_MST);
        }
    }

    /**
     * 単一選択肢(radio) type=51
     * 
     * @author kurinami
     */
    protected static class Type51 extends ClmMetaMstUtil {

        @Override
        public String getDispDelimiter() {
            return ",";
        }

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();

            List<SelectItemBean> selectItemList = getSelectMst();
            if (selectItemList != null) {
                // 選択肢マスタが存在した場合、
                String[] result = new String[disps.length];
                for (int i = 0; i < result.length; i++) {
                    result[i] = "";
                    for (SelectItemBean selectItem : selectItemList) {
                        if (disps[i].equals(selectItem.getValue())) {
                            result[i] = selectItem.getName();
                            break;
                        }
                    }
                }
                disps = result;
            }

            return disps;
        }

    }

    /**
     * 単一選択肢(select) type=52
     * 
     * @author kurinami
     */
    protected static class Type52 extends Type51 {
    }

    /**
     * 複数選択肢(checkbox) type=53
     * 
     * @author kurinami
     */
    protected static class Type53 extends Type51 {
    }

    /**
     * 複数選択肢(list) type=54
     * 
     * @author kurinami
     */
    protected static class Type54 extends Type51 {
    }

    /**
     * 単一選択肢(radio)→画像使用 type=55
     * 
     * @author kurinami
     */
    protected static class Type55 extends ClmMetaMstUtil {
        // TODO kurinami 【未実装】
    }

    /**
     * 単一選択肢(select)→画像使用 type=56
     * 
     * @author kurinami
     */
    protected static class Type56 extends ClmMetaMstUtil {
        // TODO kurinami 【未実装】
    }

    /**
     * 複数選択肢(checkbox)→画像使用 type=57
     * 
     * @author kurinami
     */
    protected static class Type57 extends ClmMetaMstUtil {
        // TODO kurinami 【未実装】
    }

    /**
     * 複数選択肢(list)→画像使用 type=58
     * 
     * @author kurinami
     */
    protected static class Type58 extends ClmMetaMstUtil {
        // TODO kurinami 【未実装】
    }

    /**
     * GUID type=G1
     * 
     * @author kurinami
     */
    protected static class TypeG1 extends ClmMetaMstUtil {
    }

    /**
     * GSID type=G2
     * 
     * @author kurinami
     */
    protected static class TypeG2 extends ClmMetaMstUtil {
    }

    /**
     * SSID type=G3
     * 
     * @author kurinami
     */
    protected static class TypeG3 extends ClmMetaMstUtil {
    }

    /**
     * GOID type=G4
     * 
     * @author kurinami
     */
    protected static class TypeG4 extends ClmMetaMstUtil {
    }

    /**
     * TOID type=G5
     * 
     * @author kurinami
     */
    protected static class TypeG5 extends ClmMetaMstUtil {
    }

    /**
     * NUMBER/DECIMAL/INT/FLOAT type=P1
     * 
     * @author kurinami
     */
    protected static class TypeP1 extends Type1 {
    }

    /**
     * CHAR type=P2
     * 
     * @author kurinami
     */
    protected static class TypeP2 extends Type3 {
    }

    /**
     * VARCHAR/VARCHAR2 type=P3
     * 
     * @author kurinami
     */
    protected static class TypeP3 extends Type3 {
    }

    /**
     * TEXT/CLOB type=P4
     * 
     * @author kurinami
     */
    protected static class TypeP4 extends Type3 {
    }

    /**
     * BLOB/RAW/BFILE type=P6
     * 
     * @author kurinami
     */
    protected static class TypeP6 extends Type3 {
    }

    /**
     * DATE type=P7
     * 
     * @author kurinami
     */
    protected static class TypeP7 extends Type7 {
    }

    /**
     * TIMESTAMP type=P9
     * 
     * @author kurinami
     */
    protected static class TypeP9 extends Type9 {
    }

}
