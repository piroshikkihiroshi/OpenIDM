package jp.co.webcrew.filters.filters.replace.htmlparser;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Stack;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.loader.util.LoadUtil;
import jp.co.webcrew.perflog.PerfLogger;
import jp.co.webcrew.proctime.SstagTimer;
import jp.co.webcrew.proctime.SstagTimer.SstagTimerInfo;

/**
 * サーバ処理タグを制御するcallbackクラス。
 * 
 * @author kurinami
 */
public class SSTagReplaceParserCallback extends HtmlReplaceParserCallback {

	/** サーバタグのタグ名 */
	public static final String TARGET_TAG_NAME = "sstag";

	/** サーバタグの種別を表すパラメータキー名 */
	public static final String TYPE_PARAM_KEY = "type";

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(SSTagReplaceParserCallback.class);
	
	/** パラメータを格納するときのキー */
	private static final String PARAMETERS_KEY = "SSTAG_PARAMETERS";
	
	/** 内部htmlを格納するときのキー */
	private static final String INNER_TEXT_KEY = "SSTAG_INNER_TEXT";
    
    /** 自分自身htmlを格納するときのキー */
    private static final String OWN_TEXT_KEY = "SSTAG_OWN_TEXT";
	
	/** type名とクラス名のマップ */
	private static Map sstagMap = null;
	
	/** リクエストオブジェクト */
	private HttpServletRequest request = null;

	/** レスポンスオブジェクト */
	private HttpServletResponse response = null;

	/** ネストに対尾するためサーバタグ処理情報を格納するスタック */
	private Stack nestStack = new Stack();

	static {
		
		sstagMap = new HashMap();
		
		// 共通sstag
		sstagMap.put("ad", "jp.co.webcrew.filters.filters.replace.sstag.AdExecuter");
		sstagMap.put("blank", "jp.co.webcrew.filters.filters.replace.sstag.BlankExecuter");
		sstagMap.put("dbrecordget", "jp.co.webcrew.filters.filters.replace.sstag.DbRecordGetExecuter");
		sstagMap.put("ifthenelse", "jp.co.webcrew.filters.filters.replace.sstag.IfThenElseExecuter");
		sstagMap.put("include", "jp.co.webcrew.filters.filters.replace.sstag.IncludeExecuter");
		sstagMap.put("test", "jp.co.webcrew.filters.filters.replace.sstag.TestExecuter");
		sstagMap.put("urlkwd", "jp.co.webcrew.filters.filters.replace.sstag.UrlKwdExecuter");
		sstagMap.put("auto_redirect", "jp.co.webcrew.filters.filters.replace.sstag.AutoRedirectExecuter");
		sstagMap.put("member_regist", "jp.co.webcrew.filters.filters.replace.sstag.MemberRegistExecuter");
		sstagMap.put("mag_reg", "jp.co.webcrew.filters.filters.replace.sstag.MagRegExecuter");
		// ログイン状態・会員登録状態で、表示htmlを制御するsstag
        sstagMap.put("displaycontrol", "jp.co.webcrew.filters.filters.replace.sstag.DisplayControlExecuter");
		// for timeSwitching
		sstagMap.put("timeswitching", "jp.co.webcrew.filters.filters.replace.sstag.TimeSwitchingExecuter");		
		// for sortingMobileContents
		sstagMap.put("sortingmobilecontents", "jp.co.webcrew.filters.filters.replace.sstag.SortingMobileContentsExecuter");
        // DoCoMoマイメニュー表示するsstag
        sstagMap.put("docomomymenureglink", "jp.co.webcrew.filters.filters.replace.sstag.DocomoMymenuRegLinkExecuter");

        //ポイント広告
        sstagMap.put("pointad", "jp.co.webcrew.filters.filters.replace.sstag.PointAdExecuter");
        
        //絵文字表示
        sstagMap.put("emoji", "jp.co.webcrew.filters.filters.replace.sstag.EmojiExecuter");
		/*		
		// for とな芝
		sstagMap.put("basis", "jp.co.webcrew.tns.sstag.BasisExecuter");
		sstagMap.put("bbscfm", "jp.co.webcrew.tns.sstag.BbsCfmExecuter");
		sstagMap.put("bbs", "jp.co.webcrew.tns.sstag.BbsExecuter");
		sstagMap.put("bbsform", "jp.co.webcrew.tns.sstag.BbsFormExecuter");
		sstagMap.put("bbssimple", "jp.co.webcrew.tns.sstag.BbsSimpleExecuter");
		sstagMap.put("bbsthanks", "jp.co.webcrew.tns.sstag.BbsThanksExecuter");
		sstagMap.put("breadcrumbs", "jp.co.webcrew.tns.sstag.BreadcrumbsExecuter");
		sstagMap.put("category", "jp.co.webcrew.tns.sstag.CategoryExecuter");
		sstagMap.put("categoryrankinglist", "jp.co.webcrew.tns.sstag.CategoryRankingListExecuter");
		sstagMap.put("contact", "jp.co.webcrew.tns.sstag.ContactExecuter");
		sstagMap.put("contactthanks", "jp.co.webcrew.tns.sstag.ContactThanksExecuter");
		sstagMap.put("element", "jp.co.webcrew.tns.sstag.ElementExecuter");
		sstagMap.put("headeraccount", "jp.co.webcrew.tns.sstag.HeaderAccountExecuter");
		sstagMap.put("news", "jp.co.webcrew.tns.sstag.NewsExecuter");
		sstagMap.put("rankingrelation", "jp.co.webcrew.tns.sstag.RankingRelationExecuter");
		sstagMap.put("requestcfm", "jp.co.webcrew.tns.sstag.RequestCfmExecuter");
		sstagMap.put("requestform", "jp.co.webcrew.tns.sstag.RequestFormExecuter");
		sstagMap.put("requestformsimple", "jp.co.webcrew.tns.sstag.RequestFormSimpleExecuter");
		sstagMap.put("requestthanks", "jp.co.webcrew.tns.sstag.RequestThanksExecuter");
		sstagMap.put("search", "jp.co.webcrew.tns.sstag.SearchExecuter");
		sstagMap.put("sitemapmypage", "jp.co.webcrew.tns.sstag.SitemapMypageExecuter");
		sstagMap.put("staticranking", "jp.co.webcrew.tns.sstag.StaticRankingExecuter");
		sstagMap.put("staticrankingsimple", "jp.co.webcrew.tns.sstag.StaticRankingSimpleExecuter");
		sstagMap.put("subcategory", "jp.co.webcrew.tns.sstag.SubcategoryExecuter");
		sstagMap.put("top", "jp.co.webcrew.tns.sstag.TopExecuter");
		sstagMap.put("topics", "jp.co.webcrew.tns.sstag.TopicsExecuter");
		sstagMap.put("weeklysbf", "jp.co.webcrew.tns.sstag.WeeklySbfExecuter");
		sstagMap.put("attentions", "jp.co.webcrew.tns.sstag.AttentionsExecuter"); 
    
    	sstagMap.put("cresearchonballotlist", "jp.co.webcrew.tns.sstag.CResearchOnBallotListExecuter");
    	sstagMap.put("cresearchvotesranking", "jp.co.webcrew.tns.sstag.CResearchVotesRankingExecuter");
    	sstagMap.put("cresearchhistorylist", "jp.co.webcrew.tns.sstag.CResearchHistoryListExecuter");
    	sstagMap.put("cresearchvote", "jp.co.webcrew.tns.sstag.CResearchVoteExecuter");
    	sstagMap.put("cresearchresult", "jp.co.webcrew.tns.sstag.CResearchResultExecuter");
        
        //ポイント広告
        sstagMap.put("pointad", "jp.co.webcrew.filters.filters.replace.sstag.PointAdExecuter");
		
		//宝探しキャンペーン
		sstagMap.put("treasure", "jp.co.webcrew.tns.sstag.TreasureExecuter");
		sstagMap.put("treasurethanks","jp.co.webcrew.tns.sstag.TreasureThanksExecuter");

		*/
		
		// sstagのサイト固有定義の動作確認  (0024999) - Start
		/*
		// for FXキング
		sstagMap.put("fxnavaccount", "jp.fxking.sstag.FxNavAccountExecuter");
		sstagMap.put("fxnavmypage", "jp.fxking.sstag.FxNavMypageExecuter");
		sstagMap.put("fxheaderaccount", "jp.fxking.sstag.FxHeaderAccountExecuter");
		sstagMap.put("fxswapcalendarcurrent", "jp.fxking.sstag.FxSwapCalendarCurrentExecuter");
		sstagMap.put("fxswapcalendarprevious", "jp.fxking.sstag.FxSwapCalendarPreviousExecuter");
		sstagMap.put("fxswapsummary", "jp.fxking.sstag.FxSwapSummaryExecuter");
		sstagMap.put("fxswapranking", "jp.fxking.sstag.FxSwapRankingExecuter");
		sstagMap.put("fxratiooflongshort", "jp.fxking.sstag.FxRatioOfLongShortExecuter");
		
		sstagMap.put("fxnewslist", "jp.fxking.sstag.FxNewsListExecuter");
		sstagMap.put("fxnewspage", "jp.fxking.sstag.FxNewsPageExecuter");
		sstagMap.put("fxupdatelist", "jp.fxking.sstag.FxUpdateListExecuter");
		sstagMap.put("fxsaibaracommentlist", "jp.fxking.sstag.FxSaibaraCommentListExecuter");
		sstagMap.put("fxcurrencyreportlist", "jp.fxking.sstag.FxCurrencyReportListExecuter");
		sstagMap.put("fxcurrencyreportpage", "jp.fxking.sstag.FxCurrencyReportPageExecuter");

		sstagMap.put("fxdealinglotssummary", "jp.fxking.sstag.FxDealingLotsSummaryExecuter"); //// for Dealing Lots
		sstagMap.put("fxdealinglotsdetail", "jp.fxking.sstag.FxDealingLotsDetailExecuter"); //// for Dealing Lots
		*/
		// sstagのサイト固有定義の動作確認  (0024999) - End

		// for mypage
        /* 
        sstagMap.put("campaign", "jp.co.webcrew.mypage.sstag.CampaignExecuter");
		sstagMap.put("campaignthanks", "jp.co.webcrew.mypage.sstag.CampaignThanksExecuter");
        */
		
		// for 新メルマガツール
		sstagMap.put("magshowcontents", "jp.co.webcrew.magtool.presentation.sstag.MagShowContentsExecuter");
		
        // for レーシック
        //sstagMap.put("cliniclist", "jp.co.webcrew.skaifuku.sstag.SkaifukuClinicListExecuter");
		
		sstagMap.put("cresearchonballotlist", "jp.co.webcrew.filters.filters.replace.sstag.CResearchOnBallotListExecuter");
		
		// 現在のポイント数、今月の取得ポイント数、順位を表示するSSTAｇ
		sstagMap.put("displaypoint", "jp.co.webcrew.filters.filters.replace.sstag.DisplayPointExecuter");
		
		// for サービス利用履歴
		sstagMap.put("servicehistoryregister", "jp.co.webcrew.filters.filters.replace.sstag.ServiceHistoryRegisterExecuter");
		
		// 携帯UIDを取得するSSTAG
		sstagMap.put("mobileuid", "jp.co.webcrew.filters.filters.replace.sstag.MobileUidExecuter");
		
		// ピザハットキャンペン用
		sstagMap.put("pizza_hut_apply", "jp.co.webcrew.filters.filters.replace.sstag.PizzaHutApplyExecuter");
        
        // メルマガ
        sstagMap.put("mailmaga", "jp.co.webcrew.filters.filters.replace.sstag.MailMagaExecuter");
        
        // システムエラーメッセージ用
        sstagMap.put("system_error_msg", "jp.co.webcrew.filters.filters.replace.sstag.SystemErrorMsgExecuter");
        
        // プロトコル変換用
        sstagMap.put("http_protocol", "jp.co.webcrew.filters.filters.replace.sstag.HttpProtocolExecuter");
        
		// クチコミ
		sstagMap.put("voice_list", "jp.co.webcrew.filters.filters.replace.sstag.VoiceListExecuter");
		
		// クチコミ
		sstagMap.put("voice_list_new", "jp.co.webcrew.filters.filters.replace.sstag.VoiceListNewExecuter");
		
		// プロモIDによる表示制御に関わる
		sstagMap.put("promo_display", "jp.co.webcrew.filters.filters.replace.sstag.PromoDisplayExecuter");

	    // コールリスト登録を行うsstag
	    sstagMap.put("calllist_regist", "jp.co.webcrew.filters.filters.replace.sstag.CallListRegistExecuter");

	
	}

	/**
	 * sstagのtype名とクラス名のマップを登録する。
	 * 
	 * @param type type名
	 * @param className クラス名(パッケージ名付き)
	 */
	public static void registSstag(String type, String className) {
		sstagMap.put(type, className);
	}
	
	/**
	 * コンストラクタ
	 * 
	 * @param request
	 * @param response
	 */
	public SSTagReplaceParserCallback(HttpServletRequest request, HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.htmlparser.HtmlReplaceParserCallback#handleComment(java.lang.String)
	 */
	public String handleComment(String data) {
		if (nestStack.empty()) {
			// サーバタグ中でなければ何もせずにそのままを返す。
			return data;
		} else {
			// サーバタグ中であれば何もせずに空を返す。
			return "";
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.HtmlReplaceParserCallback#handleStartTag(java.lang.String)
	 */
	public String handleStartTag(String data) {

		int fromIndex = 0;
		int toIndex;

		// タグ名の開始位置を求める。
		fromIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
				HtmlReplaceParser.TOKEN_SEP_CHARS);

		// タグ名が存在しない場合、
		if (fromIndex >= data.length() || data.charAt(fromIndex) == '>') {
			return data;
		}

		// タグ名を求める。
		toIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
				HtmlReplaceParser.TOKEN_SEP_CHARS);
		String tagName = data.substring(fromIndex, toIndex).trim()
				.toLowerCase();

		// タグが処理対象のものでない場合、そのまま返す。
		if (!tagName.toLowerCase().equals(TARGET_TAG_NAME)) {
			return data;
		}

		fromIndex = toIndex;

		// パラメータを解析する。
		Map parameters = new HashMap();
		parameters.putAll(HtmlReplaceParser.getParameterMap(data, fromIndex));

		// サーバタグ処理情報をスタックにつむ。
		Map info = new HashMap();
		info.put(PARAMETERS_KEY, parameters);
        info.put(OWN_TEXT_KEY, new StringBuffer(data));
		info.put(INNER_TEXT_KEY, new StringBuffer());
		nestStack.push(info);

		return "";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.htmlparser.HtmlReplaceParserCallback#handleEndTag(java.lang.String)
	 */
	public String handleEndTag(String data) {

		// サーバタグ中でなければ何もせずにそのままを返す。
		if (nestStack.empty()) {
			return data;
		}

		int fromIndex = 0;
		int toIndex;

		// 「/」の開始位置を求める。
		fromIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
				HtmlReplaceParser.TOKEN_SEP_CHARS);

		// 不正な終了タグの場合、
		if (fromIndex >= data.length() || data.charAt(fromIndex) != '/') {
			return data;
		}

		// タグ名の開始位置を求める。
		fromIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
				HtmlReplaceParser.TOKEN_SEP_CHARS);

		// タグ名が存在しない場合、
		if (fromIndex >= data.length() || data.charAt(fromIndex) == '>') {
			return data;
		}

		// タグ名を求める。
		toIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
				HtmlReplaceParser.TOKEN_SEP_CHARS);
		String tagName = data.substring(fromIndex, toIndex).trim()
				.toLowerCase();

		// タグが処理対象のものでない場合、そのまま返す。
		if (!tagName.toLowerCase().equals(TARGET_TAG_NAME)) {
			return data;
		}

		// サーバタグ処理情報を抜き出す。
		Map info = (Map) nestStack.pop();
		Map parameters = (Map) info.get(PARAMETERS_KEY);
        StringBuffer ownText = (StringBuffer) info.get(OWN_TEXT_KEY);
        ownText.append(data);
		StringBuffer innerText = (StringBuffer) info.get(INNER_TEXT_KEY);

		log.debug("sstag inner_text: " + innerText.toString());
		// 開始タグ～終了タグまでの間のパラメータを解析する。
		parameters.putAll(HtmlReplaceParser.getParameterMap(innerText
				.toString(), 0));

		// パラメータの中でキーワード置換が完了していないものがあれば、置換を行う。
		parameters = keywordReplaceForParam(parameters, request, response);
		
		// コメントを示すキーワード#が登録されていた場合は、何もしない。
		if (parameters.containsKey("#")) {
		    return "";
		}
		
	    // サーバタグの処理を実行する。
        SSTagExecuter exe = null;
        try {
            String type = ValueUtil.nullToStr(parameters.get(TYPE_PARAM_KEY));
            if (type.matches("[\\'\\\"].*[\\'\\\"]")) {
                type = type.substring(1, type.length() - 1);
            }
            if (type.length() == 0) {
                log.warn("パラメータ type が指定されていません。");
                return "";
            }
            String className = (String) sstagMap.get(type.toLowerCase());
            if (ValueUtil.nullToStr(className).length() > 0) {
                exe = (SSTagExecuter) LoadUtil.newInstance(request, className);
            } else {
                exe = (SSTagExecuter) LoadUtil.newInstanceFromSstag(request, type.toLowerCase());
            }
        } catch (Exception e) {
            log.error("", e);
            return "";
        }

		if (nestStack.empty()) {
			// サーバタグがネストしていなければ、

	        log.debug("サーバサイドタグを実行 [classname: " + exe.getClass().getName());
	        
			SstagTimerInfo timerInfo=SstagTimer.start(exe.getClass(), parameters, request);
			try
			{
				PerfLogger.sstag_Start(exe.getClass(), parameters);
				String result = exe.execute(parameters, request, response);
				// 結果をそのまま返す。
				return result;
			}
			finally
			{
				SstagTimer.stop(timerInfo);
				PerfLogger.sstag_End(exe.getClass());
			}
	        
		} else {
			// サーバタグがネストしている場合、

		    String result = null;
		    if (exe.needDefer(parameters)) {
                log.debug("サーバサイドタグの実行を遅延 [classname: " + exe.getClass().getName());
		        result = ownText.toString();
		        // ネストしている側のsstagのパラメータの引用符をエスケープしておく。
		        result = HtmlReplaceParser.escapeAdd(result);
		    } else {
	            log.debug("サーバサイドタグを実行 [classname: " + exe.getClass().getName());
				PerfLogger.sstag_Start(exe.getClass(), parameters);
				try
				{
					result = exe.execute(parameters, request, response);
				}
				finally
				{
					PerfLogger.sstag_End(exe.getClass());
				}
		    }
		    
			// 1つ上のサーバタグ処理情報にテキストをつんでおく。
			info = (Map) nestStack.peek();
	        ownText = (StringBuffer) info.get(OWN_TEXT_KEY);
	        ownText.append(result);
			innerText = (StringBuffer) info.get(INNER_TEXT_KEY);
			innerText.append(result);
			return "";
		}
	}

	/* (non-Javadoc)
	 * @see jp.co.webcrew.filters.filters.replace.htmlparser.HtmlReplaceParserCallback#handleSimpleTag(java.lang.String)
	 */
	public String handleSimpleTag(String data) {
	    // タグの形式を開始と終了に置き換えてそれぞれのメソッドを呼ぶ。
	    data = data.replaceFirst("/>$",">");
	    handleStartTag(data);
	    String result = handleEndTag("</" + TARGET_TAG_NAME + ">");
	    return result; 
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.htmlparser.HtmlReplaceParserCallback#handleText(java.lang.String)
	 */
	public String handleText(String data) {

		// サーバタグ中でなければ何もせずにそのままを返す。
        if (nestStack.empty()) {
            
            // キーワード置換が完了していないものがあれば、置換を行っておく。
            data = new KeywordReplacer().replace(data, request, response);

            // sstag直後の改行はhtml表示のきれいにするため削除する。
            if (data.startsWith("\r\n")) {
                data = data.substring("\r\n".length());
            } else if (data.startsWith("\r")) {
                data = data.substring("r".length());
            } else if (data.startsWith("\n")) {
                data = data.substring("\n".length());
            }
            return data;
        }

		// サーバタグ処理情報にテキストをつんでおく。
		Map info = (Map) nestStack.peek();
        StringBuffer ownText = (StringBuffer) info.get(OWN_TEXT_KEY);
        ownText.append(data);
		StringBuffer innerText = (StringBuffer) info.get(INNER_TEXT_KEY);
		innerText.append(data);

		// 空を返す。
		return "";
	}
	
	/* (non-Javadoc)
	 * @see jp.co.webcrew.filters.filters.replace.htmlparser.HtmlReplaceParserCallback#finalCheck()
	 */
	public String finalCheck() {
	    StringBuffer sb = new StringBuffer();
	    if (!nestStack.empty() && SSTagExecuter.isTestMode()) {
	        sb.append("<pre>");
	        sb.append("sstagの終了タグが存在しません。\n");
	        
	        Map info = (Map) nestStack.pop();
	        StringBuffer ownText = (StringBuffer) info.get(OWN_TEXT_KEY);
	        
	        sb.append(ownText.substring(1, Math.min(100, ownText.length())));
	        sb.append(ownText.length() > 100 ? " ..." : "");

	        
            sb.append("</pre>");
	    }
	    return sb.toString();
	}

	public static Map keywordReplaceForParam(Map parameters, HttpServletRequest request, HttpServletResponse response) {
	    
	    Map result = new HashMap();
	    
	    KeywordReplacer replacer = new KeywordReplacer();
	    
	    Iterator i = parameters.keySet().iterator();
	    while(i.hasNext()) {
	        String key = (String) i.next();
	        String value = (String) parameters.get(key);
	        value = replacer.replace(value, request, response);
	        result.put(key, value);
	    }
	    
	    return result;
	}
}
