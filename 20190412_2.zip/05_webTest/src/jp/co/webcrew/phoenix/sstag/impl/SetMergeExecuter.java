package jp.co.webcrew.phoenix.sstag.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * スクリーニング結果の統合を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class SetMergeExecuter extends SSTagExecuter {

    /** パラメータ名：統合結果入れる一意なID(必須) */
    private static final String RESULT_ID_PARAM_KEY = "result_id";

    /** パラメータ名：スクリーニング結果リストが入っている一意なID(必須) */
    private static final String RESULT_A_PARAM_KEY = "result_a";

    /** パラメータ名：スクリーニング結果リストが入っている一意なID(必須） */
    private static final String RESULT_B_PARAM_KEY = "result_b";

    /** パラメータ名：result_A 内のスクリーニング結果の set名(省略時は先頭のセット） */
    private static final String SET_A_PARAM_KEY = "set_a";

    /** パラメータ名：result_B 内のスクリーニング結果の set名(省略時は先頭のセット） */
    private static final String SET_B_PARAM_KEY = "set_b";

    /** パラメータ名：set_A 内の項目名（省略時は先頭の name) */
    private static final String NAME_A_PARAM_KEY = "name_a";

    /** パラメータ名：set_B 内の項目名（省略時は先頭の name) */
    private static final String NAME_B_PARAM_KEY = "name_b";

    /** パラメータ名：5つの演算子 */
    private static final String OP_PARAM_KEY = "op";

    /** パラメータ名：結果保持期間 */
    // TODO kurinami 【確認】 ★ これはいらないのか？
    private static final String LIFE_PARAM_KEY = "life";

    /** ロガー */
    private static final Logger log = Logger.getLogger(SetMergeExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { RESULT_ID_PARAM_KEY, RESULT_A_PARAM_KEY, RESULT_B_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }
            
            // パラメータの取得
            String resultId = ValueUtil.nullToStr(parameters.get(RESULT_ID_PARAM_KEY));
            String resultA = ValueUtil.nullToStr(parameters.get(RESULT_A_PARAM_KEY));
            String resultB = ValueUtil.nullToStr(parameters.get(RESULT_B_PARAM_KEY));
            String setA = ValueUtil.nullToStr(parameters.get(SET_A_PARAM_KEY));
            String setB = ValueUtil.nullToStr(parameters.get(SET_B_PARAM_KEY));
            String nameA = ValueUtil.nullToStr(parameters.get(NAME_A_PARAM_KEY));
            String nameB = ValueUtil.nullToStr(parameters.get(NAME_B_PARAM_KEY));
            String op = ValueUtil.nullToStr(parameters.get(OP_PARAM_KEY));
            String life = ValueUtil.nullToStr(parameters.get(LIFE_PARAM_KEY));

            // nameAが指定されていない場合、
            if (PhoenixUtil.isEmpty(nameA)) {
                nameA = nameB;
            }
            // nameBが指定されていない場合、
            if (PhoenixUtil.isEmpty(nameB)) {
                nameB = nameA;
            }

            // lifeが指定されていない場合、
            if (PhoenixUtil.isEmpty(life)) {
                life = StoreUtil.getLifeOfScreeningResult(request, resultA);
            }

            // スクリーニング結果を取得する。
            Map<String, Map<String, Object[]>> sResultA = StoreUtil.getScreeningResult(request, resultA);
            Map<String, Map<String, Object[]>> sResultB = StoreUtil.getScreeningResult(request, resultB);
            if (PhoenixUtil.isEmpty(sResultA) || PhoenixUtil.isEmpty(sResultB)) {
                // TODO kurinami 【未実装】 エラー発生時
                return "";
            }

            // TODO kurinami 【未実装】セット名が片方だけ省略されたケースに対応していない。
            // setAが指定されていない場合、
            if (PhoenixUtil.isEmpty(setA)) {
                for (Map.Entry<String, Map<String, Object[]>> entry : sResultA.entrySet()) {
                    if (PhoenixUtil.isEmpty(nameA) || entry.getValue().containsKey(nameA)) {
                        setA = entry.getKey();
                        break;
                    }
                }
            }

            // setBが指定されていない場合、
            if (PhoenixUtil.isEmpty(setB)) {
                for (Map.Entry<String, Map<String, Object[]>> entry : sResultB.entrySet()) {
                    if (PhoenixUtil.isEmpty(nameB) || entry.getValue().containsKey(nameB)) {
                        setB = entry.getKey();
                        break;
                    }
                }
            }

            // 結果セットを取得する。
            Map<String, Object[]> resultSetA = sResultA.get(setA);
            Map<String, Object[]> resultSetB = sResultA.get(setB);
            if (PhoenixUtil.isEmpty(resultSetA) || PhoenixUtil.isEmpty(resultSetB)) {
                // TODO kurinami 【未実装】 エラー発生時
                return "";
            }

            // 各一覧をマージする。
            Map<String, Map<String, Object[]>> sResultM = getCopy(sResultA);
            for (Map.Entry<String, Object[]> entry : resultSetA.entrySet()) {
                if (PhoenixUtil.isEmpty(nameA) || entry.getKey().equals(nameA)) {
                    Object[] resultItemA = resultSetA.get(entry.getKey());
                    Object[] resultItemB = resultSetA.get(PhoenixUtil.isEmpty(nameB) ? entry.getKey() : nameB);
                    if (resultItemB != null) {
                        Object[] resultItemM = merge(op, resultItemA, resultItemB);
                        sResultM.get(setA).put(entry.getKey(), resultItemM);
                    }
                }
            }

            // マージした結果を保存する。
            StoreUtil.setScreeningResult(request, resultId, sResultM, life);

            // TODO kurinami 【確認】 ★ 動作未確認
            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * スクリーニング結果をコピーする。
     * 
     * @param source
     * @return
     */
    private Map<String, Map<String, Object[]>> getCopy(Map<String, Map<String, Object[]>> source) {

        Map<String, Map<String, Object[]>> copy = new HashMap<String, Map<String, Object[]>>();
        for (Map.Entry<String, Map<String, Object[]>> entry : source.entrySet()) {
            copy.put(entry.getKey(), new HashMap<String, Object[]>(entry.getValue()));
        }

        return copy;

    }

    /**
     * 2つの一覧をマージする。
     * 
     * @param op
     * @param resultItemA
     * @param resultItemB
     * @return
     */
    @SuppressWarnings("unchecked")
    private Object[] merge(String op, Object[] resultItemA, Object[] resultItemB) {

        Object[] resultItemM = new Object[resultItemA.length];
        resultItemM[Constants.NAME_ITEM_INDEX] = resultItemA[Constants.NAME_ITEM_INDEX];
        for (int i = Constants.VALUE_ITEM_INDEX; i < resultItemM.length; i++) {
            resultItemM[i] = new ArrayList<String>();
        }

        List<String> valueItemListA = (List<String>) resultItemA[Constants.VALUE_ITEM_INDEX];
        List<String> valueItemListB = (List<String>) resultItemB[Constants.VALUE_ITEM_INDEX];

        if (op.equals("and")) {
            for (int i = 0; i < valueItemListA.size(); i++) {
                String value = valueItemListA.get(i);
                if (valueItemListB.contains(value)) {
                    for (int j = Constants.VALUE_ITEM_INDEX; j < resultItemM.length; j++) {
                        ((List<String>) resultItemM[j]).add(((List<String>) resultItemA[j]).get(i));
                    }
                }
            }
        } else if (op.equals("or")) {
            for (int i = 0; i < valueItemListA.size(); i++) {
                for (int j = Constants.VALUE_ITEM_INDEX; j < resultItemM.length; j++) {
                    ((List<String>) resultItemM[j]).add(((List<String>) resultItemA[j]).get(i));
                }
            }
            for (int i = 0; i < valueItemListB.size(); i++) {
                String value = valueItemListB.get(i);
                if (!valueItemListA.contains(value)) {
                    for (int j = Constants.VALUE_ITEM_INDEX; j < resultItemM.length; j++) {
                        ((List<String>) resultItemM[j]).add(((List<String>) resultItemB[j]).get(i));
                    }
                }
            }
        } else if (op.equals("nand")) {
            for (int i = 0; i < valueItemListA.size(); i++) {
                String value = valueItemListA.get(i);
                if (!valueItemListB.contains(value)) {
                    for (int j = Constants.VALUE_ITEM_INDEX; j < resultItemM.length; j++) {
                        ((List<String>) resultItemM[j]).add(((List<String>) resultItemA[j]).get(i));
                    }
                }
            }
            for (int i = 0; i < valueItemListB.size(); i++) {
                String value = valueItemListB.get(i);
                if (!valueItemListA.contains(value)) {
                    for (int j = Constants.VALUE_ITEM_INDEX; j < resultItemM.length; j++) {
                        ((List<String>) resultItemM[j]).add(((List<String>) resultItemB[j]).get(i));
                    }
                }
            }
        } else if (op.equals("nota")) {
            for (int i = 0; i < valueItemListB.size(); i++) {
                String value = valueItemListB.get(i);
                if (!valueItemListA.contains(value)) {
                    for (int j = Constants.VALUE_ITEM_INDEX; j < resultItemM.length; j++) {
                        ((List<String>) resultItemM[j]).add(((List<String>) resultItemB[j]).get(i));
                    }
                }
            }
        } else if (op.equals("notb")) {
            for (int i = 0; i < valueItemListA.size(); i++) {
                String value = valueItemListA.get(i);
                if (!valueItemListB.contains(value)) {
                    for (int j = Constants.VALUE_ITEM_INDEX; j < resultItemM.length; j++) {
                        ((List<String>) resultItemM[j]).add(((List<String>) resultItemA[j]).get(i));
                    }
                }
            }
        }

        return resultItemM;
    }
}
