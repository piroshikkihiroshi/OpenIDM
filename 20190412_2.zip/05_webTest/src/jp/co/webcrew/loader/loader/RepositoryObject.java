package jp.co.webcrew.loader.loader;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.nio.CharBuffer;
import java.sql.SQLException;

import javax.tools.SimpleJavaFileObject;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.loader.db.ClassRepositoryDb;

/**
 * コンパイラAPIが扱う1クラスのオブジェクト
 * 
 * @author kurinami
 */
public class RepositoryObject extends SimpleJavaFileObject {

    /** ロガー */
    private static final Logger log = Logger.getLogger(RepositoryObject.class);

    /** 種別 */
    private Kind kind = null;

    /** プログラムのソース文字列 */
    private String source = null;

    /** コンパイルしたクラスの実体を出力するstream */
    private ByteArrayOutputStream baos = new ByteArrayOutputStream();

    /** クラス名 */
    private String className;

    /**
     * コンストラクタ
     * 
     * @param className
     */
    public RepositoryObject(String className) {
        super(toURI(className), Kind.SOURCE);
        this.className = className;
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.tools.SimpleJavaFileObject#openInputStream()
     */
    @Override
    public InputStream openInputStream() throws IOException {
        return new BufferedInputStream(new ByteArrayInputStream(this.toByteArray()));
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.tools.SimpleJavaFileObject#openOutputStream()
     */
    @Override
    public OutputStream openOutputStream() throws IOException {
        return new FilterOutputStream(baos);
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.tools.SimpleJavaFileObject#getCharContent(boolean)
     */
    @Override
    public CharSequence getCharContent(boolean ignoreEncodingErrors) throws IOException {
        if (ValueUtil.nullToStr(source).length() == 0) {
            try {
                source = ClassRepositoryDb.getSource(className);
            } catch (SQLException e) {
                log.error(className, e);
                throw new IOException(className, e);
            }
        }
        return CharBuffer.wrap(source);
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.tools.SimpleJavaFileObject#getKind()
     */
    @Override
    public Kind getKind() {

        if (kind == null) {
            int type = 0;
            try {
                type = ClassRepositoryDb.getType(className);
            } catch (SQLException e) {
                log.error(className, e);
            }
            if (type == 1) {
                kind = Kind.SOURCE;
            } else if (type == 2) {
                kind = Kind.CLASS;
            } else {
                kind = Kind.OTHER;
            }
        }

        if (kind == Kind.SOURCE) {
            if (baos.size() > 0) {
                return Kind.CLASS;
            } else {
                return Kind.SOURCE;
            }
        } else {
            return kind;
        }
    }

    /**
     * クラスの実体をバイト配列で返す。
     * 
     * @return
     * @throws IOException
     */
    public byte[] toByteArray() throws IOException {
        if (getKind() == Kind.CLASS && baos.size() == 0) {
            try {
                baos.write(ClassRepositoryDb.getClass(className));
            } catch (SQLException e) {
                log.error(className, e);
                throw new IOException(className, e);
            }
        }
        return baos.toByteArray();
    }

    /**
     * クラス名を返す。
     * 
     * @return
     */
    public String getClassName() {
        return className;
    }

    /**
     * クラス名をURI表記に変換する。
     * 
     * @param className
     * @return
     */
    private static URI toURI(String className) {
        StringBuffer sb = new StringBuffer();
        sb.append("db://");
        sb.append(className.replace('.', '/'));
        sb.append(".java");
        return URI.create(sb.toString());
    }

}