package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * スクリーニング結果出力(デバッグ用)を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class SetDumpExecuter extends SSTagExecuter {

    /** パラメータ名：スクリーニング結果が入っている一意なID(必須) */
    private static final String RESULT_ID_PARAM_KEY = "result_id";

    /** パラメータ名：スクリーニング結果内の set名(省略可) */
    private static final String SET_ID_PARAM_KEY = "set_id";

    /** ロガー */
    private static final Logger log = Logger.getLogger(SetDumpExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { RESULT_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String resultId = ValueUtil.nullToStr(parameters.get(RESULT_ID_PARAM_KEY));
            String setId = ValueUtil.nullToStr(parameters.get(SET_ID_PARAM_KEY));

            // セッションストアで保持しているスクリーニング結果を取得する。
            Map<String, Map<String, Object[]>> sResult = StoreUtil.getScreeningResult(request, resultId);
            if (sResult == null) {
                return "";
            }

            return makeHtml(sResult, setId);

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * デバッグ用htmlを組み立てる。
     * 
     * @param sResult
     * @param setId
     * @return
     */
    @SuppressWarnings("unchecked")
    private String makeHtml(Map<String, Map<String, Object[]>> sResult, String setId) {

        // htmlを組み立てる。
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        for (Map.Entry<String, Map<String, Object[]>> setEntry : sResult.entrySet()) {
            if (PhoenixUtil.isEmpty(setId) || setId.equals(setEntry.getKey())) {

                pw.println(setEntry.getKey() + "<br>");

                for (Map.Entry<String, Object[]> entry : setEntry.getValue().entrySet()) {
                    String key = entry.getKey();
                    Object[] resultItem = entry.getValue();

                    pw.println("&nbsp;&nbsp;" + key + ", " + (PhoenixUtil.isEmpty(resultItem) ? "" : resultItem[0]) + "<br>");

                    int size = 0;
                    for (int j = 1; !PhoenixUtil.isEmpty(resultItem) && j < resultItem.length; j++) {
                        List<String> list = (List<String>) resultItem[j];
                        if(!PhoenixUtil.isEmpty(list)) {
                            size = Math.max(size, list.size());
                        }
                    }
                    
                    for (int i = 0; i < size; i++) {
                        pw.println("&nbsp;&nbsp;&nbsp;&nbsp;");
                        for (int j = 1; j < resultItem.length; j++) {
                            List<String> list = (List<String>) resultItem[j];
                            pw.print((PhoenixUtil.isEmpty(list) || i >= list.size() ? "" : list.get(i)) + ", ");
                        }
                        pw.println("<br>");
                    }
                }

            }
        }

        pw.flush();
        return sw.toString();

    }
}
