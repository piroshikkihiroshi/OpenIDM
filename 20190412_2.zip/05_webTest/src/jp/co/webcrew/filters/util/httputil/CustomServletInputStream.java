package jp.co.webcrew.filters.util.httputil;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletInputStream;

/**
 * クライアントからのリクエストを指定のstreamに置き換えるクラス。
 * 
 * @author kurinami
 */
public class CustomServletInputStream extends ServletInputStream {

	/** バッファリングする出力先 */
	private InputStream inputStream;

	public CustomServletInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.InputStream#read()
	 */
	public int read() throws IOException {
		return inputStream.read();
	}

}
