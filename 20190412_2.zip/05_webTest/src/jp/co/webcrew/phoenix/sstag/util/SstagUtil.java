package jp.co.webcrew.phoenix.sstag.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.sstag.bean.AdminAuthBean;
import jp.co.webcrew.phoenix.store.util.SessionStoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;

/**
 * phoenixのsstag内で共通で使用するutilクラス。
 * 
 * @author kurinami
 */
public class SstagUtil {

    /** ロガー */
    private static final Logger log = Logger.getLogger(SstagUtil.class);

    /**
     * 必須パラメータのチェックをして、指定されていないパラメータキーの一覧を返す。
     * 
     * @param parameters
     * @param requires
     * @return
     */
    @SuppressWarnings("unchecked")
    public static List<String> requireErrorList(Map parameters, String[] requires) {
        List<String> list = new ArrayList<String>();

        for (String require : requires) {
            if (PhoenixUtil.isEmpty((String) parameters.get(require))) {
                list.add(require);
            }
        }

        return list;
    }

    /**
     * サイトIDを返す。
     * 
     * @param param
     * @param request
     * @return
     */
    public static int getSiteId(Object param, HttpServletRequest request) {
        int siteId = ValueUtil.toint((String) param);

        // サイトIDが指定されていない場合、
        if (siteId == 0) {
            // site_id sstagによる値を取得する。
            siteId = StoreUtil.getSiteId(request);
        }

        // サイトIDが指定されていない場合、
        if (siteId == 0) {
            // 自サイトのIDを使用する。
            siteId = SiteMstDb.getInstance().getSiteId(request.getRequestURL().toString());
        }

        log.info("使用サイトID:" + siteId);

        return siteId;
    }

    /**
     * ファイルの内容を返す。
     * 
     * @param src
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    public static String getFileData(Object src, HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String fileData = ValueUtil.nullToStr(src);

        if (fileData.startsWith("/")) {

            // TODO kurinami 【未実装】 dbからのインクルード

            // ファイルの中身を取り込む。
            fileData = SstagUtil.getInclude(fileData, request, response);
        }

        return fileData;
    }

    /**
     * インクルードするファイルの中身を返す。
     * 
     * @param src
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    public static String getInclude(String src, HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String pathname = request.getSession().getServletContext().getRealPath(src);
        File file = new File(pathname);
        if (!file.isFile()) {
            throw new IOException("パラメータ src に指定された値[" + src + "]によりあらわされるファイル[" + pathname + "]が存在しません。");
        }

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        FileInputStream fis = new FileInputStream(file);
        BufferedReader br = new BufferedReader(new InputStreamReader(fis, response.getCharacterEncoding()));

        while (true) {
            String buf;
            buf = br.readLine();
            if (buf == null) {
                break;
            }
            pw.println(buf);
        }

        fis.close();

        return sw.toString();

    }

    /**
     * 共通情報を返す。
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    public static SstagGlobalInfo getSstagGlobalInfo(HttpServletRequest request) throws SQLException {
        SstagGlobalInfo sstagGlobalInfo = new SstagGlobalInfo();

        sstagGlobalInfo.guid = SessionFilterUtil.getGuid(request);
        sstagGlobalInfo.gsid = SessionFilterUtil.getGsid(request);
        sstagGlobalInfo.ssid = SessionFilterUtil.getSsid(request);
        sstagGlobalInfo.short_id = SessionStoreUtil.getCurrentShortId(request);
        sstagGlobalInfo.goid = StoreUtil.getGoid(request);
        sstagGlobalInfo.site_id = Integer.toString(getSiteId(null, request));
        sstagGlobalInfo.login_flag = SessionFilterUtil.isLogined(request);
        sstagGlobalInfo.promo_code = (String) request.getAttribute(UserInfo.SITE_SESSION_PROMO_CODE_ATTR_KEY);
        sstagGlobalInfo.af_code = (String) request.getAttribute(UserInfo.SITE_SESSION_AF_CODE_ATTR_KEY);

        return sstagGlobalInfo;
    }

    /**
     * 順序指定を返す。
     * 
     * @param resultOrder
     * @return
     */
    public static SortRequest[] getSortRequest(String resultOrder) {

        List<SortRequest> list = new ArrayList<SortRequest>();

        for (String requestOrderItem : PhoenixUtil.split(resultOrder, ",")) {
            String[] temp = PhoenixUtil.split(requestOrderItem, " ");

            SortRequest sortRequestItem = new SortRequest();
            sortRequestItem.itemName = temp[0];
            sortRequestItem.direction = !(temp.length > 1 && temp[1].equalsIgnoreCase("desc"));
            list.add(sortRequestItem);
        }

        return list.toArray(new SortRequest[0]);
    }

    /**
     * 公開フラグ無視設定を返す。
     * 
     * @param request
     * @param ignorePubflag
     * @return
     * @throws SQLException
     */
    public static boolean getIgnorePubflag(HttpServletRequest request, String ignorePubflag) throws SQLException {
        if (PhoenixUtil.isEmpty(ignorePubflag)) {
            return false;
        }

        if (ignorePubflag.equals("1") || ignorePubflag.equalsIgnoreCase("yes")
                || ignorePubflag.equalsIgnoreCase("true")) {
            if (StoreUtil.isAdminLogin(request)) {
                return true;
            }
        }
        return false;
    }

    /**
     * スクリーニング結果を置換パラメータに登録する。
     * 
     * @param request
     * @param resultId
     * @param sResult
     */
    @SuppressWarnings("unchecked")
    public static void setScreeningResultReplaceParam(HttpServletRequest request, String resultId,
            Map<String, Map<String, Object[]>> sResult) {

        for (Map.Entry<String, Map<String, Object[]>> entry : sResult.entrySet()) {
            String setName = entry.getKey();
            Map<String, Object[]> resultSet = entry.getValue();

            for (Map.Entry<String, Object[]> subEntry : resultSet.entrySet()) {
                String itemName = subEntry.getKey();
                Object[] resultItem = subEntry.getValue();

                String dispName = (String) resultItem[Constants.NAME_ITEM_INDEX];
                String kwdSetName = MessageFormat.format("set.{0}.{1}.{2}.name", resultId, setName, itemName);
                StoreUtil.addPhoenixReplaceParam(request, kwdSetName, dispName);

                List<String> valueList = (List<String>) resultItem[Constants.VALUE_ITEM_INDEX];
                List<String> dispList = (List<String>) resultItem[Constants.DISP_ITEM_INDEX];
                for (int i = 0; i < valueList.size(); i++) {
                    Object[] dispParam = new Object[] { resultId, setName, itemName, Integer.toString(i) };
                    String kwdSetValue = MessageFormat.format("set.{0}.{1}.{2}.value.{3}", dispParam);
                    StoreUtil.addPhoenixReplaceParam(request, kwdSetValue, valueList.get(i));
                }
                for (int i = 0; i < dispList.size(); i++) {
                    Object[] dispParam = new Object[] { resultId, setName, itemName, Integer.toString(i) };
                    String kwdSetDisp = MessageFormat.format("set.{0}.{1}.{2}.disp.{3}", dispParam);
                    StoreUtil.addPhoenixReplaceParam(request, kwdSetDisp, dispList.get(i));
                }

                String kwdSetSize = MessageFormat.format("set.{0}.{1}.size", resultId, setName);
                StoreUtil.addPhoenixReplaceParam(request, kwdSetSize, Integer.toString(valueList.size()));
            }
        }

    }

    /**
     * カレントレコードを置換パラメータに登録する。
     * 
     * @param request
     * @param tableId
     * @param record
     * @throws InstantiationException
     * @throws SQLException
     */
    public static void setCurrentRecordReplaceParam(HttpServletRequest request, String tableId,
            Map<String, ClmDataBean> record) throws InstantiationException, SQLException {
        setTableReplaceParam(request, record, "cont", tableId);
    }

    /**
     * テーブル情報を置換パラメータに登録する。
     * 
     * @param request
     * @param record
     * @param type
     * @param tableId
     * @throws InstantiationException
     * @throws SQLException
     */
    private static void setTableReplaceParam(HttpServletRequest request, Map<String, ClmDataBean> record, String type,
            String tableId) throws InstantiationException, SQLException {

        // 現在登録されているものをクリアしてから登録する。
        String prefix = MessageFormat.format("{0}.{1}", type, tableId);
        KeywordReplacer.removeDynamicKeyword(request, prefix);

        for (Map.Entry<String, ClmDataBean> entry : record.entrySet()) {

            String clmId = entry.getKey();
            ClmDataBean clmData = entry.getValue();

            setValueToReplaceParam(request, clmData.getMeta().getDispName(), "{0}.{1}.{2}.name", type, tableId, clmId);

            ClmMetaMstUtil clmMetaMstUtil = ClmMetaMstUtil.getInstance(request, clmData);

            setValueToReplaceParam(request, clmMetaMstUtil.getRaw(), "{0}.{1}.{2}.raw", type, tableId, clmId);
            setValueToReplaceParam(request, clmMetaMstUtil.getValue(), "{0}.{1}.{2}.value", type, tableId, clmId);
            setValueToReplaceParam(request, clmMetaMstUtil.getValueNoenc(), "{0}.{1}.{2}.value_noenc", type, tableId,
                    clmId);
            setValueToReplaceParam(request, clmMetaMstUtil.getDisp(), "{0}.{1}.{2}.disp", type, tableId, clmId);
            setValueToReplaceParam(request, clmMetaMstUtil.getDispNoenc(), "{0}.{1}.{2}.disp_noenc", type, tableId,
                    clmId);

            setValuesToReplaceParam(request, clmMetaMstUtil.getRaws(), "{0}.{1}.{2}.raw", type, tableId, clmId);
            setValuesToReplaceParam(request, clmMetaMstUtil.getValues(), "{0}.{1}.{2}.value", type, tableId, clmId);
            setValuesToReplaceParam(request, clmMetaMstUtil.getValuesNoenc(), "{0}.{1}.{2}.value_noenc", type, tableId,
                    clmId);
            setValuesToReplaceParam(request, clmMetaMstUtil.getDisps(), "{0}.{1}.{2}.disp", type, tableId, clmId);
            setValuesToReplaceParam(request, clmMetaMstUtil.getDispsNoenc(), "{0}.{1}.{2}.disp_noenc", type, tableId,
                    clmId);

            setValueToReplaceParam(request, Long.toString(clmData.getRecId()), "{0}.{1}.rec_id", type, tableId);

        }

    }

    /**
     * オーダーIDを置換パラメータに登録する。
     * 
     * @param request
     * @throws SQLException
     */
    public static void setGoidReplaceParam(HttpServletRequest request) throws SQLException {

        String goid = StoreUtil.getGoid(request);
        if (!PhoenixUtil.isEmpty(goid)) {
            StoreUtil.addPhoenixReplaceParam(request, KeywordReplacer.SESSION_PREFIX, "GOID", goid);

            // リクエスト属性にもfaon.goidのキーワードで登録する。
            request.setAttribute(UserInfo.PREFIX + "goid", goid);
        }

        String recentGoid = StoreUtil.getRecentGoid(request);
        if (!PhoenixUtil.isEmpty(recentGoid)) {
            StoreUtil.addPhoenixReplaceParam(request, KeywordReplacer.SESSION_PREFIX + "recent_goid", recentGoid);
        }
    }

    /**
     * オーダー情報を置換パラメータに登録する。
     * 
     * @param request
     * @param record
     */
    public static void setOrderInfoReplaceParam(HttpServletRequest request, Map<String, ClmDataBean> record) {

        // オーダー情報を置換変数に登録する。
        for (Map.Entry<String, ClmDataBean> entry : record.entrySet()) {
            String kwd_name = MessageFormat.format("order_info.{0}", entry.getKey());
            // TODO kurinami 【確認】 この部分は表示変換はやらなくていいの？
            String content = entry.getValue().getData();
            StoreUtil.addPhoenixReplaceParam(request, kwd_name, content);
        }

    }

    /**
     * 認証情報を置換パラメータに登録する。
     * 
     * @param request
     * @param adminAuth
     * @throws SQLException
     * @throws InstantiationException
     */
    public static void setAdminAuthReplaceParam(HttpServletRequest request, AdminAuthBean adminAuth)
            throws InstantiationException, SQLException {

        if (adminAuth.getAuthTableId() != null && adminAuth.getAuthRecord() != null) {
            setTableReplaceParam(request, adminAuth.getAuthRecord(), "admin", adminAuth.getAuthTableId());
        }

        String loginId = ValueUtil.nullToStr(adminAuth.getUserId());
        String loginPw = ValueUtil.nullToStr(adminAuth.getPassword());

        setValueToReplaceParam(request, loginId, "admin.login_id.raw");
        setValueToReplaceParam(request, loginPw, "admin.login_pw.raw");
        setValueToReplaceParam(request, ValueUtil.sanitize(loginId), "admin.login_id.value");
        setValueToReplaceParam(request, ValueUtil.sanitize(loginPw), "admin.login_pw.value");
        setValueToReplaceParam(request, ValueUtil.sanitize(loginId), "admin.login_id.disp");
        setValueToReplaceParam(request, ValueUtil.lpad("", '*', loginPw.length()), "admin.login_pw.disp");
    }

    /**
     * handover情報を置換パラメータに登録する。
     * 
     * @param request
     * @throws SQLException
     */
    public static void setHandoverReplaceParam(HttpServletRequest request) throws SQLException {
        Map<String, String> handoverMap = StoreUtil.getHandoverMap(request);
        if (handoverMap == null) {
            return;
        }

        for (Map.Entry<String, String> entry : handoverMap.entrySet()) {
            String kwd_name = "handover." + entry.getKey();
            String content = entry.getValue();
            StoreUtil.addPhoenixReplaceParam(request, kwd_name, content);
        }

        StoreUtil.removeHandoverMap(request);
    }

    /**
     * 表示用に、それぞれの値にサニタイジングを行う。
     * 
     * @param values
     * @return
     */
    public static String[] sanitize(String[] values) {
        if (PhoenixUtil.isEmpty(values)) {
            return new String[0];
        }
        String[] result = new String[values.length];
        for (int i = 0; i < result.length; i++) {
            result[i] = ValueUtil.sanitize(values[i]);
        }
        return result;
    }

    /**
     * 改行で文字列を分割する。
     * 
     * @param source
     * @return
     */
    public static String[] splitNewLine(String source) {
        List<String> valueList = new ArrayList<String>();
        BufferedReader br = new BufferedReader(new StringReader(source));
        String buf = null;
        try {
            while ((buf = br.readLine()) != null) {
                valueList.add(buf);
            }
        } catch (IOException e) {
            log.error("予期せぬエラー", e);
        }
        return valueList.toArray(new String[0]);
    }

    /**
     * パラメータで渡されたitem_mapを分割する。
     * 
     * @param source
     * @return
     * @throws Exception
     */
    public static String[][] splitItemMap(String source) throws Exception {

        if (PhoenixUtil.isEmpty(source)) {
            return new String[0][0];
        }

        String[] temp = PhoenixUtil.split(source.substring(1), source.substring(0, 1));

        if (temp.length % 2 != 0) {
            throw new Exception("パラメータエラー 個数が正しくありません。 [item_map:" + source + "]");
        }

        String[][] res = new String[temp.length / 2][2];
        for (int i = 0; i < res.length; i++) {
            res[i] = new String[2];
            res[i][0] = ValueUtil.nullToStr(temp[i * 2 + 0]);
            res[i][1] = ValueUtil.nullToStr(temp[i * 2 + 1]);
        }

        return res;
    }

    public static void setValueToReplaceParam(HttpServletRequest request, String value, String kwdPattern,
            Object... kwdArguments) {
        String kwd_name = MessageFormat.format(kwdPattern, kwdArguments);
        StoreUtil.addPhoenixReplaceParam(request, kwd_name, value);
    }

    public static void setValuesToReplaceParam(HttpServletRequest request, String[] values, String kwdPattern,
            Object... kwdArguments) {
        String kwd_name = MessageFormat.format(kwdPattern, kwdArguments);
        for (int i = 0; i < values.length; i++) {
            StoreUtil.addPhoenixReplaceParam(request, kwd_name + "." + Integer.toString(i + 1), values[i]);
        }
    }

    public static void setValueToReplaceMap(Map<String, String> replaceMap, String value, String kwdPattern,
            Object... kwdArguments) {
        String kwd_name = MessageFormat.format(kwdPattern, kwdArguments);
        replaceMap.put(kwd_name, value);
    }

    public static void setValuesToReplaceMap(Map<String, String> replaceMap, String[] values, String kwdPattern,
            Object... kwdArguments) {
        String kwd_name = MessageFormat.format(kwdPattern, kwdArguments);
        for (int i = 0; i < values.length; i++) {
            replaceMap.put(kwd_name + "." + Integer.toString(i + 1), values[i]);
        }
    }
}
