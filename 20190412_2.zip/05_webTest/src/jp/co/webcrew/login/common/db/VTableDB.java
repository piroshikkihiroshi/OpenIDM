/**
 * 
 */
package jp.co.webcrew.login.common.db;

import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import static jp.co.webcrew.login.common.db.VTableRowObject.*;
/**
 * 
 * 仮想テーブルデータ操作用のAPI
 * @author kazuto.yano
 *
 */
public class VTableDB 
{
	
	private static final Logger logger=Logger.getLogger(VTableDB.class);
	
	/***
	 * オラクル・スキーマ名
	 */
	private String schemaName;
	/***
	 * サイトID
	 */
	private int siteId;
	/***
	 * テーブルID
	 */
	private String tblId;
	/***
	 * 列定義情報
	 * キー：列ID、値：列情報(すべての列情報をここに保存するのは困難なので、必要なものだけにとどめている)
	 */
	private Map<String,ClmMetaData> clmMetaData;
	/***
	 * 
	 */
	private String[] clmIDs;
	
	
	private DBAccess dbAccess;
	
	private String sqlInsertRecMetaData;
	private String sqlInsertClmData;
	private String sqlUpdateRecMetaData;
	private String sqlUpdateClmData;
	private String sqlDeleteRecMetaData;
	private String sqlDeleteClmData;
	private String sqlSelectMaxRecId;
	private String sqlSelectRecMetaData;
	private String sqlSelectClmData;
	private String sqlSelectClmMetaMst;
	
	private int keyDataMaxLength=DEFAULT_KEYDATA_MAX_LENGTH;
	
	private static final int DEFAULT_KEYDATA_MAX_LENGTH=512;
	
	private static final String TPL_sqlInsertRecMetaData=
			"insert into {0}.REC_META_DATA"+
			"(SITE_ID, TBL_ID, REC_ID, ACC_LEVEL, PUB_FLAG" +
			", BGN_DATETIME, END_DATETIME, LINK_FLAG, UP_DATETIME, UP_ADMIN)"+
			"values(?, ?, ?, ?, ?" +
			", ?, ?, ?,?, ?)";
	
	private static final String TPL_sqlInsertClmData=
		"insert into {0}.CLM_DATA"+
		"(SITE_ID, TBL_ID, REC_ID, CLM_ID, SORT_NUM, KEY_DATA, LOB_DATA,"+ 
		"UP_DATETIME, UP_ADMIN)values(?, ?, ?, ?, ?, ?, ?, ?, ?)"
		;
	private static final String TPL_sqlUpdateRecMetaData=
		" update {0}.REC_META_DATA "+
		" set "+ 
			"ACC_LEVEL = ?,	PUB_FLAG = ?,	BGN_DATETIME = ?,END_DATETIME = ?,"+
			"LINK_FLAG = ?,UP_DATETIME = ?,UP_ADMIN = ?" +
			" where SITE_ID = ? and TBL_ID = ? and REC_ID = ?";
		
	//private static final String TPL_sqlUpdateClmData;
	private static final String TPL_sqlDeleteRecMetaData=
		"delete from {0}.REC_META_DATA where SITE_ID = ? and TBL_ID = ? and REC_ID = ? ";

	private static final String TPL_sqlSelectMaxRecId=
		"select MAX(rec_id) from {0}.REC_META_DATA where SITE_ID = ? and TBL_ID = ? ";

	
	private static final String TPL_sqlDeleteClmData=
		"delete from {0}.CLM_DATA where SITE_ID = ? and TBL_ID = ? and REC_ID = ? ";

	private static final String TPL_sqlSelectRecMetaData=
		"select * from {0}.REC_META_DATA where SITE_ID = ? and TBL_ID = ? and REC_ID = ? ";
	
	private static final String TPL_sqlSelectClmData=
		"select * from {0}.CLM_DATA where SITE_ID = ? and TBL_ID = ? and REC_ID = ? ";

	private static final String TPL_sqlSelectClmMetaMst=
		"select * from {0}.CLM_META_MST where SITE_ID = ? and TBL_ID = ? ";

	
	/****
	 * コンストラクタ
	 * 
	 * @param schemaName
	 * @param siteId
	 * @param tblId
	 * @param dbAccessc
	 */
	public VTableDB(String schemaName,int siteId,String tblId,DBAccess dbAccess)
	{
		this.schemaName=schemaName;
		this.siteId=siteId;
		this.tblId=tblId;
		this.dbAccess=dbAccess;
		
		this.sqlInsertRecMetaData=MessageFormat.format(TPL_sqlInsertRecMetaData, this.schemaName);
		this.sqlInsertClmData=MessageFormat.format(TPL_sqlInsertClmData, this.schemaName);
		this.sqlUpdateRecMetaData=MessageFormat.format(TPL_sqlUpdateRecMetaData, this.schemaName);
		this.sqlDeleteRecMetaData=MessageFormat.format(TPL_sqlDeleteRecMetaData, this.schemaName);
		this.sqlDeleteClmData=MessageFormat.format(TPL_sqlDeleteClmData, this.schemaName);
		this.sqlSelectMaxRecId=MessageFormat.format(TPL_sqlSelectMaxRecId, this.schemaName);
		this.sqlSelectClmData=MessageFormat.format(TPL_sqlSelectClmData, this.schemaName);
		this.sqlSelectRecMetaData=MessageFormat.format(TPL_sqlSelectRecMetaData, this.schemaName);
		this.sqlSelectClmMetaMst=MessageFormat.format(TPL_sqlSelectClmMetaMst, this.schemaName);
		
	}
	
	
	/***
	 * テーブル「CLM_DATA」のカラム「KEY_DATA」に保存する
	 * 最大バイト数を設定する。
	 * 設定しない場合のデフォルト値は512
	 * 
	 * @param maxlen
	 */
	public void setKeyDataMaxLength(int maxlen)
	{
		this.keyDataMaxLength=maxlen;
	}
	
	/***
	 * テーブル「CLM_DATA」のカラム「KEY_DATA」に保存する
	 * 最大バイト数を取得する。
	 * 
	 */
	public int getKeyDataMaxLength()
	{
		return this.keyDataMaxLength;
	}
	
	
	private Map<String,ClmMetaData> getClmMetaData()
	throws SQLException
	{
		if(this.clmMetaData!=null)return this.clmMetaData;
		
		synchronized (this) 
		{
			if(this.clmMetaData!=null)return this.clmMetaData;
			
			Map<String,ClmMetaData> map=new HashMap<String, VTableDB.ClmMetaData>();
			
			ResultSet rset=null;
			try
			{
				dbAccess.prepareStatement(this.sqlSelectClmMetaMst);
				dbAccess.setInt(1, this.siteId);
				dbAccess.setString(2, this.tblId);
				
				rset=dbAccess.executeQuery();
				
				while(rset.next())
				{
					String __clmId=rset.getString("clm_id");
					int sortNum=rset.getInt("sort_num");
					
					ClmMetaData clmdata=new ClmMetaData();
					clmdata.sortNum=sortNum;
					map.put(__clmId, clmdata);
				}
				this.clmMetaData=map;
				Set<String> keySet=this.clmMetaData.keySet();
				String[] clmIds=new String[keySet.size()];
				keySet.toArray(clmIds);
				this.clmIDs=clmIds;
				
				return this.clmMetaData;
				
			}
			finally
			{
				DBAccess.close(rset);
			}
			
		}
		
		
		
		
	}
	
	
	public String[] getClmIDs()
	{
		return this.clmIDs;
	}
	
	/***
	 * 引数に指定したレコードID(rec_id)の仮想テーブル行データを取得する。
	 * 取得できなかった場合、NULLを返す
	 * 
	 * @param recId
	 * @return
	 * @throws SQLException
	 * @throws ParseException
	 */
	public VTableRowObject findByRecId(long recId)
	throws SQLException,ParseException
	{
		
		List<Long> listRecId=new ArrayList<Long>();
		listRecId.add(recId);
		List<VTableRowObject> list=this.findByRecIdList(listRecId);
		
		if(list.size()==0)
		{
			return null;
		}
		
		return list.get(0);
		
	}	
	
	/***
	 * 引数に指定したレコードID(rec_id)一覧の仮想テーブル行データを取得する。
	 * 
	 * @param listRecId
	 * @return
	 * @throws SQLException
	 * @throws ParseException
	 */
	public List<VTableRowObject> findByRecIdList(List<Long> listRecId)
	throws SQLException,ParseException
	{
		ResultSet rset=null;
		try
		{
			List<VTableRowObject> listRow=new ArrayList<VTableRowObject>();
			
			dbAccess.prepareStatement(this.sqlSelectRecMetaData);
			dbAccess.setInt(1, this.siteId);
			dbAccess.setString(2, this.tblId);
			for(long recId:listRecId)
			{
				dbAccess.setLong(3, recId);
				
				rset=dbAccess.executeQuery();
				
				if(!rset.next())
				{
					listRow.add(null);
					continue;
				}
				
				VTableRowObject rowObject=new VTableRowObject();
				
				rowObject.recId=recId;
				rowObject.accLevel=rset.getInt("acc_level");
				
				
				
				rowObject.bgnDatetime=convert_YYYYMMDDHH24MISS_TO_DateObject(rset.getString("bgn_datetime"));
				rowObject.endDatetime=convert_YYYYMMDDHH24MISS_TO_DateObject(rset.getString("end_datetime"));
				rowObject.updateTime=convert_YYYYMMDDHH24MISS_TO_DateObject(rset.getString("up_datetime"));
				
				rowObject.linkFlag=rset.getString("link_flag");
				
				int pubFlag=rset.getInt("pub_flag");
				if(pubFlag==1)
				{
					rowObject.pubFlag=true;
				}
				else
				{
					rowObject.pubFlag=false;
				}
				
				rowObject.upAdmin=rset.getString("up_admin");
				
				DBAccess.close(rset);
				listRow.add(rowObject);
			}
			
			
			dbAccess.prepareStatement(this.sqlSelectClmData);
			dbAccess.setInt(1, this.siteId);
			dbAccess.setString(2, this.tblId);
			for(VTableRowObject rowObject:listRow)
			{
				if(rowObject==null)
				{
					continue;
				}
				
				dbAccess.setLong(3, rowObject.recId);
				rset=dbAccess.executeQuery();
				
				Map<String,String> rowData=new HashMap<String, String>();
				while(rset.next())
				{
					String clmId=rset.getString("clm_id");
					String data=rset.getString("lob_data");
					if(data==null || data.length()==0)
					{
						data=rset.getString("key_data");
					}
					
					rowData.put(clmId, data);
					
				}
				
				DBAccess.close(rset);
				rowObject.rowData=rowData;
			}
			return listRow;
		}
		finally
		{
			DBAccess.close(rset);
			
		}
		
	}
	
	
	private int executeUpdate(boolean strict,int normalRet)
	throws SQLException
	{
		int ret=dbAccess.executeUpdate();
		if(strict && ret!=normalRet)
		{
			throw new SQLException("[UPDATE_RETURN_ERROR]更新件数が１件ではありませんでした。"+ret);
		}
		return ret;
		
	}
	
	/***
	 * 更新系処理（登録、削除を含む）を行う
	 * 
	 * @param rowObject
	 * @param updateUser
	 * @param strict
	 * @throws SQLException
	 */
	public void update(VTableRowObject rowObject,String updateUser,boolean strict)
	throws SQLException
	{
		
		List<VTableRowObject> list=new ArrayList<VTableRowObject>();
		list.add(rowObject);
		this.update(list, updateUser, strict);
		
	}
	
	/***
	 * 更新系処理（登録、削除を含む）を行う
	 * 
	 * @param listRowObject
	 * @param updateUser
	 * @param strict
	 * @throws SQLException
	 */
	public void update(List<VTableRowObject> listRowObject,String updateUser,boolean strict)
	throws SQLException
	{
		if(dbAccess.getAutoCommit())
		{
			dbAccess.setAutoCommit(false);
		}

		this.checkData(listRowObject);
		
		
		Date sysdate=new Date();
		
		int ret;
		
		for(VTableRowObject rowObject:listRowObject)
		{
			
			rowObject.updateTime=sysdate;
			rowObject.upAdmin=updateUser;
			
			if(rowObject.deleteFlag)
			{
				if(!rowObject.isInsert())
				{
					logger.info("行データの削除処理を開始します。[siteid]"+this.siteId+"[tblid]"+this.tblId+"[recid]"+rowObject.recId);
					
					
					//TODO delete処理
					dbAccess.prepareStatement(this.sqlDeleteRecMetaData);
					dbAccess.setInt(1, this.siteId);
					dbAccess.setString(2, this.tblId);
					dbAccess.setLong(3, rowObject.recId);
					executeUpdate(strict,1);
					
					dbAccess.prepareStatement(this.sqlDeleteClmData);
					dbAccess.setInt(1, this.siteId);
					dbAccess.setString(2, this.tblId);
					dbAccess.setLong(3, rowObject.recId);
					dbAccess.executeUpdate();
					
				}
				else
				{
					logger.info("何もしません（recidが未設定のため、削除対象データはなし）[siteid]"+this.siteId+"[tblid]"+this.tblId+"[recid]"+rowObject.recId);
					
				}
			}
			else
			{
				boolean isInsert=rowObject.isInsert();
				
				Map<String,ClmMetaData> mapClmMetaData=this.getClmMetaData();

				
				//行追加の場合
				if(isInsert)
				{
					logger.info("行データの追加処理を開始します。[siteid]"+this.siteId+"[tblid]"+this.tblId+"[recid]"+rowObject.recId);
					ResultSet rset=null;
					long recId;
					try
					{
						dbAccess.prepareStatement(this.sqlSelectMaxRecId);
						dbAccess.setInt(1, this.siteId);
						dbAccess.setString(2, this.tblId);
					
						rset=dbAccess.executeQuery();
						if(rset.next())
						{
							recId=rset.getLong(1)+1;
						}
						else
						{
							recId=1;
						}
						
						rowObject.recId=recId;
					}
					finally
					{
						
						DBAccess.close(rset);
					}
					
					
					dbAccess.prepareStatement(this.sqlInsertRecMetaData);
					dbAccess.setInt(1, this.siteId);
					dbAccess.setString(2, this.tblId);
					dbAccess.setLong(3, rowObject.recId);
					dbAccess.setInt(4, rowObject.accLevel);
					if(rowObject.pubFlag)
						dbAccess.setInt(5, 1);
					else
						dbAccess.setInt(5, 0);
					
					dbAccess.setString(6, convert_Date_TO_YYYYMMDDHH24MISS(rowObject.bgnDatetime));
					dbAccess.setString(7, convert_Date_TO_YYYYMMDDHH24MISS(rowObject.endDatetime));
					dbAccess.setString(8, rowObject.linkFlag);
					dbAccess.setString(9, convert_Date_TO_YYYYMMDDHH24MISS(rowObject.updateTime));
					dbAccess.setString(10, rowObject.upAdmin);
					/*
					Calendar cal=Calendar.getInstance();
					cal.setTime(rowObject.bgnDatetime);
					dbAccess.setString(6, DateUtil.getDateTime(cal));
					cal.setTime(rowObject.endDatetime);
					dbAccess.setString(7, DateUtil.getDateTime(cal));
					dbAccess.executeUpdate();
					*/
					executeUpdate(strict,1);

					
					
				}
				//行更新の場合
				else
				{
					
					logger.info("行データの更新処理と既存のclmdataの削除処理を開始します。[siteid]"+this.siteId+"[tblid]"+this.tblId+"[recid]"+rowObject.recId);
					//rec_metadataの更新
					dbAccess.prepareStatement(this.sqlUpdateRecMetaData);
					//更新値
					dbAccess.setInt(1, rowObject.accLevel);
					if(rowObject.pubFlag)
						dbAccess.setInt(2, 1);
					else
						dbAccess.setInt(2, 0);
					
					dbAccess.setString(3, convert_Date_TO_YYYYMMDDHH24MISS(rowObject.bgnDatetime));
					dbAccess.setString(4, convert_Date_TO_YYYYMMDDHH24MISS(rowObject.endDatetime));
					dbAccess.setString(5, rowObject.linkFlag);
					dbAccess.setString(6, convert_Date_TO_YYYYMMDDHH24MISS(rowObject.updateTime));
					dbAccess.setString(7, rowObject.upAdmin);
					//更新キー
					dbAccess.setInt(8, this.siteId);
					dbAccess.setString(9, this.tblId);
					dbAccess.setLong(10, rowObject.recId);
					executeUpdate(strict,1);
					
					
					//clm_dataのデータを一旦削除(delete)
					dbAccess.prepareStatement(this.sqlDeleteClmData);
					dbAccess.setInt(1, this.siteId);
					dbAccess.setString(2, this.tblId);
					dbAccess.setLong(3, rowObject.recId);
					dbAccess.executeUpdate();
					
				}
				
				logger.info("clmdataの追加処理を開始します。[siteid]"+this.siteId+"[tblid]"+this.tblId+"[recid]"+rowObject.recId);
				dbAccess.prepareStatement(this.sqlInsertClmData);
				dbAccess.setInt(1, this.siteId);
				dbAccess.setString(2, this.tblId);
				dbAccess.setLong(3, rowObject.recId);
				
				for(String clmId:rowObject.rowData.keySet())
				{
					dbAccess.setString(4, clmId);
					
					//TODO sortnum
					int sortNum=mapClmMetaData.get(clmId).sortNum;
					dbAccess.setInt(5, sortNum);
					String value=rowObject.rowData.get(clmId);
					
					/***
					 * データがNULLもしくは空文字の場合、clm_dataへの登録は行わない
					 * 
					 */
					if(value==null || value.length()==0)
					{
						continue;
					}
					
					
					//データ量が比較的小さい
					if(getByteLength(value)<=this.keyDataMaxLength)
					{
						dbAccess.setString(6, value);
						dbAccess.setNull(7);
					}
					else
					{
						String valueLeft=getLeft(value, this.keyDataMaxLength);
						dbAccess.setString(6, valueLeft);
						dbAccess.setString(7, value);
						
					}
					dbAccess.setObject(8, convert_Date_TO_YYYYMMDDHH24MISS(rowObject.updateTime));
					dbAccess.setString(9, rowObject.upAdmin);
					executeUpdate(strict,1);
					
				}//for(String clmId:rowObject.rowData.keySet())
			}//if(rowObject.deleteFlag)
		}//for(VTableRowObject rowObject:listRowObject)
		
		
	}
	
	
    /**
     * 文字列の先頭から指定されたバイト数分取りだす。
     * phoenix_filtersのPhoenixUtilからのパクリ
     * 
     * @param source
     * @param byteLength
     * @return
     */
    private static String getLeft(String source, int byteLength) {

        if (source==null || source.length()==0) {
            return "";
        }

        try {
            int size = 0;
            int index = 0;

            for (; index < source.length(); index++) {
                String ch = source.substring(index, index + 1);
                int temp = ch.getBytes("utf-8").length;
                if (size + temp > byteLength) {
                    break;
                }
                size += temp;
            }

            return source.substring(0, index);

        } catch (UnsupportedEncodingException e) {
            //log.error("予期せぬエラー", e);
            return "";
        }

    }

    private void checkData(List<VTableRowObject> listRowObject)
    throws SQLException
    {
    	this.getClmMetaData();
    	for(VTableRowObject rowObject:listRowObject)
    	{
    		if(rowObject.bgnDatetime==null)
    		{
    			throw new RuntimeException("有効期間（開始日時）をNULLにしないでください。");
    		}
    		if(rowObject.endDatetime==null)
    		{
    			throw new RuntimeException("有効期間（終了日時）をNULLにしないでください。");
    		}
    		
    		
    		for(String clmId:rowObject.rowData.keySet())
    		{
    			boolean exist=false;
    			for(String definedClmId:this.clmIDs)
    			{
    				if(definedClmId.equals(clmId))
    				{
    					exist=true;
    					break;
    				}
    			}
    			if(!exist)
    			{
        			throw new RuntimeException("カラム「"+clmId+"」はclm_meta_mstに定義されていません。");
    			}
    		}
    	}
    }
    
    
    /**
     * 文字列が何バイトかを返す。
     * phoenix_filtersのPhoenixUtilからのパクリ
     * 
     * @param source
     * @return
     */
    private static int getByteLength(String source) {
        try {
            return ValueUtil.nullToStr(source).getBytes("utf-8").length;
        } catch (UnsupportedEncodingException e) {
            //log.error("予期せぬエラー", e);
            return 0;
        }
    }
    

	
	/***
	 * 列定義情報を管理するクラス
	 * 
	 * @author kazuto.yano
	 *
	 */
	public static class ClmMetaData
	{
		public int sortNum;
	}

	
	
	
	public static void main(String[] args) 
	throws Exception
	{
		DBAccess db=new DBAccess("phoenix");
		
		try
		{
			String schemaName="training";
			int siteId=91003;
			String tblId="bugdb";
			VTableDB vtbl=new VTableDB(schemaName, siteId, tblId,db);
			
			
			VTableRowObject row=vtbl.findByRecId(1);
			
			//row.delete();
			
			
			System.out.println(row.toString4Debug());
			
			//row.recId=-1;
			row.recId=72;
			row.rowData.put("title", "てすとだす。。");
			//row.rowData.remove("detail");
			//row.rowData.put("fake", "fake");
			
			StringBuilder sb=new StringBuilder();
			for(int i=0;i<33000;i++)
			{
				sb.append("あ");
			}
			
			
			
			row.rowData.put("detail", sb.toString());
			
			
			row.pubFlag=false;
			row.bgnDatetime=new Date();
			row.endDatetime=new Date();
			
			List<VTableRowObject> list=new ArrayList<VTableRowObject>();
			list.add(row);
			list.add(row);
			
			vtbl.update(list, "yano", true);
			
			db.commit();
			
		}
		finally
		{
			DBAccess.close(db);
			
		}
		
	}
}

