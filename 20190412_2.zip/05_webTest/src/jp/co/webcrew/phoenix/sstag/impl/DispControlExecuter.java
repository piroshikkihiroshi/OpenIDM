package jp.co.webcrew.phoenix.sstag.impl;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;

/**
 * データが存在する時としない時の出し分けを行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class DispControlExecuter extends SSTagExecuter {

    /** パラメータ名：存在するかしないかの判断のための元 */
    private static final String BASE_ITEM_PARAM_KEY = "base_item";

    /** パラメータ名：条件判断のオプション */
    private static final String OPTION_PARAM_KEY = "option";

    /** パラメータ名：データが「存在する」場合に出力されるHTML */
    private static final String EXISTS_HTML_PARAM_KEY = "exists_html";

    /** パラメータ名：データが「存在しない」場合に出力されるHTML */
    private static final String NODATA_HTML_PARAM_KEY = "nodata_html";

    /** オプション：数値指定 */
    private static final String OPTION_NUM0 = "num0";

    /** ロガー */
    private static final Logger log = Logger.getLogger(DispControlExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            String baseItem = ValueUtil.nullToStr(parameters.get(BASE_ITEM_PARAM_KEY));
            String option = ValueUtil.nullToStr(parameters.get(OPTION_PARAM_KEY));
            String existsHtml = SstagUtil.getFileData(parameters.get(EXISTS_HTML_PARAM_KEY), request, response);
            String nodataHtml = SstagUtil.getFileData(parameters.get(NODATA_HTML_PARAM_KEY), request, response);

            if (judge(baseItem, option)) {
                return existsHtml;
            } else {
                return nodataHtml;
            }

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * 値が存在するかを判定する。
     * 
     * @param baseItem
     * @param option
     * @return
     */
    private boolean judge(String baseItem, String option) {

        boolean result = true;
        if (baseItem.trim().length() == 0) {
            // 中身が空の場合は、常にfalse
            result = false;
        } else {
            // 中身があっても、num0オプションが指定してあって、値が0の場合はfalse
            if (option.equalsIgnoreCase(OPTION_NUM0)) {
                try {
                    if (Double.parseDouble(baseItem) == 0.0) {
                        return false;
                    }
                } catch (NumberFormatException e) {
                }
            }
        }
        return result;

    }
}
