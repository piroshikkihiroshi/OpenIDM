package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;

/**
 * SortingMobileContentsExecuterで判断される条件を管理するdbクラス。
 * 
 * @author amit, katsuno
 */
public class SortingMobileContentsMstDb extends RefreshMstDb {

	/** Time Switching Contentsマスタ情報取得用SQL */
	private static final String SORTING_MOBILE_CONTENTS_MST_SELECT = "select * from common.sorting_mobile_contents_mst";

	/** Delimiter for the HashMap key */
	public static final String DELIMITER = "-";

	/** 唯一のインスタンス */
	private static SortingMobileContentsMstDb objSortingMobileContentsMstDb = new SortingMobileContentsMstDb();

	/** 変換キーワードの一覧 */
	private Map mapContents = null;

	/**
	 * 生成不能コンストラクタ
	 */
	private SortingMobileContentsMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static SortingMobileContentsMstDb getInstance() {
		return objSortingMobileContentsMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {
		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();
			mapContents = new HashMap();

			dbAccess.prepareStatement(SORTING_MOBILE_CONTENTS_MST_SELECT);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				String strContentsId = rs.getString("contents_id");
				String strMobileType = rs.getString("mobile_type");
				String strCarrierId = rs.getString("carrier_id");
				String strContents = rs.getString("contents");
				mapContents.put(strContentsId + DELIMITER + strMobileType
						+ DELIMITER + strCarrierId, strContents);
			}
		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * 
	 * @return
	 */
	public Map getContents() {
		return mapContents;
	}
}
