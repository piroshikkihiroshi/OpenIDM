package jp.co.webcrew.phoenix.sstag.util;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.bean.SelectItemBean;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * ロジックの絡んだ置き換え処理を行うutilクラス。
 * 
 * @author kurinami
 */
public class LogicReplaceUtil {

    /** ロガー */
    private static final Logger log = Logger.getLogger(LogicReplaceUtil.class);

    /** 唯一の実態 */
    private static final LogicReplaceUtil replaceUtil = new LogicReplaceUtil();

    /**
     * コンストラクタ
     */
    private LogicReplaceUtil() {
    }

    /**
     * ロジックの絡んだ置換処理を行う。
     * 
     * @param source
     * @param request
     * @param formItem
     * @param values
     * @return
     * @throws Exception
     */
    public static String replace(String source, HttpServletRequest request, FormItemBean formItem, String[] values)
            throws Exception {
        try {
            return replaceUtil.replaceBase(source, request, formItem, values);
        } catch (Exception e) {
            throw new Exception(e.getMessage() + "\n\n" + source, e);
        }
    }

    // ==================================================
    // 全体共通部分

    /** 全体の書式 */
    private Pattern basePattern = Pattern.compile(
            "\\[\\s*(\\w+)\\s*:\\s*([^\\]]*)\\s*\\](.*?)\\[\\s*\\1\\s*:\\s*end\\s*\\]", Pattern.CASE_INSENSITIVE
                    + Pattern.DOTALL);

    /**
     * まず全体を解析して、タグの種類による処理を振り分ける。
     * 
     * @param source
     * @param request
     * @param formItem
     * @param values
     * @return
     * @throws ParseException
     * @throws SQLException
     * @throws InstantiationException
     */
    private String replaceBase(String source, HttpServletRequest request, FormItemBean formItem, String[] values)
            throws ParseException, SQLException, InstantiationException {

        // TODO kurinami 【未実装】 ■■■■■ caseの入れ子
        Matcher m = basePattern.matcher(source);

        // マッチしなかった場合は、そのまま返す。
        if (!m.find()) {
            return source;
        }
        m.reset();

        StringBuffer sb = new StringBuffer();

        while (m.find()) {
            log.info("replace match [tag:" + m.group(1) + "][param:" + m.group(2) + "][html:" + m.group(3) + "]");
            String replacement = "";
            String tag = m.group(1);
            if (tag.equalsIgnoreCase("loop")) {
                String html = replaceBase(m.group(3), request, formItem, values);
                replacement = replaceLoop(m.group(2), html, request, formItem, values);
            } else if (tag.equalsIgnoreCase("case")) {
                String html = replaceBase(m.group(3), request, formItem, values);
                replacement = replaceCase(m.group(2), html);
            } else {
                throw new ParseException("unrecoginzed tag [" + tag + "]", 0);
            }
            m.appendReplacement(sb, replacement);
        }
        m.appendTail(sb);

        return sb.toString();
    }

    // ==================================================
    // loop タグ制御部分

    /** 繰り返し処理の書式 */
    private Pattern loopPattern = Pattern.compile("(\\w+)\\s*(.*)\\s*", Pattern.CASE_INSENSITIVE + Pattern.DOTALL);

    /**
     * 繰り返し処理内のコマンドの種類で処理を振り分ける。
     * 
     * @param param
     * @param html
     * @param request
     * @param formItem
     * @param values
     * @return
     * @throws ParseException
     * @throws SQLException
     * @throws InstantiationException
     */
    private String replaceLoop(String param, String html, HttpServletRequest request, FormItemBean formItem,
            String[] values) throws ParseException, SQLException, InstantiationException {

        String result = "";

        Matcher m = loopPattern.matcher(param);
        if (m.matches()) {
            log.info("replace match [command:" + m.group(1) + "][subParam:" + m.group(2) + "]");
            String command = m.group(1);
            if (command.equalsIgnoreCase("auto")) {
                result = replaceLoopAuto(m.group(2), html, request, formItem, values);
            } else if (command.equalsIgnoreCase("fixed")) {
                result = replaceLoopFixed(m.group(2), html, values);
            } else {
                throw new ParseException("unrecoginzed loop-command [" + command + "]", 0);
            }
        } else {
            throw new ParseException("unrecoginzed loop-param [" + param + "]", 0);
        }

        return result;

    }

    // --------------------------------------------------
    // loop auto タグ制御部分

    /** 定型用置換変数名：選択肢の値 */
    private static final String AUTO_SELECT_VALUE_VAL_KEY = "select_value";

    /** 定型用置換変数名：選択肢の名称 */
    private static final String AUTO_SELECT_NAME_VAL_KEY = "select_name";

    /** 定型用置換変数名：選択肢用の画像 */
    private static final String AUTO_SELECT_IMAGE_VAL_KEY = "select_image";

    /** 定型用置換変数名：checked="checkd"出力用 */
    private static final String AUTO_CHECKED_VAL_KEY = "checked";

    /** 定型用置換変数名：selected="selected"出力用 */
    private static final String AUTO_SELECTED_VAL_KEY = "selected";

    /** 定型用置換変数名： 繰り返し回数 */
    private static final String AUTO_SHARP_VAL_KEY = "#";

    /** 定型繰り返しの書式 */
    private Pattern loopAutoPattern = Pattern.compile("(type\\s*=\\s*['\"]?(\\w+)['\"]?)?", Pattern.CASE_INSENSITIVE
            + Pattern.DOTALL);

    /**
     * 定型用の繰り返し処理の置き換えを行う。
     * 
     * @param subParam
     * @param html
     * @param request
     * @param formItem
     * @param values
     * @return
     * @throws ParseException
     * @throws SQLException
     * @throws InstantiationException
     */
    private String replaceLoopAuto(String subParam, String html, HttpServletRequest request, FormItemBean formItem,
            String[] values) throws ParseException, SQLException, InstantiationException {

        List<Map<String, String>> replaceParamList = null;
        Matcher m = loopAutoPattern.matcher(subParam);
        if (m.matches()) {
            String type = m.group(2);
            log.info("replaceLoopAuto match [type:" + type + "]");
            if (type == null || type.toLowerCase().endsWith("_mst")) {
                replaceParamList = getLoopAutoSelectMstParamList(request, formItem, values);
            } else if (type.equalsIgnoreCase("year")) {
                replaceParamList = getLoopAutoYearParamList(formItem, values);
            } else if (type.equalsIgnoreCase("month")) {
                replaceParamList = getLoopAutoFixedParamList(1, 12, values);
            } else if (type.equalsIgnoreCase("day")) {
                replaceParamList = getLoopAutoFixedParamList(1, 31, values);
            } else if (type.equalsIgnoreCase("hour")) {
                replaceParamList = getLoopAutoHourParamList(formItem, values);
            } else if (type.equalsIgnoreCase("minute")) {
                replaceParamList = getLoopAutoFixedParamList(0, 59, values);
            } else if (type.equalsIgnoreCase("second")) {
                replaceParamList = getLoopAutoFixedParamList(0, 59, values);
            } else {
                throw new ParseException("unrecoginzed loop-auto-type [" + type + "]", 0);
            }
        } else {
            throw new ParseException("unrecoginzed loop-auto-param [" + subParam + "]", 0);
        }

        StringBuffer sb = new StringBuffer();
        for (Map<String, String> replaceParam : replaceParamList) {
            sb.append(ReplaceUtil.getReplacedHtml(html, replaceParam, false));
        }
        return sb.toString();

    }

    /**
     * 選択子マスタから置換パラメータの一覧を作って返す。
     * 
     * @param request
     * @param formItem
     * @param selectedValues
     * @return
     * @throws SQLException
     * @throws InstantiationException
     */
    private List<Map<String, String>> getLoopAutoSelectMstParamList(HttpServletRequest request, FormItemBean formItem,
            String[] selectedValues) throws SQLException, InstantiationException {

        // 選択肢マスタを取得する。
        FormItemUtil formItemUtil = FormItemUtil.getInstance(formItem, request);
        List<SelectItemBean> selectItemList = formItemUtil.getSelectMst();
        if (selectItemList == null) {
            throw new SQLException("選択肢マスタが設定されていません。[form_id:" + formItem.getFormId() + "]");
        }

        List<Map<String, String>> replaceParamList = new ArrayList<Map<String, String>>();
        int i = 0;
        for (SelectItemBean selectItem : selectItemList) {

            boolean isSelected = PhoenixUtil.contains(selectedValues, selectItem.getValue());

            Map<String, String> replaceParam = new HashMap<String, String>();
            replaceParam.put(AUTO_SELECT_VALUE_VAL_KEY, selectItem.getValue());
            replaceParam.put(AUTO_SELECT_NAME_VAL_KEY, selectItem.getName());
            replaceParam.put(AUTO_SELECT_IMAGE_VAL_KEY, selectItem.getImage());
            replaceParam.put(AUTO_CHECKED_VAL_KEY, (isSelected ? "checked=\"checkd\"" : ""));
            replaceParam.put(AUTO_SELECTED_VAL_KEY, (isSelected ? "selected=\"selected\"" : ""));
            for (int j = 0; j < selectedValues.length; j++) {
                if (selectedValues[j].equals(ValueUtil.lpad(selectItem.getValue(), '0', selectedValues[j].length()))) {
                    replaceParam.put(AUTO_CHECKED_VAL_KEY + "." + (j + 1), "checked=\"checkd\"");
                    replaceParam.put(AUTO_SELECTED_VAL_KEY + "." + (j + 1), "selected=\"selected\"");
                }
            }
            replaceParam.put(AUTO_SHARP_VAL_KEY, Integer.toString(i + 1));

            replaceParamList.add(replaceParam);
            ++i;
        }

        return replaceParamList;

    }

    /**
     * 年用の置換パラメータの一覧を作って返す。
     * 
     * @param formItem
     * @param selectedValues
     * @return
     */
    private List<Map<String, String>> getLoopAutoYearParamList(FormItemBean formItem, String[] selectedValues) {

        int min = 1900;
        if (formItem.getMin() != null) {
            min = formItem.getMin().intValue();
        }
        int max = Calendar.getInstance().get(Calendar.YEAR);
        if (formItem.getMax() != null) {
            max = formItem.getMax().intValue();
        }

        // 和暦混合生年月日でない場合、
        if (!formItem.getType().equals("14")) {
            return getLoopAutoFixedParamList(min, max, selectedValues);
        } else {

            List<String> values = new ArrayList<String>();
            List<String> names = new ArrayList<String>();
            for (int year = min; year <= max; year++) {
                values.add(Integer.toString(year));
                if (year >= 1989) {
                    names.add("平成" + (year - 1989 + 1) + "/西暦" + year);
                } else if (year >= 1926) {
                    names.add("昭和" + (year - 1926 + 1) + "/西暦" + year);
                } else if (year >= 1912) {
                    names.add("大正" + (year - 1912 + 1) + "/西暦" + year);
                } else if (year >= 1868) {
                    names.add("明治" + (year - 1868 + 1) + "/西暦" + year);
                } else {
                    names.add("西暦" + year);
                }
            }

            return getLoopAutoFixedParamList(values.toArray(new String[0]), names.toArray(new String[0]),
                    selectedValues);
        }
    }

    /**
     * 時用の置換パラメータの一覧を作って返す。
     * 
     * @param formItem
     * @param values
     * @return
     */
    private List<Map<String, String>> getLoopAutoHourParamList(FormItemBean formItem, String[] values) {
        int min = 0;
        int max = 28;
        // タイムスタンプ型以外のときだけ最大最小を設定する。
        if (!formItem.getType().equals("9")) {
            if (formItem.getMin() != null) {
                min = formItem.getMin().intValue();
            }
            if (formItem.getMax() != null) {
                max = formItem.getMax().intValue();
            }
        }
        return getLoopAutoFixedParamList(min, max, values);
    }

    /**
     * 指定された間隔の置換パラメータの一覧を作って返す。
     * 
     * @param fromValue
     * @param toValue
     * @param selectedValues
     * @return
     */
    private List<Map<String, String>> getLoopAutoFixedParamList(int fromValue, int toValue, String[] selectedValues) {

        List<String> values = new ArrayList<String>();
        List<String> names = new ArrayList<String>();
        for (int i = 0; i < toValue - fromValue + 1; i++) {
            values.add(Integer.toString(fromValue + i));
            names.add(Integer.toString(fromValue + i));
        }

        return getLoopAutoFixedParamList(values.toArray(new String[0]), names.toArray(new String[0]), selectedValues);

    }

    /**
     * 指定された名前/値の一覧から、置換パラメータの一覧を作って返す。
     * 
     * @param values
     * @param names
     * @param selectedValues
     * @return
     */
    private List<Map<String, String>> getLoopAutoFixedParamList(String[] values, String[] names, String[] selectedValues) {
        List<Map<String, String>> replaceParamList = new ArrayList<Map<String, String>>();
        for (int i = 0; i < values.length && i < names.length; i++) {

            boolean isSelected = PhoenixUtil.contains(selectedValues, values[i]);

            Map<String, String> replaceParam = new HashMap<String, String>();
            replaceParam.put(AUTO_SELECT_VALUE_VAL_KEY, values[i]);
            replaceParam.put(AUTO_SELECT_NAME_VAL_KEY, names[i]);
            replaceParam.put(AUTO_SELECT_IMAGE_VAL_KEY, "");
            replaceParam.put(AUTO_CHECKED_VAL_KEY, (isSelected ? "checked=\"checkd\"" : ""));
            replaceParam.put(AUTO_SELECTED_VAL_KEY, (isSelected ? "selected=\"selected\"" : ""));
            for (int j = 0; j < selectedValues.length; j++) {
                if (selectedValues[j].equals(ValueUtil.lpad(values[i], '0', selectedValues[j].length()))) {
                    replaceParam.put(AUTO_CHECKED_VAL_KEY + "." + (j + 1), "checked=\"checkd\"");
                    replaceParam.put(AUTO_SELECTED_VAL_KEY + "." + (j + 1), "selected=\"selected\"");
                }
            }
            replaceParam.put(AUTO_SHARP_VAL_KEY, Integer.toString(i + 1));

            replaceParamList.add(replaceParam);
        }
        return replaceParamList;
    }

    // --------------------------------------------------
    // loop fixed タグ制御部分

    /** 固定回数用置換変数名：カラムの値 */
    private static final String FIXED_VALUE_VAL_KEY = "loop.count";

    /** 固定回数用置換変数名：checked="checkd"出力用 */
    private static final String FIXED_CHECKED_VAL_KEY = "checked";

    /** 固定回数用置換変数名：selected="selected"出力用 */
    private static final String FIXED_SELECTED_VAL_KEY = "selected";

    /** 固定回数用置換変数名：繰り返し回数 */
    private static final String FIXED_SHARP_VAL_KEY = "#";

    /** 固定回数繰り返しの書式 */
    private Pattern loopFixedPattern = Pattern
            .compile(
                    "(offset\\s*=\\s*['\"]?(\\d+)['\"]?\\s*|limit\\s*=\\s*['\"]?(\\d+)['\"]?\\s*|delta\\s*=\\s*['\"]?([\\+\\-]?\\d+)['\"]?\\s*)+",
                    Pattern.CASE_INSENSITIVE + Pattern.DOTALL);

    /**
     * 固定回数用の繰り返し処理の置き換えを行う。
     * 
     * @param subParam
     * @param html
     * @param values
     * @return
     * @throws ParseException
     */
    private String replaceLoopFixed(String subParam, String html, String[] values) throws ParseException {

        Matcher m = loopFixedPattern.matcher(subParam);
        if (m.matches()) {
            for (int i = 0; i <= m.groupCount(); i++) {
                System.out.print("[" + i + ":" + m.group(i) + "]");
            }
            System.out.println();

            if (m.group(2) == null) {
                throw new ParseException("missing loop-fixed-param offset[" + subParam + "]", 0);
            }
            if (m.group(3) == null) {
                throw new ParseException("missing loop-fixed-param limit[" + subParam + "]", 0);
            }

            log.info("replaceLoopFixed match [offset:" + m.group(2) + "][limit:" + m.group(3) + "][delta:" + m.group(4)
                    + "]");

            int offset = ValueUtil.toint(m.group(2));
            int limit = ValueUtil.toint(m.group(3));
            int delta = ValueUtil.toint(m.group(4));
            if (delta == 0) {
                delta = 1;
            }

            StringBuffer sb = new StringBuffer();
            for (int count = offset, i = 0; (delta >= 0 ? count <= limit : count >= limit); count += delta, i++) {
                boolean isSelected = PhoenixUtil.contains(values, Integer.toString(count));

                Map<String, String> replaceParam = new HashMap<String, String>();
                replaceParam.put(FIXED_VALUE_VAL_KEY, Integer.toString(count));
                replaceParam.put(FIXED_CHECKED_VAL_KEY, (isSelected ? "checked=\"checkd\"" : ""));
                replaceParam.put(FIXED_SELECTED_VAL_KEY, (isSelected ? "selected=\"selected\"" : ""));
                for (int j = 0; j < values.length; j++) {
                    if (values[j].equals(ValueUtil.lpad(Integer.toString(count), '0', values[j].length()))) {
                        replaceParam.put(FIXED_CHECKED_VAL_KEY + "." + (j + 1), "checked=\"checkd\"");
                        replaceParam.put(FIXED_SELECTED_VAL_KEY + "." + (j + 1), "selected=\"selected\"");
                    }
                }
                replaceParam.put(FIXED_SHARP_VAL_KEY, Integer.toString(i + 1));

                sb.append(ReplaceUtil.getReplacedHtml(html, replaceParam, false));
            }

            return sb.toString();

        } else {
            throw new ParseException("unrecoginzed loop-fixed-param [" + subParam + "]", 0);
        }
    }

    // ==================================================
    // case タグ制御部分

    /** 条件判断の書式 */
    private Pattern casePattern = Pattern.compile("^\\s*['\"]?(.*?)['\"]?\\s*:\\s*['\"]?(.*?)['\"]?\\s*$",
            Pattern.CASE_INSENSITIVE + Pattern.DOTALL);

    /**
     * 条件判断の置き換えを行う。
     * 
     * @param param
     * @param html
     * @return
     * @throws ParseException
     */
    private String replaceCase(String param, String html) throws ParseException {

        String result = "";

        Matcher m = casePattern.matcher(param);
        if (m.find()) {
            String value1 = ValueUtil.nullToStr(m.group(1)).trim();
            String value2 = ValueUtil.nullToStr(m.group(2)).trim();
            log.info("replaceCase match value=[" + value1 + "][" + value2 + "]");
            if (value1.equals(value2)) {
                result = html;
            } else {
                result = "";
            }
        } else {
            throw new ParseException("unrecoginzed case-param [" + param + "]", 0);
        }

        return result;

    }

    public static void main(String[] args) {
        String[] sources = {
                "       [loop:fixed offset=0 limit=100]           <option value=\"%{loop.count}\" %{selected}>%{loop.count}</option>       \n[loop:end]",
                "[loop:fixed offset=1900] <option value=\"%{#}\">%{#}年</option> [loop:end]",
                "[loop:fixed offset=1900 limit=2010 ] <option value=\"%{#}\">%{#}年</option> [loop:end]",
                "[loop:fixed offset=1900 limit=2010 delta=+1] <option value=\"%{#}\">%{#}年</option> [loop:end]",
                "[loop:fixed offset='1900' limit='2010' delta='+1'] <option value=\"%{#}\">%{#}年</option> [loop:end]",
                "[loop:fixed offset=\"1900\" limit=\"2010\" delta=\"+1\"] <option value=\"%{#}\">%{#}年</option> [loop:end]",
                " [roop:start] [roop:end] ",
                " [loop:start] [loop:end] ",
                " [loop:auto gegege] [loop:end] ",
                "        [loop: auto]     <option value='%{saelect_value}'>%{select_name}</option>     [loop: end]"
                        + "        [loop: auto type='gegege']<option value='%{saelect_value}'>%{select_name}</option>[loop: end]"
                        + "        [loop: auto type='month']<option value='%{saelect_value}'>%{select_name}</option>[loop: end]"
                        + "",
                "start [loop: auto] space1 [case: case_param] space2 [case: end] space2 [loop: end] end",
                "      日付: \n" + "      <select id='%{form.item.css.id.2}_1' name='%{form.item.name}.year' >\n"
                        + "         [loop:auto type='year']\n"
                        + "           <option value='%{select_value} %{selected}'>%{select_name}</option>\n"
                        + "         [loop:end]\n" + "      </select>\n" + "      %{form.item.date_time_sep.year}\n"
                        + "      <select id='%{form.item.css.id.2}_2' name='%{form.item.name}.month'>\n"
                        + "         [loop:auto type='month']\n"
                        + "           <option value='%{select_value} %{selected}'>%{select_name}</option>\n"
                        + "         [loop:end]\n" + "      </select>\n" + "      %{form.item.date_time_sep.month}\n"
                        + "      <select id='%{form.item.css.id.2}_3' name='%{form.item.name}.day' >\n"
                        + "         [loop:auto type='day']\n"
                        + "           <option value='%{select_value} %{selected}'>%{select_name}</option>\n"
                        + "         [loop:end]\n" + "      </select>\n" + "      %{form.item.date_time_sep.day}\n",
                "[case: gegege : bababa] dadadada [case:end] [case: gegege : gegege] popopo [case:end]",
                "[case: 'gegege' : \"bababa\"] dadadada [case:end] [case: 'gegege' : \"gegege\"] popopo [case:end]",
                "[case: parent1 : parent1]  [case: child1 : child1]child1[case:end]  [case: child2 : child1]child2[case:end]  [case:end]", };

        for (String source : sources) {
            System.out.println("==============================");
            System.out.println(source);
            System.out.println("------------------------------");
            try {
                System.out.println(replace(source, null, null, new String[] { "39" }));
            } catch (Exception e) {
                log.error("エラー", e);
            }
        }
    }

}
