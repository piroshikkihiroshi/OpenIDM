package jp.co.webcrew.phoenix.sstag.impl;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.db.OrderInfoDb;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;

/**
 * オーダーIDの発行を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class IssueOrderIdExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：発行直前のオーダーIDの取り扱い */
    private static final String BEFORE_PARAM_KEY = "before";

    /** ロガー */
    private static final Logger log = Logger.getLogger(IssueOrderIdExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String before = ValueUtil.nullToStr(parameters.get(BEFORE_PARAM_KEY));

            String recentGoid = before.equalsIgnoreCase("clear") ? "" : StoreUtil.getGoid(request);
            String goid = OrderInfoDb.getGoid(siteId);

            // オーダーIDをセッションストアに書き込む。
            StoreUtil.setGoid(request, goid, recentGoid);

            // 置換パラメータに登録する。
            SstagUtil.setGoidReplaceParam(request);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

}
