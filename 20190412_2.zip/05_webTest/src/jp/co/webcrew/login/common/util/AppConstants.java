/**
 *
 */
package jp.co.webcrew.login.common.util;


/**
 * アプリケーション共通の定数定義
 *
 * @author Takahashi
 *
 */
public class AppConstants {
	public static final String SITE_ID_TONASHIBA = "100";

	public static final String SITE_ID_MYPAGE = "200";
	public static final String SITE_ID_HKS_DANDORI = "300";
	public static final String SITE_ID_RESEARCH = "400";
	public static final String SITE_ID_CPN_SITE = "500";
	public static final String SITE_ID_CPN_FX = "501";
    //戻り値
    public static final int ERROR   					= -1;
    public static final int SUCCESS 					= 1;
    //　メルマガ　登録用　
    public static final String MAIL_MAGA_REGIST_FORM	= "MAIL_MAGA_REGIST_FORM";
    public static final String MAIL_MAGA_LOGIN_CHECK	= "MAIL_MAGA_LOGIN_CHECK";
    public static final String MAIL_MAGA_LOGIN_CHECK_OK	= "OK";
    public static final String MAIL_MAGA_LOGIN_CHECK_NG	= "NG";
}
