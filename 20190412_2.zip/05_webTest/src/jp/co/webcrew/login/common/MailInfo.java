package jp.co.webcrew.login.common;


public class MailInfo
{
	private String strSiteId   = "";
	private String strMailFrom = "";
	private String strMailTo   = "";
	private boolean blnMobileFlag = false; 
	
	/**
	 * サイトIDを設定する
	 * 
	 * @param strSiteId
	 */
	public void setSiteId(String strSiteId)
	{
		this.strSiteId = strSiteId;
	}

	/**
	 * 送信元メールアドレスを設定する
	 * 
	 * @param strMailFrom
	 */
	public void setMailFrom(String strMailFrom)
	{
		this.strMailFrom = strMailFrom;
	}
	
	/**
	 * 送信先メールアドレスを設定する
	 * 
	 * @param strMailTo
	 */
	public void setMailTo(String strMailTo)
	{
		this.strMailTo = strMailTo;
	}
	
	/**
	 * モバイルフラグを設定する
	 * 
	 * @param blnMobileFlag
	 */
	public void setMobileFlag(boolean blnMobileFlag)
	{
		this.blnMobileFlag = blnMobileFlag;
	}
	
	/**
	 * サイトIDを取得する
	 * 
	 * @return
	 */
	public String getSiteId()
	{
		return strSiteId;
	}
	
	/**
	 * 送信元メールアドレスを取得する
	 * 
	 * @return
	 */
	public String getMailFrom()
	{
		return strMailFrom;
	}
	
	/**
	 * 送信先メールアドレスを取得する
	 * 
	 * @return
	 */
	public String getMailTo()
	{
		return strMailTo;
	}
	
	/**
	 * モバイルフラグを取得する
	 * 
	 * @return
	 */
	public boolean getMobileFlag()
	{
		return blnMobileFlag;
	}
}
