/**
 * 
 */
package jp.co.webcrew.login.common.util;


import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MailTemplate;
import jp.co.webcrew.login.common.db.SystemProperties;

/**
 * アプリケーションに特化されたユーティリティクラス
 * 
 * @author Takahashi
 *
 */
public class AppUtil {

	/** ロガー */
    private static final Logger log = Logger.getLogger(AppUtil.class);

	/**
	 * <pre>
	 * 携帯メールアドレスか否かを判定する
	 * 
	 * true  : 携帯メールである
	 * false : 携帯メールではない
	 * 
	 * </pre>
	 * 
	 * @param email
	 * @return
	 */
    public static boolean isMobile(String email) {
		if (email == null) {
			return false;
		}
		
		String[] strs = getMobileMailSuffixes();
		for (int i=0 ; i < strs.length ; i++ ) {
			String suffix = ValueUtil.nullToStr( strs[i] );
			if (suffix.equals("")) {
				continue;
			}
			// メールアドレスの最後を見て携帯か否か判別する
//			Pattern pattern = Pattern.compile("\\Q" + suffix + "\\E$");
			Pattern pattern = Pattern.compile(suffix + "$");
			Matcher matcher = pattern.matcher(email);
			
			if (matcher.find()) {
				return true;
			}
		} 
	
		return false;	
		
	}
	
	/**
	 * <pre>
	 * 携帯メールアドレスを認識するためのサフィックスのリストを取得する
	 * 
	 * 対象文字列がnullもしくは空文字列の時、null
	 * 例外などのエラーが発生した場合もnull
	 * </pre>
	 * @return
	 */
	private static String[] getMobileMailSuffixes() {

		//		String suffixListStr = ValueUtil.nullToStr("docomo.ne.jp,ezweb.ne.jp,so//ftbank.ne.jp,vodafone.ne.jp");
		String suffixListStr = null;
		DBAccess db = null;
		try {
			db = new DBAccess();
			SystemProperties props = new SystemProperties(db);
			suffixListStr = ValueUtil.nullToStr(props.get(SystemProperties.MOBILE_MAIL_SUFFIXES));
	
		} catch (Exception e) {
			log.error("システムプロパティからMOBILE_MAIL_SUFFIXESの読み込みに失敗しました。" , e);
			return null;

		} finally {
			DBAccess.close(db);
		}
		
		if (suffixListStr.equals("")) {
			return null;
		}
		
		try {
			return StringUtil.split(suffixListStr);
		} catch (RuntimeException e) {
			log.error("携帯メール判別文字列を取得中に例外エラーが発生しました。" , e);
			return null;
		}
	}

	/**
	 * <pre>
	 * メールテンプレートの日時変数を現在時刻で置換する
	 * 
	 * 現在時刻がyyyymmddhhmissの14桁として、次のように置換。
	 * 
	 * $$year$$   → 年 yyyy
	 * $$month$$  → 月 mm
	 * $$day$$    → 日 dd
	 * $$hour$$   → 時 hh
	 * $$minute$$ → 分 mi
	 * $$second$$ → 秒 ss
	 * 
	 * 本文bodyがnullの時はnull
	 * 空文字の時は空文字で返す
	 * 
     * 
     * MailTemplate#replaceDateTime(String) に移動を検討
     * 
	 * </pre>
	 * 
	 * @param body メール本文
     * @see MailTemplate#replaceDateTime(String)
	 */
	public static String replaceDateTime (String body) {

        return MailTemplate.replaceDateTime(body);
        
	}
	
	/**
     * <pre>
	 * guid が正しいものならtrue
     * 
     * そうでなければfalseを返す。
	 * 
	 * 今後はSessionFilterAlterUtilを使用すること。09/02/07
     * 
     * </pre>
	 * @param guid
     * @see SessionFilterAlterUtil#isValidGuid(String)
	 */
	public static boolean isValidGuid(String guid) {
        return SessionFilterAlterUtil.isValidGuid(guid);
	}

	/**
	 * <pre>
	 * HTTPリクエストにstepEngine特有のパラメータが含まれているか否か。
	 * 
	 * true  step特有のパラメータが含まれている
	 * false 含まれていない
	 * 
	 * ステップエンジンのサイトによっては、トップページに引越し時期や生年月日などの
	 * 入力フォームを用意して、事実上トップページがstep0の役割を果たしているパターンがある。
	 * その場合、自動ログインの遷移先は
	 * 
	 * </pre>
	 * 
	 * @param request
	 * @return
	 */
    public static boolean consistsStepParamsIn(HttpServletRequest request){
	     for (Enumeration e = request.getParameterNames(); e.hasMoreElements() ;) {
	         String paramName = (String)e.nextElement();
	         if (paramName.toUpperCase().indexOf("ANSWER_Q") >= 0){
	        	 return true;
	         }
	     }

		return false;
	}
}
