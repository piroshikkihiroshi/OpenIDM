package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.ResultSet;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//t_ueda コメントアウト
//import sun.util.logging.resources.logging;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.login.common.db.ContractSiteMst;
import jp.co.webcrew.login.common.db.OrderHist;

/***
 * アンケート回答済み画面で使用するsstag
 * アンケート申請済みか否かで表示の出しわけを行う
 *
 * @author kazuto.yano
 *
 */
public class ContractEnqAnswerAfterExecuter extends SSTagExecuter
{
    /** ロガー */
    private static final Logger log = Logger.getLogger(ContractEnqAnswerExecuter.class);

	@Override
	public String execute(Map parameters, HttpServletRequest request,
			HttpServletResponse response)
	{

        // --------------------------------------------------------------------------------
        // sstagのパラメータを取得する。
        String siteId =    ValueUtil.nullToStr(parameters.get("site_id"));
        String orderId =   ValueUtil.nullToStr((String) parameters.get("order_id"));
        //申請済み＋マイページ誘導
        String htmlOk =    ValueUtil.nullToStr(parameters.get("html_ok"));
        //申請未了＋申請訴求
        String htmlNg =    ValueUtil.nullToStr(parameters.get("html_ng"));
        String htmlOther = ValueUtil.nullToStr(parameters.get("html_other"));

        // --------------------------------------------------------------------------------
        // sstagのパラメータをチェックする。

        // サイトIDがパラメータで指定されなかった場合は、filterで保持するサイトIDを使用する。
        if (siteId.length() == 0) {
            siteId = (String) request.getAttribute(UserInfo.SITE_ID_ATTR_KEY);
        }

        // siteIdが指定されていない場合、
        if (siteId.length() == 0) {
            // パラメータエラーとする
            log.error("パラメータエラー パラメータ[siteId]が指定されていません。");
            return "";
        }

        // orderIdが指定されていない場合、
        if (orderId.length() == 0) {
            // パラメータエラーとする
            log.error("パラメータエラー パラメータ[orderId]が指定されていません。");
            return "";
        }

        String returnHTML="";

        //log.info("ContractEnqAnswerAfterExecuter:exec");

        DBAccess dbAccess=null;
        ResultSet rset=null;
        String sql="SELECT CONTRACT_STATUS FROM TONASHIBA.ORDER_HIST WHERE SITE_ID=? AND ORDER_ID=?";
        try
        {
        	dbAccess=new DBAccess();
        	dbAccess.prepareStatement(sql);
        	dbAccess.setString(1, siteId);
        	dbAccess.setString(2, orderId);
        	rset=dbAccess.executeQuery();


        	if(!rset.next())
        	{
                //log.info("resultset_null");
            	//追加対応
            	//履歴がない場合は、アンケートの結果などから申請可能なユーザーか否か判定する
        		DBAccess.close(rset);
        		boolean canApply=false;
        		ContractSiteMst contractSiteMst=new ContractSiteMst();
        		if(contractSiteMst.load(dbAccess, siteId))
        		{
        			/*
        			log.info("getDisplayFlagForNoHist:param"+siteId+":"+orderId);
    				String functionName=contractSiteMst.get(ContractSiteMst.NO_HIST_SQL);
        			String sqlNoHist="SELECT "+functionName+"(?,?) FROM DUAL";
        			dbAccess.prepareStatement(sqlNoHist);
        			dbAccess.setString(1, siteId);
        			dbAccess.setString(2, orderId);
        			rset=dbAccess.executeQuery();
        			String ret;
        			if(rset.next())
        			{
        				ret=rset.getString(1);
        			}
        			else
        			{
        				ret="";
        			}
        			DBAccess.close(rset);
                    log.info("getDisplayFlagForNoHist:ret:"+ret);
        			*/
        			//対処済みのはずなので対応

        			String ret=ValueUtil.nullToStr(contractSiteMst.getDisplayFlagForNoHist(dbAccess, orderId));
                    //log.info("getDisplayFlagForNoHist:ret:"+ret);
                    if(ret.equals("1"))
        			{
                		returnHTML=htmlNg;
                		canApply=true;
        			}
        		}
        		if(canApply)
        		{
            		returnHTML=htmlNg;
        		}
        		else
        		{
        			returnHTML=htmlOther;
        		}
        	}
        	else
        	{
	        	int status=rset.getInt("contract_status");
	        	switch(status)
	        	{
	        	case OrderHist.STATUS_2_APPLICATION_WAIT:	//申請待ち
	        		returnHTML=htmlNg;
	        		break;
	        	case OrderHist.STATUS_3_CONFIRM:	//確認中
	        	case OrderHist.STATUS_4_COMPLETE:	//承認済
	        	case OrderHist.STATUS_5_REJECT:		//却下
	        	case OrderHist.STATUS_6_CANCEL:		//取消
	        		returnHTML=htmlOk;
	        		break;
	        	default:
	        		returnHTML=htmlOther;
	        		break;
	        	}
        	}
        	return returnHTML;
        }
        catch(Exception e)
        {
        	log.error("予期せぬエラー", e);
        	return htmlOther;
        }
        finally
        {
        	DBAccess.close(rset);
        	DBAccess.close(dbAccess);
        }
	}




}
