package test;

import java.util.Arrays;
import java.util.HashMap;

import net.arnx.jsonic.JSON;

public class JsonTest {

	public static void main(String[] args) {
        User user = new User();
        user.setId(1);
        user.setName("tasukujp");
        user.setHobby(Arrays.asList("running", "bouldering", "baseball"));
        user.setInterests(new String[] {"machine learning", "app"});
        user.setSkill(new HashMap<String, Object>() {
            {put("Java", true);}
            {put("Ruby", null);}
        });
        String json = JSON.encode(user);
        System.out.println(json);
    }



}
