package jp.co.webcrew.filters.batch;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * 不要になった会員マスタをきれいにするbatchクラス。
 * 
 * @author kurinami
 */
public class MemberMstCleanBatch extends BaseBatch {

	/** メンバマスタ削除用SQL */
	private static final String OLD_MEMBER_MST_DELETE = ""
			+ "delete from member_mst \n"
			+ " where email is null \n"
			+ "   and mb_mail is null \n"
			+ "   and cp_mail is null \n"
			+ "   and formal_flag = 0 \n"
			+ "   and not exists(select guid from global_session where global_session.guid = member_mst.guid) \n";

	/**
	 * 不要になった会員マスタを削除する。
	 * 
	 * @param dbAccess
	 * @throws SQLException
	 */
	protected void execute(DBAccess dbAccess) throws SQLException {

		try {

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// 不要になった会員マスタを削除する。
			dbAccess.executeUpdate(OLD_MEMBER_MST_DELETE);

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		}

	}

	/**
	 * 起動する。
	 * 
	 * @param argv
	 */
	public static void main(String[] argv) {
		new MemberMstCleanBatch().batch(argv);
	}
}
