package jp.co.webcrew.filters.bean;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.db.CResearchCategoryDb;
import jp.co.webcrew.filters.db.CResearchDb;
import jp.co.webcrew.filters.db.CResearchVotesCountingDb;
import jp.co.webcrew.filters.util.CResearchUtil;

/**
 * アンケート情報を保持するbeanクラス。
 * 投票受付中クリックリサーチ一覧を表示するためのクラス
 * 
 */
public class CResearchOnBallotListBean {

	/** ロガー */
	private static final Logger log = Logger.getLogger(CResearchOnBallotListBean.class);
  
  private List enquetesList = new ArrayList();
  private Map categoryMap = new LinkedHashMap();
  private Properties config = null;
  private String nowDate = CResearchUtil.createNowDate();

  /**
   * コンストラクタ
   * 
   * @param config
   */
  public CResearchOnBallotListBean(Properties config) {
    this.config = config;
  }
  
  /**
   * 現在日付を取得する
   * 
   * @return
   */
  public String getNowDate() {
    return nowDate;
  }
  
  /**
   * アンケート項目一覧をリストで取得する
   * 
   * @return
   */
  public List getEnquetesList() {
    return enquetesList;
  }
  
  /**
   * カテゴリ情報を取得する
   * 
   * @return
   */
  public Map getCategoryMap() {
    return categoryMap;
  }
  
  /**
   * アンケート情報を生成する
   * 
   * @return
   * @throws Exception
   */
  public boolean init() throws Exception {
    return init(nowDate);
  }
  
	/**
	 * アンケート情報を生成する
	 * 
   * @param 実行年月日
   * @return
	 * @throws Exception
	 */
	public boolean init(String nowDate) throws Exception {

		try {
      //アンケートXMLを取得
      List allEnquetesList = CResearchDb.getInstance().getAllEnquetesList();
      
      // アンケート毎の投票数を取得
      Map voteMap = CResearchVotesCountingDb.getVoteCountingSum();
      
      CResearchUtil util = new CResearchUtil(config);
      
      //各アンケートの投票件数を保存する
      util.setVoteCount(voteMap, allEnquetesList);
      
      //並び替えを行う
      if(config.get("sort") != null) {
        util.sort(allEnquetesList);
      }
      
      //受付中のデータのみを取得する
      allEnquetesList = util.getOnBallot(allEnquetesList, nowDate);
      
      //表示するアンケートだけを取得する
      enquetesList = util.create(allEnquetesList);
      
      //カテゴリ情報を取得する
      categoryMap = CResearchCategoryDb.getInstance().getCategoryMap();
      
			return true;

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			throw e;
		}
	}
}
