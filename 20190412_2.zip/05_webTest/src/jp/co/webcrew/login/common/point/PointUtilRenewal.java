/**
 * 
 */
package jp.co.webcrew.login.common.point;

import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;

/**
 * @author kazuto.yano
 *
 */
public class PointUtilRenewal 
{
	private static final String MEMBER_MST_COMMON_EXTRACT=" formal_flag=1 AND del_datetime IS NULL AND invalid_flag=0";
	
	// PointFilterからの付与
	public static final int 	CHARGE_TYPE_POINT_FILTER 	= 1;
	
	// ポイント交換不可による戻し 「とな芝管理ツール」
	public static final int 	CHARGE_TYPE_EXCHANGE_BACK 	= 2;
	public static final String 	CHARGE_REASON_EXCHANGE_BACK = "ポイント交換不可による戻し";	
	
	// クチコミの採用による加算 「とな芝管理ツール」
	public static final int 	CHARGE_TYPE_KUCHIKOMI 		= 3;
	public static final String 	CHARGE_REASON_KUCHIKOMI 	= "クチコミの採用による加算";	
	
	// クリックリサーチ付与
	public static final int 	CHARGE_TYPE_CRESEARCH 		= 5;
	public static final String 	CHARGE_REASON_CRESEARCH_1	= "クリックリサーチ(";
	public static final String 	CHARGE_REASON_CRESEARCH_2	= ")";
	
	// アンケート回答
	public static final int 	CHARGE_TYPE_ENQUETE 		= 9;
	public static final String 	CHARGE_REASON_ENQUETE_1		= "アンケート回答(";
	public static final String 	CHARGE_REASON_ENQUETE_2		= ")";
	
	// 初回ログインボーナスポイント
	public static final int 	CHARGE_TYPE_BONUS 			= 20;
	public static final String 	CHARGE_REASON_BONUS 		= "初回ログインボーナスポイント";
	
	// スロットゲームポイント付与
	public static final int 	CHARGE_TYPE_SLOT_GAME 		= 30;
	public static final String 	CHARGE_REASON_SLOT_GAME 	= "マイページミニゲーム(スロット)";
	
	// スロットゲームポイント付与
	public static final int 	CHARGE_TYPE_CLICK_AD 		= 101; //5;
	public static final String 	CHARGE_REASON_CLICK_AD_1	= "ポイントバナー(";
	public static final String 	CHARGE_REASON_CLICK_AD_2	= ")";
	
	// ズバットショッピング利用付与
	public static final int 	CHARGE_TYPE_SHOPPING 		= 103; //9;
	public static final String 	CHARGE_REASON_SHOPPING 		= "ズバットショッピング利用";
	
	// ポイント景品交換
	public static final int 	SPEND_TYPE_GOODS_EXCHANGE 	= 1;
	public static final String 	SPEND_REASON_GOODS_EXCHANGE = "ポイント景品交換";
	
	// ズバットショッピング利用消費
	public static final int 	SPEND_TYPE_SHOPPING 		= 9;
	public static final String 	SPEND_REASON_SHOPPING 		= "ズバットショッピング利用";

	// キャッシュバック要求 を表す定数
	public static final int 	SPEND_TYPE_BANK_EXCHANGE 	= 101; //1;
	public static final String 	SPEND_REASON_BANK_EXCHANGE = "楽天銀行でのキャッシュバック申請";
	
	private static final Logger logger=Logger.getLogger(PointUtilRenewal.class);
	
    private PointUtilRenewal(){}

	/****
	 * ポイントの付与を行う
	 * 
	 * @param guid 会員ID
	 * @param point 付与したいポイント数
	 * @param type ポイント付与種別
	 * @param siteId サイトID
	 * @param url URL 
	 * @param reason 付与理由
	 * @param bgn_datetime 
	 * @param auto_kbn 自動区分 true:1/false:0
	 * @param user_flag ユーザーフラグ true:1/false:0
	 * @param af_flag アフィリエートフラグ true:1/false:0
	 * @throws Exception
	 */
	public static long chargeWithTxControl(
			String      guid,
            long        point, 
            int         type,
            int 		point_id,
            long         siteId,
            String      url,
            String      reason, 
            String      bgn_datetime, 
            boolean    auto_kbn,
            boolean    user_flag,
            boolean    af_flag) throws Exception
	{
		
		DBAccess db = null;
		
		boolean committed=false;
		
        try 
        {
            db = new DBAccess();
            db.setAutoCommit(false);
		
			long pointId=chargeInternal(db,guid, point, type, point_id, siteId, url, reason, bgn_datetime, auto_kbn, user_flag, af_flag,false);
			
            db.commit();
            committed=true;
            return pointId;
		
		}
		catch(Exception exc)
		{
			//TODO エラーログをだしたいところ
			throw exc;
            
        } 
        finally 
        {
            if(!committed)
            {
            	db.rollback();
            }
        	DBAccess.close(db);
        }
		
	}


	/****
	 * ポイントの付与を行う
	 * 
	 * @param guid 会員ID
	 * @param point 付与したいポイント数
	 * @param type ポイント付与種別
	 * @param siteId サイトID
	 * @param url URL 
	 * @param reason 付与理由
	 * @param bgn_datetime 
	 * @param auto_kbn 自動区分 true:1/false:0
	 * @param user_flag ユーザーフラグ true:1/false:0
	 * @param af_flag アフィリエートフラグ true:1/false:0
	 * @throws Exception
	 */
	public static long chargeWithTxControl(
			String      guid,
            long        point, 
            int         type,
            int 		point_id,
            long         siteId,
            String      url,
            String      reason, 
            String      bgn_datetime, 
            boolean    auto_kbn,
            boolean    user_flag,
            boolean    af_flag,boolean tempFlag) throws Exception
	{
		
		DBAccess db = null;
		
		boolean committed=false;
		
        try 
        {
            db = new DBAccess();
            db.setAutoCommit(false);
		
			long pointId=chargeInternal(db,guid, point, type, point_id, siteId, url, reason, bgn_datetime, auto_kbn, user_flag, af_flag,tempFlag);
			
            db.commit();
            committed=true;
            return pointId;
		
		}
		catch(Exception exc)
		{
			//TODO エラーログをだしたいところ
			throw exc;
            
        } 
        finally 
        {
            if(!committed)
            {
            	db.rollback();
            }
        	DBAccess.close(db);
        }
		
	}

	
	/****
	 * ポイントの付与を行う
	 * 
	 * @param guid 会員ID
	 * @param point 付与したいポイント数
	 * @param type ポイント付与種別
	 * @param site_id サイトID
	 * @param url URL 
	 * @param reason 付与理由
	 * @param bgn_datetime 
	 * @param auto_kbn 自動区分 true:1/false:0
	 * @param user_flag ユーザーフラグ true:1/false:0
	 * @param af_flag アフィリエートフラグ true:1/false:0
	 * @return 
	 * @throws Exception
	 */
	public static long chargeWithoutTxControl(
			DBAccess db,
			String      guid,
            long        point, 
            int         type,
            int 		point_id,
            long        site_id,
            String      url,
            String      reason, 
            String      bgn_datetime, 
            boolean    auto_kbn,
            boolean    user_flag,
            boolean    af_flag) throws Exception
	{
		
		try
		{
		
			return chargeInternal(db,guid, point, type, point_id, site_id, url, reason, bgn_datetime, auto_kbn, user_flag, af_flag,false);
		
		}
		catch(Exception exc)
		{
			//TODO エラーログをだしたいところ
			throw exc;
		}
		
	}

	/****
	 * ポイントの付与を行う
	 * 
	 * @param guid 会員ID
	 * @param point 付与したいポイント数
	 * @param type ポイント付与種別
	 * @param site_id サイトID
	 * @param url URL 
	 * @param reason 付与理由
	 * @param bgn_datetime 
	 * @param auto_kbn 自動区分 true:1/false:0
	 * @param user_flag ユーザーフラグ true:1/false:0
	 * @param af_flag アフィリエートフラグ true:1/false:0
	 * @return 
	 * @throws Exception
	 */
	public static long chargeWithoutTxControl(
			DBAccess db,
			String      guid,
            long        point, 
            int         type,
            int 		point_id,
            long        site_id,
            String      url,
            String      reason, 
            String      bgn_datetime, 
            boolean    auto_kbn,
            boolean    user_flag,
            boolean    af_flag,
            boolean tempFlag) throws Exception
	{
		
		try
		{
		
			return chargeInternal(db,guid, point, type, point_id, site_id, url, reason, bgn_datetime, auto_kbn, user_flag, af_flag,tempFlag);
		
		}
		catch(Exception exc)
		{
			//TODO エラーログをだしたいところ
			throw exc;
		}
		
	}

	
	/****
	 * ポイントの消費を行う
	 * 
	 * @param guid
	 * @param point
	 * @param type
	 * @param site_id
	 * @param gift_id
	 * @param reason
	 * @param bgn_datetime
	 * @param auto_kbn
	 * @param user_flag
	 * @throws Exception
	 */
	public static void spendWithTxControl(
			String      guid,
            long        point, 
            int         type,
            int         site_id,
            long      gift_id,
            String      reason, 
            String      bgn_datetime, 
            boolean    auto_kbn,
            boolean    user_flag)throws Exception
	{
		DBAccess db = null;
		
		boolean committed=false;
		
        try 
        {
            db = new DBAccess();
            db.setAutoCommit(false);
		
			spendInternal(db,guid, point, type, site_id, gift_id, reason, bgn_datetime, auto_kbn, user_flag,true);
		
		}
		catch(Exception exc)
		{
			//TODO エラーログをだしたいところ
			throw exc;
        } 
        finally 
        {
            if(!committed)
            {
            	db.rollback();
            }
        	DBAccess.close(db);
        }
		
		
		
	}
	
	public static void withdraw(DBAccess db,String guid)
	throws SQLException
	{
		withdrawInternal(db, guid);
	}


	/****
	 * ポイントの消費を行う
	 * 
	 * @param guid
	 * @param point
	 * @param type
	 * @param site_id
	 * @param gift_id
	 * @param reason
	 * @param bgn_datetime
	 * @param auto_kbn
	 * @param user_flag
	 * @throws Exception
	 */
	public static void spendWithoutTxControl(
			DBAccess db,
			String      guid,
            long        point, 
            int         type,
            long        site_id,
            long      	gift_id,
            String      reason, 
            String      bgn_datetime, 
            boolean    auto_kbn,
            boolean    user_flag)throws Exception
	{
		try
		{
		
			spendInternal(db,guid, point, type, site_id, gift_id, reason, bgn_datetime, auto_kbn, user_flag,true);
		
		}
		catch(Exception exc)
		{
			//TODO エラーログをだしたいところ
			throw exc;
		}
		
		
	}
	/****
	 * 消費
	 * 
	 * @param guid
	 * @param requiredPoint 必要ポイント数
	 * @return true:利用可能なポイント数あり、false:なし
	 * @throws SQLException
	 */
	public static boolean canSpendPoint(String guid,long requiredPoint)
	throws SQLException
	{
		DBAccess db=null;
		try
		{
            db = new DBAccess();
	        MemberMstItem memberMst=selectMemberMst(db, guid,true);
	        
	        if(memberMst==null)
	        {
	        	return false;
	        }
	        
			long pointBalanceAfterSub=memberMst.balance-requiredPoint;
			
			if(pointBalanceAfterSub<0)
			{
				return false;
			}
			else
			{
				return true;
			}
		
		}
		finally
		{
			DBAccess.close(db);
		}
	}
	
	/****
	 * 現在のポイントを取得する。
	 * 
	 * @param guid
	 * @return
	 * @throws SQLException
	 */
	public static long getCurrentPoint(String guid)
	throws SQLException
	{
		DBAccess db=null;
		try
		{
            db = new DBAccess();
            MemberMstItem memberMst=selectMemberMst(db, guid,true);
            long pointBalance=memberMst.balance;
            return pointBalance;
            
		}
		finally
		{
			DBAccess.close(db);
		}
	}
	
	/****
	 * 現在のポイントを取得する。
	 * 
	 * @param guid
	 * @return
	 * @throws SQLException
	 */
	private static long getCurrentPoint(DBAccess db,String guid,boolean activeOnly)
	throws SQLException
	{
        MemberMstItem memberMst=selectMemberMst(db, guid,activeOnly);
        long pointBalance=memberMst.balance;
        return pointBalance;
	}
	
	/***
	 * 引数で指定した時点のポイント残高を取得する
	 * 
	 * @param guid
	 * @param datetimeString
	 * @return ポイント履歴が見つからない場合も
	 * @throws SQLException
	 */
	public static long getPointFindByDateTime(String guid,String datetimeString)
	throws SQLException
	{
		DBAccess db=null;
		ResultSet rset=null;
		
		//TODO 有効フラグによる絞込み
		String sqlGet_HistId_ChargeFlag=" SELECT charge_flag,point_hist_id FROM ("+
			   "  SELECT charge_flag,point_hist_id,"+
			   "         ROW_NUMBER() OVER (ORDER BY mk_datetime desc) RNUM " +
			   "  FROM tonashiba.point_balance_hist " +
			   " WHERE guid=? AND mk_datetime<=? " +
			" ) WHERE RNUM =1 ";
					
		String sqlGetBalance="SELECT balance FROM tonashiba.point_balance_hist WHERE guid=? AND charge_flag=? AND point_hist_id=? ";
			
		
		try
		{
			db=new DBAccess();
			
			MemberMstItem memberMst=selectMemberMst(db, guid,true);
			if(memberMst==null)
			{
				return 0;
			}
			
			db.prepareStatement(sqlGet_HistId_ChargeFlag);
			
			db.setString(1, guid);
			db.setString(2, datetimeString);
			
			rset=db.executeQuery();
			
			if(!rset.next())
			{
				return 0;
			}
			
			int chargeFlag=rset.getInt("charge_flag");
			long histId=rset.getLong("point_hist_id");
			
			rset.close();
			
			logger.info("[get_point_hist_id]"+histId);
			
			db.prepareStatement(sqlGetBalance);
			db.setString(1, guid);
			db.setInt(2, chargeFlag);
			db.setLong(3, histId);
			
			rset=db.executeQuery();
			if(!rset.next())
			{
				return 0;
			}
			
			
			long balance=rset.getLong("balance");
			
			return balance;
			
		}
		finally
		{
			DBAccess.close(rset);
			DBAccess.close(db);
		}
	}

	/***
	 * 
	 * @param db
	 * @param guid
	 * @param point
	 * @param type
	 * @param site_id
	 * @param url
	 * @param reason
	 * @param bgn_datetime
	 * @param auto_kbn true:1,0:false
	 * @param user_flag true:1,0:false
	 * @param af_flag true:1,0:false
	 * @throws SQLException
	 */
	private static long chargeInternal(
			DBAccess db,
			String      guid,
            long        point, 
            int         type,
            int 		point_id,
            long        site_id,
            String      url,
            String      reason, 
            String      bgn_datetime, 
            boolean    auto_kbn,
            boolean    user_flag,
            boolean    af_flag,
            boolean tempFlag
	)
	throws SQLException
	{
		//オートコミットtrueのままこのメソッドを呼び出されると、
		//不測の障害が発生するおそれがあるため
		//例外を投げている
		if(db.getAutoCommit())
		{
			throw new IllegalArgumentException("dbaccessオブジェクトのトランザクションモードがautocommitのままです。");
		}
		
	
        String sysdate=getSysDate(db);
        
        String sqlPointChargeHist = "INSERT INTO tonashiba.POINT_CHARGE_HIST (POINT_CHARGE_ID,GUID,MK_DATETIME,POINT,TYPE,"
                  + " POINT_ID,URL,REASON,AUTO_KBN,USER_FLAG,AF_FLAG,BGN_DATETIME,SITE_ID)"
                  + " VALUES(?,?,?,?,?,"
                  + " ?,?,?,?,?,?,?,?)  ";
        
        MemberMstItem memberMstItem=selectMemberMst(db, guid,true);
        
        long seq=getSeqNo(db, true);
        
        //ポイントチャージ履歴へのデータ登録(insert)
        db.prepareStatement(sqlPointChargeHist);
        int idx=0;
        db.setLong(++idx, seq);
        db.setString(++idx, guid);
        db.setString(++idx, sysdate);
        db.setLong  (++idx, point);
        db.setLong  (++idx, type);
        
        if (point_id == -1) {
        	db.setNull(++idx);
        }
        else {
        	db.setInt(++idx, point_id);
        }
        
        db.setString(++idx, url);
        db.setString(++idx, reason);
        db.setString(++idx, auto_kbn  == true ? "1" : "0");
        db.setString(++idx, user_flag == true ? "1" : "0");
        db.setString(++idx, af_flag   == true ? "1" : "0");
        db.setString(++idx, bgn_datetime);
        db.setLong   (++idx, site_id);
        
        db.executeUpdate();
        
        //ポイント履歴へのデータ登録(insert)
        long balanceAfterAdding=memberMstItem.balance+point;
        
        //仮フラグがOFFの場合
        if(tempFlag==false)
        {
        
	        insertPointBalanceHist(db, true, guid, seq, balanceAfterAdding, balanceAfterAdding,sysdate);
	        
	        boolean updateSuccess=updateMemberMst(db, true, guid, memberMstItem.updateCount, balanceAfterAdding, memberMstItem.balanceInit,sysdate);
	        
	        if(!updateSuccess)
	        {
	        	throw new PointConcurrentException("ポイントチャージ・会員マスタ更新処理にて、更新件数が１件ではなかったため、例外をthrowします。",guid);
	        }
        }
        else
        {
        	
        	String sqlInsertTempHist="INSERT INTO TONASHIBA.POINT_CHARGE_TEMP_HIST" +
        			"(POINT_CHARGE_ID,POINT,BGN_DATETIME,GUID)VALUES(?,?,?,?)";
        	db.prepareStatement(sqlInsertTempHist);
        	db.setLong(1, seq);
        	db.setLong(2, point);
        	db.setString(3, bgn_datetime);
        	db.setString(4, guid);
        	db.executeUpdate();
        	
        	boolean updateSuccess=updateMemberMstPointUpdateOnly(db, guid, sysdate);
        	
	        if(!updateSuccess)
	        {
	        	throw new PointConcurrentException("ポイントチャージ・会員マスタ更新処理にて、更新件数が１件ではなかったため、例外をthrowします。",guid);
	        }
        }
    	return seq;
	}
	
	/****
	 * ポイント消費のロジック（実装部）
	 * 
	 * @param db
	 * @param guid
	 * @param point
	 * @param type
	 * @param site_id
	 * @param gift_id
	 * @param reason
	 * @param bgn_datetime
	 * @param auto_kbn
	 * @param user_flag
	 * @throws SQLException
	 */
	private static long spendInternal
	(
			DBAccess db,
			String      guid,
            long        point, 
            int         type,
            long         site_id,
            long      gift_id,
            String      reason, 
            String      bgn_datetime, 
            boolean    auto_kbn,
            boolean    user_flag,boolean updateMemberMst)
	throws SQLException
	{
		logger.info("spendInternal:"+db.getAutoCommit());
		
		//オートコミットtrueのままこのメソッドを呼び出されると、
		//不測の障害が発生するおそれがあるため
		//例外を投げている
		if(db.getAutoCommit())
		{
			throw new IllegalArgumentException("dbaccessオブジェクトのトランザクションモードがautocommitのままです。");
		}
            
        String sysdate=getSysDate(db);
        
        
        String sqlPointSpendHist=
        "insert into TONASHIBA.POINT_SPEND_HIST"+
        	"(POINT_SPEND_ID, GUID, MK_DATETIME, POINT, TYPE" +
        	", GIFT_ID, PRICE,REASON, AUTO_KBN, USER_FLAG, INVALID_FLAG)"+
        	"values(?, ?, ?, ?, ?" +
        	", ?, ?, ?, ?, ?, 0)";
        
        
        MemberMstItem memberMstItem=selectMemberMst(db, guid,true);
        
        //ポイント初期残高の計算
        long pointBalanceAfterSub=memberMstItem.balance-point;
        //ポイント残高の計算
        long pointBalanceInitAfterSub=memberMstItem.balance-point;
        //ポイント初期残高が
        //ゼロ未満の場合、0にする
        if(pointBalanceInitAfterSub<0)
        {
        	pointBalanceInitAfterSub=0;
        }
        //ポイント初期残高がゼロの場合NG
        //ゼロ未満の場合、0にする
        if(pointBalanceAfterSub<0)
        {
        	throw new PointConcurrentException("ポイント消費・消費後のポイント残高がマイナスになるため、例外をthrowします。",guid);
        }
        
        
        long seq=getSeqNo(db, false);
        
        //ポイント消費履歴へのデータ登録(insert)
        db.prepareStatement(sqlPointSpendHist);
        int idx=0;
        db.setLong(++idx, seq);
        db.setString(++idx, guid);
        db.setString  (++idx, sysdate);
        db.setLong  (++idx, point);
        db.setLong  (++idx, type);
        
        db.setLong(++idx, gift_id);
        //price
        db.setNull(++idx);
        db.setString(++idx, reason);
        db.setString(++idx, auto_kbn  == true ? "1" : "0");
        db.setString(++idx, user_flag == true ? "1" : "0");
        //db.setString(++idx, bgn_datetime);
        //db.setInt   (++idx, site_id);
        
        db.executeUpdate();
        
        //ポイント履歴へのデータ登録(insert)
        insertPointBalanceHist(db, false, guid, seq, pointBalanceAfterSub, pointBalanceInitAfterSub,sysdate);
        
        if(updateMemberMst)
        {
	        //会員マスタのポイントの部分を更新(update)
	        boolean updateSuccess=updateMemberMst(db, false, guid, memberMstItem.updateCount, pointBalanceAfterSub, pointBalanceInitAfterSub,sysdate);
	        
	        
	        //更新件数が1件以外の場合
	        //例外を投げる
	        if(!updateSuccess)
	        {
	        	throw new PointConcurrentException("ポイント消費・会員マスタ更新処理にて、更新件数が１件ではなかったため、例外をthrowします。",guid);
	        }
        }   
            
		return seq;
	}
	
	
	private static void withdrawInternal(DBAccess db,String guid)
	throws SQLException
	{
		ResultSet rset=null;
		try
		{
			//logger.info("withdrawInternal:exec:"+db.getAutoCommit());
			//オートコミットtrueのままこのメソッドを呼び出されると、
			//不測の障害が発生するおそれがあるため
			//例外を投げている
			if(db.getAutoCommit())
			{
				throw new IllegalArgumentException("dbaccessオブジェクトのトランザクションモードがautocommitのままです。");
			}
			
			
			MemberMstItem memberMst=selectMemberMst(db, guid,false);
			
			String sysdate=getSysDate(db);
			
			long currentPoint=getCurrentPoint(db,guid,false);
			
			int type=0;
			int site_id=0;
			int gift_id=0;
			String reason="";
			String bgn_datetime="";
			boolean auto_kbn=false;
			boolean user_flag=false;
			
			//logger.info("withdrawInternal:select:"+db.getAutoCommit());
			long pointHistId=spendInternal(db, guid, currentPoint, type, site_id, gift_id, reason, bgn_datetime, auto_kbn, user_flag,false);
			
			/*
			updateMemberMst(db, false, guid, 0, 0, 0, sysdate);
			
			//TODO 有効・無効フラグによる絞込み
		    String sqlUpdateMemberMst=
		    		" UPDATE tonashiba.member_mst " +
		    		" SET " +
		    		" point_up_datetime=?  " +
		    		" WHERE guid=? AND "+MEMBER_MST_COMMON_EXTRACT;
		    
		    //long pointUpdateCountAfterAdding=pointUpdateCountBeforeAdding+1;
		    
	        //会員マスタのポイントの部分を更新(update)
	        db.prepareStatement(sqlUpdateMemberMst);
	        db.setString(1, sysdate);
	        db.setString(2, guid);
	        
	        int updateCountMemberMst=db.executeUpdate();
	        if(updateCountMemberMst==1)return true;
	        return false;
			*/
			
			String sql="DELETE FROM TONASHIBA.POINT_CHARGE_TEMP_HIST WHERE GUID=?";
			db.prepareStatement(sql);
			db.setString(1, guid);
			db.executeUpdate();

			
		}
		finally
		{
			DBAccess.close(rset);
		}
		
	}
	
	/***
	 * 会員マスタ、ポイント残高、ポイント履歴の
	 * 更新日時、登録日時の整合性を担保するためにoracleより現在日時を取得している。
	 * 
	 * @param db
	 * @return
	 * @throws SQLException
	 */
	private static String getSysDate(DBAccess db)
	throws SQLException
	{
		ResultSet rset=null;
		try
		{
			db.prepareStatement("SELECT TO_CHAR(sysdate,'YYYYMMDDHH24MISS') FROM DUAL");
			rset=db.executeQuery();
			rset.next();
			return rset.getString(1);
		}
		finally
		{
			DBAccess.close(rset);
		}
	}
	
	
	
	/****
	 * 会員マスタに対してselect文を発行する。
	 * 
	 * @param db
	 * @param guid
	 * @return
	 * @throws SQLException
	 */
	private static MemberMstItem selectMemberMst(DBAccess db,String guid,boolean activeOnly)
	throws SQLException
	{
		ResultSet rset=null;
	    String sqlSelectMemberMst;
		
	    if(activeOnly)
	    {
			//invalid_flag,del_datetime,formal_flagによる絞込みは適用済み
		    sqlSelectMemberMst=
		    	" SELECT point_balance,point_balance_init,point_up_datetime,point_update_count " +
		    	" FROM tonashiba.member_mst WHERE guid=? AND "+MEMBER_MST_COMMON_EXTRACT;
	    }
	    else
	    {
		    sqlSelectMemberMst=
		    	" SELECT point_balance,point_balance_init,point_up_datetime,point_update_count " +
		    	" FROM tonashiba.member_mst WHERE guid=? ";
	    }
	    try
	    {
	    	
	    	//会員マスタ検索（現在のポイント残高を取得）
            db.prepareStatement(sqlSelectMemberMst);
            db.setString(1, guid);
            
            rset=db.executeQuery();
            if(!rset.next())
            {
            	return null;
            }
            
            String pointLastDatetime=rset.getString("point_up_datetime");
            
            MemberMstItem memberMstItem=new MemberMstItem();
            memberMstItem.guid=guid;
            memberMstItem.balance=rset.getLong("point_balance");
            memberMstItem.balanceInit=rset.getLong("point_balance_init");
            memberMstItem.updateCount=rset.getLong("point_update_count");
            
            return memberMstItem;
            
	    }
	    finally
	    {
	    	DBAccess.close(rset);
	    }
		
	}
	
	/****
	 * ポイント残高履歴に対してINSERT文を発行する。
	 * 
	 * @param db
	 * @param charge
	 * @param guid
	 * @param seqHistId
	 * @param pointBalance
	 * @param pointBalanceInit
	 * @throws SQLException
	 */
	private static void insertPointBalanceHist(DBAccess db,boolean charge,String guid,long seqHistId,long pointBalance,long pointBalanceInit,String sysdate)
	throws SQLException
	{
	    String sqlPointBalanceHist="INSERT INTO tonashiba.point_balance_hist " +
		"(guid,charge_flag,point_hist_id,balance,mk_datetime)VALUES" +
		"(?,?,?,?,?)";

        db.prepareStatement(sqlPointBalanceHist);
        db.setString(1, guid);
        if(charge)
        {
        	db.setInt(2, 1);
        }
        else
        {
        	db.setInt(2, 0);
        }
        db.setLong(3, seqHistId);
        db.setLong(4, pointBalance);
        db.setString(5, sysdate);
        
        db.executeUpdate();
        
		
	    
	}
	
	/***
	 * 会員マスタに対してUPDATE文を発行する。
	 * 
	 * @param db
	 * @param charge
	 * @param guid
	 * @param pointUpdateCountBeforeAdding
	 * @param pointBalance
	 * @param pointBalanceInit
	 * @return
	 * @throws SQLException
	 */
	private static boolean updateMemberMst(DBAccess db,boolean charge,String guid,long pointUpdateCountBeforeAdding,long pointBalance,long pointBalanceInit,String sysdate)
	throws SQLException
	{
		//TODO 有効・無効フラグによる絞込み
	    String sqlUpdateMemberMst=
	    		" UPDATE tonashiba.member_mst " +
	    		" SET point_balance=?,point_balance_init=?" +
	    		" ,point_up_datetime=? ,point_update_count=? " +
	    		" WHERE guid=? AND point_update_count=? AND "+MEMBER_MST_COMMON_EXTRACT;
	    
	    long pointUpdateCountAfterAdding=pointUpdateCountBeforeAdding+1;
	    
        //会員マスタのポイントの部分を更新(update)
        db.prepareStatement(sqlUpdateMemberMst);
        db.setLong(1, pointBalance);
        db.setLong(2, pointBalanceInit);
        db.setString(3, sysdate);
        db.setLong(4, pointUpdateCountAfterAdding);
        db.setString(5, guid);
        db.setLong(6, pointUpdateCountBeforeAdding);
        //db.setLong(3, Date);
        
        
        int updateCountMemberMst=db.executeUpdate();
        if(updateCountMemberMst==1)return true;
        return false;
        
	}
	
	/***
	 * 会員マスタに対してUPDATE文を発行する。
	 * 
	 * @param db
	 * @param charge
	 * @param guid
	 * @param pointUpdateCountBeforeAdding
	 * @param pointBalance
	 * @param pointBalanceInit
	 * @return
	 * @throws SQLException
	 */
	private static boolean updateMemberMstPointUpdateOnly(DBAccess db,String guid,String sysdate)
	throws SQLException
	{
		//TODO 有効・無効フラグによる絞込み
	    String sqlUpdateMemberMst=
	    		" UPDATE tonashiba.member_mst " +
	    		" SET " +
	    		" point_up_datetime=?  " +
	    		" WHERE guid=? AND "+MEMBER_MST_COMMON_EXTRACT;
	    
	    //long pointUpdateCountAfterAdding=pointUpdateCountBeforeAdding+1;
	    
        //会員マスタのポイントの部分を更新(update)
        db.prepareStatement(sqlUpdateMemberMst);
        db.setString(1, sysdate);
        db.setString(2, guid);
        
        int updateCountMemberMst=db.executeUpdate();
        if(updateCountMemberMst==1)return true;
        return false;
        
	}
	
	
	
	
	/****
	 * シーケンスを発行(nextval)する。
	 * 
	 * @param db
	 * @param charge true:付与、false:消費
	 * @return
	 * @throws SQLException
	 */
	private static long getSeqNo(DBAccess db,boolean charge)
	throws SQLException
	{
		ResultSet rset=null;
		try
		{
			String sqlSeq;
			if(charge)
			{
	            sqlSeq="SELECT TONASHIBA.SEQ_POINT_CHARGE_ID.NEXTVAL FROM dual";
			}
			else
			{
	            sqlSeq="SELECT TONASHIBA.SEQ_POINT_SPEND_ID.NEXTVAL FROM dual";
			}
	        //シーケンスよりポイントチャージ履歴の主キーを取得
	        db.prepareStatement(sqlSeq);
	        rset=db.executeQuery();
	        
	        rset.next();
	        long seq=rset.getLong(1);
	        
	        return seq;

		}
		finally
		{
			DBAccess.close(rset);
		}
	}

	
	private static class MemberMstItem
	{
		/****
		 * 会員ID(GUID)
		 */
		String guid;
		/***
		 * 残高
		 */
		long balance;
		/***
		 * 初期残高
		 */
		long balanceInit;
		/***
		 * 更新回数
		 */
		long updateCount;
		
		
	}
	
	
}
