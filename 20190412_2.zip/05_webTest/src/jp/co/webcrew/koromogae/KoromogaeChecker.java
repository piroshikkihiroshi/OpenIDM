package jp.co.webcrew.koromogae;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/****
 * 衣替えチェッカー
 * 
 * 
 * 
 * 
 * @author kazuto.yano
 *
 */
public class KoromogaeChecker 
{
	
	private static final Logger logger=Logger.getLogger(KoromogaeChecker.class);
	
	private static final String PROP_FILE_NAME="koromogae.properties"; 
	private static final String PROPKEY_MODE="mode";
	//private static final String PROPKEY_INCLUDE_EXTENSIONS="include_suffixes";
	private static final String PROPKEY_LOG_LEVEL="loglevel";
	private static final String PROPKEY_EXCLUDE_URL="exclude_url_";
	private static final String PROPKEY_EXCLUDE_SUFFIXES="exclude_suffixes";
	private static final String PROPKEY_SEARCH_WORD_ZBA="search_word_zba_";
	private static final String PROPKEY_SEARCH_WORD_ZUBAT="search_word_zubat_";
	private static final Properties props=new Properties();
	
	private static List<String> listSearchWordZBA;
	private static List<String> listSearchWordZUBAT;
	private static final boolean THIS_CLASS_ENABLED;
	private static String[] excludeSuffixArray;
	private static List<String> listExcludeUrl;
	
	private static boolean logLevel_is_error;
	
	/*
	static
	{
		boolean _mode=false;
		//koromogae.propertiesの読み込みを行う
		//
		//
		InputStream is=null;
		try
		{
			ClassLoader classLodaer=KoromogaeChecker.class.getClassLoader();
			is=classLodaer.getResourceAsStream(PROP_FILE_NAME);
			
			if(is==null)
			{
				props.load(is);
	
				
				String strMode=getPropValue(PROPKEY_MODE, "off");
				if(strMode.equals("off"))
				{
					_mode=false;
				}
				else
				{
					_mode=true;
				}
				listSearchWordZBA=initSearchWord(true);
				listSearchWordZUBAT=initSearchWord(false);
				
				//logger.info("search_word:"+listSearchWord.toString());
				
				String excludeSuffixes=getPropValue(PROPKEY_EXCLUDE_SUFFIXES, "");
				
				boolean apply=true;
				if(excludeSuffixes.length()!=0)
				{
					excludeSuffixArray=excludeSuffixes.split(",");
				}
				else
				{
					excludeSuffixArray=new String[0];
				}
			
			}
		}
		catch(Exception exc)
		{
			logger.warn(PROP_FILE_NAME+"の読み込みできませんでした。koromocheckerは無効になります。"+exc.getMessage());
			//exc.printStackTrace();
			_mode=false;
			excludeSuffixArray=new String[0];
		}
		finally
		{
			try
			{
				mode=_mode;
				logger.warn("koromocheckerのon/off:"+mode);
			}catch(Exception exc){}
			
			try
			{
				is.close();
			}catch(Exception exc){}
			
		}
		
	}
	*/
	
	static
	{
		THIS_CLASS_ENABLED=initEnv();
		logger.warn("koromocheckerの有効/無効["+THIS_CLASS_ENABLED+"]");
	}
	
	
	private static boolean initEnv()
	{
		boolean mode=false;
		//koromogae.propertiesの読み込みを行う
		//
		//
		InputStream is=null;
		try
		{
			ClassLoader classLodaer=KoromogaeChecker.class.getClassLoader();
			is=classLodaer.getResourceAsStream(PROP_FILE_NAME);
			
			if(is!=null)
			{
				props.load(is);
	
				
				String strMode=getPropValue(PROPKEY_MODE, "off");
				if(strMode.equals("off"))
				{
					mode=false;
				}
				else
				{
					mode=true;
				}
				/*
				while(true)
				{
					index++;
					String word=getPropValue(PROPKEY_SEARCH_WORD+index,"");
					if(word.length()==0)
					{
						break;
					}
					listSearchWord.add(word);
				}
				*/
				listSearchWordZBA=initSearchWord(true);
				listSearchWordZUBAT=initSearchWord(false);
				listExcludeUrl=initExcludeUrlArray();
				
				//logger.info("search_word:"+listSearchWord.toString());
				
				String excludeSuffixes=getPropValue(PROPKEY_EXCLUDE_SUFFIXES, "");
				
				String logLevel=getPropValue(PROPKEY_LOG_LEVEL, "warn");
				if(logLevel.equals("error"))
				{
					logLevel_is_error=true;
				}
				else
				{
					logLevel_is_error=false;
				}
				
				
				
				
				boolean apply=true;
				if(excludeSuffixes.length()!=0)
				{
					excludeSuffixArray=excludeSuffixes.split(",");
				}
				else
				{
					excludeSuffixArray=new String[0];
				}
			
			}
			return mode;
		}
		catch(Exception exc)
		{
			logger.warn(PROP_FILE_NAME+"の読み込みできませんでした。koromocheckerは無効になります。"+exc.getMessage());
			//exc.printStackTrace();
			excludeSuffixArray=new String[0];
			return false;
		}

	}
	
	private static List<String> initSearchWord(boolean zba)
	{
		List<String> listSearchWord=new ArrayList<String>();
		
		String propKeySearchWord;
		if(zba)
		{
			propKeySearchWord=PROPKEY_SEARCH_WORD_ZBA;
		}
		else
		{
			propKeySearchWord=PROPKEY_SEARCH_WORD_ZUBAT;
		}
		
		int index=-1;
		while(true)
		{
			index++;
			String word=getPropValue(propKeySearchWord+index,"");
			if(word.length()==0)
			{
				break;
			}
			listSearchWord.add(word);
		}
		return listSearchWord;
		
	}

	private static List<String> initExcludeUrlArray()
	{
		List<String> listSearchWord=new ArrayList<String>();
		
		
		int index=-1;
		while(true)
		{
			index++;
			String word=getPropValue(PROPKEY_EXCLUDE_URL+index,"");
			if(word.length()==0)
			{
				break;
			}
			listSearchWord.add(word);
		}
		return listSearchWord;
		
	}

	
	private static final String getPropValue(String keyName,String defaultValue)
	{
		String val=ValueUtil.nullToStr(props.getProperty(keyName));
		if(val.length()==0)
		{
			return defaultValue;
		}
		return val;
	}
	
	
	
	public static void doCheck(HttpServletRequest request,HttpServletResponse response,byte[] byteArray)
	{
		doCheck(request,response,byteArray,"UTF-8");
	}
	
	public static void doCheck(HttpServletRequest request,HttpServletResponse response,byte[] byteArray,String encode)
	{
		try
		{
			doCheckInternal(request, response, byteArray, encode);
		}
		catch(Exception exc)
		{
			if(logLevel_is_error)
			{
				logger.error("衣替えチェックでエラーを検知しました", exc);
			}
			else
			{
				logger.warn("衣替えチェックでエラーを検知しました"+ exc);
			}
		}
		
	}
	
	private static final void doCheckInternal(HttpServletRequest request,HttpServletResponse response,byte[] byteArray,String encode)
	throws UnsupportedEncodingException
	{
		
		
		
		if(!THIS_CLASS_ENABLED)
		{
			return;
		}
		
		String strTobeRedirect=ValueUtil.nullToStr(request.getAttribute("tobe_redirect_flg"));
		if(strTobeRedirect.equals("true"))
		{
			return;
		}
		
		
		boolean apply=true;
		if(excludeSuffixArray.length!=0)
		{
			
			String uri=request.getRequestURI();
			for(String anExt:excludeSuffixArray)
			{
				if(anExt.length()==0)
				{
					continue;
				}
				
				if(uri.endsWith(anExt))
				{
					apply=false;
					break;
				}
			}
		}
		
		//logger.info("[thisurl]"+request.getRequestURL().toString());
		//logger.info("[thisurl]"+request.getRequestURL().toString().indexOf("://"));
		
		
		if(apply && listExcludeUrl!=null && listExcludeUrl.size()!=0)
		{
			String thisUrl=request.getRequestURL().toString();
			
			int indexof=thisUrl.indexOf("://");
			
			thisUrl=thisUrl.substring(indexof+3);
			
			//logger.info("[thisurl]"+thisUrl);
			
			for(String url:listExcludeUrl)
			{
				if(url.equals(thisUrl))
				{
					logger.info("[excludeurl]"+thisUrl);
					apply=false;
					break;
				}
			}
			
		}
		
		if(!apply)
		{
			return;
		}
		
		
		List<String> listSearchWord;
		String serverName=request.getServerName();
		if(request.getServerName().indexOf("zubat.net")!=-1)
		{
			listSearchWord=listSearchWordZUBAT;
		}
		else
		{
			listSearchWord=listSearchWordZBA;
		}
		
		
		String textData=new String(byteArray,encode);
		
		StringBuilder errorMsgBld=null;
		for(String word:listSearchWord)
		{
			int indexof=textData.indexOf(word);
			if(indexof==-1)
			{
				continue;
			}
			
			
			errorMsgBld=new StringBuilder();
			
			errorMsgBld
			.append("衣替えの対応漏れらしきものが検知されました。確認をお願いします。")
			.append("\r\n")
			.append("[検知したURL]")
			.append(request.getRequestURL())
			.append("\r\n")
			.append("[検知した文字]")
			.append(word)
			.append("\r\n")
			.append("####start####\r\n")
			.append(substring(textData, indexof, word.length()))
			.append("\r\n")
			.append("####end####\r\n")
			;
			
			break;
		}
		
		if(errorMsgBld!=null)
		{
			if(logLevel_is_error)
			{
				logger.error(errorMsgBld.toString());
			}
			else
			{
				logger.warn(errorMsgBld.toString());
			}
		}
		
		
	}
	
	private static final int RANGE=150;
	
	private static final String substring(String source,int position,int length)
	{
		int start=position-RANGE;
		if(start<0)
		{
			start=0;
		}
		int end=position+length+RANGE;
		if(source.length()-1<end)
		{
			end=source.length();
		}
		//System.out.println(start+":"+end);
		
		return source.substring(start, end);
	}
	
	/*
	public static void main(String[] args) 
	{
		String source="あいうえおかきくinfo@zubat.netけこさしすせそ";
		String searchWord="zubat.net";
		
		int position=source.indexOf(searchWord);
		
		if(position==-1)
		{
			return;
		}
		
		int length=searchWord.length();
		
		
		System.out.println(source+"[pos]"+position+"[len]"+length+"[substr]"+substring(source, position, length));
		
	}
	*/
	
	
}
