/**
 * 
 */
package jp.co.webcrew.login.common.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * @author Takahashi
 *
 */
public class DateUtil {

	/** ロガー */
    private static final Logger log = Logger.getLogger(DateUtil.class);

    /**
     * 現在日付時刻をYYYYMMDDHHMISSの文字列形式で返す
     * @return
     */
	public static String currentDateTime(){
		return now(14);
	}
	
	private static String now(int type) {

		int      Year;       /* 年   */
		int      Mon;        /* 月   */
		int      Day;        /* 日   */
//		int      WDay;       /* 曜日 */
		int      Hour;       /* 時   */
		int      Min;        /* 分   */
		int      Sec;        /* 秒   */

		TimeZone            tzone;
		GregorianCalendar   cal;

		tzone = TimeZone.getTimeZone("JST");
		cal = new GregorianCalendar(tzone);

		Year = cal.get(Calendar.YEAR);
		Mon = cal.get(Calendar.MONTH) + 1;
		Day = cal.get(Calendar.DATE);
//		WDay = cal.get(Calendar.DAY_OF_WEEK) - 1;
		Hour = cal.get(Calendar.HOUR_OF_DAY);
		Min = cal.get(Calendar.MINUTE);
		Sec = cal.get(Calendar.SECOND);

		if (type == 14) {
			// YYYYMMDDHIMMSS
			return toZString(Year,4)+toZString(Mon,2)+toZString(Day,2)+
						toZString(Hour,2)+toZString(Min,2)+toZString(Sec,2);
		}
		else {
			// YYYYMMDD
			return toZString(Year,4)+toZString(Mon,2)+toZString(Day,2);
		}
	}
	/**
	 * 数字を桁揃えする（左側に0を詰める）
	 * @param val 数字
	 * @param width 揃える桁数
	 * @return 変換後の文字列
	 */
	private static String toZString(int val, int width) {

		String s = Integer.toString(val);
		return lpadZero(s, width);
	}

	/**
	 * 文字列を指定桁数まで'0'で左詰めします
	 * @param src  変換元の文字列
	 * @param keta 桁数
	 * @return 変換後の文字列
	 * @throws IllegalDataException
	 */
	public static String lpadZero( String src ,int keta ) {
		return lpad(src,keta,"0");
	}
	
	/**
	 * 文字列を指定桁数まで左詰めします
	 * @param src  変換元の文字列
	 * @param keta 桁数
	 * @param str  埋める文字
	 * @return
	 */
	public static String lpad( String src ,int keta,String str ) {
		if(src == null){
			src = "";
		}
		
		int len = src.length();
		if(keta < len){
			log.warn("桁数の合わないデータが渡されました。");
			return "";
		}

		StringBuffer wk = new StringBuffer();
		for ( int i=0 ; i < keta - len ; i++ ){
			wk.append(str);
		}
		wk.append( src );
		
		return wk.toString();
	}

	/**
	 * カレンダーの値を文字列で返す YYYYMMDD形式
	 * @param cal
	 * @return
	 */
	public static String getDate (Calendar cal) {
		if (cal == null) return "";
		int year = cal.get(Calendar.YEAR);
		int mon = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);

		return toZString(year,4)+toZString(mon,2)+toZString(day,2);
	}
	
	/**
	 * カレンダーの値を文字列で返す YYYYMMDDHHMISS形式
	 * @param cal
	 * @return
	 */
	public static String getDateTime (Calendar cal) {
		if (cal == null) return "";

		int year = cal.get(Calendar.YEAR);
		int mon = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DATE);
		int hour = cal.get(Calendar.HOUR_OF_DAY);
		int min = cal.get(Calendar.MINUTE);
		int sec = cal.get(Calendar.SECOND);

		return toZString(year,4)+toZString(mon,2)+toZString(day,2)+
		toZString(hour,2)+toZString(min,2)+toZString(sec,2);
	}

	/**
	 * java.sql.Timestampの値を文字列で返す YYYYMMDD形式
	 * timestampがnullの時は""を返す
	 * @param Timestamp timestamp値
	 * @return
	 */
	public static String getDate (java.sql.Timestamp t) {
		if (t == null) return "";

		TimeZone tzone = TimeZone.getTimeZone("JST");
		GregorianCalendar  cal = new GregorianCalendar(tzone);
		cal.setTime(t);
		return getDate(cal);
	}

	/**
	 * java.sql.Timestampの値を文字列で返す YYYYMMDDHHMISS形式
	 * timestampがnullの時は""を返す
	 * @param Timestamp timestamp値
	 * @return
	 */
	public static String getDateTime (java.sql.Timestamp t) {
		if (t == null) return "";

		TimeZone tzone = TimeZone.getTimeZone("JST");
		GregorianCalendar  cal = new GregorianCalendar(tzone);
		cal.setTime(t);
		return getDateTime(cal);
	}

    /**
     * 指定時刻からoffsetTime分だけズレた日付時刻をYYYYMMDDHHMISS形式で返却する
     * 
     * @param offsetTime オフセット時間 デフォルトの単位は秒だが、文字列で時間単位を指定可。
     * 
     *  500    500秒後
     *  30d    30日後
     *  -24h   24時間前
     *  60m    60分後
     *  10s    10秒後
     *  
     * @return
     */
    public static String getDateTime(GregorianCalendar cal , String offsetTime) {

        int      Year;       // 年
        int      Mon;        // 月
        int      Day;        // 日 
//      int      WDay;       // 曜日 
        int      Hour;       // 時   
        int      Min;        // 分   
        int      Sec;        // 秒   

        if (cal == null) {
            return null;
        }
        
        if (offsetTime == null) offsetTime = "";
        if (offsetTime.equals("")) return getDateTime(cal);
        
        if (offsetTime.substring(offsetTime.length() - 1 ).toLowerCase().equals("d")) {
            offsetTime = offsetTime.substring(0, offsetTime.length() - 1);
            // 日付単位でずらす
            int addDay = forceInt(offsetTime);
            cal.add(Calendar.DATE, addDay);
        } else if (offsetTime.substring(offsetTime.length() - 1).toLowerCase().equals("h")) {
            offsetTime = offsetTime.substring(0, offsetTime.length() - 1);
            // 時間単位でずらす
            int addHour = forceInt(offsetTime);
            cal.add(Calendar.HOUR, addHour);
        } else if (offsetTime.substring(offsetTime.length() - 1).toLowerCase().equals("m")) {
            offsetTime = offsetTime.substring(0, offsetTime.length() - 1);
            // 分単位でずらす
            int addMin = forceInt(offsetTime);
            cal.add(Calendar.MINUTE, addMin);
        } else if (offsetTime.substring(offsetTime.length() - 1).toLowerCase().equals("s")) {
            offsetTime = offsetTime.substring(0, offsetTime.length() - 1);
            // 秒単位でずらす
            int addSec = forceInt(offsetTime);
            cal.add(Calendar.SECOND, addSec);
//      } else if (checkNumeric(offsetTime)){
        } else if (StringUtil.isNumber(offsetTime)){
            // デフォルトでは秒単位でずらす
            int addSec = forceInt(offsetTime);
            log.debug("addSec=" + addSec);
            
            cal.add(Calendar.SECOND, addSec);
        } else {
            // 現在時刻のまま返す
            log.info("解釈できない文字列が渡されました。現在時刻を返します");
            log.info("addTime = " + offsetTime);
//          return currentDateTime();
        }

        Year = cal.get(Calendar.YEAR);
        Mon = cal.get(Calendar.MONTH) + 1;
        Day = cal.get(Calendar.DATE);
//      WDay = cal.get(Calendar.DAY_OF_WEEK) - 1;
        Hour = cal.get(Calendar.HOUR_OF_DAY);
        Min = cal.get(Calendar.MINUTE);
        Sec = cal.get(Calendar.SECOND);


        return toZString(Year,4)+toZString(Mon,2)+toZString(Day,2)+
                    toZString(Hour,2)+toZString(Min,2)+toZString(Sec,2);
    }   

    
    /**
     * 指定時刻からoffsetTime分だけズレた日付時刻をYYYYMMDDHHMISS形式で返却する
     * 
     * @param offsetTime オフセット時間 デフォルトの単位は秒だが、文字列で時間単位を指定可。
     * 
     *  500    500秒後
     *  30d    30日後
     *  -24h   24時間前
     *  60m    60分後
     *  10s    10秒後
     *  
     * @return
     */
    public static String getDateTime(Timestamp t , String offsetTime) {

        if (t == null) {
            return null;
        }
        
        if (offsetTime == null) offsetTime = "";
        if (offsetTime.equals("")) return getDateTime(t);
        
        TimeZone            tzone;
        GregorianCalendar   cal;

        tzone = TimeZone.getTimeZone("JST");
        cal = new GregorianCalendar(tzone);
        cal.setTime(t);
        
        return getDateTime(cal , offsetTime);
    }   

    /**
     * 指定時刻からoffsetTime分だけズレた日付時刻をYYYYMMDDHHMISS形式で返却する
     * 
     * @param ymd YYYYMMDDHHMISS
     * @param offsetTime オフセット時間 デフォルトの単位は秒だが、文字列で時間単位を指定可。
     * 
     *  500    500秒後
     *  30d    30日後
     *  -24h   24時間前
     *  60m    60分後
     *  10s    10秒後
     *  
     * @return
     */
    public static String getDateTime(String ymd , String offsetTime) {

        if (ymd == null) {
            return null;
        }
        
        if (offsetTime == null) offsetTime = "";
        if (offsetTime.equals("")) return ymd;
        
        Timestamp t = toTimestamp(ymd);
        
        if (t == null) {
            return null;
        }
        
        return getDateTime(t , offsetTime);
    }   

    
	/**
	 * 現在時刻からoffsetTime分だけズレた日付時刻をYYYYMMDDHHMISS形式で返却する
	 * 
	 * @param offsetTime オフセット時間 デフォルトの単位は秒だが、文字列で時間単位を指定可。
	 * 
	 *  500    500秒後
	 *  30d    30日後
	 *  -24h   24時間前
	 *  60m    60分後
	 *  10s    10秒後
	 *  
	 * @return
	 */
	public static String getDateTime(String offsetTime) {

        if (offsetTime == null) offsetTime = "";
        if (offsetTime.equals("")) return currentDateTime();

        TimeZone tzone = TimeZone.getTimeZone("JST");
        GregorianCalendar cal = new GregorianCalendar(tzone);
		
        return getDateTime(cal , offsetTime);
	}	

	private static int forceInt(String str) {
		return StringUtil.forceInt(str);
	}

	/**
	 * 日付チェック 日付として妥当ならtrue、妥当でないならfalse
	 * @param yyyy 年（4文字）
	 * @param mm 月（2文字） 1文字でも可
	 * @param dd 日（2文字） 1文字でも可
	 * @return
	 */
	public static boolean checkDate(String yyyy,String mm,String dd) {
		
		if (yyyy == null) {
			log.info("引数エラー：yyyy=null");
			return false;
		}
		if (mm == null) {
			log.info("引数エラー：mm=null");
			return false;
		}
		if (dd == null) {
			log.info("引数エラー：dd=null");
			return false;
		}
		
		
		if (yyyy.length() != 4) {
			log.info("引数エラー：yyyy=" + yyyy);
			return false;
		}
		if (mm.length() > 2) {
			log.info("引数エラー：mm=" + mm);
			return false;
		}
		if (dd.length() > 2) {
			log.info("引数エラー：dd=" + dd);
			return false;
		}
		
		mm = StringUtil.lpadZero(mm, 2);
		
		dd = StringUtil.lpadZero(dd, 2);
		
		String dateString = yyyy + "-" + mm + "-" + dd;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		sdf.setLenient(false);
		try {
			Date date = sdf.parse(dateString);
			sdf.format(date);
			return true;
		} catch (ParseException e) {
			// 不正な日付
			log.warn("日付変換に失敗しました。dateString = " + dateString);
			return false;
		}	
	}
    
    /**
     * <pre>
     * YYYYMMDD 形式の日付文字列を、データベースに格納するためのYYYY-MM-DD 形式に変換して返す。
     * 
     * 変換に失敗した場合は""を返し、nullは返さない。
     * 
     * </pre>
     * 
     * @param ymd
     */
    public static String toDbDateStr(String ymd) {
        if (ymd == null) {
            return "";
        }
        
        if(ymd.length() != 8) {
            log.info("ymd = " + ymd);
            log.info("日付の形式がYYYYMMDDになっていません。");
            return "";
        }
        
        return ymd.substring(0,4) + "-" + ymd.substring(4,6) + "-" + ymd.substring(6,8);

    }

    /**
     * <pre>
     * y , m , d の日付文字列を、データベースに格納するためのYYYY-MM-DD 形式に変換して返す。
     * 
     * 変換に失敗した場合は""を返し、nullは返さない。
     * 
     * </pre>
     * 
     * @param ymd
     */
    public static String toDbDateStr(String y , String m , String d) {
        y = ValueUtil.nullToStr(y);
        m = ValueUtil.nullToStr(m);
        d = ValueUtil.nullToStr(d);

        if (y.length() != 4) {
            log.warn("年が4桁になってません。y=" + y);
            return "";
        }
        
        if (m.length() < 2) {
            
            m = StringUtil.lpadZero(m , 2);
            
        }

        if (d.length() < 2) {
            
            d = StringUtil.lpadZero(d , 2);
            
        }

        return y + "-" + m + "-" + d;

    }

    /**
     * <pre>
     * 現在日付をYYYYMMDDの形式の文字列で返す
     * 
     * </pre>
     */
    public static String currentDate(){
        return now(14).substring(0,8);
    }
    
    /**
     * <pre>
     * 現在日付をYYYY-MM-DDの形式の文字列で返す。
     * 
     * TODO データベースに格納することを想定しているが、将来的には、
     * Oracle の to_date 機能を用いるように全て置き換えること。
     * 
     * </pre>
     */
    public static String currentDbDateStr(){    
        return toDbDateStr(currentDate());
    }
    

    /**
     * <pre>
     * 日付文字列をTimestamp型に変換する。
     * 
     * 変換に失敗した場合はnullを返す。
     * 
     * 基本的に、データベースのCHAR(VARCHAR)型の日付(YYYYMMDDHHMMSS)を扱う
     * ことを想定しており、引数のフォーマットはデータベースと同じく
     * YYYYMMDD（8文字）とYYYYMMDDHHMMSS（14文字）の二種類を期待している。
     * 
     * 若干機能拡張しているため、引数として使用できる日付文字列の形式は以下の通り。
     * 
     * YYYYMMDD
     * YYYYMMDDHHMMSS
     * YYYY-MM-DD
     * YYYY/MM/DD
     * yyyy-mm-dd hh:mm:ss.fffffffff（JDBC Timestamp形式）
     * 
     * ・JDBC Timestamp形式で記述する場合を除き、ミリ秒は無視される。
     * ・年の2桁表記には対応していない。
     * ・YYYYMMDDHHMMSSもしくはJDBC Timestamp形式で記述する場合を除き、
     * 時刻は無視される。
     *
     * (例)
     * 引数（String型）         返値（Timestamp型）
     * ----------------------------------------------
     * 20080101                 2008-01-01 00:00:00.0
     * 20080235                 null (ありえない日付)
     * 2008010104               2008-01-01 00:00:00.0 (余計な文字列は無視される)
     * 20080708232546           2008-07-08 23:25:46.0 (14文字なら時刻付きと判断される)
     * 20080708232546923        2008-07-08 23:25:46.0 (ミリ秒は無視される)
     * 20080708232546.923       2008-07-08 23:25:46.0 (ミリ秒は無視される)
     * 20080708232546.923456    null (20文字以上はJDBCタイムスタンプ形式として扱われる→フーマットエラー)
     * 2008-1-1                 2008-01-01 00:00:00.0 (セパレータが入っていれば月日は1桁でも変換できる)
     * 2008-02-03               2008-02-03 00:00:00.0 
     * 2008-07-08 23:25:46.923  2008-07-08 23:25:46.923 (ミリ秒まで反映)
     * 2008-07-08 23:25:46      null (タイムスタンプ形式で指定する場合はミリ秒まで正確に指定する必要あり）
     *                          ミリ秒の指定がいらない場合はYYYYMMDDHHMMSS形式で指定する。
     * 2008/07/08 23:25:46      null (タイムスタンプ形式で指定する場合はフォーマットを正確に守る必要あり)
     * 2008/07/08 23:25:46.0    null (上に同じ)
     * 
     * </pre>
     * 
     * @param ymd
     */
    public static Timestamp toTimestamp(String ymd) {
        if (ymd == null) {
            return null;
        }
        
        ymd = ymd.trim();
        
        if (ymd.length() == 0) {
            return null;
        }
        
        if (ymd.length() < 8) {
            log.warn("引数が不正です。8文字未満の日付が指定されました。ymd=" + ymd);
            return null;
        }


        try{

            if (ymd.length() >= 14) {

                return parseDateTimeStr(ymd);
            
            }
            
            return parseDateStr(ymd);
        

        } catch (Exception e) {
            
            log.warn("日付が不正です。ymd=" + ymd);
            e.printStackTrace();
            return null;
        }

    }
    
    private static Timestamp parseDateStr(String ymd) throws ParseException{
        
        if (ymd == null) {
            return null;
        }
        
        String date = null;
        
        if (ymd.indexOf("/") >= 0) {
            date = ymd.replaceAll("/", "-"); // '/' を '-' に変換
        } else if (ymd.indexOf("-") >= 0) {
            date = ymd;
        } else {
            if (ymd.length() < 8) {
                return null;
            }
            date = toDbDateStr(ymd.substring(0,8));
        }
        
        if (date == null || date.equals("")) {
            return null;
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false);
        
        return new Timestamp(sdf.parse(date).getTime());
    }

    
    private static Timestamp parseDateTimeStr(String dateTimeStr) throws ParseException{
        
        if (dateTimeStr == null ) {
            return null;
        }
        
        if (dateTimeStr.length() == 0) {
            return null;
        }
        
        if (dateTimeStr.length() < 14) {
            return parseDateStr(dateTimeStr);
        }

        if (dateTimeStr.length() >= 20) {
            return Timestamp.valueOf(dateTimeStr);
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        sdf.setLenient(false);

        return new Timestamp(sdf.parse(dateTimeStr.substring(0 , 14)).getTime());
    }

    /**
     * <pre>
     * 年月日三つの引数から、Timestamp型の日付に変換して返す。
     * </pre>
     * @param y 年
     * @param m 月
     * @param d 日
     * @return
     */
    public static Timestamp toTimestamp (String y , String m , String d) {
        return toTimestamp(toDbDateStr(y, m, d));
    }

    

//    /**
//     * <pre>
//     * 日付を YYYYMMDD の8文字の形式に変換して返す。
//     * 
//     * YYYYMMDD もしくは YYYY{separator}MM{separator}DD の形式で渡される
//     * 日付文字列を、一律でYYYYMMDDの形式に修正する。
//     * 
//     * nullが渡された場合は null を返す。
//     * 
//     * 引数のフォーマットエラーなど、処理に失敗した場合も null を返す。
//     * 
//     * </pre>
//     * @param date 半角英数 YYYYMMDD もしくは YYYY-MM-DD,YYYY/MM/DD
//     * @return
//     */
//    private static String toYYYYMMDD(String date) {
//        
//        if (date == null) {
//            return null;
//        }
//        
//        int strLength = date.trim().length();
//        
//        if (strLength != 8 && strLength != 10) {
//            log.info("引数が不正です。birthday=" + date);
//            return null;
//        }
//        
//        if (! StringUtil.checkHankaku(date)) {
//            log.info("引数が不正です。全角文字が渡されました。birthday=" + date);
//            return null;
//        }
//        
//        if (strLength == 8) {
//            return date;
//        }
//        
//        if (strLength == 10) {
//            return date.substring(0,4) + date.substring(5,7) + date.substring(8 , 10); 
//        }
//        
//        return null;
//    }
}
