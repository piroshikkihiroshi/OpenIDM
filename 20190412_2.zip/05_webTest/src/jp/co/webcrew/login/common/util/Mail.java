package jp.co.webcrew.login.common.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

import jp.co.webcrew.dbaccess.util.Logger;
/**
 * @author Takahashi
 *
 */
public class Mail {

	/** ロガー */
	private static final Logger log = Logger.getLogger(Mail.class);

	/** SMTPサーバ接続時のタイムアウト値 (ms) */
	public static final int TIMEOUT_OF_SMTP_CONNECTION = 30000;

	/** SMTPサーバ送受信時のタイムアウト値 (ms) */
	public static final int TIMEOUT_OF_SMTP_TRANSPORT  = 30000;

	/**
	 * 
	 * 強制的にBエンコーディングをする
	 * 
	 * JavaMailはエンコーディング方法を自動決定する。
	 * Qエンコーディングに対処できない相手にはFORCE_B_ENCODINGをtrueにしてB固定で送信する
	 *
	 */
	private static final boolean FORCE_B_ENCODING = false;


	private Mail(){}


	
	/**
	 * 
	 * @param smtp
	 * @param port
	 * @param to
	 * @param cc
	 * @param bcc
	 * @param from
	 * @param fromDesc
	 * @param subject
	 * @param msg
	 * @throws Exception
	 */
	public static void sendMail(String smtp,
                                  String port,
                                  String to,
                                  String cc,
                                  String bcc,
                                  String from,
                                  String fromLabel, 
                                  String subject,
                                  String msg)
    throws Exception{

		log.debug("宛先:" + to + " subject:" + subject);

		Properties objPrp=new Properties();
		objPrp.put("mail.smtp.host" , smtp); // SMTPサーバ名
		objPrp.put("mail.host"      , smtp); // 接続するホスト名
		objPrp.put("mail.smtp.port" , port); // ポート

		//add 080530 Takahashi タイムアウト設定 --
		objPrp.put("mail.smtp.connectiontimeout" , String.valueOf(TIMEOUT_OF_SMTP_CONNECTION)); 
		objPrp.put("mail.smtp.timeout"           , String.valueOf(TIMEOUT_OF_SMTP_TRANSPORT)); 
		//-- 080530		

		// メールセッションを確立
		Session session=Session.getDefaultInstance(objPrp,null);

		// 送信メッセージを生成
		MimeMessage objMsg=new MimeMessage(session);
		try {
			// 送信先（TOの設定）
			objMsg.setRecipients(Message.RecipientType.TO, to);
			
			// 送信先（CCの設定）
			if(cc != null && !cc.trim().equals("")) {
				objMsg.setRecipients(Message.RecipientType.CC, cc);
			}
			
			// 送信先（BCCの設定）
			if(bcc != null && !bcc.trim().equals("")) {
				objMsg.setRecipients(Message.RecipientType.BCC, bcc);
			}
			
			// FromヘッダとFromラベル
			InternetAddress objFrm = null;
			if(fromLabel != null && !fromLabel.trim().equals("")) {
				objFrm = new InternetAddress(from, fromLabel);
			} else {
				objFrm = new InternetAddress(from);
			}

			objMsg.setFrom(objFrm);

			if ( FORCE_B_ENCODING ) {
				// 強制的にBエンコーディングを使う

				// 件名
				objMsg.setSubject(MimeUtility.encodeText(subject, "iso-2022-jp", "B"));

			} else {

				// 件名
				objMsg.setSubject(subject,"iso-2022-jp");

			}

			objMsg.setText(msg,"iso-2022-jp");

			// メール送信
			Transport.send(objMsg); 

			//} catch (UnsupportedEncodingException e) {
			//e.printStackTrace();
			//throw e;
		} catch (MessagingException e) {
			log.error("メール送信に失敗しました。",e);
			throw e;
		} catch (Exception e) {
			log.error("メール送信に失敗しました。",e);
			throw e;
		} 
		log.debug("メール送信成功");
	}
	
	
	/**
	 * 
	 * @param smtp
	 * @param port
	 * @param to
	 * @param cc
	 * @param bcc
	 * @param from
	 * @param subject
	 * @param msg
	 * @throws Exception
	 */
	public static void sendMail(String smtp,
            String port,
            String to,
            String cc,
            String bcc,
            String from,
            String subject,
            String msg)
      throws Exception{
		
		sendMail(smtp, port, to, cc, bcc, from, null, subject, msg);
		
	}
	
	
	/**
	 * 
	 * @param smtp
	 * @param port
	 * @param to
	 * @param from
	 * @param fromLabel
	 * @param subject
	 * @param msg
	 * @throws Exception
	 */
	public static void sendMail(String smtp,
            String port,
            String to,
            String from,
            String fromLabel,
            String subject,
            String msg)
         throws Exception{

		sendMail(smtp, port, to, null, null, from, fromLabel, subject, msg);
	}
	
	
	/**
	 * 
	 * @param smtp
	 * @param to
	 * @param from
	 * @param subject
	 * @param msg
	 * @throws MessagingException
	 */
	public static void sendMail(String smtp,
                                String port,
                                String to,
                                String from,
                                String subject,
                                String msg)
	      throws Exception{
		
		sendMail(smtp, port, to, null, null, from, null, subject, msg);
	}

	/**
	 * iso-2022-jpで扱えない文字が含まれているかをチェックしてメール送信の方法を切り替える。
	 * 
	 * @param smtp
	 * @param port
	 * @param to
	 * @param cc
	 * @param bcc
	 * @param from
	 * @param fromLabel
	 * @param subject
	 * @param msg
	 * @throws Exception
	 */
	public static void sendMailWithCharCheck(String smtp,
            String port,
            String to,
            String cc,
            String bcc,
            String from,
            String fromLabel, 
            String subject,
            String msg)
        throws Exception{
		
		// 1度iso-2022-jpに変換してみる。
		String checkMsg = new String(msg.getBytes("iso-2022-jp"), "iso-2022-jp");
		
		// iso-2022-jpに変換したものがもとの文字列と一緒の場合、iso-2022-jpで扱えると判断する。
		if (msg.equals(checkMsg)) {
			log.info("通常通りのメール送信");
			sendMail(smtp, port, to, cc, bcc, from, fromLabel, subject, msg);
		} else {
			log.info("iso-2022-jpで取扱出ない文字のメール送信"); 
			sendMailSjis(smtp, port, to, cc, bcc, from, fromLabel, subject, msg);
		}
	}

	/**
	 * 文字化けしないように、メールの本文部分だけms932で処理する。
	 * 
	 * @param smtp
	 * @param port
	 * @param to
	 * @param cc
	 * @param bcc
	 * @param from
	 * @param fromLabel
	 * @param subject
	 * @param msg
	 * @throws Exception
	 */
	private static void sendMailSjis(String smtp,
            String port,
            String to,
            String cc,
            String bcc,
            String from,
            String fromLabel, 
            String subject,
            String msg)
        throws Exception{

		log.debug("宛先:" + to + " subject:" + subject);

		Properties objPrp=new Properties();
		objPrp.put("mail.smtp.host" , smtp); // SMTPサーバ名
		objPrp.put("mail.host"      , smtp); // 接続するホスト名
		objPrp.put("mail.smtp.port" , port); // ポート

		//add 080530 Takahashi タイムアウト設定 --
		objPrp.put("mail.smtp.connectiontimeout" , String.valueOf(TIMEOUT_OF_SMTP_CONNECTION)); 
		objPrp.put("mail.smtp.timeout"           , String.valueOf(TIMEOUT_OF_SMTP_TRANSPORT)); 
		//-- 080530		

		// メールセッションを確立
		Session session=Session.getDefaultInstance(objPrp,null);

		// 送信メッセージを生成
		MimeMessage objMsg=new MimeMessage(session);
		try {
			// 送信先（TOの設定）
			objMsg.setRecipients(Message.RecipientType.TO, to);
			
			// 送信先（CCの設定）
			if(cc != null && !cc.trim().equals("")) {
				objMsg.setRecipients(Message.RecipientType.CC, cc);
			}
			
			// 送信先（BCCの設定）
			if(bcc != null && !bcc.trim().equals("")) {
				objMsg.setRecipients(Message.RecipientType.BCC, bcc);
			}

			// 差出人の設定
			if(fromLabel != null && !fromLabel.trim().equals("")) {
				objMsg.setHeader("From", MimeUtility.encodeText(fromLabel, "iso-2022-jp", "b") + " <" + from + ">");
			} else {
				objMsg.setHeader("From", from);
			}
			
			// 件名
			objMsg.setSubject(MimeUtility.encodeText(subject, "iso-2022-jp", "B"));


            // －と～の文字化けの対応を元に戻す。
            msg = msg.replace((char) 0x2212, (char) 0xFF0D);
            msg = msg.replace((char) 0x301C, (char) 0xFF5E);

			
			objMsg.setText(msg, "ms932");
			objMsg.setHeader("Content-Type", "text/plain; charset=Shift_JIS");

			// メール送信
			Transport.send(objMsg); 

		} catch (MessagingException e) {
			log.error("メール送信に失敗しました。",e);
			throw e;
		} catch (Exception e) {
			log.error("メール送信に失敗しました。",e);
			throw e;
		} 
		log.debug("メール送信成功");
	}
	
}