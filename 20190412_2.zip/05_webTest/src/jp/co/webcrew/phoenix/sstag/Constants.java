package jp.co.webcrew.phoenix.sstag;

/**
 * 固定値をまとめたインターフェース
 * 
 * @author kurinami
 */
public interface Constants {

    /** 置換変数用接頭辞 */
    public static final String REPLACE_VAL_PREFIX = "%{";

    /** 置換変数用接尾辞 */
    public static final String REPLACE_VAL_POSTFIX = "}";

    /** 置換変数用接頭辞 */
    public static final String MAIL_REPLACE_VAL_PREFIX = "$$";

    /** 置換変数用接尾辞 */
    public static final String MAIL_REPLACE_VAL_POSTFIX = "$$";

    /** スクリーニング結果セット内インデックス：表示項目名 */
    public static final int NAME_ITEM_INDEX = 0;

    /** スクリーニング結果セット内インデックス：値のリスト */
    public static final int VALUE_ITEM_INDEX = 1;

    /** スクリーニング結果セット内インデックス：表示用値名のリスト */
    public static final int DISP_ITEM_INDEX = 2;

    /** スクリーニング結果セット内インデックス：画像URLのリスト */
    public static final int IMAGE_ITEM_INDEX = 3;

    /** スクリーニング結果セット内インデックス：URLのリスト */
    public static final int URL_ITEM_INDEX = 4;

    /** スクリーニング結果セット内インデックス：その他のリスト */
    public static final int OPTION_ITEM_INDEX = 5;

    /** カラムメタ情報 項目タイプ：guid */
    public static final String CLM_TYPE_GUID = "G1";

    /** カラムメタ情報 項目タイプ：gsid */
    public static final String CLM_TYPE_GSID = "G2";

    /** カラムメタ情報 項目タイプ：ssid */
    public static final String CLM_TYPE_SSID = "G3";

    /** カラムメタ情報 項目タイプ：goid */
    public static final String CLM_TYPE_GOID = "G4";

    /** カラムメタ情報 項目タイプ：toid */
    public static final String CLM_TYPE_TOID = "G4";

    /** system_property値：都道府県マスタ */
    public static final String PHOENIX_MSTER_PREF_MST = "PHOENIX_MSTER_PREF_MST";

    /** system_property値：エリアコードマスタ */
    public static final String PHOENIX_MSTER_AREA_MST = "PHOENIX_MSTER_AREA_MST";

    /** system_property値：国マスタ */
    public static final String PHOENIX_MSTER_COUNTRY_MST = "PHOENIX_MSTER_COUNTRY_MST";

    /** system_property値：通貨マスタ */
    public static final String PHOENIX_MSTER_CURRENCY_MST = "PHOENIX_MSTER_CURRENCY_MST";

}
