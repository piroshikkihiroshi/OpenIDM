package jp.co.webcrew.filters.filters.replace;

import java.io.IOException;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.TermMstDb;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;
import jp.co.webcrew.filters.util.URLCodecUtil;

/**
 * 検索キーワードに置換を行うためのfilterクラス。
 * 
 * @author fu
 */
public class SearchWordReplaceFilter implements Filter {

    /** ロガー */
    private static final Logger log = Logger.getLogger(SearchWordReplaceFilter.class);

    /** 検索キーワード情報を格納するときの接頭辞 */
    public static final String SEARCH_WORD = "search_word";

    /** モバイル端末検索時デフォルト文字コード */
    public static final String DEFAULT_ENCODING_MOBILE = "Shift_JIS";

    /** PC端末検索時デフォルト文字コード */
    public static final String DEFAULT_ENCODING_PC = "UTF-8";

    /** サイトセッションプロパティ:対象ドメインパターン  .(yahoo|google). */
    public static final String SEARCH_DOMAIN_PATTERN = "SEARCH_DOMAIN_PATTERN";

    /** サイトセッションプロパティ:検索エンジンからのキーワードパターン。 ^(q|p)$ */
    public static final String SEARCH_WORD_PATTERN = "SEARCH_WORD_PATTERN";

    /** サイトセッションプロパティ:検索エンジンからの指定エンコーディングパターン。 ^(ie|ei)$ */
    public static final String SEARCH_ENCODING_PATTERN = "SEARCH_ENCODING_PATTERN";

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     * javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {

        log.debug("doFilter start.");

        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;

        try {

            chain.doFilter(httpServletRequest, httpServletResponse);

            // ReplaceFilterより前に実行
            String contentType = ValueUtil.nullToStr(response.getContentType());
            if (contentType.length() == 0 || contentType.toLowerCase().startsWith("text/html")) {
                setSearchWord(httpServletRequest);
            }

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            httpServletResponse.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }

        log.debug("doFilter end.");
    }

    private void setSearchWord(HttpServletRequest request) {
        try {
            // 検索エンジンからの遷移判断が必要？
            String referer = ValueUtil.nullToStr(request.getHeader("referer")).trim();
            log.debug("リファラ:" + referer);
            if (referer.indexOf("?") == -1 || referer.length() <= referer.indexOf("?")) {
                return;
            }
            String refererDomain = referer.substring(0, referer.indexOf("?"));
            String domainPattern = SystemPropertiesDb.getInstance().get(SEARCH_DOMAIN_PATTERN);
            Pattern domainPat = Pattern.compile(domainPattern);
            if (!domainPat.matcher(refererDomain).find()) {
                return; // 対象外ドメイン  .(yahoo|google).以外
            }

            // リファラパラメータの取得
            String refererQuery = referer.substring(referer.indexOf("?") + 1);
            String[] queryStrings = refererQuery.split("&");

            // 検索エンジンからのキーワードパターン。 ^(q|p)$
            String searchWordPattern = SystemPropertiesDb.getInstance().get(SEARCH_WORD_PATTERN);
            Pattern keyPat = Pattern.compile(searchWordPattern);
            // 検索エンジンからの指定エンコーディングパターン。 ^(ie|ei)$
            String encodingPattern = SystemPropertiesDb.getInstance().get(SEARCH_ENCODING_PATTERN);
            Pattern encodingPat = Pattern.compile(encodingPattern);
            String search_word = null;
            // ENCODING設定
            String inputEncoding = null;

            for (int i = 0; i < queryStrings.length; i++) {
                String[] urlParam = queryStrings[i].split("=");
                if (urlParam == null || urlParam.length < 2) {
                    break;
                }
                String name = ValueUtil.nullToStr(urlParam[0]);
                String value = ValueUtil.nullToStr(urlParam[1]);
                if (keyPat.matcher(name).find()) {
                    search_word = value;
                }
                if (encodingPat.matcher(name).find()) {
                    inputEncoding = value;
                }
                if (search_word != null && inputEncoding != null) {
                    break;
                }
            }
            // 動的キーワードをリクエスト上に登録する
            if (ValueUtil.nullToStr(search_word).trim().length() != 0) {
                if (ValueUtil.nullToStr(inputEncoding).trim().length() == 0) {
                    String ua = ValueUtil.nullToStr(request.getHeader("user-agent"));
                    inputEncoding = TermMstDb.isMobileUa(ua) ? DEFAULT_ENCODING_MOBILE : DEFAULT_ENCODING_PC; // デフォルトの文字コード設定
                }
                URLCodecUtil uc = new URLCodecUtil(inputEncoding);
                String searchWord = uc.decode(search_word);
                searchWord = searchWord.replaceAll(" ", "　"); // 注意:半角スペースがある場合IfThenElseExecuterで半角スペースで区切っています
                log.debug("SEARCH_WORD:" + searchWord + "     ENCODING:" + inputEncoding);
                KeywordReplacer.addDynamicKeyword(request, SEARCH_WORD, searchWord);
            }
        } catch (Exception ex) {
            log.error("予期せぬエラー", ex);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
     */
    public void init(FilterConfig filterConfig) throws ServletException {
        // 処理なし
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy() {
        // 処理なし
    }

}
