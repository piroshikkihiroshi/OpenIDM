package jp.co.webcrew.login.common.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

public class GlobalSession {

	private static final Logger log = Logger.getLogger(GlobalSession.class);
	public final String SQL_SELECT_GLOBAL_SESSION_FROM_GSID = "select * from global_session where gsid = ?";

	private boolean _loadSuccess = false;
	
	private String _gsid;
	private String _guid;
	private String _gsCode;
	
	public boolean exists(){
		return _loadSuccess;
	}

	public boolean load(DBAccess db , String gsid) throws SQLException{
		setGsid(gsid);
		ResultSet rs = null;
		try{
			db.prepareStatement(SQL_SELECT_GLOBAL_SESSION_FROM_GSID);
			db.setString(1, gsid);
			rs = db.executeQuery();
			if (db.next(rs)) {
				setGuid(ValueUtil.nullToStr(rs.getString("GUID")));
				setGsCode(ValueUtil.nullToStr(rs.getString("GS_CODE")));
				return true;
			} else {
				return false;				
			}
		} finally{
			DBAccess.close(rs);
		}
	}

	
 	public static void updateGuid(DBAccess db , String gsid , String guid) throws SQLException{
 		log.info("guid�̍X�V������J�n���܂�");
 		String updateSql = "update global_session set guid=? where gsid=?";
		db.prepareStatement(updateSql);
		db.setString(1, guid);
		db.setString(2, gsid);
		db.executeUpdate();		
	}
 	
	public void updateGuid(DBAccess db , String guid) throws SQLException{
		setGuid(guid);
		GlobalSession.updateGuid(db, getGsid(), getGuid());
	}
	
	public String getGsCode() {
		return _gsCode;
	}

	public void setGsCode(String code) {
		_gsCode = code;
	}

	public String getGsid() {
		return _gsid;
	}

	public void setGsid(String _gsid) {
		this._gsid = _gsid;
	}

	public String getGuid() {
		return _guid;
	}

	public void setGuid(String _guid) {
		this._guid = _guid;
	}


}
