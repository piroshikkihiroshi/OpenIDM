package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * サーバサイドタグの試験用のExecuterクラス。
 * 
 * @author kurinami
 */
public class TestExecuter extends SSTagExecuter {

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {

		StringBuffer sb = new StringBuffer();

		sb.append("<center>\n");
		sb
				.append("<table border='0' cellpadding='5' cellspacing='1' bgcolor='#CCCCCC'>\n");

		Iterator i = parameterMap.keySet().iterator();
		while (i.hasNext()) {
			String key = (String) i.next();
			String value = (String) parameterMap.get(key);

			sb.append("<tr bgcolor='#FFFFFF'>");
			sb.append("<td>");
			sb.append(key);
			sb.append("</td>");
			sb.append("<td>");
			sb.append(value);
			sb.append("</td>");
			sb.append("</tr>\n");
		}

		sb.append("</table>\n");
		sb.append("</center>\n");

		return sb.toString();
	}

}
