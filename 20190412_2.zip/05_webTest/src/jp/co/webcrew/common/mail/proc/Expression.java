package jp.co.webcrew.common.mail.proc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.common.util.proc.StringUtils;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Models the base expression type in calculations. All updates, calculations
 * etc should extend this class.
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: Expression.java,v 1.3 2005-06-14 11:45:19 rickk Exp $
 */
public abstract class Expression {
    static final String ATTR_ORDER = "order";
    static final String ATTR_DO_MAIL_REPLACE_BEFORE = "doMailReplaceBefore";
    static final String ELEM_VARIATION = "flowVariation";
    
    private int orderIndex;
    private boolean preReplace;
    private FlowVariation flowVariations[]; 
    
    protected Expression(Node node) {
        Node order = node.getAttributes().getNamedItem(ATTR_ORDER);
        this.orderIndex = Integer.parseInt(order.getNodeValue());

        Node preReplace = node.getAttributes().getNamedItem(ATTR_DO_MAIL_REPLACE_BEFORE);
        this.preReplace = (preReplace != null) && preReplace.getNodeValue().equalsIgnoreCase("true");
        
        // parse for variations
        NodeList nodeList = node.getChildNodes();
        List variations = new ArrayList();
        for (int n = 0; n < nodeList.getLength(); n++) {
            Node childNode = nodeList.item(n);

            if (childNode.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            } else if (childNode.getNodeName().equals(ELEM_VARIATION)) {
                variations.add(new FlowVariation(childNode));
            }
        }
        this.flowVariations = (FlowVariation []) variations.toArray(
                new FlowVariation[variations.size()]);
    }

    public int getOrderIndex() {
        return this.orderIndex;
    }

//    public boolean getPreReplace() {
//        return this.preReplace;
//    }
    
    protected void doReplace(Map wildcards) {
        if (this.preReplace) {
            String replaceWildcards[][] = getWildcardArrayForReplacement(wildcards);
            doWildcardReplace(wildcards, replaceWildcards);
        }
    }
    
    /**
     * Get the body fields as a replacement array
     */
    public static String[][] getWildcardArrayForReplacement(Map wildcards) {
        System.out.println("Doing pre-SQL-execution replace of wildcards");
        
        String[][] replaceWildcards = new String[wildcards.size()][2];

        int n = 0;
        for (Iterator i = wildcards.values().iterator(); i.hasNext(); n++) {
            WildcardValue wc = (WildcardValue) i.next();
            
            replaceWildcards[n][0] = "###" + wc.getName().toUpperCase() + "###";
            replaceWildcards[n][1] = CalculationSet.convertToStringForm(wc.getValue(), wc.getType());
            System.out.println("Found wildcard: " + replaceWildcards[n][0] +
                " = " + replaceWildcards[n][1] + " (type " + wc.getType() + ")");
        }
        return replaceWildcards;
    }
    
    /**
     * Get the body fields and replace any wildcards within them
     */
    public static void doWildcardReplace(Map wildcards, String replaceWildcards[][]) {

        for (Iterator i = wildcards.values().iterator(); i.hasNext(); ) {
            WildcardValue wc = (WildcardValue) i.next();
            if ((wc.getType().equalsIgnoreCase("String") || 
                    wc.getType().equalsIgnoreCase("LongString")) &&
                    (wc.getValue() != null)) {
                String stringForm = CalculationSet.convertToStringForm(wc.getValue(), wc.getType());
                wc.setValue(StringUtils.stringReplace(
                        StringUtils.capitalizeWildcardNames(stringForm),
                                replaceWildcards));
            }
        }

        System.out.println("Completed pre-SQL-execution replace of wildcards");
    }
    
    public abstract void evaluateExpression(Connection connection,
            List wildcardRows) throws SQLException;
    
    public FlowVariation checkForVariation(Map wildcards) {
        for (int n = 0; n < this.flowVariations.length; n++) {
            if (this.flowVariations[n].isMatching(wildcards)) {
                return this.flowVariations[n];
            }
        }
        return null;
    }
}
