package jp.co.webcrew.logic.lib._02_work;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.BindLogicStdStatus;
import jp.co.webcrew.phoenix.logic.ItemConvLogicStatus;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import net.arnx.jsonic.JSON;

public class Kadai_3_2_LogicTest extends SstagDynamicLogic {


	Logger logger = Logger.getLogger(Kadai_3_2_LogicTest.class);





	@Override
	public BindLogicStdStatus stdLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam, List<String> userParam,
			FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo) {
		PhoenixDBAccess dbAccess = null;
		ResultSet rs = null;
		int ret = 0;

		// 採番用変数
		int MaxNum = 0;

		int intSiteId = 91076;


		logger.info("サイトInfo：" + JSON.encode(sgInfo));

		// 採番用SQL
		String strSql = "select MAX(ORDER_ID) from \"TATSUYA.UEDA\".ORDER_INFO";
//		String strSql = "select MAX(ORDER_ID) from ORDER_INFO;";
//		String strSql = "select 1 from dual";



		// DBにアクセスして採番用の値を取得
		try {
			dbAccess = new PhoenixDBAccess(intSiteId);

			logger.info("phoenixInfo：" + dbAccess.getPhoenixSchema());


//			dbAccess.setAutoCommit(false);

			logger.info("sql: " + strSql);
//			dbAccess.prepareStatement(MAXNUMBER_QUERY);
			rs = dbAccess.executeQuery(strSql);
			logger.info("LOG");

//			while (rs.next()) {
//				String max = rs.getString("ORDER_ID");
//				MaxNum = Integer.parseInt(max);
//				MaxNum++;
//			}

			logger.info("次回の採番：" + MaxNum);


		} catch (SQLException e) {
			logger.error("test 採番処理でエラーになりました", e);
			e.printStackTrace();

		} catch (Exception e) {
			logger.error("よきせぬERROR", e);
			e.printStackTrace();

		} finally {
			PhoenixDBAccess.close(dbAccess);
			PhoenixDBAccess.close(rs);
		}


		BindLogicExtStatus status = new BindLogicExtStatus();

		return status;

	}
	@Override
	public BindLogicExtStatus validationLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}
	@Override
	public JudgementLogicStatus judgementLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}
	@Override
	public ItemConvLogicStatus itemConvLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String sub1,
			String sub2, String result) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
