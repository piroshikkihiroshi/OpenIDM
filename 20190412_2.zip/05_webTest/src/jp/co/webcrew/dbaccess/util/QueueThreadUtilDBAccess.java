/**
 * 
 */
package jp.co.webcrew.dbaccess.util;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.NoSuchElementException;


import jp.co.webcrew.dbaccess.util.Logger;

/**
 * queueを制御するためのutilクラス。
 * 
 * @author kurinami
 */
abstract public class QueueThreadUtilDBAccess<T> implements Runnable {

	/** ロガー */
	private static final Logger log = Logger.getLogger(QueueThreadUtilDBAccess.class);

	/** スレッド待機時間 */
	private static final int WAIT_TIME = 60000;

	/** 処理するためのキュー */
	private LinkedList<T> queue = new LinkedList<T>();

	/**
	 * スレッドを開始する。
	 */
	public void start() {
		log.debug("start daemon thread [" + this.getClass().getName() + "]");
		Thread thread = new Thread(this);
		thread.setDaemon(true);
		thread.start();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		while (true) {
			try {
				T object = poll();
				if (object != null) {
					execute(object);
				} else {
					synchronized (this) {
						this.wait(WAIT_TIME);
					}
				}
			} catch (Exception e) {
				log.error("予期せぬエラー", e);
			}
		}

	}

	/**
	 * キューから処理対象を取得する。
	 * 
	 * @return
	 */
	public T poll() {
		T request = null;

		synchronized (queue) {
			try {
				request = (T) queue.removeFirst();
			} catch (NoSuchElementException e) {
			}
		}

		return request;
	}

	/**
	 * キューに処理対象を登録する。
	 * 
	 * @param object
	 */
	public void push(T object) {

		synchronized (queue) {
			queue.addLast(object);
		}
		synchronized (this) {
			this.notify();
		}
	}

	/**
	 * 処理対象に対して処理を行う。
	 * 
	 * @param request
	 * @throws SQLException
	 */
	abstract protected void execute(T request)
			throws Exception;
	
	
}
