package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.TermMstDb;
import jp.co.webcrew.filters.filters.session.UserInfo;

/**
 * ルールに従ってリダイレクトを行うExecuerクラス。
 * 
 * @author kurinami
 */
public class AutoRedirectExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(AutoRedirectExecuter.class);

	/** キャリア種別：全て */
	private static final String CARRIER_ALL = "all";

	/** キャリア種別：PC */
	private static final String CARRIER_PC = "pc";

	/** キャリア種別：携帯 */
	private static final String CARRIER_MOBILE = "mobile";

	/** キャリア種別：docomo */
	private static final String CARRIER_DOCOMO = "docomo";

	/** キャリア種別：au */
	private static final String CARRIER_AU = "au";

	/** キャリア種別：softbank */
	private static final String CARRIER_SOFTBANK = "softbank";

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {

		try {

			String carrier = ValueUtil.nullToStr(parameterMap.get("carrier"));
			if (carrier.length() == 0) {
				log.error("パラメータ[carrier]が指定されていません。");
				return "";
			}

			String prefix = ValueUtil.nullToStr(parameterMap.get("prefix"));
			String hostPrefix = ValueUtil.nullToStr(parameterMap
					.get("host_prefix"));
			String url = ValueUtil.nullToStr(parameterMap.get("url"));
			if (prefix.length() == 0 && hostPrefix.length() == 0
					&& url.length() == 0) {
				log.error("パラメータ[prefix/host_prefix/url]のいずれも指定されていません。");
				return "";
			}

			// リダイレクト対象かどうかをチェックする。
			String[] carriers = getCarriers(carrier);
			String userCarrier = (String) request
					.getAttribute(UserInfo.SITE_MST_CARRIER_ATTR_KEY);
			boolean carrierMatchFlag = isCarrierMatch(carriers, userCarrier);
			if (!carrierMatchFlag) {
				return "";
			}

			// 遷移先に遷移すべきかチェックの上、リダイレクトする。
			String requestURI = request.getRequestURI();
			String requestURL = request.getRequestURL().toString();

			if (prefix.length() > 0) {
				if (!requestURI.startsWith(prefix)) {
					response.sendRedirect(prefix + requestURI);
				}
			} else if (hostPrefix.length() > 0) {
				if (!requestURL.startsWith(hostPrefix)) {
					response.sendRedirect(hostPrefix + requestURI);
				}
			} else if (url.length() > 0) {
				if (!requestURL.equals(url)) {
					response.sendRedirect(url);
				}
			}

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		return "";
	}

	/**
	 * 対象の端末の一覧を返す。
	 * 
	 * @param carrier
	 * @return
	 */
	private String[] getCarriers(String carrier) {
		String[] carriers = carrier.split("\\|");
		for (int i = 0; i < carriers.length; i++) {
			carriers[i] = carriers[i].trim().toLowerCase();
		}
		return carriers;
	}

	/**
	 * 対象の端末一覧に、リクエスト元が該当するかをチェックする。
	 * 
	 * @param carriers
	 * @param userCarrier
	 * @return
	 */
	private boolean isCarrierMatch(String[] carriers, String userCarrier) {

		boolean carrierMatchFlag = false;

		for (int i = 0; i < carriers.length; i++) {
			if (carriers[i].equals(CARRIER_ALL)) {
				carrierMatchFlag = true;
				break;
			} else if (carriers[i].equals(CARRIER_PC)) {
				if (!TermMstDb.isMobileCarrier(userCarrier)) {
					carrierMatchFlag = true;
					break;
				}
			} else if (carriers[i].equals(CARRIER_MOBILE)) {
				if (TermMstDb.isMobileCarrier(userCarrier)) {
					carrierMatchFlag = true;
					break;
				}
			} else if (carriers[i].equals(CARRIER_DOCOMO)) {
				if (userCarrier.equals(TermMstDb.TYPE_DOCOMO)) {
					carrierMatchFlag = true;
					break;
				}
			} else if (carriers[i].equals(CARRIER_AU)) {
				if (userCarrier.equals(TermMstDb.TYPE_AU)) {
					carrierMatchFlag = true;
					break;
				}
			} else if (carriers[i].equals(CARRIER_SOFTBANK)) {
				if (userCarrier.equals(TermMstDb.TYPE_SOFTBANK)) {
					carrierMatchFlag = true;
					break;
				}
			}
		}

		return carrierMatchFlag;
	}
}
