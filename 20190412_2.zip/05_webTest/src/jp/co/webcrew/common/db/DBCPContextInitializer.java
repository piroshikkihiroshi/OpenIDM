package jp.co.webcrew.common.db;

import generator.runtime.db.DBContextInitializer;
import generator.runtime.exception.ApplicationException;
import generator.runtime.utils.ApplicationProperties;

import java.util.HashSet;
import java.util.Set;

/**
 * WC specific property paths for the connection pool
 * 
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: DBCPContextInitializer.java,v 1.3 2007-04-09 10:37:11 rickk Exp $
 */
public class DBCPContextInitializer extends DBContextInitializer {

    protected String getBasePoolPropertiesFilter(ApplicationProperties props) {
        throw new ApplicationException("This should never be called - the method overrides " +
                "in " + this.getClass().getName() + " are incorrect");
    }
    
    protected String getDefaultPoolImplementationClassName(ApplicationProperties props) {
        return DBCPDBConnectionWrapperSource.class.getName();
    }

    protected String getDefaultPoolSetId(ApplicationProperties props, Set poolsetIds) {
        return (String) poolsetIds.iterator().next();
    }

    protected String getPeerPropertiesFilter(ApplicationProperties props, String poolsetId) {
        return "peers/";
    }

    protected String getCachePropertiesFilter(ApplicationProperties props, String poolsetId) {
        return "jdbc/cache/";
    }

    protected String getPoolPropertiesFilter(ApplicationProperties props, String poolsetId) {
        return "dbConnectionPool/";
    }

    protected Set getPoolsetIds(ApplicationProperties props) {
        Set ids = new HashSet();
        ids.add("main");
        return ids;
    }
}
