package jp.co.webcrew.filters.db.voice;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.bean.voice.SateiomakaseVoiceBean;
import jp.co.webcrew.filters.bean.voice.VoiceBean;
import jp.co.webcrew.login.common.util.Kana2Roma;

/**
 * 口コミ一覧を管理するdbクラス。
 * 
 * @author Fu
 */
public class SateiomakaseVoiceMstDb extends RefreshMstDb {

    /** ロガー */
    private static final Logger objLog = Logger.getLogger(SateiomakaseVoiceMstDb.class);

    /** 口コミ一覧情報取得用SQL 検索対象は最近5年間のデータです。 */
    private static final StringBuffer SELECT_BY_DATE = new StringBuffer()
    		.append(" SELECT (SELECT 'STEP_LAST_UPDATE=' || TO_CHAR(OI.LAST_UPDATE, 'YYYYMMDD')")
            .append(" || ':ADDRESS_1=' || UI.ADDRESS_1 || ':ADDRESS_2=' || UI.ADDRESS_2 ||")
            .append("     ':MAKE_NAME=' || (SELECT MAKER_MST.VALUE")
            .append("     FROM COMMON.MAKER_MST")
            .append("     WHERE MAKER_MST.ID = OI.MAKER_ID) || ':SHASHU_NAME=' || OI.SHASHU_NAME || ':MODEL_YEAR=' || (SELECT")
            .append("         MODEL_YEAR_MST.NAME")
            .append("     FROM SATEIOMAKASE.MODEL_YEAR_MST")
            .append("     WHERE MODEL_YEAR_MST.DELETE_DATE IS NULL AND MODEL_YEAR_MST.MODEL_YEAR_ID != 1 ")
            .append("     AND MODEL_YEAR_MST.MODEL_YEAR_ID = OI.MODEL_YEAR_ID) || ':BC_BASE=' || (SELECT BC_BASE_MST.NAME")
            .append("     FROM SATEIOMAKASE.BC_BASE_MST")
            .append("     WHERE BC_BASE_MST.DELETE_DATE IS NULL")
            .append("     AND BC_BASE_MST.BC_BASE_ID = OI.BC_BASE_ID) || ':NAME_KANA_1=' || UI.NAME_KANA_1 || ':NAME_KANA_2=' || UI.NAME_KANA_2")
            .append(" FROM SATEIOMAKASE.ORDER_INFO OI,")
            .append("     SATEIOMAKASE.USER_INFO UI")
            .append(" WHERE OI.ORDER_ID = EI.ORDER_ID")
            .append(" AND OI.USER_ID = UI.USER_ID")
            .append(" AND OI.ORDER_ID = EI.ORDER_ID) AS STEP_DATA ,")
            .append(" DECODE(EI.SEX_ID, 2, '女性', '男性') SEX_NAME,")
            .append(" (SELECT NAME")
            .append(" FROM SATEIOMAKASE.ENQUETE_AGE_MST EAM")
            .append(" WHERE EAM.DELETE_DATE IS NULL")
            .append(" AND EAM.AGE_ID = EI.AGE_ID) AS AGE_RANGE,")
            .append(" (CASE WHEN EI.CONTRACT_COMPANY_ID IS NULL")
            .append(" OR EI.CONTRACT_COMPANY_ID > 999 THEN NULL WHEN EI.CONTRACT_COMPANY_ID = 996 THEN 'COMPANY_ID_MTM=' || 996 || ':COMPANY_NAME=' || '売却はしなかった' WHEN EI.CONTRACT_COMPANY_ID")
            .append("      = 997 THEN 'COMPANY_ID_MTM=' || 997 || ':COMPANY_NAME=' || '中古車販売店で購入時に下取り' WHEN EI.CONTRACT_COMPANY_ID = 998 THEN 'COMPANY_ID_MTM=' || 998 || ':COMPANY_NAME=' || '新規販売店で購入時に下取り'")
            .append("     WHEN EI.CONTRACT_COMPANY_ID = 999 THEN 'COMPANY_ID_MTM=' || 999 || ':COMPANY_NAME=' || 'その他の買取会社' ELSE (SELECT 'COMPANY_ID_MTM=' || CMM.COMPANY_ID_MTM ||")
            .append("         ':COMPANY_NAME=' || CMM.NAME || ':COMPANY_NAME_KANA=' || CMM.NAME_KANA ")
            .append("     FROM SATEIOMAKASE.COMPANY_MTM_MST CMM,")
            .append("         SATEIOMAKASE.COMPANY_MST CM")
            .append("     WHERE CMM.COMPANY_ID_MTM = CM.COMPANY_ID_MTM")
            .append("     AND CMM.DELETE_DATE IS NULL")
            .append("     AND CM.COMPANY_ID = EI.CONTRACT_COMPANY_ID) END) AS COMPANY_NAME,")
            .append(" EI.ORDER_ID,")
            .append(" EI.ENQUETE_ID,")
            .append(" TO_CHAR(EI.LAST_UPDATE, 'YYYY/MM/DD') AS LAST_UPDATE,")
            .append("  (SELECT NAME")
            .append(" FROM SATEIOMAKASE.ENQUETE_SELL_EXP_MST")
            .append(" WHERE ENQUETE_SELL_EXP_MST.SELL_EXP_ID = EI.SELL_EXP_ID")
            .append(" AND DELETE_DATE IS NULL) AS SELL_EXP_NAME,")
            .append(" RCI.REASON_ID,")
            .append(" EI.RESPONSE_COMMENT,")
            .append(" EI.ADVICE_COMMENT,")
            .append(" ACI.ADVICE_ID,")
            .append(" EI.USEFUL_VOTE_NUM,")
            .append(" EI.KUTIKOMI_FLG,")
            .append(" EI.MTM_SHOW_FLG")
            .append(" FROM SATEIOMAKASE.ENQUETE_INFO EI,")
            .append("    SATEIOMAKASE.ENQUETE_ADVICE_INTER ACI,")
            .append("    SATEIOMAKASE.ENQUETE_REASON_CONTACT_INTER RCI")
            .append(" WHERE EI.LAST_UPDATE > ADD_MONTHS(SYSDATE, - 60)")
            .append(" AND EI.ENQUETE_ID = ACI.ENQUETE_ID(+)")
            .append(" AND EI.ENQUETE_ID = RCI.ENQUETE_ID(+)")
            .append(" AND EI.KUTIKOMI_FLG = 1")
            .append(" AND EI.MTM_SHOW_FLG = 1")
            .append(" ORDER BY EI.LAST_UPDATE DESC NULLS LAST, EI.ENQUETE_ID");

    /** アドバイスリスト一覧取得SQL */
    private static final String ADVICE_MST_SELECT = "SELECT ADVICE_ID, NAME FROM SATEIOMAKASE.ENQUETE_ADVICE_MST WHERE DELETE_DATE IS NULL ORDER BY SORT";

    /** 口コミ会社一覧(参加中のみ)を取得するSQL */
    private static final StringBuffer COMPANY_MTM_MST_SELECT = new StringBuffer()
    		.append("SELECT DISTINCT CMM.COMPANY_ID_MTM, CMM.NAME, CMM.NAME_KANA, ")
            .append(" (SELECT COUNT(ENQUETE_INFO.ENQUETE_ID)")
            .append("    FROM SATEIOMAKASE.ENQUETE_INFO")
            .append("    WHERE ENQUETE_INFO.LAST_UPDATE > ADD_MONTHS(SYSDATE, - 60)")
            .append("    AND ENQUETE_INFO.KUTIKOMI_FLG = 1")
            .append("    AND ENQUETE_INFO.MTM_SHOW_FLG = 1")
            .append("    AND ENQUETE_INFO.CONTRACT_COMPANY_ID IN (SELECT COMPANY_MST.COMPANY_ID")
            .append("        FROM SATEIOMAKASE.COMPANY_MST")
            .append("        WHERE COMPANY_MST.COMPANY_ID_MTM = CMM.COMPANY_ID_MTM)) AS VOICE_CNT")
            .append(" FROM SATEIOMAKASE.COMPANY_MTM_MST CMM,")
            .append(" SATEIOMAKASE.COMPANY_MST CM WHERE CMM.COMPANY_ID_MTM = CM.COMPANY_ID_MTM AND CM.DELETE_DATE IS NULL AND CM.STATUS_FLG = 1")
            .append(" AND CMM.DELETE_DATE IS NULL AND CM.COMPANY_ID < 996 AND (CM.START_DATE IS NULL OR CM.START_DATE < SYSDATE) AND (CM.END_DATE IS NULL OR CM.END_DATE > SYSDATE) ")
            .append(" ORDER BY NLSSORT(CMM.NAME_KANA,'NLS_SORT=JAPANESE_M')");
    
    /** 決め手理由リスト一覧取得SQL */
    private static final StringBuffer REASON_MST_SELECT = new StringBuffer()
    		.append("SELECT REASON_ID, NAME FROM SATEIOMAKASE.ENQUETE_REASON_MST ")
    		.append(" WHERE DELETE_DATE IS NULL ORDER BY SORT");

    /** 唯一のインスタンス */
    private static SateiomakaseVoiceMstDb voiceDb = new SateiomakaseVoiceMstDb();

    /** 新着順口コミ一覧リスト一覧 */
    private List voiceBeanListByDate = new ArrayList();

    /** 参考になった件数順口コミ一覧リスト一覧 上記の新着順口コミ一覧リストより作成したもの。 */
    private List voiceBeanListByVote = new ArrayList();

    /** 決め手理由リスト一覧 */
    private List reasonList;

    /** アドバイスリスト一覧 */
    private List adviceList;

    /** 口コミ会社リスト一覧 */
    private List companyList;

    /**
     * 生成不能コンストラクタ
     */
    private SateiomakaseVoiceMstDb() {
    }

    /**
     * 唯一のインスタンスを返す。
     * 
     * @return
     */
    public static SateiomakaseVoiceMstDb getInstance() {
        return voiceDb;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
     */
    public void init() throws SQLException {

        DBAccess db = null;
        ResultSet rs = null;
        try 
        {
            long lStart = System.currentTimeMillis();

            // db = ZubatDbUtil.getSateiomakaseDb();
            db = new DBAccess();

            // 決め手理由一覧を検索する。
            db.prepareStatement(REASON_MST_SELECT.toString());
            rs = db.executeQuery();
            List<Map> lstReason = new ArrayList<Map>();
            Map<String, String> mapReason = null;
            while (db.next(rs)) 
            {
                mapReason = new HashMap<String, String>();
                mapReason.put("REASON_ID", rs.getString("REASON_ID"));
                mapReason.put("NAME", rs.getString("NAME"));
                lstReason.add(mapReason);
            }
            this.reasonList = lstReason;

            // アドバイス一覧を検索する。
            db.prepareStatement(ADVICE_MST_SELECT);
            rs = db.executeQuery();
            List<Map> lstAadvice = new ArrayList<Map>();
            Map<String, String> mapAdvice = null;
            while (db.next(rs)) 
            {
                mapAdvice = new HashMap<String, String>();
                mapAdvice.put("ADVICE_ID", rs.getString("ADVICE_ID"));
                mapAdvice.put("NAME", rs.getString("NAME"));
                lstAadvice.add(mapAdvice);
            }
            this.adviceList = lstAadvice;

            // 口コミ参加会社一覧を検索する。
            db.prepareStatement(COMPANY_MTM_MST_SELECT.toString());
            rs = db.executeQuery();
            this.companyList = getCompanyList(db, rs);

            // 新着順口コミ一覧を検索する。
            db.prepareStatement(SELECT_BY_DATE.toString());
            rs = db.executeQuery();
            this.voiceBeanListByDate = getVoiceBeanList(db, rs);

            long lDuration = System.currentTimeMillis() - lStart;

            objLog.info("VoiceMstDb#init() duration:" + lDuration + " ms");
        } 
        finally 
        {
            DBAccess.close(rs);
            DBAccess.close(db);
        }

    }

    /**
     * @param dbAccess
     * @param rs
     * @return _voiceBeanList
     * @throws SQLException
     */
    private List getVoiceBeanList(DBAccess dbAccess, ResultSet rs) throws SQLException 
    {
        List<VoiceBean> lstVoiceBean 		= new ArrayList<VoiceBean>();
        Map mapStep 						= null;
        Map mapCompany 						= null;
        SateiomakaseVoiceBean objVoiceBean 	= null;
        String strPreEnqId				 	= "";
        String strCurrEnqId 				= "";
        int nIdx 							= 0;
        
        while (dbAccess.next(rs)) 
        {
            // アンケートIDが変わる場合
            strCurrEnqId = rs.getString("ENQUETE_ID");
            if (strPreEnqId.equals(strCurrEnqId)) 
            {
                if (rs.getString("REASON_ID") != null) 
                {
                    if (objVoiceBean.getReasonIdSb().length() > 0) 
                    {
                        // 重複しないように
                        if (objVoiceBean.getReasonIdSb().indexOf(
                                (":").concat(ValueUtil.nullToStr(rs.getString("REASON_ID")))) == -1) {
                            {
                                objVoiceBean.getReasonIdSb().append(":").append(
                                        ValueUtil.nullToStr(rs.getString("REASON_ID")));
                                objVoiceBean.getReasonNameSb().append("\n").append(
                                        ValueUtil.nullToStr(getReasonName(rs.getString("REASON_ID"))));
                            }
                        }
                    } 
                    else 
                    {
                        objVoiceBean.getReasonIdSb().append(ValueUtil.nullToStr(rs.getString("REASON_ID")));
                        objVoiceBean.getReasonNameSb().append(
                                ValueUtil.nullToStr(getReasonName(rs.getString("REASON_ID"))));
                    }
                }
                
                if (rs.getString("ADVICE_ID") != null) 
                {
                    if (objVoiceBean.getAdviceIdSb().length() > 0) 
                    {
                        // 重複しないように
                        if (objVoiceBean.getAdviceIdSb().indexOf(
                                (":").concat(ValueUtil.nullToStr(rs.getString("ADVICE_ID")))) == -1) {
                            objVoiceBean.getAdviceIdSb().append(":")
                                    .append(ValueUtil.nullToStr(rs.getString("ADVICE_ID")));
                            objVoiceBean.getAdviceNameSb().append("\n").append(
                                    ValueUtil.nullToStr(getAdviceName(rs.getString("ADVICE_ID"))));
                        }
                    } 
                    else 
                    {
                        objVoiceBean.getAdviceIdSb().append(ValueUtil.nullToStr(rs.getString("ADVICE_ID")));
                        objVoiceBean.getAdviceNameSb().append(
                                ValueUtil.nullToStr(getAdviceName(rs.getString("ADVICE_ID"))));
                    }
                }
                continue;
            }
            
            if (objVoiceBean != null) {
                lstVoiceBean.add(objVoiceBean); // 最初レコードの場合
            }
            
            objVoiceBean = new SateiomakaseVoiceBean();
            strPreEnqId = strCurrEnqId; // 置き換える
            objVoiceBean.setIndex(nIdx++);
            mapStep = parseStepParameter(rs.getString("STEP_DATA"));
            if (mapStep != null && mapStep.size() != 0) 
            {
                objVoiceBean.setNameKana1((String) mapStep.get("NAME_KANA_1"));
                objVoiceBean.setNameKana2((String) mapStep.get("NAME_KANA_2"));
                String strName1 = (String) mapStep.get("NAME_KANA_1");
                String strName2 = (String) mapStep.get("NAME_KANA_2");
                String strNickName = "t.n";
                
                if (strName1.length() > 0) {
                    strNickName = Kana2Roma.kana2roma(Kana2Roma.hanKanaToZenKana(strName1)).substring(0, 1).toLowerCase();
                }
                if (strName2.length() > 0) {
                    strNickName = strNickName + "."
                            + Kana2Roma.kana2roma(Kana2Roma.hanKanaToZenKana(strName2)).substring(0, 1).toLowerCase();
                }
                
                objVoiceBean.setNickName(strNickName);
                objVoiceBean.setAddress1((String) mapStep.get("ADDRESS_1"));
                objVoiceBean.setAddress2((String) mapStep.get("ADDRESS_2"));
                objVoiceBean.setStepLastUpadte((String) mapStep.get("STEP_LAST_UPDATE"));
                objVoiceBean.setMakeName((String) mapStep.get("MAKE_NAME"));
                objVoiceBean.setShashuName((String) mapStep.get("SHASHU_NAME"));
                objVoiceBean.setModelYear((String) mapStep.get("MODEL_YEAR"));
                objVoiceBean.setBcBase((String) mapStep.get("BC_BASE"));
            }
            
            objVoiceBean.setSexName(ValueUtil.nullToStr(rs.getString("SEX_NAME")));
            objVoiceBean.setAgeRange(ValueUtil.nullToStr(rs.getString("AGE_RANGE")));

            // 車買取業者
            mapCompany = parseStepParameter(rs.getString("COMPANY_NAME"));
            objVoiceBean.setCompanyName((String) mapCompany.get("COMPANY_NAME"));
            objVoiceBean.setCompanyNameKana((String) mapCompany.get("COMPANY_NAME_KANA"));
            objVoiceBean.setCompanyIdMtm((String) mapCompany.get("COMPANY_ID_MTM"));
            int voiceCnt = getCompanyVoiceCount((String) mapCompany.get("COMPANY_ID_MTM"));
            
            if (voiceCnt == -1) 
            {
                objVoiceBean.setComVoiceCnt(0);// 停止中の業者は表示されない
                objVoiceBean.setCompanyName(null);
                objVoiceBean.setCompanyNameKana(null);
            } 
            else 
            {
                objVoiceBean.setComVoiceCnt(voiceCnt); // 業者口コミ件数
            }
            
            objVoiceBean.setKutikomiFlg(rs.getString("KUTIKOMI_FLG"));
            objVoiceBean.setMtmShowFlg(rs.getString("MTM_SHOW_FLG"));
            objVoiceBean.setOrderId(rs.getString("ORDER_ID"));
            objVoiceBean.setEnqueteId(rs.getString("ENQUETE_ID"));

            // 決め手理由リスト　「：」で区切
            objVoiceBean.getReasonIdSb().append((":").concat(ValueUtil.nullToStr(rs.getString("REASON_ID"))));
            objVoiceBean.getReasonNameSb().append(ValueUtil.nullToStr(getReasonName(rs.getString("REASON_ID"))));

            objVoiceBean.setResponseComment(rs.getString("RESPONSE_COMMENT"));
            objVoiceBean.setSellExpName(rs.getString("SELL_EXP_NAME"));
            objVoiceBean.setAdvice(rs.getString("ADVICE_COMMENT"));
            // アドバイスリスト　「：」で区切
            objVoiceBean.getAdviceIdSb().append((":").concat(ValueUtil.nullToStr(rs.getString("ADVICE_ID"))));
            objVoiceBean.getAdviceNameSb().append(ValueUtil.nullToStr(getAdviceName(rs.getString("ADVICE_ID"))));
            // voiceBean.getAdviceNameLinkSb().append(ValueUtil.nullToStr(getAdviceNameLink(rs.getString("ADVICE_ID"))));
            objVoiceBean.setUsefulVoteNum(rs.getInt("USEFUL_VOTE_NUM"));
            objVoiceBean.setLastUpadte(rs.getString("LAST_UPDATE"));
        }

        if (objVoiceBean != null) {
            lstVoiceBean.add(objVoiceBean); // 最後レコードの場合
        }

        return lstVoiceBean;
    }

    /**
     * @param db
     * @param rs
     * @return _voiceBeanList
     * @throws SQLException
     */
    private List getCompanyList(DBAccess db, ResultSet rs) throws SQLException 
    {
        List<Map> lstCompany = new ArrayList<Map>();
        Map<String, String> mapCompany = null;
        while (db.next(rs)) 
        {
            String strKana = Kana2Roma.getKana(rs.getString("NAME_KANA"));
            if (strKana.length() == 0) {
                continue;
            }

            mapCompany = new HashMap<String, String>();
            // アンケートIDが変わる場合
            mapCompany.put("NAME_KANA", strKana);
            mapCompany.put("COMPANY_ID_MTM", rs.getString("COMPANY_ID_MTM"));
            mapCompany.put("NAME", rs.getString("NAME"));
            mapCompany.put("VOICE_CNT", rs.getString("VOICE_CNT"));
            lstCompany.add(mapCompany); // 最後レコードの場合
        }
        
        return lstCompany;
    }

    /**
     * 該当業者の口コミ件数を返す
     * 
     * @return comVoiceCnt
     */
    private int getCompanyVoiceCount(String strCompanyId)
    {
        if (strCompanyId == null || strCompanyId.length() == 0) {
            return 0;
        }
        
        List lstCompany = this.getCompanyList();
        for (int nCnt=0; nCnt<lstCompany.size(); nCnt++)
        {
            if (strCompanyId.equals(((Map) lstCompany.get(nCnt)).get("COMPANY_ID_MTM"))) {
                return ValueUtil.toint((String) ((Map) lstCompany.get(nCnt)).get("VOICE_CNT"));
            }
        }
        
        return -1;
    }

    /**
     * 新着順口コミ一覧リストを返す
     * 
     * @return voiceBeanListByDate
     */
    public List getVoiceBeanListByDate() {
        return voiceBeanListByDate;
    }

    /**
     * 参考になった件数順口コミ一覧リストを返す
     * 
     * @return voiceBeanListByVote
     */
    public List getVoiceBeanListByVote() {
        return voiceBeanListByVote;
    }

    /**
     * 決め手理由一覧リストを返す
     * 
     * @return reasonList
     */
    public List getReasonList() {
        return reasonList;
    }

    /**
     * 決め手理由名を返す
     * 
     * @return reasonName
     */
    private String getReasonName(String strReasonId) 
    {
        if (strReasonId == null || strReasonId.length() == 0) {
            return "";
        }
        
        List lstReason = this.getReasonList();
        for (int nCnt=0; nCnt<lstReason.size(); nCnt++) 
        {
            if (strReasonId.equals(((Map) lstReason.get(nCnt)).get("REASON_ID"))) {
                return "・" + ((Map) lstReason.get(nCnt)).get("NAME");
            }
        }
        
        return "";
    }

    /**
     * アドバイス一覧リストを返す
     * 
     * @return adviceList
     */
    public List getAdviceList() {
        return adviceList;
    }

    /**
     * アドバイス名を返す
     * 
     * @return adviceName
     */
    private String getAdviceName(String strAdviceId) 
    {
        if (strAdviceId == null || strAdviceId.length() == 0) {
            return "";
        }
        
        List lstAdvice = this.getAdviceList();
        for (int nCnt=0; nCnt<lstAdvice.size(); nCnt++) 
        {
            if (strAdviceId.equals(((Map) lstAdvice.get(nCnt)).get("ADVICE_ID"))) {
                return "・" + ((Map) lstAdvice.get(nCnt)).get("NAME");
            }
        }
        
        return "";
    }

    public List getCompanyList() {
        return companyList;
    }

    /**
     * Parses the struts parameter into a map of name/value pairs, so that we can put many params in
     * the one string. Delimiter is comma, and the sub-delimiter is =. So param example is:
     * name1=value1,name2=value2 etc
     */
    private Map<String, String> parseStepParameter(String strParameter) 
    {
        if (strParameter == null) {
            return new HashMap<String, String>();
        } 
        else 
        {
            StringTokenizer objStringTokenizer = new StringTokenizer(strParameter, ":", false);
            Map<String, String> mapResults = new HashMap<String, String>();
            for (int nCnt = 0; objStringTokenizer.hasMoreTokens(); nCnt++) 
            {
                String strPair = objStringTokenizer.nextToken();
                int nEqualPos = strPair.indexOf('=');
                String strName = (nEqualPos == -1 ? strPair.trim() : strPair.substring(0, nEqualPos).trim());
                String strValue = (nEqualPos == -1 ? "" : strPair.substring(nEqualPos + 1).trim());
                mapResults.put(strName, strValue);
            }
            return mapResults;
        }
    }
}
