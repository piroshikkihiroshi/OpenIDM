package jp.co.webcrew.loader.loader;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.tools.ForwardingJavaFileManager;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileManager;
import javax.tools.JavaFileObject;
import javax.tools.StandardLocation;
import javax.tools.ToolProvider;
import javax.tools.JavaCompiler.CompilationTask;
import javax.tools.JavaFileObject.Kind;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.loader.db.ClassRepositoryDb;

/**
 * コンパイルを行い、コンパイルした結果を管理するmangerクラス。
 * 
 * @author kurinami
 */
public class RepositoryManager extends ForwardingJavaFileManager<JavaFileManager> {

	/** ロガー */
	private static final Logger log = Logger.getLogger(RepositoryManager.class);

	/** このmanagerが扱うクラスのパッケージ名のprifix */
	private static final String TARGET_PACKAGE_PREFIX = "jp.co.webcrew";

	/** コンパイルを行うコンパイラクラス */
	private JavaCompiler compiler;

	/** コンパイルの基準となるクラスパスを保持するクラスローダー */
	private ClassLoader classLoader;

	/** 管理下にあるクラスを表すオブジェクト一覧 */
	private Map<String, RepositoryObject> repositoryObjects;

	/**
	 * コンストラクタ
	 * 
	 * @param classLoader
	 */
	public RepositoryManager(ClassLoader classLoader) {
		this(classLoader, ToolProvider.getSystemJavaCompiler());
	}

	/**
	 * コンストラクタ
	 * 
	 * @param classLoader
	 * @param compiler
	 */
	private RepositoryManager(ClassLoader classLoader, JavaCompiler compiler) {
		super(compiler.getStandardFileManager(null, null, null));
		this.compiler = compiler;
		this.classLoader = classLoader;
		this.repositoryObjects = new ConcurrentHashMap<String, RepositoryObject>();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seejavax.tools.ForwardingJavaFileManager#getClassLoader(javax.tools.
	 * JavaFileManager.Location)
	 */
	@Override
	public ClassLoader getClassLoader(Location location) {
		return classLoader;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.tools.ForwardingJavaFileManager#list(javax.tools.JavaFileManager
	 * .Location, java.lang.String, java.util.Set, boolean)
	 */
	@Override
	public Iterable<JavaFileObject> list(Location location, String packageName, Set<Kind> kinds, boolean recurse)
			throws IOException {

		Iterable<JavaFileObject> iterable = super.list(location, packageName, kinds, recurse);

		if (location == StandardLocation.CLASS_PATH && packageName.startsWith(TARGET_PACKAGE_PREFIX)) {
			List<JavaFileObject> list;
			try {
				list = this.getList(packageName);
			} catch (SQLException e) {
				throw new IOException(packageName, e);
			}

			if (list.size() > 0) {
				for (JavaFileObject javaFileObject : iterable) {
					list.add(javaFileObject);
				}
				iterable = list;
			}
		}

		return iterable;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seejavax.tools.ForwardingJavaFileManager#inferBinaryName(javax.tools.
	 * JavaFileManager.Location, javax.tools.JavaFileObject)
	 */
	@Override
	public String inferBinaryName(Location location, JavaFileObject file) {
		if (file instanceof RepositoryObject) {
			return ((RepositoryObject) file).getClassName();
		} else {
			return super.inferBinaryName(location, file);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.tools.ForwardingJavaFileManager#getJavaFileForInput(javax.tools
	 * .JavaFileManager.Location, java.lang.String,
	 * javax.tools.JavaFileObject.Kind)
	 */
	@Override
	public JavaFileObject getJavaFileForInput(Location location, String className, Kind kind) throws IOException {
		// TODO Auto-generated method stub
		return super.getJavaFileForInput(location, className, kind);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.tools.ForwardingJavaFileManager#getJavaFileForOutput(javax.tools
	 * .JavaFileManager.Location, java.lang.String,
	 * javax.tools.JavaFileObject.Kind, javax.tools.FileObject)
	 */
	@Override
	public JavaFileObject getJavaFileForOutput(Location location, String className, Kind kind,
			javax.tools.FileObject sibling) throws IOException {
		if (kind == Kind.CLASS) {
			return getRepositoryObject(className);
		} else {
			return super.getJavaFileForOutput(location, className, kind, sibling);
		}
	}

	/**
	 * クラスの実体をバイト配列で返す。
	 * 
	 * @param className
	 * @return
	 * @throws ClassNotFoundException
	 */
	public byte[] getClass(String className) throws ClassNotFoundException {
		RepositoryObject repositoryObject = getRepositoryObject(className);
		if (repositoryObject.getKind() == Kind.SOURCE) {
			try
			{
				compile(repositoryObject);
			}
			catch(Throwable th)
			{
				throw new ClassNotFoundException("コンパイル処理に失敗しました。詳細は内部例外orエラーを確認してください", th);
			}
		}
		try {
			return repositoryObject.toByteArray();
		} catch (IOException e) {
			throw new ClassNotFoundException(repositoryObject.getClassName(), e);
		}
	}

	/**
	 * 管理下にあるクラスを削除する。
	 * 
	 * @param classNameList
	 */
	public void removeRepositoryObjects(List<String> classNameList) {
		for (String className : classNameList) {
			repositoryObjects.remove(className);
			
			// 内部クラスも削除する。
			List<String> innerClassList = new ArrayList<String>();
			for (String tmpClassName : repositoryObjects.keySet()) {
			    if(tmpClassName.startsWith(className + "$")) {
			        innerClassList.add(tmpClassName);
			    }
			}
			for (String innerClassName : innerClassList) {
	            repositoryObjects.remove(innerClassName);
			}
		}
	}

	/**
	 * コンパイルを行う。
	 * 
	 * @param repositoryObject
	 * @return
	 * @throws ClassNotFoundException
	 */
	private void compile(RepositoryObject repositoryObject) throws ClassNotFoundException {

		log.info("========== compile start ( " + repositoryObject.getClassName() + " ).");

		// ----------
		// エラーメッセージを受け取るwriter
		StringWriter sw = new StringWriter();

		// ----------
		// コンパイルオプションを組み立てる
		StringBuffer sb = new StringBuffer();
		ClassLoader cl = this.classLoader;
		// クラスローダーを順にたどってクラスパスを抜き出す。
		// ただし、システムクラスローダーのパスはJavaFileManager自身が知っているので、それは追加しない。
		for (; cl != null && cl != ClassLoader.getSystemClassLoader(); cl = cl.getParent()) {
			log.debug(cl.getClass().getName());
			if (cl instanceof URLClassLoader) {
				for (URL url : ((URLClassLoader) cl).getURLs()) {
					sb.append(url.getPath());
					sb.append(File.pathSeparator);
					log.debug("-- " + url.getPath());
				}
				log.debug("--");
			}
		}

		List<String> options = null;
		if (sb.length() != 0) {
			options = new ArrayList<String>();
			options.add("-classpath");
			options.add(sb.toString());
		}

		// ----------
		// コンパイルするファイルを設定する。
		List<RepositoryObject> compUnits = new ArrayList<RepositoryObject>(1);
		compUnits.add(repositoryObject);

		// ----------
		// コンパイルする。
		CompilationTask task = compiler.getTask(sw, this, null, options, null, compUnits);

		if (task.call() == false) {
			throw new ClassNotFoundException(repositoryObject.getClassName() + " : コンパイルエラーが発生しました。\n" + sw.toString());
		}

		if (repositoryObject.getKind() == Kind.SOURCE) {
			repositoryObjects.remove(repositoryObject);
			throw new ClassNotFoundException(repositoryObject.getClassName() + " ：  このクラス用のDB上のレコードが存在しません。");
		}

	}

	/**
	 * クラスを表すオブジェクトを返す。
	 * 
	 * @param className
	 * @return
	 */
	private RepositoryObject getRepositoryObject(String className) {

		RepositoryObject repositoryObject = repositoryObjects.get(className);

		if (repositoryObject == null) {
			repositoryObject = new RepositoryObject(className);
			repositoryObjects.put(className, repositoryObject);
		}

		return repositoryObject;
	}

	/**
	 * クラスを表すオブジェクトの一覧を返す。
	 * 
	 * @param packageName
	 * @return
	 * @throws SQLException
	 */
	private List<JavaFileObject> getList(String packageName) throws SQLException {
		List<JavaFileObject> list = new ArrayList<JavaFileObject>();

		List<String> classNameList = ClassRepositoryDb.getClassNameList(packageName);
		for (String className : classNameList) {
			list.add(getRepositoryObject(className));
		}

		return list;
	}

}
