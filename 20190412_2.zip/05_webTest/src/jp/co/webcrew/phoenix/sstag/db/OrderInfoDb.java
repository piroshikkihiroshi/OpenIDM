package jp.co.webcrew.phoenix.sstag.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;
import jp.co.webcrew.phoenix.vtable.bean.ClmMetaMstBean;
import jp.co.webcrew.phoenix.vtable.bean.TblMetaMstBean;
import jp.co.webcrew.phoenix.vtable.db.MetaDb;

/**
 * オーダー情報を管理するdbクラス。
 * 
 * @author kurinami
 */
public class OrderInfoDb {

    /** GOID用seqno取得SQL */
    private static final String GOID_SEQNO = "select seq_goid.nextval from dual";

    /** オーダー管理テーブルに挿入するためのsql */
    private static final String INSERT_ORDER_ID_INFO = ""
            + "insert into order_id_info(goid, schema, site_id, mk_datetime) \n"
            + "                   values(?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS')) \n";

    /** オーダー情報固定テーブル用のテーブルメタ情報マスタの情報を取得するためのsql */
    private static final String SELECT_ORDER_TBL_META_MST = ""
            + "select * from (schema_name).tbl_meta_mst where tbl_schema = ? and tbl_type = '3' ";

    /**
     * 新しいgoidを発行して返す。
     * 
     * @param siteId
     * @return
     * @throws SQLException
     */
    public static String getGoid(int siteId) throws SQLException {

        // サイトのテーマスキーマ名を取得する。
        String schema = SiteMstDb.getInstance().getSchema(siteId);
        if (PhoenixUtil.isEmpty(schema)) {
            throw new SQLException("サイトID(" + siteId + ")からスキーマ名を取得することができませんでした。");
        }

        DBAccess dbAccess = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            // goidを発行
            String goid = Long.toString(dbAccess.getSequenceNo(GOID_SEQNO));

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // 固定テーブルにデータを挿入する。
            dbAccess.prepareStatement(INSERT_ORDER_ID_INFO);

            dbAccess.setString(1, goid);
            dbAccess.setString(2, schema);
            dbAccess.setInt(3, siteId);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

            return goid;

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * オーダー情報を返す。
     * 
     * @param siteId
     * @param tblSchema
     * @param guid
     * @param descFlag
     * @param offset
     * @return
     * @throws SQLException
     */
    public static Map<String, ClmDataBean> getOrderInfo(int siteId, String tblSchema, String guid, boolean descFlag,
            int offset) throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            // スキーマをもとに、オーダー情報固定テーブルのテーブルメタ情報とカラムメタ情報を取得する。
            TblMetaMstBean tblMetaMst = getOrderTblMetaMst(dbAccess, tblSchema);
            List<ClmMetaMstBean> clmMetaMstList = MetaDb.getClmMetaMstList(dbAccess, tblMetaMst.getSiteId(), tblMetaMst
                    .getTblId());

            return getOrderInfo(dbAccess, tblMetaMst, clmMetaMstList, guid, descFlag, offset);

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * オーダー情報を返す。
     * 
     * @param siteId
     * @param tblSchema
     * @param guid
     * @param goid
     * @return
     * @throws SQLException
     */
    public static Map<String, ClmDataBean> getOrderInfo(int siteId, String tblSchema, String guid, String goid)
            throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            // スキーマをもとに、オーダー情報固定テーブルのテーブルメタ情報とカラムメタ情報を取得する。
            TblMetaMstBean tblMetaMst = getOrderTblMetaMst(dbAccess, tblSchema);
            List<ClmMetaMstBean> clmMetaMstList = MetaDb.getClmMetaMstList(dbAccess, tblMetaMst.getSiteId(), tblMetaMst
                    .getTblId());

            return getOrderInfo(dbAccess, tblMetaMst, clmMetaMstList, guid, goid);

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * オーダー情報を返す。
     * 
     * @param dbAccess
     * @param tblMetaMst
     * @param clmMetaMstList
     * @param guid
     * @param goid
     * @return
     * @throws SQLException
     */
    private static Map<String, ClmDataBean> getOrderInfo(DBAccess dbAccess, TblMetaMstBean tblMetaMst,
            List<ClmMetaMstBean> clmMetaMstList, String guid, String goid) throws SQLException {

        ClmMetaMstBean guidClmMetaMst = findClmMetaMst(clmMetaMstList, Constants.CLM_TYPE_GUID);
        ClmMetaMstBean goidClmMetaMst = findClmMetaMst(clmMetaMstList, Constants.CLM_TYPE_GOID);

        ResultSet rs = null;
        try {

            String sql = MessageFormat.format("select * from {0}.{1} where {2} = ? and {3} = ? ", tblMetaMst
                    .getTblSchema(), tblMetaMst.getTblName(), guidClmMetaMst.getClmId(), goidClmMetaMst.getClmId());

            // オーダー情報固定テーブルからオーダー情報を取得する。
            dbAccess.prepareStatement(sql);
            dbAccess.setString(1, guid);
            dbAccess.setString(2, goid);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {

                Map<String, ClmDataBean> record = new HashMap<String, ClmDataBean>();

                for (ClmMetaMstBean clmMetaMst : clmMetaMstList) {
                    ClmDataBean clmData = new ClmDataBean();
                    clmData.setRecId(0l);
                    clmData.setData(ValueUtil.nullToStr(rs.getString(clmMetaMst.getClmId())));
                    clmData.setMeta(clmMetaMst);
                    record.put(clmMetaMst.getClmId(), clmData);
                }

                return record;
            } else {
                throw new SQLException("オーダー情報が存在しません。[tbl_schema:" + tblMetaMst.getTblSchema() + "][tbl_name:"
                        + tblMetaMst.getTblName() + "][guid:" + guid + "][goid:" + goid + "]");
            }

        } finally {
            DBAccess.close(rs);
        }
    }

    /**
     * オーダー情報を返す。
     * 
     * @param dbAccess
     * @param tblMetaMst
     * @param clmMetaMstList
     * @param guid
     * @param descFlag
     * @param offset
     * @return
     * @throws SQLException
     */
    private static Map<String, ClmDataBean> getOrderInfo(DBAccess dbAccess, TblMetaMstBean tblMetaMst,
            List<ClmMetaMstBean> clmMetaMstList, String guid, boolean descFlag, int offset) throws SQLException {

        ClmMetaMstBean guidClmMetaMst = findClmMetaMst(clmMetaMstList, Constants.CLM_TYPE_GUID);
        ClmMetaMstBean goidClmMetaMst = findClmMetaMst(clmMetaMstList, Constants.CLM_TYPE_GOID);

        ResultSet rs = null;
        try {

            String sql = MessageFormat.format("select * from {0}.{1} where {2} = ? order by {3} {4}", tblMetaMst
                    .getTblSchema(), tblMetaMst.getTblName(), guidClmMetaMst.getClmId(), goidClmMetaMst.getClmId(),
                    (descFlag ? "desc" : ""));

            // オーダー情報固定テーブルからオーダー情報を取得する。
            dbAccess.prepareStatement(sql);
            dbAccess.setString(1, guid);
            rs = dbAccess.executeQuery();
            int i = 1;
            while (dbAccess.next(rs)) {
                if (i >= offset) {
                    Map<String, ClmDataBean> record = new HashMap<String, ClmDataBean>();

                    for (ClmMetaMstBean clmMetaMst : clmMetaMstList) {
                        ClmDataBean clmData = new ClmDataBean();
                        clmData.setRecId(0l);
                        clmData.setData(ValueUtil.nullToStr(rs.getString(clmMetaMst.getClmId())));
                        clmData.setMeta(clmMetaMst);
                        record.put(clmMetaMst.getClmId(), clmData);
                    }

                    return record;
                }
                i++;
            }
            throw new SQLException("オーダー情報が存在しません。[tbl_schema:" + tblMetaMst.getTblSchema() + "][tbl_name:"
                    + tblMetaMst.getTblName() + "][guid:" + guid + "][desc_flag:" + (descFlag ? "true" : "false")
                    + "][offset:" + offset + "]");

        } finally {
            DBAccess.close(rs);
        }
    }

    /**
     * オーダー情報固定テーブル用のテーブルメタ情報マスタの情報を取得する。
     * 
     * @param dbAccess
     * @param tblSchema
     * @return
     * @throws SQLException
     */
    private static TblMetaMstBean getOrderTblMetaMst(DBAccess dbAccess, String tblSchema) throws SQLException {

        ResultSet rs = null;
        try {

            // オーダー情報固定テーブル用のテーブルメタ情報マスタの情報を取得する。
            dbAccess.prepareStatement(SELECT_ORDER_TBL_META_MST);
            dbAccess.setString(1, tblSchema);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                TblMetaMstBean tblMetaMst = new TblMetaMstBean();
                tblMetaMst.setSiteId(rs.getInt("site_id"));
                tblMetaMst.setTblId(ValueUtil.nullToStr(rs.getString("tbl_id")));
                tblMetaMst.setTblType(ValueUtil.nullToStr(rs.getString("tbl_type")));
                tblMetaMst.setTblSchema(ValueUtil.nullToStr(rs.getString("tbl_schema")));
                tblMetaMst.setTblName(ValueUtil.nullToStr(rs.getString("tbl_name")));
                tblMetaMst.setName(ValueUtil.nullToStr(rs.getString("name")));
                tblMetaMst.setDescription(ValueUtil.nullToStr(rs.getString("description")));
                // TODO kurinami 【確認】 アクセスレベルどうしよう。。。
                return tblMetaMst;
            } else {
                throw new SQLException("テーブルが存在しません。[tbl_schema:" + tblSchema + "]");
            }

        } finally {
            DBAccess.close(rs);
        }

    }

    /**
     * 指定された項目タイプのカラムメタ情報を一覧から探す。
     * 
     * @param clmMetaMstList
     * @param type
     * @return
     */
    private static ClmMetaMstBean findClmMetaMst(List<ClmMetaMstBean> clmMetaMstList, String type) {
        for (ClmMetaMstBean clmMetaMst : clmMetaMstList) {
            if (clmMetaMst.getType().equals(type)) {
                return clmMetaMst;
            }
        }
        return null;
    }

}
