package jp.co.webcrew.dbaccess.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * プロパティファイルを管理するためのutilクラス。
 *
 * @author kurinami
 */
public class PropertiesUtil {

    /** ロガー */
//    private static final Logger log = Logger.getLogger(PropertiesUtil.class);
    private static final Logger log = null;

    /** 内部保持しているプロパティ群 */
    private static Map propertiesHolder = new HashMap();

    /** プロパティ値を保持する */
    private Properties props = new Properties();

    public PropertiesUtil(String filename) {
        load(filename);
    }

    /**
     * プロパティ値を読み込む。
     *
     * @throws IOException
     */
    private void load(String filename) {
        InputStream is = null;
        try {
            is = this.getClass().getClassLoader().getResourceAsStream(filename);
//            is = new FileInputStream("D:/pleiades/workspace/05_webTest/WebContent/WEB-INF/db.properties"); //なんか取れないから直接指定
            props.clear();
            props.load(is);
        } catch (IOException e) {
            log.error("プロパティファイル[" + filename + "]読み込み中に、予期せぬエラーが発生しました。", e);
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e1) {
                    log.error("ファイルのクローズに失敗しました。", e1);
                }
            }
        }
    }

    /**
     * プロパティ値を返す。
     *
     * @param key
     * @return
     */
    public String getProperty(String key) {
        return props.getProperty(key);
    }

    /**
     * プロパティの配列値を返す。
     *
     * @param key
     * @return
     */
    public String[] getPropertyArray(String key) {
        String value = getProperty(key);
        return value != null ? value.split(",") : new String[0];
    }

    /**
     * 配列型のプロパティ値の指定indexの値を返す。
     *
     * @param key
     * @param index
     * @return
     */
    public String getProperty(String key, int index) {
        String[] array = getPropertyArray(key);
        if(index >= 0 && index < array.length) {
            return array[index];
        } else {
            return "";
        }
    }

    /**
     * プロパティ値にパラメータを当てて返す。
     *
     * @param key
     * @param params
     * @return
     */
    public String getProperty(String key, Object[] params) {
        String property = getProperty(key);
        MessageFormat mf = new MessageFormat(property);
        return mf.format(params);
    }

    /**
     * 指定されたファイルのPropertiesUtilを返す。
     *
     * @param filename
     * @return
     */
    public static PropertiesUtil getPropertiesUtil(String filename) {
        PropertiesUtil propertiesUtil = (PropertiesUtil) propertiesHolder
                .get(filename);

        if (propertiesUtil == null) {
            propertiesUtil = new PropertiesUtil(filename);
            propertiesHolder.put(filename, propertiesUtil);
        }

        return propertiesUtil;
    }
}