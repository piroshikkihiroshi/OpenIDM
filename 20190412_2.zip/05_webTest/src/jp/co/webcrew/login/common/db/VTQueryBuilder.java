package jp.co.webcrew.login.common.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.step.FireBangUserInfo;
import jp.co.webcrew.login.common.util.DateUtil;

import static jp.co.webcrew.login.common.db.VTQueryResultSet.*;

public class VTQueryBuilder implements Cloneable
{
	private static final Logger logger=Logger.getLogger(VTQueryBuilder.class);


	static final String SQL_TPL="select rec_id from {0}.clm_data C " +
	" where C.site_id={1} and C.tbl_id={2} and C.clm_id={3} and {4}" ;


	static final String SQL_TPL_2="{0} ({1}) TBL_{2} {3}" ;
	
	/*
	static final String SQL_TPL_2="{0} (select rec_id from {1}.clm_data C " +
	" where C.site_id={2} and C.tbl_id={3} and C.clm_id={4} and {5}) TBL_{6} {7}" ;
	*/

	static final String ON_TPL=" ON TBL_{0}.rec_id=TBL_{1}.rec_id ";
	
	static final String TPL_START_DEF=" SELECT TBL_0.rec_id FROM ";
	
    private StringBuilder sqlBuff;
    
    
    /****
     * 設定済みの条件式の位置を定義
     * 
     * 0の場合、条件式の冒頭にINNER JOIN句を付さない
     * 0以外の場合、条件式の冒頭にINNER JOIN句を付す。
     * 
     * 
     */
    protected int sqlCurrentIndex;
    //private boolean applyCondition=false;
    private int siteId=-1;
    private String tableId=null;
    private String schemaName=null;
    private List<Map<String,String>> dataSet=null;
    
    private Comparator<Map<String,String>> sortObject=null;
    
    

    /*
    private String andOr="AND";
    
    private void setCondAndOr(String andOr)
    {
    	this.andOr=" " + this.andOr + " ";
    }
    
    private String getCondAndOr()
    {
    	return this.andOr;
    }
    */
    /****
     * 
     * 
     */
    public VTQueryBuilder(String schemaName,String sqlExpression)
    {
    	this.setSchemaName(schemaName);
    	this.initSQL(sqlExpression);
    }
    
    public VTQueryBuilder(String schemaName,int siteId,String tableId)
    {
    	this.setSchemaName(schemaName);
    	this.setSiteId(siteId);
    	this.setTableId(tableId);
    	this.initSQL(TPL_START_DEF);
    }
    
    public VTQueryBuilder(int siteId,String tableId)
    {
    	this.setSchemaName("(schema_name)");
    	this.setSiteId(siteId);
    	this.setTableId(tableId);
    	this.initSQL(TPL_START_DEF);
    }
    
    private VTQueryBuilder()
    {
    }
    
    public void initSQL(String sql)
    {
    	this.sqlBuff=new StringBuilder(sql);
    	this.sqlCurrentIndex=-1;
    	//this.applyCondition=false;
    }
    
    public void clearSQL()
    {
    	sqlBuff=new StringBuilder();
    	this.sqlCurrentIndex=-1;
    	//this.applyCondition=false;
    }
    
    public void setSchemaName(String schemaName)
    {
    	this.schemaName=schemaName;
    }
    
    public String getSchemaName()
    {
    	return this.schemaName;
    }
    
    public String getSQL()
    {
    	return this.sqlBuff.toString();
    }
    
    
    public void setSiteId(int siteId)
    {
    	this.siteId=siteId;
    }
    
    public int getSiteId()
    {
    	return this.siteId;
    }

    public void setTableId(String tableId)
    {
    	this.tableId=tableId;
    }
    
    public String getTableId()
    {
    	return this.tableId;
    }
    
    public void setDataSet(List<Map<String,String>> dataSet)
    {
    	this.dataSet=dataSet;
    }
    
    public List<Map<String,String>> getDataSet()
    {
    	return this.dataSet;
    }
    
    
    private String addCondInternal(String sql)
    {
		this.sqlCurrentIndex++;
		String param0="",paramLast="";
		if(this.sqlCurrentIndex!=0)
		{
			param0="INNER JOIN ";
			paramLast=MessageFormat.format(ON_TPL, this.sqlCurrentIndex-1,(this.sqlCurrentIndex));
		}
		String retSql=MessageFormat.format
		(
				SQL_TPL_2
				//{0}
				,param0
				//{1}
				,sql
				//{2}
				, String.valueOf(this.sqlCurrentIndex)
				//{3}
				,paramLast
		);
		this.sqlBuff.append(retSql);
		return retSql;

    }
    
    /****
     * 生成済みのSQL文をUNIONALL形式で結合する
     * 
     * 
     * @param sqls
     * @return
     */
    public String addCondSentenceOr(String... sqls)
    {
		StringBuilder sqlBld=new StringBuilder("(");
		int pos=-1;
		for(String aSql:sqls)
		{
			pos++;
			if(pos!=0)
			{
				sqlBld.append(" UNION ALL ");
			}
			sqlBld.append(aSql);
		}
		
		sqlBld.append(")");
    	return addCondInternal(sqlBld.toString());

    }
    
	/**
	 * 検索条件式を追加する
	 * 一致検索を行う
	 * 
	 * @param clmId カラムID
	 * @param value 値
	 * @return
	 */
	public String addCondEQ(String clmId,String value)
	{
		String sql=addCond(clmId, "=",value);
		return sql;
	}

	/***
	 * 検索条件式を追加する
	 * 第二引数に指定した演算子に沿った検索を行う
	 * 
	 * @param clmId カラムID
	 * @param operator 演算子
	 * @param value 検索条件値
	 * @return
	 */
	public String addCond(String clmId,String operator,String value)
	{
		String sql=this.buildCond(clmId, operator, value);
		return addCondInternal(sql);
	}
	
	/***
	 * 検索条件式を生成する
	 * 一致検索を行う
	 * 
	 * @param clmId カラムID
	 * @param operator 演算子
	 * @param value 検索条件値
	 * @return
	 */
	public String buildCond(String clmId,String operator,String value)
	{
		
		String sql=MessageFormat.format
		(
				SQL_TPL
				//{0}
				,this.getSchemaName()
				//{1}
				, String.valueOf(this.getSiteId())
				//{2}
				,toSQLString(this.getTableId())
				//{3}
				,toSQLString(clmId)
				//{4}
				,"C.key_data "+operator+toSQLString(value)
		);
		return sql;
	}


	/***
	 * 検索条件式を生成する
	 * 
	 * @param clmId
	 * @param notIn NOT_IN検索の場合、true／IN検索の場合、falseを指定する
	 * @param values
	 * @return
	 */
	public String buildCondAny(String clmId,boolean notIn,String... values)
	{
		String paramIn;
		if(notIn)
		{
			paramIn=" NOT IN (";
		}
		else
		{
			paramIn=" IN (";
		}
		
		StringBuilder sb=new StringBuilder();
		for(String aVal:values)
		{
			sb.append(toSQLString(aVal)+",");
		}
		
		String paramVal=sb.substring(0,sb.length()-1);
		
		
		String sql=MessageFormat.format
		(
				SQL_TPL
				//{1}
				,this.getSchemaName()
				//{2}
				, String.valueOf(this.getSiteId())
				//{3}
				,toSQLString(this.getTableId())
				//{4}
				,toSQLString(clmId)
				//{5}
				,"C.key_data "+paramIn+paramVal+")"
		);
		return sql;
	}
	
	public String addCondAny(String clmId,boolean notIn,String... values)
	{
		String sql=this.buildCondAny(clmId, notIn, values);
		return addCondInternal(sql);
	}

	public String addCondAny(String clmId,String... values)
	{
		String sql=this.buildCondAny(clmId, false, values);
		return addCondInternal(sql);
	}

	
	
	/***
	 * 検索条件を追加する
	 * 
	 * @param clmId
	 * @param operator
	 * @param value
	 * @return
	 */
	public String buildCondNumber(String clmId,String operator,String value)
	{
		String sql=MessageFormat.format
		(
				SQL_TPL
				//{0}
				,this.getSchemaName()
				//{1}
				, String.valueOf(this.getSiteId())
				//{2}
				,toSQLString(this.getTableId())
				//{3}
				,toSQLString(clmId)
				//{4}
				,"to_number(C.key_data) "+operator+toSQLString(value)
		);
		return sql;
	}
	
	/***
	 * 検索条件を追加する
	 * 
	 * @param clmId
	 * @param operator
	 * @param value
	 * @return
	 */
	public String addCondNumber(String clmId,String operator,String value)
	{
		String sql=this.buildCondNumber(clmId, operator, value);
		return this.addCondInternal(sql);
	}

	
	/***
	 * 検索式を追加する
	 * 
	 * @param clmId
	 * @param notIn
	 * @param values
	 * @return
	 */
	public String buildCondMulti(String clmId,boolean notIn,String... values)
	{

		StringBuilder bldRegex=new StringBuilder("(");
		int i=-1;
		for(String aval:values)
		{
			i++;
			if(i!=0)
			{
				if(!notIn)
				{
					bldRegex.append(" OR ");
				}
				else
				{
					bldRegex.append(" AND ");
				}
			}
			if(notIn)
			{
				bldRegex.append(" NOT ");
			}
			bldRegex.append("REGEXP_LIKE(C.KEY_DATA,");
			bldRegex.append(toSQLString("^"+aval+"$"));
			bldRegex.append(",'m')");
		}
		bldRegex.append(")");
		
		
		String sql=MessageFormat.format
		(
				SQL_TPL
				//{0}
				,this.getSchemaName()
				//{1}
				, String.valueOf(this.getSiteId())
				//{2}
				,toSQLString(this.getTableId())
				//{3}
				,toSQLString(clmId)
				//{4}
				,bldRegex.toString() //substring(0, bldRegex.length()+")"
		);
		
		return sql;
		
	}

	/***
	 * 検索式を追加する
	 * 
	 * @param clmId
	 * @param notIn
	 * @param values
	 * @return
	 */
	public String addCondMulti(String clmId,boolean notIn,String... values)
	{
		String sql=this.buildCondMulti(clmId, notIn, values);
		return this.addCondInternal(sql);
	}
	
	public String addCondMulti(String clmId,String... values)
	{
		return addCondMulti(clmId,false ,values);
	}
	
	

	/***
	 * SQL文字列を生成する
	 * シングルクォートのエスケープを行ったあと、
	 * 前後にシングルクォートの付与を行う。
	 * 
	 * @param sources
	 * @return
	 */
	private static String toSQLString(String... sources)
	{
		StringBuilder sqlToken=new StringBuilder();
		int i=-1;
		for(String aSrc:sources)
		{
			i++;
			sqlToken.append("'"+aSrc.replaceAll("'", "''")+"',");
		}
		return sqlToken.substring(0,sqlToken.length()-1);
	}
	
	
	private static final int QUERY_MODE_ENV_DEPEND=0;
	private static final int QUERY_MODE_PUBLIC_ONLY=1;
	private static final int QUERY_MODE_PUBLIC_IGNORE=2;

	/***
	 * データ取得を行う
	 * 
	 * @param dbAccess
	 * @return
	 * @throws SQLException
	 */
	public VTQueryResultSet findByRecID(DBAccess dbAccess,long[] recIDs)
	throws SQLException
	{
		
		return this.findByRecIDInternal(dbAccess,QUERY_MODE_ENV_DEPEND,false,recIDs);
	}
	
	/****
	 * 公開フラグがＯＮかつ公開期間内のデータのみ取得する
	 * 
	 * @param dbAccess
	 * @return
	 * @throws SQLException
	 */
	public VTQueryResultSet findByRecIDPublicIgnore(DBAccess dbAccess,long[] recIDs)
	throws SQLException
	{
		return this.findByRecIDInternal(dbAccess, QUERY_MODE_PUBLIC_IGNORE,false,recIDs);
	}
	
	/***
	 * 公開フラグのチェックを一切行わない
	 * 
	 * @param dbAccess
	 * @return
	 * @throws SQLException
	 */
	public VTQueryResultSet findByRecIDPublicOnly(DBAccess dbAccess,long[] recIDs)
	throws SQLException
	{
		return this.findByRecIDInternal(dbAccess, QUERY_MODE_PUBLIC_ONLY,false,recIDs);
	}

	
	/***
	 * データ取得を行う
	 * 
	 * @param dbAccess
	 * @return
	 * @throws SQLException
	 */
	public VTQueryResultSet executeQuery(DBAccess dbAccess)
	throws SQLException
	{
		
		return this.executeQueryInternal(dbAccess,QUERY_MODE_ENV_DEPEND,false);
	}
	
	/****
	 * 公開フラグがＯＮかつ公開期間内のデータのみ取得する
	 * 
	 * @param dbAccess
	 * @return
	 * @throws SQLException
	 */
	public VTQueryResultSet executeQueryPublicIgnore(DBAccess dbAccess)
	throws SQLException
	{
		return this.executeQueryInternal(dbAccess, QUERY_MODE_PUBLIC_IGNORE,false);
	}
	
	/***
	 * 公開フラグのチェックを一切行わない
	 * 
	 * @param dbAccess
	 * @return
	 * @throws SQLException
	 */
	public VTQueryResultSet executeQueryPublicOnly(DBAccess dbAccess)
	throws SQLException
	{
		return this.executeQueryInternal(dbAccess, QUERY_MODE_PUBLIC_ONLY,false);
	}
	
	/***
	 * クエリー、ソート処理を行う
	 * 
	 * @param dbAccess
	 * @param queryMode
	 * @return
	 * @throws SQLException
	 */
	protected VTQueryResultSet findByRecIDInternal(DBAccess dbAccess,int queryMode,boolean force,long[] recIDs)
	throws SQLException
	{
		
		ResultSet rset=null;
		
		String tblId=this.getTableId();
		int siteId=this.getSiteId();
		
		if(force && this.getDataSet()!=null)
		{
			return new VTQueryResultSet(siteId, tblId, this.getDataSet());
		}
		
		
		boolean publicOnly=true;
		
		switch(queryMode)
		{
		case QUERY_MODE_ENV_DEPEND:
			publicOnly=true;
			/*
			//TODO フェニックス外への移植時に問題になりそう。
			if(LogicUtil.isProductionEnv())
			{
				publicOnly=true;
			}
			else
			{
				publicOnly=false;
			}
			*/
			break;
		case QUERY_MODE_PUBLIC_ONLY:
			publicOnly=true;
			break;
		case QUERY_MODE_PUBLIC_IGNORE:
			publicOnly=false;
			break;
		}
		
		
		final String SQL_REC_META_PUBONLY=
		" SELECT * FROM {0}.rec_meta_data \n" +
		" WHERE site_id=? AND tbl_id=? {1} AND pub_flag=1 \n" +
		" AND bgn_datetime <= to_char(sysdate,''YYYYMMDDHH24MISS'') " +
		" AND end_datetime >=to_char(sysdate,''YYYYMMDDHH24MISS'') ";

		final String SQL_REC_META=
			" SELECT * FROM {0}.rec_meta_data \n" +
			" WHERE site_id=? AND tbl_id=? {1} ";

		
		StringBuilder buffRecID=new StringBuilder();
		
		for(long recID:recIDs)
		{
			buffRecID.append(String.valueOf(recID)+",");
		}
		
		String sqlRecID;
		
		if(publicOnly)
		{
			sqlRecID=MessageFormat.format(SQL_REC_META_PUBONLY, this.getSchemaName()," AND rec_id in("+buffRecID.substring(0,buffRecID.length()-1)+")");
		}
		else
		{
			sqlRecID=MessageFormat.format(SQL_REC_META, this.getSchemaName()," AND rec_id in("+buffRecID.substring(0,buffRecID.length()-1)+")");
		}
		logger.debug("[SQL_1]"+sqlRecID);
		logger.debug("[SQL_2]"+this.getSQL());
		
		
		List<Long> listRecID2=new ArrayList<Long>();
		List<Map<String,String>> dataSet=new ArrayList<Map<String,String>>();
		
		this.setRecMetaDataListToDataSet(dbAccess, sqlRecID, listRecID2, dataSet);
		this.setClmDataListToDataSet(dbAccess, listRecID2, dataSet);
		if(this.getSortObject()!=null)
		{
			Collections.sort(dataSet,this.getSortObject());
		}
		return new VTQueryResultSet(this.getSiteId(), this.getTableId(), dataSet);
	}

	
	
	/***
	 * クエリー、ソート処理を行う
	 * 
	 * @param dbAccess
	 * @param queryMode
	 * @return
	 * @throws SQLException
	 */
	protected VTQueryResultSet executeQueryInternal(DBAccess dbAccess,int queryMode,boolean force)
	throws SQLException
	{
		
		ResultSet rset=null;
		
		String tblId=this.getTableId();
		int siteId=this.getSiteId();
		
		if(force && this.getDataSet()!=null)
		{
			return new VTQueryResultSet(siteId, tblId, this.getDataSet());
		}
		
		
		String sqlRecID=this.getSQL();
		
		
		boolean publicOnly=true;
		
		
		switch(queryMode)
		{
		case QUERY_MODE_ENV_DEPEND:
			//フェニックスではpropファイルを見れないので
			publicOnly=true;
			break;
		case QUERY_MODE_PUBLIC_ONLY:
			publicOnly=true;
			break;
		case QUERY_MODE_PUBLIC_IGNORE:
			publicOnly=false;
			break;
		}
		
		
		final String SQL_REC_META_PUBONLY=
		" SELECT * FROM {0}.rec_meta_data \n" +
		" WHERE site_id=? AND tbl_id=? {1} AND pub_flag=1 \n" +
		" AND bgn_datetime <= to_char(sysdate,''YYYYMMDDHH24MISS'') " +
		" AND end_datetime >=to_char(sysdate,''YYYYMMDDHH24MISS'') ";

		final String SQL_REC_META=
			" SELECT * FROM {0}.rec_meta_data \n" +
			" WHERE site_id=? AND tbl_id=? {1} ";

		
		if(publicOnly)
		{
			if(!sqlRecID.equals(TPL_START_DEF))
			{
				sqlRecID=MessageFormat.format(SQL_REC_META_PUBONLY, this.getSchemaName()," AND rec_id in("+sqlRecID+")");
					/*
				sqlRecID=MessageFormat.format(
						"SELECT rec_id,pub_flag,bgn_datetime,end_datetime FROM {0}.rec_meta_data \n" +
						" WHERE site_id=? AND tbl_id=? AND rec_id in({1}) AND pub_flag=1 \n" +
						" AND bgn_datetime <= to_char(sysdate,''YYYYMMDDHH24MISS'') " +
						" AND end_datetime >=to_char(sysdate,''YYYYMMDDHH24MISS'') ",this.getSchemaName(),sqlRecID);
						*/
			}
			else
			{
				sqlRecID=MessageFormat.format(SQL_REC_META_PUBONLY, this.getSchemaName(),"");
				/*
				sqlRecID=MessageFormat.format(
						"SELECT rec_id,pub_flag,bgn_datetime,end_datetime FROM {0}.rec_meta_data \n" +
						" WHERE site_id=? AND tbl_id=?  ",this.getSchemaName());
						*/
			}
		}
		else
		{
			if(!sqlRecID.equals(TPL_START_DEF))
			{
				sqlRecID=MessageFormat.format(SQL_REC_META, this.getSchemaName()," AND rec_id in("+sqlRecID+")");
				/*
				sqlRecID=MessageFormat.format("SELECT rec_id FROM {0}.rec_meta_data \n" +
						" WHERE site_id=? AND tbl_id=? AND rec_id in({1})",this.getSchemaName(),sqlRecID);
						*/
			}
			else
			{
				sqlRecID=MessageFormat.format(SQL_REC_META, this.getSchemaName(),"");
				/*
				sqlRecID=MessageFormat.format("SELECT rec_id FROM {0}.rec_meta_data \n" +
						" WHERE site_id=? AND tbl_id=? ",this.getSchemaName());
						*/
			}
		}
		logger.debug("[SQL_1]"+sqlRecID);
		logger.debug("[SQL_2]"+this.getSQL());
		
		String currentDateTime=DateUtil.currentDateTime();
		
		
		//クエリー１：該当データのrecidを取得する
		List<Long> listRecID2=new ArrayList<Long>();
		List<Map<String,String>> dataSet=new ArrayList<Map<String,String>>();
		
		this.setRecMetaDataListToDataSet(dbAccess, sqlRecID, listRecID2, dataSet);
		this.setClmDataListToDataSet(dbAccess, listRecID2, dataSet);
		/*
		try
		{
			//TODO fordebug
			System.out.println("対象のrecid取得だけを行うsql:"+sqlRecID);
			
			dbAccess.prepareStatement(sqlRecID);
			dbAccess.setInt(1, siteId);
			dbAccess.setString(2, tblId);
			rset=dbAccess.executeQuery();
			
			while(rset.next())
			{
				Map<String,String> rowData=new HashMap<String, String>();
				rowData.put(ROWDATA_KEY_REC_ID,rset.getString("rec_id"));
				rowData.put(ROWDATA_KEY_BGN_DATETIME,ValueUtil.nullToStr(rset.getString("bgn_datetime")));
				rowData.put(ROWDATA_KEY_END_DATETIME,ValueUtil.nullToStr(rset.getString("end_datetime")));
				rowData.put(ROWDATA_KEY_PUBLIC_FLAG,ValueUtil.nullToStr(rset.getString("pub_flag")));
				rowData.put(ROWDATA_KEY_UP_ADMIN,ValueUtil.nullToStr(rset.getString("up_admin")));
				rowData.put(ROWDATA_KEY_UP_DATETIME,ValueUtil.nullToStr(rset.getString("up_datetime")));
				listRecID2.add(rset.getLong("rec_id"));
				
				dataSet.add(rowData);
			}
		}
		finally
		{
			DBAccess.close(rset);
		}
		
		//logger.info("[list]"+isProductionEnv+"/"+listRecID2.toString());
		
		//クエリー２：該当データのrecidを取得する
		String sqlQuery=MessageFormat.format(
				"SELECT clm_id,key_data,lob_data FROM {0}.clm_data WHERE site_id=? AND tbl_id=? AND rec_id=? "
				,this.getSchemaName());
		
		
		dbAccess.prepareStatement(sqlQuery);
		dbAccess.setInt(1, siteId);
		dbAccess.setString(2, tblId);
		//List<Map<String,String>> dataSet=new ArrayList<Map<String,String>>();
		
		int len=listRecID2.size();
		
		logger.info("[データ取得件数]"+len);
		
		for(int i=0;i<len;i++)
		{
			
			long aRecId=listRecID2.get(i);
			Map<String,String> recordMap=dataSet.get(i);
			
			dbAccess.setLong(3, aRecId);
			//ResultSet rset=null;
			//recordMap.put(MAP_KEY_REC_ID, String.valueOf(aRecId));
			try
			{
		
				
				rset=dbAccess.executeQuery();
				while(rset.next())
				{
					String clmId=rset.getString("clm_id");
					String value;
					value=rset.getString("lob_data");
					//value=rset.getString("key_data");
					if(value==null || value.length()==0)
					{
						value=rset.getString("key_data");
						//value=rset.getString("lob_data");
						if(value==null)
						{
							value="";
						}
					}
					recordMap.put(clmId, value);
				}
			}
			finally
			{
				DBAccess.close(rset);
			}
		}
		*/
		if(this.getSortObject()!=null)
		{
			Collections.sort(dataSet,this.getSortObject());
		}
		return new VTQueryResultSet(this.getSiteId(), this.getTableId(), dataSet);
	}
	
	/****
	 * 第二、第三引数のリストの内容を設定する。
	 * 第二引数にはrec_id
	 * 第三引数にはrec_meta_dataから取得した値
	 * を設定する
	 * 
	 * @param dbAccess
	 * @param sqlRecID
	 * @param listRecIDRet
	 * @param dataSet
	 * @throws SQLException
	 */
	private void setRecMetaDataListToDataSet(DBAccess dbAccess,String sqlRecID
			,List<Long> listRecIDRet,List<Map<String,String>> dataSet)
	throws SQLException
	{
		//クエリー１：該当データのrecidを取得する
		
		ResultSet rset=null;
		try
		{
			//TODO fordebug
			//System.out.println("対象のrecid取得だけを行うsql:"+sqlRecID);
			
			dbAccess.prepareStatement(sqlRecID);
			dbAccess.setInt(1, this.getSiteId());
			dbAccess.setString(2, this.getTableId());
			rset=dbAccess.executeQuery();
			
			while(rset.next())
			{
				Map<String,String> rowData=new HashMap<String, String>();
				rowData.put(ROWDATA_KEY_REC_ID,rset.getString("rec_id"));
				rowData.put(ROWDATA_KEY_BGN_DATETIME,ValueUtil.nullToStr(rset.getString("bgn_datetime")));
				rowData.put(ROWDATA_KEY_END_DATETIME,ValueUtil.nullToStr(rset.getString("end_datetime")));
				rowData.put(ROWDATA_KEY_PUBLIC_FLAG,ValueUtil.nullToStr(rset.getString("pub_flag")));
				rowData.put(ROWDATA_KEY_UP_ADMIN,ValueUtil.nullToStr(rset.getString("up_admin")));
				rowData.put(ROWDATA_KEY_UP_DATETIME,ValueUtil.nullToStr(rset.getString("up_datetime")));
				listRecIDRet.add(rset.getLong("rec_id"));
				
				dataSet.add(rowData);
			}
		}
		finally
		{
			DBAccess.close(rset);
		}

	}
	
	/****
	 * clm_meta_dataの内容を第三引数に設定する
	 * 
	 * 
	 * @param dbAccess
	 * @param listRecID
	 * @param dataSet
	 * @throws SQLException
	 */
	private void setClmDataListToDataSet(DBAccess dbAccess,List<Long> listRecID,List<Map<String,String>> dataSet)
	throws SQLException
	{
		//クエリー２：該当データのrecidを取得する
		String sqlQuery=MessageFormat.format(
				"SELECT clm_id,key_data,lob_data FROM {0}.clm_data WHERE site_id=? AND tbl_id=? AND rec_id=? "
				,this.getSchemaName());
		
		
		dbAccess.prepareStatement(sqlQuery);
		dbAccess.setInt(1, this.getSiteId());
		dbAccess.setString(2, this.getTableId());

		int len=listRecID.size();
		
		logger.info("[データ取得件数]"+len);
		
		for(int i=0;i<len;i++)
		{
			
			long aRecId=listRecID.get(i);
			Map<String,String> recordMap=dataSet.get(i);
			
			recordMap.get(ROWDATA_KEY_REC_ID);

			
			dbAccess.setLong(3, aRecId);
			ResultSet rset=null;
			//recordMap.put(MAP_KEY_REC_ID, String.valueOf(aRecId));
			try
			{
		
				
				rset=dbAccess.executeQuery();
				while(rset.next())
				{
					String clmId=rset.getString("clm_id");
					String value;
					value=rset.getString("lob_data");
					//value=rset.getString("key_data");
					if(value==null || value.length()==0)
					{
						value=rset.getString("key_data");
						//value=rset.getString("lob_data");
						if(value==null)
						{
							value="";
						}
					}
					recordMap.put(clmId, value);
				}
			}
			finally
			{
				DBAccess.close(rset);
			}
		}

		
	}
	
	
	/***
	 * 自オブジェクトの複製を作成する
	 * 
	 * @return
	 */
	public VTQueryBuilder createCopy()
	{
		
		VTQueryBuilder vqb=new VTQueryBuilder();
		vqb.schemaName=this.getSchemaName();
		vqb.sqlCurrentIndex=this.sqlCurrentIndex;
		vqb.siteId=this.getSiteId();
		vqb.tableId=this.getTableId();
		vqb.sortObject=this.getSortObject();
		vqb.sqlBuff=new StringBuilder(this.sqlBuff.toString());
		return vqb;
	}
	
	@Override
	protected Object clone() //throws CloneNotSupportedException 
	{
		return this.createCopy();
	}
	
	
	/***
	 * 自オブジェクトと引数に渡したオブジェクトの検索条件をマージ(UNION ALL)した
	 * オブジェクトを生成し、返す。
	 * 
	 * @param originals
	 * @return
	 */
	public VTQueryBuilder createMerge(VTQueryBuilder... originals)
	{
		
		
		VTQueryBuilder vqb=this.createCopy();
		
		StringBuilder sqlBuff=new StringBuilder();
		
		int loop=originals.length;
		sqlBuff.append("(");
		sqlBuff.append(this.getSQL());
		sqlBuff.append(")\n");
		for(int i=0;i<loop;i++)
		{
			sqlBuff.append(" UNION ALL ");
			sqlBuff.append("(");
			sqlBuff.append(originals[i].getSQL());
			sqlBuff.append(")\n");
		}
		
		vqb.sqlBuff=new StringBuilder(sqlBuff.toString());
		return vqb;
		
	}
	
    /****
     * 検索結果に適用するソート条件を定義するオブジェクトを登録する
     * 
     * @param sortObject
     */
    public void setSortObject(Comparator<Map<String,String>> sortObject)
    {
    	this.sortObject=sortObject;
    }
    
    
    public Comparator<Map<String,String>> getSortObject()
    {
    	return this.sortObject;
    }
    
	
}
