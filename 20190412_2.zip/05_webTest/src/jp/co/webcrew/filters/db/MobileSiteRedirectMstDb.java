package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

public class MobileSiteRedirectMstDb extends RefreshMstDb{
	
	/** モバイルサイトリダイレクトマスタ情報取得用SQL */
	private static final String MOBILE_SITE_REDIRECT_MST_SELECT = "select * from common.mobile_site_redirect_mst";

	/** 唯一のインスタンス */
	private static MobileSiteRedirectMstDb mobileSiteRedirectMstDb = new MobileSiteRedirectMstDb();

	/** 変換キーワードの一覧
	 *  KEY:request_url, VALUE:key->ua_type,value->redirect_urlのMap
	 */
	private Map mobileSiteRedirectMap = null;

	/**
	 * 生成不能コンストラクタ
	 */
	private MobileSiteRedirectMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static MobileSiteRedirectMstDb getInstance() {
		return mobileSiteRedirectMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {
		DBAccess dbAccess = null;
		ResultSet rs = null;
		
		try {
			dbAccess = new DBAccess();
			 
			mobileSiteRedirectMap = new HashMap();
			
			// サイトリダイレクト一覧を検索する。
			dbAccess.prepareStatement(MOBILE_SITE_REDIRECT_MST_SELECT);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				String requestUrl = ValueUtil.nullToStr(rs.getString("request_url"));
				String type = rs.getString("ua_type");
				String redirect_url = rs.getString("redirect_url");
				
				HashMap redirectMap = null;
				
				if(mobileSiteRedirectMap.containsKey(requestUrl)){
					redirectMap = (HashMap)mobileSiteRedirectMap.get(requestUrl);
					redirectMap.put(type, redirect_url);
				} else {
					redirectMap = new HashMap();
					redirectMap.put(type, redirect_url);
					mobileSiteRedirectMap.put(requestUrl, redirectMap);
				}
			}
		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}
	
	/**
	 * リクエストURLに関連付くリダイレクトマップを返す
	 * 
	 * @param requestUrl リクエストURL
	 * @return リダイレクトマップ
	 */
	public Map getRedirectUrlMap(String requestUrl) {
		Object object = mobileSiteRedirectMap.get(requestUrl);
		
		if(object != null) {
			return (Map)object;
		} else {
			return null;
		}
	}
}
