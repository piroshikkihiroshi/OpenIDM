package jp.co.webcrew.login.common.db.util;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;

public class TableInfo {
	private static Logger log = Logger.getLogger(TableInfo.class);
	
	private String _schema = "";

	private String _tableName = "";
	
	/** プライマリキー */
	private List _pkColumns = new ArrayList();

	/** その他の列 */
	private List _columns = new ArrayList();

	/** 列の型 */
	private Map _types = new Record();

	/** 列の大きさ */
	private Map _info = new Record();
	
	/** コンストラクタ */
	private TableInfo(){	}

	/** スキーマを指定するコンストラクタ */
	public TableInfo(String schema,String table){
		_schema = schema;
		_tableName = table;
	}

	/** スキーマを指定しないコンストラクタ */
	public TableInfo(String table){
		_tableName = table;
	}

	public List getPkColumns() {
		return _pkColumns;
	}

	public List getColumns() {
		return _columns;
	}

	public Map getTypes() {
		return _types;
	}

	public Map getColumnInfoHolder() {
		return _info;
	}

	public String getTableName() {
		return _tableName;
	}

	public String getFullTableName() {
		return DBInfo.getFullTableName(_schema, _tableName);
	}

//	public String getSchema() {
//		return _schema;
//	}
	
//	public void setSchema(String val){
//		_schema = val;
//	}

	public void setTableName(String val){
		_tableName = val;
	}
	
	public void addPK (String columnName) {
		getPkColumns().add(columnName);
	}

	public void addColumn (String columnName) {
		getColumns().add(columnName);
	}

	public void readColumnInfoFromDB() {

		DBAccess db = null;
		ResultSet rs = null;
		try{
			db = new DBAccess();
			db.prepareStatement(makeSelectSql());
			rs = db.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				String colName = rsmd.getColumnName(i);
				int colSize = rsmd.getPrecision(i);
				int colScale = rsmd.getScale(i);
				int colType = rsmd.getColumnType(i);
//				if (log.isDebugEnabled()){
//					log.debug("colName=" + colName);
//					log.debug(" colSize=" + colSize);
//					log.debug(" colScale=" + colScale);
//					log.debug(" colType=" + colType);
//				}
				
				getColumnInfoHolder().put(colName, new ColumnInfo(colName,colSize,colScale,colType));
			}

		} catch (Exception e){
			log.error("データベース読み込みに失敗しました。");
			log.info("table=" + getTableName());
		} finally {
			DBAccess.close(rs);
			DBAccess.close(db);
		}
		
	}
	
	public String makeSelectSql(){
		StringBuffer buf = new StringBuffer();
		buf.append("select * from ");
		buf.append(getFullTableName());
		return buf.toString();
	}	


}
