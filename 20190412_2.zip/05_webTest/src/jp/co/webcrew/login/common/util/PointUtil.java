/**
 * 
 */
package jp.co.webcrew.login.common.util;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.login.common.db.util.Record;

/**
 * ポイント関連のユーティリティクラス
 * @author Takahashi
 *
 */
public class PointUtil {

	/** ロガー */
	private static final Logger log = Logger.getLogger(PointUtil.class);

    /*
     * コンストラクタ非公開
     */
	private PointUtil() {}

    /**
     * <pre>
     * 指定した期間内に取得した仮ポイント数合計を取得する。
     * 
     * 期間開始日時から期間終了日時までの期間に取得した有効ポイントのうち、
     * POINT_CHARGE_HIST.BGN_DATETIME が期間終了日時よりも未来のポイントを合計する。
     * 
     * </pre>
     * @param guid              guid    
     * @param startDatetime     期間開始日時 nullの場合は1900年0月0日として扱う
     * @param endDatetime       期間終了日時 nullの場合は2999年99月99日として扱う
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTemporaryPoint( long guid , String startDatetime , String endDatetime) throws SQLException , RuntimeException {
        return getTemporaryPoint(String.valueOf(guid) , startDatetime , endDatetime);
    }

    /**
     * <pre>
     * 指定した期間内に取得した仮ポイント数合計を取得する。
     * 
     * 期間開始日時から期間終了日時までの期間に取得した有効ポイントのうち、
     * POINT_CHARGE_HIST.BGN_DATETIME が期間終了日時よりも未来のポイントを合計する。
     * 
     * </pre>
     * @param guid              guid    
     * @param startDatetime     期間開始日時 nullの場合は1900年0月0日として扱う
     * @param endDatetime       期間終了日時 nullの場合は2999年99月99日として扱う
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTemporaryPoint( String guid , String startDatetime , String endDatetime) throws SQLException , RuntimeException {
        if (! SessionFilterAlterUtil.isValidGuid(guid)) {
            throw new IllegalArgumentException("guidが不正です。guid=" + guid);
        }

        if (startDatetime == null && endDatetime == null) {
            throw new RuntimeException("引数エラー：開始日時と終了日時の両方にnullが指定されました。");
        }
        
        if (startDatetime == null || startDatetime.equals("")) {
            startDatetime = "19000000000000";
        }

        if (endDatetime == null || endDatetime.equals("")) {
            endDatetime = "29999999999999";
        }

        if (startDatetime.length() != 14) {
            throw new IllegalArgumentException("startDateTimeが14桁になっていません。startDt=" + startDatetime);
        }

        if (endDatetime.length() != 14) {
            throw new IllegalArgumentException("endDateTimeが14桁になっていません。endDt=" + endDatetime);
        }

        DBAccess db = null;
        
        try {
            db = new DBAccess();
            
            String sql = "SELECT SUM(NVL( POINT , 0)) AS CHARGE_TOTAL "
                +  " FROM "
                +  "  POINT_CHARGE_HIST "
                +  " WHERE "
                +  "  GUID=? "
                +  " AND "
                +  "  INVALID_FLAG <> '1' "
                +  " AND "
                +  "  BGN_DATETIME > ? "
                +  " AND "
                +  "  MK_DATETIME BETWEEN ? AND ? ";
            
            db.prepareStatement(sql);
            db.setString(1, guid);
            db.setString(2, endDatetime);
            db.setString(3, startDatetime);
            db.setString(4, endDatetime);
            
            Record rec = Record.getFirstRowOf(db);
            if (rec != null) {
                return rec.getLong("CHARGE_TOTAL");
            } else {
                log.warn("ポイントチャージ合計値を取得できませんでした。guid=" + guid);
                throw new RuntimeException("ポイントチャージ合計値を取得できませんでした。");
            }
        } catch (RuntimeException e) {
        
            throw e;

        } finally {       
            DBAccess.close(db);
        }        
    }

    /**
     * <pre>
     * 指定した日時時点での仮ポイント数合計を取得する。
     * </pre>
     * @param guid              guid    
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTemporaryPoint( String guid , String dateTime) throws SQLException , RuntimeException {
        if (! SessionFilterAlterUtil.isValidGuid(String.valueOf(guid))) {
            throw new IllegalArgumentException("guidが不正です。guid=" + guid);
        }

        if (dateTime == null) {
            throw new IllegalArgumentException("日付指定が不正です。dateTime=" + dateTime);
        }

        if (dateTime.length() != 14) {
            throw new IllegalArgumentException("dateTimeが14桁になっていません。dateTime=" + dateTime);
        }
        
        return getTemporaryPoint(guid , null , dateTime);

    }
    
    /**
     * <pre>
     * 指定した日時時点での仮ポイント数合計を取得する。
     * </pre>
     * @param guid              guid    
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTemporaryPoint( long guid , String dateTime) throws SQLException , RuntimeException {
        return getTemporaryPoint(String.valueOf(guid) , dateTime);
    }

    /**
     * <pre>
     * 現在の仮ポイント数合計を取得する。
     * </pre>
     * @param guid              guid    
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTemporaryPoint( long guid ) throws SQLException , RuntimeException {
        return getTemporaryPoint(guid, DateUtil.currentDateTime());
    }

    /**
     * <pre>
     * 現在の仮ポイント数合計を取得する。
     * </pre>
     * @param guid              guid    
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTemporaryPoint( String guid ) throws SQLException , RuntimeException {
        return getTemporaryPoint(guid, DateUtil.currentDateTime());
    }
    
    /**
     * <pre>
     * 指定した日時時点での所持ポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getCurPoint( long guid , String dateTime ) throws SQLException , RuntimeException {
        return getTotalChargePoint(guid, dateTime) - getTotalSpendPoint(guid, dateTime) ; 
    }

    /**
     * <pre>
     * 指定した日時時点での所持ポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getCurPoint( String guid , String dateTime ) throws SQLException , RuntimeException {
        return getTotalChargePoint(guid, dateTime) - getTotalSpendPoint(guid, dateTime) ; 
    }
    
    /**
     * <pre>
     * 現在の所持ポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getCurPoint( long guid ) throws SQLException , RuntimeException {
        return getTotalChargePoint(guid) - getTotalSpendPoint(guid) ; 
    }

    /**
     * <pre>
     * 現在の所持ポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getCurPoint( String guid ) throws SQLException , RuntimeException {
        return getTotalChargePoint(guid) - getTotalSpendPoint(guid) ; 
    }
    
    /**
     * <pre>
     * 指定した期間中に消費されたポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param startDatetime     期間開始日時 nullの場合は1900年0月0日として扱う
     * @param endDatetime       期間終了日時 nullの場合は2999年99月99日として扱う
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalSpendPoint (long guid , String startDatetime , String endDatetime ) throws SQLException , RuntimeException {
        return getTotalSpendPoint(String.valueOf(guid) , startDatetime , endDatetime);
    }

    /**
     * <pre>
     * 指定した期間中に消費されたポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param startDatetime     期間開始日時 nullの場合は1900年0月0日として扱う
     * @param endDatetime       期間終了日時 nullの場合は2999年99月99日として扱う
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalSpendPoint (String guid , String startDatetime , String endDatetime ) throws SQLException , RuntimeException {
        if (! SessionFilterAlterUtil.isValidGuid(guid)) {
            throw new IllegalArgumentException("guidが不正です。guid=" + guid);
        }

        if (startDatetime == null && endDatetime == null) {
            throw new RuntimeException("引数エラー：開始日時と終了日時の両方にnullが指定されました。");
        }
        
        if (startDatetime == null || startDatetime.equals("")) {
            startDatetime = "19000000000000";
        }

        if (endDatetime == null || endDatetime.equals("")) {
            endDatetime = "29999999999999";
        }
        
        DBAccess db = null;
        
        try {
            db = new DBAccess();
            
            String sql = "SELECT SUM(NVL( POINT , 0)) AS SPEND_TOTAL "
                +  " FROM "
                +  "  POINT_SPEND_HIST "
                +  " WHERE "
                +  "  GUID=? "
                +  " AND "
                +  "  INVALID_FLAG <> '1' "
                +  " AND "
                +  "  MK_DATETIME BETWEEN ? AND ? ";
            
            db.prepareStatement(sql);
            db.setString(1, guid);
            db.setString(2, startDatetime);
            db.setString(3, endDatetime);
            
            Record rec = Record.getFirstRowOf(db);
            if (rec != null) {
                return rec.getLong("SPEND_TOTAL");
            } else {
                log.warn("ポイント消費合計値を取得できませんでした。guid=" + guid);
                throw new RuntimeException("ポイント消費合計値を取得できませんでした。");
            }
        } catch (RuntimeException e) {
        
            throw e;

        } finally {       
            DBAccess.close(db);
        }
    }
    
    /**
     * <pre>
     * 指定した日時までの消費ポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalSpendPoint (long guid , String dateTime ) throws SQLException , RuntimeException {
        if (! SessionFilterAlterUtil.isValidGuid(String.valueOf(guid))) {
            throw new IllegalArgumentException("guidが不正です。guid=" + guid);
        }

        if (dateTime == null) {
            throw new IllegalArgumentException("日付指定が不正です。dateTime=" + dateTime);
        }
        
        if (dateTime.length() != 14) {
            throw new IllegalArgumentException("dateTimeが14桁になっていません。dateTime=" + dateTime);
        }
        
        return getTotalSpendPoint(guid, null , dateTime);
    }

    /**
     * <pre>
     * 指定した日時までの消費ポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalSpendPoint (String guid , String dateTime ) throws SQLException , RuntimeException {
        if (! SessionFilterAlterUtil.isValidGuid(guid)) {
            throw new IllegalArgumentException("guidが不正です。guid=" + guid);
        }

        if (dateTime == null) {
            throw new IllegalArgumentException("日付指定が不正です。dateTime=" + dateTime);
        }
        
        if (dateTime.length() != 14) {
            throw new IllegalArgumentException("dateTimeが14桁になっていません。dateTime=" + dateTime);
        }
        
        return getTotalSpendPoint(guid, null , dateTime);
    }
    
    
    /**
     * <pre>
     * 現在までの消費ポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalSpendPoint (long guid) throws SQLException , RuntimeException {
        return getTotalSpendPoint(guid, DateUtil.currentDateTime());
    }

    /**
     * <pre>
     * 現在までの消費ポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalSpendPoint (String guid) throws SQLException , RuntimeException {
        return getTotalSpendPoint(guid, DateUtil.currentDateTime());
    }
    
    /**
     * <pre>
     * 現在までのチャージポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalChargePoint (long guid) throws SQLException , RuntimeException {
        return getTotalChargePoint(guid, DateUtil.currentDateTime());
    }

    /**
     * <pre>
     * 現在までのチャージポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalChargePoint (String guid) throws SQLException , RuntimeException {
        return getTotalChargePoint(guid, DateUtil.currentDateTime());
    }

    /**
     * <pre>
     * 指定した期間内のチャージポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param startDatetime     期間開始日時 nullの場合は1900年0月0日として扱う
     * @param endDatetime       期間終了日時 nullの場合は2999年99月99日として扱う
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalChargePoint (long guid , String startDatetime , String endDatetime ) throws SQLException , RuntimeException {

        return getTotalChargePoint(String.valueOf(guid) , startDatetime , endDatetime);
    }

    /**
     * <pre>
     * 指定した期間内のチャージポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param startDatetime     期間開始日時 nullの場合は1900年0月0日として扱う
     * @param endDatetime       期間終了日時 nullの場合は2999年99月99日として扱う
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalChargePoint (String guid , String startDatetime , String endDatetime ) throws SQLException , RuntimeException {

        if (! SessionFilterAlterUtil.isValidGuid(guid)) {
            throw new IllegalArgumentException("guidが不正です。guid=" + guid);
        }

        if (startDatetime == null && endDatetime == null) {
            throw new RuntimeException("引数エラー：開始日時と終了日時の両方にnullが指定されました。");
        }
        
        if (startDatetime == null || startDatetime.equals("")) {
            startDatetime = "19000000000000";
        }

        if (endDatetime == null || endDatetime.equals("")) {
            endDatetime = "29999999999999";
        }
        
        DBAccess db = null;
        
        try {
            db = new DBAccess();
            
            String sql = "SELECT SUM(NVL( POINT , 0)) AS CHARGE_TOTAL "
                +  " FROM "
                +  "  POINT_CHARGE_HIST "
                +  " WHERE "
                +  "  GUID=? "
                +  " AND "
                +  "  INVALID_FLAG <> '1' "
                +  " AND "
                +  "  ((BGN_DATETIME IS NULL AND MK_DATETIME BETWEEN ? AND ? ) OR (BGN_DATETIME BETWEEN ? AND ?)) ";
            
            db.prepareStatement(sql);
            db.setString(1, guid);
            db.setString(2, startDatetime);
            db.setString(3, endDatetime);
            db.setString(4, startDatetime);
            db.setString(5, endDatetime);
            
            Record rec = Record.getFirstRowOf(db);
            if (rec != null) {
                return rec.getLong("CHARGE_TOTAL");
            } else {
                log.warn("ポイントチャージ合計値を取得できませんでした。guid=" + guid);
                throw new RuntimeException("ポイントチャージ合計値を取得できませんでした。");
            }
        } catch (RuntimeException e) {
        
            throw e;

        } finally {       
            DBAccess.close(db);
        }
    }
    
    /**
     * <pre>
     * 指定した日時までのチャージポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalChargePoint (long guid , String dateTime ) throws SQLException , RuntimeException {

        if (! SessionFilterAlterUtil.isValidGuid(String.valueOf(guid))) {
            throw new IllegalArgumentException("guidが不正です。guid=" + guid);
        }

        if (dateTime == null) {
            throw new IllegalArgumentException("日付指定が不正です。dateTime=" + dateTime);
        }

        if (dateTime.length() != 14) {
            throw new IllegalArgumentException("dateTimeが14桁になっていません。dateTime=" + dateTime);
        }
        
        return getTotalChargePoint(guid, null, dateTime);
        
   }

    /**
     * <pre>
     * 指定した日時までのチャージポイント数合計を取得する。
     * </pre>
     * @param guid              guid
     * @param dateTime          指定日時
     * @throws SQLException     データベースエラーが発生したとき
     * @throws RuntimeException 実行時例外エラーが発生したとき
     */
    public static long getTotalChargePoint (String guid , String dateTime ) throws SQLException , RuntimeException {

        if (! SessionFilterAlterUtil.isValidGuid(guid)) {
            throw new IllegalArgumentException("guidが不正です。guid=" + guid);
        }

        if (dateTime == null) {
            throw new IllegalArgumentException("日付指定が不正です。dateTime=" + dateTime);
        }

        if (dateTime.length() != 14) {
            throw new IllegalArgumentException("dateTimeが14桁になっていません。dateTime=" + dateTime);
        }
        
        return getTotalChargePoint(guid, null, dateTime);
        
   }
    
}