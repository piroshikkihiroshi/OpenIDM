package jp.co.webcrew.login.common.util;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.SiteSession;

/**
 * <pre>
 * filter を使わないようにするための代替えクラス。
 * 
 * 実装はSessionFilterUtil に合わせて同時に変更すること。
 * 
 * </pre>
 * @author miyake
 */
public class SessionFilterAlterUtil {

    private static final Logger log = Logger.getLogger(SessionFilterAlterUtil.class);
    
    
    /*
     * 注意：定数は jp.co.webcrew.filters.util.SessionFilterUtil でも
     * 同様のものが定義されているため、更新する場合は双方を更新すること。
     * 
     */
    
    // ----- request オブジェクト内の各値格納用キー名
    public static final String GUID_ATTR_KEY       = "faon.guid";
    public static final String GSID_ATTR_KEY       = "faon.gsid";
    public static final String SSID_ATTR_KEY       = "faon.ssid";
    public static final String SITE_ID_ATTR_KEY    = "faon.site_id";
//    public static final String MEMBER_MST          = "faon.member_mst.";
//    public static final String LOGIN_FLAG_ATTR_KEY = "faon.login_flag";

    /** 属性名：ログイン済みフラグ */
    public static final String LOGIN_FLAG_ATTR_KEY = "faon.login_flag";
    
    /** サイトセッションプロパティ用の中間prefix */
    public static final String SS_PROPS_ATTR_KEY   = "faon.ss_props.";

    /** 端末情報を格納するキー */
    public static final String SITE_MST_CARRIER_ATTR_KEY = "faon.term_mst.carrier";
    
    /** 端末タイプ「PC」を表す定数 */
    public static final String TYPE_PC_BROWSER    ="pc";

    /**
     * SSIDを返す。
     * 
     * @param request
     * @return
     */
    public static String getSsid(HttpServletRequest request) {
        return ValueUtil.nullToStr( request.getAttribute(SessionFilterAlterUtil.SSID_ATTR_KEY) );
    }

    /**
     * GSIDを返す。
     * 
     * @param request
     * @return
     */
    public static String getGsid(HttpServletRequest request) {
        return ValueUtil.nullToStr(request.getAttribute(SessionFilterAlterUtil.GSID_ATTR_KEY));
    }

    /**
     * GUIDを返す。
     * 
     * @param request
     * @return
     */
    public static String getGuid(HttpServletRequest request) {
        return ValueUtil.nullToStr(request.getAttribute(SessionFilterAlterUtil.GUID_ATTR_KEY));
    }

//    /**
//     * メンバマスタの値を返す。
//     * 
//     * @param request
//     * @param columnName
//     * @return
//     */
//    public static String getMemberMst(HttpServletRequest request, String columnName) {
//        return ValueUtil.nullToStr(
//           request.getAttribute( SessionFilterAlterUtil.MEMBER_MST + columnName)
//        );
//    }

    /**
     * guidが妥当か否かを調べる
     * 
     * @param guid
     * @return
     */
    public static boolean isValidGuid( String guid ) {
        if (guid == null || guid.equals("") || guid.equals("0") || guid.equals("-1")) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * サイトセッション属性を設定する。
     * 
     * @param request
     * @param name
     * @param value
     * @throws SQLException
     */
    public static void setSiteSessionProps(HttpServletRequest request, String name, String value) 
       throws SQLException 
    {
        String gsid   = getGsid(request);
        if (! isValidGsid(gsid)) {
            log.info("gsidが無効です。gsid=" + gsid);
            return ;
        }
        
        DBAccess db = null;
        try {
            db = new DBAccess();
            SiteSession siteSession = new SiteSession(db , gsid);
            String siteId = getSiteId(request);

            siteSession.writePropertyToDB(name, value, siteId);
            request.setAttribute(SS_PROPS_ATTR_KEY + name, value);
        
        } finally {
            DBAccess.close(db);
        }
        
    }

    /**
     * サイトセッション属性を削除する。
     * 
     * @param request
     * @param name
     * @throws SQLException
     */
    public static void removeSiteSessionProps(HttpServletRequest request, String name) 
       throws SQLException 
    {
        String gsid   = getGsid(request);
        if (! isValidGsid(gsid)) {
            log.info("gsidが無効です。gsid=" + gsid);
            return ;
        }
        
        DBAccess db = null;
        try {
            db = new DBAccess();
            SiteSession siteSession = new SiteSession(db , gsid);
            siteSession.removeProperty(name);
            request.removeAttribute(SS_PROPS_ATTR_KEY + name);
        } finally {
            DBAccess.close(db);
        }
    }



    
    /**
     * 携帯からのアクセスかを返す。
     * 
     * @param request
     * @return true 携帯からのアクセスである
     * @return false 携帯からのアクセスでない
     */
    public static boolean fromMobile(HttpServletRequest request) {
    
        String testMobile = SystemPropertiesDb.getInstance().get("TEST_MOBILE");
        if (ValueUtil.nullToStr(testMobile).equals("1")) {
            log.info("システムプロパティのテスト設定により、強制的に携帯端末からのアクセスと見なします。");
            return true;
        }

        // フィルタからuseragentを元に判定する
        String carrier = (String) request
                .getAttribute(SITE_MST_CARRIER_ATTR_KEY);
        if (carrier == null) {
            log.info("端末情報が見つかりませんでした。");
            return false;
        }

        if (carrier.equals(TYPE_PC_BROWSER)) {
            log.info("PC端末からのアクセスが認識されました。");
            return false;
        } else {
            log.info("携帯端末からのアクセスが認識されました。");
            return true;
        }

    }

    /**
     * gsidが妥当か否かを調べる
     * 
     * @param gsid
     * @return
     */
    public static boolean isValidGsid(String gsid) {
        if (gsid == null || gsid.equals("") || gsid.equals("0")
                || gsid.equals("-1")) {
            return false;
        } else {
            return true;
        }
    }
    
   
    /**
     * GSIDを返す。
     * 
     * @param request
     * @return
     */
    public static String getSiteId(HttpServletRequest request) {
        return ValueUtil.nullToStr(request.getAttribute(SessionFilterAlterUtil.SITE_ID_ATTR_KEY));
    }
    
    /**
     * ログイン済みであるかを返す。
     * 
     * @param request
     * @return
     */
    public static boolean isLoggedIn(HttpServletRequest request) {
        String flg = getLoginFlag(request);
        if (flg.equals("t")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * ログインフラグを返す。
     * 
     * @param request
     * @return
     */
    public static String getLoginFlag(HttpServletRequest request) {
        return ValueUtil.nullToStr(request
                .getAttribute(LOGIN_FLAG_ATTR_KEY));
    }
}
