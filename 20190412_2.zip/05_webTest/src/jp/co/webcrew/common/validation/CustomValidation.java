package jp.co.webcrew.common.validation;

import java.util.Map;

import generator.runtime.db.DBConnectionWrapper;
import generator.runtime.exception.ApplicationException;

/**
 * A rather inefficient way of allowing custom validation classes to be 
 * presented nicely in the stepengine's syntax
 */
public class CustomValidation extends ValidationCheck {
    
    private Map configParameters;
    private ValidationCheck vc;
    
    public void init(Map configParameters) {
        if (configParameters != null) {
            this.configParameters.putAll(configParameters);
        }
        super.init(configParameters);
    }
    
    public ValidationFailure validate(Object value, DBConnectionWrapper dbConn) {
        String className = getConfigParameter("class");
        if (className == null) {
            throw new ApplicationException("Custom validation has class parameter null");
        } else {
            if (this.vc == null) {
                try {
                    Class cls = Class.forName(className);
                    this.vc = (ValidationCheck) cls.newInstance();
                    this.vc.setFieldName(getFieldName());
                    this.vc.init(configParameters);
                } catch (ClassNotFoundException err) {
                    throw new ApplicationException("Error inside custom exception", err);
                } catch (InstantiationException err) {
                    throw new ApplicationException("Error inside custom exception", err);
                } catch (IllegalAccessException err) {
                    throw new ApplicationException("Error inside custom exception", err);
                }
            }

            return this.vc.validate(value, dbConn);
        }
    }

}
