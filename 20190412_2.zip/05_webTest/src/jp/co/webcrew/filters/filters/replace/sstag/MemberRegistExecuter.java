package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.DBUtil;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.StepDb;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.login.common.LoginUtil;
import jp.co.webcrew.login.common.LogoutUtil;
import jp.co.webcrew.login.common.TempRegistResult;
import jp.co.webcrew.login.common.TempRegistUtil;
import jp.co.webcrew.login.common.db.MagSubscribe;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.SiteCrossCampaign;
import jp.co.webcrew.login.common.db.step.StepUserInfo;
import jp.co.webcrew.login.common.db.step.StepUserInfoFactory;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.MelmagaUtil;

/**
 * ユーザ登録を行うsstag
 * 
 * @author kurinami
 */
public class MemberRegistExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(MemberRegistExecuter.class);

	/** 広告種別：テキスト */
	
	/**
	パスワードの置き換え変数は標準では、「$$this.password$$」だが、
	フェニックス上ではこのsstagが実行される前に置換処理が働いてしまう。
	上記事象を回避するために、パスワードの置き換え変数はフェニックス的に以下のように置き換えた
	*/
	private static final String PASSWORD_PARAM_KEY = "%{this.password}";
	
	/** インプレッションログ出力用スレッド */
	private static MemberRegistThread memberRegistThread;

	static {
		// ユーザ登録用スレッドを開始する。
		memberRegistThread = new MemberRegistThread();
		memberRegistThread.start();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameters, HttpServletRequest request,
			HttpServletResponse response) {

		try {

			// --------------------------------------------------------------------------------
			// 会員新規登録用連携テーブルの該当レコードを削除。
			// (現時点で不要な情報であるが、ごみが残らないように無条件で削除。)
			StepDb.deleteCoordinateRegist(SessionFilterUtil.getGuid(request));

			// --------------------------------------------------------------------------------
			// sstagのパラメータを取得する。
			String siteId = ValueUtil.nullToStr(parameters.get("site_id"));
			String orderId = ValueUtil.nullToStr((String) parameters
					.get("order_id"));
			String userId = ValueUtil.nullToStr((String) parameters
					.get("user_id"));
			String email = ValueUtil.nullToStr(parameters.get("email"));
			int emailType = ValueUtil.toint((String) parameters
					.get("email_type"));
			String password = ValueUtil.nullToStr(parameters.get("password"));
			String nickname = ValueUtil.nullToStr(parameters.get("nickname"));
			String gender = ValueUtil.nullToStr(parameters.get("gender"));
			String birthday = ValueUtil.nullToStr(parameters.get("birthday"));
			String unregisterdHtml = ValueUtil.nullToStr(parameters
					.get("unregisterd_html"));
			String temporizedHtml = ValueUtil.nullToStr(parameters
					.get("temporized_html"));
			String formaledHtml = ValueUtil.nullToStr(parameters
					.get("formaled_html"));
			String loginedHtml = ValueUtil.nullToStr(parameters
					.get("logined_html"));
			String magFlag = ValueUtil.nullToStr(parameters.get("mag_flag"));
			boolean mobileSiteFlag = ValueUtil.nullToStr(
					parameters.get("mobile_site_flag")).equals("1");
			String campaignId = ValueUtil.nullToStr(parameters.get("campaign_id"));
			
			// Issue0030155 キャンペーンよりパラメータauth_key追加
			String authKey = ValueUtil.nullToStr(parameters.get("auth_key"));

			// --------------------------------------------------------------------------------
			// sstagのパラメータをチェックする。

			// サイトIDがパラメータで指定されなかった場合は、filterで保持するサイトIDを使用する。
			if (siteId.length() == 0) {
				siteId = (String) request
						.getAttribute(UserInfo.SITE_ID_ATTR_KEY);
			}

			// emailが指定されていない場合、
			if (email.length() == 0) {
				// パラメータエラーとする
				log.error("パラメータエラー パラメータ[email]が指定されていません。");
				return "";
			}

			// キャンペーン応募管理テーブルへの記録
            // キャンペーン期間中の判断
            if (authKey.length() != 0 && isCampaignPeriod(campaignId)) {
                if (ValueUtil.nullToStr(siteId).length() != 0 && orderId.length() != 0) {
                    log.info("キャンペーン登録処理を開始する。[orderId:" + orderId + "]");
                    // テーブルへ記録
                    insertSiteCrossCampaign(authKey, orderId, siteId, email, SessionFilterUtil.getGuid(request), campaignId);
                } else {
                    // パラメータエラーとする
                    log.error("キャンペーン応募管理テーブルへの記録時パラメータ [siteId]または[orderId]が指定されていません。\n");
                }
            }

			// メルマガフラグ、悪質ユーザフラグを取得  ※ステップ側nullを渡される場合"null"文字列になっているため取ります
			String strAnnounceFlag = ValueUtil.nullToStr(parameters.get("announce_mail"));
			String strCategoryFlag = ValueUtil.nullToStr(parameters.get("category_mail"));
			String strZubatFlag    = ValueUtil.nullToStr(parameters.get("zubat_mail"));
			String strMaturity_mail    = ValueUtil.nullToStr(parameters.get("maturity_mail"));
			String strBadUser = ValueUtil.nullToStr(parameters.get("bad_user"));
			String strOmiMemberRegist = ValueUtil.nullToStr(parameters.get("omit_member_regist")); // 公式化サイトのメルマガ対応、
			log.info("パミション更新。[AnnounceFlag:" + strAnnounceFlag + "][CategoryFlag:" + strCategoryFlag + "][ZubatFlag:"
					+ strZubatFlag + "]" + "][MaturityFlag(満期日お知らせ):" + strMaturity_mail + "][BadUser:" + strBadUser + "]" + "][OmiMemberRegist:" + strOmiMemberRegist + "]");

			// 公式化サイトのメルマガ対応、
			if ("1".equals(strOmiMemberRegist)) {
				if ("0".equals(strBadUser)) {
					updateMailPermission(strAnnounceFlag, strCategoryFlag, strZubatFlag, strMaturity_mail, email, siteId, orderId,
							userId, SessionFilterUtil.getGuid(request));
				}
				return ""; // 会員登録処理しない、空文字を返します
			}
			
			if (!SessionFilterUtil.isLogined(request)) {
				// ログインしていない場合、

				// 登録処理を行う。
				log.info("登録処理を開始する。[email:" + email + "]");
				return regist(request, response, siteId, orderId, userId,
						email, emailType, password, nickname, gender, birthday,
						unregisterdHtml, temporizedHtml, formaledHtml, magFlag,
						mobileSiteFlag, strBadUser, strAnnounceFlag, strCategoryFlag, strZubatFlag, strMaturity_mail);
			} else {
				// ログインしている場合、

				// ユーザ情報更新処理を行う。
				log.info("ユーザ情報更新処理を開始する。[email:" + email + "]");
				return update(request, response, siteId, orderId, userId,
						email, loginedHtml, mobileSiteFlag, strBadUser, strAnnounceFlag, strCategoryFlag, strZubatFlag, strMaturity_mail);
			}

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			return "";
		}

	}

	/**
	 * 登録処理を行う。
	 * 
	 * @param request
	 * @param response
	 * @param siteId
	 * @param orderId
	 * @param userId
	 * @param email
	 * @param emailType
	 * @param password
	 * @param nickname
	 * @param gender
	 * @param birthday
	 * @param unregisterdHtml
	 * @param temporizedHtml
	 * @param formaledHtml
	 * @param magFlag
	 * @param mobileSiteFlag
	 * @return
	 * @throws Exception
	 */
	private String regist(HttpServletRequest request,
			HttpServletResponse response, String siteId, String orderId,
			String userId, String email, int emailType, String password,
			String nickname, String gender, String birthday,
			String unregisterdHtml, String temporizedHtml, String formaledHtml,
			String magFlag, boolean mobileSiteFlag, String badUser, String announceFlag, String categoryFlag, String zubatFlag, String strMaturity_mail) throws Exception {

		String resultHtml = "";
		DBAccess db = null;
		
		try {

			// email_typeを確認する。
			if (!(emailType == MemberMst.TYPE_PC_MAIL
					|| emailType == MemberMst.TYPE_MB_MAIL || emailType == MemberMst.TYPE_CP_MAIL)) {
				// パラメータエラーとする
				log.error("パラメータエラー パラメータ[emailType:" + emailType + "]が不正です。");
				return "";
			}

			// パスワードが指定されていない場合、
			if (ValueUtil.nullToStr(password).length() == 0) {
				// パスワードを自動生成
				password = DBUtil
						.makeRandomPassword(TempRegistUtil.TEMP_PASSWORD_LENGTH);
			}

			// ニックネームが指定されていない場合、
			if (nickname.length() == 0) {
				// emailのユーザ名部分をニックネームとする。
				int index = email.indexOf("@");
				if (index > 0) {
					nickname = email.substring(0, index);
				} else {
					nickname = email;
				}
			}

			// 生年月日を確認する。
			switch (birthday.length()) {
			case 0:
				break;
			case 8: // "yyyymmdd".length():
				break;
			case 10: // "yyyy-mm-dd".length():
				birthday = birthday.substring(0, 4) + birthday.substring(5, 7)
						+ birthday.substring(8, 10);
				break;
			default:
				// パラメータエラーとする
				log.error("パラメータエラー パラメータ[birthday:" + birthday + "]が不正です。");
				return "";
			}

			// 性別を確認する。
			if (!(gender.equals("") || gender.equals("1") || gender.equals("2"))) {
				// パラメータエラーとする
				log.error("パラメータエラー パラメータ[gender:" + gender + "]が不正です。");
				return "";
			}

			// 未登録時の登録処理結果用HTMLが指定されていない場合、
			if (unregisterdHtml.length() == 0) {
				// パラメータエラーとする
				log.error("パラメータエラー パラメータ[unregisterd_html]が指定されていません。");
				return "";
			}

			// 仮会員登録されていた時の処理結果用HTMLが指定されていない場合、
			if (temporizedHtml.length() == 0) {
				// パラメータエラーとする
				log.error("パラメータエラー パラメータ[temporized_html]が指定されていません。");
				return "";
			}

			// 本登録されていた時の処理結果用HTMLが指定されていない場合、
			if (formaledHtml.length() == 0) {
				// パラメータエラーとする
				log.error("パラメータエラー パラメータ[formaled_html]が指定されていません。");
				return "";
			}

			// --------------------------------------------------------------------------------
			// 処理を行う。

			// データベースに接続
			db = new DBAccess();

			// step登録時のデータを取得する
			StepUserInfo stepRegInfo = StepUserInfoFactory.createStepUserInfo(
					request, siteId);
			if (stepRegInfo != null) {
				if (stepRegInfo.doLoad(db, orderId, userId) == true) {
					log.info("step-DBのUserInfo,OrderInfoの読み込みに成功しました。siteId="
							+ siteId + ",orderId=" + orderId + ",userId="
							+ userId);
				} else {
					stepRegInfo = null;
					log.error("step-DBのUserInfo,OrderInfoの読み込みに失敗しました。siteId="
							+ siteId + ",orderId=" + orderId + ",userId="
							+ userId);
				}
			} else {
				// 該当のサイトが見つからなかった場合、
				log
						.error("該当のStepUserInfoが見つけられませんでした。なかったため、guidの書き戻しに失敗しました。[site_id:"
								+ siteId + "]");
			}

			// 仮登録処理を行う。
			log.info("仮登録処理開始 [email:" + email + "]");
			TempRegistResult result = TempRegistUtil.registTemporary(request,
					siteId, email, emailType, password);
			if (!result.isDupulicateError() && !result.isSuccess()) {
				// 処理エラーが発生した場合、
				log.error("仮登録処理エラー [エラーコード:" + result.status + "]");
				return "";
			}

			boolean needRegist;
			String registGuid = "";
			if (result.isDupulicateError()) {
				// 仮登録済みだった場合、

				MemberMst member = new MemberMst();
				member.load(db, email);

				if (member.isHontouroku()) {
					// 本登録済みだった場合、
					log.info("本登録済み [email:" + email + "]");

					// パスワードは表示しない。
					password = "";

					resultHtml = formaledHtml;
					needRegist = false;
				} else {
					// 本登録はすんでいなかった場合、
					log.info("仮登録状態 [email:" + email + "]");

					if (LoginUtil.isHashedPasswd(ValueUtil.nullToStr(member
							.get(MemberMst.PASSWD)))) {
						// ハッシュされたバスワードの場合、

						// パスワードを再設定する。
						member.setPassword(password);

						DBUpdater updater = new DBUpdater(MemberMst.TABLE);
						updater.addString(MemberMst.PASSWD, member
								.get(MemberMst.PASSWD));
						updater.setCond("WHERE GUID=?");
						updater.addCondString(member.getGuid());
						updater.update(db);
					} else {
						// 平文のパスワードの場合、
					    /*  sstagの外でパスワードを利用するために、仮登録状態でパスワード
					        設定済みの場合も、stepengine側で生成されたパスワードで、会員
					        情報を上書きする必要がある為、下記はコメントアウトします
					     */
						// 現在設定されているパスワードをそのまま表示する。
						//password = member.get(MemberMst.PASSWD);
					}

					// 仮登録状態のguidを確保しておく。
					registGuid = member.getGuid();

					resultHtml = temporizedHtml;
					needRegist = true;
				}

			} else {
				// 未登録だった場合、
				log.info("未登録 [email:" + email + "]");

				// sstagのmag_flagパラメータが設定されていない場合は、StepUserInfoのgetMagFlag()が"1"のときに
				// sstagのmag_flagパラメータが設定されている場合は、値が"1"のときに
				// メルマガ登録をする。
				/*
				if (magFlag.length() == 0
						&& stepRegInfo != null
						&& ValueUtil.nullToStr(stepRegInfo.getMagFlag())
								.equals("1") || magFlag.equals("1")) {
					// ステップ側の情報を元に、メルマガ管理テーブルを更新する
					log.info("メルマガ管理テーブルを更新");
					StepDb
							.updateMelmagaFlg(result.temporaryGuid, email,
									siteId);
				}*/

				// 新規に作成したguidを確保しておく。
				registGuid = result.temporaryGuid;

				resultHtml = unregisterdHtml;
				needRegist = true;
			}

			// 本登録がまだ行われていない場合、
			if (needRegist) {

				// カレントセッションのguidと仮登録済みのユーザのguidが違う場合、
				String currentGuid = ValueUtil.nullToStr(request
						.getAttribute(UserInfo.GUID_ATTR_KEY));
				if (!currentGuid.equals(registGuid)) {
					log
							.info("カレントセッションのguidと仮登録のguidが一致しない。[current_guid:"
									+ currentGuid
									+ "][regist_guid:"
									+ registGuid + "]");

					// 仮登録済みのユーザのguidでサイトセッションを作り直す
					String gsid = SessionFilterUtil.getGsid(request);
					log.info("サイトセッションを作り直す。[gsid:" + gsid + "][guid:"
							+ registGuid + "]");
					LogoutUtil.changeGuid(gsid, registGuid, request);

					// 生成したguidを、ステップ側に書き戻す
					if (stepRegInfo != null) {
						log.info("生成したguidを、ステップ側に書き戻す。[guid:" + registGuid
								+ "]");
						db.setAutoCommit(false);
						stepRegInfo.doOverWriteGuid(db, registGuid);
						db.commit();
					}
				}

				// 別スレッドで本登録処理を行う。
				request.setAttribute(
						MemberRegistThread.MEMBER_REGIST_THREAD_EMAIL_ATTR_KEY,
						email);
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_PASSWORD_ATTR_KEY,
								password);
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_SITE_ID_ATTR_KEY,
								siteId);
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_ORDER_ID_ATTR_KEY,
								orderId);
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_USER_ID_ATTR_KEY,
								userId);
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_NICKNAME_ATTR_KEY,
								nickname);
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_GENDER_ATTR_KEY,
								gender);
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_BIRTHDAY_ATTR_KEY,
								birthday);
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_MOBILE_SITE_FLAG_ATTR_KEY,
								new Boolean(mobileSiteFlag));
				request
						.setAttribute(
								MemberRegistThread.MEMBER_REGIST_THREAD_EXEC_TYPE_ATTR_KEY,
								MemberRegistThread.MEMBER_REGIST_THREAD_EXEC_TYPE_REGIST);

				memberRegistThread.push(request, response);
				
		    //  コールリスト登録用のGUIDを設定、このGUIDはユーザーStep利用時の電話番号と紐付けてます
		    request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_GUID_ATTR_KEY, SessionFilterUtil.getGuid(request));

			}

			// メルマガ登録をする
			if (badUser.equals("0"))
			{
				if(!SessionFilterUtil.isValidGuid(registGuid)){
					registGuid = SessionFilterUtil.getGuid(request);
				}
				log.info("apply update_mag_permission");
				updateMailPermission(announceFlag, categoryFlag, zubatFlag, strMaturity_mail, email, siteId, orderId, userId, registGuid);
			}
			else
			{
				log.info("not apply update_mag_permission");
			}
			
			// パスワード部分を置き換える。
			resultHtml = ValueUtil.replace(resultHtml, PASSWORD_PARAM_KEY,
					password);

		} catch (SQLException e) {
			log.error("DBエラー", e);
			return "";
		} finally {
			DBAccess.close(db);
		}

		return resultHtml;
	}

	/**
	 * ユーザ情報更新処理を行う。
	 * 
	 * @param request
	 * @param response
	 * @param siteId
	 * @param orderId
	 * @param userId
	 * @param email
	 * @param loginedHtml
	 * @param mobileSiteFlag
	 * @return
	 */
	private String update(HttpServletRequest request,
			HttpServletResponse response, String siteId, String orderId,
			String userId, String email, String loginedHtml,
			boolean mobileSiteFlag, String badUser, String announceFlag, String categoryFlag, String zubatFlag, String strMaturity_mail) {

		// ログイン済みの時の結果用HTMLが指定されていない場合、
		if (loginedHtml.length() == 0) {
			// パラメータエラーとする
			log.error("パラメータエラー パラメータ[logined_html]が指定されていません。");
			return "";
		}

		// 別スレッドで本登録処理を行う。
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_EMAIL_ATTR_KEY, email);
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_PASSWORD_ATTR_KEY, "");
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_SITE_ID_ATTR_KEY,
				siteId);
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_ORDER_ID_ATTR_KEY,
				orderId);
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_USER_ID_ATTR_KEY,
				userId);
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_NICKNAME_ATTR_KEY, "");
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_GENDER_ATTR_KEY, "");
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_BIRTHDAY_ATTR_KEY, "");
		request
				.setAttribute(
						MemberRegistThread.MEMBER_REGIST_THREAD_MOBILE_SITE_FLAG_ATTR_KEY,
						new Boolean(mobileSiteFlag));
		request.setAttribute(
				MemberRegistThread.MEMBER_REGIST_THREAD_EXEC_TYPE_ATTR_KEY,
				MemberRegistThread.MEMBER_REGIST_THREAD_EXEC_TYPE_UPDATE);

		memberRegistThread.push(request, response);
		
    //  コールリスト登録用のGUIDを設定、このGUIDはユーザーStep利用時の電話番号と紐付けてます
    request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_GUID_ATTR_KEY, SessionFilterUtil.getGuid(request));


		// メルマガ登録をする
		if (badUser.equals("0"))
		{
			log.info("apply update_mag_permission");
			updateMailPermission(announceFlag, categoryFlag, zubatFlag, strMaturity_mail, email, siteId, orderId, userId, SessionFilterUtil.getGuid(request));
		}
		else
		{
			log.info("not apply update_mag_permission bad_user");
		}

		return loginedHtml;
	}
	
	// キャンペーン期間中の判断
	private boolean isCampaignPeriod(String campaignId)
	{
		try
		{
			if (campaignId.equals(""))
			{
				return false;
			}
			else
			{
				String period = ValueUtil.nullToStr(SiteCrossCampaign.getPeriod(campaignId));
				if (period.equals(""))
				{
					return false;
				}
				
				String[] date_period = period.split(":");
				// 開始日時
				Timestamp start_timestamp = DateUtil.toTimestamp(date_period[0]);
				// 終了日時
				Timestamp end_timestamp = DateUtil.toTimestamp(date_period[1]);
				// 現在日付時刻を取得(YYYYMMDDHHMISS形式)
				Timestamp current_timestamp = DateUtil.toTimestamp(DateUtil.currentDateTime());
				
				//キャンペーン期間中の判断
				if (current_timestamp.after(start_timestamp) && current_timestamp.before(end_timestamp))
				{
					//期間内
					return true;
				}
				else
				{
					//期間外
					return false;
				}
			}
		}
		catch (Exception ex)
		{
			log.error("キャンペーン期間判定処理で例外が発生しました。", ex);
			return false;
		}
	}

	/*
	 * SITE_CROSS_CAMPAIGNテーブルに一行作成する。
	 * 
	 * @param authKey
	 * 
	 * @param orderId
	 * 
	 * @param siteId
	 * 
	 * @param email
	 * 
	 * @param guid
	 * 
	 * @return -1 : エラー -1 : 処理中止（引数がNULLの場合など） 1 : 成功
	 */
	private int insertSiteCrossCampaign(String authKey, String orderId, String siteId, String email, String guid, String campaignId)
	{
		try
		{
			// テーブルに一行作成する。
			SiteCrossCampaign campaign = new SiteCrossCampaign();
			campaign.set(SiteCrossCampaign.AUTH_KEY, authKey);
			campaign.set(SiteCrossCampaign.ORDER_ID, orderId);
			campaign.set(SiteCrossCampaign.SITE_ID, siteId);
			campaign.set(SiteCrossCampaign.GUID, guid);
			campaign.set(SiteCrossCampaign.EMAIL, email);
			campaign.set(SiteCrossCampaign.CAMPAIGN_ID, campaignId);

			// 登録の際初期値を設定
			campaign.set(SiteCrossCampaign.APP_KIND, SiteCrossCampaign.APP_KIND_DEFAULT);
			campaign.set(SiteCrossCampaign.APP_FLG, SiteCrossCampaign.APP_FLG_DEFAULT);
			campaign.set(SiteCrossCampaign.LOT_TYPE, SiteCrossCampaign.LOT_TYPE_DEFAULT);
			campaign.set(SiteCrossCampaign.ALTERNATIVE_LOT_TYPE, SiteCrossCampaign.ALTERNATIVE_LOT_TYPE_DEFAULT);

			// システムデートを設定
			String currentDateTime = DateUtil.currentDateTime();
			campaign.set(SiteCrossCampaign.MK_DATETIME, currentDateTime);
			campaign.set(SiteCrossCampaign.UP_DATETIME, currentDateTime);

			// テーブルに一行作成する。
			return SiteCrossCampaign.insertToDB(campaign);
		}
		catch (Exception ex)
		{
			log.error("予期せぬエラーが発生しました。", ex);
			return -1;
		}
	}

	// パミション更新
	private boolean updateMailPermission(String strAnnounceFlag, String strCategoryFlag, String strZubatFlag, String strMaturity_mail,
			String email, String siteId, String orderId, String userId, String guid) {
		
		DBAccess objDBAccess = null;

		try {
			objDBAccess = new DBAccess();
			// チェックボックスが表示され、ONの状態の場合「1」です。
			String strCheckedFlag = "1";
			// チェックボックスの状態をリストに保存する, 四つのフラグは「0」、「1」です。チェックボックス表示しない場合は処理しない
			
			
			log.info("[mag_value][announce]"+strAnnounceFlag+"[category]"+strCategoryFlag+"[zubat]"+strZubatFlag+"[maturity]"+strMaturity_mail);
			
			if (strAnnounceFlag.length() != 0 || strCategoryFlag.length() != 0 || strZubatFlag.length() != 0 || strMaturity_mail.length() != 0) {

				// メール購読管理テーブルに保存されているメールIDを取得する. ※購読済みも取得する、引越し大手など外す処理があるため
				List recordList = MelmagaUtil.getSiteMailList(objDBAccess, siteId);
				String mailId = "";
				String mailType = "";
				objDBAccess.setAutoCommit(false);
				for (Iterator it = recordList.iterator(); it.hasNext();) {
					Record rec = (Record) it.next();
					mailId = rec.getString("MAIL_ID");
					mailType = rec.getString("MAIL_TYPE");
					String invalidFlag = "";
					// メールタイプとチェック状態を判断する
					if (MagSubscribe.ANNOUNCE_MAIL.equals(mailType) && strAnnounceFlag.length() == 1) {
						invalidFlag = strCheckedFlag.equals(strAnnounceFlag) ? MagSubscribe.MAG_INVALID_FLAG_OFF
								: MagSubscribe.MAG_INVALID_FLAG_ON;
					} else if (MagSubscribe.CATEGORY_MAIL.equals(mailType) && strCategoryFlag.length() == 1) {
						invalidFlag = strCheckedFlag.equals(strCategoryFlag) ? MagSubscribe.MAG_INVALID_FLAG_OFF
								: MagSubscribe.MAG_INVALID_FLAG_ON;
					} else if (MagSubscribe.ZUBAT_MAIL.equals(mailType) && strZubatFlag.length() == 1) {
						invalidFlag = strCheckedFlag.equals(strZubatFlag) ? MagSubscribe.MAG_INVALID_FLAG_OFF
								: MagSubscribe.MAG_INVALID_FLAG_ON;
					} else if (MagSubscribe.MATURITY_MAIL.equals(mailType) && strMaturity_mail.length() == 1) {
						// 満期日お知らせ
						invalidFlag = strCheckedFlag.equals(strMaturity_mail) ? MagSubscribe.MAG_INVALID_FLAG_OFF
								: MagSubscribe.MAG_INVALID_FLAG_ON;
					}

					// チェックボックス表示した場合
					if (MagSubscribe.MAG_INVALID_FLAG_OFF.equals(invalidFlag)) {
						MelmagaUtil.executeMailSubscribe(objDBAccess, email, mailId, invalidFlag, MagSubscribe.REGIST_SITE_USE);
					} else if(MagSubscribe.MAG_INVALID_FLAG_ON.equals(invalidFlag)){
						MelmagaUtil.executeMailSubscribe(objDBAccess, email, mailId, invalidFlag, MagSubscribe.DELETE_SITE_USE);
					}
				}
			}

			// メール購読詳細テーブルを新規登録
			MagSubscribe.insertMailSubscribeDetail(objDBAccess, email, siteId, orderId, userId, guid);

			objDBAccess.commit();

			return true;
		} catch (Exception e) {
			log.error("メルマガ情報登録処理で例外が発生しました。email=" + email + " site_id=" + siteId + " order_id=" + orderId, e);
			return false;
		} finally {
			DBAccess.close(objDBAccess);
		}
	}

}
