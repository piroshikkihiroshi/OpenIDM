/**
 * 
 */
package jp.co.webcrew.phoenix.htmlservlet;

import java.io.UnsupportedEncodingException;

import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * <pre>
 * </pre>
 * @author Takahashi
 *
 */
public class HttpEntry {
 
    /** DBにテキストを格納する時のデフォルトのエンコーディング */
    public static final String DEFAULT_DB_STORE_ENCODING = "UTF-8";
    String path;
    byte[] contents;
    String type;
    String charset;
    String content_type;
    
    public boolean isEmpty() {
        
        if (contents == null) return true;
        
        
//        String strContents = getContentsStr();
//        if (strContents == null || strContents.length() == 0) {
//            return true;
//        }
        if (contents.length == 0) return true;
        
        return false;
    }
    
    public byte[] getContents() {
        return contents;
    }
    
   
    public String getContentsStr() throws UnsupportedEncodingException{
        if (contents == null) {
            return null;
        }
        
        //typeは考慮しない
        
        try {
            String encoding = charset;
            if (encoding == null || encoding.length() == 0) {
                encoding = DEFAULT_DB_STORE_ENCODING; 
            }
            
            return new String (contents , encoding);
            
//            return new String(contents); // エンコーディングしない

        } catch (UnsupportedEncodingException e) {
            throw e;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
       
    }
    
    /**
     * <pre>
     * テキストであればfalse、そうでなければtrueを返す。
     * </pre>
     * @return
     */
    public boolean isBinary() {
       
        /*
         * 
         * (1) content-type の指定がある場合。
         * 
         * content-type が text/xxx ならテキスト、そうでなければバイナリと判断する
         * 
         * (2) content-type の指定がない場合。
         * 
         * html_store.type が1,2,3以外ならバイナリと判断する。
         * 
         * 
         */
        
        String contentType = ValueUtil.nullToStr(getContentType());
        
        if (contentType.length() > 0) {
            if (contentType.startsWith("text") || contentType.endsWith("xml") ) {
                return false;
            } else {
                return true;
            }
        }
        
        if (type == null) {
            return true;
        } else {
            if (type.equals("1") || type.equals("2") || type.equals("3")) {
                return false;
            } else {
                return true;
            }
        }
    }
    
    /**
     * <pre>
     * Content-typeを返す。
     * </pre>
     * @return
     */
    public String getContentType() {

        // 指定があればそれを返す
        if (content_type != null && content_type.length() > 0) {
            return content_type;
        }
        
        // 拡張子から自動判別する
        String contentType;

        if (path != null) {
            
            if (path.endsWith(".html") || path.endsWith(".htm")) {
                return "text/html";
            }
            
            if (path.endsWith(".js")) {
                return "text/javascript";
            }
            
            if (path.endsWith(".text") || path.endsWith(".txt")) {
                return "text/plain";
            }

            if (path.endsWith(".csv")) {
                return "text/csv"; 
            }
            
            if (path.endsWith(".swf") || path.endsWith(".swfl")) {
                return "application/x-shockwave-flash";
            }
            
            if (path.endsWith(".css")) {
                return "text/css";
            }
            
            if (path.endsWith(".gif")) {
                return "image/gif";
            }

            if (path.endsWith(".jpg") || path.endsWith(".jpeg") || path.endsWith(".jpe")) {
                return "image/jpeg";
            }

            if (path.endsWith(".bmp")) {
                return "image/bmp";
            }

            if (path.endsWith(".xml") || path.endsWith(".xsl")) {
                return "application/xml";
            }

            if (path.endsWith(".xslt")) {
                return "application/xslt+xml";
            }
            
            if (path.endsWith(".dtd")) {
                return "application/xml-dtd";
            }

            if (path.endsWith(".pdf")) {
                return "application/pdf";
            }

            if (path.endsWith(".exe")) {
                return "application/octet-stream";
            }

            if (path.endsWith(".doc")) {
                return "application/msword";
            }

            if (path.endsWith(".xls") ) {
                return "application/vnd.ms-excel";
            }

            if (path.endsWith(".ppt") ) {
                return "application/vnd.ms-powerpoint";
            }

            if (path.endsWith(".docx")) {
                return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            }

            if (path.endsWith(".xlsx") ) {
                return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            }

            if (path.endsWith(".pptx") ) {
                return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            }

            
        }
        
        return null;
    }
    
    public String getCharSet() {
        return charset;
    }
}
