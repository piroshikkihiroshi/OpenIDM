package jp.co.webcrew.dbaccess.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 各種の値を処理するためのutilクラス。
 * 
 * @author kurinami
 */
public class ValueUtil {

	private static final Logger log = Logger.getLogger(ValueUtil.class);

	/** ID暗号化のハッシュアルゴリズム */
	public static final String ID_HASH_ALGORITHM = "SHA-1";

	/**
	 * nullを空文字列に変換する。
	 * 
	 * @param source
	 * @return
	 */
	public static String nullToStr(Object source) {
		if (source == null) {
			return "";
		} else {
			return source.toString();
		}
	}

	/**
	 * 空文字列をnullに変換する。
	 * 
	 * @param source
	 * @return
	 */
	public static String strToNull(Object source) {
		if (source.equals("")) {
			return null;
		} else {
			return source.toString();
		}
	}

	/**
	 * 文字列をintにして返す。
	 * 
	 * @param source
	 * @return
	 */
	public static int toint(String source) {
		int ret = 0;

		try {
			ret = Integer.parseInt(source);
		} catch (Exception e) {
		}

		return ret;
	}

	/**
	 * 文字列をIntegerにして返す。
	 * 
	 * @param source
	 * @return
	 */
	public static Integer toInteger(String source) {
		if (source == null || source.length() == 0) {
			return null;
		}
		return new Integer(toint(source));
	}

	/**
	 * 文字列をlongにして返す。
	 * 
	 * @param source
	 * @return
	 */
	public static long tolong(String source) {
		long ret = 0;

		try {
			ret = Long.parseLong(source);
		} catch (Exception e) {
		}

		return ret;
	}

	/**
	 * 文字列をLongにして返す。
	 * 
	 * @param source
	 * @return
	 */
	public static Long toLong(String source) {
		if (source == null || source.length() == 0) {
			return null;
		}
		return new Long(tolong(source));
	}

	/**
	 * 文字列をdoubleにして返す。
	 * 
	 * @param source
	 * @return
	 */
	public static double todouble(String source) {
		double ret = 0.0;

		try {
			ret = Double.parseDouble(source);
		} catch (Exception e) {
		}

		return ret;
	}

	/**
	 * 文字列をDoubleにして返す。
	 * 
	 * @param source
	 * @return
	 */
	public static Double toDouble(String source) {
		if (source == null || source.length() == 0) {
			return null;
		}
		return new Double(todouble(source));
	}

	/**
	 * 文字列をDate型にして返す。
	 * 
	 * @param source
	 * @return
	 */
	public static Date toDate(String source) {

		if (source == null) {
			return null;
		}

		try {
			if (source.length() == "yyyyMMdd".length()) {
				return new SimpleDateFormat("yyyyMMdd").parse(source);
			} else if (source.length() == "yyyyMMddHHmmss".length()) {
				return new SimpleDateFormat("yyyyMMddHHmmss").parse(source);
			} else {
				return null;
			}
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * Date型をyyyymmddの8桁の日付文字列に変換する。
	 * 
	 * @param source
	 * @return
	 */
	public static String toDateString(Date source) {
		if (source == null) {
			return "";
		}
		return new SimpleDateFormat("yyyyMMdd").format(source);
	}

	/**
	 * Date型をyyyymmddhhmmssの14桁の日時文字列に変換する。
	 * 
	 * @param source
	 * @return
	 */
	public static String toDateTimeString(Date source) {
		if (source == null) {
			return "";
		}
		return new SimpleDateFormat("yyyyMMddHHmmss").format(source);
	}

	/**
	 * Date型をyyyymmddhhmmss.sssの18桁の日時文字列に変換する。
	 * 
	 * @param source
	 * @return
	 */
	public static String toDateTimeMillString(Date source) {
		if (source == null) {
			return "";
		}
		return new SimpleDateFormat("yyyyMMddHHmmss.SSS").format(source);
	}

	/**
	 * 2つの日付の差を秒数で返す。
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static long dateDiff(Date date1, Date date2) {
		return ((date1.getTime() - date2.getTime()) / 1000l);
	}

	/**
	 * listを区切り文字でつないで1つの文字列にして返す。
	 * 
	 * @param list
	 * @param sep
	 * @return
	 */
	public static String concat(List list, String sep) {
		if (list == null) {
			return "";
		}

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < list.size(); i++) {
			if (i != 0) {
				sb.append(sep);
			}
			sb.append(list.get(i));
		}
		return sb.toString();
	}

	/**
	 * 指定された長さになるように、右側に文字を埋め込む。
	 * 
	 * @param source
	 * @param ch
	 * @param length
	 * @return
	 */
	public static String rpad(String source, char ch, int length) {
		StringBuffer sb = new StringBuffer();

		sb.append(source);

		while (sb.toString().length() < length) {
			sb.append(ch);
		}

		return sb.toString();
	}

	/**
	 * 指定された長さになるように、左側に文字を埋め込む。
	 * 
	 * @param source
	 * @param ch
	 * @param length
	 * @return
	 */
	public static String lpad(String source, char ch, int length) {
		StringBuffer sb = new StringBuffer();

		while (sb.toString().length() + source.length() < length) {
			sb.append(ch);
		}

		sb.append(source);

		return sb.toString();
	}

	/**
	 * 指定された桁になるように、数字の頭に0埋めする。
	 * 
	 * @param source
	 * @param length
	 * @return
	 */
	public static String lpad(int source, int length) {
		return lpad(Integer.toString(source), '0', length);
	}

	/**
	 * 文字列の中を置換する。
	 * 
	 * @param source
	 *            元文字列
	 * @param from
	 *            変換元
	 * @param to
	 *            変換先
	 * @return String
	 */
	public static String replace(String source, String from, String to) {
		// 元文字列がnullだった場合は、そのままnullを返す。
		if (source == null) {
			return null;
		}

		// 変換元もしくは、変換先がnullの場合は、元文字列をそのまま返す。
		if (from == null || to == null) {
			return source;
		}

		// 文字列を置換していく。
		StringBuffer sb = new StringBuffer();

		int index = source.indexOf(from);

		while (index != -1) {
			sb.append(source.substring(0, index));
			sb.append(to);

			source = source.substring(index + from.length());

			index = source.indexOf(from);
		}

		sb.append(source);

		// 結果を返す。
		return sb.toString();
	}

	/**
	 * 文字列の中の最初の一致文字列を置換する。
	 * 
	 * @param source
	 *            元文字列
	 * @param from
	 *            変換元
	 * @param to
	 *            変換先
	 * @return String
	 */
	public static String replaceFirst(String source, String from, String to) {
		// 元文字列がnullだった場合は、そのままnullを返す。
		if (source == null) {
			return null;
		}

		// 変換元もしくは、変換先がnullの場合は、元文字列をそのまま返す。
		if (from == null || to == null) {
			return source;
		}

		// 最初の文字列を置換する。
		StringBuffer sb = new StringBuffer();

		int index = source.indexOf(from);

		if (index != -1) {
			sb.append(source.substring(0, index));
			sb.append(to);

			source = source.substring(index + from.length());
		}

		sb.append(source);

		// 結果を返す。
		return sb.toString();
	}

	/**
	 * 文字列を指定の文字数に収まるように切り捨てる。
	 * 
	 * @param source
	 * @param maxLength
	 * @return
	 */
	public static String trim(Object source, int maxLength) {
		String sourceStr = nullToStr(source);
		if (sourceStr.length() > maxLength) {
			sourceStr = sourceStr.substring(0, maxLength - 1) + "…";
		}
		return sourceStr;
	}

	/**
	 * 文字列配列を連結する。
	 * 
	 * @param arr1
	 * @param arr2
	 * @return
	 */
	public static String[] arrayCat(String[] arr1, String[] arr2) {
		if (arr1 == null || arr2 == null) {
			return null;
		}

		String[] res = new String[arr1.length + arr2.length];
		System.arraycopy(arr1, 0, res, 0, arr1.length);
		System.arraycopy(arr2, 0, res, arr1.length, arr2.length);

		return res;
	}

	/**
	 * 数字配列を連結する。
	 * 
	 * @param arr1
	 * @param arr2
	 * @return
	 */
	public static int[] arrayCat(int[] arr1, int[] arr2) {
		if (arr1 == null || arr2 == null) {
			return null;
		}

		int[] res = new int[arr1.length + arr2.length];
		System.arraycopy(arr1, 0, res, 0, arr1.length);
		System.arraycopy(arr2, 0, res, arr1.length, arr2.length);

		return res;
	}

	/**
	 * 配列の値の合計を返す。
	 * 
	 * @param values
	 * @return
	 */
	public static int sum(String[] values) {
		if (values == null || values.length == 0) {
			return 0;
		}

		int sum = 0;
		for (int i = 0; i < values.length; i++) {
			sum += toint(values[i]);
		}
		return sum;
	}

	/**
	 * 配列の値の平均を返す。
	 * 
	 * @param values
	 * @return
	 */
	public static int avg(String[] values) {
		if (values == null || values.length == 0) {
			return 0;
		}

		int sum = 0;
		for (int i = 0; i < values.length; i++) {
			sum += toint(values[i]);
		}

		return sum / values.length;
	}

	/**
	 * 配列の値の平均を返す。
	 * 
	 * @param values
	 * @return
	 */
	public static int avg(int[] values) {
		if (values == null || values.length == 0) {
			return 0;
		}

		int sum = 0;
		for (int i = 0; i < values.length; i++) {
			sum += values[i];
		}

		return sum / values.length;
	}

	/**
	 * サニタイジングを行う。
	 * 
	 * @param value
	 * @return
	 */
	public static String sanitize(String value) {
		if (value == null) {
			return "";
		}
		value = value.replaceAll("&", "&amp;");
		value = value.replaceAll("<", "&lt;");
		value = value.replaceAll(">", "&gt;");
		value = value.replaceAll("\"", "&quot;");
		value = value.replaceAll("'", "&#39;");
		return value;
	}

	/**
	 * md5で変換した文字列を作成。
	 * 
	 * @param source
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public static String getMd5Digest(String source) {
		try {
			char[] HEX = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
					'A', 'B', 'C', 'D', 'E', 'F' };
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			byte[] digest = messageDigest.digest(source.getBytes());
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < digest.length; i++) {
				sb.append(HEX[(int) (digest[i] & 0xff) / 16]);
				sb.append(HEX[(int) (digest[i] & 0xff) % 16]);
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
	}

	/**
	 * <pre>
	 *  ID（数値）からチェックサム付きのSHA-1ハッシュを生成して返す
	 *  
	 *  処理中にエラーが発生した場合は null を返す
	 *  
	 * </pre>
	 * 
	 * @param id
	 *            生成元の数値
	 */
	public static String createHash(long id) {

		try {
			String id_str = String.valueOf(id);

			int checksum = 0;

			StringBuffer s = new StringBuffer();

			MessageDigest md = MessageDigest.getInstance(ID_HASH_ALGORITHM);
			byte[] dat = id_str.getBytes();
			md.update(dat);

			byte[] digest = md.digest();
			for (int i = 0; i < digest.length; i++) {
				int d = digest[i];

				if (d < 0) { // byte 128-255
					d += 256;
				}

				checksum += d;

				if (d < 16) { // 0-15 16
					s.append("0");
				}
				s.append(Integer.toString(d, 16));
			}

			// チェックサムの下二桁を先頭に加える
			int checkdigit = checksum % 100;

			log.debug("checkdigit=" + checkdigit);
			log.debug("checkdigit_16=" + Integer.toString(checkdigit, 16));

			s.insert(0, Integer.toString(checkdigit, 16));
			if (checkdigit < 16) {
				s.insert(0, "0");
			}

			return s.toString();

		} catch (Exception e) {
			log.error("ハッシュ生成に失敗しました。", e);
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * <pre>
	 *  ValueUtil#createHash で生成されたハッシュのチェックサム
	 *  が正しいかを検証する。
	 *  
	 *  正しければ true , 正しくなければ false を返す
	 *  
	 * </pre>
	 * 
	 * @param str
	 *            チェックサム付きのIDハッシュ
	 * @see ValueUtil#createHash(long)
	 */
	public static boolean isValidHash(String hash) {

		if (hash == null) {
			log.debug("引数が不正です。nullが渡されました。");
			return false;
		}

		int check_sum = 0;
		String target = nullToStr(hash);
		if (target.trim().equals("")) {
			log.debug("引数が不正です。nullまたは空または空白の文字列が渡されました。");
			return false;
		}

		if (hash.length() < 4) {
			log.debug("引数が不正です。ハッシュが正しく生成されていないようです。hash=" + hash);
			return false;
		}

		if (hash.length() % 2 != 0) {
			log.debug("引数が不正です。ハッシュが正しく生成されていないようです。hash=" + hash);
			return false;
		}

		String chk_str = hash.substring(0, 2);
		String hash_str = hash.substring(2, hash.length());

		StringBuffer buf = new StringBuffer();

		try {
			// 先頭から二文字ずつ切り取って、数値変換して足していく
			for (int i = 0; i < hash_str.length(); i = i + 2) {
				buf.setLength(0); // クリア
				buf.append(hash_str.charAt(i));
				buf.append(hash_str.charAt(i + 1));

				int c = Integer.parseInt(buf.toString(), 16);

				check_sum += c;
			}

			log.debug("hash_str=" + hash_str);
			log.debug("chk_str=" + chk_str);
			log.debug("check_sum=" + check_sum);
			int check_digit = check_sum % 100;
			log.debug("check_digit=" + check_digit);
			log.debug("check_digit_16=" + Integer.toString(check_digit, 16));

			StringBuffer chkBuf = new StringBuffer();
			if (check_digit < 16) {
				chkBuf.append("0");
			}
			chkBuf.append(Integer.toString(check_digit, 16));

			if (chk_str.equals(chkBuf.toString())) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("ハッシュの解析に失敗しました。hash=" + hash, e);
			return false;
		}
	}

	/**
	 * url表現中に/がダブっていた場合に1つにまとめる。
	 * 
	 * @param sourceUrl
	 * @return
	 */
	public static String sanitizeUrl(String sourceUrl) {

		int index;

		// リクエストパラメータ部分を抜き出す。
		String queryString = "";
		index = sourceUrl.indexOf('?');
		if (index >= 0) {
			queryString = sourceUrl.substring(index);
		}

		// スキーマ名部分を抜き出す。
		String scheme = "";
		index = sourceUrl.indexOf("://");
		if (index >= 0) {
			scheme = sourceUrl.substring(0, index + "://".length());
		}

		String base = sourceUrl.substring(scheme.length(), sourceUrl.length()
				- queryString.length());
		base = base.replaceAll("/{2,}", "/");

		return scheme + base + queryString;
	}

}