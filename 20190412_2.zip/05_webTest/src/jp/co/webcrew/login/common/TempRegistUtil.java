package jp.co.webcrew.login.common;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.DBUtil;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MailPerSiteContents;
import jp.co.webcrew.login.common.db.MailTemplate;
import jp.co.webcrew.login.common.db.MailTemplateUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.util.AppUtil;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.Mail;

/**
 * 仮登録処理に関するユーティリティクラス
 * 
 * @author Takahashi
 *
 */
public class TempRegistUtil {


	/** ロガー */
	private static final Logger log = Logger.getLogger(TempRegistUtil.class);

	/** 仮パスワード生成時のパスワード長 */
	public static final int TEMP_PASSWORD_LENGTH = 8;

	/** メールアドレスを MEMBER_MST.EMAILに格納 */ 
	public static final int TYPE_EMAIL_PC        = MemberMst.TYPE_PC_MAIL;
	
	/** メールアドレスを MEMBER_MST.MB_MAILに格納 */ 
	public static final int TYPE_EMAIL_MOBILE    = MemberMst.TYPE_MB_MAIL;

	/** メールアドレスを MEMBER_MST.CP_MAILに格納 */ 
	public static final int TYPE_EMAIL_CORPORATE = MemberMst.TYPE_CP_MAIL;
	
	/**
	 * emailTypeが妥当な値であればtrue、不正であればfalse
	 * 
	 * @param emailType
	 * @return
	 */
	private static boolean isValidEmailType (int emailType) {
		if ( emailType == TYPE_EMAIL_CORPORATE ||
			 emailType == TYPE_EMAIL_MOBILE    ||
			 emailType == TYPE_EMAIL_PC) {
			
			return true;
		} else {
			return false;
		}
			
			
	}
    /**
     * 仮登録処理を行う
     * 
     * 結果はTempRegistResultオブジェクトで返す
     * 
     * @param request    リクエスト 未使用
     * @param siteId     サイトID 必須
     * @param email      メールアドレス 必須
     * @param emailType  メール種別 必須
     * @return TempRegistResult 
     * @see TempRegistResult
     */
    public static TempRegistResult registTemporary(HttpServletRequest request , String siteId , String email , int emailType) {
        return TempRegistUtil.registTemporary(request, siteId, email, emailType, "");
    }
    /**
     * 仮登録処理を行う
     * 
     * 結果はTempRegistResultオブジェクトで返す
     * 
     * @param request    リクエスト 未使用
     * @param siteId     サイトID 必須
     * @param email      メールアドレス 必須
     * @param emailType  メール種別 必須
     * @return TempRegistResult 
     * @see TempRegistResult
     */
    public static TempRegistResult registTemporary(HttpServletRequest request , String siteId , String email , int emailType, String password) {

        log.info("ユーザ仮登録処理を開始します");
        
        String guid = ValueUtil.nullToStr(request.getAttribute("faon.guid")); // TODO 引数として渡してもらう？
        
        TempRegistResult result = new TempRegistResult();

        /*
         * 入力チェック
         */

        // requestは未使用なのでチェックしない
        
        // siteId が無効、もしくは取得できなかった場合は、仮登録しない
        if (siteId == null || siteId.equals("")) {
            log.error("登録元siteIdを取得できませんでした。呼び出し方が不正です。仮登録処理をスキップします。");
            result.status = TempRegistResult.REGIST_INPUT_ERROR;
            return result;
        }

        // E-mail が無効、もしくは取得できなかった場合は、仮登録しない
        if (email == null || email.equals("")) {
            log.error("emailを取得できませんでした。呼び出し方が不正です。仮登録処理をスキップします。");
            result.status = TempRegistResult.REGIST_INPUT_ERROR;
            return result;
        }

        // emailType が無効、もしくは取得できなかった場合は、仮登録しない
        if (! isValidEmailType (emailType) ) {
            log.error("emailTypeが不正です。呼び出し方が不正です。仮登録処理をスキップします。");
            result.status = TempRegistResult.REGIST_INPUT_ERROR;
            return result;
        }

        /*
         * 仮登録処理
         */
        
        DBAccess db = null;
        SystemProperties props ;

        try{
            // データベースに接続し、システムプロパティを読み込む
            db = new DBAccess();
            db.setAutoCommit(false);
            props = new SystemProperties(db);

            // 登録前の会員情報を読み込む
            MemberMst member = new MemberMst(guid);
            if (! member.load(db) ){
                result.status = TempRegistResult.REGIST_DB_ERROR;
                db.rollback();
                return result;
            }
            
            String tempPasswd;
            if (ValueUtil.nullToStr(password).length() == 0) {
                // 仮パスワードが指定されていなかった場合、
                
                // 仮パスワードを生成
                tempPasswd = DBUtil.makeRandomPassword(TEMP_PASSWORD_LENGTH); // ランダムな英数字で仮パスワードを生成
            } else {
                // 仮パスワードが指定されていた場合、
                
                // それをそのまま使用する。
                tempPasswd = password;
            }
//          String passwdDigest = DBUtil.getDigestOf(tempPasswd);                // 仮パスワードを暗号化

            // 既にメールアドレスがDB登録済の場合、仮登録は行わない
            if(MemberMst.existsMailAddress(db, email)){
                log.info("既に登録済です。仮登録処理をスキップします。email=" + email);
                db.commit();
                result.status = TempRegistResult.REGIST_DUPLICATE_ERROR;
                return result;
            }
            
            // 会員情報テーブルに書き込む
            String new_guid = DBUtil.createNewGuid(db);                 // 仮登録時に、guidを常に新しく生成する（ログイン時に整合性が取れる仕掛け）
            MemberMst tempMemberRecord = new MemberMst(new_guid);
            tempMemberRecord.setPassword(tempPasswd);                   // 仮登録時には平文パスワードを入れる
            tempMemberRecord.setLimitDateTime(getLimitDateTime(props)); // 有効期限をセットする
            tempMemberRecord.setKaritourokuFlg();                       // 仮登録フラグを立てる
            tempMemberRecord.set(MemberMst.SITE_ID, siteId);            // siteIdを設定
            tempMemberRecord.set(MemberMst.AF_CODE ,
                      member.get(MemberMst.AF_CODE));                   // アフェリエイトコードをコピー
            tempMemberRecord.set(MemberMst.PROMO_CODE ,
                      member.get(MemberMst.PROMO_CODE));                // プロモーションコードをコピー
//          tempMemberRecord.set(MemberMst.REMINDER_FLAG ,
//                  MemberMst.FLG_REMINDER_NOT_SENT_OR_REGISTERD);      // リマインダフラグをオフ
            
            setEmailToMember(tempMemberRecord, email, emailType);       // メールアドレスをセット 

            insertMemberMst(db, tempMemberRecord);                      // 新規レコードを追加

            // 戻り値を設定
            result.temporaryGuid = new_guid;
            result.temporaryPassword = tempPasswd;
            result.status = TempRegistResult.REGIST_SUCCESS;

            db.commit();

            log.info("ユーザ仮登録のDB処理が完了しました");
                        
            return result;
            
        } catch (SQLException e){
            log.error("ユーザ登録中にデータベースエラーが発生しました。",e);
            result.status = TempRegistResult.REGIST_DB_ERROR;
            return result;

        } catch (Exception e){
            log.error("ユーザ登録中に例外エラーが発生しました。",e);
            result.status = TempRegistResult.REGIST_OTHER_ERROR;
            return result;
            
        } finally {
            DBAccess.close(db);
        }
        
    }
//    public static TempRegistResult registTemporary(HttpServletRequest request , String siteId , String email , int emailType) {
//
//		log.info("ユーザ仮登録処理を開始します");
//		
//		String guid = ValueUtil.nullToStr(request.getAttribute("faon.guid")); // TODO 引数として渡してもらう？
//		
//		TempRegistResult result = new TempRegistResult();
//
//		/*
//		 * 入力チェック
//		 */
//
//		// requestは未使用なのでチェックしない
//		
//		// siteId が無効、もしくは取得できなかった場合は、仮登録しない
//		if (siteId == null || siteId.equals("")) {
//			log.error("登録元siteIdを取得できませんでした。呼び出し方が不正です。仮登録処理をスキップします。");
//			result.status = TempRegistResult.REGIST_INPUT_ERROR;
//			return result;
//		}
//
//		// E-mail が無効、もしくは取得できなかった場合は、仮登録しない
//		if (email == null || email.equals("")) {
//			log.error("emailを取得できませんでした。呼び出し方が不正です。仮登録処理をスキップします。");
//			result.status = TempRegistResult.REGIST_INPUT_ERROR;
//			return result;
//		}
//
//		// emailType が無効、もしくは取得できなかった場合は、仮登録しない
//		if (! isValidEmailType (emailType) ) {
//			log.error("emailTypeが不正です。呼び出し方が不正です。仮登録処理をスキップします。");
//			result.status = TempRegistResult.REGIST_INPUT_ERROR;
//			return result;
//		}
//
//		/*
//		 * 仮登録処理
//		 */
//		
//		DBAccess db = null;
//		SystemProperties props ;
//
//		try{
//			// データベースに接続し、システムプロパティを読み込む
//			db = new DBAccess();
//			db.setAutoCommit(false);
//			props = new SystemProperties(db);
//
//			// 登録前の会員情報を読み込む
//			MemberMst member = new MemberMst(guid);
//			if (! member.load(db) ){
//				result.status = TempRegistResult.REGIST_DB_ERROR;
//				db.rollback();
//				return result;
//			}
//			
//			// 仮パスワードを生成
//			String tempPasswd = DBUtil.makeRandomPassword(TEMP_PASSWORD_LENGTH); // ランダムな英数字で仮パスワードを生成
////			String passwdDigest = DBUtil.getDigestOf(tempPasswd);                // 仮パスワードを暗号化
//
//			// 既にメールアドレスがDB登録済の場合、仮登録は行わない
//			if(MemberMst.existsMailAddress(db, email)){
//				log.info("既に登録済です。仮登録処理をスキップします。email=" + email);
//				db.commit();
//				result.status = TempRegistResult.REGIST_DUPLICATE_ERROR;
//				return result;
//			}
//			
//			// 会員情報テーブルに書き込む
//			String new_guid = DBUtil.createNewGuid(db);                 // 仮登録時に、guidを常に新しく生成する（ログイン時に整合性が取れる仕掛け）
//			MemberMst tempMemberRecord = new MemberMst(new_guid);
//			tempMemberRecord.setPassword(tempPasswd);                   // 仮登録時には平文パスワードを入れる
//			tempMemberRecord.setLimitDateTime(getLimitDateTime(props)); // 有効期限をセットする
//			tempMemberRecord.setKaritourokuFlg();                       // 仮登録フラグを立てる
//			tempMemberRecord.set(MemberMst.SITE_ID, siteId);            // siteIdを設定
//			tempMemberRecord.set(MemberMst.AF_CODE ,
//					  member.get(MemberMst.AF_CODE));                   // アフェリエイトコードをコピー
//			tempMemberRecord.set(MemberMst.PROMO_CODE ,
//					  member.get(MemberMst.PROMO_CODE));                // プロモーションコードをコピー
////			tempMemberRecord.set(MemberMst.REMINDER_FLAG ,
////					MemberMst.FLG_REMINDER_NOT_SENT_OR_REGISTERD);      // リマインダフラグをオフ
//			
//			setEmailToMember(tempMemberRecord, email, emailType);       // メールアドレスをセット 
//
//			insertMemberMst(db, tempMemberRecord);                      // 新規レコードを追加
//
//			// 戻り値を設定
//			result.temporaryGuid = new_guid;
//			result.temporaryPassword = tempPasswd;
//			result.status = TempRegistResult.REGIST_SUCCESS;
//
//			db.commit();
//
//			log.info("ユーザ仮登録のDB処理が完了しました");
//						
//			return result;
//			
//		} catch (SQLException e){
//			log.error("ユーザ登録中にデータベースエラーが発生しました。",e);
//			result.status = TempRegistResult.REGIST_DB_ERROR;
//			return result;
//
//		} catch (Exception e){
//			log.error("ユーザ登録中に例外エラーが発生しました。",e);
//			result.status = TempRegistResult.REGIST_OTHER_ERROR;
//			return result;
//			
//		} finally {
//			DBAccess.close(db);
//		}
//		
//	}

	
	/**
	 * <pre>
	 * 
	 * 会員情報オブジェクトにメールアドレスとメール種別をセットする
	 * 
	 * </pre>
	 * @param member    会員情報
	 * @param email     メールアドレス
	 * @param emailType メールアドレス種別 
	 */
	private static void setEmailToMember (MemberMst member , String email , int emailType) {
		
		// 080519 Takahashi メール種別を更新するよう追加
		
		switch(emailType) {
		
			case(TYPE_EMAIL_MOBILE):
	            member.set(MemberMst.MB_MAIL , email);
				member.set(MemberMst.PRIMARY_EMAIL, String.valueOf(TYPE_EMAIL_MOBILE));
				break;
			case(TYPE_EMAIL_CORPORATE):
	            member.set(MemberMst.CP_MAIL , email);
				member.set(MemberMst.PRIMARY_EMAIL, String.valueOf(TYPE_EMAIL_CORPORATE));
				break;
			default:
	            member.set(MemberMst.EMAIL , email);
				member.set(MemberMst.PRIMARY_EMAIL, String.valueOf(TYPE_EMAIL_PC));
		}
    }	

	/**
     * システムプロパティの値（LIMIT_FROM_TEMPORARY_REGIST）に応じて、
     * 仮登録有効期限をYYYYMMDDHHMISS形式で取得する
     * 
     * @param props システムプロパティオブジェクト
     * @return
     */
	public static String getLimitDateTime(SystemProperties props ){
		String limit_time = props.get(SystemProperties.LIMIT_FROM_TEMPORARY_REGIST);
		return DateUtil.getDateTime(limit_time);
	}

	/**
	 * <pre>
	 * 仮登録メールを送信する
	 * 
	 * 引数のうち、fromとregistUrlの二つはシステムプロパティの指定が可能($$で囲む)
	 * 
	 * 送信処理に成功したらtrue、失敗したらfalseを返す
	 * </pre>
	 * 
	 * @param mailto     仮登録ユーザのメールアドレス(=仮登録通知メールの宛先)。必須。
	 * 
	 * @param from       仮登録通知メールの送信者。省略時はデフォルト値が使用される。null可。
	 * 
	 * @param passwd     仮パスワード。必須。
	 * 
	 * @param registUrl  本登録処理を行うURI。呼び出し元がURLを生成する。必須。
	 * 
	 * @param templateId 仮登録通知メールのテンプレートID。必須。
	 * 
	 */
	public static boolean sendMail(String mailto , String from , String passwd , String registUrl , String templateId) {

		/*
		 * 入力チェック
		 */
		
		if (ValueUtil.nullToStr(mailto).equals("")) {
			log.error("宛先が指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(mailto); return false;
		}
		if (ValueUtil.nullToStr(passwd).equals("")) {
			log.error("仮パスワードが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(mailto); return false;
		}
		if (ValueUtil.nullToStr(registUrl).equals("")) {
			log.error("本登録用のURLが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(mailto); return false;
		}
		if (ValueUtil.nullToStr(templateId).equals("")) {
			log.error("仮登録用のメールテンプレートが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(mailto); return false;
		}

		
		/*
		 * 送信処理開始
		 */
		
		DBAccess db = null;
		try {
			db = new DBAccess();

			// システムプロパティを取得
			SystemProperties props = new SystemProperties(db);
			
			// 引数の中のシステムプロパティ変数を解釈する
			registUrl = props.replaceStr(registUrl);
			if (registUrl == null) {
				log.error("本登録URLの解釈に失敗しました。メール送信を中断します。");
				rollbackTempRegist(mailto); return false;
			}


			// メールテンプレートを準備する
			MailTemplate template = new MailTemplate(templateId);
			
			if (! template.load(db) ) {
				log.error("メールテンプレートの読み込みに失敗しました。");
				rollbackTempRegist(mailto); return false;
			}

			// 各設定を取得
			String smtp    = props.getSmtpHost();
			String port    = props.get(SystemProperties.MAIL_SMTP_PORT);
			String subject = template.getSubject();
			String body    = template.getBody();
			from           = getMailSender (template , props , from);

			if (from == null) {
				log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
				rollbackTempRegist(mailto); return false;
			}
			
			// テンプレートの変数を置換
	    
		    body = body.replaceAll("\\$\\$auth_url\\$\\$"   , registUrl );
		    body = body.replaceAll("\\$\\$login_url\\$\\$"  , registUrl );
		    body = body.replaceAll("\\$\\$auth_pass\\$\\$"  , passwd );
		    body = body.replaceAll("\\$\\$login_pass\\$\\$" , passwd );
		    body = body.replaceAll("\\$\\$password\\$\\$"   , passwd );
		    body = body.replaceAll("\\$\\$email\\$\\$"      , mailto );

		    body = AppUtil.replaceDateTime(body); // 日付時刻を置換
		    
		    Mail.sendMail(smtp, port, mailto , from, subject, body);
		    
		    log.info("仮登録メールを送信しました。");
		    return true;
		    
		} catch (Exception e) {
			log.error("メール送信中に例外エラーが発生しました。" , e);
			rollbackTempRegist(mailto); return false;

		} finally {
			DBAccess.close(db);
		}

			
	}
	
	/**
     * <pre>
     * ステップサイト用の仮登録メールを送信する
     * 
     * 引数のうち、fromとregistUrlの二つはシステムプロパティの指定が可能($$で囲む)
     * 
     * 送信処理に成功したらtrue、失敗したらfalseを返す
     * </pre>
     * 
     * @param mailto     仮登録ユーザのメールアドレス(=仮登録通知メールの宛先)。必須。
     * 
     * @param from       仮登録通知メールの送信者。省略時はデフォルト値が使用される。null可。
     * 
     * @param passwd     仮パスワード。必須。
     * 
     * @param registUrl  本登録処理を行うURI。呼び出し元がURLを生成する。必須。
     * 
     * @param templateId 仮登録通知メールのテンプレートID。必須。
     * 
     * @param siteId     該当ステップサイトのサイトID 
     */
    public static boolean sendMailStepTempRegist(String mailto , String from , String passwd , String registUrl , String templateId , String siteId) {

        /*
         * 入力チェック
         */
        
        if (ValueUtil.nullToStr(mailto).equals("")) {
            log.error("宛先が指定されませんでした。メール送信を中断します。");
            rollbackTempRegist(mailto); return false;
        }
        if (ValueUtil.nullToStr(passwd).equals("")) {
            log.error("仮パスワードが指定されませんでした。メール送信を中断します。");
            rollbackTempRegist(mailto); return false;
        }
        if (ValueUtil.nullToStr(registUrl).equals("")) {
            log.error("本登録用のURLが指定されませんでした。メール送信を中断します。");
            rollbackTempRegist(mailto); return false;
        }
        if (ValueUtil.nullToStr(templateId).equals("")) {
            log.error("仮登録用のメールテンプレートが指定されませんでした。メール送信を中断します。");
            rollbackTempRegist(mailto); return false;
        }
        if (ValueUtil.nullToStr(siteId).equals("")) {
            log.error("仮登録時のサイトIDが指定されていませんでした。メール送信を中断します。");
            rollbackTempRegist(mailto); return false;
        }

        
        /*
         * 送信処理開始
         */
        
        DBAccess db = null;
        try {
            db = new DBAccess();

            // システムプロパティを取得
            SystemProperties props = new SystemProperties(db);
            
            // 引数の中のシステムプロパティ変数を解釈する
            registUrl = props.replaceStr(registUrl);
            if (registUrl == null) {
                log.error("本登録URLの解釈に失敗しました。メール送信を中断します。");
                rollbackTempRegist(mailto); return false;
            }


            // メールテンプレートを準備する
            MailTemplate template = new MailTemplate(templateId);
            
            if (! template.load(db) ) {
                log.error("メールテンプレートの読み込みに失敗しました。");
                rollbackTempRegist(mailto); return false;
            }

            // サイト固有メールコンテンツの準備
            MailPerSiteContents perSiteContents = new MailPerSiteContents(siteId);
            if (! perSiteContents.load(db)) {
                log.error("サイト固有コンテンツ：サイトＩＤ：" + siteId + "の読み込みに失敗しました。");
                return false;
            }
            
            // 各設定を取得
            String smtp    = props.getSmtpHost();
            String port    = props.get(SystemProperties.MAIL_SMTP_PORT);
            String subject = template.getSubject();
            String body    = template.getBody();
            from           = getMailSender (template , props , from);

            if (from == null) {
                log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
                rollbackTempRegist(mailto); return false;
            }
            
            // サイト固有メールコンテンツの取得
            String siteName        = ValueUtil.nullToStr(perSiteContents.getSiteName());
            String var_contents_1  = ValueUtil.nullToStr(perSiteContents.getVarContents1());
            String var_contents_2  = ValueUtil.nullToStr(perSiteContents.getVarContents2());
            String var_contents_3  = ValueUtil.nullToStr(perSiteContents.getVarContents3());
            String var_contents_4  = ValueUtil.nullToStr(perSiteContents.getVarContents4());
            String var_contents_5  = ValueUtil.nullToStr(perSiteContents.getVarContents5());
            
            // 先にサイト固有文言を変換しておく。
            body = body.replaceAll("\\$\\$site_var_contents_1\\$\\$"   ,   var_contents_1);
            body = body.replaceAll("\\$\\$site_var_contents_2\\$\\$"   ,   var_contents_2);
            body = body.replaceAll("\\$\\$site_var_contents_3\\$\\$"   ,   var_contents_3);
            body = body.replaceAll("\\$\\$site_var_contents_4\\$\\$"   ,   var_contents_4);
            body = body.replaceAll("\\$\\$site_var_contents_5\\$\\$"   ,   var_contents_5);
            
            // テンプレートの変数を置換
            body = MailTemplate.replaceSysProp(body); // システムプロパティを一括置換
            if (body == null || body.equals("")) {
                log.error("メール本文の取得に失敗しました。データベースに登録されていないか、必要なシステムプロパティの取得に失敗した可能性があります。メール送信を中断します。");
                return false;
            }
            
            // テンプレートの変数を置換
            // タイトルへの変数の埋め込み
            subject = subject.replaceAll("\\$\\$site_name\\$\\$"    ,   siteName);
            
            // ボディへの変数の埋め込み
            body = body.replaceAll("\\$\\$site_name\\$\\$"             ,   siteName);
            body = body.replaceAll("\\$\\$auth_url\\$\\$"   , registUrl );
            body = body.replaceAll("\\$\\$login_url\\$\\$"  , registUrl );
            body = body.replaceAll("\\$\\$auth_pass\\$\\$"  , passwd );
            body = body.replaceAll("\\$\\$login_pass\\$\\$" , passwd );
            body = body.replaceAll("\\$\\$password\\$\\$"   , passwd );
            body = body.replaceAll("\\$\\$email\\$\\$"      , mailto );

            body = AppUtil.replaceDateTime(body); // 日付時刻を置換
            
            Mail.sendMail(smtp, port, mailto , from, subject, body);
            
            log.info("仮登録メールを送信しました。");
            return true;
            
        } catch (Exception e) {
            log.error("メール送信中に例外エラーが発生しました。" , e);
            rollbackTempRegist(mailto); return false;

        } finally {
            DBAccess.close(db);
        }

            
    }

	/**
	 * 該当メールアドレスの会員仮登録を中止する
	 * 
	 * @param email
	 */
	public static void rollbackTempRegist(String email) {
		if (ValueUtil.nullToStr(email).equals("")) return; // emailが無い場合は中断

		DBAccess db = null;
		try {
			db = new DBAccess();
			db.setAutoCommit(false);
			// MemberMstからEmailを削除する
			DBUpdater updater = new DBUpdater(MemberMst.TABLE);
			updater.addString(MemberMst.EMAIL   , "");
			updater.addString(MemberMst.MB_MAIL , "");
			updater.addString(MemberMst.CP_MAIL , "");
			updater.setCond("WHERE (" + MemberMst.EMAIL + "=? OR " + MemberMst.MB_MAIL + "=? OR " + MemberMst.CP_MAIL + "=? ) AND " + MemberMst.FORMAL_FLAG + "=?");
			updater.addCondString(email);
			updater.addCondString(email);
			updater.addCondString(email);
			updater.addCondString(MemberMst.FLG_FORMAL_OFF);
			
			updater.update(db);
			db.commit();
			
		} catch (Exception e) {
			log.error("仮登録キャンセル処理中にエラーが発生しました。" , e);
			db.rollback();
			
		} finally {
			DBAccess.close(db);
		}


	}

	
	/**
	 * 仮登録用のメール送信者を取得する
	 * 
	 * @param template  メールテンプレート（null可）
	 * @param props     システムプロパティ（必須）
	 * @param from      メール送信者（null可。システムプロパティ変数を指定可。）
	 * @return          メール送信者
	 */
	private static String getMailSender(MailTemplate template , SystemProperties props , String from) {

		if (props == null) {
			log.error("システムプロパティオブジェクトがnullです。呼び出しが不正です。");
			return null;
		}

		String sender = "";

		if (template != null) {
			sender  = ValueUtil.nullToStr(template.getFrom());  // メールテンプレートのfromを最優先とする
		}

		if (sender.equals("")) {
			// メールテンプレートから送信者を取得できなかった場合、指定されたfromを使用する
			sender = ValueUtil.nullToStr (from);
		}
		
		if (sender.equals("")) {
			log.warn("MAIL_TEMPLテーブルにfromが指定されていないため、システムプロパティからデフォルト値を取得します。");
			sender = "$$MAIL_SENDER_OF_TEMPORARY_REGIST$$"; // メールテンプレートにも指定が無い場合、デフォルト値を使う
		}

		
		return  props.replaceStr(sender); // システムプロパティ変数を置換	
	}
	
	/**
	 * <pre>
	 * 仮登録において、会員マスタテーブルへの登録処理を行う
	 * </pre>
	 * @param db
	 * @param member
	 * @throws SQLException
	 */
	private static void insertMemberMst(DBAccess db , MemberMst member ) throws SQLException{

		
		DBUpdater inserter = new DBUpdater(member.getFullTableName());
		inserter.addString(MemberMst.GUID           , member.get(MemberMst.GUID));
		inserter.addString(MemberMst.PASSWD         , member.get(MemberMst.PASSWD));
		inserter.addString(MemberMst.LIMIT_DATETIME , member.get(MemberMst.LIMIT_DATETIME));
		inserter.addString(MemberMst.FORMAL_FLAG    , member.get(MemberMst.FORMAL_FLAG));
		inserter.addString(MemberMst.SITE_ID        , member.get(MemberMst.SITE_ID));
		
		inserter.addString(MemberMst.PRIMARY_EMAIL  , member.get(MemberMst.PRIMARY_EMAIL));
		inserter.addString(MemberMst.EMAIL          , member.get(MemberMst.EMAIL));
		inserter.addString(MemberMst.MB_MAIL        , member.get(MemberMst.MB_MAIL));
		inserter.addString(MemberMst.CP_MAIL        , member.get(MemberMst.CP_MAIL));
		inserter.addString(MemberMst.MK_DATETIME    , DateUtil.currentDateTime());
		inserter.addString(MemberMst.UP_DATETIME    , DateUtil.currentDateTime());
		inserter.addString(MemberMst.REMINDER_FLAG  , MemberMst.FLG_REMINDER_NOT_SENT_OR_REGISTERD);

		inserter.addString(MemberMst.AF_CODE        , member.get(MemberMst.AF_CODE));
		inserter.addString(MemberMst.PROMO_CODE     , member.get(MemberMst.PROMO_CODE));
		inserter.insert(db);
	}

	/**
	 * <pre>
	 * 【メール送信処理共通化用】
	 * 
	 * 仮登録メールを送信する
	 * 
	 * 引数のうち、fromとregistUrlの二つはシステムプロパティの指定が可能($$で囲む)
	 * 
	 * 送信処理に成功したらtrue、失敗したらfalseを返す
	 * </pre>
	 * 
	 * @param mailto     仮登録ユーザのメールアドレス(=仮登録通知メールの宛先)。必須。
	 * 
	 * @param from       仮登録通知メールの送信者。省略時はデフォルト値が使用される。null可。
	 * 
	 * @param passwd     仮パスワード。必須。
	 * 
	 * @param registUrl  本登録処理を行うURI。呼び出し元がURLを生成する。必須。
	 * 
	 * @param templateId 仮登録通知メールのテンプレートID。必須。
	 * 
	 */
	public static boolean sendMail(String strMailTo, String strMailFrom, String strPasswd, String strRegistUrl, String strTemplateId, String strSiteId)
	{
		/*
		 * 入力チェック
		 */
		if (ValueUtil.nullToStr(strMailTo).equals(""))
		{
			log.error("宛先が指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}
		if (ValueUtil.nullToStr(strPasswd).equals(""))
		{
			log.error("仮パスワードが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}
		if (ValueUtil.nullToStr(strRegistUrl).equals(""))
		{
			log.error("本登録用のURLが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}
		if (ValueUtil.nullToStr(strTemplateId).equals(""))
		{
			log.error("仮登録用のメールテンプレートが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}

		/*
		 * 送信処理開始
		 */
		
		DBAccess objDbAccess = null;
		try
		{
			objDbAccess = new DBAccess();

			// システムプロパティを取得
			SystemProperties props = new SystemProperties(objDbAccess);
			
			// 引数の中のシステムプロパティ変数を解釈する
			strRegistUrl = props.replaceStr(strRegistUrl);
			if (strRegistUrl == null)
			{
				log.error("本登録URLの解釈に失敗しました。メール送信を中断します。");
				rollbackTempRegist(strMailTo); return false;
			}

			// メールテンプレートを準備する
			MailTemplateUtil objMailTemplate = new MailTemplateUtil(strTemplateId);
			if (! objMailTemplate.load(objDbAccess) )
			{
				log.error("メールテンプレートの読み込みに失敗しました。");
				rollbackTempRegist(strMailTo); return false;
			}

			// 各設定を取得
			strMailFrom = getMailSender (objMailTemplate , props , strMailFrom);
			if (strMailFrom == null)
			{
				log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
				rollbackTempRegist(strMailTo); return false;
			}
			
			//メール送信情報を設定する
			MailInfo objMailInfo = new MailInfo();
			objMailInfo.setMailTo(strMailTo);
			objMailInfo.setMailFrom(strMailFrom);
			objMailInfo.setMobileFlag(MailTemplateUtil.isMobileEmail(objDbAccess, strMailTo));
			objMailInfo.setSiteId(strSiteId);
			
			//件名情報を生成(件名の変数を置き換えるための変数を設定する)
			MailSubject objMailSubject = new MailSubject();
			
			//本文情報を生成(本文の変数を置き換えるための変数を設定する)
			MailBody objMailBody = new MailBody();
			objMailBody.setAuthUrl(strRegistUrl);
			objMailBody.setLoginUrl(strRegistUrl);
			objMailBody.setAuthPass(strPasswd);
			objMailBody.setLoginPass(strPasswd);
			objMailBody.setPassword(strPasswd);
			objMailBody.setEmail(strMailTo);
			
			return objMailTemplate.doReplaceAndMail(objMailSubject, objMailBody, objMailInfo);
		}
		catch (Exception e)
		{
			log.error("メール送信中に例外エラーが発生しました。" , e);
			rollbackTempRegist(strMailTo); return false;
		}
		finally
		{
			DBAccess.close(objDbAccess);
		}
	}
	
	
	/**
	 * 【メール送信処理共通化用】
	 * 会員登録簡略化していないステップサイト用の仮登録メールを送信する
	 * 引数のうち、fromとregistUrlの二つはシステムプロパティの指定が可能($$で囲む)
	 * 送信処理に成功したらtrue、失敗したらfalseを返す
	 * 
	 * @param mailto
	 * @param passwd
	 * @param registUrl
	 * @param templateId
	 * @param siteId
	 * @return
	 */
	public static boolean sendMailStepTempRegist(String strMailTo, String strPasswd, String strRegistUrl, String strTemplateId, String strSiteId)
	{
		/*
		 * 入力チェック
		 */
		if (ValueUtil.nullToStr(strMailTo).equals(""))
		{
			log.error("宛先が指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}
		if (ValueUtil.nullToStr(strPasswd).equals(""))
		{
			log.error("仮パスワードが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}
		if (ValueUtil.nullToStr(strRegistUrl).equals(""))
		{
			log.error("本登録用のURLが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}
		if (ValueUtil.nullToStr(strTemplateId).equals(""))
		{
			log.error("仮登録用のメールテンプレートが指定されませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}
		if (ValueUtil.nullToStr(strSiteId).equals(""))
		{
			log.error("仮登録時のサイトIDが指定されていませんでした。メール送信を中断します。");
			rollbackTempRegist(strMailTo); return false;
		}

		/*
		 * 送信処理開始
		 */
		DBAccess objDbAccess = null;
		try
		{
			objDbAccess = new DBAccess();

			// システムプロパティを取得
			SystemProperties props = new SystemProperties(objDbAccess);

			// 引数の中のシステムプロパティ変数を解釈する
			strRegistUrl = props.replaceStr(strRegistUrl);
			if (strRegistUrl == null)
			{
				log.error("本登録URLの解釈に失敗しました。メール送信を中断します。");
				rollbackTempRegist(strMailTo); return false;
			}

			// メールテンプレートを準備する
			MailTemplateUtil objMailTemplate = new MailTemplateUtil(strTemplateId);
			if (! objMailTemplate.load(objDbAccess) )
			{
				log.error("メールテンプレートの読み込みに失敗しました。");
				rollbackTempRegist(strMailTo); return false;
			}

			// サイト固有メールコンテンツの準備
			MailPerSiteContents perSiteContents = new MailPerSiteContents(strSiteId);
			if (! perSiteContents.load(objDbAccess))
			{
				log.error("サイト固有コンテンツ：サイトＩＤ：" + strSiteId + "の読み込みに失敗しました。");
				return false;
			}

			// 各設定を取得
			String strMailFrom = getMailSender (objMailTemplate , props , "$$MAIL_SENDER_OF_TEMPORARY_REGIST$$");
			if (strMailFrom == null) {
				log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
				rollbackTempRegist(strMailTo); return false;
			}
			
			//メール送信情報を設定する
			MailInfo objMailInfo = new MailInfo();
			objMailInfo.setMailTo(strMailTo);
			objMailInfo.setMailFrom(strMailFrom);
			objMailInfo.setMobileFlag(MailTemplateUtil.isMobileEmail(objDbAccess, strMailTo));
			objMailInfo.setSiteId(strSiteId);
			
			//件名情報を生成(件名の変数を置き換えるための変数を設定する)
			MailSubject objMailSubject = new MailSubject();
			
			//本文情報を生成(本文の変数を置き換えるための変数を設定する)
			MailBody objMailBody = new MailBody();
			objMailBody.setEmail(strMailTo);
			objMailBody.setAuthUrl(strRegistUrl);
			objMailBody.setLoginUrl(strRegistUrl);
			objMailBody.setPasswordAll(strPasswd);
			
			return objMailTemplate.doReplaceAndMail(objMailSubject, objMailBody, objMailInfo);
		}
		catch (Exception e)
		{
			log.error("メール送信中に例外エラーが発生しました。", e);
			rollbackTempRegist(strMailTo); return false;
		}
		finally
		{
			DBAccess.close(objDbAccess);
		}
	}
	
	/**
	 * 【メール送信処理共通化用】
	 * 仮登録用のメール送信者を取得する
	 * 
	 * @param template
	 * @param props
	 * @param from
	 * @return
	 */
	private static String getMailSender(MailTemplateUtil template , SystemProperties props , String from) {

		if (props == null) {
			log.error("システムプロパティオブジェクトがnullです。呼び出しが不正です。");
			return null;
		}

		String sender = "";

		if (template != null) {
			sender  = ValueUtil.nullToStr(template.getFrom());  // メールテンプレートのfromを最優先とする
		}

		if (sender.equals("")) {
			// メールテンプレートから送信者を取得できなかった場合、指定されたfromを使用する
			sender = ValueUtil.nullToStr (from);
		}
		
		if (sender.equals("")) {
			log.warn("MAIL_TEMPLテーブルにfromが指定されていないため、システムプロパティからデフォルト値を取得します。");
			sender = "$$MAIL_SENDER_OF_TEMPORARY_REGIST$$"; // メールテンプレートにも指定が無い場合、デフォルト値を使う
		}

		
		return  props.replaceStr(sender); // システムプロパティ変数を置換	
	}
}
