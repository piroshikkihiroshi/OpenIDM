package jp.co.webcrew.login.common;

import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;

public class MailSubject
{
	private Map hmapSubjectParam = null;
	
	/**
	 * コンストラクタ
	 */
	public MailSubject()
	{
		hmapSubjectParam = new HashMap();
	}
	
	/**
	 * コンストラクタ
	 * 
	 * @param objMemberMst
	 */
	public MailSubject(MemberMst objMemberMst)
	{
		hmapSubjectParam = new HashMap();
		
		setMemberName1(objMemberMst.get(MemberMst.NAME1));
		setMemberName2(objMemberMst.get(MemberMst.NAME2));
	}
	
	/**
	 * コンストラクタ
	 * 
	 * @param objDbAccess
	 * @param strGuid
	 * @throws Exception
	 */
	public MailSubject(DBAccess objDbAccess, String strGuid) throws Exception
	{
		hmapSubjectParam = new HashMap();
		
		MemberMst objMemberMst = new MemberMst(strGuid);
		if (!objMemberMst.load(objDbAccess))
		{
			setMemberName1("");
			setMemberName2("");
		}
		else
		{
			setMemberName1(objMemberMst.get(MemberMst.NAME1));
			setMemberName2(objMemberMst.get(MemberMst.NAME2));
		}
	}
	
	/**
	 * サイト名を保存する。
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strSiteName サイト名
	 */
//	public void setSiteName(String strSiteName)
//	{
//		hmapSubjectParam.put("\\$\\$site_name\\$\\$", ValueUtil.strToNull(strSiteName));
//	}
	
	/**
	 * 氏名(姓)を保存する。
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strMemberName1 氏名(姓)
	 */
	public void setMemberName1(String strMemberName1)
	{
		hmapSubjectParam.put("\\$\\$member_name1\\$\\$", ValueUtil.strToNull(strMemberName1));
	}
	
	/**
	 * 氏名(名)を保存する。
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strMemberName2 氏名(名)
	 */
	public void setMemberName2(String strMemberName2)
	{
		hmapSubjectParam.put("\\$\\$member_name2\\$\\$", ValueUtil.strToNull(strMemberName2));
	}
	
	/**
	 * 注文番号を保存する
	 * 
	 * @param lngPurchaseId
	 */
	public void setPurchaseId(long lngPurchaseId)
	{
		hmapSubjectParam.put("\\$\\$purchase_id\\$\\$", String.valueOf(lngPurchaseId));
	}
	
	/**
	 * 姓を保存する
	 * 
	 * @param strFamilyName
	 */
	public void setFamilyName(String strFamilyName)
	{
		hmapSubjectParam.put("\\$\\$family_name\\$\\$", strFamilyName);
	}
	
	/**
	 * 名を保存する
	 * 
	 * @param strFirstName
	 */
	public void setFirstName(String strFirstName)
	{
		hmapSubjectParam.put("\\$\\$first_name\\$\\$", strFirstName);
	}
	
	/**
	 * タイトルの変数を置き換えるための値を保持するマップを返す
	 * 
	 * @return
	 */
	public Map getSubjectParam()
	{
		return hmapSubjectParam;
	}

	
	
	/**
	 * タイトルの変数を保持するマップを設定する
	 * 
	 * @param hmapSubjectParam
	 */
//	public void setSubjectParam(HashMap hmapSubjectParam)
//	{
//		this.hmapSubjectParam = hmapSubjectParam;
//	}
}
