package jp.co.webcrew.phoenix.sstag.impl;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.store.util.SessionStoreUtil;

/**
 * ショートセッションを終了させるsstagクラス。
 * 
 * @author kurinami
 */
public class EndSessionExecuter extends SSTagExecuter {

    /** パラメータ名：ショートセッションID */
    private static final String ID_PARAM_KEY = "id";

    /** ロガー */
    private static final Logger log = Logger.getLogger(EndSessionExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    @SuppressWarnings("unchecked")
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            String id = ValueUtil.nullToStr(parameters.get(ID_PARAM_KEY)).toLowerCase();

            // このショートセッションのデータを削除する。
            SessionStoreUtil.removeAllAttribute(request, id);

            // TODO kurinami 【未実装】 ここ以外でのセッションストア情報の削除
            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

}
