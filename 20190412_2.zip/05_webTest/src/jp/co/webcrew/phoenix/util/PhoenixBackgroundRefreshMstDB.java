package jp.co.webcrew.phoenix.util;

import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.xml.soap.MessageFactory;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.loader.db.ClassRepositoryDb;
import jp.co.webcrew.loader.util.LoadUtil;

/****
 * RefreshMstDBの機能をPhoenixLogicStoreでも利用できるように実装したクラス
 * 
 * 
 * @author kazuto.yano
 *
 */
public class PhoenixBackgroundRefreshMstDB extends RefreshMstDb
{
	private static Logger logger=Logger.getLogger(PhoenixBackgroundRefreshMstDB.class);
	//private static PhoenixBackgroundRefreshMstDB instance=new PhoenixBackgroundRefreshMstDB();
	private Map<String,__BackgroundThread> mapKeyLogicIDValThread=new HashMap<String, PhoenixBackgroundRefreshMstDB.__BackgroundThread>();
	
	private WeakReference<ServletContext> servletContext=null;
	
	private boolean firstAction=false;
	
	private static final String SRV_CONTEXT_NAME=PhoenixBackgroundRefreshMstDB.class.getSimpleName()+"_HASHMAP_SPAN";
	private static final String SRV_CONTEXT_NAME_THIS=PhoenixBackgroundRefreshMstDB.class.getSimpleName()+"_OBJECT";
	
	
	private PhoenixBackgroundRefreshMstDB(ServletContext context)
	{
		super();
		this.servletContext=new WeakReference<ServletContext>(context);
		
	}
	
	public static PhoenixBackgroundRefreshMstDB getInstance(ServletContext servletConext)
	{
		PhoenixBackgroundRefreshMstDB thisObject;
		synchronized (servletConext)
		{
			thisObject=(PhoenixBackgroundRefreshMstDB)servletConext.getAttribute(SRV_CONTEXT_NAME_THIS);
			if(thisObject==null)
			{
				thisObject=new PhoenixBackgroundRefreshMstDB(servletConext);
				servletConext.setAttribute(SRV_CONTEXT_NAME_THIS, thisObject);
			}
			return thisObject;
		}
	}
	
	@Override
	public void init() 
	{
		//this.__refresh();
		this.refresh();
	}
	/*
	@Override
	public void run() 
	{
		while(true)
		{
			try
			{
				Thread.sleep(1000*60*60);
			}catch(Exception exc){}
			this.__refresh();
		}
	}
	*/
	
	private static void logging(String msg)
	{
		logger.info(msg);
	}
	
	
	private void refresh()
	{
		DBAccess dbAccess=null;
		ResultSet rset=null;
		try
		{
			logger.info("処理開始");
			dbAccess=new DBAccess("phoenix");
			Map<String,Map<String,String>> mapMetaData=this.getRefreshMetaData(dbAccess);
			this.refresh2(mapMetaData);
			logger.info("処理完了");
			
		}
		catch(Throwable th)
		{
			logger.error("処理失敗",th);
		}
		finally
		{
			DBAccess.close(dbAccess);
		}
	}
	
	/***
	 * 仮想テーブル「refresh_meta_mst」の内容を取得する
	 * 
	 * @param dbAccess
	 * @return
	 * @throws Exception
	 */
	private Map<String,Map<String,String>> getRefreshMetaData(DBAccess dbAccess)
	throws Exception
	{
		ResultSet rset=null;
		try
		{
			
			String sqlRecMeta="SELECT REC_ID FROM COMMON_PHOENIX.REC_META_DATA WHERE SITE_ID=800 AND TBL_ID='refresh_meta_mst' AND PUB_FLAG=1";
			String sqlClmData="SELECT CLM_ID,KEY_DATA FROM COMMON_PHOENIX.CLM_DATA WHERE SITE_ID=800 AND TBL_ID='refresh_meta_mst' AND REC_ID=?";
			dbAccess.prepareStatement(sqlRecMeta);
			rset=dbAccess.executeQuery();
			
			List<Long> listRecID=new ArrayList<Long>();
			
			while(rset.next())
			{
				listRecID.add(rset.getLong("REC_ID"));
			}
			DBAccess.close(rset);
			
			
			List<String> listThisIPAddress=this.getIPAddress();
			Map<String,Map<String,String>> mapMetaData=new HashMap<String,Map<String,String>>();
			
			for(long recId:listRecID)
			{
				dbAccess.prepareStatement(sqlClmData);
				dbAccess.setLong(1, recId);
				rset=dbAccess.executeQuery();
				Map<String,String> map_Key_ClmId_Val_ClmData=new HashMap<String, String>();
				while(rset.next())
				{
					map_Key_ClmId_Val_ClmData.put(rset.getString("CLM_ID"), rset.getString("KEY_DATA"));
				}
				
				String logicId=map_Key_ClmId_Val_ClmData.get("logic_id");
				String ipAddress=map_Key_ClmId_Val_ClmData.get("ip_address");
				
				//logicIDがNULLの場合、対象外
				if(logicId==null)
				{
					continue;
				}
				
				//IPAddressの制限があり、対象のIPAddressでない場合、対象外
				if(ipAddress!=null && listThisIPAddress.indexOf(ipAddress)==-1)
				{
					continue;
				}
				
				mapMetaData.put(logicId,map_Key_ClmId_Val_ClmData);
				
				DBAccess.close(rset);
				
			}
			return mapMetaData;
		}
		finally
		{
			DBAccess.close(rset);
		}
	}
	
	
	private void refresh2(Map<String,Map<String,String>> mapMetaData)
	{
		
		
		List<String> canDeleteKeyList=new ArrayList<String>(); 
		
		//既存のMAP分をチェック
		for(String logicID:this.mapKeyLogicIDValThread.keySet())
		{
			__BackgroundThread thread=this.mapKeyLogicIDValThread.get(logicID);
			Map<String,String> aMetaData=mapMetaData.get(logicID);
			//metadataが見つからない場合、スレッドを殺す
			if(aMetaData==null)
			{
				thread.doKill();
				//java.util.ConcurrentModificationExceptionをふせぐため
				//this.mapKeyLogicIDValThread.remove(logicID);
				canDeleteKeyList.add(logicID);
			}
			//metadataが見つかった場合、起動間隔を更新
			else
			{
				String strSpan=aMetaData.get("span");
				//TODO spanがNULLの可能性あり
				
				long spanMillSec=Integer.parseInt(strSpan)*60*1000;
				thread.setSpanMilliSec(spanMillSec);
				
			}
			//__BackgroundThread thread=this.mapKeyLogicIDValThread.get(logicID);
		}
		
		for(String logicID:canDeleteKeyList)
		{
			this.mapKeyLogicIDValThread.remove(logicID);
		}
		
		
		//新規登録分をチェック
		for(String logicID:mapMetaData.keySet())
		{
			Map<String,String> aMetaData=mapMetaData.get(logicID);
			__BackgroundThread thread=this.mapKeyLogicIDValThread.get(logicID);
			//スレッドが見つからない場合
			if(thread==null)
			{
				String strSpan=aMetaData.get("span");
				//TODO spanがNULLの可能性あり
				
				long spanMilliSec=Integer.parseInt(strSpan)*60*1000;
				thread=new __BackgroundThread(spanMilliSec, logicID);
				this.mapKeyLogicIDValThread.put(logicID, thread);
				Thread thread1=new Thread(thread);
				thread1.setDaemon(true);
				thread1.start();
				
			}
		}
		
		
	}
	
	
	private void __refresh() 
	{
		//TODO dbログインはphoenixユーザーにしたいところ
		DBAccess dbAccess=null;
		ResultSet rset=null;
		try
		{
			
			ServletContext servletContext=this.servletContext.get();
			HashMap<String, Date> beforeExecTimeMap=(HashMap<String, Date>)servletContext.getAttribute(SRV_CONTEXT_NAME);
			if(beforeExecTimeMap==null)
			{
				beforeExecTimeMap=new HashMap<String, Date>();
				servletContext.setAttribute(SRV_CONTEXT_NAME, beforeExecTimeMap);
			}
			
			dbAccess=new DBAccess("phoenix");
			String sqlFmt="SELECT * FROM PHOENIX.PH_REFRESH_META_MST WHERE (IP_ADDRESS IN ({0}) OR IP_ADDRESS IS NULL )AND INVALID_FLAG=0";
			
			
			String sqlRecMeta="SELECT REC_ID FROM COMMON_PHOENIX.REC_META_DATA WHERE SITE_ID=800 AND TBL_ID='refresh_meta_mst' AND PUB_FLAG=1";
			String sqlClmData="SELECT CLM_ID,KEY_DATA FROM COMMON_PHOENIX.CLM_DATA WHERE SITE_ID=800 AND TBL_ID='refresh_meta_mst' AND REC_ID=?";
			dbAccess.prepareStatement(sqlRecMeta);
			rset=dbAccess.executeQuery();
			
			List<Long> listRecID=new ArrayList<Long>();
			
			while(rset.next())
			{
				listRecID.add(rset.getLong("REC_ID"));
			}
			DBAccess.close(rset);
			
			
			List<String> listThisIPAddress=this.getIPAddress();
			
			
			for(long recId:listRecID)
			{
				dbAccess.prepareStatement(sqlClmData);
				dbAccess.setLong(1, recId);
				rset=dbAccess.executeQuery();
				Map<String,String> map_Key_ClmId_Val_ClmData=new HashMap<String, String>();
				while(rset.next())
				{
					map_Key_ClmId_Val_ClmData.put(rset.getString("CLM_ID"), rset.getString("KEY_DATA"));
				}
				DBAccess.close(rset);
				
				String logicId=map_Key_ClmId_Val_ClmData.get("logic_id");
				String span=map_Key_ClmId_Val_ClmData.get("span");
				String ipAddress=map_Key_ClmId_Val_ClmData.get("ip_address");
				
				//logicIDがNULLの場合、対象外
				if(logicId==null)
				{
					continue;
				}
				
				//IPAddressの制限があり、対象のIPAddressでない場合、対象外
				if(ipAddress!=null && listThisIPAddress.indexOf(ipAddress)==-1)
				{
					continue;
				}
				
				
				if(span!=null)
				{
					Date beforeExecTime=beforeExecTimeMap.get(logicId);
					if(beforeExecTime==null)
					{
						//logging(logicId+"/前回起動時間なし");
						beforeExecTimeMap.put(logicId, new Date());
					}
					else
					{
						Date nowTime=new Date();
						long spanNum=Long.parseLong(span)*60*1000;
						
						{
							
						{
							SimpleDateFormat df=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
							logging(
									"\r\n[現在日時]"+df.format(nowTime)+"\r\n"+
									"[前回日時]"+df.format(new Date(beforeExecTime.getTime())+"\r\n"+
									"[次回日時]"+new Date(beforeExecTime.getTime() + spanNum)));
						}	
						
						}
						if(nowTime.getTime() > (beforeExecTime.getTime() + spanNum))
						{
							logging(logicId+"/レンジ内");
							beforeExecTimeMap.put(logicId, nowTime);
						}
						//起動時間が一定期間未満の場合、対象外
						else
						{
							logging(logicId+"/レンジ外");
							continue;
						}
					}
				}
				
				//Class名取得
				String className=ClassRepositoryDb.getClassName(logicId);
				//オブジェクトを作成(LogicStoreから)
				Object obj=LoadUtil.newInstance(servletContext, className);
				
				if(obj instanceof PhoenixRefreshMstDB)
				{
					try
					{
						logging("start:"+logicId);
						((PhoenixRefreshMstDB)obj).init(servletContext);
						logging("finish:"+logicId);
					}
					catch(Exception exc2)
					{
						logger.error("abort:"+logicId,exc2);
					}
				}
				else
				{
					logging("cast_failure:"+logicId);
				}

				
				
			}
			
			
			
//			StringBuilder bld=new StringBuilder();
//			List<String> sqlParams=new ArrayList<String>();
//			//IPアドレスによる絞込み条件を設定
//			for(String ipAdr:this.getIPAddress())
//			{
//				bld.append("?,");
//				sqlParams.add(ipAdr);
//			}
//			
//			String sql=MessageFormat.format(sqlFmt, bld.substring(0,bld.length()-1));
//			dbAccess.prepareStatement(sql);
//			
//			int paramIndex=0;
//			for(String aSqlParam:sqlParams)
//			{
//				paramIndex++;
//				dbAccess.setString(paramIndex, aSqlParam);
//			}
//			rset=dbAccess.executeQuery();
//			
//			List<String> listLogicID=new ArrayList<String>();
//			
//			while(rset.next())
//			{
//				String logicId=rset.getString("LOGIC_ID");
//				String span=rset.getString("SPAN");
//				
//				boolean apply=false;
//				if(span==null)
//				{
//					logging(logicId+"/span nullのため");
//					apply=true;
//				}
//				else
//				{
//					Date beforeExecTime=beforeExecTimeMap.get(logicId);
//					if(beforeExecTime==null)
//					{
//						logging(logicId+"/前回起動時間なし");
//						
//						beforeExecTimeMap.put(logicId, new Date());
//						apply=true;
//					}
//					else
//					{
//						Date nowTime=new Date();
//						long spanNum=Long.parseLong(span)*60*1000;
//						
//						logging(nowTime+"/"+beforeExecTime+"+"+spanNum+"/"+
//								nowTime.getTime()+"/"+beforeExecTime.getTime());
//						
//						if(nowTime.getTime() > (beforeExecTime.getTime() + spanNum))
//						{
//							logging(logicId+"/レンジ内");
//							beforeExecTimeMap.put(logicId, nowTime);
//							apply=true;
//						}
//						else
//						{
//							logging(logicId+"/レンジ外");
//						}
//					}
//				}
//				
//				if(apply)
//				{
//					listLogicID.add(logicId);
//				}
//				
//			}
//			DBAccess.close(rset);
//			
//			for(String logicId:listLogicID)
//			{
//				String className=ClassRepositoryDb.getClassName(logicId);
//				Object obj=LoadUtil.newInstance(servletContext, className);
//				
//				if(obj instanceof PhoenixRefreshMstDB)
//				{
//					try
//					{
//						logging("start:"+logicId);
//						((PhoenixRefreshMstDB)obj).init(servletContext);
//						logging("finish:"+logicId);
//					}
//					catch(Exception exc2)
//					{
//						logger.error("abort:"+logicId,exc2);
//					}
//				}
//				else
//				{
//					logging("cast_failure:"+logicId);
//				}
//			}
//			
			
		}
		catch(Exception exc)
		{
			logger.error(exc.getMessage(),exc);
		}
		finally
		{
			DBAccess.close(rset);
			DBAccess.close(dbAccess);
		}
	}

	
	
	//private 
	
	/***
	 * 自ホストのIPアドレスを取得する
	 * 
	 */
	private List<String> getIPAddress()
	throws Exception
	{
		
		java.util.Enumeration enuIfs = NetworkInterface.getNetworkInterfaces();
		List<String> listIpAddress=new ArrayList<String>();
		if (null != enuIfs)
		{
		    while (enuIfs.hasMoreElements()) 
		    {
		        NetworkInterface ni = (NetworkInterface)enuIfs.nextElement();
		        //System.out.println("getDisplayName:\t" + ni.getDisplayName());
		        //System.out.println("getName:\t" + ni.getName());
		        java.util.Enumeration enuAddrs = ni.getInetAddresses();
		        while (enuAddrs.hasMoreElements()) 
		        {
		            InetAddress in4 = (InetAddress)enuAddrs.nextElement();
		            listIpAddress.add(in4.getHostAddress());
		        }
		    }
		}
		return listIpAddress;
	}
	
	private class __BackgroundThread implements Runnable
	{
		private long spanMilliSec;
		private boolean killFlag=false;
		private String logicId;
		
		__BackgroundThread(long spanMilliSec,String logicId)
		{
			this.spanMilliSec=spanMilliSec;
			this.logicId=logicId;
		}
		
		void doKill()
		{
			this.killFlag=true;
		}
		
		/***
		 * 実行間隔を指定する
		 * 
		 * @param spanMillSec ミリ秒単位
		 */
		void setSpanMilliSec(long spanMillSec)
		{
			this.spanMilliSec=spanMillSec;
		}
		
		@Override
		public void run() 
		{
			
			logging("threadを開始します:"+this.logicId);
			while(true)
			{
				logging("処理開始:"+this.logicId);
				
				//KILLフラグが有効の場合、処理終了
				//
				if(this.killFlag)
				{
					break;
				}
				
				ServletContext servletContext=PhoenixBackgroundRefreshMstDB.this.servletContext.get();
				
				try
				{
					//Class名取得
					String className=ClassRepositoryDb.getClassName(logicId);
					//オブジェクトを作成(LogicStoreから)
					Object obj=LoadUtil.newInstance(servletContext, className);
					logging("start:"+logicId);
					((PhoenixRefreshMstDB)obj).init(servletContext);
					logging("finish:"+logicId);
				}
				//コンパイルエラーなどでErrorをキャッチできていない＋そのままスレッドが死んでしまうので対応
				catch(Throwable exc2)
				{
					logger.error("abort:"+logicId,exc2);
				}
				
				logging("処理完了:"+this.logicId+"[停止時間]"+this.spanMilliSec);
				try
				{
					Thread.sleep(this.spanMilliSec);
				}catch(InterruptedException exc){}
				
			}
			logging("threadを終了します:"+this.logicId);
		}
		
		
	}
	
	/*
	//------------------------------------------
	//java.util.ConcurrentModificationException
	//の検証コード
	//------------------------------------------
	*   /
	public static void main(String[] args) 
	{
		HashMap<String, String> testMap=new HashMap<String, String>();
		
		testMap.put("1", "val1");
		testMap.put("2", "val2");
		testMap.put("3", "val3");
		testMap.put("4", "val4");
		
		int i=-1;
		for(String key:testMap.keySet())
		{
			i++;
			System.out.println("[before]"+key);
			if(i==2)
			{
				
				//testMap.remove(key);
				
			}
			System.out.println("[after]"+key);
		}
		
		
		
		
		
		
	}
	/*
	 */
}
