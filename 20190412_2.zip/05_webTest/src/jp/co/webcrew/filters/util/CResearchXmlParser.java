package jp.co.webcrew.filters.util;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import jp.co.webcrew.dbaccess.util.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class CResearchXmlParser {
  /** ロガー */
  private static final Logger log = Logger.getLogger(CResearchXmlParser.class);
  
  /**
   * アンケートXMLを取得しアンケート項目ごとにマップに保存しリストで返す
   * 
   * @return
   * @throws Exception
   */
  public static List parser(String enquetesXml) {
    
    List allEnquetesList = new ArrayList();
    
    try {
      //ドキュメントビルダーファクトリを生成
      DocumentBuilderFactory dbfactory = DocumentBuilderFactory.newInstance();
      // ドキュメントビルダーを生成
      DocumentBuilder builder = dbfactory.newDocumentBuilder();
      // enqXmlをInputStreamに変換し、解析
      Document doc = builder.parse(new ByteArrayInputStream(enquetesXml.getBytes("Shift_JIS")));
            
      // ルート要素を取得（タグ名enquetes）
      Element root = doc.getDocumentElement();
            
      // enquete要素のリストを取得
      NodeList list = root.getElementsByTagName("enquete");
      // enquete要素の数だけループ
      for(int i=0; i < list.getLength() ; i++) {
        
        //CResearchEnqueteBean bean = new CResearchEnqueteBean();
        Map enqueteMap = new HashMap();
                
        //enquete要素を取得
        Element element = (Element)list.item(i);
        
        //(1)アンケート番号を設定
        enqueteMap.put("id", new Integer(element.getAttribute("id")));
        
        //(2)項目の入力タイプを設定
        enqueteMap.put("style", getXmlNodeValue(element, "style"));
                
        //(3)タイトルを設定
        enqueteMap.put("title", getXmlNodeValue(element, "title"));
        
        //(4)質問文を設定
        enqueteMap.put("question", getXmlNodeValue(element, "question"));
        
        //(5)質問に対する回答番号と回答分を設定する
        NodeList optsList = element.getElementsByTagName("options");
        Element optsElement = (Element)optsList.item(0);
        NodeList optList = optsElement.getElementsByTagName("option");
        
        Map optionsMap = new LinkedHashMap();
        for(int optIndex=0; optIndex<optList.getLength(); optIndex++) {
          // option要素を取得
          Element optElement = (Element)optList.item(optIndex);
          
          //項目名を設定
          optionsMap.put((String)optElement.getAttribute("id"), (String)optElement.getFirstChild().getNodeValue());
          
          //Enqueteオブジェクトに格納
          enqueteMap.put("options", optionsMap); 
        }
        
        //(6)投票数を設定する(初期値０)
        enqueteMap.put("voteCount", new Integer("0"));

        //(7)掲載開催年月日を設定する
        enqueteMap.put("startDate", getXmlNodeValue(element, "startDate"));
        
        //(8)掲載終了年月日を設定する
        enqueteMap.put("endDate", getXmlNodeValue(element, "endDate"));
        
        //(9)質問文の詳細を設定
        //enqueteMap.put("pullQuote", getXmlNodeValue(element, "pullQuote"));
        
        //(10)カテゴリIDを設定
        enqueteMap.put("categoryId", getXmlNodeValue(element, "categoryId"));
        
        //(11)NEWマーク表示開始年月日を取得する
        enqueteMap.put("newStartDate", getXmlNodeValue(element, "newStartDate"));
        
        //(12)NEWマーク表示終了年月日
        enqueteMap.put("newEndDate", getXmlNodeValue(element, "newEndDate"));
        
        allEnquetesList.add(enqueteMap);
      }
    } catch (Exception e) {
      log.error("予期せぬエラー", e);
    }
    
    return allEnquetesList;
  }
  
  /**
   * key要素のリストを取得し最初の子ノードを取得する
   * 
   * @param element
   * @param key
   * @return
   */
  private static String getXmlNodeValue(Element element, String key) {
    NodeList node = element.getElementsByTagName(key);
    Element child = (Element)node.item(0);
    
    if(child == null) {
      return "";
    }
    
    if(child.getFirstChild() == null) {
      return "";
    } else {
      return child.getFirstChild().getNodeValue();
    }
  }
}
