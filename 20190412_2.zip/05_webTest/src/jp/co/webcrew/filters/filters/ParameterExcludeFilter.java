package jp.co.webcrew.filters.filters;

import java.io.IOException;
import java.util.Enumeration;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

/**
 * Strutsの脆弱性に対するパッチです。
 * 
 * @author satoshi.moriya
 *
 */
public class ParameterExcludeFilter implements Filter{
    /** パラメータ名に含まれていた場合、除外するパターン */
    private static Pattern EXLUDE_PARAMS = Pattern.compile("(^|\\W)([cC]lass|[cC]lass[lL]oader)\\W");
    
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse res,
            FilterChain filter) throws IOException, ServletException {
        HttpServletRequest httpreq = (HttpServletRequest)req;
        Enumeration<?> params = httpreq.getParameterNames();
        while (params.hasMoreElements()) {
            String paramName = (String) params.nextElement();
            if (isAttack(paramName)) {
                throw new IllegalArgumentException("Attack: " + paramName);
            }
        }
        Cookie cookies[] = httpreq.getCookies();
        if (cookies != null) {
            for  (Cookie c : cookies) {
                String cookieName = c.getName();
                if (isAttack(cookieName)) {
                    throw new IllegalArgumentException("Attack: " + cookieName);
                }
            }
        }
        filter.doFilter(req, res);
    }
    
    private static boolean isAttack(String target) {
    	
        return EXLUDE_PARAMS.matcher(target).find();
    }

    public void init(FilterConfig arg0) throws ServletException {}
}  