package jp.co.webcrew.phoenix.sstag.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * ショートセッションの宣言をするsstagクラス。
 * 
 * @author kurinami
 */
public class StartSessionExecuter extends SSTagExecuter {

    /** パラメータ名：ショートセッションID */
    private static final String ID_PARAM_KEY = "id";

    /** パラメータ名：セッションデータ保持範囲 */
    private static final String LIFE_PARAM_KEY = "life";

    /** ロガー */
    private static final Logger log = Logger.getLogger(StartSessionExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    @SuppressWarnings("unchecked")
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String id = ValueUtil.nullToStr(parameters.get(ID_PARAM_KEY)).toLowerCase();
            String life = ValueUtil.nullToStr(parameters.get(LIFE_PARAM_KEY));

            // この時点までに登録されているphoenix用の置換変数を削除する。
            StoreUtil.removePhoenixReplaceParam(request);

            // このショートセッションをカレントにする。
            StoreUtil.setCurrent(request, id, life);

            // セッションストアで保持しているフォームデータを取得する。
            PostInfo postInfo = StoreUtil.getPostInfo(request);
            if (postInfo == null) {
                postInfo = new PostInfo();
            }

            // TODO kurinami 【確認】 postのときだけ？
            // リクエストパラメータで更新する。
            Map<String, String[]> parameterMap = (Map<String, String[]>) request.getParameterMap();
            parameterMap = parseParam(parameterMap);
            for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
                // TODO kurinami 【未実装】 fileパラメータ
                postInfo.postItemMap.put(entry.getKey(), entry.getValue());
            }

            // セッションストアにフォームデータを格納し直す。
            StoreUtil.setPostInfo(request, postInfo);

            // グローバルオーダーIDを置換パラメータに登録する。
            SstagUtil.setGoidReplaceParam(request);

            // handorver情報を置換パラメータに登録する。
            SstagUtil.setHandoverReplaceParam(request);

            // スクリーニング結果を置換パラメータに登録する。
            for (Map.Entry<String, Map<String, Map<String, Object[]>>> entry : StoreUtil.getAllScreeningResult(request)
                    .entrySet()) {
                SstagUtil.setScreeningResultReplaceParam(request, entry.getKey(), entry.getValue());
            }

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * ###.1 ###.2 ###.3 という形式のパラメータを ### というパラメータ名の1組の値と認識するように置き換える。
     * 
     * @param parameterMap
     * @return
     */
    private static Map<String, String[]> parseParam(Map<String, String[]> parameterMap) {

        Map<String, String[]> tmp = new HashMap<String, String[]>(parameterMap);

        List<String> list = new ArrayList<String>();
        for (Map.Entry<String, String[]> entry : tmp.entrySet()) {
            String key = entry.getKey();
            if (key.endsWith(".1")) {
                list.add(key.substring(0, key.length() - ".1".length()));
            }
        }

        for (String key : list) {
            List<String> valueList = new ArrayList<String>();
            for (int i = 1; tmp.containsKey(key + "." + i); i++) {
                String[] values = tmp.remove(key + "." + i);
                valueList.add(PhoenixUtil.isEmpty(values) ? "" : values[0]);
            }
            tmp.put(key, valueList.toArray(new String[0]));
        }

        return tmp;
    }

    public static void main(String[] args) {
        Map<String, String[]> test = new HashMap<String, String[]>();
        test.put("test1", new String[] { "test1_1", "test1_2" });
        test.put("test2.1", new String[] { "test2_1" });
        test.put("test2.2", new String[] { "test2_2" });
        test.put("test3", new String[] { "test1_1", "test1_2", "test1_3" });
        test.put("test4.1", new String[] { "test4_1" });
        test.put("test4.2", new String[] { "test4_2" });
        test.put("test4.3", new String[] { "test4_3" });

        Map<String, String[]> result = parseParam(test);
        for (Map.Entry<String, String[]> entry : result.entrySet()) {
            System.out.println("[" + entry.getKey() + "][" + PhoenixUtil.concat(entry.getValue(), ",") + "]");
        }
    }
}
