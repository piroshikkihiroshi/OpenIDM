package jp.co.webcrew.phoenix.logic;

import java.util.List;
import java.util.Map;

import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormItem;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * 動的に呼び出されるlogicの基底クラス。
 * 
 * @author kurinami
 */
abstract public class SstagDynamicLogic {

    /**
     * 汎用ロジックバインディング
     * 
     * @param sgInfo
     *            共通情報
     * @param sstagParam
     *            sstagの通常の引数
     * @param userParam
     *            sstag内でロジックをコールする際に書かれた追加の引数
     * @param formInfo
     *            form定義情報。 DBで定義され formにマップされる構造情報
     * @param postInfo
     *            form入力情報。 入力された(postされた)データのマップ 項目名,値の組み合わせ
     * @param formUseInfo
     *            フォーム定義の中で使用するグループと項目を個別に指定
     * @return
     */
    abstract public BindLogicStdStatus stdLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
            List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo);

    /**
     * バリデーションチェックおよびスクリーニングロジック
     * 
     * @param sgInfo
     *            共通情報
     * @param sstagParam
     *            sstagの通常の引数
     * @param userParam
     *            sstag内でロジックをコールする際に書かれた追加の引数
     * @param formInfo
     *            form定義情報。 DBで定義され formにマップされる構造情報
     * @param postInfo
     *            form入力情報。 入力された(postされた)データのマップ 項目名,値の組み合わせ
     * @param formUseInfo
     *            フォーム定義の中で使用するグループと項目を個別に指定
     * @param sortReq
     *            結果の並べ替え指定
     * @param vResult
     *            前回のバリデーション結果（初回の場合はNULL)
     * @param sResult
     *            前回のスクリーニング結果（初回の場合はNULL)
     * @param auxResult
     *            前回の補助結果 (初回の場合は NULL)
     * @param doValidation
     *            バリデーションを実行する(=true) しない(=false)
     * @param doScreening
     *            スクリーニングを実行する(=true) しない(=false)
     * @return
     */
    abstract public BindLogicExtStatus validationLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
            List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
            SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
            Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening);

    /**
     * 条件判断ロジック
     * 
     * @param sgInfo
     *            共通情報
     * @param sstagParam
     *            sstagの通常の引数
     * @param userParam
     *            sstag内でロジックをコールする際に書かれた追加の引数
     * @param formInfo
     *            form定義情報。 DBで定義され formにマップされる構造情報
     * @param postInfo
     *            form入力情報。 入力された(postされた)データのマップ 項目名,値の組み合わせ
     * @param formUseInfo
     *            フォーム定義の中で使用するグループと項目を個別に指定
     * @param sortReq
     *            結果の並べ替え指定
     * @param vResult
     *            前回のバリデーション結果（初回の場合はNULL)
     * @param sResult
     *            前回のスクリーニング結果（初回の場合はNULL)
     * @param auxResult
     *            前回の補助結果 (初回の場合は NULL)
     * @param doValidation
     *            バリデーションを実行する(=true) しない(=false)
     * @param doScreening
     *            スクリーニングを実行する(=true) しない(=false)
     * @return
     */
    // TODO kurinami 【確認】
    // jedgementにsortReq/vResult/sResult/auxResult/doValidation/doScreeningはいる？
    abstract public JudgementLogicStatus judgementLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
            List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
            SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
            Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening);

    /**
     * 
     * @param sgInfo
     *            共通情報
     * @param sstagParam
     *            sstagの通常の引数
     * @param userParam
     *            sstag内でロジックをコールする際に書かれた追加の引数
     * @param formInfo
     *            form定義情報。 DBで定義され formにマップされる構造情報
     * @param postInfo
     *            form入力情報。 入力された(postされた)データのマップ 項目名,値の組み合わせ
     * @param formUseInfo
     *            フォーム定義の中で使用するグループと項目を個別に指定
     * @param sub1
     *            サブパラメータ１
     * @param sub2
     *            サブパラメータ２
     * @param result
     *            結果項目ID
     * @return
     */
    abstract public ItemConvLogicStatus itemConvLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
            List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String sub1,
            String sub2, String result);

    /**
     * フォーム項目が処理の対象であるかをチェックする。
     * 
     * @param formUseInfo
     * @param formItem
     * @return
     */
    public static boolean isTargetItem(FormUseInfo formUseInfo, String itemId, String groupId) {
        if ((PhoenixUtil.isEmpty(formUseInfo.groupId) || PhoenixUtil.contains(formUseInfo.groupId, groupId) || PhoenixUtil
                .contains(formUseInfo.includeItemId, itemId))
                && !PhoenixUtil.contains(formUseInfo.excludeItemId, itemId)) {
            return true;
        } else {
            return false;
        }
    }

}
