package jp.co.webcrew.phoenix.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * このプロジェクト用のutilクラス。
 * 
 * @author kurinami
 */
public class PhoenixUtil {

    /** ロガー */
    private static final Logger log = Logger.getLogger(PhoenixUtil.class);

    /**
     * 文字列が空かをチェックする。
     * 
     * @param source
     * @return
     */
    public static boolean isEmpty(String source) {
        return source == null || source.trim().length() == 0;
    }

    /**
     * バイト配列が空かをチェックする。
     * 
     * @param source
     * @return
     */
    public static boolean isEmpty(byte[] source) {
        return source == null || source.length == 0;
    }

    /**
     * 配列が空かをチェックする。
     * 
     * @param source
     * @return
     */
    public static boolean isEmpty(Object[] source) {
        return source == null || source.length == 0;
    }

    /**
     * コレクションが空かをチェックする。
     * 
     * @param collection
     * @return
     */
    public static boolean isEmpty(Collection<?> collection) {
        return collection == null || collection.size() == 0;
    }

    /**
     * マップが空かをチェックする。
     * 
     * @param map
     * @return
     */
    public static boolean isEmpty(Map<?, ?> map) {
        return map == null || map.size() == 0;
    }

    /**
     * 文字列配列が空、もしくはすべての要素が空かをチェックする。
     * 
     * @param values
     * @return
     */
    public static boolean isArrayEmpty(String[] values) {
        if (isEmpty(values)) {
            return true;
        }
        for (String value : values) {
            if (!isEmpty(value)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 文字列が一覧の中に含まれているかをチェックする。
     * 
     * @param list
     *            一覧
     * @param value
     *            文字列
     * @return
     */
    public static boolean contains(String[] list, String value) {

        if (isEmpty(value)) {
            return false;
        }

        for (String tmp : list) {
            if (tmp.equals(value)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 文字列の配列を、連結する。
     * 
     * @param values
     * @param sep
     * @return
     */
    public static String concat(String[] values, String sep) {
        if (PhoenixUtil.isEmpty(values)) {
            return "";
        }
        return ValueUtil.concat(Arrays.asList(values), sep);
    }

    /**
     * 文字列の配列を連結する。ただし、すべてのデータが空だった場合には、空文字列を返す。
     * 
     * @param values
     * @param sep
     * @return
     */
    public static String dataCat(String[] values, String sep) {
        if (PhoenixUtil.isArrayEmpty(values)) {
            return "";
        }
        return concat(values, sep);
    }
    
    /**
     * 文字列から部分文字列を抜き出す。
     * 
     * @param source
     * @param beginIndex
     * @return
     */
    public static String substring(String source, int beginIndex) {
        if (isEmpty(source) || source.length() < beginIndex) {
            return "";
        }
        return source.substring(beginIndex);
    }

    /**
     * 文字列から部分文字列を抜き出す。
     * 
     * @param source
     * @param beginIndex
     * @param endIndex
     * @return
     */
    public static String substring(String source, int beginIndex, int endIndex) {
        if (isEmpty(source) || source.length() < beginIndex) {
            return "";
        }

        if (source.length() < endIndex) {
            return source.substring(beginIndex);
        } else {
            return source.substring(beginIndex, endIndex);
        }
    }

    /**
     * 文字列をtrimをかけながら、分割する。
     * 
     * @param source
     * @param sep
     * @return
     */
    public static String[] split(String source, String sep) {

        if (PhoenixUtil.isEmpty(source)) {
            return new String[0];
        }

        String[] temp = source.trim().split("\\Q" + sep + "\\E");

        List<String> list = new ArrayList<String>();
        for (String value : temp) {
            value = value.trim();
            if (value.length() > 0 || sep.trim().length() > 0) {
                list.add(value);
            }
        }

        return list.toArray(new String[0]);

    }

    /**
     * 文字列の先頭から指定されたバイト数分取りだす。
     * 
     * @param source
     * @param byteLength
     * @return
     */
    public static String getLeft(String source, int byteLength) {

        if (PhoenixUtil.isEmpty(source)) {
            return "";
        }

        try {
            int size = 0;
            int index = 0;

            for (; index < source.length(); index++) {
                String ch = source.substring(index, index + 1);
                int temp = ch.getBytes("utf-8").length;
                if (size + temp > byteLength) {
                    break;
                }
                size += temp;
            }

            return source.substring(0, index);

        } catch (UnsupportedEncodingException e) {
            log.error("予期せぬエラー", e);
            return "";
        }

    }

    /**
     * 文字列が何バイトかを返す。
     * 
     * @param source
     * @return
     */
    public static int getByteLength(String source) {
        try {
            return ValueUtil.nullToStr(source).getBytes("utf-8").length;
        } catch (UnsupportedEncodingException e) {
            log.error("予期せぬエラー", e);
            return 0;
        }
    }

    /**
     * 文字列の1文字目を返す。
     * 
     * @param source
     * @return
     */
    public static char tochar(String source) {
        if (isEmpty(source)) {
            return ' ';
        } else {
            return source.charAt(0);
        }
    }

    /**
     * テストモードかを返す。
     * 
     * @return
     */
    public static boolean isTestMode() {
        return ValueUtil.nullToStr(System.getProperty("testMode")).equals("1");
    }
}
