package jp.co.webcrew.login.common.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.DBException;
import jp.co.webcrew.login.common.db.util.Record;

public class SiteSession {
	
	public static final String LOGIN_OK = "1";
	public static final String LOGOFF = "0";
	public static final String PROP_USER_ID = "_userId";	
	public static final String PROP_REQUEST_ID = "_requestId";	

    
	DBAccess _db;
	

	/** ロガー */
	private static Logger log = Logger.getLogger(SiteSession.class);

	private String ssid_ = "";
	private String gsid_ = "";
	
	/** デフォルトコンストラクタは不可視とする */
	private SiteSession(){}

	/**
	 * gsidを元にサイトセッションオブジェクトを生成する
	 * @param db
	 * @param gsid
	 */
	public SiteSession(DBAccess db,String gsid) throws SQLException{
	
	   /** GS_IDを元にサイトセッションIDを取得するsql */
	    String SELECT_BY_GS_CODE = 
			"select ssid "
			+ " from "
			+ "  site_session ss "
			+ " where "
			+ "  ss.gsid = ? ";
//			+ " and "
//			+ "  ss.last_datetime > to_char(sysdate - 1, 'YYYYMMDDHH24MISS') ";

		_db = db;
		setGsId(gsid);
		ResultSet rs = null;
		try{
			db.prepareStatement(SELECT_BY_GS_CODE);
			db.setString(1, gsid);
			rs = db.executeQuery();
			if (db.next(rs)) {
				ssid_ = ValueUtil.nullToStr(rs.getString("ssid"));
			} else {
				log.error("ssidが見つかりません。");
				throw new DBException("ssidの取得に失敗しました。");
			}
			
		} catch(SQLException e){
			// 例外エラー
			log.error("シーケンス取得中にデータベースエラーが発生しました。",e);
			throw e;
			
		} finally {
			DBAccess.close(rs);
		}		
		
	}

	/**
	 * サイトセッションプロパティの値を取得する
	 * @param key プロパティのキー
	 * @return
	 * @throws SQLException
	 */
	public String readProperty(String key) throws SQLException{
		String ssid = ValueUtil.nullToStr(getSsId());
		
		if ( ssid.equals("") ) {
			log.info("ユーザのSSIDが見つかりませんでした。");
			return null;
		}

		String sql = "SELECT VALUE FROM SITE_SESSION_PROPS WHERE SSID = ? AND NAME = ?";
		DBAccess db = getDb();
		db.prepareStatement(sql);
		db.setString(1	, ssid);
		db.setString(2	, key);
		Record rec = Record.getFirstRowOf(db);
		
		if (rec == null) {
			return null;
		} else {
			return rec.getString("VALUE");
		}
		
	}
	
	/**
	 * サイトセッションプロパティの値を削除する
	 * @param key プロパティのキー
	 * @return
	 * @throws SQLException
	 */
	public boolean removeProperty(String key) {
		String ssid = ValueUtil.nullToStr(getSsId());
		
		if ( ssid.equals("") ) {
			log.info("ユーザのSSIDが見つかりませんでした。");
			return false;
		}

		try {
			String sql = "DELETE FROM SITE_SESSION_PROPS WHERE SSID = ? AND NAME = ?";
			DBAccess db = getDb();
			db.prepareStatement(sql);
			db.setString(1	, ssid);
			db.setString(2	, key);
			
			db.executeUpdate();
			
			return true;

		} catch (Exception e) {

			log.error("サイトセッションの削除中に例外エラーが発生しました。" , e);
			return false;
		}
	
	}	
	
	
	/**
	 * サイトセッションのプロパティをセットする
	 * @param key プロパティ名
	 * @param value プロパティ値
	 * @param siteId クライアントが利用中のアプリケーションのサイトID どのサイトから値をセットしたかを残す
	 */
	public void writePropertyToDB(String key,String value,String siteId) throws SQLException{
		
		if (siteId == null) siteId = "";
		
		String ssid = getSsId();
		String gsid = getGsId();

		//keyによる列が存在するか否かを確認
		
		String sql = "select ssid from site_session_props where ssid = ? and name = ?";
		ResultSet rs = null;
		try{
			_db.prepareStatement(sql);
			_db.setString(1	, ssid);
			_db.setString(2	, key);
			rs = _db.executeQuery();
			if(_db.next(rs)){
				// 既にプロパティが存在するので、上書きする
				sql = "update site_session_props set gsid=?,value=?,site_id=? where ssid=? and name=?";
				_db.prepareStatement(sql);
				_db.setString(1	, gsid);
				_db.setString(2	, value);
				_db.setString(3	, siteId);
				_db.setString(4	, ssid);
				_db.setString(5	, key);
				_db.executeUpdate();
					
			} else {
				// プロパティを登録（INSERT)する
				sql = "insert into site_session_props(ssid,gsid,name,value,site_id) values(?,?,?,?,?) ";
				_db.prepareStatement(sql);
				_db.setString(1	, ssid);
				_db.setString(2	, gsid);
				_db.setString(3	, key);
				_db.setString(4	, value);
				_db.setString(5	, siteId);
				_db.executeUpdate();
			
			}
		} catch(SQLException e){
			// 例外エラー
			log.error("DBエラーが発生しました。",e);
			throw e;
			
		} finally {
			DBAccess.close(rs);
		}			
		
	}

	public String getGsId() {
		return gsid_;
	}

	public void setGsId(String gsid) {
		this.gsid_ = gsid;
	}

	public String getSsId() {
		return ssid_;
	}

	public void setSsId(String ssid) {
		this.ssid_ = ssid;
	}
	public void setLoginFlg(String flg) throws SQLException{
		// ログイン済みフラグを立てる
		try{
		String sql = "update site_session set login_flag=? where ssid=?";
			_db.prepareStatement(sql);
			_db.setString(1, flg);
			_db.setString(2, getSsId());
			_db.executeUpdate();
		} catch(SQLException e){
			// 例外エラー
			log.error("DBのログインフラグ更新に失敗しました。",e);
			throw e;
			
		} finally {
			//
		}			
	}
	public static void setLoginFlgOn(DBAccess db , String gsid) throws SQLException { 
		// ログイン済みフラグを立てる
		String sql = "update site_session set login_flag=? where gsid=?";
		db.prepareStatement(sql);
		db.setString(1, LOGIN_OK);
		db.setString(2, gsid);
		db.executeUpdate();
	}

	public static void setLoginFlgOff(DBAccess db , String gsid) throws SQLException { 
		// ログイン済みフラグをオフにする
		String sql = "update site_session set login_flag=? where gsid=?";
		db.prepareStatement(sql);
		db.setString(1, LOGOFF);
		db.setString(2, gsid);
		db.executeUpdate();
	}
	
	private DBAccess getDb() {
		return _db;
	}
}
