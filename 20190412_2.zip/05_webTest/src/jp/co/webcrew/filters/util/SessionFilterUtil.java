package jp.co.webcrew.filters.util;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.db.TermMstDb;
import jp.co.webcrew.filters.filters.session.MemberMstDb;
import jp.co.webcrew.filters.filters.session.UserInfo;

/**
 * フィルタ外でSessioniFilter関連の機能を使うためのutilクラス。
 * 
 * @author kurinami
 */
public class SessionFilterUtil {

	/** ロガー */
	private static final Logger log = Logger.getLogger(SessionFilterUtil.class);

	/**
	 * SSIDを返す。
	 * 
	 * @param request
	 * @return
	 */
	public static String getSsid(HttpServletRequest request) {
		return ValueUtil
				.nullToStr(request.getAttribute(UserInfo.SSID_ATTR_KEY));
	}
     
	/**
	 * GSIDを返す。
	 * 
	 * @param request
	 * @return
	 */
	public static String getGsid(HttpServletRequest request) {
		return ValueUtil
				.nullToStr(request.getAttribute(UserInfo.GSID_ATTR_KEY));
	}

	/**
	 * GUIDを返す。
	 * 
	 * @param request
	 * @return
	 */
	public static String getGuid(HttpServletRequest request) {
		return ValueUtil
				.nullToStr(request.getAttribute(UserInfo.GUID_ATTR_KEY));
	}

	/**
	 * ニックネームを返す。
	 * 
	 * @param request
	 * @return
	 */
	public static String getNickname(HttpServletRequest request) {
		return ValueUtil.nullToStr(request
				.getAttribute(UserInfo.MEMBER_MST_NICKNAME_ATTR_KEY));
	}

	/**
	 * メンバマスタの値を返す。
	 * 
	 * @param request
	 * @param columnName
	 * @return
	 */
	public static String getMemberMst(HttpServletRequest request,
			String columnName) {
		return ValueUtil.nullToStr(request.getAttribute(UserInfo.MEMBER_MST
				+ columnName));
	}

	/**
	 * ログインフラグを返す。
	 * 
	 * @param request
	 * @return
	 */
	public static String getLoginFlag(HttpServletRequest request) {
		return ValueUtil.nullToStr(request
				.getAttribute(UserInfo.LOGIN_FLAG_ATTR_KEY));
	}

	/**
	 * ログイン済みであるかを返す。
	 * 
	 * @param request
	 * @return
	 */
	public static boolean isLogined(HttpServletRequest request) {
		String flg = getLoginFlag(request);
		if (flg.equals("t")) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 登録済みであるかを返す。
	 * 
	 * @return
	 */
	public static boolean isFormal(HttpServletRequest request) {
		String flg = ValueUtil.nullToStr(request
				.getAttribute(UserInfo.MEMBER_MST_FORMAL_FLAG_ATTR_KEY));
		if (flg.equals("t")) {
			return true;
		} else {
			return false;
		}
	} 

	/**
	 * 携帯からのアクセスかを返す。
	 * 
	 * @param request
	 * @return true 携帯からのアクセスである
	 * @return false 携帯からのアクセスでない
	 */
	public static boolean fromMobile(HttpServletRequest request) {

		// TODO kurinami 【重要】<- ここおかしい。
		String testMobile = SystemPropertiesDb.getInstance().get("");
		if (ValueUtil.nullToStr(testMobile).equals("1")) {
			log.info("システムプロパティのテスト設定により、強制的に携帯端末からのアクセスと見なします。");
			return true;
		}

		// フィルタからuseragentを元に判定する
		String carrier = ValueUtil.nullToStr(request
				.getAttribute(UserInfo.SITE_MST_CARRIER_ATTR_KEY));
		// Issue0038980 クローラーからの対応、carrierのデフォルト値は空文字「""」のため、空文字の判断は追加しました。
		if (carrier .equals("")) {
			log.info("端末情報が見つかりませんでした。");
			return false;
		}

		if (carrier.equals(TermMstDb.TYPE_PC_BROWSER)) {
			log.info("PC端末からのアクセスが認識されました。");
			return false;
		} else {
			log.info("携帯端末からのアクセスが認識されました。");
			return true;
		}
	}

	/**
	 * gsidが妥当か否かを調べる
	 * 
	 * @param gsid
	 * @return
	 */
	public static boolean isValidGsid(String gsid) {
		if (gsid == null || gsid.equals("") || gsid.equals("0")
				|| gsid.equals("-1")) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * guidが妥当か否かを調べる
	 * 
	 * @param guid
	 * @return
	 */
	public static boolean isValidGuid(String guid) {
		if (guid == null || guid.equals("") || guid.equals("0")
				|| guid.equals("-1")) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * サイトセッション属性を取得する。
	 * 
	 * @param request
	 * @param name
	 * @return
	 */
	public static String getSiteSessionProps(HttpServletRequest request,
			String name) {
		String value = ValueUtil.nullToStr(request
				.getAttribute(UserInfo.SS_PROPS + name));
		return value;
	}

	/**
	 * サイトセッション属性を設定する。
	 * 
	 * @param request
	 * @param name
	 * @param value
	 * @throws SQLException
	 */
	public static void setSiteSessionProps(HttpServletRequest request,
			String name, String value) throws SQLException {
		int ssid = ValueUtil.toint(getSsid(request));
		int gsid = ValueUtil.toint(getGsid(request));
		int siteId = SiteMstDb.getInstance().getSiteId(
				request.getRequestURL().toString());

		MemberMstDb.writeSiteSessionProps(ssid, gsid, name, value, siteId);
		request.setAttribute(UserInfo.SS_PROPS + name, value);
	}

	/**
	 * サイトセッション属性を削除する。
	 * 
	 * @param request
	 * @param name
	 * @throws SQLException
	 */
	public static void removeSiteSessionProps(HttpServletRequest request,
			String name) throws SQLException {
		int ssid = ValueUtil.toint(getSsid(request));

		MemberMstDb.removeSiteSessionProps(ssid, name);
		request.removeAttribute(UserInfo.SS_PROPS + name);
	}
}
