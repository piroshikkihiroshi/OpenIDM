﻿Imports WHandleTool.commonFunc
Imports Microsoft.Office.Core       'Project menu, Add references
Imports Microsoft.Office.Interop.Excel

Public Class ExcelCnt

    Function ExcelOutPut(ByRef objTgtTable_i)
        Dim objWorkBook As Object = Nothing
        Dim objExcel As Object = Nothing
        Dim objSheet As Object = Nothing

        Dim range As Object = Nothing
        Dim range1 As Object = Nothing
        Dim range2 As Object = Nothing
        Dim objComFn As New commonFunc

        Dim tmpPath As String
        Dim fname As String
        Dim timestamp As String

        'Const even As MidpointRounding = MidpointRounding.ToEven   '四捨五入用

        Dim xl As New Microsoft.Office.Interop.Excel.Application

        timestamp = Replace(Replace(Replace(Now, ":", ""), "/", ""), " ", "")

        'エクセルのMsoFileDialogTypeを使用する
        tmpPath = objComFn.tgtDirGet()

        'エクセルのMsoFileDialogTypeを使用する場合

        'xl.FileDialog(MsoFileDialogType.msoFileDialogFolderPicker).Execute()    'おまじない Excel前面にする
        'xl.FileDialog(MsoFileDialogType.msoFileDialogFolderPicker).Title = "検索結果Excelの出力先フォルダを選択してください。"
        'If xl.FileDialog(MsoFileDialogType.msoFileDialogFolderPicker).Show() = True Then
        '    tmpPath = xl.FileDialog(MsoFileDialogType.msoFileDialogFolderPicker).SelectedItems(0)
        'Else
        '    tmpPath = ""
        'End If


        If tmpPath = "" Then
            MessageBox.Show("Excel出力を中止します。")
        Else
            If tmpPath = "" Then

            End If

            Cursor.Current = Cursors.WaitCursor

            fname = tmpPath & "\顧客王検索結果_" & timestamp & ".xls"

            'Try
            'CreateObjectでExcelObjectを実行時バインディングする
            objExcel = CreateObject("Excel.Application")

            'objExcel.visible = True
            objWorkBook = objExcel.Workbooks.add


            'DataTableを二次元配列に格納する
            Dim data(objTgtTable_i.Rows.Count, objTgtTable_i.Columns.Count - 1) As String
            For y As Integer = 0 To objTgtTable_i.Rows.Count - 1

                If y = 0 Then
                    For x As Integer = 0 To objTgtTable_i.Columns.Count - 1
                        data(y, x) = objTgtTable_i.Columns(x).HeaderCell.Value.ToString
                    Next
                End If

                For x As Integer = 0 To objTgtTable_i.Columns.Count - 1

                    'If objComFn.IsNumeric(objTgtTable_i.Rows(y).cells(x).value.ToString) Then
                    '    '四捨五入処理 小数点以下のデータがあるのでとりあえず行わない
                    '    Dim tmpStr As String = objTgtTable_i.Rows(y).cells(x).value.ToString
                    '    tmpStr = tmpStr.Trim()
                    '    Dim tmpNum As Decimal = tmpStr
                    '    tmpNum = Math.Round(tmpNum, 0, even)
                    '    data(y + 1, x) = tmpNum
                    'Else
                    '    data(y + 1, x) = objTgtTable_i.Rows(y).cells(x).value.ToString
                    'End If

                    data(y + 1, x) = objTgtTable_i.Rows(y).cells(x).value.ToString
                Next
            Next


            objSheet = objWorkBook.Worksheets(1)


            objSheet.Cells.NumberFormatLocal = "@"

            Dim startX As Integer = 1
            Dim startY As Integer = 3
            '始点
            range1 = DirectCast(objSheet.Cells(startY, startX), Object)
            '終点
            range2 = DirectCast(objSheet.Cells(startY + UBound(data), startX + UBound(data, 2)), Object)
            'セル範囲
            range = objSheet.Range(range1, range2)
            '貼り付け
            range.Value = data

            Select Case objExcel.Version
                Case "12.0", "14.0"
                    'ファイルに保存 Excel2007,Excel2010の場合は互換方式にて保存
                    objWorkBook.SaveAs(fname, 56)
                Case Else
                    objWorkBook.SaveAs(fname)
            End Select
            '保存時の問合せのダイアログを非表示に設定
            objExcel.DisplayAlerts = True

            MessageBox.Show(fname & vbCrLf & "上記のファイルを作成しました。", "Excel出力が成功しました。")

            'Catch ex As Exception
            '    MsgBox("エクセルがインストールされていない、もしくは、伝票生成中にエラーが発生しました。")
            'Finally

            If Not IsNothing(objWorkBook) Then
                objWorkBook.Close(False) 'ファイルを閉じる
                'Marshal.ReleaseComObject(objWorkBook) 'オブジェクト参照を解放
                objWorkBook = Nothing 'オブジェクト解放
            End If

            If Not IsNothing(objWorkBook) Then
                'Marshal.ReleaseComObject(objWorkBook) 'オブジェクト参照を解放
                objWorkBook = Nothing 'オブジェクト解放
            End If

            If Not IsNothing(objExcel) Then
                objExcel.Quit() 'EXCELを閉じる
                'Marshal.ReleaseComObject(objExcel) 'オブジェクト参照を解放
                objExcel = Nothing 'オブジェクト解放
            End If

            System.GC.Collect() 'オブジェクトを確実に削除

            'End Try
        End If



        ExcelOutPut = 0

        Cursor.Current = Cursors.Default

    End Function




End Class
