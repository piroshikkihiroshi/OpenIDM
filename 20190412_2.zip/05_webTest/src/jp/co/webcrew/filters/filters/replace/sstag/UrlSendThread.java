package jp.co.webcrew.filters.filters.replace.sstag;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.util.QueueThreadUtil;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;

/**
 * URLを送信するUrlSendThreadクラス。
 *
 * @author kiyoshi.higashide
 */
public class UrlSendThread extends QueueThreadUtil
{
	private static final Logger log = Logger.getLogger(UrlSendThread.class);
	public static final String URL_SEND_KEY = "webcrew_url_send";

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequestCache)
	 */
	protected void execute(HttpServletRequestCache request) throws Exception
	{
		try
		{
			// URLを取得する
			List listUrlSend = (List)request.getAttribute("webcrew_url_send");

			for (int i = 0; i < listUrlSend.size(); i++)
			{
				try
				{
					setUrlSend((String)listUrlSend.get(i));
				}
				catch (Exception e) {
					log.error("URL送信エラー", e);
				}
			}
		}
		catch (Exception e)
		{
			log.error("予期せぬエラー", e);
		}
	}

	/**
	 * 指定のURLをGETで送信を行う。
	 *
	 * @param strUrl
	 * @return なし
	 */
	private void setUrlSend(String strUrl) throws MalformedURLException, IOException
	{
		HttpURLConnection connection = null;

		try
		{
			log.info("URL送信 [url: " + strUrl + "]");

			URL url = new URL(strUrl);
			connection = (HttpURLConnection)url.openConnection();
			connection.setRequestMethod("GET");
			connection.setDoOutput(false);
			
			//2012-06-06 connect()を追加
			connection.connect();
			
			int responseCode = connection.getResponseCode();
			log.info("request url[" + strUrl + "]  response code[" + responseCode + "]");
		}
		finally
		{
			connection.disconnect();
		}
	}

}
