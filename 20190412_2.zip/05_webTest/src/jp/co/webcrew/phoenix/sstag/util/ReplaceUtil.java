package jp.co.webcrew.phoenix.sstag.util;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

public class ReplaceUtil {

    /**
     * 各項目ごとのhtmlを組み立てる。
     * 
     * @param html
     * @param replaceMap
     * @return
     */
    public static String getReplacedHtml(String html, Map<String, String> replaceMap) {
        return getReplacedHtml(html, replaceMap, true);
    }

    /**
     * 各項目ごとのhtmlを組み立てる。
     * 
     * @param html
     * @param replaceMap
     * @param forseFlag
     * @return
     */
    public static String getReplacedHtml(String html, Map<String, String> replaceMap, boolean forceFlag) {
        return getReplacedText(html, replaceMap, forceFlag, Constants.REPLACE_VAL_PREFIX, Constants.REPLACE_VAL_POSTFIX);
    }

    /**
     * メール送信用のテキストを組み立てる。
     * 
     * @param text
     * @param replaceMap
     * @return
     */
    public static String getReplacedMail(String text, Map<String, String> replaceMap) {
        return getReplacedText(text, replaceMap, true, Constants.MAIL_REPLACE_VAL_PREFIX,
                Constants.MAIL_REPLACE_VAL_POSTFIX);
    }

    /**
     * 置換変数をもったテキストを置き換える。
     * 
     * @param text
     * @param replaceMap
     * @param forceFlag
     * @param prefix
     * @param postfix
     * @return
     */
    public static String getReplacedText(String text, final Map<String, String> replaceMap, final boolean forceFlag,
            final String prefix, final String postfix) {

        Replacer replacer = new Replacer() {
            @Override
            public String replace(String key) {
                if (replaceMap.get(key) != null || forceFlag) {
                    return ValueUtil.nullToStr(replaceMap.get(key));
                } else {
                    // 強制フラグがｆａｌｓｅの場合、値が設定されていない置換パラメータはそのまま残す。
                    return prefix + key + postfix;
                }

            }
        };

        return getReplacedText(replacer, text, prefix, postfix);

    }

    /**
     * 変換クラスでhtmlを組み立てる。
     * 
     * @param replacer
     * @param text
     * @return
     */
    public static String getReplacedHtml(Replacer replacer, String text) {
        return getReplacedText(replacer, text, Constants.REPLACE_VAL_PREFIX, Constants.REPLACE_VAL_POSTFIX);
    }

    /**
     * 変換クラスで置き換えを行う。
     * 
     * @param replacer
     * @param text
     * @param prefix
     * @param postfix
     * @return
     */
    public static String getReplacedText(Replacer replacer, String text, String prefix, String postfix) {

        StringBuffer sb = new StringBuffer();

        int fromIndex = 0;
        int toIndex;
        while (fromIndex <= text.length()) {
            toIndex = text.indexOf(prefix, fromIndex);
            if (toIndex < 0) {
                sb.append(text.substring(fromIndex));
                break;
            }
            sb.append(text.substring(fromIndex, toIndex));

            fromIndex = toIndex + prefix.length();
            toIndex = text.indexOf(postfix, fromIndex);
            if (toIndex < 0) {
                toIndex = text.length();
            }

            String key = text.substring(fromIndex, toIndex);
            sb.append(replacer.replace(key.trim()));

            fromIndex = toIndex + postfix.length();
        }

        return sb.toString();

    }

    public static String clearReplaceParam(String html) {
        return getReplacedHtml(html, new HashMap<String, String>());
    }

    /**
     * 文字列の変換を行うクラス。
     * 
     * @author kurinami
     */
    abstract public interface Replacer {
        /**
         * 変換した文字列を返す。
         * 
         * @param source
         * @return
         */
        abstract public String replace(String source);
    }

    /**
     * ヘッダ/フッタ部分の置換変数の置き換えを行う。
     * 
     * @param header
     * @param request
     * @param offset
     * @param limit
     * @param max
     * @return
     */
    public static String getReplacedHeader(String header, HttpServletRequest request, final int offset,
            final int limit, final int max) {

        // 表示するものがなかった場合、ヘッダ/フッタも表示しない。
        if (limit == 0 || max < offset) {
            return "";
        }

        final String url = request.getRequestURI();
        final String queryString = ValueUtil.nullToStr(request.getQueryString());

        Replacer replacer = new Replacer() {

            private Pattern dirPattern = Pattern.compile("(offset|page)\\.(prev|next|this|top|last)(\\.(\\d+))?");

            private Pattern urlPattern = Pattern.compile("url\\.(this|param\\.(.+))");

            private Pattern linkPattern = Pattern.compile("pagelink\\.(.+)\\.(\\d+)");

            @Override
            public String replace(String source) {

                int firstPage = 1;
                int currentPage = (int) Math.ceil((offset - 1.0) / limit) + 1;
                int lastPage = offset <= max ? currentPage + (max - offset) / limit : (max - 1) / limit + 1;

                // オフセット値やページ番号に関する置換を行う。
                Matcher dirMatcher = dirPattern.matcher(source);
                if (dirMatcher.matches()) {
                    int ret = 0;

                    String type = dirMatcher.group(1);
                    String dir = dirMatcher.group(2);
                    int num = Math.max(1, ValueUtil.toint(dirMatcher.group(4)));

                    int base = type.equals("offset") ? offset : currentPage;
                    int increment = type.equals("offset") ? limit : 1;
                    int last = type.equals("offset") ? max : lastPage;

                    if (dir.equals("prev")) {
                        ret = Math.max(base - increment * num, 1);
                    } else if (dir.equals("next")) {
                        ret = Math.min(base + increment * num, last);
                    } else if (dir.equals("this")) {
                        ret = base;
                    } else if (dir.equals("top")) {
                        ret = 1;
                    } else if (dir.equals("last")) {
                        ret = last;
                    }

                    return Integer.toString(ret);
                }

                // urlに関する置換を行う。
                Matcher urlMatcher = urlPattern.matcher(source);
                if (urlMatcher.matches()) {
                    String ret = "";

                    String type = urlMatcher.group(1);
                    if (type.equals("this")) {
                        ret = url;
                    } else {
                        ret = queryString.replaceFirst("(.*)(" + urlMatcher.group(2) + "(=([^&]*))&?){1}(.*)", "$1$5");
                        if (!PhoenixUtil.isEmpty(ret) && !ret.endsWith("&")) {
                            ret += "&";
                        }
                    }

                    return ret;
                }

                // ページリンクに関する置換を行う。
                Matcher linkMatcher = linkPattern.matcher(source);
                if (linkMatcher.matches()) {
                    StringBuffer sb = new StringBuffer();

                    String paramName = linkMatcher.group(1);
                    int linkCount = ValueUtil.toint(linkMatcher.group(2));

                    int startPage = Math.max(Math.min(currentPage - (int) Math.ceil(linkCount / 2.0) + 1, lastPage
                            - linkCount + 1), firstPage);
                    int stopPage = Math.min(Math.max(currentPage + (int) Math.floor(linkCount / 2.0), startPage
                            + linkCount - 1), lastPage);

                    for (int i = startPage; i <= stopPage; i++) {
                        if (i < currentPage) {
                            sb
                                    .append(MessageFormat
                                            .format(
                                                    "<a href=\"%'{'url.this}?%'{'url.param.{0}}{0}=%'{'offset.prev.{1}}\">%'{'page.prev.{1}}</a>\n",
                                                    paramName, currentPage - i));
                        } else if (i == currentPage) {
                            sb.append("%{page.this}\n");
                        } else if (i > currentPage) {
                            sb
                                    .append(MessageFormat
                                            .format(
                                                    "<a href=\"%'{'url.this}?%'{'url.param.{0}}{0}=%'{'offset.next.{1}}\">%'{'page.next.{1}}</a>\n",
                                                    paramName, i - currentPage));
                        }
                    }

                    // 組み立てたページリンクを自分自身で再度置換する。
                    return getReplacedHtml(this, sb.toString());
                }

                return "！";
            }
        };

        return getReplacedHtml(replacer, header);
    }
}
