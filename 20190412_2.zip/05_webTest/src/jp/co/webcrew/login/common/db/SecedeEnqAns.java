/**
 * 
 */
package jp.co.webcrew.login.common.db;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.login.common.db.util.DBEntity;

/**
 * @author stk
 *
 */
public class SecedeEnqAns extends DBEntity{
	
	/** ロガー */
	private static final Logger log = Logger.getLogger(SecedeEnqAns.class);

	/** テーブル名 */
	public static final String TABLE = "SECEDE_ENQ_ANS";
	
	/** TYPE列 数値入力 */
	public static final String FLG_TYPE_NUM  = "1"; // 番号選択・数値選択

	/** TYPE列 テキスト入力 */
	public static final String FLG_TYPE_TEXT = "2"; // テキスト入力

	/*
	 * 列定義
	 */
	public final static String GUID     = "GUID"; 
	public final static String ENQ_CODE = "ENQ_CODE"; 
	public final static String TYPE     = "TYPE"; 
	public final static String ANS_NUM  = "ANS_NUM"; 
	public final static String ANS_TEXT = "ANS_TEXT";

	public void init(){
		setTable(TABLE);
	}
}
