package jp.co.webcrew.loader.loader;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.loader.db.ClassRepositoryDb;

/**
 * クラスのロードを管理するmanagerクラス。
 * 
 * @author kurinami
 */
public class LoadManager implements Runnable {

    /** ロガー */
    private static final Logger log = Logger.getLogger(RepositoryManager.class);

    /** コンパイルを行うmanager */
    private RepositoryManager manager;

    /** 親クラスローダー */
    private URLClassLoader parentClassLoader;

    /** 動的クラスローダー */
    private DynamicClassLoader dynamicClassLoader;

    /** 前回クラスローダーの更新を行った日時 */
    private long lastDatetime;

    /** スレッドを終了させるかのフラグ */
    private boolean halt = false;

    /** 更新をチェックする間隔(秒) */
    private int reloadCheckIntervalSec = 5;

    /**
     * コンストラクタ
     * 
     * @param autoReloadFlag
     */
    public LoadManager(boolean autoReloadFlag) {
        init(new URL[0], autoReloadFlag);
    }

    /**
     * コンストラクタ
     * 
     * @param urls
     * @param autoReloadFlag
     */
    public LoadManager(URL[] urls, boolean autoReloadFlag) {
        init(urls, autoReloadFlag);
    }

    /**
     * コンストラクタ
     * 
     * @param servletContext
     * @param autoReloadFlag
     * @throws ServletException
     */
    @SuppressWarnings("deprecation")
    public LoadManager(ServletContext servletContext, boolean autoReloadFlag) throws ServletException {

        try {
            List<URL> urlList = new ArrayList<URL>();

            File classPath = new File(servletContext.getRealPath("/WEB-INF/classes/"));
            if (classPath.isDirectory()) {
                urlList.add(classPath.toURL());
            }

            File libDir = new File(servletContext.getRealPath("/WEB-INF/lib/"));
            if (libDir.isDirectory()) {
                File[] libFiles = libDir.listFiles();
                for (int i = 0; i < libFiles.length; i++) {
                    String filename = libFiles[i].getName().toLowerCase();
                    if (filename.endsWith(".jar") || filename.endsWith(".zip")) {
                        urlList.add(libFiles[i].toURL());
                    }
                }
            }

            init(urlList.toArray(new URL[0]), autoReloadFlag);

        } catch (MalformedURLException e) {
            throw new ServletException(e);
        }

    }

    /**
     * 初期処理を行う。
     * 
     * @param urls
     * @param autoReloadFlag
     */
    private void init(URL[] urls, boolean autoReloadFlag) {
        this.parentClassLoader = new URLClassLoader(urls, LoadManager.class.getClassLoader());
        this.manager = new RepositoryManager(parentClassLoader);
        this.lastDatetime = System.currentTimeMillis();
        this.dynamicClassLoader = new DynamicClassLoader(manager, parentClassLoader);
        if (autoReloadFlag) {
            Thread thread = new Thread(this);
            thread.setDaemon(true);
            thread.start();
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        while (!halt) {
            long now = System.currentTimeMillis();

            try {
                List<String> modifiedClassNameList = ClassRepositoryDb.getModifiedClassNameList(lastDatetime);
                if (!modifiedClassNameList.isEmpty()) {
                    lastDatetime = now;
                    manager.removeRepositoryObjects(modifiedClassNameList);
                    dynamicClassLoader = new DynamicClassLoader(manager, parentClassLoader);
                    log.info("DynamicClassLoader reloaded.");
                }
            } catch (Throwable t) {
                log.error("予期せぬエラー", t);
            }

            try {
                Thread.sleep(reloadCheckIntervalSec * 1000);
            } catch (InterruptedException e) {
            }
        }
    }

    /**
     * クラスのインスタンスを返す。
     * 
     * @param className
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws ClassNotFoundException
     */
    public Object newInstance(String className) throws InstantiationException, IllegalAccessException,
            ClassNotFoundException {
        return Class.forName(className, true, dynamicClassLoader).newInstance();
    }

    /**
     * 明示的にクラスローダーを新しくする。
     */
    public void reload() {
        lastDatetime = System.currentTimeMillis();
        dynamicClassLoader = new DynamicClassLoader(manager, parentClassLoader);
        log.info("DynamicClassLoader reloaded.");
    }

    /**
     * 自動更新のスレッドを終了する。
     */
    public void close() {
        halt = true;
    }

    public ClassLoader getClassLoader() {
        return dynamicClassLoader;
    }
}
