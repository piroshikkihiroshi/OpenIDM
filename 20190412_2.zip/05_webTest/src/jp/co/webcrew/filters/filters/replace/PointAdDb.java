package jp.co.webcrew.filters.filters.replace;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;


/**
 * 広告を管理するためのdbクラス。
 * 
 */
public class PointAdDb extends AdDb {
  
  public static final int POINT_AD_DB_ERROR = -1;
  
  /** system_propertiesテーブル用のスキーマ名格納キー値 */
  private static final String SCHEMA_NAME_PROP_KEY = "WCADVMAN_SCHEMA_NAME";
  
  /**
   * クリック件数を取得するためのSQL
   */
  private static final String SELECT_POINT_AD_CLICK_COUNT_INFO = ""
    + "SELECT total_click_cnt FROM {0}.point_ad_click_count_info WHERE ad_id LIKE ? AND site_id = ?";
  
  /**
   * point_ad_click_count_infoから件数を取得する
   * 
   * @param siteId サイトID
   * @param guid GUID
   * @return
   * @throws SQLException
   */
  public static int getCount(String adId, int siteId) throws SQLException {

    // スキーマ名の取得
    String schmaName = SystemPropertiesDb.getInstance().get(SCHEMA_NAME_PROP_KEY);

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();

      // point_ad_click_count_infoから件数を取得する
      String sql = new MessageFormat(SELECT_POINT_AD_CLICK_COUNT_INFO).format(new String[] { schmaName });

      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, adId);
      dbAccess.setInt(2, siteId);
      
      rs = dbAccess.executeQuery();
      if (dbAccess.next(rs)) {
        return rs.getInt("total_click_cnt");
      } else {
        return 0; //クリックされていない広告
      }
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }

  /** 広告のクリック上限数を取得するためのSQL */
  private static final String SELECT_MAX_VALUE_INFO = ""
    + "SELECT NVL(max_click, -1) AS max FROM {0}.max_value_info WHERE ad_id = ? ORDER BY effective_date DESC";
  
  /**
   * max_value_infoから広告のクリック上限数を取得する
   * 
   * @param adId 広告ID
   * @return
   * @throws SQLException
   */
  public static int getMaxCount(String adId) throws SQLException {
    // スキーマ名の取得
    String schmaName = SystemPropertiesDb.getInstance().get(SCHEMA_NAME_PROP_KEY);

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();

      // max_value_infoからクリック上限数を取得する
      String sql = new MessageFormat(SELECT_MAX_VALUE_INFO).format(new String[] { schmaName });

      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, adId);
      
      rs = dbAccess.executeQuery();
      if (dbAccess.next(rs)) {
        return rs.getInt("max");
      } else {
        return POINT_AD_DB_ERROR; //件数を取得出来なかった
      }
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }

  /** point_ad_click_logから件数を取得するためのSQL */
  private static final String SELECT_POINT_AD_CLICK_LOG = ""
    + "SELECT COUNT(1) AS cnt FROM {0}.point_ad_click_log WHERE guid = ? AND site_id = ? AND click_date BETWEEN TO_DATE(?, ''YYYY/MM/DD HH24:MI:SS'') AND TO_DATE(?, ''YYYY/MM/DD HH24:MI:SS'') AND ad_id = ?";
  
  /**
   * point_ad_click_logから件数を取得
   * 
   * @param guid GUID
   * @param siteId サイトID
   * @param clickDate クリック年月日(YYYYMMDDHH24MISS)
   * @param adId 広告ID
   * @return
   */
  public static int getCountFromLog(String guid, int siteId, String searchStartDate, String searchEndDate, String adId) throws SQLException {
    //スキーマ名の取得
    String schmaName = SystemPropertiesDb.getInstance().get(SCHEMA_NAME_PROP_KEY);

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();

      // point_ad_click_logから当日のクリック履歴を取得する
      String sql = new MessageFormat(SELECT_POINT_AD_CLICK_LOG).format(new String[] { schmaName });

      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, guid);
      dbAccess.setInt(2, siteId);
      dbAccess.setString(3, searchStartDate);
      dbAccess.setString(4, searchEndDate);
      dbAccess.setString(5, adId);
      
      rs = dbAccess.executeQuery();
      if (dbAccess.next(rs)) {
        return rs.getInt("cnt");
      } else {
        return POINT_AD_DB_ERROR; //件数を取得出来なかった
      }
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
  
  /** ポイント数を取得するためのSQL */
  private static final String SELECT_POINT_AMOUNT_FROM_AD_MST = ""
    + "SELECT NVL(point_amount, -1) AS amount FROM {0}.ad_mst WHERE ad_id LIKE ? AND point_ad_flg = 1";
  
  /**
   * ポイント数を取得する
   * 
   * @param adId 広告ID
   * @return
   * @throws SQLException
   */
  public static int getAmount(String adId) throws SQLException {
    //スキーマ名の取得
    String schmaName = SystemPropertiesDb.getInstance().get(SCHEMA_NAME_PROP_KEY);

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();

      // ad_mstからポイント数を取得する
      String sql = new MessageFormat(SELECT_POINT_AMOUNT_FROM_AD_MST).format(new String[] { schmaName });

      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, adId);
      
      rs = dbAccess.executeQuery();
      if (dbAccess.next(rs)) {
        return rs.getInt("amount");
      } else {
        return POINT_AD_DB_ERROR; //ポイントを取得出来なかった
      }
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
  
  /** POINT_CHARGE_HISTにポイント付与情報を登録する */
  private static final String INSERT_POINT_CHARGE_HIST = ""
    + "INSERT INTO point_charge_hist(point_charge_id, guid, mk_datetime, point, type, point_id, url, reason, auto_kbn, user_flag, af_flag) "
    + "VALUES (seq_point_charge_id.nextval, ?, ?, ?, 5, null, null, ?, 0, 1, 0)";

  /**
   * ポイント付与情報を登録する
   * 
   * @param guid GUID
   * @param adName 広告名
   * @param amount 付与ポイント数
   * @param clickDate クリック年月日(YYYYMMDDHH24MISS)
   * @throws SQLException
   */
  public static void insertPointChargeHist(String guid, String adName, int amount, String clickDate) throws SQLException {

    // スキーマ名の取得
    String schmaName = SystemPropertiesDb.getInstance().get(INSERT_POINT_CHARGE_HIST);

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();

      // トランザクションを開始する。
      dbAccess.setAutoCommit(false);

      String sql = new MessageFormat(INSERT_POINT_CHARGE_HIST).format(new String[] { schmaName });
      
      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, guid);
      dbAccess.setString(2, clickDate);
      dbAccess.setInt(3, amount);
      dbAccess.setString(4, "ポイントバナー(" + adName + ")");
      
      dbAccess.executeUpdate();

      // コミットする。
      dbAccess.commit();

    } catch (SQLException e) {
      // ロールバックする。
      dbAccess.rollback();
      throw e;

    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }

  /** AD_MSTから広告名を取得するためのSQL */
  private static final String SELECT_AD_NAME = ""
    + "SELECT ad_name FROM {0}.ad_mst WHERE ad_id LIKE ? AND point_ad_flg = 1";
  
  /**
   * 広告名を取得する
   * 
   * @param adId
   * @return
   * @throws SQLException
   */
  public static String getPointAdName(String adId) throws SQLException {
    //スキーマ名の取得
    String schmaName = SystemPropertiesDb.getInstance().get(SCHEMA_NAME_PROP_KEY);

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();

      // ad_mstからポイント数を取得する
      String sql = new MessageFormat(SELECT_AD_NAME).format(new String[] { schmaName });

      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, adId);
      
      rs = dbAccess.executeQuery();
      if (dbAccess.next(rs)) {
        return rs.getString("ad_name");
      } else {
        return ""; //ポイント広告名を取得出来なかった
      }
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
  
  /** ポイント広告クリック数集計テーブルを削除するためのSQL */ 
  private static final String DELETE_POINT_AD_CLICK_COUNT_INFO = ""
    + "DELETE FROM {0}.point_ad_click_count_info WHERE ad_id = ? AND site_id = ?";
  
  /** ポイント広告クリック数集計テーブルを作成するためのSQL */ 
  private static final String INSERT_POINT_AD_CLICK_COUNT_INFO = ""
    + "INSERT INTO {0}.point_ad_click_count_info VALUES(?, ?, ?, sysdate)";
  
  /** ポイント広告クリック履歴(piont_ad_click_log)を挿入するためのsql */
  private static final String INSERT_POINT_AD_CLICK_LOG = ""
    + "insert into {0}.point_ad_click_log(guid, site_id, click_date, ad_id, session_id) values(?, ?, TO_DATE(?, ''YYYY/MM/DD HH24:MI:SS''), ?, ?)";
  
  /**
   * ポイント広告クリック履歴を更新する
   * SELECT -> (DELETE) -> INSERT
   * 
   * @param guid
   * @param siteId
   * @param clickDate
   * @param adId
   * @param sessionId
   * @throws SQLException
   */
  public static void updatePointAdClickLog(String guid, int siteId, String clickDate, String adId, String sessionId) throws SQLException {
    
    //クリック件数を取得
    int clickCount = getCount(adId, siteId);
    
    //スキーマ名の取得
    String schmaName = SystemPropertiesDb.getInstance().get(SCHEMA_NAME_PROP_KEY);
    
    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();
      
      //トランザクションを開始する。
      dbAccess.setAutoCommit(false);
      
      String sql = "";
      
      if(clickCount != 0) {
        //クリック件数履歴を削除する
        sql = new MessageFormat(DELETE_POINT_AD_CLICK_COUNT_INFO).format(new String[] { schmaName });
        dbAccess.prepareStatement(sql);
        dbAccess.setString(1, adId);
        dbAccess.setInt(2, siteId);
        
        dbAccess.executeUpdate();
      }
      
      //clickCountを+1してクリック件数履歴を作成する
      sql = new MessageFormat(INSERT_POINT_AD_CLICK_COUNT_INFO).format(new String[] { schmaName });
      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, adId);
      dbAccess.setInt(2, siteId);
      dbAccess.setInt(3, clickCount + 1);
      
      dbAccess.executeUpdate();
      
      //クリックログを作成
      sql = new MessageFormat(INSERT_POINT_AD_CLICK_LOG).format(new String[] { schmaName });
      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, guid);
      dbAccess.setInt(2, siteId);
      dbAccess.setString(3, clickDate);
      dbAccess.setString(4, adId);
      dbAccess.setString(5, sessionId);
      
      dbAccess.executeUpdate();
      
      //コミットする。
      dbAccess.commit();
      
    } catch (SQLException e) {
      // ロールバックする。
      dbAccess.rollback();
      throw e;

    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
}
