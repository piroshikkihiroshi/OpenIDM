package jp.co.webcrew.login.common.db;

public enum VTQuerySortType 
{
	Integer
	,Decimal
	,Date
	,DateTime
	,String
}
