package jp.co.webcrew.login.common.db;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.ValueUtil;

public class VTQueryResultSet implements Serializable
{
	private int siteId;
	private String tableId;
	private List<Map<String,String>> dataSet;
    /****
     * recidのマップキー
     */
    public static final String ROWDATA_KEY_REC_ID="__ph_vtable_recid__";
    /***
     * [reserved]公開フラグのマップキー
     */
    public static final String ROWDATA_KEY_PUBLIC_FLAG="__ph_vtable_public_flag__";
    /***
     * [reserved]公開開始日時のマップキー
     */
    public static final String ROWDATA_KEY_BGN_DATETIME="__ph_vtable_bgn_datetime__";
    /***
     * [reserved]公開終了日時のマップキー
     */
    public static final String ROWDATA_KEY_END_DATETIME="__ph_vtable_end_datetime__";

    
    /***
     * [reserved]更新日時のマップキー
     */
    public static final String ROWDATA_KEY_UP_DATETIME="__ph_vtable_up_datetime__";

    /***
     * [reserved]更新ユーザーのマップキー
     */
    public static final String ROWDATA_KEY_UP_ADMIN="__ph_vtable_up_admin__";

    
    /***
     * 
     * 
     */
    public static final List<String> LIST_ROWDATA_KEY;
    
    static
    {
    	LIST_ROWDATA_KEY
    	=Arrays.asList(new String[]{
    			ROWDATA_KEY_REC_ID
    			,ROWDATA_KEY_PUBLIC_FLAG
    			,ROWDATA_KEY_BGN_DATETIME
    			,ROWDATA_KEY_END_DATETIME
    			,ROWDATA_KEY_UP_ADMIN
    			,ROWDATA_KEY_UP_DATETIME
    	});
    }
    
	public VTQueryResultSet(int siteId,String tableId,List<Map<String,String>> dataSet)
	{
		this.siteId=siteId;
		this.tableId=tableId;
		this.dataSet=dataSet;
	}
	
	public void setSiteId(int siteId)
	{
		this.siteId=siteId;
	}
	
	public void setTableId(String tableId)
	{
		this.tableId=tableId;
	}
	
	public void setDataSet(List<Map<String,String>> dataSet)
	{
		this.dataSet=dataSet;
	}
	
	
	public int getSiteId()
	{
		return this.siteId;
	}
	
	public String getTableId()
	{
		return this.tableId;
	}
	
	public List<Map<String,String>> getDataSet()
	{
		return this.dataSet;
	}
	
	
	/****
	 * 内部結合を行う
	 * 
	 * @param dataSetBase
	 * @param dataSetAP
	 * @param joinKeyBase
	 * @param joinKeyAP
	 * @param ifClmIdDuplicateShowBase
	 * @return
	 */
    public static List<Map<String,String>> doInnerJoin(
    		List<Map<String,String>> dataSetBase
    		,List<Map<String,String>> dataSetAP
    		,String joinKeyBase
    		,String joinKeyAP
    		,boolean ifClmIdDuplicateShowBase
    )
    {
    	return doJoin(dataSetBase, dataSetAP, joinKeyBase, joinKeyAP, ifClmIdDuplicateShowBase, false, false);
    }
    	    
    /****
     * 外部結合を行う
     * 第一引数に渡したリストがアウター
     * 第二引数に渡したリストがインナー
     * 
     * @param dataSetBase
     * @param dataSetAP
     * @param joinKeyBase
     * @param joinKeyAP
     * @param ifClmIdDuplicateShowBase
     * @return
     */
    public static List<Map<String,String>> doOuterJoin(
    		List<Map<String,String>> dataSetBase
    		,List<Map<String,String>> dataSetAP
    		,String joinKeyBase
    		,String joinKeyAP
    		,boolean ifClmIdDuplicateShowBase
    )
    {
    	return doJoin(dataSetBase, dataSetAP, joinKeyBase, joinKeyAP, ifClmIdDuplicateShowBase, true, false);
    }

    /****
     * フル外部結合(FULL_OUTER_JOIN)処理を行う
     * 
     * 
     * @param dataSetBase
     * @param dataSetAP
     * @param joinKeyBase
     * @param joinKeyAP
     * @param ifClmIdDuplicateShowBase
     * @return
     */
    public static List<Map<String,String>> doFullOuterJoin(
    		List<Map<String,String>> dataSetBase
    		,List<Map<String,String>> dataSetAP
    		,String joinKeyBase
    		,String joinKeyAP
    		,boolean ifClmIdDuplicateShowBase
    )
    {
    	return doJoin(dataSetBase, dataSetAP, joinKeyBase, joinKeyAP, ifClmIdDuplicateShowBase, true, true);
    }

    
    /***
     * 結合処理を行う
     * 
     * @param dataSetBase
     * @param dataSetAP
     * @param joinKeyBase
     * @param joinKeyAP
     * @param ifClmIdDuplicateShowBase　列名が重複した場合、どちらを優先するか true:第一引数側／false:第二引数側
     * @param base
     * @param ap
     * @return
     */
    public static List<Map<String,String>> doJoin(
    		List<Map<String,String>> dataSetBase
    		,List<Map<String,String>> dataSetAP
    		,String joinKeyBase
    		,String joinKeyAP
    		,boolean ifClmIdDuplicateShowBase
    		,boolean base
    		,boolean ap)
    {
    	List<Map<String,String>> dataSetRet=new ArrayList<Map<String,String>>();
    	
		
		List<Integer> appliedRowAP=new ArrayList<Integer>();
		
		//第１引数DataSetを軸にループ
		for(Map<String,String> rowDataBase:dataSetBase)
		{
			boolean matched=false;
			//第１引数DataSetの結合キーの値を取得
			String keyBase=ValueUtil.nullToStr(rowDataBase.get(joinKeyBase));
			//上記で取得した値がNULLもしくは空文字の場合、結合処理はスキップする
			if(keyBase.length()!=0)
			{
				int ap_index=-1;
				//第２引数DataSetを軸にループ
				for(Map<String,String> rowDataAP:dataSetAP)
				{
					ap_index++;
					//第２引数DataSetの結合キーの値を取得
					String keyAP=ValueUtil.nullToStr(rowDataAP.get(joinKeyAP));
					//上記で取得した値がNULLもしくは空文字の場合、結合処理はスキップする
					if(keyAP.length()!=0)
					{
						//結合キーの値が一致
						if(keyBase.equals(keyAP))
						{
							//第２引数DataSetのリスト・索引番号を保存
							appliedRowAP.add(ap_index);
							
							matched=true;
							//戻り値（のリスト）に行追加
							Map<String,String> newRowData=new HashMap<String, String>(rowDataBase);
							dataSetRet.add(newRowData);
							
							for(String clmIdAP:rowDataAP.keySet())
							{
								//標準キーの場合、スキップ
								if(LIST_ROWDATA_KEY.indexOf(clmIdAP)!=-1)
								{
									continue;
								}
								//列名重複が重複し、優先フラグが第１引数DataSetにある場合、スキップ
								if(ifClmIdDuplicateShowBase && newRowData.containsKey(clmIdAP))
								{
									continue;
								}
								//上記スキップ条件に合致しない場合、
								//第二引数DataSetの内容を戻り値（のリスト）にセットする
								String valueAP=rowDataAP.get(clmIdAP);
								newRowData.put(clmIdAP, valueAP);
							}
							//データマッチがしても、
							//次のデータがマッチする可能性もある。
							//このため、ここではbreakは入れない。
							//break;
						}
					}
				}
			}
			
			//結合ができなかった場合＆その場合でも戻り値リストに追加するフラグ(第１引数編)が有効な場合、
			//戻り値リストに追加
			//外部結合に考え方は近い
			if(!matched && base)
			{
				Map<String,String> newRowData=new HashMap<String, String>(rowDataBase);
				dataSetRet.add(newRowData);
			}
			
			
		}
		
		//結合ができなかった場合＆その場合でも戻り値リストに追加するフラグ(第２引数編)が有効な場合、
		//戻り値リストに追加
		//外部結合に考え方は近い
		if(ap)
		{
			int ap_index=-1;
			
			
			for(Map<String,String> rowDataAP:dataSetAP)
			{
				ap_index++;
				if(appliedRowAP.indexOf(ap_index)==-1)
				{
					Map<String,String> newRowData=new HashMap<String, String>(rowDataAP);
					dataSetRet.add(newRowData);
				}
			}
			
		}
		
		return dataSetRet;
    }
    
    
    /***
     * 行データの中から、行のメタデータ(rec_meta_dataから取得したデータ)と
     * データそのもの(clm_dataから取得したデータ)を分離する。
     * 
     * 戻り値の配列のサイズは常に２
     * 索引０には、行のメタデータ
     * 索引１には、データそのもの
     * 
     * が入る
     * 
     * @param rowData
     * @return
     */
    public static Map<String,String>[] separate_recMetaData_clmData(Map<String,String> rowData)
    {
    	Map<String,String> clmData=new HashMap<String, String>();
    	Map<String,String> recMetaData=new HashMap<String, String>();
    	
    	for(String key:rowData.keySet())
    	{
    		String value=rowData.get(key);
    		if(LIST_ROWDATA_KEY.indexOf(key)!=-1)
    		{
    			recMetaData.put(key, value);
    		}
    		else
    		{
    			clmData.put(key, value);
    		}
    	}
    	Map<String,String>[] ret=new Map[]{recMetaData,clmData};
    	return ret;
    	//return {clmData,recMetaData};
    }
    
    private void writeObject(ObjectOutputStream stream)throws IOException
    {
    	//stream.writeInt(this.getSiteId());
    	//stream.wr
    	
    }

    private void readObject(ObjectInputStream stream)throws IOException,ClassNotFoundException
    {
    	
    	
    }
    
    
	
}
