package jp.co.webcrew.login.common.db.step;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.SiteSession;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;



public abstract class StepUserInfoAbstract implements StepUserInfo{

	/** ロガー */
	private static final Logger log = Logger.getLogger(StepUserInfoAbstract.class);

	private HttpServletRequest _request;
	private String _siteId;
//	private String _userId;
	private String _requestId;
	
	private String _schema;
	
	
	private boolean _corporateService = false;

	protected void setCorporateService(boolean b) {
		_corporateService = b;
	}
	
//	public void init() {
//		doInit();
//	}
//
//	public abstract void doInit();

//	public boolean doLoad(DBAccess db , String orderId , String userId) throws SQLException{
//		setRequestId(orderId);
//		setUserId(userId);
//		return load(db);
//	}
	
	protected void setHttpRequest(HttpServletRequest request) {
		_request = request;
	}
	
	public HttpServletRequest getHttpRequest() {
		return _request;
	}
	
	public String getSiteId() {
		return _siteId;
	}
	
	public void setSiteId(String id){
		_siteId = id;
	}

//	public String getUserId() {
//		return _userId;
//	}

	public String getRequestId() {
		return _requestId;
	}

	public void setRequestId(String id) {
		_requestId = id;
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#isMobileAccess()
	 */
	public final boolean isMobileAccess(){
		return SessionFilterAlterUtil.fromMobile(getHttpRequest());
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#isCorporateService()
	 */
	public boolean isCorporateService(){
		DBAccess db = null;
		try {
			db = new DBAccess();
			SystemProperties props = new SystemProperties(db);
			if (props.get(SystemProperties.TEST_COMPANY).equals("1")){
				log.info("法人サイトからの登録です。");
				return true;
			}
		} catch (Exception e) {
			log.error("システムプロパティのロード中にエラーが発生しました。",e);
		} finally {
			DBAccess.close(db);
		}
		return _corporateService;
	}	


	/**
	 * USER_INFOとORDER_INFOのGUIDを上書き更新する。
	 * 必要があればオーバーライドして使用する
	 * 
	 * @param db
	 * @param guid
	 * @return
	 */
	public final boolean updateGuidCommon(DBAccess db , String guid)  {
		log.info ("ステップのデータベースに対し、guidの上書き処理を開始します。");
		
	// 入力チェック
		
		// GUIDが不正ならエラー
		if (! SessionFilterAlterUtil.isValidGuid(guid)){
			log.error("GUIDが不正です。");
			return false;
		}

		// ORDER_IDが不正ならエラー
		String orderId = ValueUtil.nullToStr(getRequestId());
		if (orderId.equals("")) {
			log.error("ORDER_IDが不正です。");
			return false;
		}

		// USER_IDが不正ならエラー
		String userId = ValueUtil.nullToStr(getUserId());
		if (userId.equals("")) {
			log.error("USER_IDが不正です。");
			return false;
		}

	// 更新
		
		try {
			// ORDER_INFOのGUIDを更新する
			String sql = "UPDATE " + getSchema() + ".ORDER_INFO SET GUID = ? ";
			sql += "WHERE ORDER_ID = ? ";
			db.prepareStatement(sql);
			db.setString(1, guid);
			db.setString(2, orderId);
			db.executeUpdate();

			sql = "UPDATE " + getSchema() + ".USER_INFO SET GUID = ? ";
			sql += "WHERE USER_ID = ? ";
			db.prepareStatement(sql);
			db.setString(1, guid);
			db.setString(2, getUserId());
			db.executeUpdate();
			
			log.info("GUIDの上書き処理が完了しました。");
			return true;
		
		} catch (Exception e) {

			log.error("guid上書き処理中に例外エラーが発生しました。" , e);
			return false;
		}		
	    
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPrepareStepDatabase(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String, java.lang.String)
	 */
	public void doPrepareStepDatabase(DBAccess db , String guid , String gsid) throws SQLException{

		// step側のID（requestId , UserId）を取得し、セットする
		doCreateNewStepId(db); 

		// サイトセッションをログイン済みとする
		SiteSession siteSession = new SiteSession(db , gsid);
		siteSession.setLoginFlg(SiteSession.LOGIN_OK); // ログイン済みフラグを立てる 

		// StepへrequestIdを引き渡す。サイトセッションにプロパティを直接セットする
		// プロパティ名は、{siteId}_userId
		String siteId = this.getSiteId(); 
		siteSession.writePropertyToDB(siteId+ SiteSession.PROP_USER_ID , getUserId() , siteId);
		siteSession.writePropertyToDB(siteId + SiteSession.PROP_REQUEST_ID , getRequestId() , siteId);

		// guidを元に、会員情報を取得
		MemberMst member = new MemberMst(guid);
		member.load(db);
		
		// 会員情報を元に、Stepユーザ情報へと変換
		doPopulateFromMemberMst(member);

		// サイトユーザ情報を元にデータベース登録
		doPrepareStepDatabase(db);
	}

	/**
	 * <pre>
	 * step_loginのログイン成功後、Step側に遷移する直前に、Step側のデータベースに
	 * 変更を加えてstep開始準備を整える。
	 * 
	 * 具体的には、となしばの会員情報をステップのデータベースにあらかじめコピーする等。
	 * 
	 * 本来、step-xml の InitialCalculations の前処理を記述することを想定していたため、
	 * 
	 *   do-pre-InitialCalculations-Process
	 * 
	 * という位置づけだったのだが、現在は、
	 * 
	 *   do-InitialCalculations-of-login
	 * 
	 * として機能しているのが実状である。
	 * 
	 * 
	 * ・当初のイメージ： initialCalculation の中で共通処理が走る
	 * 
	 *   ログイン無し
	 *    （前処理無し）         → step開始 → initialCalculation → step0
	 *     
	 *   ログインあり
	 *     doPrepareStepDatabase → step開始 → initialCalculation → step0
	 *
	 *    
	 * ・現在の実装：  ログイン済みの場合は、initialCalculation が実行されない
	 * 
	 *   ログイン無し
	 *     （前処理無し）        → step開始 → initialCalculation → step0
	 *     
	 *   ログインあり
	 *     doPrepareStepDatabase → step開始 → initialCalculation はスキップ → step0
	 * 
	 * <呼出条件>
	 * doLoad()メソッドを先に呼び出し、データベースから読み出した値を内部保持しておく
	 * 
	 * <使用箇所>
	 * step_loginのログイン機能で使用される。
	 * 
	 * <実装方法>
	 * 通常のstepでは、UserInfoとOrderInfoのレコードをそれぞれ一行ずつ作成する。 
     * 大抵の場合、xmlのinitialCalculationsにおいて冒頭で新規レコードを生成するよう
	 * 定義されているが、それと同じ内容を、ここに記述する。
	 * 
	 * ただし、ここではログインに成功していることが前提なので、step-xmlに記述されている
	 * 以上のことを実装する必要がある。
	 * 具体的には、空っぽのレコードを新規作成するだけではなく、ログイン成功後の処理すなわち
	 * 「会員情報から必要な情報を変換・コピー」を追加実装しなければならない。
	 * 
	 * 指定したDBアクセサを使う以外は、実装方法は自由で良い。
	 * </pre>
	 * @param db DBアクセサ
	 * @throws SQLException
	 */
	protected abstract void doPrepareStepDatabase(DBAccess db) throws SQLException;
	
	/**
	 * <pre>
	 * Step側のID（OrderId , UserId）をシーケンスから生成して、オブジェクトにセットする
	 * </pre>
	 * @param db DBアクセサ
	 * @throws SQLException
	 */
	protected abstract void doCreateNewStepId(DBAccess db) throws SQLException; 
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getMagEmail()
	 */
	public String getMagEmail() {
		return getEmail();
	}

	public String getSchema() {
		return _schema;
	}

	public void setSchema(String schema) {
		_schema = schema;
	}
	
}
