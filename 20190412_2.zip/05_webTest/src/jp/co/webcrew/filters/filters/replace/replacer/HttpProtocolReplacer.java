package jp.co.webcrew.filters.filters.replace.replacer;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

public class HttpProtocolReplacer extends Replacer {

    /** ロガー */
    private static final Logger log = Logger.getLogger(HttpProtocolReplacer.class);

    /** レクエストヘッダーキー値：プロトコル判定 */
    private static final String PROTOCOL_HEADER_KEY = "X-PHOENIX-PROTOCOL";

    private static final String PATTERN = "<\\s*sstag\\s+type\\s*=\\s*[\\'\\\"]?http_protocol[\\'\\\"]\\s*>"
            + ".*?protocol\\s*=\\s*[\\'\\\"]?(https|http)[\\'\\\"]?\\s*+.*?"
            + "<\\s*/sstag\\s*>(\\r\\n|\\r|\\n)?";

    /** sstagの指定がない場合に強制的にhttpに切り替えるかのフラグ */
    private boolean forseHttpProtocolFlag = false;

    /** マッチャー */
    private Pattern pattern = null;

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.replacer.Replacer#init(javax.servlet
     * .FilterConfig)
     */
    public void init(FilterConfig filterConfig) throws ServletException {
        pattern = Pattern.compile(PATTERN, Pattern.CASE_INSENSITIVE + Pattern.DOTALL);

        // sstagの指定がない場合に強制的にhttpに切り替えるかを設定する。
        String forceHttpProtocol = ValueUtil.nullToStr(filterConfig.getInitParameter("forceHttpProtocol"));
        if (forceHttpProtocol.equalsIgnoreCase("HTTP")) {
            forseHttpProtocolFlag = true;
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.replacer.Replacer#replace(java.
     * lang.String, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    public String replace(String source, HttpServletRequest request, HttpServletResponse response) {
        try {

            log.debug("replace start.");

            boolean isExistTag = false;

            Matcher m = pattern.matcher(source);

            StringBuffer sb = new StringBuffer();
            while (m.find()) {

                System.out.println("==============================");
                for (int i = 0; i <= m.groupCount(); i++) {
                    System.out.print(m.group(i));
                    System.out.print(", ");
                }
                System.out.println();

                isExistTag = true;

                String protocol = ValueUtil.nullToStr(m.group(1));
                if (protocol.equalsIgnoreCase("HTTP") && isSsl(request)) {
                    response.sendRedirect(getOwnUrl(request, false));
                    return "";
                } else if (protocol.equalsIgnoreCase("HTTPS") && !isSsl(request)) {
                    response.sendRedirect(getOwnUrl(request, true));
                    return "";
                }

                m.appendReplacement(sb, "");
            }
            m.appendTail(sb);

            if (forseHttpProtocolFlag && !isExistTag && isSsl(request)) {
                response.sendRedirect(getOwnUrl(request, false));
                return "";
            }

            log.debug("replace end.");
            return sb.toString();

        } catch (IOException e) {
            log.error("予期せぬエラー", e);
            return "";
        }
    }

    private String getOwnUrl(HttpServletRequest httpServletRequest, boolean sslFlag) {
        String requestUrl = httpServletRequest.getRequestURL().toString();
        String queryString = ValueUtil.nullToStr(httpServletRequest.getQueryString()).trim();
        requestUrl += (queryString.length() > 0 ? "?" + queryString : "");

        int beginIndex = requestUrl.indexOf("://");
        return (sslFlag ? "https://" : "http://") + requestUrl.substring(beginIndex + "://".length());
    }

    public static boolean isSsl(HttpServletRequest request) {
        if (ValueUtil.nullToStr(request.getHeader(PROTOCOL_HEADER_KEY)).equalsIgnoreCase("https")
                || ValueUtil.nullToStr(request.getHeader(PROTOCOL_HEADER_KEY)).equalsIgnoreCase("ssl")
                || request.getScheme().equalsIgnoreCase("https")) {
            return true;
        } else {
            return false;
        }
    }
    
    public static void main(String[] args) {

        String source = "" +
        		"<sstag type=\"HTTP_PROTOCOL\">\n" +
        		"   protocol = HTTPS \n" +
        		"</sstag>\n";
        
        Pattern pattern = Pattern.compile(PATTERN, Pattern.CASE_INSENSITIVE + Pattern.DOTALL);
        Matcher m = pattern.matcher(source);

        StringBuffer sb = new StringBuffer();
        while (m.find()) {

            System.out.println("==============================");
            for (int i = 0; i <= m.groupCount(); i++) {
                System.out.print(m.group(i));
                System.out.print(", ");
            }
            System.out.println();

            m.appendReplacement(sb, "");
        }
        m.appendTail(sb);

        System.out.println(sb.toString());
        return ;
        
    }

}
