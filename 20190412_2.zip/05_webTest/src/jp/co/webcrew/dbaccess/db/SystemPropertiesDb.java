package jp.co.webcrew.dbaccess.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * システムプロパティを管理するdbクラス。
 * 
 * @author kurinami
 */
public class SystemPropertiesDb extends RefreshMstDb {

    /** システムプロパティ取得用SQL */
    private static final String SYSTEM_PROPERTIES_SELECT = "select * from system_properties ";

    /** システムプロパティ値 ： サイトセッションタイムアウト */
    public static final String SITE_SESSION_TIMEOUT = "SITE_SESSION_TIMEOUT";

    /** システムプロパティ値 ： サイトセッション滞在上限時間 */
    public static final String SITE_SESSION_STAY_LIMIT = "SITE_SESSION_STAY_LIMIT";

    /** システムプロパティ値 ： サイトセッション滞在上限チェック経過時間 */
    public static final String SITE_SESSION_STAY_LIMIT_CHECK_TERM = "SITE_SESSION_STAY_LIMIT_CHECK_TERM";

    /** システムプロパティ値 ： 外部サイト経由チェック経過時間 */
    public static final String SITE_SESSION_OUTER_SITE_CHECK_TERM = "SITE_SESSION_OUTER_SITE_CHECK_TERM";

    /** システムプロパティ値 ： ログインタイムアウト時間 */
    public static final String LOGIN_TIMEOUT = "LOGIN_TIMEOUT";

    /** システムプロパティ値 ： クッキーエラー発生時遷移先URL */
    public static final String COOKIE_ERROR_REDIRECT_URL = "COOKIE_ERROR_REDIRECT_URL";

	/** システムプロパティ値 ： 認証エラー発生時遷移先URL */
	public static final String AUTH_ERROR_REDIRECT_URL = "AUTH_ERROR_REDIRECT_URL";

    /** システムプロパティ値 ： httpでの認証サーバへのURL */
    public static final String AUTH_HTTP_SERVER = "AUTH_HTTP_SERVER";

    /** システムプロパティ値 ： httpsでの認証サーバへのURL */
    public static final String AUTH_HTTPS_SERVER = "AUTH_HTTPS_SERVER";

    /** 唯一のインスタンス */
    private static SystemPropertiesDb systemPropertiesDb = new SystemPropertiesDb();

    /** システムプロパティの一覧 */
    private Map systemProperties = null;

    /**
     * 生成不能コンストラクタ
     */
    private SystemPropertiesDb() {
    }

    /**
     * 唯一のインスタンスを返す。
     * 
     * @return
     */
    public static SystemPropertiesDb getInstance() {
        return systemPropertiesDb;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
     */
    public void init() throws SQLException {

        Map systemProperties = new HashMap();

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess();

            // サイト情報一覧を検索する。
            rs = dbAccess.executeQuery(SYSTEM_PROPERTIES_SELECT);
            while (dbAccess.next(rs)) {
                systemProperties.put(ValueUtil.nullToStr(rs.getString("name")),
                        ValueUtil.nullToStr(rs.getString("value")));
            }

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

        // システムプロパティの一覧を更新する。
        this.systemProperties = systemProperties;

    }

    /**
     * プロパティの値をチェックする。
     * 
     * @param normalKeys
     * @param termKeys
     * @throws Exception
     */
    public void check(String[] normalKeys, String[] termKeys) throws Exception {

        // 必要なプロパティ値がそろっているか確認する。
        for (int i = 0; i < normalKeys.length; i++) {
            if (!systemProperties.containsKey(normalKeys[i])) {
                throw new Exception("system property '" + normalKeys[i]
                        + "' is not set");
            }
        }

        // 時間を表すプロパティ値に正しい値が設定されているか確認する。
        for (int i = 0; i < termKeys.length; i++) {
            if (toSecondValue((String) systemProperties.get(termKeys[i])) == 0) {
                throw new Exception("system property '" + termKeys[i]
                        + "' is invalid");
            }
        }
    }

    /**
     * システムプロパティをすべて返す。
     * 
     * @return
     */
    public Map getSystemProperties() {
    	return systemProperties;
    }
    
    /**
     * 指定されたname値に対応するvalue値を返す。
     * 
     * @param name
     * @return
     */
    public String get(String name) {
        Map systemProperties = this.systemProperties;
        return (String) systemProperties.get(name);
    }

    /**
     * 指定されたname値に対応するvalue値を<br>
     * 末尾の時間の単位を見て秒にして返す。<br>
     * d : 日<br>
     * h : 時<br>
     * m : 分<br>
     * s : 秒<br>
     * 
     * @param name
     * @return
     */
    public int getSecondValue(String name) {
        String value = get(name);
        return toSecondValue(value);
    }

    /**
     * 指定されたvalue値を<br>
     * 末尾の時間の単位を見て秒にして返す。<br>
     * d : 日<br>
     * h : 時<br>
     * m : 分<br>
     * s : 秒<br>
     * 
     * @param value
     * @return
     */
    private int toSecondValue(String value) {
        char postfix = ' ';
        int number = 0;
        if (value.length() > 0) {
            postfix = value.charAt(value.length() - 1);
            number = ValueUtil.toint(value.substring(0, value.length() - 1));
        }

        if (number != 0) {
            switch (postfix) {
            case 'd':
                return number * 24 * 60 * 60;
            case 'h':
                return number * 60 * 60;
            case 'm':
                return number * 60;
            case 's':
                return number;
            }
        }

        return 0;
    }
}
