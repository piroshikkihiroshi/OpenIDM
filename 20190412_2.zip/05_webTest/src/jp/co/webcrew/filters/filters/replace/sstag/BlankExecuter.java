package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 空のサーバサイドタグを意味するExecuterクラス。
 * 
 * @author kurinami
 */
public class BlankExecuter extends SSTagExecuter {

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {
		return "";
	}

}
