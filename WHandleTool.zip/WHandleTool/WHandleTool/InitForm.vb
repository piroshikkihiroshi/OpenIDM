﻿Imports System.Text 'stringbuilder用
Imports WHandleTool.DeclareCs
Imports WHandleTool.commonFunc
Imports WHandleTool.sqlMng
Imports WHandleTool.typeCls

Imports NPOI.SS.UserModel
Imports NPOI.XSSF.UserModel
Imports System.IO
Imports NPOI.HSSF.UserModel


Public Class InitForm
    Public tmpDatas As typeCls

    Private Sub InitForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Location = New Point(10, 10)
        'Me.Size = New Point(glDispWidth - 70, glDispHeight - 70)    'フォームのサイズ(ディスプレイサイズから計算)

        Dim objFnc As New commonFunc()
        Dim Datainfo As New Collection

        Dim objExcelSh As HSSFSheet
        Dim ret As Integer

        'iniファイル読み込み
        ret = objFnc.imporIni()

        If ret = 0 Then

            Dim fileName = TGT_BOOK_NAME
            Dim sheetName = TGT_SHEET_NAME

            objExcelSh = objFnc.getExcelObj(fileName, sheetName)

            'row,clmは0から始まる
            Dim row = objExcelSh.GetRow(ST_ROW - 3)

            Dim endClm = row.LastCellNum

            For lngLoopIdx = ST_CLM To endClm Step 5
                Dim tgtCell = objExcelSh.GetRow(ST_ROW - 3).GetCell(lngLoopIdx - 1)
                tgtList.Items.Add(tgtCell.StringCellValue)

            Next lngLoopIdx

            objExcelSh = Nothing
        Else
            MsgBox("INIファイルが読み込めませんでした。" & INI_FILE & "が存在することを確認してください。", vbOKOnly, "エラー")
        End If


    End Sub


    Private Sub tgtList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tgtList.KeyDown
        If (e.KeyCode = System.Windows.Forms.Keys.Return) And (tgtList.SelectedIndex <> -1) Then
            Call mainAct()
        End If
    End Sub


    Function mainAct() As Integer


        Dim objFnc As New commonFunc()
        Dim ret As Long
        Dim Datainfo As New Collection
        Dim tmpDatas As typeCls
        Dim objExcelSh As HSSFSheet
        Dim listStatus = -1
        Dim tgtClm As Long = 0

        Dim fileName = TGT_BOOK_NAME
        Dim sheetName = TGT_SHEET_NAME

        objExcelSh = objFnc.getExcelObj(fileName, sheetName)


        'row,clmは0から始まる
        Dim row = objExcelSh.GetRow(ST_ROW - 3)

        Dim endClm = row.LastCellNum


        For lngLoopIdx = ST_CLM To endClm Step 5
            Dim tgtCell = objExcelSh.GetRow(ST_ROW - 3).GetCell(lngLoopIdx - 1)

            If tgtList.SelectedItem = tgtCell.StringCellValue Then
                tgtClm = lngLoopIdx
                listStatus = 0
                Exit For
            End If


        Next lngLoopIdx

        Dim endRow As Long = objExcelSh.LastRowNum



        '情報をコレクションに詰め込む
        For lngLoopIdx = ST_ROW To endRow
            row = objExcelSh.GetRow(lngLoopIdx - 1)
            If row.GetCell(tgtClm - 1).StringCellValue = "" Then
                Exit For
            End If
            tmpDatas = New typeCls()
            tmpDatas.tgtVal = row.GetCell(tgtClm - 1).StringCellValue
            tmpDatas.tgtStatus = row.GetCell(tgtClm).NumericCellValue
            tmpDatas.tgtRow = lngLoopIdx
            tmpDatas.tgtClm = tgtClm
            tmpDatas.actStatus = row.GetCell(tgtClm + 1).StringCellValue
            Datainfo.Add(tmpDatas)
            tmpDatas = Nothing
        Next lngLoopIdx




        'メイン処理
        For Each tmpData In Datainfo


            If tmpData.actStatus = "○" Then
                ret = objFnc.hwndAct(tmpData)
                If ret = -1 Then

                    ret = MsgBox("ウィンドウハンドルが取得できませんでした。" & vbCrLf & "row:" & tmpData.tgtRow & " clm:" & tmpData.tgtClm, vbOKOnly, "エラー")
                    End
                End If

            End If

        Next tmpData



        If listStatus <> 0 Then
            ret = MsgBox("処理をする対象を選択してください。", vbOKOnly, "処理をする対象を選択してください。")
        Else
            ret = MsgBox("処理が完了しました。", vbOKOnly, "実行完了")

        End If


        objExcelSh = Nothing


        mainAct = 0

    End Function


End Class