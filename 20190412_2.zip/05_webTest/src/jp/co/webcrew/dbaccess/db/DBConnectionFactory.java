package jp.co.webcrew.dbaccess.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.PropertiesUtil;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * コネクションを管理するDBクラス。
 *
 * @author kurinami
 */
public class DBConnectionFactory {

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(DBConnectionFactory.class);

//	private static final Logger log = null;

	/** デフォルトのコネクション最少数 */
	public static final int DEFAULT_MIN_CONNECTION = 5;

	/** デフォルトのコネクション最大数 */
	public static final int DEFAULT_MAX_CONNECTION = 20;

	/** プールからの接続取得リトライ回数 */
	public static final int RETRY_COUNT = 5;

	/** DB設定を保持するプロパティ */
	private static PropertiesUtil propertiesUtil = new PropertiesUtil(
			"db.properties");

	/** コネクション名ごとのプール情報を保持するmap */
	private static Map poolMapByName = Collections
			.synchronizedMap(new HashMap());

	/** 実行スレッドにコネクション名ごとにコネクションを関連付けるためのmap */
	private static Map threadMapByName = Collections
			.synchronizedMap(new HashMap());

	/**
	 * スレッドに関連付けたデフォルトのコネクションを確保する。
	 */
	public static void registConnectionOnThread() {
		registConnectionOnThread("");
	}

	/**
	 * スレッドに関連付けたコネクションを確保する。
	 */
	public static void registConnectionOnThread(String name) {
		try {

			Map connectionMapByThread = (Map) threadMapByName.get(name);
			if (connectionMapByThread == null) {
				connectionMapByThread = Collections
						.synchronizedMap(new HashMap());
				threadMapByName.put(name, connectionMapByThread);
			}

			if (!connectionMapByThread.containsKey(Thread.currentThread())) {
				connectionMapByThread.put(Thread.currentThread(),
						getConnection(name));
				log.debug("name:[" + name + "] スレッドへのコネクション関連付け成功");
			}
		} catch (SQLException e) {
			log.error("name:[" + name + "] スレッドへのコネクション関連付け失敗");
		}
	}

	/**
	 * スレッドへのデフォルトのコネクションの関連付けを削除する。
	 */
	public static void unregistConnectionOnThread() {
		unregistConnectionOnThread("");
	}

	/**
	 * スレッドへのコネクションの関連付けを削除する。
	 */
	public static void unregistConnectionOnThread(String name) {
		Map connectionMapByThread = (Map) threadMapByName.get(name);
		if (connectionMapByThread != null) {
			Connection conn = (Connection) connectionMapByThread.remove(Thread
					.currentThread());
			if (conn != null) {
				log.debug("name:[" + name + "] スレッドへのコネクション関連付け解除");
				releaseConnection(name, conn, false);
			}
		}
	}

	/**
	 * コネクションを返す。
	 *
	 * @return
	 * @throws DBConnectionException
	 */
	public static Connection getConnection(String name)
			throws DBConnectionException {

		return newConnection(name);
		// t_ueda
//		// 実行スレッドに関連付けられたコネクションが存在する場合それを返す。
//		Map connectionMapByThread = (Map) threadMapByName.get(name);
//		if (connectionMapByThread != null) {
//			Connection tempConn = (Connection) connectionMapByThread.get(Thread
//					.currentThread());
//			if (tempConn != null) {
//				log.debug("name:[" + name + "] スレッドへ関連付けたコネクションを使用");
//				return tempConn;
//			}
//		}
//
//		String poolEnable = getDBProperty(name, "poolEnable");
//
//		if (poolEnable.equals("true")) {
//			log.debug("name:[" + name + "] getConnection  プールからのDB接続取得開始");
//
//			for (int i = 0; i < RETRY_COUNT; i++) {
//				Connection conn = getPoolConnection(name);
//				if (conn != null) {
//					return conn;
//				}
//
//				try {
//					Thread.sleep(10 * 1000);
//				} catch (InterruptedException e) {
//					log.error("name:[" + name + "] 予期せぬエラー", e);
//				}
//			}
//			DBConnectionException dbConnectionException = new DBConnectionException();
//			log.error("name:[" + name + "] プールからの接続取得エラー",
//					dbConnectionException);
//			throw dbConnectionException;
//
//		} else {
//			log.debug("name:[" + name + "] getConnection  プールなしのDB接続取得開始");
//			return newConnection(name);
//		}
	}

	/**
	 * コネクションを開放する。
	 *
	 * @param conn
	 * @param force
	 */
	public static void releaseConnection(String name, Connection conn,
			boolean force) {

		// 実行スレッドに関連付けられたコネクションの場合
		Map connectionMapByThread = (Map) threadMapByName.get(name);
		if (connectionMapByThread != null) {
			Connection tempConn = (Connection) connectionMapByThread.get(Thread
					.currentThread());
			if (tempConn == conn) {
				if (force == false) {
					// 強制開放が指定されていなければなにもしない。
					return;
				} else {
					// 強制開放が指定されている場合は、関連付けを削除して、その後の処理に進む。
					connectionMapByThread.remove(Thread.currentThread());
				}
			}
		}

		String poolEnable = getDBProperty(name, "poolEnable");

		if (poolEnable.equals("true")) {
			log.debug("name:[" + name + "] releaseConnection  プールへのDB接続開放開始");
			releasePoolConnection(name, conn, force);
		} else {
			log.debug("name:[" + name + "] releaseConnection  プールなしのDB接続開放開始");
			closeConnection(conn);
		}
	}

	/**
	 * プールからコネクションを取得する。
	 *
	 * @return
	 * @throws DBConnectionException
	 */
	private static Connection getPoolConnection(String name)
			throws DBConnectionException {

		// プールしているコネクション
		List poolConnections = null;

		// 使用中のコネクション
		List useConnections = null;

		// コネクション名ごとのプール情報を取得する。
		if (poolMapByName.containsKey(name)) {
			List[] lists = (List[]) poolMapByName.get(name);
			poolConnections = lists[0];
			useConnections = lists[1];
		} else {
			poolConnections = Collections.synchronizedList(new LinkedList());
			useConnections = Collections.synchronizedList(new LinkedList());
			poolMapByName.put(name, new List[] { poolConnections,
					useConnections });
		}

		// 空いているコネクションを取得する。
		Connection conn = null;
		try {
			while (true) {
				conn = (Connection) poolConnections.remove(0);
				if (checkConnection(name, conn)) {
					break;
				}
			}
		} catch (IndexOutOfBoundsException e) {
			// 現在プールに空きがない場合、
			log.debug("name:[" + name + "] getPoolConnection  プールに空き接続なし");

			int maxConection = getMaxConnection(name);
			log.debug("name:[" + name + "] getPoolConnection  現在のプール数("
					+ useConnections.size() + ")");
			if (useConnections.size() < maxConection) {
				// 使用中のコネクション数が最大数に達していない場合、
				// 新規のコネクションを作成する。
				log.debug("name:[" + name + "] getPoolConnection  最大プール数("
						+ maxConection + ")に達していないため新規接続を作成");
				conn = newConnection(name);
			} else {
				// 使用中のコネクション数が最大数に達している場合、
				// nullを返す。
				log.debug("name:[" + name + "] getPoolConnection  最大プール数("
						+ maxConection + ")に達したため新規接続を作成せず");
				return null;
			}
		}

		// 使用中リストに追加する。
		useConnections.add(conn);

		// プールの使用を通知する。
		DBConnectionThread.noticeUse(name);

		return conn;
	}

	/**
	 * プールにコネクションを返す。
	 *
	 * @param conn
	 * @param force
	 */
	private static void releasePoolConnection(String name, Connection conn,
			boolean force) {

		// プールしているコネクション
		List poolConnections = null;

		// 使用中のコネクション
		List useConnections = null;

		// コネクション名ごとのプール情報を取得する。
		List[] lists = (List[]) poolMapByName.get(name);
		poolConnections = lists[0];
		useConnections = lists[1];

		// 使用中リストから削除する。
		boolean remove = useConnections.remove(conn);

		if (force == true) {
			// コネクションの強制開放が指定され場合、
			log.debug("name:[" + name
					+ "] releasePoolConnection  強制開放が指定されたため接続を開放");
			closeConnection(conn);
		} else if (remove == false) {
			// 使用中リストに残っていなかった場合、
			log.debug("name:[" + name
					+ "] releasePoolConnection  使用中リストからはずされたため接続を強制的に開放");
			closeConnection(conn);
		} else {
			int minConection = getMinConnection(name);
			log.debug("name:[" + name + "] releasePoolConnection  現在のプール数("
					+ useConnections.size() + ")");
			if (poolConnections.size() < minConection) {
				// コネクションの最小数分プールしていない場合は、
				// コネクションをプールに戻す。
				log.debug("name:[" + name + "] releasePoolConnection  最小プール数("
						+ minConection + ")に達していないため接続をプールに戻す");

				// 安全のための強制的にrollbackをかけておく。
				try {
					conn.rollback();
				} catch (SQLException e) {
				}

				poolConnections.add(conn);
			} else {
				// コネクションを最小数分プールしている場合は、
				// コネクションを破棄する。
				log.debug("name:[" + name + "] releasePoolConnection  最小プール数("
						+ minConection + ")超過のため接続を開放");
				closeConnection(conn);
			}
		}

	}

	/**
	 * 接続が有効かを確認する。
	 *
	 * @param conn
	 * @return
	 */
	private static boolean checkConnection(String name, Connection conn) {

		Statement st = null;
		try {
			conn.setAutoCommit(true);

			String pingQuery = getDBProperty(name, "pingQuery");
			if (pingQuery.length() > 0) {

				log.debug("name:[" + name + "] checkConnection  [pingQuery: "
						+ pingQuery + "]");
				st = conn.createStatement();
				st.executeQuery(pingQuery);

				log.debug("name:[" + name + "] checkConnection  接続確認OK");
				return true;

			} else {
				log.debug("name:[" + name
						+ "] checkConnection  pingQuery未設定のため接続確認省略");
				return true;
			}
		} catch (SQLException e) {

			log.debug("name:[" + name + "] checkConnection  接続確認NG");
			log.error("name:[" + name + "] DBエラー", e);
			return false;
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				log.error("name:[" + name + "] statementクローズ", e);
			}
		}

	}

	/**
	 * 各プールごとのコネクション数の最小値
	 *
	 * @return
	 */
	private static int getMinConnection(String name) {
		int minConnection = DEFAULT_MIN_CONNECTION;
		try {
			minConnection = Integer.parseInt(getDBProperty(name,
					"poolMinConnection"));
		} catch (Exception e) {
			log.error("name:[" + name + "] poolMinConnection取得エラー", e);
		}
		return minConnection;
	}

	/**
	 * 各プールごとのコネクション数の最大値
	 *
	 * @return
	 */
	private static int getMaxConnection(String name) {
		int maxConnection = DEFAULT_MAX_CONNECTION;
		try {
			maxConnection = Integer.parseInt(getDBProperty(name,
					"poolMaxConnection"));
		} catch (Exception e) {
			log.error("name:[" + name + "] poolMaxConnection取得エラー", e);
		}
		return maxConnection;
	}

	/**
	 * 新しいコネクションを作成する。
	 *
	 * @return
	 * @throws DBConnectionException
	 */
	private static Connection newConnection(String name)
			throws DBConnectionException {
		// t_ueda
		String jdbcDriver = "org.postgresql.Driver";
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "postgres";

//		String jdbcDriver = getDBProperty(name, "driverClassName");
//		String url = getDBProperty(name, "url");
//		String username = getDBProperty((name.length() == 0 ? "" : name + ".") + "username");
//		String password = getDBProperty((name.length() == 0 ? "" : name + ".") + "password");

		log.debug("name:[" + name + "] newConnection  DB接続作成 [jdbcDriver: "
				+ jdbcDriver + "]  [url: " + url + "]  [username: " + username
				+ "]  [password: " + password + "]");

		if (username.trim().length() == 0) {
			DBConnectionException dbConnectionException = new DBConnectionException();
			log.error("name:[" + name + "] db.propertiesに" + name + ".username"
					+ " が指定されていません。", dbConnectionException);
			throw dbConnectionException;
		}

		try {
			Class.forName(jdbcDriver);
			return DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
//			log.error("name:[" + name + "] DB接続エラー", e);
			throw new DBConnectionException();
		}
	}

	/**
	 * コネクションを物理的に開放する。
	 *
	 * @param conn
	 */
	private static void closeConnection(Connection conn) {
		if (conn != null) {

			log.debug("closeConnection  DB接続開放");

			try {
				conn.close();
			} catch (SQLException e) {
				log.error("DB開放エラー", e);
			}
		}
	}

	/**
	 * プールの中身を新しくする。
	 */
	public static void poolRefresh(String name) {

		String poolEnable = getDBProperty(name, "poolEnable");

		if (poolEnable.equals("true")) {

			// コネクション名ごとのプール情報を作り直す。
			List[] lists = (List[]) poolMapByName.get(name);

			List tempPoolConnections = lists[0];
			lists[0] = Collections.synchronizedList(new LinkedList());
			lists[1] = Collections.synchronizedList(new LinkedList());

			// プールしていたコネクションを破棄する。
			while (!tempPoolConnections.isEmpty()) {
				Connection conn = (Connection) tempPoolConnections.remove(0);
				closeConnection(conn);
			}

			// 新たにコネクションをプールに入れる。
			try {
				while (lists[0].size() < getMinConnection(name)) {
					lists[0].add(newConnection(name));
				}
			} catch (SQLException e) {
			}
		} else {
			// プールが有効でない場合は何もしない。
		}
	}

	/**
	 * データベース用の設定値を取得する。
	 *
	 * @param key
	 * @return
	 */
	public static String getDBProperty(String key) {
		return ValueUtil.nullToStr(propertiesUtil.getProperty(key));
	}

	/**
	 * コネクション名ごとの設定値を取得する。
	 *
	 * @param name
	 * @param key
	 * @return
	 */
	public static String getDBProperty(String name, String key) {
		String value = propertiesUtil.getProperty(name + "." + key);
		if (value == null || name.length() == 0) {
			value = getDBProperty(key);
		}
		return value;
	}

	/**
	 * db.properties に記述されている schema名を返すヘルパー関数
	 *
	 * @param key
	 * @return
	 */
	public static String getSchemaFromPropeties() {
		return getSchemaFromPropeties("");
	}

	public static String getSchemaFromPropeties(String suffix) {
		String schema = propertiesUtil.getProperty("schema");

		if (schema == null || schema.trim().length() == 0) {
			return "";
		} else {
			return schema + suffix;
		}
	}
}