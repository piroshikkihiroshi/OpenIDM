package jp.co.webcrew.common.mail.proc;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.common.util.proc.Base64;
import jp.co.webcrew.common.util.proc.XMLStringUtils;
import oracle.sql.CLOB;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Holds an entire calculation
 */
public class CalculationSet implements Comparator {
    private static final String ELEM_CALCULATION = "calculation";
    private static final String ELEM_UPDATE = "update";
    private static final String ELEM_CALL = "call";
    private static final String ELEM_PARAMETER_ROW = "parameterRow";
    private static final String ELEM_PARAMETER = "parameter";
    
    private static final String ATTR_NAME = "name";
    private static final String ATTR_TYPE = "type";
    private static final String ATTR_DB_INTERNAL = "dbInternal";
        
    private Expression[] childCalculations;
    private Boolean doInternalToDatabase;
    
    private static final String ILLEGAL_CHARS[][] = new String [][] {
        {".", "_"}, {"?", "_"}, {":", "_"}, {";", "_"}, {"@", "_"}, {"#", "_"}
    };
    
    /**
     * Constructor. Parser for the calculation lists
     *
     * @param node The DOM representing the config for this rule and it's children
     */
    public CalculationSet(Node node) {

        NodeList nodeList = node.getChildNodes();
        List calcs = new ArrayList();

        for (int n = 0; n < nodeList.getLength(); n++) {
            Node childNode = nodeList.item(n);

            if (childNode.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            } else if (childNode.getNodeName().equals(ELEM_CALCULATION)) {
                calcs.add(new CalculationExpression(childNode));
            } else if (childNode.getNodeName().equals(ELEM_CALL)) {
                calcs.add(new CallableExpression(childNode));
            } else if (childNode.getNodeName().equals(ELEM_UPDATE)) {
                calcs.add(new UpdateExpression(childNode));
            }
        }
        
        // Get the externally relevant wildcard names
        NamedNodeMap atts = node.getAttributes();
        Node doInternalToDatabase = atts.getNamedItem(ATTR_DB_INTERNAL);
        if (doInternalToDatabase != null) {
            this.doInternalToDatabase = new Boolean(doInternalToDatabase.getNodeValue());
        }

        System.out.println("Found " + calcs.size() + " calculations");

        this.childCalculations = (Expression []) calcs.toArray(new Expression[calcs.size()]);

        Arrays.sort(this.childCalculations, this);
    }

    public Boolean isDoInternalToDatabase() {
        return doInternalToDatabase;
    }
    
    /**
     * Comparator implementation, so we can sort Rules in the array
     */
    public int compare(Object one, Object two) {
        int oneOrder = ((Expression) one).getOrderIndex();
        int twoOrder = ((Expression) two).getOrderIndex();

        if (oneOrder == twoOrder) {
            return 0;
        } else if (oneOrder < twoOrder) {
            return -1;
        } else {
            return 1;
        }
    }

    /**
     * Loops through the steps of the calculation set and executes each of the rows in the 
     * wildcardRows list. If a flow variation is detected for any row, that row is processed 
     * through to completion, and then we proceed to the next row.   
     * 
     * @param connection JDBC Connection
     * @param wildcardRows A list of maps, containing a WildcardValue object for each parameter 
     * @throws SQLException
     */
    public void evaluate(Connection connection, List wildcardRows)
        throws SQLException {
        
        List workingSet = new ArrayList(wildcardRows);
        
        // Execute the calculations
        for (int n = 0; n < this.childCalculations.length; n++) {
            
            this.childCalculations[n].evaluateExpression(connection, workingSet);

            // Check for list for flow variation requests, and if found, add them to 
            // the list for removal, because we assume they are finished
            List finishedRows = new ArrayList();
            for (Iterator k = workingSet.iterator(); k.hasNext(); ) {
                Map wildcards = (Map) k.next();
                if (checkForFlowVariation(wildcards, n, connection)) {
                    finishedRows.add(wildcards);
                }
            }

            // Remove the variation rows from the list - assume they are finished.
            for (Iterator k = finishedRows.iterator(); k.hasNext(); ) {
                workingSet.remove(k.next());
            }
        }
    }
    
    /**
     * Checks for a flow variation, and if one is found, processes it through to the end of the chain.
     * This is inefficient for chains with large nos of variations, but is the only safe way to make it work.
     * 
     * A return value of true means we should abort the processing of the chain for this wildcard set, because it
     * has progressed as far as it can. 
     */
    protected boolean checkForFlowVariation(Map wildcards, int index, Connection connection) throws SQLException {
        FlowVariation fv = this.childCalculations[index].checkForVariation(wildcards);
        if (fv != null) {
            String thrownErrorMessage = fv.getThrownErrorMessage(wildcards);
            if (thrownErrorMessage != null) {
                throw new RuntimeException("CalculationSet error: " + thrownErrorMessage);
            } else if (fv.getGotoOrder() == null) {
                return true;
            } else {
                // Find calc matching desired goto index
                boolean continueFlag = true;
                int gotoOrder = fv.getGotoOrder().intValue(); 
                for (int searchIdx = 0; (searchIdx < this.childCalculations.length) && continueFlag; searchIdx++) {
                    // Set the loop index to the one before our match, so that
                    // we can continue as if from that point
                    if (gotoOrder == this.childCalculations[searchIdx].getOrderIndex()) {
                        index = searchIdx - 1;
                        continueFlag = false;
                    }
                }
                
                // If we didn't find our goto, throw an error
                if (continueFlag) {
                    throw new RuntimeException("Can't find calculation " +
                            "with order=" + gotoOrder + " for calculation index " + 
                            this.childCalculations[index].getOrderIndex());
                } else {
                    List singleItemList = new ArrayList();
                    singleItemList.add(wildcards);
                    
                    // Loop until we find a flow variation or the end, then return true
                    boolean foundVariation = false;
                    while (!foundVariation && (this.childCalculations.length != index + 1)) {
                        index++;
                        this.childCalculations[index].evaluateExpression(connection, singleItemList);
                        foundVariation = checkForFlowVariation(wildcards, index, connection);
                    }
                    return true;
                }
            }
        } else {
            return false;
        }
    }

    /**
     * Simple oracle stull null value replacer.
     */
    private static Object nvl(Object input, Object defaultValue) {
        return (input == null ? defaultValue : input);
    }

    /**
     * Parse the xml calculation set into the java CalculationSet object.
     */
    public static CalculationSet buildCalculationSetFromXML(String xml) {
        Document doc = XMLStringUtils.parseXML(xml);
        return new CalculationSet(doc.getDocumentElement());
    }

    /**
     * Accepts CLOB parameters, so we can call with large input
     */
    public static Clob dbServerEvaluate(Clob calculationRulesetXML,
            Clob inWildcardsXML) throws SQLException, IOException {
        
        if (calculationRulesetXML == null) {
            return null;
        } else if (inWildcardsXML == null) {
            return null;
        }
        
        Connection connection = ((CLOB) calculationRulesetXML).getOracleConnection();

        int read = 0;
        char buffer[] = new char[1000];

        // Calculation set
        Reader csIn = calculationRulesetXML.getCharacterStream();
        StringWriter csOut = new StringWriter();
        while ((read = csIn.read(buffer)) != -1) {
            csOut.write(buffer, 0, read);
        }
        csIn.close();

        // Input xml
        Reader iwIn = inWildcardsXML.getCharacterStream();
        StringWriter iwOut = new StringWriter();
        while ((read = iwIn.read(buffer)) != -1) {
            iwOut.write(buffer, 0, read);
        }
        iwIn.close();

        List wildcardRows = parseWildcardXML(iwOut.toString());
        CalculationSet cs = buildCalculationSetFromXML(csOut.toString());
        cs.evaluate(connection, wildcardRows);
        String outputXML = writeXMLWildcardOutput(wildcardRows);
        
        CLOB outputClob = CLOB.createTemporary(connection, false, CLOB.DURATION_SESSION);
        outputClob.setString(1, outputXML);
        return outputClob;
    }

    /**
     * Varchar version, so we can call with less overhead
     */
    public static Clob dbServerEvaluate(String calculationRulesetXML,
            String inWildcardsXML) throws SQLException, IOException {
        
        if (calculationRulesetXML == null) {
            return null;
        } else if (inWildcardsXML == null) {
            return null;
        }
        
        Connection connection = DriverManager.getConnection("jdbc:default:connection:");
        List wildcardRows = parseWildcardXML(inWildcardsXML);
        CalculationSet cs = buildCalculationSetFromXML(calculationRulesetXML);
        cs.evaluate(connection, wildcardRows);
        String outputXML = writeXMLWildcardOutput(wildcardRows);
        
        CLOB outputClob = CLOB.createTemporary(connection, false, CLOB.DURATION_SESSION);
        outputClob.setString(1, outputXML);
        return outputClob;
    }

    public static List applicationServerEvaluate(Connection connection, 
            String calculationRulesetXML, String inWildcardsXML) throws SQLException, IOException {

        if (calculationRulesetXML == null) {
            return null;
        } else if (inWildcardsXML == null) {
            return null;
        }
        
        long startTime = System.currentTimeMillis();
        
        // Add a check here to see if we should use the db stored proc
        String overrideProperty = System.getProperty("webcrew.calculationSet.disableDBExec");
        if (overrideProperty == null) {
            overrideProperty = "false";
        }
        List resultRows = new ArrayList();
        CalculationSet parsed = buildCalculationSetFromXML(calculationRulesetXML);
        
        // Default to execute inside the db if more than 1 calc found
        boolean useJavaStoredProc = false;
        if (overrideProperty.equalsIgnoreCase("true")) {
            useJavaStoredProc = false;
        } else if (parsed.doInternalToDatabase != null) {
            useJavaStoredProc = parsed.doInternalToDatabase.booleanValue();
        } else {
            useJavaStoredProc = (parsed.childCalculations.length > 1) || 
                    (inWildcardsXML.length() > 500);
        }
        
        if (useJavaStoredProc) {
                        
            if ((calculationRulesetXML.length() > 4000) ||
                    (inWildcardsXML.length() > 4000)) {
                System.out.println("Evaluating calculation set db server side - CLOB version");

                Connection oraConn = QueryFunctions.getDelegatedConnection(connection);

                CLOB clobRuleset = CLOB.createTemporary(oraConn, false, CLOB.DURATION_SESSION);
                clobRuleset.setString(1,  calculationRulesetXML);
                CLOB clobInput = CLOB.createTemporary(oraConn, false, CLOB.DURATION_SESSION);
                clobInput.setString(1,  inWildcardsXML);

                // build a stored procedure call
                CallableStatement cs = null;
                try {
                    cs = oraConn.prepareCall("{ call ? := calculation_set.execute_calc_clob(?, ?) }");
                    cs.registerOutParameter(1, Types.CLOB);
                    cs.setClob(2, clobRuleset);
                    cs.setClob(3, clobInput);
                    cs.execute();
                    Clob outputClob = cs.getClob(1);
                    String resultXML = QueryFunctions.getAsString(outputClob.getCharacterStream());
                    cs.close();
                    resultRows = parseWildcardXML(resultXML);
                } finally {
                    if (cs != null) {
                        cs.close();
                    }
                }
            } else {
                System.out.println("Evaluating calculation set db server side - VARCHAR version");

                // build a stored procedure call to the varchar version
                CallableStatement cs = null;
                try {
                    cs = connection.prepareCall("{ call ? := calculation_set.execute_calc(?, ?) }");
                    cs.registerOutParameter(1, Types.CLOB);
                    cs.setCharacterStream(2, new StringReader(calculationRulesetXML), calculationRulesetXML.length());
                    cs.setCharacterStream(3, new StringReader(inWildcardsXML), inWildcardsXML.length());
                    cs.execute();
                    Clob outputClob = cs.getClob(1);
                    String resultXML = QueryFunctions.getAsString(outputClob.getCharacterStream());
                    resultRows = parseWildcardXML(resultXML);
                } finally {
                    if (cs != null) {
                        cs.close();
                    }
                }
            }
        } else {
            System.out.println("Evaluating calculation set application server side");
            List wildcardRows = parseWildcardXML(inWildcardsXML);
            CalculationSet cs = buildCalculationSetFromXML(calculationRulesetXML);
            cs.evaluate(connection, wildcardRows);
            resultRows.addAll(wildcardRows);
        }
        
        System.out.println("Calculation set evaluation time: " + 
                (System.currentTimeMillis() - startTime) + "ms");
        return resultRows;
    }    

    public static Map buildCalculationSetInputMap(Map inputVariables) {
        Map output = new HashMap();
        for (Iterator i = inputVariables.keySet().iterator(); i.hasNext();) {
            String key = (String) i.next();
            Object value = inputVariables.get(key);
            WildcardValue wc = makeWildcardValue(key, value);
            output.put(wc.getName(), wc);
        }
        return output;
    }
    
    public static WildcardValue makeWildcardValue(String key, Object value) {

        String type = QueryFunctions.STRING;
        if (value instanceof Long) {
            type = QueryFunctions.NUMBER;
        } else if (value instanceof Float) {
            type = QueryFunctions.FLOAT;
        } else if (value instanceof Date) {
            type = QueryFunctions.DATE + "yyyy/MM/dd HH:mm:ss";
        } else if (value instanceof byte[]) {
            type = QueryFunctions.BLOB;
        }
        return makeWildcardValue(key, value, type);
    }
    
    protected static WildcardValue makeWildcardValue(String key, Object value, String type) {
        return new WildcardValue(key.toLowerCase(), value, type);
    }
    
    public static WildcardValue findWildcardInMap(String key, Map wildcards) {
        return (WildcardValue) wildcards.get(key.toLowerCase());
    }
    
    public static Map unpackCalculationSetMap(Map calcSetResults) {
        Map outputVariables = new HashMap();
        for (Iterator i = calcSetResults.values().iterator(); i.hasNext();) {
            WildcardValue wc = (WildcardValue) i.next();
            outputVariables.put(wc.getName(), wc.getValue());
        }
        return outputVariables;
    }

    public static String makeXMLWildcards(List input) {
        StringBuffer out = new StringBuffer();
        for (Iterator i = input.iterator(); i.hasNext(); ) {
            out.append(makeXMLWildcards((Map) i.next(), ELEM_PARAMETER_ROW));
        }
        return XMLStringUtils.element("in", out.toString(), null, false);
    }
    
    public static String makeXMLWildcards(Map input) {
        return makeXMLWildcards(input, "in");
    }
    
    public static String makeXMLWildcards(Map input, String parentName) {
        StringBuffer out = new StringBuffer();

        // sort the keys
        Object keys[] = input.keySet().toArray();
        Arrays.sort(keys);
        
        for (int n = 0; n < keys.length; n++) {
            String name = (String) keys[n];
            Object value = input.get(name);
            Map atts = new HashMap();
            String type = QueryFunctions.STRING;
            if (value == null) {
                type = QueryFunctions.STRING;
            } else if (value instanceof Float) {
                type = QueryFunctions.FLOAT;
            } else if (value instanceof Long) {
                type = QueryFunctions.NUMBER;
            } else if (value instanceof Integer) {
                type = QueryFunctions.NUMBER;
            } else if (value instanceof byte []) {
                type = QueryFunctions.BLOB;
            } else if (value instanceof Date) {
                type = QueryFunctions.DATE + "yyyyMMddHHmmss";
            } else if ((value instanceof String) && 
                        (("" + value).length() > 4000)) {
                type = QueryFunctions.LONGSTRING;
            }
            atts.put("type", type);
            atts.put("name", name);
            out.append(XMLStringUtils.element("parameter", convertToStringForm(value, type), atts, true));
        }

        return XMLStringUtils.element(parentName, out.toString(), null, false);
    }
    
    public static String writeXMLWildcardOutput(List input) {
        StringBuffer out = new StringBuffer();
        for (Iterator i = input.iterator(); i.hasNext(); ) {
            out.append(writeXMLWildcardOutput((Map) i.next(), ELEM_PARAMETER_ROW));
        }
        return XMLStringUtils.element("in", out.toString(), null, false);
    }
    
    public static String writeXMLWildcardOutput(Map input) {
        return writeXMLWildcardOutput(input, "in");
    }

    public static String writeXMLWildcardOutput(Map wildcards, String parentName) {
        StringBuffer out = new StringBuffer();

        // sort the keys
        Object keys[] = wildcards.keySet().toArray();
        Arrays.sort(keys);
        
        for (int n = 0; n < keys.length; n++) {
            String name = (String) keys[n];
            WildcardValue wc = (WildcardValue) wildcards.get(name);
            Map atts = new HashMap();
            atts.put("type", wc.getType());
            atts.put("name", wc.getName());
            out.append(XMLStringUtils.element("parameter", 
                    convertToStringForm(wc.getValue(), wc.getType()), atts, true));
        }

        return XMLStringUtils.element(parentName, out.toString(), null, false);
    }
    
    public static Object convertToJavaType(String input, String type) {
        if (input == null) {
            return null;
        } else if (type == null) {
            return input;
        } else if (type.equalsIgnoreCase(QueryFunctions.STRING)) {
            return input;
        } else if (type.equalsIgnoreCase(QueryFunctions.LONGSTRING)) {
            return input;
        } else if (type.equalsIgnoreCase(QueryFunctions.NUMBER)) {
            return new Long(input);
        } else if (type.equalsIgnoreCase(QueryFunctions.FLOAT)) {
            return new Double(input);
        } else if (type.equalsIgnoreCase(QueryFunctions.BLOB)) {
            return Base64.decodeBase64(input);
        } else if (type.toUpperCase().startsWith(QueryFunctions.DATE.toUpperCase())) {
            try {
                DateFormat df = new SimpleDateFormat(type.substring(5));
                return df.parse(input);
            } catch (ParseException err) {
                err.printStackTrace();
                throw new RuntimeException("Bad date format: " + 
                        type.substring(5) + " value=" + input);
            }
        } else {
            throw new RuntimeException("Unknown wildcard type: " + 
                    type + " value=" + input);
        }
    }
    
    public static String convertToStringForm(Object input, String type) {
        if (input == null) {
            return null;
        } else if (type == null) {
            return input + "";
        } else if (type.equalsIgnoreCase(QueryFunctions.STRING)) {
            return input + "";
        } else if (type.equalsIgnoreCase(QueryFunctions.LONGSTRING)) {
            return input + "";
        } else if (type.equalsIgnoreCase(QueryFunctions.NUMBER)) {
            return input + "";
        } else if (type.equalsIgnoreCase(QueryFunctions.FLOAT)) {
            return input + "";
        } else if (type.equalsIgnoreCase(QueryFunctions.BLOB)) {
            return Base64.encodeBase64((byte []) input);
        } else if (type.toUpperCase().startsWith(QueryFunctions.DATE.toUpperCase())) {
            DateFormat df = new SimpleDateFormat(type.substring(5));
            return df.format((Date) input);
        } else {
            throw new RuntimeException("Unknown wildcard type: " + 
                    type + " value=" + input);
        }
    }
    
    public static List parseWildcardXML(String inWildcardsXML) {
        
        // Build wildcards set
        Document docWildcards = XMLStringUtils.parseXML(inWildcardsXML);
        Node parentNode = docWildcards.getDocumentElement();
        NodeList childNodes = parentNode.getChildNodes();
        List wildcardRows = new ArrayList();
        Map oneRowWildcards = new HashMap();

        for (int n = 0; n < childNodes.getLength(); n++) {
            Node child = childNodes.item(n);

            if (child.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            } else if (child.getNodeName().equals(ELEM_PARAMETER_ROW)){
                Map rowWildcards = new HashMap();
                NodeList grandchildNodes = child.getChildNodes();
                for (int m = 0; m < grandchildNodes.getLength(); m++) {
                    Node grandchild = grandchildNodes.item(m);
                    if (grandchild.getNodeType() != Node.ELEMENT_NODE) {
                        continue;
                    } else if (grandchild.getNodeName().equals(ELEM_PARAMETER)){
                        processParameterNode(grandchild, rowWildcards);
                    }
                }
                wildcardRows.add(rowWildcards);
            } else if (child.getNodeName().equals(ELEM_PARAMETER)){
                processParameterNode(child, oneRowWildcards);
            }
            
        }
        if (wildcardRows.isEmpty() && !oneRowWildcards.isEmpty()) {
            wildcardRows.add(oneRowWildcards);
        }
        return wildcardRows;
    }

    public static void processParameterNode(Node child, Map wildcards) {
        String nodeValue = null;
        if (child.getFirstChild() != null) {
            nodeValue = child.getFirstChild().getNodeValue();
        }
        if ((nodeValue != null) && nodeValue.equals("")) {
            nodeValue = null;
        }

        NamedNodeMap atts = child.getAttributes();
        Node nameAtt = atts.getNamedItem(ATTR_NAME);
        if (nameAtt == null) {
            throw new RuntimeException("No name attribute supplied " +
                    "in calculation set input xml");
        }
        String name = nameAtt.getNodeValue();
        
        Node typeAtt = atts.getNamedItem(ATTR_TYPE);
        String type = null;
        if (typeAtt != null) {
            type = typeAtt.getNodeValue();
        } else {
            type = "String";
        }

        WildcardValue wc = makeWildcardValue(name,
                convertToJavaType(nodeValue, "" + type), type);
        wildcards.put(wc.getName(), wc);
    }
}
