package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.loader.util.LoadUtil;
import jp.co.webcrew.phoenix.logic.BindLogicStdStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.logic.db.FormDb;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * 汎用のロジックに対応するsstagクラス。
 * 
 * @author kurinami
 */
public class LogicExecuter extends SSTagExecuter {

    /** パラメータ名：任意処理用のロジック */
    private static final String LOGIC_PARAM_KEY = "logic";

    /** パラメータ名：対象とするform_id(任意） */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：対象とする group_id(任意） */
    private static final String GROUP_ID_PARAM_KEY = "group_id";

    /** パラメータ名：group_id外であっても対象とする項目(カラム)を指定 */
    private static final String INCLUDE_PARAM_KEY = "include";

    /** パラメータ名：group_id内であっても対象としない項目名を指定 */
    private static final String EXCLUDE_PARAM_KEY = "exclude";

    /** パラメータ名：form定義カラムの中で対象とする項目IDを指定 */
    private static final String ITEM_ID_PARAM_KEY = "item_id";

    /** パラメータ名：ロジックに渡すショートセッションID */
    private static final String SHORT_ID_PARAM_KEY = "short_id";

    /** パラメータ名：ロジックに渡すショートセッションID */
    private static final String BUILD_PARAM_PARAM_KEY = "build_param";

    
    /** ロガー */
    private static final Logger log = Logger.getLogger(LogicExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            String[] logic = PhoenixUtil.split((String) parameters.get(LOGIC_PARAM_KEY), " ");
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String[] groupId = PhoenixUtil.split((String) parameters.get(GROUP_ID_PARAM_KEY), ",");
            String[] include = PhoenixUtil.split((String) parameters.get(INCLUDE_PARAM_KEY), ",");
            String[] exclude = PhoenixUtil.split((String) parameters.get(EXCLUDE_PARAM_KEY), ",");
            String[] itemId = PhoenixUtil.split((String) parameters.get(ITEM_ID_PARAM_KEY), ",");
            // TODO kurinami 【確認】 ショートID渡せない？
            String shortId = ValueUtil.nullToStr(parameters.get(SHORT_ID_PARAM_KEY));

            /*
            // サイトIDを取得
            int siteId = SstagUtil.getSiteId(null, request);

            // フォーム項目一覧を取得する。
            FormInfo formInfo = FormDb.getFormInfo(siteId, formId);

            // セッションストアで保持しているフォームデータを取得する。
            PostInfo postInfo = StoreUtil.getPostInfo(request);

            // form内で使用するグループと項目
            FormUseInfo formUseInfo = new FormUseInfo(groupId, include, exclude, itemId);

            // 共通情報を取得する。
            SstagGlobalInfo sgInfo = SstagUtil.getSstagGlobalInfo(request);
		*/
            /***
             * セッションが無効の場合、エラーを発生させるか否か。
             */
            boolean buildParam=true;
            String strBuildParam = ValueUtil.nullToStr(parameters.get(BUILD_PARAM_PARAM_KEY));
            if(strBuildParam.equals("0") || strBuildParam.equals("no"))
            {
            	buildParam=false;
            }
            
            
            FormInfo formInfo=null;
            PostInfo postInfo=null;
            FormUseInfo formUseInfo=null;
            SstagGlobalInfo sgInfo=null;
            
            if(buildParam)
            {
	            // サイトIDを取得
	            int siteId = SstagUtil.getSiteId(null, request);
	            // フォーム項目一覧を取得する。
	            formInfo = FormDb.getFormInfo(siteId, formId);
	            // セッションストアで保持しているフォームデータを取得する。
	            postInfo = StoreUtil.getPostInfo(request);
	            // form内で使用するグループと項目
	            formUseInfo = new FormUseInfo(groupId, include, exclude, itemId);
	            // 共通情報を取得する。
	            sgInfo = SstagUtil.getSstagGlobalInfo(request);
            }

            
            // htmlを組み立てる。
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);

            // 汎用ロジックを実行する。
            BindLogicStdStatus status = logic(request, parameters, sgInfo, formInfo, postInfo, formUseInfo, logic);
            if (!status.result) {
                status.writeLog(log);
                return onerror(request, response, parameters, status.errStatus, status.errMsg);
            }

            // 結果htmlを出力する。
            pw.println(ValueUtil.nullToStr(status.html));

            pw.flush();
            return sw.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * 汎用のロジックを実行する。
     * 
     * @param request
     * @param sstagParam
     * @param sgInfo
     * @param formInfo
     * @param postInfo
     * @param formUseInfo
     * @param logic
     * @return
     * @throws Exception
     */
    private BindLogicStdStatus logic(HttpServletRequest request, Map<String, String> sstagParam,
            SstagGlobalInfo sgInfo, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String[] logic)
            throws Exception {

        SstagDynamicLogic logicClass = (SstagDynamicLogic) LoadUtil.newInstanceFromId(request, logic[0]);

        List<String> userParam = Arrays.asList(logic);
        return logicClass.stdLogic(sgInfo, sstagParam, userParam, formInfo, postInfo, formUseInfo);

    }

}
