package jp.co.webcrew.phoenix.sstag.impl;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * スクリーニング結果とformの関連づけを削除するためのsstagクラス。
 * 
 * @author kurinami
 */
public class ResetAssignExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：項目ID */
    private static final String ITEM_ID_PARAM_KEY = "item_id";

    /** ロガー */
    private static final Logger log = Logger.getLogger(ResetAssignExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { FORM_ID_PARAM_KEY, ITEM_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String itemId = ValueUtil.nullToStr(parameters.get(ITEM_ID_PARAM_KEY));

            // 関連付けを削除する。
            StoreUtil.removeAssign(request, siteId, formId, itemId);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

}
