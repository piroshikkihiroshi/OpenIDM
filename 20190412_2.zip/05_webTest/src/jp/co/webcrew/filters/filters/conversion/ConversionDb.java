package jp.co.webcrew.filters.filters.conversion;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.filters.db.ConversionMstDb;

/**
 * ポイント情報を管理するdbクラス。
 * 
 * @author kurinami
 */
public class ConversionDb {

	/** コンバージョン経過ワーク情報取得用SQL */
	private static final String CONV_PROCESS_SELECT = "select * from conv_process where ssid = ? and conv_id = ?";

	/** コンバージョン経過ワーク情報挿入用SQL */
	private static final String CONV_PROCESS_INSERT = "insert into conv_process(ssid, conv_id, url_type, mk_datetime, last_datetime) values(?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'), to_char(sysdate, 'YYYYMMDDHH24MISS'))";

	/** コンバージョン経過ワーク情報更新用SQL */
	private static final String CONV_PROCESS_UPDATE = "update conv_process set url_type = ?, last_datetime = to_char(sysdate, 'YYYYMMDDHH24MISS') where ssid = ? and conv_id = ?";

	/** コンバージョン経過ワーク情報更新用SQL */
	private static final String CONV_PROCESS_DELETE = "delete from conv_process where ssid = ? and conv_id = ?";

	/** コンバージョン記録取得用SQL */
	private static final String CONVERSION_LOG_SELECT = "select * from conversion_log where guid = ? and conv_id = ?";

	/** コンバージョン記録挿入用SQL */
	private static final String CONVERSION_LOG_INSERT = ""
			+ "insert into conversion_log(guid, ssid, conv_id, turn, mk_datetime, last_datetime) "
			+ "values(?, "
			+ "       ?, "
			+ "       ?, "
			+ "       (select coalesce(max(turn), 0) + 1 from conversion_log sub where sub.ssid = conversion_log.ssid and sub.conv_id = conversion_log.conv_id), "
			+ "       (select coalesce(max(mk_datetime), to_char(sysdate, 'YYYYMMDDHH24MISS')) from conv_process sub where sub.ssid = conversion_log.ssid and sub.conv_id = conversion_log.conv_id), "
			+ "       to_char(sysdate, 'YYYYMMDDHH24MISS'))";

	/**
	 * 経過ワークから現在の通過URLタイプを返す。
	 * 
	 * @param ssid
	 * @param convId
	 * @return
	 * @throws SQLException
	 */
	public static String getCurrentUrlType(int ssid, int convId)
			throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// ポイント発生ワーク情報を検索する。
			dbAccess.prepareStatement(CONV_PROCESS_SELECT);
			dbAccess.setInt(1, ssid);
			dbAccess.setInt(2, convId);
			rs = dbAccess.executeQuery();

			String currentUrlType = ConversionMstDb.URL_TYPE_NONE;
			if (dbAccess.next(rs)) {
				currentUrlType = rs.getString("url_type");
			}
			return currentUrlType;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * コンバージョン経過ワーク情報をDBに挿入する。
	 * 
	 * @param ssid
	 * @param convId
	 * @param urlType
	 * @throws SQLException
	 */
	public static void insertConvProcess(int ssid, int convId, String urlType)
			throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// コンバージョン経過ワーク情報をDBに挿入する。
			dbAccess.prepareStatement(CONV_PROCESS_INSERT);
			dbAccess.setInt(1, ssid);
			dbAccess.setInt(2, convId);
			dbAccess.setString(3, urlType);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * コンバージョン経過ワーク情報を更新する。
	 * 
	 * @param ssid
	 * @param convId
	 * @param urlType
	 * @throws SQLException
	 */
	public static void updateConvProcess(int ssid, int convId, String urlType)
			throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// コンバージョン経過ワーク情報を更新する。
			dbAccess.prepareStatement(CONV_PROCESS_UPDATE);
			dbAccess.setString(1, urlType);
			dbAccess.setInt(2, ssid);
			dbAccess.setInt(3, convId);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * このユーザがこのコンバージョン条件にコンバージョンしたssidの一覧を返す。
	 * 
	 * @param guid
	 * @param convId
	 * @return
	 * @throws SQLException
	 */
	public static Set getSsidSetOnConversionLog(int guid, int convId)
			throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			Set ssidSet = new HashSet();

			// コンバージョン記録を検索する。
			dbAccess.prepareStatement(CONVERSION_LOG_SELECT);
			dbAccess.setInt(1, guid);
			dbAccess.setInt(2, convId);
			rs = dbAccess.executeQuery();

			while (dbAccess.next(rs)) {
				ssidSet.add(new Integer(rs.getInt("ssid")));
			}

			return ssidSet;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * コンバージョン記録に挿入する。
	 * 
	 * @param guid
	 * @param ssid
	 * @param convId
	 * @throws SQLException
	 */
	public static void insertConversionLog(int guid, int ssid, int convId)
			throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// コンバージョン記録に挿入する。
			dbAccess.prepareStatement(CONVERSION_LOG_INSERT);
			dbAccess.setInt(1, guid);
			dbAccess.setInt(2, ssid);
			dbAccess.setInt(3, convId);
			dbAccess.executeUpdate();

			// コンバージョン経過ワークを削除する。
			dbAccess.prepareStatement(CONV_PROCESS_DELETE);
			dbAccess.setInt(1, ssid);
			dbAccess.setInt(2, convId);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}
}
