/*
 * Generator Runtime Servlet Framework
 * Copyright (C) 2004 Rick Knowles
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package jp.co.webcrew.common.validation;

import generator.runtime.db.DBConnectionWrapper;

import java.util.Arrays;


/**
 * Implements a numeric only check - ensures the field is either null or 
 * a numeric value
 * 
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: NumericOnlyValidation.java,v 1.5 2005-06-15 06:12:41 rickk Exp $
 */
public class NumericOnlyValidation extends ValidationCheck {
	
    private static final char ALLOWED_DIGITS[] = new char[] {
        ',', '.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
    }; 
    
	public ValidationFailure validate(Object value, DBConnectionWrapper dbConnection) {
		if (value == null) {
			return null;
		}
        boolean foundNonNumeric = false;
        String strValue = value + "";

        for (int n = 0; (n < strValue.length()) && !foundNonNumeric; n++) {
            if (Arrays.binarySearch(ALLOWED_DIGITS, strValue.charAt(n)) == -1) {
                return new ValidationFailure(getFieldName(), getErrorType(), value);
            }
        }
        try {
            Double.parseDouble(strValue);
            return null;
        } catch (Throwable err) {
            return new ValidationFailure(getFieldName(), getErrorType(), value);
        }
	}
}
