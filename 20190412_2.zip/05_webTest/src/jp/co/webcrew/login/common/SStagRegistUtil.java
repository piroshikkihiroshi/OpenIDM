package jp.co.webcrew.login.common;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MailTemplateUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OnetimeMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.db.step.StepUserInfo;
import jp.co.webcrew.login.common.db.step.StepUserInfoFactory;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;
import jp.co.webcrew.login.common.util.StringUtil;


/**
 * SStag本登録用のユーティリティ
 * 
 * @author Takahashi
 *
 */
public class SStagRegistUtil {

    /** ロガー */
    private static final Logger log = Logger.getLogger(SStagRegistUtil.class);
    
    /**
     * <pre>
     * 本登録処理を行い、本登録通知メールを送付する。
     * 
     *                                                                内部コード 戻り値
     * 1) 本登録のデータベース処理とメール送信の双方が成功した場合      0        TRUE
     * 2) 本登録のデータベース処理が成功し、メール送信が失敗した場合    1        TRUE
     * 3) ロジカルエラーによって登録処理ができなかった場合             -1        FALSE
     * 4) ユーザが既に本登録済みである場合                             -2        FALSE
     * 5) システム系のエラーによって登録処理ができなかった場合         -3        FALSE
     *
     * </pre>
     *
     * @param guid         必須 仮登録で生成されたguid
     * @param email        必須 仮登録したメールアドレス
     * @param password     必須 仮登録で生成したパスワード 
     * @param site_id      必須 仮登録で使用したサイトID
     * @param order_id          sstag.order_id
     * @param user_id           sstag.user_id
     * @param nickname          sstag.nickname      指定されない場合はemailの@より前を使う
     * @param gender            sstag.gender        1=男性 2=女性
     * @param birthday          sstag.birthday      生年月日 yyyymmddもしくはyyyy-mm-dd
     * @param mobile_flag  必須 true=携帯端末 false=携帯以外
     * @return
     */
      public static boolean registUser ( 
            String guid,
            String email,
            String password,
            String site_id,
            String order_id,
            String user_id,
            String nickname,
            String gender,
            String birthday,
            boolean mobile_flag
      ) {
          int status = registUserReturnedInt( guid,
                                              email,
                                              password,
                                              site_id,
                                              order_id,
                                              user_id,
                                              nickname,
                                              gender,
                                              birthday,
                                              mobile_flag
                                           );
          if( status >= 0 ) { 
             return true;
          } else { 
             return false;
          }
          
      }
      
     // ----- 実処理
      public static int registUserReturnedInt (
            String guid,
            String email,
            String password,
            String site_id,
            String order_id,
            String user_id,
            String nickname,
            String gender,
            String birthday,
            boolean mobile_flag
        )   {
        log.info("ユーザ情報をDB登録");
        
        /*
          1) 指定された guid で member_mst を検索し情報を取得
             レコードが見つからない場合には異常終了 
          
          2) 本登録状態の場合には処理を正常終了
          
          3) member_mst.nickname が NULL の場合、渡された引数 nickname をセットする。
             引数 nickname が NULL の場合、email の @ より前側を取り出し
             nickname カラムへ入れる。
             
          4) 性別、生年月日の登録を行う
          
          5) 更新日時を設定
          
          6) formal_flag = ON として本登録完了とする
          
          7) site_id/order_id/user_id からデータを取得して order_hist を作成
          
          8) 指定された email アドレスへ登録済みメールを送信
               ログインURL (URL + email + password )
               リマインダURL
               一発削除用URL（迷惑防止）
        */
        

        // 引数チェック
        
        if (! SessionFilterAlterUtil.isValidGuid(guid) ) {
            log.error("guidが不正です。本登録処理を中止します。guid=" + guid);
            return -1;
        }

        if (email == null || email.equals("")) {
            log.error("emailが指定されていません。本登録処理を中止します。guid=" + guid);
            return -1;
        }

        if (password == null || password.equals("")) {
            log.error("パスワードが指定されていません。本登録処理を中止します。guid=" + guid);
            return -1;
        }

        if (site_id == null || site_id.equals("")) {
            log.error("site_idが指定されていません。本登録処理を中止します。guid=" + guid);
            return -1;
        }

        DBAccess db = null;
        MemberMst real_member = null;
        
        try {
            db = new DBAccess();
            db.setAutoCommit(false);

        // ---- 二重登録チェック
            if (MemberMst.isRegisterdUser(db, email)){
                log.info("既に登録済みです");
                return -2;
            }

        // ---- 仮登録情報を取得する
            MemberMst kari_member = new MemberMst(guid);
            if (! kari_member.load(db)) {
                log.info("仮登録情報を取得できませんでした。guid=" + guid);
                return -1;
            }
            
            if (! kari_member.isHavingEmail()) {
                // e-mailが無ければ仮登録情報を取得できたとは言えない
                log.info("仮登録情報を取得できませんでした。guid=" + guid);
                return -1;
            }
            
        // ---- stepの登録情報(USER_INFO,ORDER_INFO)をコピー
            
            // stepの登録情報を取得する
            StepUserInfo userinfo = getStepUserInfo(db, site_id, order_id, user_id);
            
            if (userinfo == null) {
                log.info("stepの登録情報を取得できませんでした。site_id=" + site_id + ", order_id=" + order_id + ", user_id=" + user_id);
                return -1;
            }
            
            // stepの情報で上書き
            userinfo.doPopulateToMemberMst(kari_member); // stepの情報をコピー

        // ---- 本登録用に会員情報を上書きする
            
            // 念のためにパスワードは上書き
            kari_member.set(MemberMst.PASSWD , password);
             
           // ニックネームを上書き
           // member_mst.nickname が NULL の場合、渡された引数 nickname をセットする。
           // 引数 nickname が NULL の場合、email の @ より前側を取り出しnickname カラムへ入れる。
            
            String registNickName = ValueUtil.nullToStr(kari_member.get(MemberMst.NICKNAME)).trim();

            // Issue0028296: （PC）必須項目入力画面：ニックネーム設定変更依頼 対応
            // エラー対策として会員登録処理時に、メールアドレスからのニックネームを自動登録しない
            // Issue0029197: (PC)必須項目入力画面：ニックネーム設定変更戻し依頼 対応
            // 完了率が伸びなかったため、当初の設定に戻し
            if (registNickName.equals("")) {
                registNickName = ValueUtil.nullToStr(nickname).trim();
                if (registNickName.equals("")) {
                    registNickName = email.replaceFirst("@.*$" , "");
                }
            }

            kari_member.set(MemberMst.NICKNAME , registNickName);
            kari_member.set(MemberMst.SITE_ID  , site_id);
            
//            4) 性別、生年月日の登録を行う

            // 性別・生年月日は、値がnullもしくは空値で無い場合のみ、更新を行う。
            updateIfNotEmpty(kari_member , MemberMst.SEX_ID    , gender);
            updateIfNotEmpty(kari_member , MemberMst.BIRTHDAY  , formatBirthDay(birthday));

//            5) 更新日時その他を設定
            
            kari_member.set(MemberMst.UP_DATETIME, DateUtil.currentDateTime());
            kari_member.unLimitDateTime(); // 有効期限を無期限にする。

//            6) formal_flag = ON として本登録完了とする
            
            kari_member.setFormalFlag(MemberMst.FLG_FORMAL_ON);

             // MEMBER_MSTを更新
            RegistUtil.updateMemberMst(db , kari_member);
            
//          7) site_id/order_id/user_id からデータを取得して order_hist を作成
            
            // オーダー情報をstepからコピーする
            OrderHist order  = createOrderHistFrom(userinfo);
            
//            writeOrderHistoryToDB (order);
            // オーダー情報を書き込み
            OrderHist.insertToDB(db , order);

            db.commit();
            
//          8) 指定された email アドレスへ登録済みメールを送信
//          ログインURL (URL + email + password )
//          リマインダURL
//          一発削除用URL（迷惑防止） 
            
            real_member = kari_member; // 本登録済み
            
           // ----- メール送信
            boolean sent = sendMail(db, email, real_member) ;
            if ( sent == true ) {
            
                return 0;   // メール送信OK
            
            } else {
                log.error("本登録通知メールの送信に失敗しました。guid=" + guid + ", email=" + email);
                return 1;
            }

        } catch (SQLException e) {
            log.error("ユーザ登録中にデータベースエラーが発生しました。" , e);
            return -3;
            
        } catch (Exception e) {
            log.error("ユーザ登録中に想定外のエラーが発生しました。" , e);
            return -3;
            
        } finally {
            DBAccess.close(db);
        }

    }
    
    /**
     * <pre>
     * 【メール送信処理共通化用】
     * 本登録完了メールを送信する
     * 
     * 引数のうち、from はシステムプロパティの指定が可能($$で囲む)
     * 
     * 送信処理に成功したらtrue、失敗したらfalseを返す。
     * 
     * （falseなら確実に失敗していると思われるが、trueであっても、
     * 本当にメールが送信できたかどうかは分からない）
     * 
     * </pre>
     * 
     * @param objDbAccess
     * @param mailto       本登録ユーザのメールアドレス(=本登録通知メールの宛先)。必須。SSTAGのパラメータから取得したEMAIL
     * @param objMemberMst 本登録通知メールの送信者情報。null不可。
     * 
     */
	public static boolean sendMail(
			DBAccess objDbAccess,
			String strMailTo,
			MemberMst objMemberMst)
	{
		log.info ("本登録完了通知メールを送信します。");
		
		/*
		 * 送信処理開始
		 */
		try
		{
			// システムプロパティを取得
			SystemProperties props = new SystemProperties(objDbAccess);
			
			// メールテンプレートを準備する
			MailTemplateUtil objMailTemplate = new MailTemplateUtil(MailTemplateUtil.SSTAG_REGIST_MAIL_TEMPLATE_ID);
			if (! objMailTemplate.load(objDbAccess))
			{
				log.error("メールテンプレート" + MailTemplateUtil.SSTAG_REGIST_MAIL_TEMPLATE_ID + " の読み込みに失敗しました。");
				return false;
			}
			
			//送信者のメールアドレスを取得
			String strMailFrom = getMailSender (objMailTemplate, props, null);
			if (strMailFrom == null)
			{
				log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
				return false;
			}
			
			//パスワードを取得
			String passwd = objMemberMst.get(MemberMst.PASSWD);
			
			// なりすまし防止urlを取得する
			String oneTimeId = getOnetimeId(objDbAccess, objMemberMst, strMailTo); // ワンタイムIDを取得
			if (oneTimeId == null)
			{
				log.error("ワンタイムIDの取得に失敗しました。メール送信を中断します。");
				return false;
			}
			
			// メール送信情報を設定する
			MailInfo objMailInfo = new MailInfo();
			objMailInfo.setMailTo(strMailTo);
			objMailInfo.setMailFrom(strMailFrom);
			objMailInfo.setMobileFlag(MailTemplateUtil.isMobileEmail(objDbAccess, strMailTo));
			objMailInfo.setSiteId(objMemberMst.get(MemberMst.SITE_ID));
			
			// 件名情報を生成(件名の変数を置き換えるための変数を設定する)
			MailSubject objMailSubject = new MailSubject(objMemberMst);
			
			// 本文情報を生成(本文の変数を置き換えるための変数を設定する)
			MailBody objMailBody = new MailBody(objMemberMst);
			objMailBody.setEmail(strMailTo);
			objMailBody.setAuthPass(passwd);
			objMailBody.setLoginPass(passwd);
			objMailBody.setPassword(passwd);
			objMailBody.setPass(passwd);
			objMailBody.setEncodeEmail(strMailTo);
			objMailBody.setOneTimeId(oneTimeId);
			objMailBody.setMypageReminderUrl(props, SystemProperties.MYPAGE_REMINDER_TOP);
			objMailBody.setMypageDeleteMemberUrl(props, SystemProperties.MYPAGE_DEL_MEMBER_TOP, strMailTo, oneTimeId);
			objMailBody.setMypageAuthUrl(props, SystemProperties.MYPAGE_LOGIN_TOP, strMailTo, passwd);
			objMailBody.setMypageLoginUrl(props, SystemProperties.MYPAGE_LOGIN_TOP, strMailTo, passwd);
			
			//変数の置き換えと、メール送信を行う
			return objMailTemplate.doReplaceAndMail(objMailSubject, objMailBody, objMailInfo);
		}
		catch (Exception e)
		{
			log.error("メール送信中に例外エラーが発生しました。" , e);
			return false;
		}
	}
	
	/**
	 * ワンタイムIDを取得する
	 * 
	 * @param db
	 * @param member
	 * @param email
	 * @return
	 */
    private static String getOnetimeId(DBAccess db , MemberMst member , String email) {
        try {
            // ワンタイムIDを取得
            String member_guid = member.getGuid();
            OnetimeMst onetime = new OnetimeMst(member_guid);
            onetime.load(db);
            
            if (! member_guid.equals(onetime.get(OnetimeMst.GUID))) {
                log.error("会員情報とワンタイムIDが一致しませんでした。"
                        +  "member_guid=" + member_guid 
                        +  ", onetime_guid=" + onetime.get(OnetimeMst.GUID));
                return null;
            }
            
            if (! email.equals(onetime.get(OnetimeMst.EMAIL)) ) {
                updateOnetimeMstEmail(db , member_guid , email);
            }
            
            return onetime.get(OnetimeMst.ONETIME_ID);

        } catch (Exception e) {
            log.error("ワンタイムIDを取得中に例外エラーが発生しました。" , e);
            return null;
        }
        
    }
    
    /**
     * <pre>
     * </pre>
     * @param db
     * @param guid
     * @param email
     * @throws SQLException
     */
    private static void updateOnetimeMstEmail(DBAccess db , String guid , String email) throws SQLException{
        String sql = "UPDATE ONETIME_MST SET EMAIL=? WHERE GUID=?";
        db.prepareStatement(sql);
        db.setString(1, email);
        db.setString(2, guid);
        db.executeUpdate();
    }

    /**
     * <pre>
     * 【メール送信処理共通化用】
     * メール送信者を取得する
     * </pre>
     * @param template
     * @param props
     * @param from
     * @return
     */
    private static String getMailSender(MailTemplateUtil template , SystemProperties props , String from) {

      if (props == null) {
          log.error("システムプロパティオブジェクトがnullです。呼び出しが不正です。");
          return null;
      }

      String sender = "";

      if (template != null) {
          sender  = ValueUtil.nullToStr(template.getFrom());  // メールテンプレートのfromを最優先とする
      }

      if (sender.equals("")) {
          // メールテンプレートから送信者を取得できなかった場合、指定されたfromを使用する
          sender = ValueUtil.nullToStr (from);
      }
      
      if (sender.equals("")) {
          log.warn("MAIL_TEMPLテーブルにfromが指定されていないため、システムプロパティからデフォルト値を取得します。");
          sender = "$$MAIL_SENDER_OF_REGIST$$"; // メールテンプレートにも指定が無い場合、デフォルト値を使う
      }
      
      return  props.replaceStr(sender); // システムプロパティ変数を置換       
  }

    
//    /**
//     * <pre>
//     * 
//     * 会員情報の値を、既存の値をなるべく生かすかたちで上書きする。
//     * 
//     * １）引数 value がnullもしくは空値であれば何もしない。
//     * 
//     * ２）valueが空で無い場合、会員情報の値を更新する。ただし、該当するcolumnNameの
//     * 値が既に存在している（nullでも空でもない値が入っている）場合は、何もしない。
//     * 
//     * </pre>
//     * @param member
//     * @param columnName
//     * @param value
//     */
//    private  static void updateIfNotExists (MemberMst member , String columnName , String value) {
//        
//        value = ValueUtil.nullToStr(value);
// 
//        if (value.equals("")) {
//            return;
//        }
//        
//        String currentVal = ValueUtil.nullToStr(member.get(columnName));
//        
//        if (currentVal.equals("")) {
//            member.set(columnName, value);
//        }
//        
//    }

    /**
     * <pre>
     * 
     * 引数 value がnullや空値でなければ、会員情報の値をvalueで更新する。
     * 
     * value が null もしくは空値であれば、何もしない。
     * 
     * </pre>
     * @param member
     * @param columnName
     * @param value
     */
    private  static void updateIfNotEmpty (MemberMst member , String columnName , String value) {
        
        value = ValueUtil.nullToStr(value);
 
        if (value.equals("")) {
            return;
        }
        
        member.set(columnName, value);
        
    }
    
    /**
     * <pre>
     * 誕生日を YYYYMMDD の8文字の形式に変換して返す。
     * 
     * YYYYMMDD もしくは YYYY{separator}MM{separator}DD の形式で渡される
     * 誕生日を、一律でYYYYMMDDの形式に修正する。
     * 
     * nullが渡された場合は null を返す。
     * 
     * 引数のフォーマットエラーなど、処理に失敗した場合も null を返す。
     * 
     * </pre>
     * @param birthday 半角英数 YYYYMMDD もしくは YYYY-MM-DD,YYYY/MM/DD
     * @return
     */
    private static String formatBirthDay(String birthday) {
        
        if (birthday == null) {
            return null;
        }
        
        int strLength = birthday.trim().length();
        
        if (strLength != 8 && strLength != 10) {
            log.info("引数が不正です。birthday=" + birthday);
            return null;
        }
        
        if (! StringUtil.checkHankaku(birthday)) {
            log.info("引数が不正です。全角文字が渡されました。birthday=" + birthday);
            return null;
        }
        
        if (strLength == 8) {
            return birthday;
        }
        
        if (strLength == 10) {
            return birthday.substring(0,4) + birthday.substring(5,7) + birthday.substring(8 , 10); 
        }
        
        return null;
    }

    /**
     * <pre>
     * ステップサイトで登録したユーザ情報などをデータベース
     * （STEP.USER_INFO,ORDER_INFO）から取得する。
     * 
     * </pre>
     * @param db
     * @param site_id
     * @param order_id
     * @param user_id
     * @return
     */
    private static StepUserInfo getStepUserInfo(DBAccess db , String site_id , String order_id , String user_id){ 

        StepUserInfo userinfo = StepUserInfoFactory.createStepUserInfo(null , site_id);
        
        if (userinfo == null) {
            log.error("ステップ側のクラス生成に失敗しました。siteId=" + site_id);
            return null;
        }
        
        try {
            if (! userinfo.doLoad(db , order_id , user_id) ) {
                
                // ユーザ情報が取得できない場合、エラーとする
                log.error("ステップ側のユーザ情報読み込みに失敗したか、情報が見つかりませんでした。");
                return null;

            }
            
            return userinfo;
            
        } catch (SQLException e) {
            log.error("ステップ側のユーザ情報読み込み時に、データベースエラーが発生しました。" , e);
            e.printStackTrace();
            return null;
        }        
    }
    
    /**
     * Stepの入力情報を元に、履歴オブジェクト(OrderHist)を生成する
     * @param form
     * @return OrderHist
     */
    private static OrderHist createOrderHistFrom( StepUserInfo stepUserInfo ){
        
        String step_guid = stepUserInfo.getGuid();
        
        if (! SessionFilterAlterUtil.isValidGuid(step_guid)) {
            log.info("guidが不正です。step履歴の取得を中止します。guid=" + step_guid);
            return null;
        }
        
        OrderHist order = new OrderHist(step_guid);
        stepUserInfo.doPopulateToOrderHist(order);
        return order;
    }

}
