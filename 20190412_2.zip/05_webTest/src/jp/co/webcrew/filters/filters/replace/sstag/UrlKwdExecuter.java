package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.UrlKwdMstDb;

/**
 * URLキーワードを置き換えるExecuterクラス。
 * 
 * @author kurinami
 */
public class UrlKwdExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(UrlKwdExecuter.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {

		try {

			String kwd = ValueUtil.nullToStr(parameterMap.get("kwd"));
			if (kwd.length() == 0) {
				log.error("UrlKwd sstag に、パラメータ kwd が指定されていません。");
				return ValueUtil.nullToStr(parameterMap.get("default"));
			}

			String content = UrlKwdMstDb.getInstance().getContent(
					request.getRequestURI(), request.getServerName(), kwd);
			if (content == null) {
				log.info("RequestURL [" + request.getRequestURL().toString()
						+ "] には キーワード[" + kwd + "] が登録されていません。");
				return ValueUtil.nullToStr(parameterMap.get("default"));
			}

			return content;

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		return ValueUtil.nullToStr(parameterMap.get("default"));

	}

}
