package jp.co.webcrew.phoenix.sstag.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.sstag.bean.FormWriteMapBean;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.TblMetaMstBean;
import jp.co.webcrew.phoenix.vtable.db.MetaDb;

/**
 * フォーム登録先テーブルマップを管理するdbクラス。
 * 
 * @author kurinami
 */
public class FormWriteMapDb {

    /** フォーム登録先テーブルマップを取得するためのsql */
    private static final String SELECT_FORM_WRITE_MAP = ""
            + "select * from (schema_name).form_write_map where site_id = ? and form_id = ? order by map_site_id, map_tbl_id";

    /** テーブルマップ用キー定義の一覧を取得するためのsql */
    private static final String SELECT_FORM_WRITE_MAP_KEY = ""
            + "select * from (schema_name).form_write_map_key where site_id = ? and form_id = ? and map_site_id = ? and map_tbl_id = ? ";

    /**
     * フォーム登録先テーブルマップを書き込み先テーブルごとにまとめて返す。
     * 
     * @param siteId
     * @param formId
     * @return
     * @throws SQLException
     */
    public static Map<TblMetaMstBean, List<FormWriteMapBean>> getFormWriteMapList(int siteId, String formId,
            String[] groupId) throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            Map<TblMetaMstBean, List<FormWriteMapBean>> formWriteMapList = new HashMap<TblMetaMstBean, List<FormWriteMapBean>>();

            TblMetaMstBean lastTblMetaMst = null;

            // フォーム登録先テーブルマップを取得する。
            dbAccess.prepareStatement(SELECT_FORM_WRITE_MAP);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, formId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                FormWriteMapBean formWriteMap = new FormWriteMapBean();
                formWriteMap.setSiteId(rs.getInt("site_id"));
                formWriteMap.setFormId(ValueUtil.nullToStr(rs.getString("form_id")));
                formWriteMap.setGroupId(ValueUtil.nullToStr(rs.getString("group_id")));
                formWriteMap.setMapSiteId(rs.getInt("map_site_id"));
                formWriteMap.setMapTblId(ValueUtil.nullToStr(rs.getString("map_tbl_id")));

                // グループIDが指定されている場合、指定されているものだけ対象とする。
                if (PhoenixUtil.isEmpty(groupId) || PhoenixUtil.contains(groupId, formWriteMap.getGroupId())) {
                    if (lastTblMetaMst == null || lastTblMetaMst.getSiteId() != formWriteMap.getMapSiteId()
                            || !lastTblMetaMst.getTblId().equals(formWriteMap.getMapTblId())) {
                        lastTblMetaMst = MetaDb.getTblMetaMst(formWriteMap.getMapSiteId(), formWriteMap.getMapTblId());
                        formWriteMapList.put(lastTblMetaMst, new ArrayList<FormWriteMapBean>());
                    }
                    formWriteMapList.get(lastTblMetaMst).add(formWriteMap);
                }
            }

            return formWriteMapList;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * テーブルマップ用キー定義の一覧を返す。
     * 
     * @param siteId
     * @param formId
     * @return
     * @throws SQLException
     */
    public static String[] getFormWriteMapKey(int siteId, String formId, int mapSiteId, String mapTblId)
            throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            List<String> list = new ArrayList<String>();

            // テーブルマップ用キー定義を取得する。
            dbAccess.prepareStatement(SELECT_FORM_WRITE_MAP_KEY);
            // TODO kurinami 【確認】 ★★ それでも、group_id, item_idはいらなくない？
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, formId);
            dbAccess.setInt(3, mapSiteId);
            dbAccess.setString(4, mapTblId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                list.add(ValueUtil.nullToStr(rs.getString("map_clm_id")));
            }

            return list.toArray(new String[0]);

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

}
