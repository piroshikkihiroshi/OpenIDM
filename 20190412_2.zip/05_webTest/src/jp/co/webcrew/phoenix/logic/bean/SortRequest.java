package jp.co.webcrew.phoenix.logic.bean;

/**
 * 結果の並べ替え指定(１項目）
 * 
 * @author kurinami
 */
public class SortRequest {
    public String itemName;
    public boolean direction; /* true=asc, false=desc */
}
