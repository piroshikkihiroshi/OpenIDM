package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.TermMstDb;

/**
 * 携帯UIDを取得するためのsstag
 *
 */
public class MobileUidExecuter extends SSTagExecuter
{
	/** ロガー */
	private static final Logger log = Logger.getLogger(MobileUidExecuter.class);

	private static final String PARAM_MOBILE_UID = "\\$\\$mu\\$\\$";

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map mapParameters, HttpServletRequest objRequest, HttpServletResponse objResponse)
	{
		
		//パラメータを取得
		String strHTML = (String)mapParameters.get("html");

		//　携帯uid
		String mUid = null;
		
		try
		{
		    // キャリア判断
			String ua = ValueUtil.nullToStr(objRequest.getHeader("User-Agent"));
			Map termInfo = TermMstDb.getInstance().getTermInfo(ua);
			String carrier = (String) termInfo.get("carrier");
			
			// DOCOMO
			if (carrier.equals(TermMstDb.TYPE_DOCOMO)) {
				log.info("case: docomo");
				String gwid = getDocomoGwid(objRequest);
				String guid = getDocomoGuid(objRequest);
				if(gwid != null || guid != null) {
					log.info("case: docomo  端末番号あり");
					if(gwid != null) mUid = gwid;
                    else mUid = guid;
				}
				else {
					log.info("case: docomo  端末番号なし");
				}
				
			}
			// AU
			else if(carrier.equals(TermMstDb.TYPE_AU)) {
				log.info("case: au");
				String id = getAuUid(objRequest);
				if(id != null)	{
					log.info("case: au  端末番号あり");
					mUid = id;
				}
				else {
					log.info("case: au  端末番号なし");
				}
				
			} 
			// SOFTBANK
			else if(carrier.equals(TermMstDb.TYPE_SOFTBANK)) {
				log.info("case: softbank");
				// 固体識別番号からグローバルセッションコードを生成する。
				String gsCode = getSoftbankUid(objRequest);

				if (gsCode != null) {
					// グローバルセッションコードが生成できた場合、
					log.info("case: softbank  端末番号あり");
					mUid = gsCode;
				} else {
					// グローバルセッションコードが生成できなかった場合、
					log.info("case: softbank  端末番号なし");
				}
				
			}
			if(mUid != null){
				//変数を置換する
				strHTML = strHTML.replaceAll(PARAM_MOBILE_UID, mUid);
			}
			return strHTML;
 		}
		catch (Exception e)
		{
			log.error("予期せぬエラー", e);
			return "";
		}
	}
	
	/**
	 * HTMLに変数が埋め込まれているか確認
	 *
	 * @param strHTML
	 * @param strParam
	 * @return
	 */
	private boolean isParameter(String strHTML, String strParam)
	{
		String strSearch = strParam.replaceAll("\\\\", "");

		if (strHTML.indexOf(strSearch) != -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * docomo端末の公式サイト用の端末IDを返す。
	 * 
	 * @param request
	 * @return
	 */
	private String getDocomoGwid(HttpServletRequest request) {
		String gwid = ValueUtil.nullToStr(request.getParameter("uid"));
		if(!gwid.equals("NULLGWDOCOMO") && gwid.length() == "NULLGWDOCOMO".length()) {
			return gwid;
		}
		return null;
	}
	
	/**
	 * docomo端末のiモードIDを返す。
	 * 
	 * @param request
	 * @return
	 */
	private String getDocomoGuid(HttpServletRequest request) {
		String guid =ValueUtil.nullToStr(request.getHeader("X-DCMGUID"));
		if(!guid.equals("") && guid.length() == "DCMGUID".length()) {
			return guid;
		}
		return null;
	}
	
	/**
	 * AU端末の固体識別番号を返す。
	 * 
	 * @param request
	 * @return
	 */
	private String getAuUid(HttpServletRequest request) {
		String id = ValueUtil.nullToStr(request.getHeader("X-Up-Subno"));
		if (id.length() > 0) {
			log.info("case: au  get [端末番号: " + id + "]");
			return id;
		} else {
			return null;
		}
	}	

	/**
	 * softbank端末の固体識別番号を返す。
	 * 
	 * @param request
	 * @return
	 */
	private String getSoftbankUid(HttpServletRequest request) {

		String id = ValueUtil.nullToStr(request.getHeader("x-jphone-uid"));
		if (id.length() > 0) {
			log.info("case: softbank  get [端末番号: " + id + "]");
			return id;
		} else {
			return null;
		}		
	}
}
