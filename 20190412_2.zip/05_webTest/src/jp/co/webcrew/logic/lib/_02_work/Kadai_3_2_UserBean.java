package jp.co.webcrew.logic.lib._02_work;

public class Kadai_3_2_UserBean {

	public int getORDER_ID() {
		return ORDER_ID;
	}

	public void setORDER_ID(int oRDER_ID) {
		ORDER_ID = oRDER_ID;
	}

	public String getNAME_KANJI_1() {
		return NAME_KANJI_1;
	}

	public void setNAME_KANJI_1(String nAME_KANJI_1) {
		NAME_KANJI_1 = nAME_KANJI_1;
	}

	public String getNAME_KANJI_2() {
		return NAME_KANJI_2;
	}

	public void setNAME_KANJI_2(String nAME_KANJI_2) {
		NAME_KANJI_2 = nAME_KANJI_2;
	}

	public String getNAME_KANA_1() {
		return NAME_KANA_1;
	}

	public void setNAME_KANA_1(String nAME_KANA_1) {
		NAME_KANA_1 = nAME_KANA_1;
	}

	public String getNAME_KANA_2() {
		return NAME_KANA_2;
	}

	public void setNAME_KANA_2(String nAME_KANA_2) {
		NAME_KANA_2 = nAME_KANA_2;
	}

	public String getEMAIL() {
		return EMAIL;
	}

	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}

	public String getTEL() {
		return TEL;
	}

	public void setTEL(String tEL) {
		TEL = tEL;
	}

	public int getCONTACT() {
		return CONTACT;
	}

	public void setCONTACT(int cONTACT) {
		CONTACT = cONTACT;
	}

	public int getDELETE_FLG() {
		return DELETE_FLG;
	}

	public void setDELETE_FLG(int dELETE_FLG) {
		DELETE_FLG = dELETE_FLG;
	}

	private int ORDER_ID = 0;
	private String NAME_KANJI_1 = "";
	private String NAME_KANJI_2 = "";
	private String NAME_KANA_1 = "";
	private String NAME_KANA_2 = "";
	private String EMAIL = "";
	private String TEL = "";
	private int CONTACT = 0;
	private int DELETE_FLG = 0;

	//デフォルトコンストラクタ
	Kadai_3_2_UserBean() {

	} //constructor

} //class
