package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.loader.util.LoadUtil;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.logic.db.FormDb;
import jp.co.webcrew.phoenix.sstag.bean.FormCssInfoBean;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.db.FormItemDb;
import jp.co.webcrew.phoenix.sstag.util.FormItemUtil;
import jp.co.webcrew.phoenix.sstag.util.LogicReplaceUtil;
import jp.co.webcrew.phoenix.sstag.util.ReplaceUtil;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * フォームを表示するためのsstagクラス。
 * 
 * @author kurinami
 */
public class FormDispExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：グループID */
    private static final String GROUP_ID_PARAM_KEY = "group_id";

    /** パラメータ名：含める項目 */
    private static final String INCLUDE_PARAM_KEY = "include";

    /** パラメータ名：含めない項目 */
    private static final String EXCLUDE_PARAM_KEY = "exclude";

    /** パラメータ名：group_id/include/exclude を使用せず直接項目IDを指定する際に使用 */
    private static final String ITEM_ID_PARAM_KEY = "item_id";

    /** パラメータ名：条件判断ロジック */
    private static final String LOGIC_PARAM_KEY = "logic";

    /** パラメータ名：HTMLテンプレート用変換MAPID */
    private static final String MAP_ID_PARAM_KEY = "map_id";

    /** パラメータ名：繰り返し出力用HTML */
    private static final String HTML_PARAM_KEY = "html";

    /** パラメータ名：項目が必須項目の時に出力するHTML */
    private static final String REQUIRED_PARAM_KEY = "required";

    /** パラメータ名：偶数時に出力するHTML */
    private static final String EVEN_PARAM_KEY = "even";

    /** パラメータ名：奇数時に出力するHTML */
    private static final String ODD_PARAM_KEY = "odd";

    /** パラメータ名：初回のみ出力するHTML */
    private static final String FIRST_PARAM_KEY = "first";

    /** パラメータ名：最終回のみ出力するHTML */
    private static final String LAST_PARAM_KEY = "last";

    /** パラメータ名：バリデーションエラーがある時に出力されるHTML(その1) */
    private static final String ERROR1_PARAM_KEY = "error1";

    /** パラメータ名：バリデーションエラーがある時に出力されるHTML(その2) */
    private static final String ERROR2_PARAM_KEY = "error2";

    /** パラメータ名：バリデーションエラーがある時に出力されるHTML(その3) */
    private static final String ERROR3_PARAM_KEY = "error3";

    /** パラメータ名：バリデーションエラーがある時に出力されるHTML(その4) */
    private static final String ERROR4_PARAM_KEY = "error4";

    /** パラメータ名：バリデーションエラーがない時に出力されるHTML(その1) */
    private static final String NOERROR1_PARAM_KEY = "noerror1";

    /** パラメータ名：バリデーションエラーがない時に出力されるHTML(その2) */
    private static final String NOERROR2_PARAM_KEY = "noerror2";

    /** パラメータ名：バリデーションエラーがない時に出力されるHTML(その3) */
    private static final String NOERROR3_PARAM_KEY = "noerror3";

    /** パラメータ名：バリデーションエラーがない時に出力されるHTML(その4) */
    private static final String NOERROR4_PARAM_KEY = "noerror4";

    /** 置換変数名：カレントセットの最大繰り返し数 */
    private static final String SIZE_VAL_KEY = "size";

    /** 置換変数名：カレントの繰り返し回数 (1～) */
    private static final String COUNT_VAL_KEY = "count";

    /** 置換変数名： 必須項目のHTML */
    private static final String REQUIRED_VAL_KEY = "required";

    /** 置換変数名：偶数・奇数の各回ごとのHTML */
    private static final String EVEN_ODD_VAL_KEY = "even_odd";

    /** 置換変数名：firstで指定されたHTML */
    private static final String FIRST_VAL_KEY = "first";

    /** 置換変数名：last で指定されたHTML */
    private static final String LAST_VAL_KEY = "last";

    /** 置換変数名：バリデーションエラーが在る時 error1 ない時 noerror1 */
    private static final String ERROR1_VAL_KEY = "error1";

    /** 置換変数名：バリデーションエラーが在る時 error2 ない時 noerror2 */
    private static final String ERROR2_VAL_KEY = "error2";

    /** 置換変数名：バリデーションエラーが在る時 error3 ない時 noerror3 */
    private static final String ERROR3_VAL_KEY = "error3";

    /** 置換変数名：バリデーションエラーが在る時 error4 ない時 noerror4 */
    private static final String ERROR4_VAL_KEY = "error4";

    /** 置換変数名：フォーム項目名称 */
    private static final String FORM_ITEM_NAME_VAL_KEY = "form.item.name";

    /** 置換変数名：フォーム項目CSS */
    private static final String FORM_ITEM_CSS_VAL_KEY = "form.item.css.{0}";

    /** 置換変数名：フォーム項目タイトル */
    private static final String FORM_ITEM_TITLE_VAL_KEY = "form.item.title";

    /** 置換変数名：フォーム項目に入力された生の値 */
    private static final String FORM_ITEM_RAW_VAL_KEY = "form.item.raw";

    /** 置換変数名：フォーム項目に入力された値 */
    private static final String FORM_ITEM_VALUE_VAL_KEY = "form.item.value";

    /** 置換変数名：フォーム項目に入力された値 */
    private static final String FORM_ITEM_VALUE_NOENC_VAL_KEY = "form.item.value_noenc";

    /** 置換変数名：選択肢の場合、選択されたvalue値に対する表示用の値 */
    private static final String FORM_ITEM_DISP_VAL_KEY = "form.item.disp";

    /** 置換変数名：選択肢の場合、選択されたvalue値に対する表示用の値 */
    private static final String FORM_ITEM_DISP_NOENC_VAL_KEY = "form.item.disp_noenc";

    /** 置換変数名：項目が選択項目の場合に値がチェックされているは "checked"という文字、チェックされていない場合には値なし */
    private static final String FORM_ITEM_CHECKED_VAL_KEY = "form.item.{0}.checked";

    /** 置換変数名：項目が選択項目の場合に値がチェックされているは "selected"という文字、チェックされていない場合には値なし */
    private static final String FORM_ITEM_SELECTED_VAL_KEY = "form.item.{0}.selected";

    /** 置換変数名：注意書き文言 */
    private static final String FORM_ITEM_CAUTION_VAL_KEY = "form.item.caution";

    /** 置換変数名：バリデーションエラーの文字列 */
    private static final String FORM_ITEM_ERROR_VAL_KEY = "form.item.error";

    /** 置換変数名：バリデーションエラーの番号 */
    private static final String FORM_ITEM_ERRNO_VAL_KEY = "form.item.errno";

    /** 置換変数名：項目のタイプ */
    private static final String FORM_ITEM_TYPE_VAL_KEY = "form.item.type";

    /** 置換変数名：フォーム項目を <input>タグなど HTMLに展開したもの */
    private static final String FORM_ITEM_HTML_VAL_KEY = "form.item.html";

    /** 置換変数名：入力画面での表示文字数 */
    private static final String FORM_ITEM_CLM_SIZE_VAL_KEY = "form.item.clm_size";

    /** 置換変数名：入力画面での表示行数 */
    private static final String FORM_ITEM_ROW_SIZE_VAL_KEY = "form.item.row_size";

    /** 置換変数名：最大文字数 */
    private static final String FORM_ITEM_LEAST_VAL_KEY = "form.item.least";

    /** 置換変数名：最大文字数 */
    private static final String FORM_ITEM_MOST_VAL_KEY = "form.item.most";

    /** 置換変数名：最大文字数 */
    private static final String FORM_ITEM_MIN_VAL_KEY = "form.item.min";

    /** 置換変数名：最大文字数 */
    private static final String FORM_ITEM_MAX_VAL_KEY = "form.item.max";

    /** 置換変数名：日付・時刻入力タイプ */
    private static final String FORM_ITEM_DATE_TIME_INPUT_VAL_KEY = "form.item.date_time_input";

    /** ロガー */
    private static final Logger log = Logger.getLogger(FormDispExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#getExcludeParamList
     * ()
     */
    @SuppressWarnings("unchecked")
    @Override
    protected List getExcludeParamList() {
        return Arrays.asList(HTML_PARAM_KEY);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    @SuppressWarnings("unchecked")
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { FORM_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String[] groupId = PhoenixUtil.split((String) parameters.get(GROUP_ID_PARAM_KEY), ",");
            String[] include = PhoenixUtil.split((String) parameters.get(INCLUDE_PARAM_KEY), ",");
            String[] exclude = PhoenixUtil.split((String) parameters.get(EXCLUDE_PARAM_KEY), ",");
            String[] itemId = PhoenixUtil.split((String) parameters.get(ITEM_ID_PARAM_KEY), ",");
            String[] logic = PhoenixUtil.split((String) parameters.get(LOGIC_PARAM_KEY), " ");
            String mapId = ValueUtil.nullToStr(parameters.get(MAP_ID_PARAM_KEY));
            String html = SstagUtil.getFileData(parameters.get(HTML_PARAM_KEY), request, response);
            String required = ValueUtil.nullToStr(parameters.get(REQUIRED_PARAM_KEY));
            String even = ValueUtil.nullToStr(parameters.get(EVEN_PARAM_KEY));
            String odd = ValueUtil.nullToStr(parameters.get(ODD_PARAM_KEY));
            String first = ValueUtil.nullToStr(parameters.get(FIRST_PARAM_KEY));
            String last = ValueUtil.nullToStr(parameters.get(LAST_PARAM_KEY));
            String error1 = ValueUtil.nullToStr(parameters.get(ERROR1_PARAM_KEY));
            String error2 = ValueUtil.nullToStr(parameters.get(ERROR2_PARAM_KEY));
            String error3 = ValueUtil.nullToStr(parameters.get(ERROR3_PARAM_KEY));
            String error4 = ValueUtil.nullToStr(parameters.get(ERROR4_PARAM_KEY));
            String noerror1 = ValueUtil.nullToStr(parameters.get(NOERROR1_PARAM_KEY));
            String noerror2 = ValueUtil.nullToStr(parameters.get(NOERROR2_PARAM_KEY));
            String noerror3 = ValueUtil.nullToStr(parameters.get(NOERROR3_PARAM_KEY));
            String noerror4 = ValueUtil.nullToStr(parameters.get(NOERROR4_PARAM_KEY));

            // フォーム項目一覧を取得する。
            List<FormItemBean> formItemList = FormItemDb.getList(siteId, formId, groupId, include, exclude, mapId);

            // セッションストアで保持している入力チェックの結果を取得する。
            Map<String, String[]> vResult = StoreUtil.getValidationResult(request, formId);
            if (vResult == null) {
                vResult = new HashMap<String, String[]>();
            }

            // htmlを組み立てる。
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);

            // 条件判断ロジックが指定されている場合、
            if (!PhoenixUtil.isEmpty(logic)) {

                // 共通情報を取得する。
                SstagGlobalInfo sgInfo = SstagUtil.getSstagGlobalInfo(request);

                // フォーム項目一覧を取得する。
                // TODO kurinami 【検討】 上のformItemListとの統合
                FormInfo formInfo = FormDb.getFormInfo(siteId, formId);

                // セッションストアで保持しているフォームデータを取得する。
                PostInfo postInfo = StoreUtil.getPostInfo(request);

                // form内で使用するグループと項目
                FormUseInfo formUseInfo = new FormUseInfo(groupId, include, exclude, itemId);

                JudgementLogicStatus status = logic(request, parameters, sgInfo, formInfo, postInfo, formUseInfo, logic);
                if (!status.result) {
                    status.writeLog(log);
                    return onerror(request, response, parameters, status.errStatus, status.errMsg);
                }

                // 結果htmlを出力する。
                pw.println(ValueUtil.nullToStr(status.html));

                // 条件判断が偽の場合、フォームを表示しない。
                if (!status.judge) {
                    pw.flush();
                    return sw.toString();
                }
            }

            int count = 1;
            for (FormItemBean formItem : formItemList) {

                // 通常表示の場合、
                if (formItem.getDispStat().equals("0")) {

                    // この項目に対する入力情報とエラー情報を取りだす。
                    String[] errors = vResult.get(formItem.getItemId());

                    // 入力項目自体には関係しない置換変数の設定。
                    // TODO kurinami 【確認】 required even_odd first last
                    // にもincludeある？置換変数入る？
                    Map<String, String> replaceMap = new HashMap<String, String>();
                    replaceMap.put(SIZE_VAL_KEY, Integer.toString(formItemList.size()));
                    replaceMap.put(COUNT_VAL_KEY, Integer.toString(count));
                    replaceMap.put(REQUIRED_VAL_KEY, (formItem.isRequire() ? required : ""));
                    replaceMap.put(EVEN_ODD_VAL_KEY, (count % 2 == 0 ? even : odd));
                    replaceMap.put(FIRST_VAL_KEY, (count == 1 ? first : ""));
                    replaceMap.put(LAST_VAL_KEY, (count >= formItemList.size() ? last : ""));
                    replaceMap.put(ERROR1_VAL_KEY, (PhoenixUtil.isEmpty(errors) ? noerror1 : error1));
                    replaceMap.put(ERROR2_VAL_KEY, (PhoenixUtil.isEmpty(errors) ? noerror2 : error2));
                    replaceMap.put(ERROR3_VAL_KEY, (PhoenixUtil.isEmpty(errors) ? noerror3 : error3));
                    replaceMap.put(ERROR4_VAL_KEY, (PhoenixUtil.isEmpty(errors) ? noerror4 : error4));

                    // 入力項目に関する置換変数の設定。
                    setItemReplaceVal(request, replaceMap, formItem, errors);

                    // htmlの出力。
                    pw.println(ReplaceUtil.getReplacedHtml(html, replaceMap));
                }
                // hidden表示の場合、
                else if (formItem.getDispStat().equals("1")) {
                    FormItemUtil formItemUtil = FormItemUtil.getInstance(formItem, request);
                    pw.println(MessageFormat.format("<input type=\"hidden\" name=\"{0}\" value=\"{1}\" />", formItem
                            .getItemId(), formItemUtil.getValue()));
                }
                // それ以外は表示しない。
                else {
                }

                count++;
            }

            pw.flush();
            return sw.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * 入力項目に関する置換変数を設定する。
     * 
     * @param request
     * @param replaceMap
     * @param formItem
     * @param errors
     * @throws Exception
     */
    public static void setItemReplaceVal(HttpServletRequest request, Map<String, String> replaceMap,
            FormItemBean formItem, String[] errors) throws Exception {

        // 入力項目に関する置換変数の一覧を登録する。
        replaceMap.putAll(getItemReplaceMap(request, formItem));

        // エラーが存在する場合、
        if (!PhoenixUtil.isEmpty(errors)) {
            // エラーメッセージ自体にも置換変数が含まれる。
            String error = (errors.length >= 2 && !PhoenixUtil.isEmpty(errors[1]) ? errors[1] : "Error");
            replaceMap.put(FORM_ITEM_ERROR_VAL_KEY, error);
            replaceMap.put(FORM_ITEM_ERROR_VAL_KEY + ".br", "<br />");
            String errno = (errors.length >= 1 && !PhoenixUtil.isEmpty(errors[0]) ? errors[0] : "");
            replaceMap.put(FORM_ITEM_ERRNO_VAL_KEY, errno);
        } else {
            replaceMap.put(FORM_ITEM_ERROR_VAL_KEY, "");
            replaceMap.put(FORM_ITEM_ERROR_VAL_KEY + ".br", "");
            replaceMap.put(FORM_ITEM_ERRNO_VAL_KEY, "");
        }

        String htmlTmpl = formItem.getHtmlTmpl();
        htmlTmpl = ReplaceUtil.getReplacedHtml(htmlTmpl, replaceMap, false);

        // 繰り返しと条件判断の置き換えを行う。
        FormItemUtil formItemUtil = FormItemUtil.getInstance(formItem, request);
        htmlTmpl = LogicReplaceUtil.replace(htmlTmpl, request, formItem, formItemUtil.getRaws());
        htmlTmpl = ReplaceUtil.clearReplaceParam(htmlTmpl);

        replaceMap.put(FORM_ITEM_HTML_VAL_KEY, htmlTmpl);

    }

    /**
     * 入力項目に関する置換変数のmapを返す。
     * 
     * @param request
     * @param formItem
     * @return
     * @throws InstantiationException
     * @throws SQLException
     */
    public static Map<String, String> getItemReplaceMap(HttpServletRequest request, FormItemBean formItem)
            throws InstantiationException, SQLException {

        Map<String, String> replaceMap = new HashMap<String, String>();

        replaceMap.put(FORM_ITEM_NAME_VAL_KEY, formItem.getItemId());
        replaceMap.put(FORM_ITEM_TITLE_VAL_KEY, formItem.getTitle());
        replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".1", formItem.getCaution1());
        replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".2", formItem.getCaution2());
        replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".3", formItem.getCaution3());
        replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".4", formItem.getCaution4());
        replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".5", formItem.getCaution5());
        replaceMap
                .put(FORM_ITEM_CAUTION_VAL_KEY + ".1.br", PhoenixUtil.isEmpty(formItem.getCaution1()) ? "" : "<br />");
        replaceMap
                .put(FORM_ITEM_CAUTION_VAL_KEY + ".2.br", PhoenixUtil.isEmpty(formItem.getCaution2()) ? "" : "<br />");
        replaceMap
                .put(FORM_ITEM_CAUTION_VAL_KEY + ".3.br", PhoenixUtil.isEmpty(formItem.getCaution3()) ? "" : "<br />");
        replaceMap
                .put(FORM_ITEM_CAUTION_VAL_KEY + ".4.br", PhoenixUtil.isEmpty(formItem.getCaution4()) ? "" : "<br />");
        replaceMap
                .put(FORM_ITEM_CAUTION_VAL_KEY + ".5.br", PhoenixUtil.isEmpty(formItem.getCaution5()) ? "" : "<br />");
        replaceMap.put(FORM_ITEM_TYPE_VAL_KEY, formItem.getType());
        replaceMap.put(FORM_ITEM_CLM_SIZE_VAL_KEY, ValueUtil.nullToStr(formItem.getClmSize()));
        replaceMap.put(FORM_ITEM_ROW_SIZE_VAL_KEY, ValueUtil.nullToStr(formItem.getRowSize()));
        replaceMap.put(FORM_ITEM_LEAST_VAL_KEY, ValueUtil.nullToStr(formItem.getLeast()));
        replaceMap.put(FORM_ITEM_MOST_VAL_KEY, ValueUtil.nullToStr(formItem.getMost()));
        replaceMap.put(FORM_ITEM_MIN_VAL_KEY, ValueUtil.nullToStr(formItem.getMin()));
        replaceMap.put(FORM_ITEM_MAX_VAL_KEY, ValueUtil.nullToStr(formItem.getMax()));
        replaceMap.put(FORM_ITEM_DATE_TIME_INPUT_VAL_KEY, ValueUtil.nullToStr(formItem.getDateTimeInput()));

        for (FormCssInfoBean formCssInfo : formItem.getFormCssInfoList()) {
            replaceMap.put(MessageFormat.format(FORM_ITEM_CSS_VAL_KEY, formCssInfo.getVarName()) + "."
                    + Integer.toString(formCssInfo.getNum()), formCssInfo.getVarValue());

            if (formCssInfo.getNum() == 1) {
                replaceMap.put(MessageFormat.format(FORM_ITEM_CSS_VAL_KEY, formCssInfo.getVarName()), formCssInfo
                        .getVarValue());
            }
        }

        FormItemUtil formItemUtil = FormItemUtil.getInstance(formItem, request);

        SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getRaw(), FORM_ITEM_RAW_VAL_KEY);
        SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getValueNoenc(), FORM_ITEM_VALUE_NOENC_VAL_KEY);
        SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getValue(), FORM_ITEM_VALUE_VAL_KEY);
        SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getDispNoenc(), FORM_ITEM_DISP_NOENC_VAL_KEY);
        SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getDisp(), FORM_ITEM_DISP_VAL_KEY);

        SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getRaws(), FORM_ITEM_RAW_VAL_KEY);
        SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getValuesNoenc(), FORM_ITEM_VALUE_NOENC_VAL_KEY);
        SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getValues(), FORM_ITEM_VALUE_VAL_KEY);
        SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getDispsNoenc(), FORM_ITEM_DISP_NOENC_VAL_KEY);
        SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getDisps(), FORM_ITEM_DISP_VAL_KEY);

        // 性別のときだけ、rawsではなくvaluesでchecked/selectedの値を確認する。
        String[] values = (formItem.getType().equals("17") ? formItemUtil.getValues() : formItemUtil.getRaws());
        for (String value : values) {
            SstagUtil.setValueToReplaceMap(replaceMap, "checked", FORM_ITEM_CHECKED_VAL_KEY, value);
            SstagUtil.setValueToReplaceMap(replaceMap, "selected", FORM_ITEM_SELECTED_VAL_KEY, value);
        }

        return replaceMap;
    }

    /**
     * 条件判断ロジックにより、表示内容を切り替える。
     * 
     * @param request
     * @param sstagParam
     * @param sgInfo
     * @param formInfo
     * @param postInfo
     * @param formUseInfo
     * @param logic
     * @return
     * @throws Exception
     */
    private JudgementLogicStatus logic(HttpServletRequest request, Map<String, String> sstagParam,
            SstagGlobalInfo sgInfo, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String[] logic)
            throws Exception {
        // TODO kurinami 【確認】 ★ 動作未確認
        SstagDynamicLogic logicClass = (SstagDynamicLogic) LoadUtil.newInstanceFromId(request, logic[0]);

        List<String> userParam = Arrays.asList(logic);
        return logicClass.judgementLogic(sgInfo, sstagParam, userParam, formInfo, postInfo, formUseInfo, null, null,
                null, null, true, false);

    }

}
