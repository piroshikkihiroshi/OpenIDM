package jp.co.webcrew.phoenix.sstag.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.filters.util.httputil.CustomHttpServletResponse;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * リダイレクトを行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class RedirectExecuter extends SSTagExecuter {

    /** パラメータ名：リダイレクト先ＵＲＬ */
    private static final String LOCATION_PARAM_KEY = "location";

    /** パラメータ名：リダイレクトのレスポンスコード */
    private static final String RESPONSE_PARAM_KEY = "response";

    /** パラメータ名：このパラメータで指定した値が存在する時リダイレクトする */
    private static final String EXIST_PARAM_KEY = "exist";

    /** パラメータ名：このパラメータで指定した値が存在しない時リダイレクトする */
    private static final String NODATA_PARAM_KEY = "nodata";

    /** パラメータ接頭辞：リダイレクト先に渡す情報 */
    private static final String HANDOVER_PREFIX = "handover.";
    
    private static final String STATUS_PARAM_KEY = "status";

    

    /** ロガー */
    private static final Logger log = Logger.getLogger(RedirectExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            String location = ValueUtil.nullToStr(parameters.get(LOCATION_PARAM_KEY));
            int responseCode = ValueUtil.toint((String) parameters.get(RESPONSE_PARAM_KEY));
            String exist = (String) parameters.get(EXIST_PARAM_KEY);
            String nodata = (String) parameters.get(NODATA_PARAM_KEY);
            
            String status = ValueUtil.nullToStr(parameters.get(STATUS_PARAM_KEY));
            
            Map<String, String> handoverMap = getHandoverMap(parameters);

            if (exist != null && exist.length() > 0 || nodata != null && nodata.length() == 0 || exist == null
                    && nodata == null) {

                // handover用のメッセージが存在する場合、
                if (!PhoenixUtil.isEmpty(handoverMap)) {
                    StoreUtil.setHandoverMap(request, handoverMap);
                }

                if(status.length()==0 || status.equals("302") || status.equals("temp"))
                {
                    // リダイレクトする。
                    response.sendRedirect(location);
                }
                else if(status.equals("301") || status.equals("perm"))
                {
                	if(response instanceof CustomHttpServletResponse)
                	{
                		CustomHttpServletResponse customResponse=(CustomHttpServletResponse)response;
                		customResponse.send301Redirect(location);
                	}
                	else
                	{
	                    response.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
	                    response.setHeader("Location",location);
                	}
                }
                else
                {
                	throw new Exception("パラメータ[status]に指定した値が不正です。"+status);
                }
                
                if (responseCode != 0) {
                    // TODO kurinami 【確認】 レスポンスコードの指定はできないっぽい。
                    response.sendError(responseCode);
                }
            }

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * handover用のメッセージ一覧を返す。
     * 
     * @param parameters
     * @return
     */
    private Map<String, String> getHandoverMap(Map<String, String> parameters) {

        Map<String, String> handoverMap = new HashMap<String, String>();

        for (Map.Entry<String, String> entry : parameters.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            if (key.toLowerCase().startsWith(HANDOVER_PREFIX)) {
                handoverMap.put(key.substring(HANDOVER_PREFIX.length()), value);
            }
        }

        return handoverMap;

    }
}
