package jp.co.webcrew.login.common;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.DBUtil;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MailTemplate;
import jp.co.webcrew.login.common.db.MailTemplateUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.SiteMst;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.util.AppUtil;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.Mail;
import jp.co.webcrew.login.common.util.SiteUtil;


/**
 * リマインダ共通処理
 *
 * @author Takahashi
 *
 */
public class ReminderUtil {

	/** ロガー */
	private static final Logger log = Logger.getLogger(ReminderUtil.class);

	/** 生成するパスワードの長さ */
	public static final int TEMP_PASSWORD_LENGTH = 8;

	/**
	 * リマインダ送付通知メールを送信し、メール送信に失敗したらリマイダ処理を元に戻す
	 *
	 * 全ての処理が成功したらtrue
	 * 失敗したらfalseを返す
	 *
	 * @param mailto      リマインド処理に渡したのと同じ email アドレス（必須）
	 *
	 * @param from        メールの送信元用E-mailアドレス               （null可）
	 *
	 * @param passwd      リマインド処理で再設定されたパスワード       （必須）
	 *
	 * @param url         リマインダ通知後にユーザがアクセスするurl    （必須）
	 *                      本登録済みの時 ---> ログインURL
	 *                      仮登録状態の時 ---> 本登録用URL
	 *
	 * @param templateId  送信するメール文面ID                         （必須）
	 *
	 * @param result      リマインダ処理の結果                         （必須）
	 */
	public static boolean sendMail ( String mailto ,
			String from ,
			String passwd ,
			String url ,
			String templateId ,
	ReminderResult result) {

		boolean sent = sendMailOnly(mailto , from , passwd , url , templateId , result);

		if ( sent ) {

			return true;

		} else {

			rollbackRemind(result);

			return false;
		}
	}
	
	/**
	 * リマインダ送付通知メールを送信する
	 *
	 * 成功したらtrue、失敗したらfalseを返す
	 *
	 * @param mailto      リマインド処理に渡したのと同じ email アドレス（必須）
	 *
	 * @param from        メールの送信元用E-mailアドレス               （null可）
	 *
	 * @param passwd      リマインド処理で再設定されたパスワード       （必須）
	 *
	 * @param url         リマインダ通知後にユーザがアクセスするurl    （必須）
	 *                      本登録済みの時 ---> ログインURL
	 *                      仮登録状態の時 ---> 本登録用URL
	 *
	 * @param templateId  送信するメール文面ID                         （必須）
	 *
	 * @param result      リマインダ処理の結果                         （必須）
	 */
	private static boolean sendMailOnly ( String mailto ,
								String from ,
								String passwd ,
								String url ,
								String templateId ,
						ReminderResult result) {

		log.info ("リマインダメールを送信します。");

		/*
		 * 入力チェック
		 */

		if (ValueUtil.nullToStr(mailto).equals("")) {
			log.error("宛先が指定されませんでした。メール送信を中断します。");
			return false;
		}

		if (ValueUtil.nullToStr(passwd).equals("")) {
			log.error("パスワードが指定されませんでした。メール送信を中断します。");
			return false;
		}

		if (ValueUtil.nullToStr(url).equals("")) {
			log.error("urlが指定されませんでした。メール送信を中断します。");
			return false;
		}

		if (ValueUtil.nullToStr(templateId).equals("")) {
			log.error("templateIdが指定されませんでした。メール送信を中断します。");
			return false;
		}

		if (result == null || result.status == false) {
			log.error("リマインダ処理が成功していないようです。メール送信を中断します。");
			return false;
		}


		/*
		 * 送信処理開始
		 */

		DBAccess db = null;
		try {
			db = new DBAccess();

			// システムプロパティを取得
			SystemProperties props = new SystemProperties(db);

			// urlをシステムプロパティ変数で置換する
			url = SystemProperties.replace(props, url);
			if (url == null) {
				log.error("urlのシステムプロパティ置換に失敗しました。url = " + url);
				return false;
			}

			// メールアドレスから会員情報を読み込む
			MemberMst member = new MemberMst();
			if (! member.load(db , mailto) ) {
				log.error("会員情報の読み込みに失敗しました。email = " + mailto);
				return false;
			}

			boolean isKaritouroku = member.isKaritouroku();


			// メールテンプレートを準備する
//			String mailTemplateId = getMailTemplateId(templateId , isKaritouroku);
			MailTemplate template = new MailTemplate(templateId);

			if (! template.load(db)) {
				// テンプレート読み込みに失敗したらエラー
				log.error("リマインダメール送信中に、テンプレートの読み込みに失敗しました。templateId = " + templateId);
				return false;
			}

			// 各設定を取得
			String smtp    = props.getSmtpHost();
			String port    = props.get(SystemProperties.MAIL_SMTP_PORT);
			String subject = template.getSubject();
			String body    = template.getBody();
//			String from    = template.getFrom();

			from = getMailSender (template , props , from , isKaritouroku) ;
			if (from == null) {
				log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
				return false;
			}



			// テンプレートの変数を置換
		    if (! isKaritouroku) {
			    body = body.replaceAll("\\$\\$nickname\\$\\$"     , member.get(MemberMst.NICKNAME) );
			    body = body.replaceAll("\\$\\$member_name1\\$\\$" , member.get(MemberMst.NAME1));
			    body = body.replaceAll("\\$\\$member_name2\\$\\$" , member.get(MemberMst.NAME2));
			}

		    body = body.replaceAll("\\$\\$auth_url\\$\\$"   ,    url    );
		    body = body.replaceAll("\\$\\$login_url\\$\\$"  ,    url    );
		    body = body.replaceAll("\\$\\$auth_pass\\$\\$"  ,    passwd );
		    body = body.replaceAll("\\$\\$login_pass\\$\\$" ,    passwd );
		    body = body.replaceAll("\\$\\$password\\$\\$"   ,    passwd );
		    body = body.replaceAll("\\$\\$email\\$\\$"      ,    mailto );

		    body = AppUtil.replaceDateTime(body); // 日付時刻を置換

		    Mail.sendMail(smtp , port , mailto , from , subject , body);

		    log.info("リマインダメールを送信しました。");
		    return true;

		} catch (Exception e) {
			log.error("リマインダメール送信中に例外エラーが発生しました。" , e);

//			rollbackRemind (result);

			return false;

		} finally {
			DBAccess.close(db);
		}

	}
	
	/**
	 * <pre>
	 * リマインド処理を元に戻す
	 * </pre>
	 *
	 * @param result リマインダの処理結果
	 */
	private static void rollbackRemind (ReminderResult result) {

		if (result.status == false) {
			log.warn("リマインダ処理が成功していないようです。リマインダ処理ロールバックを中止します。");
			return;
		}

		DBAccess db = null;
		try {
			db = new DBAccess();
			db.setAutoCommit(false);

			rollbackRemind (db , result); // ロールバック

			db.commit();

		} catch (Exception e) {
			log.error("仮登録用リマインド処理のロールバック中に例外エラーが発生しました。" , e);
			db.rollback();

		} finally {
			DBAccess.close(db);
		}
	}

	/**
	 * <pre>
	 * リマインド処理を元に戻す
	 * </pre>
	 *
	 * @param result リマインダの処理結果
	 */
	private static void rollbackRemind (DBAccess db , ReminderResult result) {

		if (result.status == false) {
			log.warn("リマインダ処理が成功していないようです。リマインダ処理ロールバックを中止します。");
			return;
		}

		try {

			DBUpdater updater = new DBUpdater(MemberMst.TABLE);
			updater.addString(MemberMst.PASSWD           , result.passwd);
			updater.addString(MemberMst.REMINDER_FLAG    , result.reminder_flag);
			updater.addString(MemberMst.RM_DATETIME      , result.rm_datetime);
			updater.addString(MemberMst.LIMIT_DATETIME   , result.limit_datetime);
			updater.setCond("WHERE GUID = ?");
			updater.addCondString(result.guid);

			updater.update(db);

		} catch (Exception e) {
			log.error("仮登録用リマインド処理のロールバック中に例外エラーが発生しました。" , e);
		}
	}

	/**
	 * 該当E-MAILの会員が存在するか否かを調べる
	 *
	 * true  : 存在する
	 * false : 存在しない
	 *
	 * @param email
	 * @return
	 */
	public static boolean existsMember (DBAccess db , String email) throws SQLException {
		return MemberMst.existsMailAddress(db, email);
	}

	/**
	 * 該当E-MAILの会員が仮登録会員であるか否か調べる
	 *
	 * true  : 仮登録会員である
	 * false : 仮登録会員ではない(登録されていない、本登録ユーザである等)
	 *
	 * @param db
	 * @param email
	 * @return
	 */
	public static boolean isTempMember (DBAccess db , String email) {
		MemberMst member = new MemberMst();

		try {
			if (!member.load(db, email)) {
				return false;
			}
			return member.isKaritouroku();
		} catch (Exception e) {
			log.error("ユーザの登録状態を調査中に例外エラーが発生しました。" , e);
			return false;
		}

	}

	/**
	 * 該当E-MAILの会員が本登録会員であるか否か調べる
	 *
	 * true  : 本登録会員である
	 * false : 本登録会員ではない(登録されていない、仮登録会員である等)
	 *
	 * @param db
	 * @param email
	 * @return
	 */
	public static boolean isRealMember (DBAccess db , String email) {
		MemberMst member = new MemberMst();

		try {
			if (!member.load(db, email)) {
				return false;
			}
			return member.isHontouroku();
		} catch (Exception e) {
			log.error("ユーザの登録状態を調査中に例外エラーが発生しました。" , e);
			return false;
		}

	}

	/**
	 * リマインド処理を行う
	 *
	 * @param email     メールアドレス  （必須）
	 *
	 * @param birthDay  誕生日 YYYYMMDD （null可）
	 *                    ・本登録済みの会員の場合
     *                      生年月日が会員マスタの生年月日と一致すること
     *                    ・仮登録済み会員の場合
     *                      引数として渡された生年月日は無視する
	 *
	 * @return ReminderResult 処理結果オブジェクト
	 */
	public static ReminderResult remind (String email , String birthDay) {

		log.info ("リマインダのデータベース処理を行います。");
		ReminderResult result = new ReminderResult();

		result.status = false;

	  // ----- 入力チェック

		if (ValueUtil.nullToStr(email).equals("")) {
			log.error("宛先が指定されませんでした。リマインダ処理を中断します。");
			result.reason = ReminderResult.REMIND_INPUT_EMAIL_ERROR;
			return result;
		}


		DBAccess db = null;
		try {
			db = new DBAccess();
			db.setAutoCommit(false);

			// メールアドレスが会員マスタに存在するか否かをチェックする
			if (! MemberMst.existsMailAddress(db, email)) {
				log.info("会員マスタにメールアドレスが存在しません。");
				result.reason = ReminderResult.REMIND_EMAIL_NOT_EXIST_ERROR;
				return result;
			}

			// パスワードを再生成
			String newPasswd    = DBUtil.makeRandomPassword(TEMP_PASSWORD_LENGTH); // ランダムな英数字で仮パスワードを生成
//			String passwdDigest = DBUtil.getDigestOf(newPasswd);                   // 仮パスワードは暗号化しない 08/12/13 Takahashi

			// 会員情報を読み込む
			MemberMst member = new MemberMst();
			if (! member.load(db , email) ) {
				log.error("会員情報の読み込みに失敗しました。email=" + email);
				result.reason = ReminderResult.REMIND_DB_ERROR;
				return result;
			}

			// 読み込んだ会員情報を、結果に保存しておく
			result.guid             = member.get(MemberMst.GUID);
			result.passwd           = member.get(MemberMst.PASSWD);
			result.reminder_flag    = member.get(MemberMst.REMINDER_FLAG);
			result.rm_datetime      = member.get(MemberMst.RM_DATETIME);
			result.limit_datetime   = member.get(MemberMst.LIMIT_DATETIME);

		  // ----- 仮登録か本登録かを判断
			if ( member.isKaritouroku() ) {




				// パスワードを更新
				if (remindTempUserPassword (db , member , newPasswd)){
					db.commit();

					result.status     = true;
					result.registStat = ReminderResult.STAT_TEMP_REG;
					result.siteId     = member.get((MemberMst.SITE_ID));
					result.newPasswd  = newPasswd;
					result.emailType  = member.getEmailType();

					return result;

				} else {

					db.rollback();

					result.reason     = ReminderResult.REMIND_DB_ERROR;

					return result;

				}



			} else{
				//パスワードが暗号化されている場合のみ生年月日チェックを行う
				if(member.isHavingHashedPasswd())
				{
				// 本登録の時は、生年月日がDB登録されている場合のみ、生年月日をチェックする

                String memberBirthday = member.get(MemberMst.BIRTHDAY);
                if (! memberBirthday.equals("")) {
                    if (birthDay == null) {
                        log.error("生年月日が指定されていません。");
                        result.reason = ReminderResult.REMIND_INPUT_BIRTHDAY_ERROR;
                        return result;

                    }
                    if (birthDay.length() != 8) {
                        log.error("生年月日の形式がYYYMMDD形式になっていません。リマインダ処理を中断します。");
                        result.reason = ReminderResult.REMIND_INPUT_BIRTHDAY_ERROR;
                        return result;
                    }
                    // 生年月日が合致しているかどうかをチェックする
                    if (! memberBirthday.equals(birthDay)) {
                        result.reason = ReminderResult.REMIND_BIRTHDAT_AUTH_ERROR;
                        return result;
                    }
                }
				}

				// パスワードを更新
				if (remindUserPassword (db , member , newPasswd)) {
					db.commit();
					// 処理結果を生成
					result.registStat = ReminderResult.STAT_REAL_REG;
					result.siteId     = member.get((MemberMst.SITE_ID));
					result.newPasswd  = newPasswd;
					result.emailType  = member.getEmailType();
					result.status     = true;
					return result;

				} else {
					db.rollback();
					// 処理結果を生成
					result.reason = ReminderResult.REMIND_DB_ERROR;
					return result;

				}

			}



		} catch (SQLException e) {
			log.error("リマインダ処理中にデータベースエラーが発生しました。" , e);
			result.reason = ReminderResult.REMIND_DB_ERROR;
			return result;

		} catch (Exception e) {
			log.error("リマインダ処理中に例外エラーが発生しました。" , e);
			result.reason = ReminderResult.REMIND_OTHER_ERROR;
			return result;

		} finally {
			DBAccess.close(db);
		}

	}


	/**
	 * リマインダメールの送信者を取得する。
	 * 取得に失敗した場合はnullを返す。
	 *
	 * @param props         システムプロパティ
	 * @param from          指定された送信者
	 * @param isKaritouroku 仮登録者であるか否か
	 * @return
	 */
	private static String getMailSender(MailTemplate template , SystemProperties props , String from , boolean isKaritouroku) {
/*
 		if (ValueUtil.nullToStr(from).equals("")) {
			// デフォルト値を使う
			if (isKaritouroku) {
				from = "$$MAIL_SENDER_OF_DEFAULT_TEMP_REMINDER$$";
			} else {
				from = "$$MAIL_SENDER_OF_DEFAULT_REAL_REMINDER$$";
			}
		}

		return  props.replaceStr(from);
*/
		if (props == null) {
			log.error("システムプロパティオブジェクトがnullです。呼び出しが不正です。");
			return null;
		}

		String sender = "";

		if (template != null) {
			sender  = ValueUtil.nullToStr(template.getFrom());  // メールテンプレートのfromを最優先とする
		}

		if (sender.equals("")) {
			// メールテンプレートから送信者を取得できなかった場合、指定されたfromを使用する
			sender = ValueUtil.nullToStr (from);
		}

		if (sender.equals("")) {
			log.warn("MAIL_TEMPLテーブルにfromが指定されていないため、システムプロパティからデフォルト値を取得します。");
			// デフォルト値を使う
			if (isKaritouroku) {
				sender = "$$MAIL_SENDER_OF_DEFAULT_TEMP_REMINDER$$";
			} else {
				sender = "$$MAIL_SENDER_OF_DEFAULT_REAL_REMINDER$$";
			}
		}


		return  props.replaceStr(sender); // システムプロパティ変数を置換
	}
	
	/**
	 * 仮登録済みユーザに対して、リマインダ処理を行う
	 *
	 * @param db
	 * @param member
	 * @param newPassDigest
	 * @return
	 */
	private static boolean remindTempUserPassword (DBAccess db , MemberMst member , String newPassDigest) {

		if (member == null) return false;

		String now = DateUtil.currentDateTime();

		try {

			SystemProperties props = new SystemProperties(db);

			DBUpdater updater = new DBUpdater(member.getFullTableName());
			updater.addString(MemberMst.PASSWD         , newPassDigest);                          // 新パスワードダイジェスト
			updater.addString(MemberMst.REMINDER_FLAG  , MemberMst.FLG_REMINDER_SENT);            // リマインダ送信フラグON
			updater.addString(MemberMst.LIMIT_DATETIME , TempRegistUtil.getLimitDateTime(props)); // 仮登録有効期限を更新
			updater.addString(MemberMst.RM_DATETIME    , now); // 日付を更新
			updater.addString(MemberMst.UP_DATETIME    , now); // 日付を更新
			updater.setCond("WHERE GUID=?");
			updater.addCondString(member.getGuid());

			updater.update(db);

		} catch (Exception e) {
			log.error("仮登録ユーザ更新処理中に例外エラーが発生しました。" , e);
			return false;
		}

		return true;

	}

	/**
	 * 本登録済みユーザに対して、リマインダ処理を行う
	 *
	 * @param db
	 * @param member
	 * @param newPasswd
	 * @return
	 */
	private static boolean remindUserPassword (DBAccess db , MemberMst member , String newPasswd) {

		if (member == null) return false;

		String now = DateUtil.currentDateTime();

		DBUpdater updater = new DBUpdater(member.getFullTableName());
		updater.addString(MemberMst.PASSWD ,        newPasswd);                   // 新パスワード
		updater.addString(MemberMst.REMINDER_FLAG , MemberMst.FLG_REMINDER_SENT); // リマインダ送信フラグON
		updater.addString(MemberMst.RM_DATETIME ,   now); // 日付を更新
		updater.addString(MemberMst.UP_DATETIME ,   now); // 日付を更新
		updater.setCond("WHERE GUID=?");
		updater.addCondString(member.getGuid());

		try {
			updater.update(db);
		} catch (Exception e) {
			log.error("仮登録ユーザ更新処理中に例外エラーが発生しました。" , e);
			return false;
		}

		return true;

	}

	/**
	 * <pre>
	 * 仮登録者向けリマインド処理後の、本登録用のurlを生成する
	 *
	 * エラーの場合はnull
	 *
	 * </pre>
	 *
	 * @param siteId
	 * @return
	 */
	public static String getRegistUrl(DBAccess db , String siteId , String email , String passwd) {

		try {
			if (SiteUtil.isTonashibaSiteId(siteId)) {
				// となしばの本登録用のURLを生成する
				return getTonashibaRealRegistUrl (email , passwd);
			}

			if (SiteUtil.isStepSite(db, siteId)) {
				// 本登録用のURLを生成する
				return getStepRegistUrl();
			}

			if (SiteUtil.isTargetSite(siteId)) {
				// 本登録用のURLを生成する
				return getStepRegistUrl();
			}

			if (! SiteMst.contains(db , siteId) ) {
				// サイトマスタに登録されていない場合はエラー
				log.error("サイトIDがサイトマスタに登録されていません。");
				log.info("siteId=" + siteId);
				return null;
			}

			// ステップサイトでも無く、となしばでも無い場合、呼び出し方に問題がある
			log.error("仮登録者向けのリマインド処理ができない、特殊なサイトが認識されました。siteId = " + siteId);
			return null;

		} catch (Exception e) {
			log.error("例外エラーが発生しました。" , e);
			return null;
		}
	}

	/**
	 * となしば本登録処理のurlを生成する
	 *
	 * @param siteId
	 * @return
	 */
	public static String getTonashibaRealRegistUrl(String email , String passwd)
			throws UnsupportedEncodingException {
		// となしばの本登録用のURLを生成する
		String registUrl = "$$TNS_LOGIN_URI_TOP$$$$TNS_REGIST_URI_PATH$$";
		registUrl += "?email=" + java.net.URLEncoder.encode(email,"utf-8");
		registUrl += "&passwd=" + passwd;
		return registUrl;
	}

	/**
	 * step_loginの本登録処理を行うURLを取得する
	 *
	 * @param stepRegInfo
	 * @return
	 */
	public static String getStepRegistUrl () {
		String registUrl = "$$LOGIN_APP_URI_TOP$$$$REGIST_AUTH_URI_PATH$$";
//		registUrl += "?siteId=" + stepRegInfo.getSiteId();
//		registUrl += "&userId=" + stepRegInfo.getUserId() + "&orderId=" + stepRegInfo.getRequestId();

		return registUrl;

	}
	
	
	
	
	/**
	 * 【メール送信処理共通化用】
	 * リマインダ送付通知メールを送信し、メール送信に失敗したらリマイダ処理を元に戻す
	 * 
	 * @param strMailTo
	 * @param strMailFrom
	 * @param strPasswd
	 * @param strUrl
	 * @param strTemplateId
	 * @param objResult
	 * @param objMemberMst
	 * @return
	 */
	public static boolean sendMail(
			String strMailTo,
			String strMailFrom,
			String strPasswd,
			String strUrl,
			String strTemplateId,
			ReminderResult objResult,
			MemberMst objMemberMst)
	{
		boolean sent = sendMailOnly(strMailTo, strMailFrom, strPasswd, strUrl, strTemplateId, objResult, objMemberMst);

		if (sent)
		{
			return true;
		}
		else
		{
			rollbackRemind(objResult);

			return false;
		}
	}
	
	/**
	 * 【メール送信処理共通化用】
	 * リマインダ送付通知メールを送信する
	 * 成功したらtrue、失敗したらfalseを返す
	 * 
	 * @param mailto
	 * @param from
	 * @param passwd
	 * @param url
	 * @param templateId
	 * @param result
	 * @param objMemberMst
	 * @return
	 */
	private static boolean sendMailOnly (
			String strMailTo,
			String strMailFrom,
			String strPasswd,
			String strUrl,
			String templateId,
			ReminderResult result,
			MemberMst objMemberMst)
	{
		/*
		 * 入力チェック
		 */

		if (ValueUtil.nullToStr(strMailTo).equals(""))
		{
			log.error("宛先が指定されませんでした。メール送信を中断します。");
			return false;
		}

		if (ValueUtil.nullToStr(strPasswd).equals(""))
		{
			log.error("パスワードが指定されませんでした。メール送信を中断します。");
			return false;
		}

		if (ValueUtil.nullToStr(strUrl).equals(""))
		{
			log.error("urlが指定されませんでした。メール送信を中断します。");
			return false;
		}

		if (ValueUtil.nullToStr(templateId).equals(""))
		{
			log.error("templateIdが指定されませんでした。メール送信を中断します。");
			return false;
		}

		if (result == null || result.status == false)
		{
			log.error("リマインダ処理が成功していないようです。メール送信を中断します。");
			return false;
		}

		/*
		 * 送信処理開始
		 */
		DBAccess objDbAccess = null;
		try
		{
			objDbAccess = new DBAccess();

			// システムプロパティを取得
			SystemProperties props = new SystemProperties(objDbAccess);

			// urlをシステムプロパティ変数で置換する
			strUrl = SystemProperties.replace(props, strUrl);
			if (strUrl == null)
			{
				log.error("urlのシステムプロパティ置換に失敗しました。url = " + strUrl);
				return false;
			}

			// メールテンプレートを準備する
			MailTemplateUtil objMailTemplate = new MailTemplateUtil(templateId);

			if (! objMailTemplate.load(objDbAccess))
			{
				// テンプレート読み込みに失敗したらエラー
				log.error("リマインダメール送信中に、テンプレートの読み込みに失敗しました。templateId = " + templateId);
				return false;
			}

			//差出人メールアドレスを取得
			strMailFrom = getMailSender (objMailTemplate , props , strMailFrom , objMemberMst.isKaritouroku());
			if (strMailFrom == null)
			{
				log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
				return false;
			}

			//メール送信情報を設定する
			MailInfo objMailInfo = new MailInfo();
			objMailInfo.setMailTo(strMailTo);
			objMailInfo.setMailFrom(strMailFrom);
			objMailInfo.setMobileFlag(MailTemplateUtil.isMobileEmail(objDbAccess, strMailTo));
			objMailInfo.setSiteId(objMemberMst.get(MemberMst.SITE_ID));
			
			//件名情報を生成(件名の変数を置き換えるための変数を設定する)
			MailSubject objMailSubject = new MailSubject(objMemberMst);
			
			//本文情報を生成(本文の変数を置き換えるための変数を設定する)
			MailBody objMailBody = new MailBody(objMemberMst);
			objMailBody.setEmail(strMailTo);
			objMailBody.setAuthUrl(strUrl);
			objMailBody.setLoginUrl(strUrl);
			objMailBody.setPasswordAll(strPasswd);
			
			return objMailTemplate.doReplaceAndMail(objMailSubject, objMailBody, objMailInfo);
		}
		catch (Exception e)
		{
			log.error("リマインダメール送信中に例外エラーが発生しました。" , e);
			return false;
		}
		finally
		{
			DBAccess.close(objDbAccess);
		}
	}
	
	/**
	 * 【メール送信処理共通化用】
	 * リマインダメールの送信者を取得する。
	 * 取得に失敗した場合はnullを返す。
	 *
	 * @param props         システムプロパティ
	 * @param from          指定された送信者
	 * @param isKaritouroku 仮登録者であるか否か
	 * @return
	 */
	private static String getMailSender(MailTemplateUtil template , SystemProperties props , String from , boolean isKaritouroku)
	{
		if (props == null)
		{
			log.error("システムプロパティオブジェクトがnullです。呼び出しが不正です。");
			return null;
		}

		String sender = "";

		if (template != null)
		{
			sender  = ValueUtil.nullToStr(template.getFrom());  // メールテンプレートのfromを最優先とする
		}

		if (sender.equals(""))
		{
			// メールテンプレートから送信者を取得できなかった場合、指定されたfromを使用する
			sender = ValueUtil.nullToStr (from);
		}

		if (sender.equals(""))
		{
			log.warn("MAIL_TEMPLテーブルにfromが指定されていないため、システムプロパティからデフォルト値を取得します。");
			// デフォルト値を使う
			if (isKaritouroku)
			{
				sender = "$$MAIL_SENDER_OF_DEFAULT_TEMP_REMINDER$$";
			}
			else
			{
				sender = "$$MAIL_SENDER_OF_DEFAULT_REAL_REMINDER$$";
			}
		}

		return  props.replaceStr(sender); // システムプロパティ変数を置換
	}
}
