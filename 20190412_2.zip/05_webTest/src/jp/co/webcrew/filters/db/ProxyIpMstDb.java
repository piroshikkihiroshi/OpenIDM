package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * プロキシ許可IPを管理するdbクラス。
 * 
 * @author kurinami
 */
public class ProxyIpMstDb extends RefreshMstDb {

	/** プロキシ許可IPマスタ情報取得用SQL */
	private static final String PROXY_IP_MST_SELECT = "select * from proxy_ip_mst";

	/** 唯一のインスタンス */
	private static ProxyIpMstDb proxyIpMstDb = new ProxyIpMstDb();

	/** プロキシ情報の一覧 */
	private List proxyIpList;

	/**
	 * 生成不能コンストラクタ
	 */
	private ProxyIpMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static ProxyIpMstDb getInstance() {
		return proxyIpMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			List proxyIpList = new ArrayList();

			// プロキシ許可IP一覧を検索する。
			dbAccess.prepareStatement(PROXY_IP_MST_SELECT);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				Map element = new HashMap();

				element.put("ip_addr", ValueUtil.nullToStr(rs
						.getString("ip_addr")));
				element.put("netmask", ValueUtil.nullToStr(rs
						.getString("netmask")));
				element.put("description", ValueUtil.nullToStr(rs
						.getString("description")));

				proxyIpList.add(element);
			}

			this.proxyIpList = proxyIpList;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * プロキシ可能なホストからのリクエストかを判定する。
	 * 
	 * @param gegege
	 * @return
	 */
	public boolean isProxyHost(String remoteAddr) {
		List proxyIpList = this.proxyIpList;

		for (int i = 0; i < proxyIpList.size(); i++) {
			Map element = (Map) proxyIpList.get(i);
			String ipAddr = (String) element.get("ip_addr");
			String netmask = (String) element.get("netmask");

			if (ValueUtil.toint(netmask) == 0) {

			} else {
				int remoteBit = getMaskedAddressBit(remoteAddr, ValueUtil
						.toint(netmask));
				int proxyBit = getMaskedAddressBit(ipAddr, ValueUtil
						.toint(netmask));
				if (remoteBit == proxyBit) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * IPアドレスにマスクをかけたビット値を返す。
	 * 
	 * @param address
	 * @param maskBitDigit
	 * @return
	 */
	private static int getMaskedAddressBit(String address, int maskBitDigit) {

		final int byteDigit = 4;
		final int bitDigit = 8;

		int addressBit = 0;

		String[] nums = ValueUtil.nullToStr(address).split("\\.", byteDigit);

		for (int i = 0; i < byteDigit; i++) {
			addressBit <<= bitDigit;
			if (nums.length > i && nums[i].length() > 0) {
				addressBit += Integer.parseInt(nums[i]);
			}
		}

		int shiftBitDigit = byteDigit * bitDigit - maskBitDigit;
		return (shiftBitDigit < byteDigit * bitDigit) ? (addressBit >>> shiftBitDigit << shiftBitDigit)
				: 0;
	}

}
