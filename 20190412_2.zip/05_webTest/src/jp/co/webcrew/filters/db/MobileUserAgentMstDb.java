package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

public class MobileUserAgentMstDb extends RefreshMstDb {
		
	/** モバイルユーザエージェントマスタ情報取得用SQL */
	private static final String MOBILE_USER_AGENT_MST_SELECT = "select * from common.mobile_user_agent_mst";

	/** 唯一のインスタンス */
	private static MobileUserAgentMstDb mobileUserAgentMstDb = new MobileUserAgentMstDb();

	/** 変換キーワードの一覧 */
	private Map uaMap;
	
	/** 上位機種タイプ */
	public static final String TYPE_UPPER = "3";
	
	/** 下位機種タイプ */
	public static final String TYPE_LOWER = "2";
	
	/** 非対応機種タイプ */
	public static final String TYPE_NONCOMPLIANT = "1";

	/**
	 * 生成不能コンストラクタ
	 */
	private MobileUserAgentMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static MobileUserAgentMstDb getInstance() {
		return mobileUserAgentMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			Map uaMap = new HashMap();

			// サイト情報一覧を検索する。
			dbAccess.prepareStatement(MOBILE_USER_AGENT_MST_SELECT);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				String ua_name = ValueUtil.nullToStr(rs.getString("ua_name"));
				String type = rs.getString("ua_type");

				uaMap.put(ua_name, type);
			}

			this.uaMap = uaMap;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * モバイルユーザエージェントの一覧を返す。
	 * 
	 * @return
	 */
	public Map getUserAgentMap() {
		Map uaMap = this.uaMap;
		if (uaMap != null) {
			return new HashMap(uaMap);
		} else {
			return new HashMap();
		}
	}

}
