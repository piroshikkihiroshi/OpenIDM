package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Calendar;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.AuthMailSendingDb;
import jp.co.webcrew.filters.util.MD5;
import jp.co.webcrew.login.common.MailBody;
import jp.co.webcrew.login.common.MailInfo;
import jp.co.webcrew.login.common.MailSubject;
import jp.co.webcrew.login.common.db.MailTemplateUtil;

/**
 * STEPサイトに認証メールを送るためのExecuterクラス
 * 
 * ・cond_1, cond_2について
 * 　認証メール送信日時(auth_mail_sending_datetime)カラムが存在するテーブル(table_name)から設定する必要があります。
 * 
 * ・table_name, param_1, param_2について
 * 　SELECT {auth_mail_sending_datetime} FROM {table_name} WHERE {cond_1} = {param_1} AND {cond_2} = {param_2}
 * 　のようにSQLが生成されます。
 * 
 * ・qstrについて
 * 　qstrが指定されている場合は、URLにそのqstrで指定されたパラメータを付与
 */
public class AuthMailSendingExecuter extends SSTagExecuter
{
	/** ロガー */
	private static final Logger log = Logger.getLogger(AuthMailSendingExecuter.class);

	private static final String KEY_PARAM_1            = "param_1";            //cond_1に設定したカラム名と紐付ける値(必須)
	private static final String KEY_PARAM_2            = "param_2";            //cond_2に設定したカラム名と紐付ける値(必須)
	private static final String KEY_TABLE_NAME         = "table_name";         //cond_1とcond_2に設定したカラムが存在するテーブル名(必須)
	private static final String KEY_CONDITION_1        = "cond_1";             //param_1に設定した値と紐付けるカラム名(必須)
	private static final String KEY_CONDITION_2        = "cond_2";             //param_2に設定した値と紐付けるカラム名(必須)
	private static final String KEY_EMAIL              = "email";              //メール送信先(必須)
	private static final String KEY_MAIL_TEMPLATE_ID   = "mail_template_id";   //使用するメールテンプレートID(必須)
	private static final String KEY_SITE_ID            = "site_id";            //サイトID(必須)
	private static final String KEY_QUERY_STRING       = "qstr";               //クエリーストリング(任意)
	private static final String KEY_GENERATED_PASSWORD = "generated_password"; //パスワード生成(false=生成しない、それ以外は生成する)(任意)
	private static final String KEY_INTERVAL           = "interval";           //認証メール再送可能間隔[分](デフォルトは0)(任意)
	private static final String KEY_NAME_KANJI_1       = "name_kanji_1";       //姓(任意)
	private static final String KEY_NAME_KANJI_2       = "name_kanji_2";       //名(任意)
	
	/**
	 * メール送信処理
	 */
	public String execute(Map mapParameters, HttpServletRequest objRequest, HttpServletResponse objResponse)
	{
		DBAccess objDBAccess = null;
		
		String strParam_1     = "";
		String strParam_2     = "";
		String strTableName   = "";
		String strCond_1      = "";
		String strCond_2      = "";
		String strEmail       = "";
		String strTemplateId  = "";
		String strSiteId      = "";
		String strQStr        = "";
		String strGenePass    = "";
		String strInterval    = "";
		String strNameKanji_1 = "";
		String strNameKanji_2 = "";
		
		try
		{
			strParam_1     = ValueUtil.nullToStr(mapParameters.get(KEY_PARAM_1));
			strParam_2     = ValueUtil.nullToStr(mapParameters.get(KEY_PARAM_2));
			strTableName   = ValueUtil.nullToStr(mapParameters.get(KEY_TABLE_NAME));
			strCond_1      = ValueUtil.nullToStr(mapParameters.get(KEY_CONDITION_1));
			strCond_2      = ValueUtil.nullToStr(mapParameters.get(KEY_CONDITION_2));
			strEmail       = ValueUtil.nullToStr(mapParameters.get(KEY_EMAIL));
			strTemplateId  = ValueUtil.nullToStr(mapParameters.get(KEY_MAIL_TEMPLATE_ID));
			strSiteId      = ValueUtil.nullToStr(mapParameters.get(KEY_SITE_ID));
			strQStr        = ValueUtil.nullToStr(mapParameters.get(KEY_QUERY_STRING));
			strGenePass    = ValueUtil.nullToStr(mapParameters.get(KEY_GENERATED_PASSWORD));
			strInterval    = ValueUtil.nullToStr(mapParameters.get(KEY_INTERVAL));
			strNameKanji_1 = ValueUtil.nullToStr(mapParameters.get(KEY_NAME_KANJI_1));
			strNameKanji_2 = ValueUtil.nullToStr(mapParameters.get(KEY_NAME_KANJI_2));
		
			if (strParam_1.equals("")
					|| strParam_2.equals("")
					|| strTableName.equals("")
					|| strCond_1.equals("")
					|| strCond_2.equals("")
					|| strEmail.equals("")
					|| strTemplateId.equals("")
					|| strSiteId.equals(""))
			{
				log.error("パラメータを正しく設定して下さい。param_1=" + strParam_1 + " param_2=" + strParam_2 + " table_name=" + strTableName + " cond_1=" + strCond_1 + " cond_2=" + strCond_2 + " email=" + strEmail + " mail_template_id=" + strTemplateId + " site_id=" + strSiteId);
			}
		
			objDBAccess = new DBAccess(true);
			
			//申込情報チェック
			if ( ! AuthMailSendingDb.isExists(objDBAccess, strTableName, strCond_1, strCond_2, strParam_1, strParam_2))
			{
				log.error("[認証メール送信処理] 利用者情報の有無を確認して下さい。param_1=" + strParam_1 + " param_2=" + strParam_2 + " table_name=" + strTableName + " cond_1=" + strCond_1 + " cond_2=" + strCond_2 + " email=" + strEmail + " mail_template_id=" + strTemplateId + " site_id=" + strSiteId);
				
				return "";
			}
			
			//送信チェック
			//送信済みだった場合は送らない
			if (AuthMailSendingDb.isSent(objDBAccess, strTableName, strCond_1, strCond_2, strParam_1, strParam_2, strInterval.equals("") ? 0 : Integer.parseInt(strInterval)))
			{
				log.info("[認証メール送信処理] 認証メール送信済みです。param_1=" + strParam_1 + " param_2=" + strParam_2 + " table_name=" + strTableName + " cond_1=" + strCond_1 + " cond_2=" + strCond_2 + " email=" + strEmail + " mail_template_id=" + strTemplateId + " site_id=" + strSiteId);
				
				return "";
			}
			
			String strPassword = "";
			if ( ! strGenePass.equals("false"))
			{
				strPassword = generatedPassword(strParam_1, strParam_2);
			}
			
			//----------------------------------------------------------------------
			//メール送信処理
			//----------------------------------------------------------------------
			MailTemplateUtil objMailTemplate = new MailTemplateUtil(strTemplateId);
			if ( ! objMailTemplate.load(objDBAccess))
			{
				log.error("[認証メール送信処理] メールテンプレートの有無を確認して下さい。param_1=" + strParam_1 + " param_2=" + strParam_2 + " table_name=" + strTableName + " cond_1=" + strCond_1 + " cond_2=" + strCond_2 + " email=" + strEmail + " mail_template_id=" + strTemplateId + " site_id=" + strSiteId);
				
				return "";
			}
			
			//メール情報
			MailInfo obInfo = new MailInfo();
			obInfo.setMailTo(strEmail);
			obInfo.setMailFrom(objMailTemplate.getFrom());
			obInfo.setMobileFlag(MailTemplateUtil.isMobileEmail(objDBAccess, strEmail));
			obInfo.setSiteId(strSiteId);
			
			//件名
			MailSubject objSubject = new MailSubject();
			
			//本文
			MailBody objBody = new MailBody();
			
			if ( ! strQStr.equals(""))
			{
				//クエリーストリングの&amp;を&に変換
				strQStr = strQStr.replaceAll("&amp;", "&");
				
				if ( ! strGenePass.equals("false"))
				{
					//パスワードをクエリーストリングに追加
					strQStr = strQStr + "&pw=" + strPassword;
				}
				
				objBody.setAuthPass(strQStr);
			}
			else
			{
				if ( ! strGenePass.equals("false"))
				{
					//パスワードをメールに記載する
					objBody.setAuthPass(strPassword);
				}
			}

			//名前を設定
			objBody.setMemberName1(strNameKanji_1);
			objBody.setMemberName2(strNameKanji_2);
			
			try
			{
				//認証メール送信日時を設定する
				if (AuthMailSendingDb.updateTable(objDBAccess, strTableName, strParam_1, strParam_2, strCond_1, strCond_2, strPassword))
				{
					//変数の置換とメール送信
					if (objMailTemplate.doReplaceAndMail(objSubject, objBody, obInfo))
					{
						objDBAccess.commit();
					}
					else
					{
						objDBAccess.rollback();
						
						log.error("[認証メール送信処理] メール送信処理で例外が発生しました。param_1=" + strParam_1 + " param_2=" + strParam_2 + " table_name=" + strTableName + " cond_1=" + strCond_1 + " cond_2=" + strCond_2 + " email=" + strEmail + " mail_template_id=" + strTemplateId + " site_id=" + strSiteId);
						
						return "";
					}
				}
				else
				{
					objDBAccess.rollback();
					
					log.error("[認証メール送信処理] 更新処理で例外が発生しました。param_1=" + strParam_1 + " param_2=" + strParam_2 + " table_name=" + strTableName + " cond_1=" + strCond_1 + " cond_2=" + strCond_2 + " email=" + strEmail + " mail_template_id=" + strTemplateId + " site_id=" + strSiteId);
					
					return "";
				}
			}
			catch (Exception e)
			{
				objDBAccess.rollback();
				
				log.error("[認証メール送信処理] 更新処理で例外が発生しました。param_1=" + strParam_1 + " param_2=" + strParam_2 + " table_name=" + strTableName + " cond_1=" + strCond_1 + " cond_2=" + strCond_2 + " email=" + strEmail + " mail_template_id=" + strTemplateId + " site_id=" + strSiteId);
				
				return "";
			}

			return "";
		}
		catch (Exception e)
		{
			log.error("[認証メール送信処理] 例外が発生しました。param_1=" + strParam_1 + " param_2=" + strParam_2 + " table_name=" + strTableName + " cond_1=" + strCond_1 + " cond_2=" + strCond_2 + " email=" + strEmail + " mail_template_id=" + strTemplateId + " site_id=" + strSiteId, e);
			
			return "";
		}
		finally
		{
			DBAccess.close(objDBAccess);
		}
	}

	/**
	 * パスワードを生成する
	 * 
	 * @param strParam_1
	 * @param strParam_2
	 * @return
	 */
	private String generatedPassword(String strParam_1, String strParam_2)
	{
		String strMD5 = MD5.crypt(strParam_1 + strParam_2 + Calendar.getInstance().getTime().getTime());
		
		return strMD5.substring(0, 8);
	}
}
