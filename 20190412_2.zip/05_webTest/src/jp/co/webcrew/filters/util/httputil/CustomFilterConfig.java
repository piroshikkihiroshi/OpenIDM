package jp.co.webcrew.filters.util.httputil;

import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;

/**
 * サーブレット環境以外でサーブレットフィルタを使用するためのconfigクラス。
 * 
 * @author kurinami
 */
public class CustomFilterConfig implements FilterConfig {

	/** init parameter */
	private Hashtable initParameters = new Hashtable();

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.FilterConfig#getFilterName()
	 */
	public String getFilterName() {
		return this.getClass().getName();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.FilterConfig#getInitParameter(java.lang.String)
	 */
	public String getInitParameter(String key) {
		return (String) initParameters.get(key);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.FilterConfig#getInitParameterNames()
	 */
	public Enumeration getInitParameterNames() {
		return initParameters.keys();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.FilterConfig#getServletContext()
	 */
	public ServletContext getServletContext() {
		return null;
	}

	/**
	 * @param key
	 * @param value
	 */
	public void setInitParameter(String key, String value) {
		initParameters.put(key, value);
	}

}
