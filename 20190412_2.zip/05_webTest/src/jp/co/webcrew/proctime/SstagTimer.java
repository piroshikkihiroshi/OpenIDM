package jp.co.webcrew.proctime;

import java.text.MessageFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.htmlservlet.HtmlPropertiesUtil;

/***
 * Sstagの実行時間を計測する。
 * より詳細なログを採れる仕組み(dbaccessパッケージにPerfLogを導入/SQLやDBAccessオブジェクトの初期化の時間も計測したかったので)を導入したので、
 * 処理を無意味化（空に変更）。
 * 
 * @author kazuto.yano
 *
 */
public class SstagTimer 
{
	/*
	private static final Logger logger=Logger.getLogger(SstagTimer.class);
	
	private static final int LOG_LEVEL;
	private static final int LOG_LEVEL_NON=0;
	private static final int LOG_LEVEL_NORMAL=1;
	private static final int LOG_LEVEL_DETAIL=2;
	private static final int LOG_MSEC;
	private static final int LOG_MSEC_DEFAULT=500;
	*/
	
	static
	{
		/*
		int logLevel=LOG_LEVEL_NON;
		int msec=LOG_MSEC_DEFAULT;
        try {
            HtmlPropertiesUtil prop = new HtmlPropertiesUtil("html_servlet.properties");
            String strVal=ValueUtil.nullToStr( prop.getProperty("sstag.timer.msec"));
            if(strVal.length()!=0)
            {
                msec=Integer.parseInt(strVal);
            }
            strVal=ValueUtil.nullToStr( prop.getProperty("sstag.timer.loglevel"));
            logLevel=Integer.parseInt(strVal);
            //System.out.println("loglevel:"+logLevel);
            
        } catch (Throwable e) {
        }
        
        logger.info("SstagTimerLogLevel:"+logLevel);
        
        LOG_LEVEL=logLevel;
        LOG_MSEC=msec;
		*/
	}
	
	public static SstagTimerInfo start(Class cls,Map<?,?> sstagParams,HttpServletRequest request)
	{
		return null;
		/*
		if(LOG_LEVEL<=0)
		{
			return null;
		}
		
		SstagTimerInfo timerInfo=new SstagTimerInfo();
		timerInfo.url=request.getRequestURL().toString();
		timerInfo.startTime=new Date().getTime();
		timerInfo.cls=cls;
		timerInfo.sstagParams=sstagParams;
		return timerInfo;
		*/
	}
	
	public static void stop(SstagTimerInfo timerInfo)
	{
		return;
		/*
		if(timerInfo==null || LOG_LEVEL==LOG_LEVEL_NON)
		{
			return;
		}
		long endTime=new Date().getTime();
		long msec=endTime-timerInfo.startTime;
		
		if(msec<=LOG_MSEC)
		{
			return;
		}
		
		StringBuilder sb=new StringBuilder();
		if(LOG_LEVEL==LOG_LEVEL_DETAIL)
		{
			int i=0;
			for(Object name:timerInfo.sstagParams.keySet())
			{
				i++;
				Object value=timerInfo.sstagParams.get(name);
				sb.append("key_");
				sb.append(i);
				sb.append("|");
				sb.append(name);
				sb.append("|value|");
				sb.append(value.toString().replaceAll("\r\n|\n", "<Break>").replaceAll("\t", "<Tab>"));
				sb.append("|");
			}
		}
		else
		{
			sb.append("NoLogging");
		}
		
		String msg=MessageFormat.format("|SstagTimer|sstag|{0}|msec|{2}|url|{1}|param|{3}"
				, timerInfo.cls.getSimpleName()
				, timerInfo.url
				,""+msec
				,sb.toString()
				);
		
		logger.info(msg);
		
		//return msg;
		 
		 */
	}
	
	
	
	
	public static class SstagTimerInfo
	{
		public String url;
		public long startTime;
		public Class cls;
		public Map<?,?> sstagParams;
		
	}
	
	
	
	
	
}
