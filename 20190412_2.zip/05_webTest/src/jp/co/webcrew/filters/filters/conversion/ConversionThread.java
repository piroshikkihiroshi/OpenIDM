package jp.co.webcrew.filters.filters.conversion;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.ConversionMstDb;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.QueueThreadUtil;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;

/**
 * 各リクエストに対してポイントのチェックを行うthreadクラス。
 * 
 * @author kurinami
 */
public class ConversionThread extends QueueThreadUtil {

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.util.QueueThreadUtil#execute(java.lang.Object)
	 */
	protected void execute(HttpServletRequestCache request) throws Exception {

		int guid = ValueUtil.toint((String) request
				.getAttribute(UserInfo.GUID_ATTR_KEY));
		int ssid = ValueUtil.toint((String) request
				.getAttribute(UserInfo.SSID_ATTR_KEY));
		boolean formalFlag = ValueUtil
				.nullToStr(
						(String) request
								.getAttribute(UserInfo.MEMBER_MST_FORMAL_FLAG_ATTR_KEY))
				.equals("t");

		String url = (String) request.getRequestURL().toString();

		List conversionMstList = ConversionMstDb.getInstance()
				.getConversionMstList();

		for (int i = 0; i < conversionMstList.size(); i++) {
			Map element = (Map) conversionMstList.get(i);

			int convId = ((Integer) element.get("conv_id")).intValue();
			String userType = (String) element.get("user_type");
			boolean repeatFlag = ((Boolean) element.get("repeat_flag"))
					.booleanValue();
			boolean sameDayFlag = ((Boolean) element.get("same_day_flag"))
					.booleanValue();
			String urlType = (String) element.get("url_type");
			String convUrl = (String) element.get("conv_url");

			if (isMatch(url, convUrl)) {
				// 経過ページの場合、

				// 現在の経過状況から、次に経過するべきURLタイプを取得する。
				String currentUrlType = ConversionDb.getCurrentUrlType(ssid,
						convId);
				String nextUrlType = ConversionMstDb.getInstance()
						.getNextUrlType(convId, currentUrlType);

				// 次通過するべきページであり、かつ
				// 経過の条件を満たしている場合、
				if (urlType.equals(nextUrlType)
						&& isFulfill(convId, userType, repeatFlag, sameDayFlag,
								guid, formalFlag, ssid)) {

					if (!urlType.equals(ConversionMstDb.URL_TYPE_GOAL)) {
						// 成果達成URLでない場合、

						if (currentUrlType
								.equals(ConversionMstDb.URL_TYPE_NONE)) {
							// 未通過の場合、
							// 経過情報を挿入する。
							ConversionDb.insertConvProcess(ssid, convId,
									urlType);

						} else {
							// 経過ページを通過済みの場合、
							// 経過情報を更新する。
							ConversionDb.updateConvProcess(ssid, convId,
									urlType);
						}

					} else {
						// 成果達成URLの場合、

						// コンバージョン記録を書く。
						ConversionDb.insertConversionLog(guid, ssid, convId);

					}

				}
			}
		}

	}

	/**
	 * urlが一致しているかを判定する。 比較urlの最後が*で終わっていたら、前方一致、 そうでなければ、完全一致で比較する。
	 * 
	 * @param url
	 * @param targetUrl
	 * @return
	 */
	private boolean isMatch(String url, String targetUrl) {
		if (targetUrl.endsWith("*")) {
			targetUrl = targetUrl.substring(0, targetUrl.length() - 1);
			return url.startsWith(targetUrl);
		} else {
			return url.equals(targetUrl);
		}
	}

	/**
	 * ポイント付与の条件に適合するかを判定する。
	 * 
	 * @param convId
	 * @param userType
	 * @param repeatFlag
	 * @param sameDayFlag
	 * @param guid
	 * @param formalFlag
	 * @param ssid
	 * @return
	 * @throws SQLException
	 */
	private boolean isFulfill(int convId, String userType, boolean repeatFlag,
			boolean sameDayFlag, int guid, boolean formalFlag, int ssid)
			throws SQLException {

		// 新規登録ユーザのみのポイント付与なのに、登録済みユーザの場合、
		if (userType.equals(ConversionMstDb.USER_TYPE_NEW)
				&& formalFlag == true) {
			// 不適合とする。
			return false;
		}

		// 既登録ユーザのみのポイント付与なのに、未登録のユーザの場合、
		if (userType.equals(ConversionMstDb.USER_TYPE_REGISTED)
				&& formalFlag == false) {
			// 不適合とする。
			return false;
		}

		Set ssidSet = ConversionDb.getSsidSetOnConversionLog(guid, convId);

		// リピートNGなのに、既にポイント付与済みの場合、
		if (repeatFlag == false && ssidSet.size() > 0) {
			// 不適合とする。
			return false;
		}

		// 同一セッションNGのポイント付与なのに、同一セッションでポイント付与済みの場合、
		if (sameDayFlag == false && ssidSet.contains(new Integer(ssid))) {
			// 不適合とする。
			return false;
		}

		// 適合とする。
		return true;
	}
}
