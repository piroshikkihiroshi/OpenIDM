package jp.co.webcrew.phoenix.store.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * セッションストア情報を保持するbeanクラス。
 * 
 * @author kurinami
 */
public class SessionStoreBean implements Serializable {

    /** デフォルトシリアルバージョン */
    private static final long serialVersionUID = 1L;

    /** スコープ：short */
    public static final String SCOPE_SHORT = "0";

    /** スコープ：local */
    public static final String SCOPE_LOCAL = "1";

    /** スコープ：site */
    public static final String SCOPE_SITE = "2";

    /** スコープ：global */
    public static final String SCOPE_GLOBAL = "3";

    /** スコープ：login */
    public static final String SCOPE_LOGIN = "4";

    /** セッションストア情報を保持するmap */
    private Map<String, Map<String, Object>> storeMap = new HashMap<String, Map<String, Object>>();

    /**
     * コンストラクタ
     */
    public SessionStoreBean() {
        storeMap.put(SCOPE_SHORT, new HashMap<String, Object>());
        storeMap.put(SCOPE_LOCAL, new HashMap<String, Object>());
        storeMap.put(SCOPE_SITE, new HashMap<String, Object>());
        storeMap.put(SCOPE_GLOBAL, new HashMap<String, Object>());
        storeMap.put(SCOPE_LOGIN, new HashMap<String, Object>());
    }

    /**
     * セッションストア情報が存在しているかを返す。
     * 
     * @param keyName
     * @return
     */
    public boolean isExist(String keyName) {
        for (Map.Entry<String, Map<String, Object>> entry : storeMap.entrySet()) {
            if (entry.getValue().containsKey(keyName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * セッションストア情報を返す。
     * 
     * @param keyName
     * @return
     */
    public Object get(String keyName) {
        for (Map.Entry<String, Map<String, Object>> entry : storeMap.entrySet()) {
            if (entry.getValue().containsKey(keyName)) {
                return entry.getValue().get(keyName);
            }
        }
        return null;
    }

    /**
     * 指定された接頭辞で始まるキー値を持つ全てのセッションストア情報を返す。
     * 
     * @param prefix
     * @return
     */
    public Map<String, Object> getAll(String prefix) {
        Map<String, Object> all = new HashMap<String, Object>();
        for (Map.Entry<String, Map<String, Object>> entry : storeMap.entrySet()) {
            for (Map.Entry<String, Object> subEntry : entry.getValue().entrySet()) {
                if (subEntry.getKey().startsWith(prefix)) {
                    all.put(subEntry.getKey(), subEntry.getValue());
                }
            }
        }
        return all;
    }

    /**
     * セッションストア情報を設定する。
     * 
     * @param keyName
     * @param store
     */
    public void set(String keyName, Object store) {
        set(keyName, store, SCOPE_SHORT);
    }

    /**
     * セッションストア情報を設定する。
     * 
     * @param keyName
     * @param store
     * @param scope
     */
    public void set(String keyName, Object store, String scope) {
        for (Map.Entry<String, Map<String, Object>> entry : storeMap.entrySet()) {
            if (entry.getValue().containsKey(keyName)) {
                scope = entry.getKey();
                break;
            }
        }
        storeMap.get(scope).put(keyName, store);
    }

    /**
     * セッションストア情報を削除する。
     * 
     * @param keyName
     */
    public void remove(String keyName) {
        for (Map.Entry<String, Map<String, Object>> entry : storeMap.entrySet()) {
            if (entry.getValue().containsKey(keyName)) {
                entry.getValue().remove(keyName);
            }
        }
    }

    /**
     * どのスコープに格納されているかを返す。
     * 
     * @param keyName
     * @return
     */
    public String getScope(String keyName) {
        for (Map.Entry<String, Map<String, Object>> entry : storeMap.entrySet()) {
            if (entry.getValue().containsKey(keyName)) {
                return entry.getKey();
            }
        }
        return null;
    }
}
