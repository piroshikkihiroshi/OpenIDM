package jp.co.webcrew.filters.util;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.filters.replace.PointAdDb;


/**
 * ポイント広告関連の機能を使うためのutilクラス。
 * 
 * @author kurinami
 */
public class PointAdUtil {

  /** ロガー */
  private static final Logger log = Logger.getLogger(PointAdUtil.class);
  
  /**
   * 現在の日時をYYYYMMDDHH24MISS形式で取得する
   * 
   * @return
   */
  public static String getNowDate() {
    Calendar cal = Calendar.getInstance();
    
    int year   = cal.get(Calendar.YEAR);
    int month  = cal.get(Calendar.MONTH) + 1;
    int day    = cal.get(Calendar.DAY_OF_MONTH);
    int hour   = cal.get(Calendar.HOUR_OF_DAY);
    int minute = cal.get(Calendar.MINUTE);
    int second = cal.get(Calendar.SECOND);
    
    NumberFormat nf = new DecimalFormat("00");
    
    return String.valueOf(year) + nf.format(month) + nf.format(day) + nf.format(hour) + nf.format(minute) + nf.format(second);
  }
  
  /**
   * 検索開始年月日を取得
   * 
   * @param clickDate
   * @return
   */
  public static String getSearchStartDate(String clickDate) {
    return clickDate.substring(0, 8) + "000000";
  }
  
  /**
   * 検索終了年月日を取得
   * 
   * @param clickDate
   * @return
   */
  public static String getSearchEndDate(String clickDate) {
    return clickDate.substring(0, 8) + "235959";
  }
  
  /**
   * 同一日に広告をクリックしているかチェック
   * 
   * @param guid GUID
   * @param siteId サイトID
   * @param clickDate クリック年月日(YYYYMMDDHH24MISS)
   * @param adId 広告ID
   * @return true=クリックしている/false=クリックしていない
   */
  public static boolean isPointAdClicked(String guid, int siteId, String clickDate, String adId) {
    
    boolean isClicked = true;
    
    try {
      String searchStartDate = getSearchStartDate(clickDate);
      String searchEndDate   = getSearchEndDate(clickDate);
      
      int count = PointAdDb.getCountFromLog(guid, siteId, searchStartDate, searchEndDate, adId);
      if(count == 0) {
        isClicked = false;
      } else if(count == PointAdDb.POINT_AD_DB_ERROR) {
        log.error("poing_ad_click_logから件数を取得出来ませんでした");
      }
    } catch (SQLException e) {
      log.error("DBエラー", e);
    } catch (Exception e) {
      log.error("予期せぬエラー", e);
    }
    
    return isClicked;
  }

  /**
   * 広告のクリック上限数を取得する
   * 
   * @param adId 広告ID
   * @return
   */
  public static int getMaxClickCount(String adId) {
    
    int count = PointAdDb.POINT_AD_DB_ERROR;
    
    try {
      count = PointAdDb.getMaxCount(adId);
    } catch (SQLException e) {
      log.error("DBエラー", e);
    } catch (Exception e) {
      log.error("予期せぬエラー", e);
    }
    
    return count;
  }

  /**
   * クリック件数を取得する
   * 
   * @param adId 広告ID
   * @param siteId 場所ID
   * @return
   */
  public static int getClickCount(String adId, int siteId) {
    
    int count = PointAdDb.POINT_AD_DB_ERROR;
    
    try {
      count = PointAdDb.getCount(adId, siteId);
    } catch (SQLException e) {
      log.error("DBエラー", e);
    } catch (Exception e) {
      log.error("予期せぬエラー", e);
    }
    
    return count;
  }

  /**
   * ポイント数を取得する
   * 
   * @param adId
   * @return
   */
  public static int getPointAmount(String adId) {
    
    int amount = PointAdDb.POINT_AD_DB_ERROR;
    
    try {
      amount = PointAdDb.getAmount(adId);
    } catch (SQLException e) {
      log.error("DBエラー", e);
    } catch (Exception e) {
      log.error("予期せぬエラー", e);
    }
    
    return amount;
  }
}
