/**
 * 
 */
package jp.co.webcrew.login.common.util.twitter;

import twitter4j.Twitter;

/**
 * 直接Twitterクラスを利用すると、使う側のプロジェクトでTwitter4Jを入れないといけないので
 * このクラスを経由して利用する
 * @author shintaro.kurihara
 *
 */
public class TwitterBean{
	
	
	private Twitter twitter = null;
	

	public TwitterBean(Twitter twitter){
		this.setTwitter(twitter);
		
	}
	
	/**
	 * デフォルトコンストラクタ
	 *
	 */
	public Twitter getTwitter() {
		return twitter;
	}

	public void setTwitter(Twitter twitter) {
		this.twitter = twitter;
	}
	

}
