package jp.co.webcrew.filters.filters.replace.sstag;

import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.filters.replace.AdDb;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.QueueThreadUtil;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;

public class AdThread extends QueueThreadUtil {

	public static final String AD_THREAD_AD_ID_ATTR_KEY = "webcrew_ad_thread_ad_id";

	public static final String AD_THREAD_AD_WINDOW_ID_ATTR_KEY = "webcrew_ad_thread_ad_window_id";

	public static final String AD_THREAD_SPACE_ID_ATTR_KEY = "webcrew_ad_thread_space_id";

	protected void execute(HttpServletRequestCache request) throws Exception {

		String sessionId = (String) request
				.getAttribute(UserInfo.SSID_ATTR_KEY);
		int siteId = SiteMstDb.getInstance().getSiteId(
				request.getRequestURL().toString());
		String adId = (String) request.getAttribute(AD_THREAD_AD_ID_ATTR_KEY);
		int adWindowId = ((Integer) request
				.getAttribute(AD_THREAD_AD_WINDOW_ID_ATTR_KEY)).intValue();
		String spaceId = (String) request
				.getAttribute(AD_THREAD_SPACE_ID_ATTR_KEY);

		AdDb.insertImpressionLog(sessionId, siteId, adId, adWindowId, spaceId);

	}

}
