package jp.co.webcrew.filters.filters.replace.replacer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.filters.replace.htmlparser.HtmlReplaceParser;
import jp.co.webcrew.filters.filters.replace.htmlparser.LsCodeReplaceParserCallback;
import jp.co.webcrew.filters.util.httputil.CustomHttpServletResponse;

/**
 * <pre>
 *          クッキーが使えない環境のために
 *          html内の各リンクのリクエストパラメータに
 *          ローカルセッションコードを付与するReplacerクラス。
 * </pre>
 * 
 * @author kurinami
 */
public class LsCodeReplacer extends Replacer {

	/** ロガー */
	private static final Logger log = Logger.getLogger(LsCodeReplacer.class);

	/** 付与するローカルセッションコードを格納するための属性名 */
	public static final String REPLACE_LS_CODE_ATTR_KEY = "replace_ls_code";

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.Replacer#replace(java.lang.String,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String replace(String source, HttpServletRequest request,
			HttpServletResponse response) {

		log.debug("replace start.");

		String lsCode = (String) request.getAttribute(REPLACE_LS_CODE_ATTR_KEY);
		// ローカルセッションコードが取得できない場合は、置換しない。
		if (lsCode == null) {
			return source;
		}

		LsCodeReplaceParserCallback cb = new LsCodeReplaceParserCallback(lsCode);

		// リダイレクトが指定されている場合、Location:ヘッダにパラメータを追加。
		if (response instanceof CustomHttpServletResponse) {
			CustomHttpServletResponse customHttpServletResponse = (CustomHttpServletResponse) response;
			String location = customHttpServletResponse.getLocation();
			if (location != null) {
				location = LsCodeReplaceParserCallback.addParameter(location,
						lsCode);
				customHttpServletResponse.setLocation(location);
			}
		}

		// TODO kurinami 【未実装】metaタグに対応。

		String result = HtmlReplaceParser.parse(source, cb);

		log.debug("replace end.");
		return  result;
	}

}
