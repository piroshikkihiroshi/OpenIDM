﻿Imports CRMForm.DeclareCs
Imports System.Text 'stringbuilder用
Imports System.Management



Public Class commonFunc

    Function copyMain(ByRef InputAry_i, ByVal tgtStatus_i)

        Dim hwnd1 As IntPtr
        Dim ret As Long

        Dim objCmFn As New commonFunc

        hwnd1 = FindWindow("TMainForm", vbNullString)

        'ウィンドウが最小化されている場合は元に戻す
        If IsIconic(hwnd1) Then
            ret = ShowWindowAsync(hwnd1, SW_RESTORE)
        End If

        '画面を全面にする
        ret = SetForegroundWindow(hwnd1)


        '顧客王の深めのタイトルl_scrTabScrollBoxからテキストのハンドルを探す
        glTgtClassTitle = "l_scrTabScrollBox"
        ret = EnumChildWindows(hwnd1, AddressOf EnumWindowCallBack, 0)

        'テキストのハンドル(クラスTLEdit)をglTLEDITColに格納
        glTLEDITCol = New Collection
        glTgtClassTitle = "TLEdit"
        ret = EnumChildWindows(glTgtHndl, AddressOf EnumWindowCBByOpt, 0)

        'Dim tgtStatus_i As Long = 1
        Dim loopIdx As Long = 0
        Dim loopIdx2 As Long = 0

        If tgtStatus_i = 1 Then
            '逆順になるのでマックスから逆にする
            For loopIdx2 = MAX_ROW To 1 Step -1
                ret = SendMessage(glTLEDITCol.Item(loopIdx2), WM_ACTIVATE, 1, 0&)
                ret = SendMessage(glTLEDITCol.Item(loopIdx2), WM_SETTEXT, 0, CStr(InputAry_i(loopIdx)))
                If UBound(InputAry_i) = loopIdx Then
                    Exit For
                End If

                loopIdx = loopIdx + 1
            Next loopIdx2

        Else
            '略歴は100から始まる おそらく後ろのタブの下から1．２・・・となっている
            For loopIdx2 = HISTORY_ST_ROW To MAX_ROW Step -1
                ret = SendMessage(glTLEDITCol.Item(loopIdx2), WM_ACTIVATE, 1, 0&)
                ret = SendMessage(glTLEDITCol.Item(loopIdx2), WM_SETTEXT, 0, CStr(InputAry_i(loopIdx)))
                If UBound(InputAry_i) = loopIdx Then
                    Exit For
                End If

                loopIdx = loopIdx + 1
            Next loopIdx2
        End If


        'release
        glTLEDITCol = Nothing

        copyMain = 1

    End Function


    'タイトルからの検索用
    Function EnumWindowCallBack(ByVal hwnd As IntPtr, ByVal lParam As Long) As Long

        'ウィンドウのタイトルの長さを取得する
        Dim textLen As Integer = GetWindowTextLength(hwnd)
        If 0 < textLen Then
            'ウィンドウのタイトルを取得する
            Dim tsb As New StringBuilder(textLen + 1)
            GetWindowText(hwnd, tsb, tsb.Capacity)

            'ウィンドウのクラス名を取得する
            Dim csb As New StringBuilder(256)
            GetClassName(hwnd, csb, csb.Capacity)

            '結果を表示する
            'Debug.Print("クラス名:" & csb.ToString())
            'Debug.Print("タイトル:" & tsb.ToString())

            '対象のタイトルが見つかったらハンドルを格納して終了
            If tsb.ToString() = glTgtClassTitle Then
                glTgtHndl = hwnd
                EnumWindowCallBack = 0
                Exit Function
            End If

        End If

        EnumWindowCallBack = 1
    End Function


    'クラス名からの検索用
    Function EnumWindowClassBack(ByVal hwnd As IntPtr, ByVal lParam As Long) As Long

        'ウィンドウのタイトルの長さを取得する
        Dim textLen As Integer = GetWindowTextLength(hwnd)

        'ウィンドウのタイトルを取得する
        Dim tsb As New StringBuilder(textLen + 1)
        GetWindowText(hwnd, tsb, tsb.Capacity)

        'ウィンドウのクラス名を取得する
        Dim csb As New StringBuilder(256)
        GetClassName(hwnd, csb, csb.Capacity)

        '結果を表示する
        'Debug.Print("クラス名:" & csb.ToString())
        'Debug.Print("タイトル:" & tsb.ToString())

        '対象のクラス名が見つかったらハンドルを格納して終了
        If csb.ToString() = glTgtClassTitle Then
            glTgtHndl = hwnd
            EnumWindowClassBack = 0
            Exit Function
        End If


        EnumWindowClassBack = 1
    End Function


    '備考、略歴等専用
    Function EnumWindowCBByOpt(ByVal hwnd As IntPtr, ByVal lParam As Long) As Long

        'ウィンドウのタイトルの長さを取得する
        Dim textLen As Integer = GetWindowTextLength(hwnd)
        'If 0 < textLen Then
        'ウィンドウのタイトルを取得する
        Dim tsb As New StringBuilder(textLen + 1)
        GetWindowText(hwnd, tsb, tsb.Capacity)

        'ウィンドウのクラス名を取得する
        Dim csb As New StringBuilder(256)
        GetClassName(hwnd, csb, csb.Capacity)

        '結果を表示する
        'Debug.Print("クラス名:" & csb.ToString())
        'Debug.Print("タイトル:" & tsb.ToString())

        '対象のクラスが見つかったらハンドルを格納
        If csb.ToString() = glTgtClassTitle Then
            glTLEDITCol.Add(hwnd)
            EnumWindowCBByOpt = 0
        End If

        'End If

        EnumWindowCBByOpt = 1
    End Function


    Function searchTgtInfo(ByVal strTgtCode_i As String) As Long

        Dim hwnd1 As IntPtr
        Dim tgtHwnd As IntPtr
        Dim ret As Long

        Dim objCmFn As New commonFunc

        hwnd1 = FindWindow("TMainForm", vbNullString)

        If hwnd1 = 0 Then
            MessageBox.Show("顧客王を起動してください。")
            searchTgtInfo = -1
            Exit Function
        End If

        'ウィンドウが最小化されている場合は元に戻す
        If IsIconic(hwnd1) Then
            ret = ShowWindowAsync(hwnd1, SW_RESTORE)
        End If

        '画面を全面にする
        ret = SetForegroundWindow(hwnd1)

        '顧客コードを検索するボックスクラス(TREdit)のハンドルを探す
        glTgtClassTitle = "TREdit"
        ret = EnumChildWindows(hwnd1, AddressOf EnumWindowClassBack, 0)

        If ret = -1 Then
            ret = ShowWindowAsync(hwnd1, SW_SHOWMINIMIZED)
            MessageBox.Show("顧客カードを選択してください。")
            searchTgtInfo = -2
            Exit Function
        End If

        tgtHwnd = glTgtHndl

        '対象のコードを送り、検索
        ret = SendMessage(tgtHwnd, WM_ACTIVATE, 1, 0&)
        ret = SendMessage(tgtHwnd, WM_SETTEXT, 0, strTgtCode_i)
        ret = SendMessage(tgtHwnd, WM_KEYDOWN, VK_RETURN, 0&)

        searchTgtInfo = 0

    End Function

    Function checkCardAble() As Long  '顧客カードを検索可能な状態かチェック
        Dim hwnd1 As IntPtr
        Dim tgtHwnd As IntPtr
        Dim ret As Long

        Dim objCmFn As New commonFunc

        hwnd1 = FindWindow("TMainForm", vbNullString)

        If hwnd1 = 0 Then
            MessageBox.Show("顧客王を起動してください。")
            checkCardAble = -1
            Exit Function
        End If

        '顧客コードを検索するボックスクラス(TREdit)のハンドルを探す
        glTgtClassTitle = "TREdit"
        ret = EnumChildWindows(hwnd1, AddressOf EnumWindowClassBack, 0)

        If ret = -1 Then
            MessageBox.Show("顧客カードを選択してください。")
            checkCardAble = -2
            Exit Function
        End If

        tgtHwnd = glTgtHndl

        'アクティベートできるか確認
        ret = SendMessage(tgtHwnd, WM_ACTIVATE, 1, 0&)

        checkCardAble = 0

    End Function

    Function imporIni()
        Const DEF_STR As String = vbNullString
        Dim buffer As String = New String(" ", 1024) 'Spaceが1024文字
        Dim iniFileName As String = Application.StartupPath & "\" & INI_FILE 'INIファイル名
        Dim ret As Integer

        ret = GetPrivateProfileString( _
           "DB_SETTING", "TGT_SERVER_NAME", DEF_STR, buffer, buffer.Length, iniFileName _
           )
        TGT_SERVER_NAME = buffer.Substring(0, buffer.IndexOf(vbNullChar))

        ret = GetPrivateProfileString( _
           "DB_SETTING", "TGT_DB", DEF_STR, buffer, buffer.Length, iniFileName _
           )
        TGT_DB = buffer.Substring(0, buffer.IndexOf(vbNullChar))

        ret = GetPrivateProfileString( _
           "DB_SETTING", "TGT_USER", DEF_STR, buffer, buffer.Length, iniFileName _
           )
        TGT_USER = buffer.Substring(0, buffer.IndexOf(vbNullChar))

        ret = GetPrivateProfileString( _
           "DB_SETTING", "TGT_PASS", DEF_STR, buffer, buffer.Length, iniFileName _
           )
        TGT_PASS = buffer.Substring(0, buffer.IndexOf(vbNullChar))

        imporIni = 0

    End Function


    Function tgtDirGet() As String
        ' FolderBrowserDialog の新しいインスタンスを生成する (デザイナから追加している場合は必要ない)
        Dim FolderBrowserDialog1 As New FolderBrowserDialog()

        ' ダイアログの説明を設定する
        FolderBrowserDialog1.Description = "Excelファイルを出力するフォルダを選択してください。"

        ' ルートになる特殊フォルダを設定する (初期値 SpecialFolder.Desktop)
        'FolderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.MyComputer
        FolderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.Desktop

        ' 初期選択するパスを設定する
        'FolderBrowserDialog1.SelectedPath = "C:\Windows\"
        FolderBrowserDialog1.SelectedPath = System.Environment.SpecialFolder.Desktop

        ' [新しいフォルダ] ボタンを表示する (初期値 True)
        FolderBrowserDialog1.ShowNewFolderButton = True

        ' ダイアログを表示し、戻り値が [OK] の場合は、選択したディレクトリを表示する
        If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then

            tgtDirGet = FolderBrowserDialog1.SelectedPath
        Else
            tgtDirGet = ""
        End If

        'C直下対応
        If tgtDirGet = "C:\" Then
            tgtDirGet = "C:"
        End If

        ' 不要になった時点で破棄する (正しくは オブジェクトの破棄を保証する を参照)
        FolderBrowserDialog1.Dispose()

    End Function


    Function IsNumeric(ByVal stTarget As String) As Boolean
        Return Double.TryParse( _
            stTarget, _
            System.Globalization.NumberStyles.Any,
            Nothing, _
            0.0# _
        )
    End Function


    Function ProcKillMain() As Boolean


        'Dim startMsgStatus
        Dim strHanbaiName
        Dim strkokyakuName
        Dim proStatus
        Dim startMsgStatus As String

        'WMIにて使用する各種オブジェクトを定義・生成する。

        Dim oClassSet
        Dim oClass
        Dim oLocator
        Dim oService As New ManagementObjectSearcher()
        Dim sMesStr As String = ""
        Dim PrcSrc As ManagementObjectCollection


        startMsgStatus = MsgBox("顧客王を完全に終了してよろしいですか？" & vbCrLf & "(顧客王が起動しなくなった際に使用してください。)", vbYesNo + vbQuestion, "確認")
        If startMsgStatus = vbYes Then

            proStatus = 0

            ' --------------------------------------------------------------
            '    顧客王バージョンアップ時はサービス名の修正が必要。
            ' --------------------------------------------------------------
            strHanbaiName = "BridgeSvr18.exe"
            strkokyakuName = "SCL18.exe"

            'ローカルコンピュータに接続する。
            'oLocator = WScript.CreateObject("WbemScripting.SWbemLocator")
            'oService = oLocator.ConnectServer
            'クエリー条件をWQLにて指定する。
            oService.Query.QueryString = "Select * From Win32_Process"
            PrcSrc = oService.Get

            'コレクションを解析する。
            For Each oClass In PrcSrc
                sMesStr = sMesStr & oClass("Description") & ":" & oClass("ProcessId").ToString() & vbCrLf
                If strHanbaiName = oClass("Description") Then
                    oClass.Terminate()
                    proStatus = 1
                ElseIf strkokyakuName = oClass("Description") Then
                    oClass.Terminate()
                    proStatus = 1
                End If

            Next

            If proStatus = 1 Then
                MsgBox("顧客王を完全に終了しました。")
            Else
                MsgBox("顧客王は起動していませんでした。")
            End If


            '使用した各種オブジェクトを後片付けする。
            oClassSet = Nothing
            oClass = Nothing
            oService = Nothing
            oLocator = Nothing


        Else
            MsgBox("処理を中断します")
        End If

        Return False
    End Function

End Class
