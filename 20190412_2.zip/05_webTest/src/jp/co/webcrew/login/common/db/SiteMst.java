package jp.co.webcrew.login.common.db;


import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.DBException;
import jp.co.webcrew.login.common.db.util.Record;


/**
 * SITE_MSTテーブルを扱うクラス
 * 
 * @author Takahashi
 *
 */
public class SiteMst extends DBEntity {

	/** テーブル名 */
	public static final String TABLE = "SITE_MST"; 

	/*
	 * 列名定義
	 */
	public static final String SITE_ID      = "SITE_ID"; 
	public static final String SITE_NAME    = "SITE_NAME"; 
	public static final String STEP_FLAG    = "STEP_FLAG"; 
	public static final String INVALID_FLAG = "INVALID_FLAG"; 
	public static final String UP_DATETIME  = "UP_DATETIME"; 
	public static final String UP_ADMIN     = "UP_ADMIN"; 
	public static final String SITE_NAME_DISP     = "SITE_NAME_DISP"; 
	/** 成約サイトID */
	public static final String CONTRACT_SITE_ID     = "CONTRACT_SITE_ID"; 

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
	 */
	public void init(){
		setTable(TABLE);
	}

	
	/** 不可視 */
	private SiteMst(){
		super();
	}
	
	/**
	 * コンストラクタ
	 * @param siteId
	 */
	public SiteMst(String siteId){
		super();
		setSiteId(siteId);
	}
	
	public void setSiteId(String val){
		set (SITE_ID , val);
	}

	public final String getSiteId(){
		return get(SITE_ID);
	}
	
	/**
	 * サイトIDがSITE_MSTテーブルに存在するか否かを返す
	 * 
	 * true  存在する
	 * false 存在しない
	 * 
	 * @param db
	 * @param siteId
	 * @return
	 * @throws SQLException
	 */
	public static boolean contains (DBAccess db , String siteId) 
			throws SQLException {

		if (siteId == null || siteId.equals("")) {
			throw new DBException("引数が不正です：サイトIDが空です。");
		}
		
		String sql = "SELECT SITE_ID FROM SITE_MST WHERE SITE_ID=? AND INVALID_FLAG<>'1'";
		db.prepareStatement(sql);
		db.setString(1, siteId);
		Record rec = Record.getFirstRowOf(db);
		
		if (rec == null) {
			return false;
		} else {
			return true;
		}
		
	}

}
