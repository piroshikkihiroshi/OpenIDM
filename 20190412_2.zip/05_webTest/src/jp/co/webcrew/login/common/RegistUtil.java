package jp.co.webcrew.login.common;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.util.DateUtil;

public class RegistUtil {

//    /** ロガー */
//    private static final Logger log = Logger.getLogger(RegistUtil.class);

    
	/**
	 * <pre>
	 * 本登録において、会員マスタテーブルの更新処理を行う。
     * 
     * 2009.3.27 同時に、ワンタイムIDの書き込みも行う。
	 * 
	 * </pre>
	 * @param db
	 * @param member
	 * @throws SQLException
	 */
	public static void updateMemberMst(DBAccess db , MemberMst member ) throws SQLException{

		/*
		 * af_flgやpromo_codeなどを上書きしないよう注意する
		 */
		
		DBUpdater updater = new DBUpdater(member.getFullTableName());
		updater.addString(MemberMst.PASSWD, member.get(MemberMst.PASSWD));
		updater.addString(MemberMst.NICKNAME , member.get(MemberMst.NICKNAME));
		updater.addString(MemberMst.NAME1 , member.get(MemberMst.NAME1));
		updater.addString(MemberMst.NAME2 , member.get(MemberMst.NAME2));
		updater.addString(MemberMst.FURI1 , member.get(MemberMst.FURI1));

		updater.addString(MemberMst.FURI2 , member.get(MemberMst.FURI2));
		updater.addString(MemberMst.ZIP , member.get(MemberMst.ZIP));
		updater.addString(MemberMst.PREF_ID , member.get(MemberMst.PREF_ID));
		updater.addString(MemberMst.ADDR1 , member.get(MemberMst.ADDR1));
		updater.addString(MemberMst.ADDR2 , member.get(MemberMst.ADDR2));

		updater.addString(MemberMst.ADDR3 , member.get(MemberMst.ADDR3));
		updater.addString(MemberMst.ADDR4 , member.get(MemberMst.ADDR4));
		updater.addString(MemberMst.ADDR5 , member.get(MemberMst.ADDR5));
		updater.addString(MemberMst.BIRTHDAY , member.get(MemberMst.BIRTHDAY));
		updater.addString(MemberMst.SEX_ID , member.get(MemberMst.SEX_ID));

		updater.addString(MemberMst.TEL , member.get(MemberMst.TEL));
		updater.addString(MemberMst.MOBILE , member.get(MemberMst.MOBILE));
		updater.addString(MemberMst.COMPANY , member.get(MemberMst.COMPANY));
		updater.addString(MemberMst.CP_TEL , member.get(MemberMst.CP_TEL));
		updater.addString(MemberMst.CP_ZIP , member.get(MemberMst.CP_ZIP));

		updater.addString(MemberMst.CP_PREF_ID , member.get(MemberMst.CP_PREF_ID));
		updater.addString(MemberMst.CP_ADDR1 , member.get(MemberMst.CP_ADDR1));
		updater.addString(MemberMst.CP_ADDR2 , member.get(MemberMst.CP_ADDR2));
		updater.addString(MemberMst.CP_ADDR3 , member.get(MemberMst.CP_ADDR3));
		updater.addString(MemberMst.CP_ADDR4 , member.get(MemberMst.CP_ADDR4));

		updater.addString(MemberMst.CP_ADDR5 , member.get(MemberMst.CP_ADDR5));
		updater.addString(MemberMst.COP_FLAG , member.get(MemberMst.COP_FLAG));
		updater.addString(MemberMst.CONSORT , member.get(MemberMst.CONSORT));
		updater.addString(MemberMst.CHILDREN , member.get(MemberMst.CHILDREN));
		updater.addString(MemberMst.PARENT , member.get(MemberMst.PARENT));

		updater.addString(MemberMst.INCOME_KBN , member.get(MemberMst.INCOME_KBN));

		// サイトIDが設定されている時だけ上書きする。
		String siteId = ValueUtil.nullToStr(member.get(MemberMst.SITE_ID));
		if (! siteId.equals("")) updater.addString(MemberMst.SITE_ID, siteId);
//del 080425 メルマガ管理方法変更--
//		updater.addString(MemberMst.MAG_FLAG , member.get(MemberMst.MAG_FLAG));
//--
		updater.addString(MemberMst.FORMAL_FLAG , member.get(MemberMst.FORMAL_FLAG));
		updater.addString(MemberMst.LIMIT_DATETIME , member.get(MemberMst.LIMIT_DATETIME));
		updater.addString(MemberMst.UP_DATETIME , DateUtil.currentDateTime());

// add 080520 メール種別やメールアドレスを本登録処理で上書きするよう変更 --
		
		// データが指定されていた場合は、メール種別やメールアドレスを上書きする
		String pc_mail = member.get(MemberMst.EMAIL);
		String mb_mail = member.get(MemberMst.MB_MAIL);
		String cp_mail = member.get(MemberMst.CP_MAIL);
		String primary = member.get(MemberMst.PRIMARY_EMAIL);
		
		if (! pc_mail.equals("") || ! mb_mail.equals("") ||  ! cp_mail.equals("")) {
			// メールアドレスが呼び出し元で指定されていて、かつ、メール種別が指定されているときは、DBを上書きする
			if (! primary.equals("")) {
				updater.addString(MemberMst.EMAIL         , pc_mail);
				updater.addString(MemberMst.MB_MAIL       , mb_mail);
				updater.addString(MemberMst.CP_MAIL       , cp_mail);
				updater.addString(MemberMst.PRIMARY_EMAIL , primary);
			}
		} else {
			// データに不備がある場合は、何も触らない
		}
		
//--
        // Issue0039056より　生活情報項目追加
		updater.addString(MemberMst.HOUSE_TYPE_ID , member.get(MemberMst.HOUSE_TYPE_ID));
		updater.addString(MemberMst.SUMAI_KEITAI_CODE , member.get(MemberMst.SUMAI_KEITAI_CODE));
		updater.addString(MemberMst.CAR_MAKER_NAME_DISP , member.get(MemberMst.CAR_MAKER_NAME_DISP));
		updater.addString(MemberMst.CAR_SHASHU_NAME_DISP , member.get(MemberMst.CAR_SHASHU_NAME_DISP));
		updater.addString(MemberMst.CAR_KATASHIKI_NAME , member.get(MemberMst.CAR_KATASHIKI_NAME));
		updater.addString(MemberMst.SHODO_TOROKU_NENGETSU , member.get(MemberMst.SHODO_TOROKU_NENGETSU));
		updater.addString(MemberMst.HAVE_BIKE , member.get(MemberMst.HAVE_BIKE));

		updater.setCond("WHERE GUID=?");
		updater.addCondString(member.get(MemberMst.GUID));
		
		updater.update(db);
        
        
        insertOnetimeMst(db , member);

	}

    private static void insertOnetimeMst(DBAccess db , MemberMst member) throws SQLException{
        String sql = "INSERT INTO ONETIME_MST "
                +   "(GUID , ONETIME_ID , EMAIL , MK_DATETIME) "  
                +   "VALUES "  
                +   "(? , ? , ? , TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS')) ";
        
        db.prepareStatement(sql);
        
        String oneTimeId    = ValueUtil.nullToStr(MemberMst.createOneTimeId (member.get(MemberMst.GUID)));

        int i= 0;
        db.setString(++i , member.getGuid());
        db.setString(++i , oneTimeId);
        db.setString(++i , member.getPrimaryEmail());
        
        db.executeUpdate();
    
    }
    
    
    
    /**
     * <pre>
     * guidを元にワンタイムＩＤを生成して返す。
     * 
     * 生成に失敗した場合はnullを返す。
     * 
     * </pre>
     * @param guid
     * @return
     */
    public static String createOneTimeId (String guid) {
        return MemberMst.createOneTimeId (guid);
    }


}
