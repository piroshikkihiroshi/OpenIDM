package jp.co.webcrew.filters.filters.replace.htmlparser;

/**
 * html解析用のcallbackクラスの雛形
 * 
 * @author kurinami
 */
abstract public class HtmlReplaceParserCallback {

	/**
	 * <pre>
	 * html上にコメント部分があったときに呼び出される。
	 * 置換後のコメントを戻り値として返す。
	 * </pre>
	 * 
	 * @param data コメント文字列(<!-- -->部分を含む)
	 * @return 置換後のコメント部分
	 */
	public String handleComment(String data) {
//		System.out.println("comment: " + data);
		return data;
	}
	
	/**
	 * <pre>
	 * html上に開始タグがあったときに呼び出される。
	 * 置換後の開始タグを戻り値として返す。
	 * </pre>
	 * 
	 * @param data 開始タグ(< >部分を含む)
	 * @return 置換後の開始タグ
	 */
	public String handleStartTag(String data) {
//		System.out.println("start tag: " + data);
		return data;
	}
	
	/**
	 * <pre>
	 * html上に終了タグがあったときに呼び出される。
	 * 置換後の終了タグを戻り値として返す。
	 * </pre>
	 * 
	 * @param data 終了タグ(< >部分を含む)
	 * @return 置換後の終了タグ
	 */
	public String handleEndTag(String data) {
//		System.out.println("end tag: " + data);
		return data;
	}
	
    /**
     * <pre>
     * html上に単体タグがあったときに呼び出される。
     * 置換後の単体タグを戻り値として返す。
     * </pre>
     * 
     * @param data 単体タグ(< >部分を含む)
     * @return 置換後の単体タグ
     */
	public String handleSimpleTag(String data) {
//      System.out.println("simple tag: " + data);
        return data;
	}
	
	/**
	 * <pre>
	 * html上にテキストがあったときに呼び出される。
	 * 置換後のテキストを戻り値として返す。
	 * </pre>
	 * 
	 * @param data テキスト
	 * @return 置換後のテキスト
	 */
	public String handleText(String data) {
//		System.out.println("text: " + data);
		return data;
	}
	
	/**
	 * <pre>
	 * 最終的なチェックを行い必要であれば、メッセージを返す。
	 * </pre>
	 * 
	 * @return
	 */
	public String finalCheck() {
	    return "";
	}
}
