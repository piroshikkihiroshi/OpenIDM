package jp.co.webcrew.filters.filters.session;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.db.TermMstDb;

/**
 * リクエスト属性に格納する値を保持するクラス。 
 * 
 * @author kurinami
 */
public class UserInfo {

	private static final String SSID_SEQ = "SELECT tonashiba.seq_ssid.nextval AS ssid FROM dual";
	
	/** リクエスト属性の格納する場合のprefix */
	public static final String PREFIX = "faon.";

	/** サイトセッションプロパティ用の中間prefix */
	public static final String SS_PROPS = PREFIX + "ss_props.";

	/** 属性名：ユーザID */
	public static final String GUID_ATTR_KEY = PREFIX + "guid";

	/** 属性名：グローバルセッションID */
	public static final String GSID_ATTR_KEY = PREFIX + "gsid";

	/** 属性名：グローバルセッションコード */
	public static final String GS_CODE_ATTR_KEY = PREFIX + "gs_code";

	/** 属性名：サイトセッションID */
	public static final String SSID_ATTR_KEY = PREFIX + "ssid";

	/** 属性名：ローカルセッションコード */
	public static final String LS_CODE_ATTR_KEY = PREFIX + "ls_code";

	/** 属性名：ログイン済みフラグ */
	public static final String LOGIN_FLAG_ATTR_KEY = PREFIX + "login_flag";
	
	/** 属性名：携帯フラグ */
	public static final String MOBILE_FLAG_ATTR_KEY = PREFIX + "mobile_flag";
	
	/** 会員マスタ用の中間prefix */
	public static final String MEMBER_MST = PREFIX + "member_mst.";

	/** 属性名：ニックネーム */
	public static final String MEMBER_MST_NICKNAME_ATTR_KEY = MEMBER_MST + "nickname";

	/** 属性名：正式登録済みフラグ */
	public static final String MEMBER_MST_FORMAL_FLAG_ATTR_KEY = MEMBER_MST + "formal_flag";

	/** 属性名：サイトID */
	public static final String SITE_ID_ATTR_KEY = PREFIX + "site_id";

	/** 属性名：サイトサブ番号値 */
	public static final String SITE_SUB_NUM_ATTR_KEY = PREFIX + "site_sub_num";

	/** 属性名：プロモーションコード */
	public static final String SITE_SESSION_PROMO_CODE_ATTR_KEY = PREFIX + "site_session.promo_code";
	
	/** 属性名：アフィリエイトコード */
	public static final String SITE_SESSION_AF_CODE_ATTR_KEY = PREFIX + "site_session.af_code";

	/** 属性名：端末キャリア */
	public static final String SITE_MST_CARRIER_ATTR_KEY = PREFIX + "term_mst.carrier";

	/** 属性名：端末種別 */
	public static final String SITE_MST_TERM_TYPE_ATTR_KEY = PREFIX + "term_mst.term_type";

	/** クローラ用のユーザ情報に割り当てるID */
	public static final String CRAWLER_ID = "0";

	/** ユーザID */
	private String guid = "";

	/** グローバルセッションID */
	private String gsid = "";

	/** グローバルセッションコード */
	private String gsCode = "";

	/** サイトセッションID */
	private String ssid = "";

	/** ローカルセッションコード */
	private String lsCode = "";

	/** ログイン済みフラグ */
	private boolean loginFlag = false;
	
	/** プロモーションコード */
	private String promoCode = "";

	/** アフィリエイトコード */
	private String afCode = "";
	
	/** 端末キャリア */
	private String carrier = "";

	/** 端末種別 */
	private String termType = "";

	/**
	 * クローラ用のユーザ情報を返す。
	 * 
	 * @return
	 */
	public static UserInfo getCrawlerUserInfo() {
		UserInfo userInfo = new UserInfo();
		userInfo.guid = CRAWLER_ID;
		userInfo.gsid = CRAWLER_ID;
		userInfo.ssid = CRAWLER_ID;
		return userInfo;
	}
	
	/**
	 * 認証サーバ対象外のユーザ情報
	 * 
	 * @return
	 */
	public static UserInfo getNoAuthUserInfo() throws Exception {
		UserInfo userInfo = new UserInfo();
		userInfo.guid = CRAWLER_ID;
		userInfo.gsid = CRAWLER_ID;
		userInfo.ssid = getSSidSeq();
		
		return userInfo;
	}
	
	private static String getSSidSeq() throws Exception
	{
		DBAccess db  = null;
		ResultSet rs = null;
		try
		{
			db = new DBAccess();
			rs = db.executeQuery(SSID_SEQ);
			if (rs.next())
			{
				return rs.getString("ssid");
			}
			return "0";
		} finally
		{
			DBAccess.close(db);
			DBAccess.close(rs);
		}
	}

	/**
	 * ユーザ情報をアプリから見えるようにリクエストスコープに格納する。
	 * 
	 * @param request
	 * @throws SQLException
	 */
	public void setUserInfoToRequest(HttpServletRequest request)
			throws SQLException {

		Iterator i = null; 
		
		// それぞれの属性を格納する。
		request.setAttribute(GUID_ATTR_KEY, guid);
		request.setAttribute(GSID_ATTR_KEY, gsid);
		request.setAttribute(GS_CODE_ATTR_KEY, gsCode);
		request.setAttribute(SSID_ATTR_KEY, ssid);
		request.setAttribute(LS_CODE_ATTR_KEY, lsCode);
		request.setAttribute(LOGIN_FLAG_ATTR_KEY, loginFlag ? "t"
				: "f");
		request.setAttribute(MOBILE_FLAG_ATTR_KEY, TermMstDb.isMobileCarrier(carrier) ? "t" : "f");
		
		Map siteInfo = SiteMstDb.getInstance().getSiteInfo(request.getRequestURL().toString());
		request.setAttribute(SITE_ID_ATTR_KEY, siteInfo.get("site_id").toString());
		request.setAttribute(SITE_SUB_NUM_ATTR_KEY, siteInfo.get("sub_num").toString());
		
		request.setAttribute(SITE_SESSION_PROMO_CODE_ATTR_KEY, promoCode);
		request.setAttribute(SITE_SESSION_AF_CODE_ATTR_KEY, afCode);

		request.setAttribute(SITE_MST_CARRIER_ATTR_KEY, carrier);
		request.setAttribute(SITE_MST_TERM_TYPE_ATTR_KEY, termType);

		// サイトセッションプロパティを格納する。
		Map siteSessionProps = MemberMstDb.getSiteSessionProps(ssid);
		i = siteSessionProps.keySet().iterator();
		while (i.hasNext()) {
			String key = (String) i.next();
			request.setAttribute(SS_PROPS + key, 
					(siteSessionProps.get(key)==null ? "" : siteSessionProps.get(key)));
		}

		// 会員マスタを格納する。
		Map memberMst = MemberMstDb.getMemberMst(guid);
		i = memberMst.keySet().iterator();
		while (i.hasNext()) {
			String key = (String) i.next();
			
			// パスワード以外を格納する。
			if(!key.equals("passwd")) {
				String value = (String) memberMst.get(key);

				// フラグはt/fで格納する。
				if (key.endsWith("_flag")) {
					value = value.equals("1") ? "t" : "f";
				}

				request.setAttribute(MEMBER_MST + key, value);
			}
		}

	}

	/**
	 * ユーザ情報をDBのレコードから取得して属性に格納する。
	 * 
	 * @param rs
	 * @throws SQLException
	 */
	public void setUserInfoFromDb(ResultSet rs) throws SQLException {
		guid = ValueUtil.nullToStr(rs.getString("guid"));
		gsid = ValueUtil.nullToStr(rs.getString("gsid"));
		gsCode = ValueUtil.nullToStr(rs.getString("gs_code"));
		ssid = ValueUtil.nullToStr(rs.getString("ssid"));
		lsCode = ValueUtil.nullToStr(rs.getString("ls_code"));
		loginFlag = rs.getBoolean("login_flag");

		promoCode = ValueUtil.nullToStr(rs.getString("site_session_promo_code"));
		afCode = ValueUtil.nullToStr(rs.getString("site_session_af_code"));

		carrier = ValueUtil.nullToStr(rs.getString("carrier"));
		termType = ValueUtil.nullToStr(rs.getString("term_type"));
	}

	// 以下アクセッサ

	public String getAfCode() {
		return afCode;
	}

	public void setAfCode(String afCode) {
		this.afCode = afCode;
	}

	public String getCarrier() {
		return carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public String getGsCode() {
		return gsCode;
	}

	public void setGsCode(String gsCode) {
		this.gsCode = gsCode;
	}

	public String getGsid() {
		return gsid;
	}

	public void setGsid(String gsid) {
		this.gsid = gsid;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public boolean isLoginFlag() {
		return loginFlag;
	}

	public void setLoginFlag(boolean loginFlag) {
		this.loginFlag = loginFlag;
	}

	public String getLsCode() {
		return lsCode;
	}

	public void setLsCode(String lsCode) {
		this.lsCode = lsCode;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public String getSsid() {
		return ssid;
	}

	public void setSsid(String ssid) {
		this.ssid = ssid;
	}

	public String getTermType() {
		return termType;
	}

	public void setTermType(String termType) {
		this.termType = termType;
	}
	
}
