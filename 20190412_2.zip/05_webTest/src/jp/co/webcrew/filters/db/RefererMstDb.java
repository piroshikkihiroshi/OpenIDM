package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * リファラとプロモーションIDを管理するdbクラス。
 * 
 * @author kurinami
 */
public class RefererMstDb extends RefreshMstDb {

	/** リファラ一覧取得用SQL */
	private static final String REFERER_MST_SELECT = "select * from referer_mst where invalid_flag = '0' order by case when referer is null then ' ' else referer end desc";

	/** 唯一のインスタンス */
	private static RefererMstDb refererMstDb = new RefererMstDb();

	/** リファラとプロモーションIDの一覧 */
	private List refererList = null;

	/**
	 * 生成不能コンストラクタ
	 */
	private RefererMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static RefererMstDb getInstance() {
		return refererMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			List refererList = new ArrayList();

			// サイト情報一覧を検索する。
			rs = dbAccess.executeQuery(REFERER_MST_SELECT);
			while (dbAccess.next(rs)) {
				Map element = new HashMap();
				element.put("promo_code", ValueUtil.nullToStr(rs
						.getString("promo_code")));
				element.put("referer", ValueUtil.nullToStr(rs
						.getString("referer")));

				refererList.add(element);
			}

			this.refererList = refererList;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * リファラを元にプロモーションコードを返す。
	 * 
	 * @param id
	 * @param referer
	 * @return
	 */
	public String getPromoCode(String id, String referer) {

		// IDが指定された場合、それをプロモーションコードとする。
		if (ValueUtil.nullToStr(id).length() > 0) {
			return id;
		}

		List refererList = this.refererList;

		for (int i = 0; i < refererList.size(); i++) {
			Map element = (Map) refererList.get(i);

			if (referer.startsWith((String) element.get("referer"))) {
				return (String) element.get("promo_code");
			}
		}

		return "";
	}

}
