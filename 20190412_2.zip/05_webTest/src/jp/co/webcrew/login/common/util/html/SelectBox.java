package jp.co.webcrew.login.common.util.html;

import java.io.Serializable;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;

import jp.co.webcrew.login.common.util.StringUtil;


public class SelectBox implements Serializable {
	private String _name;	 // フォーム名
	private List _data = new ArrayList();	 // 連想配列
	private String _selectedVal = "" ;  // 選択値
//	private String _javascript;   // JavaScript
	private ValueBean _topData;   // 一行目のデータ

	public SelectBox(){
		
	}
	/**
	 * コンストラクタ
	 * @access    public
	 * @param     String    $name   
	 * @param     Array     $arr    連想配列 ('val'->'displayName')
	 */
	public SelectBox(String name) {
		setName(name);
	}

	public void setName(String val) {
		_name = val;
	}

	public void setData(List list) {
		_data = list;
	}
	
	public void setSelectedVal(String val) {
		_selectedVal = val;
	}

	public String getSelectedVal() {
		return _selectedVal;
	}
	
	public void selectVal(String val) {
		setSelectedVal(val);
	}

	public void setTopData(String value , String display) {
		_topData = new ValueBean(value,display);
	}

	public void addData(String value , String display) {
		getData().add(new ValueBean(value,display));
	}

	public void  setFirstRow(String value, String display) {
		setTopData(value , display);
	}

	public ValueBean getTopData(){
		return _topData;
	}
	public List getData() {
		return _data;
	}

//	function display() {
//		echo $this->tag();
//	}
	

	public String  getTag() {
		StringBuffer tag = new StringBuffer();
		tag.append("\n<select name=\"");
		tag.append(_name);
		tag.append("\">\n");

		ValueBean top = getTopData();
		if (top != null) {
			String topVal = top.getValue();
			String topDisplay = top.getDisplay();			
			if (_selectedVal != null && _selectedVal.equals(topVal)) {
				tag.append("<option value=\"" + StringUtil.sanitize(topVal) + "\" selected>" + StringUtil.sanitize(topDisplay) + "</option>\n");
			} else {
				tag.append("<option value=\"" + StringUtil.sanitize(topVal) + "\" >" + StringUtil.sanitize(topDisplay) + "</option>\n");
			}
		}

		
		
		List rows = getData();
		if (rows.size() <= 0 ){
			return tag.toString();
		}

		for (Iterator it = rows.iterator() ; it.hasNext();) {
			ValueBean v =  (ValueBean)it.next();
			String val = v.getValue();
			String display = v.getDisplay();
			tag.append("	<option value=\"" + StringUtil.sanitize(val) + "\"");
			if(_selectedVal != null && val.equals(_selectedVal) ){
				tag.append(" selected");
			}
			tag.append(">");
			tag.append(StringUtil.sanitize(display));
			tag.append("</option>\n");
		}
		tag.append("</select>\n");
		return tag.toString();
	}
	
	

	public class ValueBean implements Serializable {
		public ValueBean(){
		}
		public ValueBean(String value , String display){
			_value = value;
			_display = display;
		}
		
		String _value;
		String _display;

		public String getValue(){
			return _value;
		}
		public String getDisplay(){
			return _display;
		}
		
		public void setValue(String val){
			_value = val;
		}
		
		public void setDisplay(String val){
			_display = val;
		}
		
		
	}

	public String getHtml(){
		return getTag();
	}
	
/*
 	public String getDisplayVal(String val) {
		if (getTopData() != null) {
			
		}
		List valList = getData();
		for (Iterator it = valList.iterator();it.hasNext();) {
			ValueBean bean = (ValueBean)it.next();
			if ( bean._value.equals(val) ) {
				return bean._display;
			}
		}
		return "";
	}
*/
	public Map getDisplayMap() {
		Map displays = new HashMap();
		displays.put("",""); //値が設定されていない場合のための対策
		
		ValueBean top = getTopData();
		if (getTopData() != null) {
			displays.put(top._value,top._display);
		}
		
		List valList = getData();
		for (Iterator it = valList.iterator();it.hasNext();) {
			ValueBean bean = (ValueBean)it.next();
			String val = bean._value;
			String display = bean._display;
			displays.put(val,display);
		}
		return displays;
	}
	
	/**
	 * 選択値に対応した表示値を求める。主に確認画面で使用する。
	 * 
	 * ただし、先頭に無回答データ（選択催促用データ）が挿入されている場合、
	 * その値が無回答を意味する値として渡ってくることがある。
	 * 
	 * その「無回答値（noAnswerVal）」に対しては、セレクタの表示文字列ではなく、
	 * 空文字を返す。
	 * 
	 * 選択値に対応した表示値が無い場合も、空文字を返す。
	 * 
	 * @param val
	 */
	public String getDisplay( String val ) {

		if (val == null) val = "";

		// 一行目に挿入した無効値の値を取得
		String noAnswerVal = getNoAnswerVal();

		if (val.equals(noAnswerVal)) {
			return "";
		}
		
		
		String disp = (String)getDisplayMap().get(val);
		if (disp == null) {
			disp = "";
		}
		return disp;
	}

	/**
	 * 選択された値の表示値を取得する。
	 * 
	 * ただし、無回答値が選択されている場合は、空文字を返す。
	 *  
	 * @return
	 */
	public String getSelected() {
		return getDisplay(getSelectedVal());
	}
	
	/**
	 * 無回答値を取得する
	 * 
	 * @return
	 */
	public String getNoAnswerVal() {
		ValueBean topData = getTopData();
		if (topData == null) {
			return "";
		} else {
			return topData.getValue();
		}
	}	

} 
