package jp.co.webcrew.dbaccess.db;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.perflog.PerfLogger;

/**
 * 汎用DB用のDBクラス。
 *
 * @author kurinami
 */
public class DBAccess {

    /** ロガー */
    private static final Logger log = Logger.getLogger(DBAccess.class);

    /** コネクション名 */
    private String _name = "";

    /** 内部保持接続 */
    private Connection _conn = null;

    /** 内部保持PreparedStatement */
    private PreparedStatement _pstmt = null;

    /** パラメータ一覧(ログ出力用) */
    private List _paramList = new ArrayList();

    /** パラメータsql(ログ出力用) */
    private String _sql = "";

    /** 処理中にsqlエラーが発生したかを表すフラグ */
    private boolean _hasSqlError = false;

    /**
     * 呼び出しもとのクラス名を返す。
     *
     * @return
     */
    public static String getCallClassname() {

		try {
			Exception e = new Exception();

			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);

			StringReader sr = new StringReader(sw.toString());
			BufferedReader br = new BufferedReader(sr);
			br.readLine();
			br.readLine();
			br.readLine();

			return br.readLine().trim();

		} catch (Exception e) {
			log.error("呼び出し元クラス名取得失敗", e);
			return "(クラス名取得失敗)";
		}

	}

    /**
     * デフォルトコンストラクタ
     *
     * @throws SQLException
     */
    public DBAccess() throws SQLException {
    	this("");
    }



    /**
	 * コンストラクタ
	 *
	 * プールからコネクションを取得して、コネクションを AutoCommit=ON 状態にしておく また日付フォーマットがデフォルトだと変な形式なので
	 * YYYY-MM-DD に変更しておく。 ちなみにプールから取得されるコネクションは、正しくサーバに接続されていることが
	 * テスト済みではあるが、その後にエラーが発生する可能性はあるので 100%エラーがない とは限らない。
	 *
	 * @throws SQLException
	 */
    public DBAccess(String name) throws SQLException {

    	_name = name;

        log.debug( "DBAccess 呼び出し元クラス[" + getCallClassname() + "]");

        PerfLogger.sqlGetConn_Start(this.getClass());
       // ----- コネクションをプールから取得
        _conn = DBConnectionFactory.getConnection(name);
        PerfLogger.sqlGetConn_End(this.getClass());

        // ----- 2007.12.06 auto commit の初期化
        try {
           // ----- まず commit しておく(念のため）
//            _conn.commit();

           // ----- そのあと autocmiit 状態にする
            _conn.setAutoCommit(true);

        } catch ( Exception e ){
            log.error( "auto commit 状態の初期化がエラーになりました", e);
            e.printStackTrace();
            return;
        }
        DBAccessCloseChecker.doCheck(this);

// 08.07.18 日付フォーマット削除 --
//        // ----- 2007.10.17 暫定 日付フォーマットの設定
//        try {
//           Statement stmt = _conn.createStatement();
////            String sql = "alter session set NLS_DATE_FORMAT = 'DD-MON-RR'";
////           String sql = "alter session set NLS_DATE_FORMAT = 'YYYY-MM-DD'";
////           log.info( "日付フォーマット設定: " + sql );
//           stmt.executeUpdate( sql );
//           stmt.close();
//        } catch ( Exception e ){
//            e.printStackTrace();
//            log.error( "alter session できませんでした", e);
//            return;
//        }
// --
    }

    /**
     * コンストラクタ
     *
     * 2011/08/24 追加　
     * メソッド追加の理由はDBAccess(String,boolean)を参照ください。
     *
     * @param applyCommit true:commit/setautocommit(false)を適用 false:commit/setautocommit(false)を適用しない
     * @throws SQLException
     */
    public DBAccess(boolean applyCommit) throws SQLException
    {
    	this("",applyCommit);
    }


    /**
	 * コンストラクタ
     *
     * 2011/08/24 追加　
     * 既存のコンストラクタの仕様（強制コミット）だと、
     *
     * 1)呼び出し元でトランザクションを開始
     * 2)呼び出し先（サブルーチン側）でDBAccessオブジェクトを作成しただけで、トランザクションが勝手にコミットされてしまう。
     *
     * 結果、呼び出し元で管理しているはずのトランザクションの一貫性が無効になってしまう恐れがある。
     * この問題を回避するために新たにコンストラクタを追加した。
     *
     * 既存のコンストラクタのうち、デフォルトコンストラクタと文字列のみを受け取るコンストラクタは非推奨オプションを付けた。
     * 共通機能のデグレを起こさないために、既存のコンストラクタは@deprecatedを付ける以外は一切触っていない。
     *
	 * @param name 接続名
     * @param applyCommit true:commit/setautocommit(false)を適用 false:commit/setautocommit(false)を適用しない
	 * @throws SQLException
	 */
    public DBAccess(String name,boolean applyCommit) throws SQLException
    {

    	_name = name;

        log.debug( "DBAccess 呼び出し元クラス[" + getCallClassname() + "]");

        PerfLogger.sqlGetConn_Start(this.getClass());
       // ----- コネクションをプールから取得
        _conn = DBConnectionFactory.getConnection(name);
        PerfLogger.sqlGetConn_End(this.getClass());

        if(!applyCommit)
        {
        	return;
        }
        // ----- 2007.12.06 auto commit の初期化
        try {
           // ----- まず commit しておく(念のため）
            _conn.commit();

           // ----- そのあと autocmiit 状態にする
            _conn.setAutoCommit(true);

        } catch ( Exception e ){
            log.error( "auto commit 状態の初期化がエラーになりました", e);
            e.printStackTrace();
            return;
        }
        DBAccessCloseChecker.doCheck(this);

    }


    /**
     * バッチ処理用にプーリングを使わない版のコンストラクタ。
     *
     * @param conn
     */
    public DBAccess(Connection conn) {
    	_conn = conn;
    }

    /**
     * autoCommitを設定する。
     *
     * @param autoCommit
     * @throws SQLException
     */
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        try {
            _conn.setAutoCommit(autoCommit);
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * autoCommitの値を返す。
     *
     * @return
     * @throws SQLException
     */
    public boolean getAutoCommit() throws SQLException {
        try {
            return _conn.getAutoCommit();
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * コミットする。
     *
     * @throws SQLException
     */
    public void commit() throws SQLException {
        try {
            log.debug("commit start");
            _conn.commit();
            log.debug("commit complete");
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * ロールバックする。
     */
    public void rollback() {
        try {
            log.debug("rollback start");
            _conn.rollback();
            log.debug("rollback complete");
        } catch (Exception e) {
            log.error("ロールバック時にエラーが発生しました。", e);
            _hasSqlError = true;
            // 何もしない
        }
    }

    /**
     * リソースを開放する。
     */

    private void close() {

       // ----- 2007.12.06 ここで一旦rollback する。
       //       本来 close() で commit/rollback されていないトランザクションは
       //       自動でrollbackされるのが仕様なので、次回コネクションを使うアプリに
       //       間違ってトランザクションを継続させないように強制的にrollbackしておく
        try {
            log.debug("rollback on close");
            _conn.rollback();
        } catch (Exception e) {
            // 何もしない
        }

        _paramList.clear();
        _sql = "";

        close(_pstmt);
        _pstmt = null;

        DBConnectionFactory.releaseConnection(_name, _conn, _hasSqlError);
        _conn = null;
    }

    /**
     * DBAccessを開放する。
     *
     * @param rs
     * @throws SQLException
     */
//    public static void close(DBAccess db) throws SQLException {
//        if (db != null) {
//           db.close();
//        }
//    }
    public static void close(DBAccess db) {
        if (db != null) {
        	PerfLogger.sqlConn_Close(db.getClass());
            try{

                db.close();
            } catch (Exception e) {
                log.error("DBAccessのclose時に例外エラーが発生しました。" , e );
                //何もしない
            }
        }
    }

    /**
     * ResultSetを開放する。
     *
     * @param rs
     */
    public static void close(ResultSet rs) {
        try {
            if (rs != null) {
            	PerfLogger.sqlRSet_Close(rs.getClass());
                rs.close();
            }
        } catch (SQLException se) {
            log.error("ResultSetクローズ時にエラーが発生しました。", se);
            // 何もしない
        }
    }

    /**
     * Statementを開放する。
     *
     * @param st
     */
    private static void close(Statement st) {
        try {
            if (st != null) {
                st.close();
            }
        } catch (SQLException se) {
            log.error("Statementクローズ時にエラーが発生しました。", se);
            // 何もしない
        }
    }

    /**
     * ログ出力用にパラメータの一覧を設定する。
     *
     * @param i
     * @param value
     */
    private void setParamList(int i, String value) {
        for (int j = _paramList.size(); j <= i - 1; j++) {
            _paramList.add("");
        }
        _paramList.set(i - 1, value);
    }

    /**
     * パラメータSQLを展開して返す。
     */
    private String getPreparedSql() {
        String execSql = _sql;
        for (int i = 0; i < _paramList.size(); i++) {
            execSql = ValueUtil.replaceFirst(execSql, "?", (String) _paramList.get(i));
        }
        return execSql;
    }

    /**
     * PreparedStatementを作成する。
     *
     * @param sql
     * @throws SQLException
     */
    public void prepareStatement(String sql) throws SQLException {
        try {
            _paramList.clear();
            _sql = sql;
            close(_pstmt);
            _pstmt = _conn.prepareStatement(sql);
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * ResultSetのfetchサイズの事前指定
     * @param size fetch行数
     * @throws SQLException
     */
    public void setFetchSize(int size) throws SQLException {
        try {
            _pstmt.setFetchSize(size);
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
	 * PreparedStatementを作成する。
	 *
	 * @param sql
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @throws SQLException
	 */
	public void prepareStatement(String sql, int resultSetType,
			int resultSetConcurrency) throws SQLException {
		try {
			_paramList.clear();
			_sql = sql;
			close(_pstmt);
			_pstmt = _conn.prepareStatement(sql, resultSetType,
					resultSetConcurrency);
		} catch (SQLException e) {
			_hasSqlError = true;
			throw e;
		}
	}

    /**
	 * 条件を設定する。
	 *
	 * @param i
	 * @param value
	 * @throws SQLException
	 */
    public void setString(int i, String value) throws SQLException {
        try {
            setParamList(i, "'" + value + "'");
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            _pstmt.setString(i, value);
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 条件を設定する。
     *
     * @param i
     * @param value
     * @throws SQLException
     */
    public void setInt(int i, int value) throws SQLException {
        try {
            setParamList(i, Integer.toString(value));
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            _pstmt.setInt(i, value);
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 条件を設定する。
     *
     * @param i
     * @param value
     * @throws SQLException
     */
    public void setLong(int i, long value) throws SQLException {
        try {
            setParamList(i, Long.toString(value));
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            _pstmt.setLong(i, value);
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 条件を設定する。
     *
     * @param i
     * @param value
     * @throws SQLException
     */
    public void setDouble(int i, double value) throws SQLException {
        try {
            setParamList(i, Double.toString(value));
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            _pstmt.setDouble(i, value);
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 条件を設定する。
     *
     * @param i
     * @param value
     * @throws SQLException
     */
    public void setClob(int i, Clob value) throws SQLException {
        try {
            setParamList(i, (value == null ? "null" : "'" + value.toString() + "'"));
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            if (value != null) {
                _pstmt.setClob(i, value);
            } else {
                setNull(i);
            }
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 条件を設定する。
     *
     * @param i
     * @param value
     * @throws SQLException
     */
    public void setObject(int i, Object value) throws SQLException {
        try {
            setParamList(i, (value == null ? "null" : "'" + value.toString() + "'"));
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            if (value != null) {
                _pstmt.setObject(i, value);
            } else {
                setNull(i);
            }
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 条件を設定する。
     *
     * @param i
     * @throws SQLException
     */
    public void setNull(int i) throws SQLException {
        try {
            setParamList(i, "null");
            log.debug("param" + i + ": null");
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            _pstmt.setNull(i, Types.NULL);
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * PreparedStatementを実行し、結果を返す。
     *
     * @return
     * @throws SQLException
     */
    public ResultSet executeQuery() throws SQLException {
        try {
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            String _sql=getPreparedSql();
            log.info("executeQuery tring ...\n" + _sql);
            PerfLogger.sqlStmt_Start(this.getClass(), _sql);
            ResultSet rs = _pstmt.executeQuery();
            log.debug("executeQuery OK");
            return rs;
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
        finally
        {
            PerfLogger.sqlStmt_End(this.getClass());
        }
    }

    /**
     * PreparedStatementを実行し、DBを更新する。
     *
     * @return 更新したレコード数。
     * @throws SQLException
     */
    public int executeUpdate() throws SQLException {
        try {
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            int ret = 0;
            String _sql=getPreparedSql();
            log.info("executeUpdate tring ...\n" + _sql);
            PerfLogger.sqlStmt_Start(this.getClass(), _sql);
            ret = _pstmt.executeUpdate();
            log.debug("executeUpdate OK: " + String.valueOf(ret));
            return ret;
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
        finally
        {
            PerfLogger.sqlStmt_End(this.getClass());

        }
    }

    /**
     * sqlを実行し、結果を返す。
     *
     * @param sql
     * @return
     * @throws SQLException
     */
    public ResultSet executeQuery(String sql) throws SQLException {
        try {
            log.info("executeQuery tring ...\n" + sql);
            PerfLogger.sqlStmt_Start(this.getClass(),sql);
            prepareStatement(sql);
            return executeQuery();
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
        finally
        {
            PerfLogger.sqlStmt_End(this.getClass());
        }
    }

    /**
     * sqlを実行し、DBを更新する。
     *
     * @param sql
     * @return 更新したレコード数。
     * @throws SQLException
     */
    public int executeUpdate(String sql) throws SQLException {
        try {
            int ret = 0;
            Statement stmt = null;
            try {
                log.info("executeUpdate tring ...\n" + sql);
                stmt = _conn.createStatement();
                ret = stmt.executeUpdate(sql);
                log.debug("executeUpdate OK: " + String.valueOf(ret));
            } finally {
                close(stmt);
            }
            return ret;
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * シーケンス番号を取得する。
     *
     * @param sequenceSql
     * @return
     * @throws SQLException
     */
    public long getSequenceNo(String sequenceSql) throws SQLException {
        try {
            long sequenceNo = 0;

            ResultSet rs = null;
            try {
                rs = executeQuery(sequenceSql);
                if (next(rs)) {
                    sequenceNo = rs.getLong(1);
                }
            } finally {
                close(rs);
            }

            return sequenceNo;
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 結果セットを次の行に移動する。
     *
     * @return
     * @throws SQLException
     */
    public boolean next(ResultSet rs) throws SQLException {
        try {
            boolean ret = rs.next();
            if (ret) {
                log.debug("fetch: " + rs.getRow() + "(ID:" + rs.hashCode() + ")");
            } else {
                log.debug("fetch end(ID:" + rs.hashCode() + ")");
            }
            return ret;
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * sqlのwhere句のinに渡す形式にする。
     *
     * @param ids
     * @return
     */
    public static String getInList(String[] ids) {
        StringBuffer sb = new StringBuffer();

        if (ids.length > 0) {
            sb.append('\'');
            sb.append(ids[0].replaceAll("'", "\'"));
            sb.append('\'');
        }

        for (int i = 1; i < ids.length; i++) {
            sb.append(',');
            sb.append('\'');
            sb.append(ids[i].replaceAll("'", "\'"));
            sb.append('\'');
        }

        return sb.toString();
    }

    /**
     * sqlのwhere句のinに渡す形式にする。
     *
     * @param ids
     * @return
     */
    public static String getInList(Integer[] ids) {
        StringBuffer sb = new StringBuffer();

        if (ids.length > 0) {
            sb.append(ids[0].intValue());
        }

        for (int i = 1; i < ids.length; i++) {
            sb.append(',');
            sb.append(ids[i].intValue());
        }

        return sb.toString();
    }

    /**
     * sqlのwhere句のinに渡す形式にする。
     *
     * @param ids
     * @return
     */
    public static String getInList(Long[] ids) {
        StringBuffer sb = new StringBuffer();

        if (ids.length > 0) {
            sb.append(ids[0].longValue());
        }

        for (int i = 1; i < ids.length; i++) {
            sb.append(',');
            sb.append(ids[i].longValue());
        }

        return sb.toString();
    }

    /**
     * カレントのスキーマ名を返す
     *   実際には db.properties に記述されているので
     *   Factory 側でも単に読み込んでいるだけ。
     *
     * @throws SQLException
     */
    public String getSchema() {
       return DBConnectionFactory.getSchemaFromPropeties();
    }
    public String getSchema( String surrfix ) {
       return DBConnectionFactory.getSchemaFromPropeties(surrfix);
    }

    public DatabaseMetaData  getDatabaseMetaData() throws SQLException{
        return _conn.getMetaData();
    }

    /*
     *
     * 2010/08/31
     *  以下、BLOB用に追加
     *
     */

    public void setBlob(int i, Blob value) throws SQLException {
        try {
            setParamList(i, (value == null ? "null" : "'" + value.toString() + "'"));
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            if (value != null) {
                _pstmt.setBlob(i, value);
            } else {
                setNull(i);
            }
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 条件を設定する。
     *
     * @param i
     * @param value
     * @throws SQLException
     */
    public void setBinary(int i, byte[] bytes) throws SQLException {
        try {
            setParamList(i, (bytes == null ? "null" : "'" + new String(bytes) + "'"));
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            if (bytes != null) {
                ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
                _pstmt.setBinaryStream(i, bais, bytes.length);
            } else {
                setNull(i);
            }
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /**
     * 条件を設定する。
     *
     * @param i
     * @param value
     * @throws SQLException
     */
    public void setBytes(int i, byte[] bytes) throws SQLException {
        try {
            setParamList(i, (bytes == null ? "null" : "'" + new String(bytes) + "'"));
            if (_pstmt == null) {
                throw new SQLException("PreparedStatementが用意されていません。");
            }
            if (bytes != null) {
                _pstmt.setBytes(i, bytes);
            } else {
                setNull(i);
            }
        } catch(SQLException e) {
            _hasSqlError = true;
            throw e;
        }
    }

    /*
     *
     * 2010/08/31
     *  BLOB用に追加  ここまで
     *
     */

    /***
     * CallableStatementオブジェクトを取得する
     *
     * @param sql
     * @return
     * @throws SQLException
     */
    public CallableStatement prepareCall(String sql)
    throws SQLException
    {
    	return this._conn.prepareCall(sql);
    }

    public static void closeCallableStatement(CallableStatement st)
    {
    	close(st);
    }


    Connection __getConnection()
    {
    	return this._conn;
    }

    String __getName()
    {
    	return this._name;
    }


}