package jp.co.webcrew.filters.filters.replace.sstag;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.util.httputil.CustomHttpServletRequest;
import jp.co.webcrew.filters.util.httputil.CustomHttpServletResponse;

/**
 * 各サーバサイドタグの処理を行うクラスの共通インターフェース
 * 
 * @author kurinami
 */
abstract public class SSTagExecuter {

	/** サーバサイド処理Executerのクラス名の接尾辞 */
	public static final String EXECUTER_POSTFIX = "Executer";

	/** レスポンスの形式を指定するためのパラメータキー名 */
	public static final String SSTAG_FLAG_PARAM_KEY = "sstag_flag";

	/** ロガー */
	private static final Logger log = Logger.getLogger(SSTagExecuter.class);

	/**
	 * <pre>
	 *  サーバサイドタグに対応するサーブレットを呼び出し、
	 *  結果を文字列で返す。
	 *      
	 *  サーバサイドタグがサーブレットを呼び出すのではなく、
	 *  独自の処理を行なわせたい場合、
	 *  このメソッドをオーバーライドする。
	 * </pre>
	 * 
	 * @param parameters
	 * @param request
	 * @param response
	 * @return
	 */
	public String execute(Map parameters, HttpServletRequest request,
			HttpServletResponse response) {

		// パラメータ一覧にレスポンスの形式をsstagにするパラメータを追加。
		Map localParameters = new HashMap();
		localParameters.putAll(parameters);
		localParameters.put(SSTAG_FLAG_PARAM_KEY, "t");

		// 処理移譲用のrequestクラスとresponseクラスを生成
		CustomHttpServletRequest customRequest = new CustomHttpServletRequest(
				request);
		customRequest.setParameterMap(localParameters);
		CustomHttpServletResponse customResponse = new CustomHttpServletResponse(
				response, response.getCharacterEncoding());

		String content = execute(customRequest, customResponse);

		// リダイレクトをチェックする。
		String location = customResponse.getLocation();
		if (location != null) {
			try {
				response.sendRedirect(location);
			} catch (Exception e) {
				log.error("予期せぬエラー", e);
			}
			return "";
		}

		return content;
	}

	/**
	 * <pre>
	 *  サーブレットのようにsstagを実装する場合は、
	 *  こちらのメソッドをオーバーライドする。
	 * </pre>
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	protected String execute(HttpServletRequest request,
			HttpServletResponse response) {
		String servletPath = getServletPath();
		String content = forward(servletPath,
				(CustomHttpServletRequest) request,
				(CustomHttpServletResponse) response);
		return content;
	}

	/**
	 * 処理を別のサーブレットに移譲して結果だけを返す。
	 * 
	 * @param path
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	private String forward(String path, CustomHttpServletRequest request,
			CustomHttpServletResponse response) {

		String res = "";

		try {

			// 処理をサーブレットに移譲する。
			request.getRequestDispatcher(path).forward(request, response);

			// 結果を取得する。
			res = response.getHtml();

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		return res;
	}

	/**
	 * 実体のクラス名を元に 呼び出すサーブレットの相対パスを求める。
	 * 
	 * 呼び出すサーブレットのパスが デフォルトと違う場合は、このメソッドをオーバーライドする。
	 * 
	 * @return
	 */
	protected String getServletPath() {
		String className = this.getClass().getName();
		int i = className.lastIndexOf('.');
		String simpleClassName = className.substring(i + 1);
		String servletPath = "/"
				+ simpleClassName.substring(0, 1).toLowerCase()
				+ simpleClassName.substring(1, simpleClassName.length()
						- EXECUTER_POSTFIX.length());

		return servletPath;
	}

    protected String onerror(HttpServletRequest request, HttpServletResponse response, Map parameters, Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        pw.flush();
        
        return onerror(request, response, parameters, sw.toString());
    }
    
    protected String onerror(HttpServletRequest request, HttpServletResponse response, Map parameters, String errorCode, String errorMessage) {
        return onerror(request, response, parameters, "[" + errorCode + "] " + errorMessage);
    }
    
    protected String onerror(HttpServletRequest request, HttpServletResponse response, Map parameters, String message) {
        
        message = this.getClass().getSimpleName() + ":" + message;
        
        if(isTestMode() && SystemErrorMsgExecuter.isDisplayOn(request)){
            return "<pre>エラー \n" + message + "</pre>";
        }
        
        return "";
        
//        String html = "";
//        String onerror = ValueUtil.nullToStr(parameters.get("onerror"));
//        if(onerror.equalsIgnoreCase("redirect")) {
//            String url = ValueUtil.nullToStr(SystemPropertiesDb.getInstance().get("EC_SSTAG_ERROR_URL"));
//            try {
//                response.sendRedirect(url);
//            } catch (IOException e) {
//                log.error("予期せぬエラー", e);
//            }
//        } else if(onerror.equalsIgnoreCase("alert")){
//            html = "<!-- システムエラーが発生しました。({0}) -->\n<script type=\"text/javascript\">\n<!--\nalert(\"システムエラーが発生しました。\");\n// --></script>";
//        } else {
//            html = "<!-- システムエラーが発生しました。({0}) -->エラーが発生しました。";
//        }
//        return MessageFormat.format(html, message);
    }

    public boolean needDefer(Map parameters) {
        
        List excludeParamList = getExcludeParamList();
        
        Iterator i = parameters.keySet().iterator();
        while (i.hasNext()) {
            String key = (String) i.next();
            if(!excludeParamList.contains(key)) {
                String value = (String) parameters.get(key);
                if (value.matches(".*\\%\\{[0-9a-zA-Z_\\-\\.]+\\}.*")) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    protected List getExcludeParamList() {
        return new ArrayList();
    }
    

    /**
     * テストモードかを返す。
     * 
     * @return
     */
    public static boolean isTestMode() {
        return ValueUtil.nullToStr(System.getProperty("testMode")).equals("1");
    }
    
    public static void main(String[] args) {
        Map parameters = new HashMap();
        parameters.put("key1", "<sstag> %{gegege.gege} </sstag>");
        parameters.put("key2", "<sstag> gegege.gege </sstag>");
        
        System.out.println(new SSTagExecuter() {}.needDefer(parameters));
    }
}
