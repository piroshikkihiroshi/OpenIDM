package jp.co.webcrew.log4wc;
/*
 * <システム名> : WebCrew
 * <概      要> : ログ出力関連
 * <履      歴> : 1.0  07-08-01/T.Ookawa  新規
 *
 *  Copyright(C) 2007, WebCrew Inc, All Rights Reserved.
 *
 */


// インポート
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * ログ出力関連クラス
 *
 * @version 1.0
 * @since   1.0
 *
 */
public class LogOut {


    /* ------------------------------------------------------------------------------------ */
    /*
     * 定数
     */
    /** ログレベル－全て */
    private static final int LOGOUT_LEBEL_ALL       = 0;

    /** ログレベル－デバッグ */
    private static final int LOGOUT_LEBEL_DEBUG     = 1;

    /** ログレベル－情報 */
    private static final int LOGOUT_LEBEL_INFO      = 2;

    /** ログレベル－ワーニング */
    private static final int LOGOUT_LEBEL_WARN      = 3;

    /** ログレベル－エラー */
    private static final int LOGOUT_LEBEL_ERROR     = 4;

    /** ログレベル－致命的 */
    private static final int LOGOUT_LEBEL_FATAL     = 5;

    /** ログレベル－定義文字列 */
    private static final String[] LogOutLebelStr = {
                                                    "ALL",
                                                    "DEBUG",    // これ以降、出力時を考慮して、各文字列の長さを半角スペースで揃えておく
                                                    "INFO ",
                                                    "WARN ",
                                                    "ERROR",
                                                    "FATAL"
                                                };

    /** 呼び出し元情報－クラス名 */
    private static final int LOGOUT_TARGET_CLASS    = 0;

    /** 呼び出し元情報－メソッド名 */
    private static final int LOGOUT_TARGET_METHOD   = 1;

    /** 呼び出し元情報－ファイル名 */
    private static final int LOGOUT_TARGET_FILE     = 2;

    /** 呼び出し元情報－行番号 */
    private static final int LOGOUT_TARGET_LINE     = 3;

    /** 呼び出し元情報－情報数 */
    private static final int LOGOUT_TARGET_MAX      = 4;

    /** プロパティ項目－出力ディレクトリ名 */
    private static final String LOGOUT_PROP_ITEM_DIRNAME        = "DirName";

    /** プロパティ項目－ファイル名接頭文字列 */
    private static final String LOGOUT_PROP_ITEM_PREFIX         = "Prefix";

    /** プロパティ項目－ファイル名接尾文字列 */
    private static final String LOGOUT_PROP_ITEM_SUFFIX         = "Suffix";

    /** プロパティ項目－ファイル名接続文字列 */
    private static final String LOGOUT_PROP_ITEM_JOIN           = "Join";

    /** プロパティ項目－ファイル出力単位 */
    private static final String LOGOUT_PROP_ITEM_UNIT           = "Unit";

    /** プロパティ項目－シンボリックリンク作成ディレクトリ名 */
    private static final String LOGOUT_PROP_ITEM_LINK_DIRNAME   = "LinkDirName";

    /** プロパティ項目－シンボリックリンク名接尾文字列 */
    private static final String LOGOUT_PROP_ITEM_LINK_SUFFIX    = "LinkSuffix";

    /** プロパティ項目－無効用ログインID */
    private static final String LOGOUT_PROP_ITEM_INVALIDID      = "InvalidId";

    /** プロパティ項目－出力ログレベル */
    private static final String LOGOUT_PROP_ITEM_LOGLEVEL       = "LogLevel";

    /** プロパティ項目－出力ファイル文字コード */
    private static final String LOGOUT_PROP_ITEM_ENCODING       = "Encoding";

    /** プロパティ項目－シンボリックリンクコマンドパス */
    private static final String LOGOUT_PROP_ITEM_SYSTEMLNPATH   = "SystemLnPath";

    /** プロパティファイル名 */
    private static final String LOGOUT_PROP_FILENAME            = "log4wc.properties";

    private static boolean debug_msg = false;

    /** プロパティ項目－メールToアドレス */
    private static final String LOGOUT_PROP_MAIL_TO             = "MailTo";

    /** プロパティ項目－メールFromアドレス */
    private static final String LOGOUT_PROP_MAIL_FROM           = "MailFrom";

    /** プロパティ項目－メールSubject */
    private static final String LOGOUT_PROP_MAIL_SUBJECT        = "MailSubject";

    /** プロパティ項目－メールSMTPサーバ */
    private static final String LOGOUT_PROP_MAIL_SMTP           = "MailSMTP";

    /** プロパティ項目－メールSMTPサーバのポート */
    private static final String LOGOUT_PROP_MAIL_PORT           = "MailPort";


    /* ------------------------------------------------------------------------------------ */
    /*
     * フィールド
     */
    /** プロパティ情報 */
    private Properties  props;

    /** ログインID */
    private String      loginId         = null;

    /** 識別子 */
    private String      ident           = null;

    /** ラッパークラス名 */
    private String      wrapperClass    = null;


    private static Method phoenixMethod_getRequestInfo=null;

    private static final String CLASS_PHOENIX_REQUEST_CTXT="jp.co.webcrew.phoenix.util.PhoenixRequestContext";
    private static final String METHOD_PHOENIX_getRequestInfo="getRequestInfo";

    static
    {
    	/****
    	 *
    	 * errorメソッド呼び出しの際、
    	 *
    	 *
    	 *
    	 */
    	Class cls;
    	//t_ueda loggerはlocalでは殺す
//		try {
//			cls = Class.forName(CLASS_PHOENIX_REQUEST_CTXT);
//	    	phoenixMethod_getRequestInfo=cls.getMethod(METHOD_PHOENIX_getRequestInfo, new Class[0]);
//		} catch (ClassNotFoundException e) {
//			System.out.println("↓↓非フェニックス環境では出ても問題のないエラー");
//			System.out.println("###class_not_found###"+e.getMessage());
//			//e.printStackTrace();
//		} catch (SecurityException e) {
//			System.out.println("↓↓非フェニックス環境では出ても問題のないエラー");
//			System.out.println("###securty_exc###"+e.getMessage());
//			//e.printStackTrace();
//		} catch (NoSuchMethodException e) {
//			System.out.println("↓↓非フェニックス環境では出ても問題のないエラー");
//			System.out.println("###NoSuchMethod###"+e.getMessage());
//			//e.printStackTrace();
//		}

    }


    /* ------------------------------------------------------------------------------------ */
    /**
     *
     *<PRE>
     * コンストラクタ
     *</PRE>
     *
     * @since 1.0
     *
     */
    public LogOut() {


        getProp();
        this.loginId = null;
        this.ident = null;
        this.wrapperClass = null;


    } /*- LogOut() -*/


    /**
     *
     *<PRE>
     * コンストラクタ
     *</PRE>
     *
     * @since 1.0
     *
     * @param loginid [in]ログインID(無効値:null)
     * @param ident   [in]識別子(無効値:null)･･･セッションID
     *
     */
    public LogOut(String    loginid,
                  String    ident) {


        getProp();
        this.loginId = loginid;
        this.ident = ident;
        this.wrapperClass = null;


    } /*- LogOut() -*/


    /**
     *
     *<PRE>
     * コンストラクタ
     *</PRE>
     *
     * @since 1.0
     *
     * @param loginid      [in]ログインID(無効値:null)
     * @param ident        [in]識別子(無効値:null)･･･セッションID
     * @param wrapperclass [in]ラッパークラス名
     *
     */
    public LogOut(String    loginid,
                  String    ident,
                  String    wrapperclass) {


        getProp( wrapperclass );
        this.loginId = loginid;
        this.ident = ident;
        this.wrapperClass = wrapperclass;


    } /*- LogOut() -*/


    /* ------------------------------------------------------------------------------------ */
    /**
     *
     *<PRE>
     * プロパティ情報取得
     *</PRE>
     *
     * @since 1.0
     *
     */
    private void getProp() {
       getProp( null );
    }
    private void getProp( String wrapperclass ) {

        // 呼び出し元情報取得
        String proj_name = getProjectName(wrapperclass);

if( debug_msg ){
   System.out.println( "=====================================================" );
   System.out.println( "log4wc - debug: proj_name = " + proj_name  );
}

        // ----- プロパティファイル名調査
        String prop_file = LOGOUT_PROP_FILENAME;
        if( proj_name != null && proj_name.length() > 0 ){
           prop_file += "." + proj_name;

if( debug_msg ){
   System.out.println( "log4wc - debug: filename = " + prop_file );
}

           InputStream is = this.getClass().getClassLoader().getResourceAsStream(prop_file);
           if( is == null ) {
              prop_file = LOGOUT_PROP_FILENAME;
           }
           try {
              is.close();
           } catch( Exception e ){
               // ここでエラーがでても意味がないので無視する
           }
        }
if( debug_msg ){
   System.out.println( "log4wc - debug: filename = " + prop_file );
   System.out.println( "=====================================================" );
}







        // インスタンス作成
        this.props = new Properties();

        InputStream fin = null;
        try {

            // ファイル読み込み
            ClassLoader cl = Thread.currentThread().getContextClassLoader();
            fin = cl.getResourceAsStream(prop_file);

            if (fin == null) {
                System.err.println( now() + " SYSTEM_ERROR: getResourceAsStream file=" + prop_file);
            }
            else {
                // ロード
                this.props.load(fin);
            }

        }
        catch (IOException e) {
            System.err.println( now() + " SYSTEM_ERROR: IOException file=" + e);
            e.printStackTrace();
        }
        finally {
            try {
                if (fin != null) {
                    fin.close();
                }
            }
            catch (IOException e) {
                System.err.println( now() + " SYSTEM_ERROR: IOException on close" + e);
                e.printStackTrace();
            }
        }


    } /*- getProp() -*/


    /**
     *
     *<PRE>
     * 呼び出し元で、自分のパッケージ以外ののプロジェクト名を取得
     *</PRE>
     *
     * @since 1.0
     *
     * @return String プロジェクト名
     */
    private String getProjectName( String wrapperClassName ) {

        Throwable           t;
        StackTraceElement   element;
        String              class_name;
        int                 ii;

        String prefix    = "jp.co.webcrew.";
        String proj_name = null;


if( debug_msg ){
   System.out.println( "=================================" );
   System.out.println( "wrapper = " + wrapperClassName );
}

        t = new Throwable();
        element = t.getStackTrace()[2];
        for (ii = 2; ii < t.getStackTrace().length; ii++) {

           // ----- stack のエレメント取得
            element = t.getStackTrace()[ii];
            class_name = element.getClassName();
if( debug_msg ){
   System.out.println( class_name );
}

           // ----- 自分自身の時は読み飛ばす
            String my_pkg   = "jp.co.webcrew.log4wc.";
            if( class_name.startsWith( my_pkg ) ){
               continue;
            }

           // ----- ラッパークラスの場合はリセット
            if( wrapperClassName!=null && class_name.startsWith( wrapperClassName ) ){
               proj_name = null;
if( debug_msg ){
   System.out.println( "**** RESET" );
}
               continue;
            }

           // ----- jp.co.webcrew に続く名称の取得 (プロジェクト名とする)
            if( proj_name == null && class_name.startsWith( prefix ) ){
               int to = class_name.indexOf( '.', prefix.length() );
               proj_name = class_name.substring( prefix.length(), to );
               // return proj_name;
            }
        }

if( debug_msg ){
   System.out.println( "proj_name = " + proj_name );
   System.out.println( "=================================" );
}
        return proj_name;


    } /*- getProjectName -*/


    /**
     *
     *<PRE>
     * プロパティ値取得
     *</PRE>
     *
     * @since 1.0
     *
     * @param name [in]プロパティ項目
     *
     * @return String プロパティ値(存在しない場合は、"")
     *
     */
    private String getPropValue(String name) {


        // プロパティ情報取得
        if (this.props.getProperty(name) != null) {
            return (this.props.getProperty(name));
        }

        return ("");


    } /*- getPropValue() -*/


    /**
     *
     *<PRE>
     * ログインID取得
     *</PRE>
     *
     * @since 1.0
     *
     * @return String ログインID
     *
     */
    public String getLoginId() {


        return (this.loginId);


    } /*- getLoginId() -*/


    /**
     *
     *<PRE>
     * ログインID設定
     *</PRE>
     *
     * @since 1.0
     *
     * @param loginid [in]ログインID
     *
     */
    public void setLoginId(String loginid) {


        this.loginId = loginid;


    } /*- setLoginId() -*/


    /**
     *
     *<PRE>
     * 識別子取得
     *</PRE>
     *
     * @since 1.0
     *
     * @return String 識別子
     *
     */
    public String getIdent() {


        return (this.ident);


    } /*- getIdent() -*/


    /**
     *
     *<PRE>
     * 識別子設定
     *</PRE>
     *
     * @since 1.0
     *
     * @param ident [in]識別子
     *
     */
    public void setIdent(String ident) {


        this.ident = ident;


    } /*- setIdent() -*/


    /**
     *
     *<PRE>
     * ラッパークラス名取得
     *</PRE>
     *
     * @since 1.0
     *
     * @return String ラッパークラス名
     *
     */
    public String getWrapperClass() {


        return (this.wrapperClass);


    } /*- getWrapperClass() -*/


    /**
     *
     *<PRE>
     * ラッパークラス名設定
     *</PRE>
     *
     * @since 1.0
     *
     * @param wrapperclass [in]ラッパークラス名
     *
     */
    public void setWrapperClass(String wrapperclass) {


        this.wrapperClass = wrapperclass;


    } /*- setWrapperClass() -*/


    /**
     *
     *<PRE>
     * 呼び出し元情報取得
     *</PRE>
     *
     * @since 1.0
     *
     * @return String[] [LOGOUT_TARGET_CLASS] クラス名
     *                  [LOGOUT_TARGET_METHOD]メソッド名
     *                  [LOGOUT_TARGET_FILE]  ファイル名
     *                  [LOGOUT_TARGET_LINE]  行番号
     *
     */
    private String[] getTargetInfo() {

        Throwable           t;
        StackTraceElement   element;
        StringTokenizer     token;
        String[]            target;
        String              class_name, last_class_name;
        int                 ii;


        // 戻り値初期化
        target = new String[LOGOUT_TARGET_MAX];

        // [0]本メソッド。[1]同クラス内のメソッド。[2]が呼び出し元。
        t = new Throwable();
        element = t.getStackTrace()[2];

        // ラッパークラスの場合、その次を取得
        if (getWrapperClass() != null) {
            for (ii = 2; ii < t.getStackTrace().length; ii++) {
                element = t.getStackTrace()[ii];
                class_name = element.getClassName();
                if (class_name.equals(getWrapperClass())) {
//System.out.println("WrapperCalss: " + getWrapperClass());
                    if (ii + 1 < t.getStackTrace().length) {
                        element = t.getStackTrace()[ii + 1];
                    }
                    break;
                }
            }
        }

        // 完全限定クラス名を取得
        class_name = element.getClassName();

        // パッケージ名を除くクラス名を取得
        token = new StringTokenizer(class_name, ".");
        last_class_name = "";
        while (token.hasMoreTokens()) {
            last_class_name = token.nextToken();
        }

        // 呼び出し元情報設定
        target[LOGOUT_TARGET_CLASS] = last_class_name;
        target[LOGOUT_TARGET_METHOD]    = element.getMethodName();
        target[LOGOUT_TARGET_FILE]      = element.getFileName();
        target[LOGOUT_TARGET_LINE]      = Integer.toString(element.getLineNumber());

        return (target);


    } /*- getTargetInfo() -*/


    /**
     *
     *<PRE>
     * 出力ログインID取得
     *</PRE>
     *
     * @since 1.0
     *
     * @return String 出力ログインID(存在しない場合、"")
     *
     *//*
     *   note:ログインIDが無効値の場合、無効値用ログインIDを出力する
     */
    public String getOutLoginId() {


        String  login_id = "";

        if (getLoginId() != null) {
            if (getLoginId().length() > 0) {
                login_id = getLoginId();
            }
        }
        if (login_id.length() <= 0) {
            login_id = getPropValue(LOGOUT_PROP_ITEM_INVALIDID);
        }

        return (login_id);


    } /*- getOutLoginId() -*/


    /**
     *
     *<PRE>
     * 出力対象識別子取得
     *</PRE>
     *
     * @since 1.0
     *
     * @return String 出力識別子(存在しない場合、"")
     *
     */
    public String getOutIdent() {


        if (getIdent() == null) {
            return ("");
        }

        return (getIdent());


    } /*- getOutIdent() -*/


    /**
     *
     *<PRE>
     * ログインIDと識別子から対象ファイル名を取得
     *</PRE>
     *
     * @since 1.0
     *
     * @param date_str [in]日付文字列
     *
     * @return String 対象ファイル名(対象外の場合、null)
     *
     */
    private String getTargetFileNameFromId(String date_str) {

        File        real_file, link_file, file;
        Process     process;
        int         index1, index2;
        String      login_id, ident;
        String      real_flname, link_flname, now_flname, flname;
        String      chk_str1, chk_str2;
        String      cmd;


        // 出力ログインID取得
        login_id = getOutLoginId();

        // 出力識別子取得
        ident = getOutIdent();

        // 対象外
        if (login_id.length() <= 0 || ident.length() <= 0) {
            return (null);
        }

        // チェックする文字列
        chk_str1  = getPropValue(LOGOUT_PROP_ITEM_PREFIX);
        chk_str1 += getPropValue(LOGOUT_PROP_ITEM_JOIN);
        chk_str1 += login_id;
        chk_str1 += getPropValue(LOGOUT_PROP_ITEM_JOIN);
        chk_str2  = getPropValue(LOGOUT_PROP_ITEM_SUFFIX);

        // 実体ファイル名
        real_flname  = chk_str1 + date_str + chk_str2;

        // リンクファイル名
        link_flname = ident + getPropValue(LOGOUT_PROP_ITEM_LINK_SUFFIX);
        link_file = new File(getPropValue(LOGOUT_PROP_ITEM_LINK_DIRNAME), link_flname);

        // 既にシンボリックリンクが存在する場合
        if (link_file.exists()) {

            // 実体ファイル名
            try {
                now_flname = link_file.getCanonicalPath();
            }
            catch (IOException ex) {
                System.err.println( now() + " SYSTEM_ERROR: IOException on getCanonicalPath" + ex);
                ex.printStackTrace();
                return (null);
            }
            file = new File(now_flname);
            flname = file.getName();

//System.out.println("Check Log File: " + "[" + login_id + "] " + flname + "(" + link_file.getAbsolutePath() + ")");

            index1 = flname.indexOf(chk_str1);
            if (index1 == 0) {
                index2 = flname.indexOf(chk_str2, chk_str1.length());
                if (index2 >= 0) {
                    if (index2 + chk_str2.length() == flname.length()) {
                        if (index2 - chk_str1.length() == 8) {  // YYYYMMDDの長さかをチェックしておく
//System.out.println("Same Log File: " + "[" + login_id + "] " + flname);
                            return (flname);    // ログインIDが同じと判断し、そのファイルを返す
                        }
                    }
                }
            }

            // シンボリックリンク削除
//System.out.println("remove link: " + link_file.getAbsolutePath());
            if (!link_file.delete()) {
                System.err.println("remove error: " + link_file.getAbsolutePath());
                return (null);
            }

        }

        try {

            real_file = new File(getPropValue(LOGOUT_PROP_ITEM_DIRNAME), real_flname);

            // シンボリックリンク作成
            cmd = getPropValue(LOGOUT_PROP_ITEM_SYSTEMLNPATH) + " -s " + real_file.getAbsolutePath() + " " + link_file.getAbsolutePath();
//System.out.println("cmd: " + cmd);
            process = Runtime.getRuntime().exec(cmd);

           // ----- 事前にクローズしておく
            OutputStream os = process.getOutputStream();
            InputStream  is = process.getInputStream();
            InputStream  es = process.getErrorStream();
            os.close();
            is.close();
            es.close();

           // ----- リンク作成実行
            process.waitFor();
//System.out.println("status: " + process.exitValue());

        }
        catch (Exception ex) {
            System.err.println( now() + " SYSTEM_ERROR: Exception on exec(mksymlink)" + ex);
            ex.printStackTrace();
            return (null);
        }

        // 実体ファイル名を返す
//System.out.println("Target Log File: " + "[" + login_id + "] " + real_flname);
        return (real_flname);


    } /*- getTargetFileNameFromId() -*/


    /**
     *
     *<PRE>
     * ログ出力
     *</PRE>
     *
     * @since 1.0
     *
     * @param level  [in]ログレベル(LOGOUT_LEBEL_***)
     * @param target [in]呼び出し元情報
     * @param msg    [in]出力内容
     *
     */
    private void out(int        level,
                     String[]   target,
                     String     msg) {

        FileOutputStream    fl = null;
        OutputStreamWriter  out;
        BufferedWriter      bw;
        SimpleDateFormat    simple;
        String              str, path, flname, target_flname, date_str;
        String              login_id;
        int                 index;


        // 現在日時
        GregorianCalendar calendar = new GregorianCalendar();

        // 出力ログインID取得
        login_id = getOutLoginId();

        // 出力文字列生成
        simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
        date_str = simple.format(calendar.getTime());
        str = date_str + " " + LogOutLebelStr[level] + " ";
        if (login_id.length() > 0) {
            str += "[" + login_id + "] ";
        }
        str += target[LOGOUT_TARGET_CLASS] + "." + target[LOGOUT_TARGET_METHOD];
        str += "(" + target[LOGOUT_TARGET_FILE] + ":" + target[LOGOUT_TARGET_LINE] + ")";
        str += " - " + msg;
        str += "\n";

        // ファイル名生成
        simple = new SimpleDateFormat("yyyyMMdd");
        date_str = simple.format(calendar.getTime());
        path = getPropValue(LOGOUT_PROP_ITEM_DIRNAME);
        index = path.lastIndexOf("/");
        if (index < 0 || index != path.length() - 1) {
            path += "/";
        }
        flname = "";

        // ログイン+日付単位(ログインID+日付+識別子)
        if (getPropValue(LOGOUT_PROP_ITEM_UNIT).equals("1")) {

            // ログインIDと識別子から対象ファイル名を取得
            target_flname = getTargetFileNameFromId(date_str);
            if (target_flname != null) {
                flname = target_flname;
            }
            else {
                flname += getPropValue(LOGOUT_PROP_ITEM_PREFIX);
                flname += getPropValue(LOGOUT_PROP_ITEM_JOIN);
                flname += date_str;
                flname += getPropValue(LOGOUT_PROP_ITEM_SUFFIX);
            }
        }

        // 日付単位(ログイン無関係)
        else if (getPropValue(LOGOUT_PROP_ITEM_UNIT).equals("2")) {
            flname += getPropValue(LOGOUT_PROP_ITEM_PREFIX);
            flname += getPropValue(LOGOUT_PROP_ITEM_JOIN);
            flname += date_str;
            flname += getPropValue(LOGOUT_PROP_ITEM_SUFFIX);
        }

        // ログイン単位(日付無関係)
        else if (getPropValue(LOGOUT_PROP_ITEM_UNIT).equals("3")) {
            flname += getPropValue(LOGOUT_PROP_ITEM_PREFIX);
            if (login_id.length() > 0) {
                flname += getPropValue(LOGOUT_PROP_ITEM_JOIN);
                flname += login_id;
            }
            flname += getPropValue(LOGOUT_PROP_ITEM_SUFFIX);
        }

        // 常に1ファイル(ログインID、日付無関係)
        else {
            flname += getPropValue(LOGOUT_PROP_ITEM_PREFIX);
            flname += getPropValue(LOGOUT_PROP_ITEM_SUFFIX);
        }

        try {

        	if(flname.length() > 0) {
                // ファイルオープン
                fl = new FileOutputStream(path + flname, true);

                // ファイル出力
                out = new OutputStreamWriter(fl, getPropValue(LOGOUT_PROP_ITEM_ENCODING));
                bw = new BufferedWriter(out);
                bw.write(str);
                bw.flush();
                bw.close();

        	} else {
        		// ファイル名が組み立てられなかった場合、デフォルトで標準出力に出す。
                System.out.print(str);
        	}

        }
        catch (Exception ex) {
            ;
        }
        finally {

            // ファイルクローズ
            if (fl != null) {
                try {
                    fl.close();
                }
                catch (IOException ex) {
                    ;
                }
            }

        }


    } /*- out() -*/


    /**
     *
     *<PRE>
     * ログレベル文字列からログレベルを取得
     *</PRE>
     *
     * @since 1.0
     *
     * @param level_str [in]ログレベル文字列(LogOutLebelStr)
     *
     * @return int ログレベル(LOGOUT_LEBEL_***)、無効の場合、-1
     *
     */
    private int getLogLebel(String level_str) {

        int     ii;

        if (level_str != null) {
            if (level_str.length() > 0) {
                for (ii = 0; ii < LogOutLebelStr.length; ii++) {
                    if (LogOutLebelStr[ii].trim().equals(level_str)) {
                        return (ii);
                    }
                }
            }
        }

        return (LOGOUT_LEBEL_INFO);


    } /*- getLogLebel() -*/


    /**
     *
     *<PRE>
     * ログレベルチェック
     *</PRE>
     *
     * @since 1.0
     *
     * @param level [in]ログレベル(LOGOUT_LEBEL_***)
     *
     * @return boolean true :出力対象
     *                 false:出力対象外
     *
     */
    private boolean chkLogLevel(int level) {

        int     now_level;
        String  level_str;


        // 現在設定のログレベル取得
        level_str = getPropValue(LOGOUT_PROP_ITEM_LOGLEVEL);
        level_str = level_str.toUpperCase();
        now_level = getLogLebel(level_str);
//System.out.println("LogLebel: " + level_str + "(" + now_level + ")");

        // 判断
        if (now_level >= 0) {
            if (level >= now_level) {
                return (true);
            }
        }

        return (false);


    } /*- chkLogLevel() -*/


    /**
     *
     *<PRE>
     * デバッグログ出力
     *</PRE>
     *
     * @since 1.0
     *
     * @param msg [in]出力内容
     *
     */
    public void debug(String msg) {


        // ログ出力対象外
        if (!chkLogLevel(LOGOUT_LEBEL_DEBUG)) {
            return;
        }

        // 呼び出し元情報取得
        String[] target = getTargetInfo();

        // ログ出力
        out(LOGOUT_LEBEL_DEBUG, target, msg);


    } /*- debug() -*/


    /**
     *
     *<PRE>
     * 情報ログ出力
     *</PRE>
     *
     * @since 1.0
     *
     * @param msg [in]出力内容
     *
     */
    public void info(String msg) {


        // ログ出力対象外
        if (!chkLogLevel(LOGOUT_LEBEL_INFO)) {
            return;
        }

        // 呼び出し元情報取得
        String[] target = getTargetInfo();

        // ログ出力
        out(LOGOUT_LEBEL_INFO, target, msg);


    } /*- info() -*/


    /**
     *
     *<PRE>
     * ワーニングログ出力
     *</PRE>
     *
     * @since 1.0
     *
     * @param msg [in]出力内容
     *
     */
    public void warn(String msg) {


        // ログ出力対象外
        if (!chkLogLevel(LOGOUT_LEBEL_WARN)) {
            return;
        }

        // 呼び出し元情報取得
        String[] target = getTargetInfo();

        // ログ出力
        out(LOGOUT_LEBEL_WARN, target, msg);


    } /*- warn() -*/

    private static boolean __firstErrorOccurred=false;


    /**
     *
     *<PRE>
     * エラーログ出力
     *</PRE>
     *
     * @since 1.0
     *
     * @param msg [in]出力内容
     *
     */
    public void error(String msg) {

    	if(phoenixMethod_getRequestInfo!=null)
    	{


    		//String[] requestInfo;
			try
			{
				//requestInfo = (String[])phoenixMethod_getRequestInfo.invoke(null);
				String requestInfo = (String)phoenixMethod_getRequestInfo.invoke(null);
				if(requestInfo!=null)
				{
					/*
					if(requestInfo[0].equals("success"))
					{
						msg="[ServerName]"+requestInfo[1]+"\n[URI]"+requestInfo[2]+"\n[QueryString]"+requestInfo[3]+"\n"+msg;
					}
					else
					{
						msg="[Result]"+requestInfo[0]+"\n"+msg;
					}
					*/
					msg=requestInfo+msg;

				}
				else
				{
					System.err.println("[log4wc#error]mismatched");
				}
			} catch (Exception e) {
				System.err.println("[log4wc#error]"+e.getClass().getName()+":"+e.getMessage());
				if(!__firstErrorOccurred)
				{
					e.printStackTrace();
				}
				__firstErrorOccurred=true;
			}

    	}

        // ログ出力対象外
        if (!chkLogLevel(LOGOUT_LEBEL_ERROR)) {
            return;
        }

        // 呼び出し元情報取得
        String[] target = getTargetInfo();

        // ログ出力
        out(LOGOUT_LEBEL_ERROR, target, msg);

        // 以下、メール出力
        // まずは、プロパティファイルから各値を取得
        String mailTo = getPropValue(LOGOUT_PROP_MAIL_TO);
        String mailFrom = getPropValue(LOGOUT_PROP_MAIL_FROM);
        String mailSubject = getPropValue(LOGOUT_PROP_MAIL_SUBJECT) + " : " +
                             target[LOGOUT_TARGET_CLASS] + " : " +
                             target[LOGOUT_TARGET_METHOD];
        String mailSmtp = getPropValue(LOGOUT_PROP_MAIL_SMTP);
        String mailPort = getPropValue(LOGOUT_PROP_MAIL_PORT);

        try {
    		Session session;
    		//セッション変数にセッションオブジェクトが設定済みの場合、
    		//オブジェクトを利用
    		//そうでない場合、新たにセッションオブジェクトを生成した上で利用
    		//同時アクセスの可能性があるので、クラスレベルでロック
			if(staticSession==null)
			{
	    		synchronized (LogOut.class)
	    		{
	    			if(staticSession==null)
	    			{
			        	// 現在のシステムプロパティを取得
	    				//system.getPropertiesから取得になっていたので、変更
			        	Properties pt = new Properties();

			        	// smtpサーバのアドレスをセット
			        	pt.put("mail.smtp.host" , mailSmtp);

			        	// smtpサーバのアドレスをセット
			    		pt.put("mail.host",mailSmtp);

			    		// smtpサーバのポート番号をセット
			    		pt.put("mail.smtp.port", mailPort);

			    		// Authenticatorオブジェクトをnullで誰でも使えるsessionを作成or取得
			    		staticSession = Session.getInstance(pt);//,null);
	    			}
    	        	session = staticSession;//,null);
				}
			}
			else
			{
	        	session = staticSession;//,null);
			}

        	// 空のメッセージオブジェクトを作成
        	MimeMessage mm = new MimeMessage(session);

        	// Fromアドレスをセット
        	mm.setFrom(new InternetAddress(mailFrom,mailFrom,"iso-2022-jp"));

        	// 内部クラスを通じて、Toアドレスをセット。Cc,Bccも設定可。
        	mm.setRecipients(Message.RecipientType.TO, mailTo);

        	// ヘッダーにコンテントタイプをセット。今回はプレーンテキストのみ。
        	mm.setHeader("Content-Type", "text/plain");

        	// Subjectをセット
        	mm.setSubject(mailSubject,"iso-2022-jp");

        	// 今回はテキストのみなのでsetContentは使わずsetTextでBody部をセット
        	mm.setText(msg,"iso-2022-jp");

        	// 送信日時をセット
        	mm.setSentDate(new Date());

        	// staticメソッドのsendを使って送信
        	Transport.send(mm);

        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            sw.flush();
        	out(LOGOUT_LEBEL_ERROR, target, "メール送信に失敗しました。" +
        			sw.toString());
        }


    } /*- error() -*/

    private static Session staticSession=null;

    /**
     *
     *<PRE>
     * 致命的ログ出力
     *</PRE>
     *
     * @since 1.0
     *
     * @param msg [in]出力内容
     *
     */
    public void fatal(String msg) {


        // ログ出力対象外
        if (!chkLogLevel(LOGOUT_LEBEL_FATAL)) {
            return;
        }

        // 呼び出し元情報取得
        String[] target = getTargetInfo();

        // ログ出力
        out(LOGOUT_LEBEL_FATAL, target, msg);


    } /*- fatal() -*/

    private String now()
    {
       SimpleDateFormat fmt = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
       java.util.Date dt = new java.util.Date();
       return fmt.format( dt );
    }

} /*- LogOut -*/

