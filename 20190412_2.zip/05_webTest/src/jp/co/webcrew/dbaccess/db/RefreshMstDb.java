package jp.co.webcrew.dbaccess.db;

import java.net.InetAddress;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * DBからの取得情報を定期的にリフレッシュするための基底クラス。
 * 
 * @author kurinami
 */
public abstract class RefreshMstDb implements Runnable {

	/** ロガー */
	private static final Logger log = Logger.getLogger(RefreshMstDb.class);

	/** リフレッシュが必要なdbクラスの一覧 */
	private static final Set refreshMstDbSet = new HashSet();

	/** リフレッシュ間隔 */
	private int masterRefreshMinutes = ValueUtil.toint(DBConnectionFactory
			.getDBProperty("masterRefreshMinutes"));

	/**
	 * コンストラクタ
	 */
	public RefreshMstDb() {
		// リフレッシュ間隔が指定されている場合、デーモンスレッドを起動する。
		if (masterRefreshMinutes > 0) {
			log.info("start daemon thread [" + this.getClass().getName() + "]");
			Thread thread = new Thread(this);
			thread.setDaemon(true);
			thread.start();
		}
	}

	/**
	 * 定期的にDBからの取得情報を更新する。
	 */
	public void run() {

		try {
			refreshMstDbSet.add(this);

			while (true) {
				try {
					init();
				} catch (SQLException e) {
					
					InetAddress addr = null;
					try
					{
						addr = InetAddress.getLocalHost();
						String hostname = addr.getHostName();
						
						log.info("ＨＯＳＴ名："+hostname);
						
						//host名をを「wcdev」infoレベルでのログ出力
						if(hostname.startsWith("wcdev")){
							log.info("DBエラー"+e);
						} else {
							log.error("DBエラー", e);
						}
					}
					catch (Exception exp)
					{
						log.error("DBエラー", exp);
					}
					
				}
				try {
					Thread.sleep(masterRefreshMinutes * 60 * 1000);
				} catch (InterruptedException e) {
					
					InetAddress addr = null;
					try
					{
						addr = InetAddress.getLocalHost();
						String hostname = addr.getHostName();
						
						log.info("ＨＯＳＴ名："+hostname);
						
						//host名をを「wcdev」infoレベルでのログ出力
						if(hostname.startsWith("wcdev")){
							log.info("予期せぬエラー"+e);
						} else {
							log.error("予期せぬエラー", e);
						}
					}
					catch (Exception exp)
					{
						log.error("予期せぬエラー", exp);
					}
					
				}
			}

		} finally {
			refreshMstDbSet.remove(this);
		}

	}

	/**
	 * 初期化処理を行う。
	 * 
	 * @throws SQLException
	 */
	abstract public void init() throws SQLException;

	/**
	 * リフレッシュが必要なものを全て強制的にリフレッシュする。
	 * 
	 * @throws SQLException
	 */
	public static void refreshForce() throws SQLException {
		RefreshMstDb[] refreshMstDbs = (RefreshMstDb[]) refreshMstDbSet
				.toArray(new RefreshMstDb[0]);

		for (int i = 0; i < refreshMstDbs.length; i++) {
			refreshMstDbs[i].init();
		}

	}

}
