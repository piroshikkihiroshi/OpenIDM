package jp.co.webcrew.phoenix.logic;

import java.util.Map;

/**
 * 項目変換ロジックの結果を保持するstatusクラス。
 * 
 * @author kurinami
 */
public class ItemConvLogicStatus extends BindLogicStdStatus {

    /** 項目ID に格納する結果文字列 */
    public Map<String, String[]> itemData;

}
