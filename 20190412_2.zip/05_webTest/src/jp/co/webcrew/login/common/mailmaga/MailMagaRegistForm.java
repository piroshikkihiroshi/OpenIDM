package jp.co.webcrew.login.common.mailmaga;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.util.StringUtil;

public class MailMagaRegistForm {

	//private static final Logger log = Logger.getLogger(MailMagaRegistForm.class);
	
	private String email			= "";
	private String selectEmail		= "";
	private String siteId			= "";
	private String message 			= "";
	private boolean messageFlag 	= false;
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getSelectEmail() {
		return selectEmail;
	}

	public void setSelectEmail(String selectEmail) {
		this.selectEmail = selectEmail;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isMessageFlag() {
		return messageFlag;
	}

	public void setMessageFlag(boolean messageFlag) {
		this.messageFlag = messageFlag;
	}

	/**
	 * validate the form
	 * @param request
	 */
	public void validate(HttpServletRequest request)
	{
		String strEmail = ValueUtil.nullToStr(getEmail());
		if ("".equals(strEmail))
		{
			strEmail = ValueUtil.nullToStr(getSelectEmail());
		}	
		
		// 必須チェック
		if(strEmail.equals("")) {
			setMessage("「E-mail」を正しくご入力ください。");
			setMessageFlag(true);
			return;
		}

		// Emailチェック
		if(! StringUtil.checkHankakuEisuu(strEmail)){
			setMessage("「E-mail」を正しくご入力ください。(半角英数のみ可)");
			setMessageFlag(true);
			return;
		}
	}
	
	/**
	 * populate the form bean from request
	 * @param request
	 */
	public void populate(HttpServletRequest request) 
	{
		setMessage("");
		setEmail(request.getParameter("email"));
		setSelectEmail(request.getParameter("selectEmail"));
		setSiteId(request.getParameter("siteId"));
	}	
}
