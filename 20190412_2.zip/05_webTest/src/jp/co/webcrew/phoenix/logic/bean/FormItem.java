package jp.co.webcrew.phoenix.logic.bean;

/**
 * form_item テーブル用
 * 
 * @author kurinami
 */
public class FormItem {
    public String site_id;
    public String form_id;
    public String item_id;
    public String group_id;
    public String sort_num;
    public char fixed_flag;
    public String type;
    public String title;
    public String caution1;
    public String caution2;
    public String caution3;
    public String caution4;
    public String caution5;
    public char require_flag;
    public int clm_size;
    public int row_size;
    public int least;
    public int most;
    public double min;
    public double max;
    public String limit_char;
    public String limit_regex;
    public char wchar_conv;
    public String date_time_type;
    public String date_time_sep;
    public String time_option;
    public String sel_mst_id;
    public int max_select;
    public char edit_kbn;
    public char del_kbn;
    public String up_datetime;
    public String up_admin;
}
