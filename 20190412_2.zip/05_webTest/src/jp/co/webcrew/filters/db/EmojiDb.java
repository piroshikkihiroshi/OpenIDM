package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;


/**
 * 絵文字を管理するためのdbクラス。
 * 
 */
public class EmojiDb extends RefreshMstDb
{ 
	//唯一のインスタンス
	private static EmojiDb objEmojiDb = new EmojiDb();
	
	//絵文字情報を保持するマップ(key=絵文字ID_キャリアID)
	private Map mapEmoji = new HashMap();
	
  /**
   * キャリア毎の文字コードを取得するためのSQL
   */
  private static final String SELECT_PICTURE_CHARACTER_MST = ""
    + "SELECT emoji_id, career_id, code FROM common.picture_character_mst ORDER BY emoji_id, career_id";
  
  /**
   * インスタンスを取得する
   * 
   * @return
   */
  public static EmojiDb getInstance()
  {
  	return objEmojiDb;
  }

  /**
   * キャリア毎の文字コードを取得する
   * 
   * @throws SQLException
   */
  public void init() throws SQLException
  {
		DBAccess dbAccess = null;
    ResultSet rs = null;
    try
    {
      dbAccess = new DBAccess();
      
      rs = dbAccess.executeQuery(SELECT_PICTURE_CHARACTER_MST);
      
      while (dbAccess.next(rs))
      {
      	String strKey = rs.getInt("emoji_id") + "_" + rs.getInt("career_id");      
        mapEmoji.put(strKey, rs.getString("code"));
      }
    }
    finally
    {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
  
  /**
   * 絵文字情報を保持したマップを取得する
   * 
   * @return
   */
  public Map getEmojiMap()
  {
  	return mapEmoji;
  }
  
  /**
   * 絵文字IDとキャリアIDが一致する絵文字コードを取得する
   * 
   * @param nEmojiId
   * @param nCarrerId
   * @return
   */
  public String getEmojiCode(int nEmojiId, int nCareerId)
  {
  	String strKey = nEmojiId + "_" + nCareerId;
  	
  	return (mapEmoji.get(strKey) == null) ? "" : (String)mapEmoji.get(strKey);
  }
}
