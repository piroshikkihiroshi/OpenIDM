package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * MOBILE用のアフィリエイトタグ、CVタグを出力するSSTagExecuterクラス。
 *
 * @author kiyoshi.higashide
 */
public class AffiliateTagMstExecuter extends SSTagExecuter
{
	private static final Logger log = Logger.getLogger(AffiliateTagMstExecuter.class);

	private static UrlSendThread urlSendThread = new UrlSendThread();

	static {
		urlSendThread.start();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response)
	{
		String siteId = ValueUtil.nullToStr((String)parameters.get("site_id"));
		String promCode = ValueUtil.nullToStr((String)parameters.get("prom_code"));
		String poSition = ValueUtil.nullToStr((String)parameters.get("position_code"));

		// サイトIDが指定されていない場合
		if (siteId.length() == 0)
		{
			log.error("パラメータエラー パラメータ[siteId]が指定されていません。");
			return "";
		}

		// プロモーションコードが指定されていない場合
		if (promCode.length() == 0)
		{
			log.error("パラメータエラー パラメータ[promCode]が指定されていません。");
			return "";
		}

		// 位置が指定されていない場合
		if (poSition.length() == 0)
		{
			log.error("パラメータエラー パラメータ[poSition]が指定されていません。");
			return "";
		}

		// ユーザーエージェントがない場合
		String strUserAgent = request.getHeader("user-agent");

		DBAccess dbAccess = null;

		String returnHTML = "";
		List<String> listHtmlTag = new ArrayList<String>();
		List<String> listOutputTag = new ArrayList<String>();
		List<String> listUrlsend = new ArrayList<String>();
		try
		{
			dbAccess = new DBAccess(true);

			String strFlg = getTonashibaDevHonbanFlg(dbAccess);

			// アフィリエイトタグ、CVタグを取得する(プロモコードが指定)
			listHtmlTag = getHtmlTag(siteId, promCode, poSition, dbAccess);

			// アフィリエイトタグ、CVタグを取得する(プロモコードがない)
			if (listHtmlTag.size() == 0)
			{
				listHtmlTag = getDefalutHtmlTag(siteId, poSition, dbAccess);
			}

			// アフィリエイトタグ、CVタグを取得する(常に出す)
			listHtmlTag = getAlltHtmlTag(siteId, poSition, dbAccess, listHtmlTag);

			for (int i = 0; i < listHtmlTag.size(); i++)
			{
				String strHensyu = (String)listHtmlTag.get(i);

				strHensyu = getHtmlHenkan(strHensyu);

				Set<String> keySet = parameters.keySet();
				Iterator<String> keyIte = keySet.iterator();
				while (keyIte.hasNext()) {
					String key = (String)keyIte.next();
					String value = (String)parameters.get(key);
					if (("site_id".equals(key)) ||
							("prom_code".equals(key)) ||
							("position_code".equals(key)) ||
							("type".equals(key)))
						continue;
					strHensyu = strHensyu.replace("###" + key + "###", value);
				}

				// ユーザーエージェントを置換する
				if ((strUserAgent != null) && (!"".equals(strUserAgent)))
				{
					strHensyu = strHensyu.replace("###mu###", strUserAgent);
				}

				listOutputTag.add(strHensyu);

				if (!"1".equals(strFlg)){
					// URLを取得する
					listUrlsend = getUrlHenkan(strHensyu);
					listUrlsend = getUrlCapitalHenkan(strHensyu, listUrlsend);

					// URLを送信する
					request.setAttribute(
							"webcrew_url_send",
							listUrlsend);

					urlSendThread.push(request, response);
				}
			}

			for (int i = 0; i < listOutputTag.size(); i++)
			{
				returnHTML = returnHTML + listOutputTag.get(i);
			}

		}
		catch (Exception objExp)
		{
			log.error("予期せぬエラー", objExp);
		}
		finally
		{
			DBAccess.close(dbAccess);
		}

		return returnHTML;
	}

	/**
	 * COMMON.AFFILIATE_TAG_MSTからデータを取得する。
	 *
	 * @param siteId
	 * @param promCode
	 * @param position
	 * @param dbAccess
	 * @return List
	 */
	private List<String> getHtmlTag(String siteId, String promCode, String position, DBAccess dbAccess)	throws SQLException
    {
		String strSql = "SELECT HTML_TAG FROM COMMON.AFFILIATE_TAG_MST WHERE SITE_ID=? AND PROM_CODE=? AND POSITION=? AND DELETE_DATE IS NULL AND START_DATE < sysdate AND (END_DATE IS NULL OR END_DATE > sysdate) ORDER BY SEQ ";

		ResultSet rset = null;
		List<String> retList = new ArrayList<String>();

		try
		{
			dbAccess.prepareStatement(strSql);
			dbAccess.setString(1, siteId);
			dbAccess.setString(2, promCode);
			dbAccess.setString(3, position);
			rset = dbAccess.executeQuery();
			while (dbAccess.next(rset)) {
				retList.add(rset.getString("HTML_TAG"));
			}

			return retList;
		}
		finally
		{
			DBAccess.close(rset);
		}
    }

	/**
	 *  COMMON.AFFILIATE_DEFAULT_TAG_MSTからデータを取得する。
	 *
	 * @param siteId
	 * @param position
	 * @param dbAccess
	 * @return List
	 */
	private List<String> getDefalutHtmlTag(String siteId, String position, DBAccess dbAccess) throws SQLException
    {
	  	String strSql = "SELECT HTML_TAG FROM COMMON.AFFILIATE_DEFAULT_TAG_MST WHERE SITE_ID=? AND POSITION=? AND DELETE_DATE IS NULL AND START_DATE < sysdate AND (END_DATE IS NULL OR END_DATE > sysdate) ORDER BY SEQ ";

	  	ResultSet rset = null;
	  	List<String> retList = new ArrayList<String>();

	  	try
    	{
	  		dbAccess.prepareStatement(strSql);
	  		dbAccess.setString(1, siteId);
	  		dbAccess.setString(2, position);
	  		rset = dbAccess.executeQuery();
	  		while (dbAccess.next(rset)) {
	  			retList.add(rset.getString("HTML_TAG"));
	  		}

	  		return retList;
    	}
	  	finally
	  	{
	  		DBAccess.close(rset);
	  	}
    }

	/**
	 * COMMON.AFFILIATE_ALL_TAG_MSTからデータを取得する。
	 *
	 * @param siteId
	 * @param position
	 * @param dbAccess
	 * @param retList
	 * @return List
	 */
	private List<String> getAlltHtmlTag(String siteId, String position, DBAccess dbAccess, List<String> retList) throws SQLException
	{
		String strSql = "SELECT HTML_TAG FROM COMMON.AFFILIATE_ALL_TAG_MST WHERE SITE_ID=? AND POSITION=? AND DELETE_DATE IS NULL AND START_DATE < sysdate AND (END_DATE IS NULL OR END_DATE > sysdate) ORDER BY SEQ ";

		ResultSet rset = null;

		try
		{
			dbAccess.prepareStatement(strSql);
			dbAccess.setString(1, siteId);
			dbAccess.setString(2, position);
			rset = dbAccess.executeQuery();
			while (dbAccess.next(rset)) {
				retList.add(rset.getString("HTML_TAG"));
			}

			return retList;
		}
		finally
		{
			DBAccess.close(rset);
		}
	}

	/**
	 * TONASHIBA.SYSTEM_PROPERTIESからデータを取得する。
	 *
	 * @param siteId
	 * @param position
	 * @param dbAccess
	 * @param retList
	 * @return List
	 */
	private String getTonashibaDevHonbanFlg(DBAccess dbAccess) throws SQLException
	{
		String strSql = "SELECT VALUE FROM TONASHIBA.SYSTEM_PROPERTIES WHERE NAME=? ";

		ResultSet rset = null;

		try
		{
			dbAccess.prepareStatement(strSql);
			dbAccess.setString(1, "SYSTEM_DEV_HONBAN_FLG");
			rset = dbAccess.executeQuery();
			while (dbAccess.next(rset)) {
				return rset.getString("VALUE");
			}

			return "1";
		}
		finally
		{
			DBAccess.close(rset);
		}
	}

	/**
	 * <img.+?/>|<IMG.+?/>|<img.+?>|<IMG.+?> の部分をコメント(<!-- -->)にする。
	 *
	 * @param htmlTag
	 * @return String
	 */
	private String getHtmlHenkan(String htmlTag) throws IllegalStateException, IndexOutOfBoundsException
	{
		String strResult = htmlTag;

		Pattern p = Pattern.compile("(<img.+?/>|<IMG.+?/>|<img.+?>|<IMG.+?>)");
		Matcher m = p.matcher(htmlTag);

		while (m.find())
		{
			strResult = strResult.replace(m.group(1), "<!--" + m.group(1) + "-->");
		}

		return strResult;
	}

	/**
	 * src=以降 を抜き出す。
	 *
	 * @param strUrl
	 * @return List
	 */
	private List<String> getUrlHenkan(String strUrl) throws IllegalArgumentException, IndexOutOfBoundsException
	{
		List<String> listHenkan = new ArrayList<String>();

		Pattern p = Pattern.compile("src=\"(.+?)\"");
		Matcher m = p.matcher(strUrl);

		while (m.find())
		{
			listHenkan.add(m.group(1));
		}

		return listHenkan;
	}

	/**
	 * SRC=以降 を抜き出す。
	 *
	 * @param strUrl
	 * @param retList
	 * @return List
	 */
	private List<String> getUrlCapitalHenkan(String strUrl, List<String> retList) throws IllegalArgumentException, IndexOutOfBoundsException
	{
		Pattern p = Pattern.compile("SRC=\"(.+?)\"");
		Matcher m = p.matcher(strUrl);

		while (m.find())
		{
			retList.add(m.group(1));
		}

		return retList;
	}

}
