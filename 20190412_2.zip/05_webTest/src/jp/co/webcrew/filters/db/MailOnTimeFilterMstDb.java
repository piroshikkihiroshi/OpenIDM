package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;


/****
 * 即時配信定義(mailontime_filter_mst)をキャッシュするために用意したクラス
 * 
 * @author kazuto.yano
 *
 */
public class MailOnTimeFilterMstDb extends RefreshMstDb
{
	
	private static final MailOnTimeFilterMstDb thisClassObject=new MailOnTimeFilterMstDb();
	private static final Logger logger=Logger.getLogger(MailOnTimeFilterMstDb.class);
	
	private static final String DB_PROP="";
	//private static final String DB_PROP="stepengine";
	
	private Map<FilterMstKey,List<FilterMstBean> > mapFilterMstBean;
	
	private boolean passFirstAction=false;
	
	private MailOnTimeFilterMstDb()
	{
		super();
	}
	
	@Override
	public void init() throws SQLException 
	{
		DBAccess dbAccess=null;
		try
		{
			logger.debug("即時配信情報取得 開始");
			//logger.debug("即時配信情報取得 開始");
			dbAccess=new DBAccess(DB_PROP);
			Map<FilterMstKey,List<FilterMstBean>> map=this.getFilterMstBeans(dbAccess);
			
			//データの取得が完了した時点で、インスタンス変数の差し替えを行う
			this.mapFilterMstBean=map;
			if(!passFirstAction)
			{
				logger.info(this.getClass().getSimpleName()+"初期化完了[変数の中身の有無]"+(this.mapFilterMstBean!=null));
			}
			passFirstAction=true;
			
		}
		catch(Exception exc)
		{
			logger.error("mail_ontime_filter_mstの取得に失敗しました。"+exc.getMessage(),exc);
		}
		finally
		{
			DBAccess.close(dbAccess);
		}
		
		
	}
	
	
	/***
	 * 送信するメール情報を取得する
	 * 
	 * 
	 * @param dbAccess 
	 * @param siteId サイトID
	 * @param requestUri リクエストURI
	 * @return
	 * @throws SQLException
	 */
	private Map<FilterMstKey,List<FilterMstBean>> getFilterMstBeans(DBAccess dbAccess)
	throws SQLException
	{
		ResultSet rset=null;
		//String sqlFilterMaster="select * from stepengine.mail_ontime_filter_mst f where invalid_flag=0 order by step_site_id,request_uri,order_no";
		String sqlFilterMaster="select * from stepengine.mail_ontime_filter_mst f where invalid_flag=0 order by order_no";
		try
		{
			
			logger.debug("mail_ontime_filter_mstへの問合せ");
			
			dbAccess.prepareStatement(sqlFilterMaster);
			
			rset=dbAccess.executeQuery();
			
			
			//List<FilterMstBean> listMstBean=new ArrayList<FilterMstBean>();
			Map<FilterMstKey,List<FilterMstBean>> mapFilterMstBean=new HashMap<MailOnTimeFilterMstDb.FilterMstKey, List<FilterMstBean>>(); 
			
			while(rset.next())
			{
			
				FilterMstBean bean=new FilterMstBean();
				bean.stepSiteId=rset.getLong("step_site_id");
				bean.requestUri=ValueUtil.nullToStr(rset.getString("request_uri"));
				bean.mailType=ValueUtil.nullToStr(rset.getString("mail_type"));
				bean.sqlFetch=ValueUtil.nullToStr(rset.getString("sql_fetch"));
				bean.sqlInsertTpl=ValueUtil.nullToStr(rset.getString("sql_insert"));
				bean.sqlBadUserTpl=ValueUtil.nullToStr(rset.getString("sql_bad_user"));
				bean.sqlTestUserTpl=ValueUtil.nullToStr(rset.getString("sql_test_user"));
				bean.getVarName=ValueUtil.nullToStr(rset.getString("get_var_name"));
				bean.sqlPendingJobTpl=ValueUtil.nullToStr(rset.getString("sql_pending_job"));
				bean.sqlSentLogTpl=ValueUtil.nullToStr(rset.getString("sql_sent_log"));
				
				FilterMstKey key=new FilterMstKey(bean.stepSiteId, bean.requestUri);
				
				List<FilterMstBean> listBean=mapFilterMstBean.get(key);
				if(listBean==null)
				{
					listBean=new ArrayList<MailOnTimeFilterMstDb.FilterMstBean>();
					mapFilterMstBean.put(key, listBean);
				}
				listBean.add(bean);
				
			}
			return mapFilterMstBean;
		}
		finally
		{
			DBAccess.close(rset);
		}
	}
	
	/****
	 * 指定したページで送信すべき即時配信情報の一覧を取得する
	 * 
	 * @param stepSiteId サイトID
	 * @param requestUri リクエストURI
	 * @return
	 */
	public List<FilterMstBean> getFilterMstBean(long stepSiteId,String requestUri)
	{
		FilterMstKey findKey=new FilterMstKey(stepSiteId, requestUri);
		List<FilterMstBean> list=this.mapFilterMstBean.get(findKey);
		return list;
		
	}
	
	
	/***
	 * 
	 * @return
	 */
	public static MailOnTimeFilterMstDb getInstance()
	{
		return thisClassObject;
	}
	
	
	/***
	 * インスタンス変数「mapFilterMstBean」のマップキーとして使用することを想定したクラス
	 * このクラス以外で使うことはないので、private属性を付けている。
	 * 
	 * @author kazuto.yano
	 */
	private static class FilterMstKey
	{
		private final long stepSiteId;
		private final String requestUri;
		private int __hashCode;
		
		
		public FilterMstKey(long stepSiteId,String requestUri)
		{
			this.stepSiteId=stepSiteId;
			this.requestUri=requestUri.toLowerCase();
			this.__hashCode=(this.stepSiteId+"@"+this.requestUri).hashCode();
		}
		
		@Override
		public int hashCode() 
		{
			return this.__hashCode;
		}
		
		@Override
		public boolean equals(Object obj) 
		{
			if(!(obj instanceof FilterMstKey))
			{
				return false;
			}
			FilterMstKey other=(FilterMstKey)obj;
			if(this.stepSiteId==other.stepSiteId && this.requestUri.equals(other.requestUri))
			{
				return true;
			}
			return false;
		}
		
	}

	/***
	 * インスタンス変数「mapFilterMstBean」のマップ値として使用することを想定したクラス
	 * このクラス以外でも使うので、public属性を付けている。
	 * 
	 * @author kazuto.yano
	 *
	 */
	public static class FilterMstBean 
	{
		public long stepSiteId;
		public String requestUri;
		public String mailType;
		public String sqlFetch;
		public String sqlInsertTpl;
		public String sqlBadUserTpl;
		public String sqlTestUserTpl;
		public String getVarName;
		public String sqlPendingJobTpl;
		public String sqlSentLogTpl;
		
		@Override
		public String toString() 
		{
			return "[mailtype]"+mailType+"[varName]"+getVarName;
		}
		
	}
	
	/*
	public static void main(String[] args) 
	throws Exception
	{
		MailOnTimeFilterMstDb mstdb=MailOnTimeFilterMstDb.getInstance();
		
		mstdb.init();
		List<FilterMstBean> list;
		list=mstdb.getFilterMstBean(3300, "/test/test");
		System.out.println("[list]"+list);
		list=mstdb.getFilterMstBean(3300, "/step/skaifuku/answerconfirm.htm");
		System.out.println("[list]"+list);
		
	}
*/
	
	private static void __main(String[] args) 
	throws Exception
	{
		MailOnTimeFilterMstDb db=MailOnTimeFilterMstDb.getInstance();
		//.init();
		db.init();
		List<FilterMstBean> list=db.getFilterMstBean(3001, "/step/hikkoshi/answerconfirm.htm");
		System.out.println(list);
		
	}
	
}


