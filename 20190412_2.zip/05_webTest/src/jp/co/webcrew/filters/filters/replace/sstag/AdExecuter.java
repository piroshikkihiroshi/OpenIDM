package jp.co.webcrew.filters.filters.replace.sstag;

import java.net.URLEncoder;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.filters.replace.AdDb;
import jp.co.webcrew.filters.filters.replace.replacer.HttpProtocolReplacer;
import jp.co.webcrew.filters.util.ReplaceFilterUtil;

/**
 * 広告を表示するExecuterクラス。
 * 
 * @author kurinami
 */
public class AdExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(AdExecuter.class);

	/** 広告種別：テキスト */
	private static final int TYPE_TEXT = 1;

	/** 広告種別：画像 */
	private static final int TYPE_IMAGE = 2;

	/** 広告種別：flash */
	private static final int TYPE_FLASH = 3;

	/** 広告種別：html */
	private static final int TYPE_HTML = 4;

	/** system_properties上のクリック履歴計測用のURL */
	private static final String CLICK_LOG_URL_TEMPLATE = "CLICK_LOG_URL_TEMPLATE";

	/** テキスト用出力テンプレート */
	private static final String TEMPLATE_TEXT = "<a href=\"{0}\" target=\"_blank\">{1}</a>";

	/** 画像用出力テンプレート */
	private static final String TEMPLATE_IMAGE = "<a href=\"{0}\" target=\"_blank\"><img src=\"{1}\" {2} {3} alt=\"{4}\"></a>";

	/** flash用出力テンプレート */
	private static final String TEMPLATE_FLASH = ""
			+ "<div style=\"margin-bottom:9px;\">\n"
			+ "<script language=\"javascript\">\n"
			+ "<!--\n"
			+ "writeflash(\"_swf={0}\",\"_width={1}\",\"_height={2}\",\"_quality=high\",\"_bgcolor=#FFFFFF\",\"_clickTAG={3}\");\n"
			+ "-->\n" 
			+ "</script>\n"
			+ "</div>\n";

	/** インプレッションログ出力用スレッド */
	private static AdThread adThread;
	
	private static final String ALLOW_IP_ADDRESS = "ALLOW_IP_ADDRESS";
	
	static {
		// インプレッションログ出力スレッドを開始する。
		adThread = new AdThread();
		adThread.start();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {

		try {

			String spaceId = ValueUtil.nullToStr(parameterMap.get("space_id"));
			int siteId = SiteMstDb.getInstance().getSiteId(request.getRequestURL().toString());
			String codes = ValueUtil.nullToStr(parameterMap.get("codes"));
			int pageSpaceNum = ValueUtil.toint((String) parameterMap
					.get("page_space_num"));

			// 場所IDが指定されていない場合、
			if (spaceId.length() == 0 && codes.length() > 0) {
				// 場所IDを検索する。
				spaceId = ValueUtil.nullToStr(AdDb.getSpaceId(siteId, codes
						.split("/"), pageSpaceNum));
				log.info("場所IDを検索  site_id[" + siteId + "] codes[" + codes
						+ "] page_space_num[" + pageSpaceNum + "] -> space_id["
						+ spaceId + "]");
			}

			// 場所IDが見つけられなかった場合、
			if (spaceId.length() == 0) {
				return "";
			}

			//IPアドレスを取得
			String strIpAddress = ValueUtil.nullToStr(request.getRemoteAddr());
			
			String fromAdman = ValueUtil.nullToStr(request.getParameter("from_adman"));
			log.info("fromAdman：" + fromAdman);
			boolean fromAdmanFlag = false;
			if (!fromAdman.equals("") && isAllowIpAddress(strIpAddress)) {
			    fromAdmanFlag = new Boolean(fromAdman).booleanValue();
			}
			
			// 広告情報を取得する。
			Map map = AdDb.getAdDetail(spaceId);

			if (map != null) {

				String imgPathPrefix = (String) map.get("imgPathPrefix");
				int spaceWidth = ((Integer) map.get("spaceWidth")).intValue();
				int spaceHeight = ((Integer) map.get("spaceHeight")).intValue();
				int adWindowId = ((Integer) map.get("adWindowId")).intValue();
				String adId = (String) map.get("adId");
				int adType = ((Integer) map.get("adType")).intValue();
				int width = ((Integer) map.get("width")).intValue();
				int height = ((Integer) map.get("height")).intValue();
				String image1 = (String) map.get("image1");
				String altText1 = (String) map.get("altText1");
				String linkUrl1 = URLEncoder.encode((String) map
						.get("linkUrl1"), "UTF-8");
				String fixedHtml = (String) map.get("fixedHtml");

				log.info("広告が決定 space_id[" + spaceId + "] ad_id[" + adId
						+ "] ad_window_id[" + adWindowId + "] ad_type["
						+ adType + "] site_id[" + siteId + "]");

				String content = "";
				String clickLogUrlTemplate = "";
				String clickLogUrl = "";
				String widthStr = "";
				String heightStr = "";

				// 広告の種別ごとにhtmlを組み立てる。
				switch (adType) {
				case TYPE_TEXT:

					// クリック計測ができるように遷移先URLを組み立てる。
					clickLogUrlTemplate = SystemPropertiesDb.getInstance().get(
							CLICK_LOG_URL_TEMPLATE);
					clickLogUrl = new MessageFormat(clickLogUrlTemplate)
							.format(new String[] { linkUrl1, spaceId,
									Integer.toString(adWindowId), adId,
									Integer.toString(siteId) });

					// 広告htmlを組み立てる。
					content = new MessageFormat(TEMPLATE_TEXT)
							.format(new String[] { clickLogUrl, fixedHtml });
					break;

				case TYPE_IMAGE:

					// クリック計測ができるように遷移先URLを組み立てる。
					clickLogUrlTemplate = SystemPropertiesDb.getInstance().get(
							CLICK_LOG_URL_TEMPLATE);
					clickLogUrl = new MessageFormat(clickLogUrlTemplate)
							.format(new String[] { linkUrl1, spaceId,
									Integer.toString(adWindowId), adId,
									Integer.toString(siteId) });

					// 画像のサイズが場所のサイズを超えている場合、
					if (spaceWidth != 0 && spaceHeight != 0
							&& (width > spaceWidth || height > spaceHeight)) {

						// 縦横比を維持するために、超過率の高いほうだけ指定する。;
						if (width / spaceWidth > height / spaceHeight) {
							widthStr = "width=" + spaceWidth;
						} else {
							heightStr = "height=" + spaceHeight;
						}
					}
					
					String protocol   = HttpProtocolReplacer.isSsl(request) ? "https://" : "http://";
					String serverName = ReplaceFilterUtil.getActualServerName(request);
					
                    // 広告htmlを組み立てる。
                    content = new MessageFormat(TEMPLATE_IMAGE)
                            .format(new String[] { clickLogUrl,
                                    protocol + serverName + imgPathPrefix + image1, widthStr,
                                    heightStr, altText1 });
					
					break;

				case TYPE_FLASH:

					// クリック計測ができるように遷移先URLを組み立てる。
					clickLogUrlTemplate = SystemPropertiesDb.getInstance().get(
							CLICK_LOG_URL_TEMPLATE);
					clickLogUrl = new MessageFormat(clickLogUrlTemplate)
							.format(new String[] { linkUrl1, spaceId,
									Integer.toString(adWindowId), adId,
									Integer.toString(siteId) });

					// 場所のサイズとflash自身のサイズでそれぞれ小さいほうを指定する。
					widthStr = Integer.toString(Math.min(spaceWidth, width));
					heightStr = Integer.toString(Math.min(spaceHeight, height));

					// 広告htmlを組み立てる。
					content = new MessageFormat(TEMPLATE_FLASH)
							.format(new String[] { imgPathPrefix + image1,
									widthStr, heightStr, clickLogUrl });
					break;

				case TYPE_HTML:
					content = (String) map.get("fixedHtml");
					break;
				}

                if (fromAdmanFlag)
                {
                    content += "<table>"
                              + "<tr><td><strong style=\"color:#F00;\">↑場所ＩＤ：" + spaceId + "、広告ＩＤ：" + map.get("adId") + "<strong>↑</strong></td></tr></table>";
                }
				
				// インプレッションログを出力する。
				request.setAttribute(AdThread.AD_THREAD_AD_ID_ATTR_KEY, adId);
				request.setAttribute(AdThread.AD_THREAD_AD_WINDOW_ID_ATTR_KEY, new Integer(adWindowId));
				request.setAttribute(AdThread.AD_THREAD_SPACE_ID_ATTR_KEY, spaceId);
				adThread.push(request, response);

				return content;
			} else {
				log.info("広告が未決定 space_id[" + spaceId + "]");
				return "";
			}

		} catch (SQLException e) {
			log.error("DBエラー", e);
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		return "";

	}

	/**
	 * 
	 * @param strIpAddress
	 * @return
	 */
	private boolean isAllowIpAddress(String strIpAddress)
	{
		strIpAddress = strIpAddress.replaceAll("\\.", "@");
		
		//テストモード(広告の下に場所IDなどを表示する)を許可するIPアドレスを取得
		String strAllowIpAddress = SystemPropertiesDb.getInstance().get(ALLOW_IP_ADDRESS);
		
		strAllowIpAddress = strAllowIpAddress.replaceAll("\\.", "@");
		strAllowIpAddress = strAllowIpAddress.replaceAll("\\*", "[\\.0-9]{0,}");
		
		log.info("ip=" + strIpAddress + ", allow=" + strAllowIpAddress);
		
		Pattern objPattern = Pattern.compile(strAllowIpAddress);
		Matcher objMatcher = objPattern.matcher(strIpAddress);
		
		if (objMatcher.matches())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
