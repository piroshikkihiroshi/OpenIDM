package jp.co.webcrew.phoenix.sstag.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;

/**
 * フォーム担当者を管理するdbクラス。
 * 
 * @author kurinami
 */
public class FormActStaffDb {

    /** フォーム担当者E-mailの一覧を取得するためのsql */
    private static final String SELECT_STAFF_EMAIL_LIST = ""
            + "select staff_email from (schema_name).form_act_staff where site_id = ? and form_id = ? and staff_email is not null order by num ";

    /**
     * フォーム担当者E-mailの一覧を返す。
     * 
     * @param siteId
     * @param formId
     * @return
     * @throws SQLException
     */
    public static String[] getStaffEmails(int siteId, String formId) throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            List<String> staffEmailList = new ArrayList<String>();

            // フォーム担当者E-mailの一覧を取得する。
            dbAccess.prepareStatement(SELECT_STAFF_EMAIL_LIST);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, formId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                staffEmailList.add(ValueUtil.nullToStr(rs.getString("staff_email")));
            }

            return staffEmailList.toArray(new String[0]);

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }
    }

}
