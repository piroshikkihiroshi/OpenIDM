package jp.co.webcrew.logic.lib._02_work;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.BindLogicStdStatus;
import jp.co.webcrew.phoenix.logic.ItemConvLogicStatus;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import net.arnx.jsonic.JSON;

public class Kadai_3_2_LogicSearchDebug extends SstagDynamicLogic {

	Logger logger = Logger.getLogger(Kadai_3_2_LogicSearchDebug.class);

	public static void main(String[] args) {
		String strDriver = "oracle.jdbc.OracleDriver";
		String strUrli = "jdbc:oracle:thin:@10.81.50.164:1521:cairo";
		String strUser = "tatsuya.ueda";
		String strPassword = "gomainu55";

		//member変数
		ResultSet objRs = null;
		int intCnt = 0;
		String strOutJson = "";
		Kadai_3_2_UserBean objBean = null;
		List<Kadai_3_2_UserBean> listBean = new ArrayList<Kadai_3_2_UserBean>();
		//update delete対象
		String strUpdateOrderId = "2";
		//検索対象初期化
		String strORDER_ID = "";
		String strNAME_KANJI_1="上田";
		String strNAME_KANJI_2="";
		String strNAME_KANA_1="";
		String strNAME_KANA_2="";
		String strEMAIL="";
		String strTEL="";
		boolean blPrepare = false;


		//sql作成
		String strSql = "";
		strSql += "SELECT  ";
		strSql += "  ORDER_ID";
		strSql += "  , NAME_KANJI_1";
		strSql += "  , NAME_KANJI_2";
		strSql += "  , NAME_KANA_1";
		strSql += "  , NAME_KANA_2";
		strSql += "  , EMAIL";
		strSql += "  , TEL";
		strSql += "  , CONTACT ";
		strSql += "  , DELETE_FLG ";
		strSql += "FROM ";
		strSql += " \"TATSUYA.UEDA\".ORDER_INFO ";
		strSql += " WHERE DELETE_FLG = 0 ";

		//Where
		if (!strUpdateOrderId.equals("")) {strSql += " AND ORDER_ID = ? AND "; blPrepare = true;}
		if (!strORDER_ID.equals("")) {strSql += " AND ORDER_ID = ? AND "; blPrepare = true;}
		if (!strNAME_KANJI_1.equals("")) {strSql += " AND NAME_KANJI_1 = ? AND "; blPrepare = true;}
		if (!strNAME_KANJI_2.equals("")) {strSql += " AND NAME_KANJI_2 = ? AND "; blPrepare = true;}
		if (!strNAME_KANA_1.equals("")) {strSql += " AND NAME_KANA_1 = ? AND "; blPrepare = true;}
		if (!strNAME_KANA_2.equals("")) {strSql += " AND NAME_KANA_2 = ? AND "; blPrepare = true;}
		if (!strEMAIL.equals("")) {strSql += " AND EMAIL = ? AND "; blPrepare = true;}
		if (!strTEL.equals("")) {strSql += " AND TEL = ? AND "; blPrepare = true;}

		if(blPrepare) {
//			strSql = andなくすところから
		} //if

		try {
			Class.forName(strDriver);
			Connection objCon = DriverManager.getConnection(strUrli,
					strUser, strPassword);

			objCon.setAutoCommit(false); //一応明示的にオートコミット切る
			PreparedStatement objPs = null;

			try {

				objPs = objCon.prepareStatement(strSql);

				//UPDATE_TGT
				if (!strUpdateOrderId.equals("")) {
					int intUpdateOrderId = Integer.parseInt(strUpdateOrderId);
					objPs.setInt(1,intUpdateOrderId) ;
				} //if
				objRs = objPs.executeQuery();
				while (objRs.next()) {
					objBean = new Kadai_3_2_UserBean();
					objBean.setORDER_ID(objRs.getInt("ORDER_ID"));
					objBean.setNAME_KANJI_1(objRs.getString("NAME_KANJI_1"));
					objBean.setNAME_KANJI_2(objRs.getString("NAME_KANJI_2"));
					objBean.setNAME_KANA_1(objRs.getString("NAME_KANA_1"));
					objBean.setNAME_KANA_2(objRs.getString("NAME_KANA_2"));
					objBean.setEMAIL(objRs.getString("EMAIL"));
					objBean.setTEL(objRs.getString("TEL"));
					listBean.add(objBean);
					intCnt++;
				} //while

				//			logger.info("commit success");
			} catch (SQLException e) {
				//			logger.error("SQLException Error", e);
				objCon.rollback(); //ロールバック処理
				throw e;
			} finally {
				//クローズ処理
				if (objPs != null)
					objPs.close();
				if (objCon != null)
					objCon.close();

			} //try SQLException
		} catch (Exception e) {
			//		logger.error("Unexpect Error", e);
			e.printStackTrace();
		} //try Exception
		strOutJson = JSON.encode(listBean);
		System.out.println(JSON.encode(listBean));
	} // main

	//Trainingの検索ロジック
	@Override
	public BindLogicStdStatus stdLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam, List<String> userParam,
			FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo) {

		String strDriver = "oracle.jdbc.OracleDriver";
		String strUrli = "jdbc:oracle:thin:@10.81.50.164:1521:cairo";
		String strUser = "tatsuya.ueda";
		String strPassword = "gomainu55";

		//member変数
		int intSiteId = 91076;
		PhoenixDBAccess objDbAccess = null;

		logger.info("サイトInfo：" + JSON.encode(sgInfo));
		//sql作成
		String strSql = "";
		strSql += "INSERT ";
		strSql += "INTO \"TATSUYA.UEDA\".ORDER_INFO(";
		strSql += "  ORDER_ID";
		strSql += "  , NAME_KANJI_1";
		strSql += "  , NAME_KANJI_2";
		strSql += "  , NAME_KANA_1";
		strSql += "  , NAME_KANA_2";
		strSql += "  , EMAIL";
		strSql += "  , TEL";
		strSql += "  , CONTACT ";
		strSql += "  , DELETE_FLG ";
		strSql += ") ";
		strSql += "VALUES ( ";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?";
		strSql += ")";

		try {
			Class.forName(strDriver);
			Connection objCon = DriverManager.getConnection(strUrli,
					strUser, strPassword);

			objCon.setAutoCommit(false); //一応明示的にオートコミット切る
			objDbAccess = new PhoenixDBAccess(intSiteId);
			logger.info("phoenixInfo：" + objDbAccess.getPhoenixSchema());
			objDbAccess.setAutoCommit(false); //一応明示的にオートコミット切る

			try {
				objDbAccess.prepareStatement(strSql);
				objDbAccess.setInt(1, 6);
				objDbAccess.setString(2, "value2");
				objDbAccess.setString(3, "value3");
				objDbAccess.setString(4, "value4");
				objDbAccess.setString(5, "value5");
				objDbAccess.setString(6, "value6");
				objDbAccess.setString(7, "value7");
				objDbAccess.setInt(8, 1);
				objDbAccess.setInt(9, 0);

				int intCnt = objDbAccess.executeUpdate();
				objDbAccess.commit();
				logger.info("commit success");
			} catch (SQLException e) {
				logger.error("SQLException Error", e);
				objDbAccess.rollback(); //ロールバック処理
				throw e;
			} finally {
				//クローズ処理
				if (objDbAccess != null)
					DBAccess.close(objDbAccess);
			} //try SQLException
		} catch (Exception e) {
			logger.error("Unexpect Error", e);
			e.printStackTrace();
		} //try Exception

		//statusは必須
		BindLogicExtStatus objStatus = new BindLogicExtStatus();

		return objStatus;

	} // stdLogic

	@Override
	public BindLogicExtStatus validationLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public JudgementLogicStatus judgementLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public ItemConvLogicStatus itemConvLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String sub1,
			String sub2, String result) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
