package jp.co.webcrew.phoenix.sstag.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.sstag.bean.SelectItemBean;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * 選択肢マスタを管理するdbクラス。
 * 
 * @author kurinami
 */
public class SelectMstDb {

    /** 選択肢候補データの一覧を取得するためのsql */
    private static final String SELECT_ITEM_LIST = ""
            + "select * from (schema_name).select_item where site_id = ? and sel_mst_id = ? order by sort_num ";

    /**
     * 選択肢候補データの一覧を取得する。
     * 
     * @param request
     * @param siteId
     * @param selMstId
     * @return
     * @throws SQLException
     */
    public static List<SelectItemBean> getItemList(HttpServletRequest request, int siteId, String selMstId)
            throws SQLException {

        // リクエスト内に選択肢マスタがすでに保持されていないかを調べる。
        String key = siteId + selMstId;
        List<SelectItemBean> list = StoreUtil.getSelectMst(request, key);
        if (list != null) {
            // 保持されていれば、それをそのまま使用する。
            return list;
        }

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            list = new ArrayList<SelectItemBean>();

            // 選択肢候補一覧を取得する。
            dbAccess.prepareStatement(SELECT_ITEM_LIST);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, selMstId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                SelectItemBean selectItem = new SelectItemBean();
                selectItem.setSiteId(rs.getInt("site_id"));
                selectItem.setSelMstId(ValueUtil.nullToStr(rs.getString("sel_mst_id")));
                selectItem.setSortNum(rs.getInt("sort_num"));
                selectItem.setName(ValueUtil.nullToStr(rs.getString("name")));
                selectItem.setValue(ValueUtil.nullToStr(rs.getString("value")));
                selectItem.setImage(ValueUtil.nullToStr(rs.getString("image")));
                list.add(selectItem);
            }

            // リクエスト内に取得した選択肢マスタを保持しておく。
            StoreUtil.setSelectMst(request, key, list);
            return list;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * 選択肢マスタテーブル以外のテーブルの値を選択肢にする場合
     * 
     * @param request
     * @param propKey
     * @return
     * @throws SQLException
     */
    public static List<SelectItemBean> getItemList(HttpServletRequest request, String propKey) throws SQLException {

        // リクエスト内に選択肢マスタがすでに保持されていないかを調べる。
        String key = propKey;
        List<SelectItemBean> list = StoreUtil.getSelectMst(request, key);
        if (list != null) {
            // 保持されていれば、それをそのまま使用する。
            return list;
        }

        String propValue = SystemPropertiesDb.getInstance().get(propKey);
        if (PhoenixUtil.isEmpty(propValue)) {
            throw new SQLException("system_propertiesに[" + propKey + "]が設定されていません。");
        }
        String[] mst = PhoenixUtil.split(propValue, ",");
        if (mst.length != 3 || PhoenixUtil.isEmpty(mst[0]) || PhoenixUtil.isEmpty(mst[1])
                || PhoenixUtil.isEmpty(mst[2])) {
            throw new SQLException("system_propertiesの" + propKey + "の値[" + propValue + "]が不正です。");
        }

        String tableName = mst[0];
        String valueColName = mst[1];
        String nameColName = mst[2];

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess("phoenix");

            list = new ArrayList<SelectItemBean>();

            // 選択肢候補一覧を取得する。
            rs = dbAccess.executeQuery("select * from " + tableName);
            while (dbAccess.next(rs)) {
                SelectItemBean selectItem = new SelectItemBean();
                selectItem.setSiteId(0);
                selectItem.setSelMstId("");
                selectItem.setSortNum(0);
                selectItem.setName(ValueUtil.nullToStr(rs.getString(nameColName)));
                selectItem.setValue(ValueUtil.nullToStr(rs.getString(valueColName)));
                selectItem.setImage("");
                list.add(selectItem);
            }

            // リクエスト内に取得した選択肢マスタを保持しておく。
            StoreUtil.setSelectMst(request, key, list);
            return list;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }
    
    /**
     * セレクトマスタの値が数値だけで構成されているかをチェックする。
     * 
     * @param siteId
     * @param selMstId
     * @return
     * @throws SQLException
     */
    public static boolean isNumberValue(int siteId, String selMstId) throws SQLException {

        // 選択肢マスタが指定されていない場合、
        if (PhoenixUtil.isEmpty(selMstId)) {
            return false;
        }
        
        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            // 選択肢候補一覧を順に調べる。
            dbAccess.prepareStatement(SELECT_ITEM_LIST);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, selMstId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                String value = ValueUtil.nullToStr(rs.getString("value"));
                try {
                    // 数値化のチェックをする。
                    Double.parseDouble(value);
                } catch (NumberFormatException e) {
                    // 1つでも数値でなかった場合、
                    return false;
                }
            }

            // 全てが数値だった場合、
            return true;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }
}
