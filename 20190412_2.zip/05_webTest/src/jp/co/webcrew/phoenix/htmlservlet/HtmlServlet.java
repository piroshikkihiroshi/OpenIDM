package jp.co.webcrew.phoenix.htmlservlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.util.ReplaceFilterUtil;
import jp.co.webcrew.log4wc.LogOut;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.htmlservlet.Empty;
import jp.co.webcrew.htmlservlet.HtmlServletLogger;
import jp.co.webcrew.phoenix.htmlservlet.HtmlServletUtil;
import jp.co.webcrew.phoenix.htmlservlet.HttpEntry;
import jp.co.webcrew.phoenix.htmlservlet.UriAliasMstUtil.UrlReplaceStatus;
import jp.co.webcrew.phoenix.htmlservlet.db.UriAliasMstDB;

/**
 * <pre>
 * データベースからhtmlを読み込んで表示するためのサーブレット。
 * DefaultServletをオーバーライドするためのもの。
 * </pre>
 * 
 * @author Takahashi
 * 
 */
public class HtmlServlet extends HttpServlet
{

	int	ouput_buffer	= 256;
	
	/****
	 * URL擬似静的化のアクティブ、ディアクティブを管理するために用意したフラグ
	 * 
	 */
	public static final boolean URL_STATIC_FUNC_ON=true;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{

		// Serve the requested resource, including the data content
		serveResource(request, response, true);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException,
			ServletException
	{

		doGet(request, response);
	}

	private String getSiteId(HttpServletRequest request)
	{

		return ValueUtil.nullToStr(request.getAttribute("faon.site_id"));

	}

	// private String createLogMsg(HttpServletRequest request ,
	// HttpServletResponse response , String url , String code) {
	// return "[HtmlServlet] " + request.getMethod() + " site(" +
	// getSiteId(request) + ") " + url + " " + code;
	// }

	private void response404(HttpServletRequest request, HttpServletResponse response, String url) throws IOException,
			ServletException
	{
		//HtmlServletLogger.info("[HtmlServlet] " + request.getMethod() + " site(" + getSiteId(request) + ") " + url + " 404");
		HtmlServletLogger.accesslog_tempSaveInfo(request,404);
		showErrorPage(request, response, "404");
	}

	private void response403(HttpServletRequest request, HttpServletResponse response, String url) throws IOException,
			ServletException
	{
		//HtmlServletLogger.info("[HtmlServlet] " + request.getMethod() + " site(" + getSiteId(request) + ") " + url + " 403");
		HtmlServletLogger.accesslog_tempSaveInfo(request,403);
		showErrorPage(request, response, "403");
	}

	private void response500(HttpServletRequest request, HttpServletResponse response, String url) throws IOException,
			ServletException
	{
		//HtmlServletLogger.info("[HtmlServlet] " + request.getMethod() + " site(" + getSiteId(request) + ") " + url + " 500");
		HtmlServletLogger.accesslog_tempSaveInfo(request,500);
		showErrorPage(request, response, "500");
	}

	/***
	 * メソッドは302と冠しているが、実際は301リダイレクト
	 * 
	 * @param request
	 * @param response
	 * @param nextUrl
	 * @throws IOException
	 * @throws ServletException
	 */
	private void response302(HttpServletRequest request, HttpServletResponse response, String nextUrl)
			throws IOException, ServletException
	{
		//HtmlServletLogger.info("[HtmlServlet] " + request.getMethod() + " site(" + getSiteId(request) + ") 302 - "
		//		+ nextUrl);
		HtmlServletLogger.accesslog_tempSaveInfo(request, 301,nextUrl);
		response.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
		response.setHeader("Location", nextUrl);
	}

	private void serveResource(HttpServletRequest request, HttpServletResponse response, boolean content)
			throws IOException, ServletException
	{

		DBAccess db = null;

		HttpEntry entry = null;

		String requestUri = request.getRequestURI();

		String siteId = getSiteId(request);

		HtmlServletLogger.info("[HtmlServlet] " + request.getMethod() + " site(" + ValueUtil.nullToStr(getSiteId(request))
				+ ") " + requestUri);

		if (siteId == null || siteId.length() == 0)
		{
			HtmlServletLogger.warn("サイトIDの取得に失敗しました。");
			response404(request, response, requestUri);
			return;
		}

		String theme = HtmlServletUtil.getTheme(siteId);

		if (theme == null)
		{
			//既存サイトからフェニックスへリダイレクトされた再に
			//「,」で同一ドメインが区切られたURLになり、サイトID
			//が取得できない問題を考慮
			siteId = ReplaceFilterUtil.getActualSiteId(request);
			theme = HtmlServletUtil.getTheme(siteId);

			if (theme == null)
			{
				HtmlServletLogger.warn("テーマの取得に失敗しました。");
				response404(request, response, requestUri);
				return;
			}
		}

		try
		{
			db = HtmlServletUtil.getDB();
			//TODO URL擬似静的化 requestUriの置き換え処理[start]
			if(URL_STATIC_FUNC_ON)
			{
				/*
				boolean applyReplacedUri=false;
				String replacedUri=replaceRequestURI(db, request,Integer.parseInt(siteId), requestUri);
				if(replacedUri!=null)
				{
					requestUri=replacedUri;
					applyReplacedUri=true;
				}
				*/
				UriAliasMstUtil.applyUriAlias_ReturnObject ret=UriAliasMstUtil.applyUriAlias(Integer.parseInt(siteId),request,requestUri);
				if(ret.urlReplaceStatus==UrlReplaceStatus.Apply404)
				{
					response404(request, response, requestUri);
					return;
				}
				else
				{
					requestUri=ret.pathName;
				}
			}
			//TODO URL擬似静的化 requestUriの置き換え処理[end]
			
			if (!requestUri.endsWith("/"))
			{

				// pathの最後の部分を取得
				String lastPath = HtmlServletUtil.getLastPathOf(requestUri);

				if (lastPath.indexOf(".") >= 0)
				{

					// 拡張子あり

					entry = HtmlServletUtil.getEntry(db, theme, siteId, requestUri);

					if (entry == null || entry.isEmpty())
					{
						response404(request, response, requestUri);
						return;
					}

				}
				else
				{

					// 拡張子なし

					entry = HtmlServletUtil.getEntry(db, theme, siteId, requestUri);

					if (entry == null || entry.isEmpty())
					{

						// ディレクトリかもしれないので、/をつけて転送
						requestUri = requestUri + "/";

						response302(request, response, requestUri);

						return;
					}

				}

			}
			else
			{

				entry = HtmlServletUtil.getDefaultIndexEntry(db, theme, siteId, requestUri);

				if (entry == null || entry.isEmpty())
				{
					response403(request, response, requestUri);
					return;
				}

			}

		}
		catch (Exception e)
		{
			//e.printStackTrace();
			HtmlServletLogger.error("HtmlServletにて例外を検知しました/"+e.getMessage(),e);
			response500(request, response, requestUri);
			return;

		}
		finally
		{
			DBAccess.close(db);
		}

		// response.setContentLength(entry.getContentLength()); //
		// content-lengthはReplaceFilterがセットする想定

		String contentType = entry.getContentType();
		if (contentType != null)
		{
			// ContentTypeの指定があれば、それを使う。
			// 一部の登録済み拡張子の場合も、ContentTypeを自動判別する。
			response.setContentType(contentType);
		}
		else
		{

			// ContentTypeの指定が無く、拡張子の登録も無い場合
			if (entry.isBinary())
			{
				response.setContentType("application/octet-stream");
			}
			else
			{
				// デフォルト
				response.setContentType("text/html");
			}
		}

		if (!entry.isBinary())
		{
			String charset = entry.getCharSet();
			if (charset != null && charset.length() > 0)
			{
				response.setCharacterEncoding(charset);
			}
		}

		// 読み込んだ entry の内容をそのまま出力
		HtmlServletUtil.copy(entry, response);
		/*
		HtmlServletLogger.info("[HtmlServlet] " + request.getMethod() + " site(" + getSiteId(request) + ") " + requestUri
				+ " 200 OK");
			*/
		HtmlServletLogger.accesslog_tempSaveInfo(request,200);

	}

	/** エラーページのパス */
	private static final String	ERROR_PAGE_PATH	= "error/error###error_code###.html";

	/** ズバットドメインのSystemproperty名 */
	//private static final String	ZUBAT_URL		= "ZUBAT_TOP";

	/**
	 * それぞれのサイトのエラーページへリダイレクトする。
	 * 
	 * @param request
	 * @param response
	 * @param url
	 * @param status
	 * @throws IOException
	 * @throws ServletException
	 */
	private void showErrorPage(HttpServletRequest request, HttpServletResponse response, String status)
			throws IOException, ServletException
	{
		// それに対応するサイト情報をDBキャッシュから取得する。
		String requestUrl = request.getRequestURL().toString();
		Map siteInfo = SiteMstDb.getInstance().getSiteInfo(requestUrl);

		if (siteInfo != null)
		{
			String siteName = (String) siteInfo.get("site_name_disp");
			HtmlServletLogger.info("URL：" + requestUrl + "、サイト名:" + siteName);

			// サイトURLを取得する。
			String siteUrl = (String) siteInfo.get("site_url");
			if (siteUrl == null || siteUrl.equals(""))
			{
				showDefaultErrorPage(request, response, status);
				return;
			}

			// エラーページパスを生成。
			siteUrl += ERROR_PAGE_PATH;
			// エラーコードを取得して埋め込み TODO
			siteUrl = siteUrl.replaceAll("###error_code###", status);
			response.sendRedirect(siteUrl);
			return;
		}
		else
		{
			showDefaultErrorPage(request, response, status);
			return;
		}
	}

	/**
	 * デフォルトのエラーページ（ズバットポータル）へ飛ばす。
	 * 
	 * @param request
	 * @param response
	 * @param status
	 * @throws IOException
	 * @throws ServletException
	 */
	private void showDefaultErrorPage(HttpServletRequest request, HttpServletResponse response, String status)
			throws IOException, ServletException
	{
		//TODO 矢野 デフォルトエラーページをコーポレートサイトの404にする
		//String zubatUrl = SystemPropertiesDb.getInstance().get(ZUBAT_URL) + ERROR_PAGE_PATH;
		//zubat.netのページからzba.jpにリダイレクトされるとまずいのでそれを阻止する。
		String zubatUrl = "http://www.webcrew.co.jp/" + ERROR_PAGE_PATH;
		zubatUrl = zubatUrl.replaceAll("###error_code###", status);
		response.sendRedirect(zubatUrl);
		
		response.sendRedirect(zubatUrl);
		
		
	}
	
	/*
	 * 古いコードなので不要。廃止予定
	 * URL擬似静的化対応のロジック
	 * バージョン管理が煩雑なので、一旦マージ
	 * 
	 * @param db
	 * @param request
	 * @param siteId
	 * @param requestUri
	 * @return
	 */
	/*
	private static String replaceRequestURI(DBAccess db,HttpServletRequest request,int siteId,String requestUri)
	{
		//TODO キャッシュ最適化は必要か？
		String sql="select alias_uri,path_name,getvar_name from phoenix.uri_alias_mst where site_id=? and ? like alias_uri || '%' order by alias_uri desc";
		ResultSet rset=null;
		
		final String EXT_HTML=".html";
		final int EXT_HTML_LENGTH=EXT_HTML.length();
		
		try
		{
			//System.out.println("[replace]"+sql+"\r\n[siteid]"+siteId+"[uri]"+requestUri);
			HtmlServletLogger.info("[replace]"+sql+"\r\n[siteid]"+siteId+"[uri]"+requestUri);
			db.prepareStatement(sql);
			db.setInt(1, siteId);
			//db.setString(2, requestUri+"%");
			db.setString(2, requestUri);
			rset=db.executeQuery();
			
			if(!rset.next())return null;
			
			String aliasUri=rset.getString("alias_uri");
			
			String unmatchedWord=requestUri.substring(aliasUri.length());
			
			
			
			
			if(unmatchedWord.endsWith(EXT_HTML))
			{
				int length=unmatchedWord.length()-EXT_HTML_LENGTH;
				if(length<=0)
				{
					unmatchedWord="";
				}
				else
				{
					unmatchedWord=unmatchedWord.substring(0,length);
				}
			}
			
			
			String[] unmatchedArray=unmatchedWord.split("/");
			
			String pathName=rset.getString("path_name");
			String varName=rset.getString("getvar_name");
			if(varName!=null && unmatchedArray.length!=0)
			{
				request.setAttribute("replace_getvar", new String[]{varName,unmatchedArray[0]});
			}
			else
			{
				request.removeAttribute("replace_getvar");
			}
			request.setAttribute("replace_path_array", unmatchedArray);
			request.setAttribute("replace_path_all", unmatchedWord);
			
			
			return pathName;
			
		}
		catch(Exception exc)
		{
			HtmlServletLogger.error("uri_aliasの処理でエラーを検知しました。/"+exc.getMessage(),exc);
			throw new RuntimeException(exc);
		}
		finally
		{
			DBAccess.close(rset);
		}
		
	}
	*/
	
	
}
