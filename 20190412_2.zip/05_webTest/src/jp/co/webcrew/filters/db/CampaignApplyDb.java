package jp.co.webcrew.filters.db;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * PizzaHutApplyExecuter用dbクラス。
 * 
 * @author amit
 */
public class CampaignApplyDb {

	/** PIZZA_HUT_APPLYマスタ情報取得用SQL */
	private static final String PIZZA_HUT_APPLY_INSERT = "INSERT INTO tonashiba.pizza_hut_apply (auth_key, order_id) VALUES (?, ?)";
	
	/** GIN_SARA_APPLYマスタ情報取得用SQL */
	private static final String GINNOSARA_APPLY_INSERT = "INSERT INTO tonashiba.ginnosara_apply (auth_key, order_id) VALUES (?, ?)";

	/**
	 * 生成不能コンストラクタ
	 */
	public CampaignApplyDb() {
	}

	/**
	 * Insert into PizzaHutApply table
	 * Insert into GinSaraApply table
	 * @param strAuthKey
	 * @param strOrderId
	 * @throws SQLException
	 */
	public void insertIntoCampaignApply(String strAuthKey, String strOrderId) throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			dbAccess.prepareStatement(PIZZA_HUT_APPLY_INSERT);
			dbAccess.setString(1, strAuthKey);
			dbAccess.setString(2, strOrderId);
			dbAccess.executeUpdate();
			
			dbAccess.prepareStatement(GINNOSARA_APPLY_INSERT);
			dbAccess.setString(1, strAuthKey);
			dbAccess.setString(2, strOrderId);
			dbAccess.executeUpdate();
			
		} finally {
			DBAccess.close(dbAccess);
		}
	}
}
