package jp.co.webcrew.phoenix.sstag.bean;

/**
 * フォーム出力css定義を保持するbeanクラス。
 * 
 * @author kurinami
 */
public class FormCssInfoBean {

    /** サイトID */
    private int siteId = 0;

    /** フォームID */
    private String formId = "";

    /** 項目ID */
    private String itemId = "";

    /** マップ内変数名 */
    private String varName = "";

    /** 識別番号 */
    private int num = 0;

    /** 変数の値 */
    private String varValue = "";

    // 以下、アクセッサ。

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getVarName() {
        return varName;
    }

    public void setVarName(String varName) {
        this.varName = varName;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getVarValue() {
        return varValue;
    }

    public void setVarValue(String varValue) {
        this.varValue = varValue;
    }

}
