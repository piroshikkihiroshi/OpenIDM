package jp.co.webcrew.phoenix.sstag.impl;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * 管理用認証を終了するためのsstagクラス。
 * 
 * @author kurinami
 */
public class AdminAuthEndExecuter extends SSTagExecuter {

    /** パラメータ名：ログイン認証ID */
    private static final String AUTH_ID_PARAM_KEY = "auth_id";

    /** ロガー */
    private static final Logger log = Logger.getLogger(AdminAuthEndExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { AUTH_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String authId = ValueUtil.nullToStr(parameters.get(AUTH_ID_PARAM_KEY));

            // 認証情報をセッションから削除する。
            StoreUtil.setAdminAuth(request, authId, null);

            // 管理者ログイン済みを解除する。
            StoreUtil.clearAdminLogin(request);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

}
