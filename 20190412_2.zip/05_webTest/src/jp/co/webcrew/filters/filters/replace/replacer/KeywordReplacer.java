package jp.co.webcrew.filters.filters.replace.replacer;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.CmsKwdMstDb;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.db.TermMstDb;
import jp.co.webcrew.filters.db.UrlKwdMstDb;
import jp.co.webcrew.filters.filters.replace.ReplaceFilter;
import jp.co.webcrew.filters.filters.session.SessionFilter;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.DBAccessUtil;
import jp.co.webcrew.filters.util.ReplaceFilterUtil;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.phoenix.htmlservlet.HtmlServlet;
import jp.co.webcrew.phoenix.htmlservlet.UriAliasMstBean;
import jp.co.webcrew.phoenix.htmlservlet.UriAliasMstUtil;

/**
 * キーワードを置換するreplacerクラス。
 * 
 * @author kurinami
 */
public class KeywordReplacer extends Replacer {

	/** 置換キーワードにつける接頭辞 */
	public static final String PREFIX = "$$";

	/** 置換キーワードにつける接尾辞 */
	public static final String POSTFIX = "$$";

	/** 置換キーワードの遅延を表す前カッコ */
	public static final String PRE_BRACE = "{";

    /** 置換キーワードの遅延を表す後ろカッコ */
    public static final String POST_BRACE = "}";
	
	/** 置換キーワードが残った場合の代替文字列 */
	public static final String ALTERNATIVE_WORD = "";

	/** ダイナミックキーワードのマップを格納する属性キー */
	public static final String DYNAMIC_KEYWORD_MAP_ATTR_KEY = "webcrew_dynamic_keyword_map";

	/** CMSキーワード用の接頭辞 */
	public static final String CMSKWD_PREFIX = "cmskwd.";

	/** URLキーワード用の接頭辞 */
	public static final String URLKWD_PREFIX = "urlkwd.";
	
	/** SPECIALキーワード用の接頭辞 */
	public static final String SPECIAL_PREFIX = "special.";

	/** HTMLエンコーディングの接頭辞 */
	public static final String HTMLENC_PREFIX = "htmlenc.";
	
	/** URLエンコーディングの接頭辞 */
	public static final String URLENC_PREFIX = "urlenc.";
    
    /** ORACLEキーワード用の接頭辞 */
    public static final String ORACLE_PREFIX = "oracle.";
	
	/** サイト関連情報に関する値を格納するときの接頭辞 */
	public static final String SITE_PREFIX = "site.";

	/** セッション関連情報に関する値を格納するときの接頭辞 */
	public static final String SESSION_PREFIX = "session.";

	/** 会員情報に関する値を格納するときの接頭辞 */
	public static final String MEMBER_MST_PREFIX = "member_mst.";

	/** サーバ情報に関する値を格納するときの接頭辞 */
	public static final String SERVER_PREFIX = "server.";

	/** GET情報を格納するときの接頭辞 */
	public static final String GET_PREFIX = "get.";

	/** POST情報を格納するときの接頭辞 */
	public static final String POST_PREFIX = "post.";

	/** cookie情報を格納するときの接頭辞 */
	public static final String COOKIE_PREFIX = "cookie.";

	/** HEADER情報を格納するときの接頭辞 */
	public static final String HEADER_PREFIX = "header.";

	/** システムプロパティを格納するときの接頭辞 */
	public static final String SYSPROP_PREFIX = "sysprop.";

	/** 属性名：サイトID */
	public static final String SITE_ID_ATTR_KEY = "SITE_ID";

	/** ロガー */
	private static final Logger log = Logger.getLogger(KeywordReplacer.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.Replacer#replace(java.lang.String,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String replace(String source, HttpServletRequest request,
			HttpServletResponse response) {

		log.debug("replace start.");

        // キーワード置換をやりきる。
        for (int i = 0; i < ReplaceFilter.LOOP_LIMIT; i++) {

            boolean replaceFlag = false;
            StringBuffer sb = new StringBuffer();
            int startIndex = 0;
            int searchIndex = source.indexOf(PREFIX);

            // 頭から順にprefixを探しながら処理していく。
            while (searchIndex >= 0) {

                int endIndex = source.indexOf(POSTFIX, searchIndex
                        + PREFIX.length());
                if (endIndex < 0) {
                    break;
                }

                String target = source.substring(searchIndex + PREFIX.length(),
                        endIndex).toLowerCase();
                String content = getReplaceWord(target, request, response);

                if (content != null) {
                    replaceFlag = true;

                    sb.append(source.substring(startIndex, searchIndex));
                    sb.append(content);
                    startIndex = searchIndex + PREFIX.length() + target.length()
                            + POSTFIX.length();
                    searchIndex = startIndex - 1;
                }

                searchIndex = source.indexOf(PREFIX, searchIndex + 1);

            }

            // 1度でも置換していた場合
            if (replaceFlag) {
                sb.append(source.substring(startIndex));
                source = sb.toString();
            }
            // 1度も置換していなかった場合
            else {
                break;
            }
        }

        // 置換を遅延するカッコで括られているもののカッコを外す。
        String regex = "(\\Q" + PREFIX + "\\E)\\Q" + PRE_BRACE + "\\E\\s*(.*?)\\s*\\Q" + POST_BRACE + "\\E(\\Q" + POSTFIX + "\\E)";
        String replacement = "$1$2$3";
        source = source.replaceAll(regex, replacement);
        
		log.debug("replace end.");

		return source;
	}

	private String getReplaceWord(String target, HttpServletRequest request, HttpServletResponse response) {
        String content = "";

        if (target.startsWith(PRE_BRACE) && target.endsWith(POST_BRACE)) {
            // 遅延を意味するカッコでくくられていた場合、
            content = null;
            
        } else if (target.startsWith(CMSKWD_PREFIX)) {
            // DBから置換キーワードを取得する。
            Map dbKeywordMap = CmsKwdMstDb.getInstance().getKeywordMap();
            content = (String) dbKeywordMap.get(target
                    .substring(CMSKWD_PREFIX.length()));
            // 見つからなかった場合は、prefixつきで探す。
            if (content == null) {
                content = (String) dbKeywordMap.get(target);
            }

        } else if (target.startsWith(URLKWD_PREFIX)) {
            // DBからURLキーワードを取得する。
            content = UrlKwdMstDb.getInstance().getContent(
                    request.getRequestURI(), request.getServerName(),
                    target.substring(URLKWD_PREFIX.length()));
        } else if (target.startsWith(SPECIAL_PREFIX)) {
            // 日付、時刻の置き換えをする。
            content = replaceSpecial(target.substring(SPECIAL_PREFIX.length()));
        } else if (target.startsWith(HTMLENC_PREFIX)) {
            // htmlエンコードを行う。
            content = replaceHtmlenc(target.substring(HTMLENC_PREFIX.length()), request, response);
        } else if (target.startsWith(URLENC_PREFIX)) {
            // urlエンコードを行う。
            content = replaceUrlenc(target.substring(URLENC_PREFIX.length()), request, response);
        } else if (target.startsWith(ORACLE_PREFIX)) {
            // oracle関連の置き換えをする。
            content = replaceOracle(target.substring(ORACLE_PREFIX.length()), request, response);
        } else {

            // phoenix関連の置き換えをしてみる。
            content = replacePhoenix(target, request, response);
            
            // phoenix関連の置き換えができなかった場合、
            if (content == null) {
                // 動的置換キーワードを取得する。
                Map dynamicKeywordMap = getDynamicKeywordMap(request);
                content = ValueUtil.nullToStr(dynamicKeywordMap.get(target));
            }
        }
        
        return content;
	}
	
	/**
	 * 事前定義済みキーワードを登録する。
	 * 
	 * @param request
	 */
	public void setDefinedKeyword(HttpServletRequest request) {
		setSite(request);
		setSession(request);
		setMemberMst(request);
		setServer(request);
		//TODO URL擬似静的化
		if(!HtmlServlet.URL_STATIC_FUNC_ON)
		{
			setGetPost(request);
		}
		else
		{
			__setGetPost(request);
		}
		setCookie(request);
		setHeader(request);
		setSystemProperties(request);
	}

	/**
	 * サイト関連情報を置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void setSite(HttpServletRequest request) {
		Map siteInfo = SiteMstDb.getInstance().getSiteInfo(request.getRequestURL().toString());
		addDynamicKeyword(request, SITE_PREFIX, "site_id", siteInfo.get("site_id").toString());
		addDynamicKeyword(request, SITE_PREFIX + "site_name", (String)siteInfo.get("site_name"));
		addDynamicKeyword(request, SITE_PREFIX + "step_flag", ((Boolean)siteInfo.get("step_flag")).booleanValue() ? "t" : "f"); // TODO kurinami 【確認】t/f でいいか？
		addDynamicKeyword(request, SITE_PREFIX + "site_url", (String)siteInfo.get("site_url"));
		addDynamicKeyword(request, SITE_PREFIX + "step0_show_url", (String)siteInfo.get("step0_show_url"));
		addDynamicKeyword(request, SITE_PREFIX + "step0_answer_url", (String)siteInfo.get("step0_answer_url"));
	}

	/**
	 * セッション関連情報を置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void setSession(HttpServletRequest request) {
		addDynamicKeyword(request, SESSION_PREFIX + "ls_code", (String)request.getAttribute(UserInfo.LS_CODE_ATTR_KEY));
		addDynamicKeyword(request, SESSION_PREFIX, "GUID", (String)request.getAttribute(UserInfo.GUID_ATTR_KEY));
		addDynamicKeyword(request, SESSION_PREFIX, "GSID", (String)request.getAttribute(UserInfo.GSID_ATTR_KEY));
		addDynamicKeyword(request, SESSION_PREFIX, "SSID", (String)request.getAttribute(UserInfo.SSID_ATTR_KEY));
		addDynamicKeyword(request, SESSION_PREFIX, "LOGIN_FLAG", (String)request.getAttribute(UserInfo.LOGIN_FLAG_ATTR_KEY));
		addDynamicKeyword(request, SESSION_PREFIX + "promo_code", (String)request.getAttribute(UserInfo.SITE_SESSION_PROMO_CODE_ATTR_KEY));
		addDynamicKeyword(request, SESSION_PREFIX + "af_code", (String)request.getAttribute(UserInfo.SITE_SESSION_AF_CODE_ATTR_KEY));
		
		String lsCode = (String) request.getAttribute(LsCodeReplacer.REPLACE_LS_CODE_ATTR_KEY);
		addDynamicKeyword(request, SESSION_PREFIX, "ls_code_param_hatena", lsCode == null ? "" : "?" + SessionFilter.LS_CODE_PARAM_KEY + "=" + lsCode);
		addDynamicKeyword(request, SESSION_PREFIX, "ls_code_param_and", lsCode == null ? "" : "&" + SessionFilter.LS_CODE_PARAM_KEY + "=" + lsCode);
		
		Enumeration e = request.getAttributeNames();
		while(e.hasMoreElements()) {
			String name = (String)e.nextElement();
			if(name.startsWith(UserInfo.SS_PROPS)) {
				String value = (String)request.getAttribute(name);
				addDynamicKeyword(request, SESSION_PREFIX + "props." + name, value);
				
			}
		}
	}

	/**
	 * 会員情報を置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void setMemberMst(HttpServletRequest request) {
		if(SessionFilterUtil.isLogined(request)) {
log.debug("Replace(miyake): Already login"  );
			// ログイン済みの場合は、会員マスタの情報をすべて格納する。
			Enumeration e = request.getAttributeNames();
			while(e.hasMoreElements()) {
				String name = (String)e.nextElement();
				if(name.startsWith(UserInfo.MEMBER_MST)) {
					String value = (String)request.getAttribute(name);
				    String kwd   = name.substring( UserInfo.MEMBER_MST.length() );  // add by miyake 08.04.30
					addDynamicKeyword(request, MEMBER_MST_PREFIX + kwd, value);     // edit by miyake 08.04.30
log.debug("Replace(miyake): " + MEMBER_MST_PREFIX + kwd );
				}
			}
		} else {
log.debug("Replace(miyake): NOT login"  );
			// ログインしていない場合は、会員マスタの一部の情報だけ格納する。
			addDynamicKeyword(request, MEMBER_MST_PREFIX + "nickname", (String)request.getAttribute(UserInfo.MEMBER_MST + "nickname"));
			addDynamicKeyword(request, MEMBER_MST_PREFIX + "email", (String)request.getAttribute(UserInfo.MEMBER_MST + "email"));
			addDynamicKeyword(request, MEMBER_MST_PREFIX + "mb_mail", (String)request.getAttribute(UserInfo.MEMBER_MST + "mb_mail"));
			addDynamicKeyword(request, MEMBER_MST_PREFIX + "cp_mail", (String)request.getAttribute(UserInfo.MEMBER_MST + "cp_mail"));
			addDynamicKeyword(request, MEMBER_MST_PREFIX + "formal_flag", (String)request.getAttribute(UserInfo.MEMBER_MST + "formal_flag"));
		}
	}

	/**
	 * サーバ情報を置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void setServer(HttpServletRequest request) {
		//既存サイトからフェニックスへリダイレクトされた再に
		//「,」で同一ドメインが区切られたURLになり、本来のドメイン
		//が取得できない問題を考慮。
		addDynamicKeyword(request, SERVER_PREFIX, "SERVER_NAME", ReplaceFilterUtil.getActualServerName(request));
		addDynamicKeyword(request, SERVER_PREFIX + "METHOD", request.getMethod());
		addDynamicKeyword(request, SERVER_PREFIX + "PROTOCOL", request.getProtocol());
		addDynamicKeyword(request, SERVER_PREFIX + "CONTEXT_PATH", request.getContextPath());
		addDynamicKeyword(request, SERVER_PREFIX + "SCHEME", request.getScheme());
		addDynamicKeyword(request, SERVER_PREFIX + "REQUEST_URL", request.getRequestURL().toString());
		addDynamicKeyword(request, SERVER_PREFIX + "REQUEST_URI", request.getRequestURI());
		addDynamicKeyword(request, SERVER_PREFIX + "QUERY_STRING", request.getQueryString());
		addDynamicKeyword(request, SERVER_PREFIX + "CONTENT_TYPE", request.getContentType());
		addDynamicKeyword(request, SERVER_PREFIX + "CONTENT_LENGTH", request.getHeader("Content-Length"));
		addDynamicKeyword(request, SERVER_PREFIX + "REFERER", request.getHeader("referer"));
		addDynamicKeyword(request, SERVER_PREFIX + "USER_AGENT", request.getHeader("User-Agent"));
		addDynamicKeyword(request, SERVER_PREFIX + "CLIENT_IP_ADDRESS", request.getRemoteAddr());
		
		/***
		 * プロモーションコードを取得する。
		 * 
		 */
		//その１．GET変数より取得
		String promoCode=ValueUtil.nullToStr(request.getParameter("ID"));
		//その２．GET変数より取得できなかった場合、Cookieより取得
		if(promoCode.length()==0)
		{
			
			Cookie[] cookieArray=request.getCookies();
			if(cookieArray!=null)
			{
				for(Cookie aCookie : cookieArray)
				{
					if(aCookie.getName().equals("promID"))
					{
						promoCode=ValueUtil.nullToStr(aCookie.getValue());
						log.info("[cookieより取得]"+promoCode);
						break;
					}
				}
				//その３．GET変数／Cookie共に取得できなかった場合
				if(promoCode.length()==0)
				{
					promoCode="aaaaa00000";
				}
			}
			else
			{
				promoCode="aaaaa00000";
			}
		}
		if (promoCode.length() > 10) {
			promoCode = promoCode.substring(0, 10);
		}
		addDynamicKeyword(request, SERVER_PREFIX + "PROMID", promoCode);
		
		/***
		 * コンテンツＩＤを取得する。
		 * 
		 */
		//その１．GET変数より取得
		String contentsId=ValueUtil.nullToStr(request.getParameter("XID"));
		//その２．GET変数より取得できなかった場合、Cookieより取得
		if(contentsId.length()==0)
		{
			
			Cookie[] cookieArray=request.getCookies();
			if(cookieArray!=null)
			{
				for(Cookie aCookie : cookieArray)
				{
					if(aCookie.getName().equals("XID"))
					{
						contentsId=ValueUtil.nullToStr(aCookie.getValue());
						log.info("[cookieより取得]"+contentsId);
						break;
					}
				}
				//その３．GET変数／Cookie共に取得できなかった場合
				if(contentsId.length()==0)
				{
					contentsId="aaa0000";
				}
			}
			else
			{
				contentsId="aaa0000";
			}
		}
		if (contentsId.length() > 7) {
			contentsId = contentsId.substring(0, 7);
		}
		addDynamicKeyword(request, SERVER_PREFIX + "XID", contentsId);
		
		Map termInfo = TermMstDb.getInstance().getTermInfo(request.getHeader("User-Agent"));
		addDynamicKeyword(request, SERVER_PREFIX + "TERM_TYPE", (String)termInfo.get("term_type"));
		addDynamicKeyword(request, SERVER_PREFIX + "CARIIER", (String)termInfo.get("carrier"));
		
		addDynamicKeyword(request, SERVER_PREFIX + "COOKIE", request.getHeader("Cookie"));
		addDynamicKeyword(request, SERVER_PREFIX + "ENCODING", request.getCharacterEncoding());
		
		addDynamicKeyword(request, SERVER_PREFIX + "HTTP_PROTOCOL", HttpProtocolReplacer.isSsl(request) ? "https" : "http");
        addDynamicKeyword(request, SERVER_PREFIX + "IMG_SERVER_PREFIX", ImageUrlReplacer.getPrefix(request));
	}

	/**
	 * GET情報とPOST情報を置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void setGetPost(HttpServletRequest request) {
		
		String queryString = ValueUtil.nullToStr(request.getQueryString()).trim();
		String[] queryStrings = queryString.split("&");
		
		Set getParameterSet = new HashSet();
		for(int i = 0; i < queryStrings.length; i++) {
			String[] getParameer = queryStrings[i].split("=");
			getParameterSet.add(getParameer[0]);
		}
		
		Enumeration e = request.getParameterNames();
		while(e.hasMoreElements()) {
			String name = (String)e.nextElement();
			String value = request.getParameter(name);
			
			if(getParameterSet.contains(name)) {
				addDynamicKeyword(request, GET_PREFIX + name, value);
			} else {
				addDynamicKeyword(request, POST_PREFIX + name, value);
			}
		}
	}


	/**
	 * GET情報とPOST情報を置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void __setGetPost(HttpServletRequest request) {
		
		String queryString = ValueUtil.nullToStr(request.getQueryString()).trim();
		String[] queryStrings = queryString.split("&");
		
		Set getParameterSet = new HashSet();
		for(int i = 0; i < queryStrings.length; i++) {
			String[] getParameer = queryStrings[i].split("=");
			getParameterSet.add(getParameer[0]);
		}
		
		Enumeration e = request.getParameterNames();
		while(e.hasMoreElements()) {
			String name = (String)e.nextElement();
			String value = request.getParameter(name);
			
			if(getParameterSet.contains(name)) {
				addDynamicKeyword(request, GET_PREFIX + name, value);
			} else {
				addDynamicKeyword(request, POST_PREFIX + name, value);
			}
		}
		
		//擬似静的化対応(replace_getvar)start
		String[] getVarAlias=UriAliasMstUtil.getGetVarDataFromRequest(request);
		//String[] getVarAlias=(String[])request.getAttribute(UriAliasMstUtil.REQ_ATTR_NAME_GETVAR);
		if(getVarAlias!=null)
		{
			addDynamicKeyword(request, GET_PREFIX + getVarAlias[0], getVarAlias[1]);
		}
		
		String[] pathArray=UriAliasMstUtil.getAliasArrayFromRequest(request);
		String pathALL=UriAliasMstUtil.getAliasAllFromRequest(request);
		//String[] pathArray=(String[])request.getAttribute(UriAliasMstUtil.REQ_ATTR_UNMATCHED_PATH_ARRAY);
		//String pathALL=(String)request.getAttribute(UriAliasMstUtil.REQ_ATTR_UNMATCHED_PATH_ALL);
		
		if(pathArray!=null)
		{
			int index=0;
			for(String aPath:pathArray)
			{
				index++;
				addDynamicKeyword(request, "aliasuri." + index, aPath);
			}
		}
		addDynamicKeyword(request, "aliasuri.all", pathALL);
		//擬似静的化対応(replace_getvar)end
		
		
		
	}

	/**
	 * cookie情報を置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void setCookie(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		// クッキーなしUA用暫定対応 by masuda
		if ( cookies != null ) {
		for (int i = 0; i < cookies.length; i++) {
			String name = cookies[i].getName();
			String value = cookies[i].getValue();
			addDynamicKeyword(request, COOKIE_PREFIX + name, value);
		}
		}
	}

	/**
	 * HEADER情報を置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void setHeader(HttpServletRequest request) {
		Enumeration e = request.getHeaderNames();
		while (e.hasMoreElements()) {
			String name = (String) e.nextElement();
			String value = request.getHeader(name);
			addDynamicKeyword(request, HEADER_PREFIX + name, value);
		}
	}

	/**
	 * システムプロパティを置換キーワードに格納する。
	 * 
	 * @param request
	 */
	private void setSystemProperties(HttpServletRequest request) {
		Map systemProperties = SystemPropertiesDb.getInstance()
				.getSystemProperties();
		Iterator i = systemProperties.keySet().iterator();
		while (i.hasNext()) {
			String name = (String) i.next();
			String value = (String) systemProperties.get(name);
			addDynamicKeyword(request, SYSPROP_PREFIX + name, value);
		}
	}
	
	/**
     * 置換キーワードが置換されずに残ってしまった場合のために、残った置換キーワードを削除する。
	 * 
	 * @param source
	 * @return
	 */
    public String eraseReplaceKeyword(String source) {
        return eraseReplaceKeyword(source, ALTERNATIVE_WORD);
    }

	/**
	 * 置換キーワードが置換されずに残ってしまった場合のために、残った置換キーワードを削除する。
	 * 
	 * @param source
	 * @return
	 */
	public String eraseReplaceKeyword(String source, String alternativeWord) {

		StringBuffer sb = new StringBuffer();
		int startIndex = 0;
		int searchIndex = source.indexOf(PREFIX);

		if (searchIndex < 0) {
			return source;
		}

		// 頭から順にprefixを探しながら処理していく。
		while (searchIndex >= 0) {

			int endIndex = source.indexOf(POSTFIX, searchIndex
					+ PREFIX.length());
			if (endIndex < 0) {
				break;
			}

			sb.append(source.substring(startIndex, searchIndex));

			// urlキーワード以外の場合、代替文字を差し込んでおく。
			if (!source.substring(searchIndex + PREFIX.length(),
					searchIndex + PREFIX.length() + URLKWD_PREFIX.length())
					.toLowerCase().equals(URLKWD_PREFIX)) {
				sb.append(alternativeWord);
			}

			startIndex = endIndex + POSTFIX.length();
			searchIndex = source.indexOf(PREFIX, startIndex);

		}

		sb.append(source.substring(startIndex));

		return sb.toString();

	}

	/**
	 * 動的キーワードをリクエスト上に登録する。
	 * 
	 * @param request
	 * @param kwd_name
	 * @param content
	 */
	public static void addDynamicKeyword(HttpServletRequest request,
			String kwd_name, String content) {
		Map dynamicKeywordMap = getDynamicKeywordMap(request);
		dynamicKeywordMap.put(ValueUtil.nullToStr(kwd_name).toLowerCase(),
				ValueUtil.nullToStr(content));
	}

	/**
	 * 動的キーワードをリクエスト上に登録する。(接頭辞つきとそうでないのと両方とも登録)
	 * 
	 * @param request
	 * @param prefix
	 * @param kwd_name
	 * @param content
	 */
	public static void addDynamicKeyword(HttpServletRequest request,
			String prefix, String kwd_name, String content) {
		addDynamicKeyword(request, kwd_name, content);
		addDynamicKeyword(request, prefix + kwd_name, content);
	}
	
	/**
	 * 指定された接頭辞の動的キーワードを削除する。
	 * 
	 * @param request
	 * @param prefix
	 */
	public static void removeDynamicKeyword(HttpServletRequest request, String prefix) {
	    prefix = ValueUtil.nullToStr(prefix).toLowerCase();
        Map dynamicKeywordMap = getDynamicKeywordMap(request);
        List removeList = new ArrayList();
	    Iterator ite = dynamicKeywordMap.keySet().iterator();
	    while(ite.hasNext()) {
	        String key = (String) ite.next();
	        if(key.startsWith(prefix)) {
	            removeList.add(key);
	        }
	    }
	    for(int i = 0; i < removeList.size(); i++) {
	        dynamicKeywordMap.remove(removeList.get(i));
	    }
	}

	/**
	 * 動的キーワードを登録するmapをリクエスト属性から取得する。
	 * 
	 * @param request
	 * @return
	 */
	private static Map getDynamicKeywordMap(HttpServletRequest request) {
		Map dynamicKeywordMap = (Map) request
				.getAttribute(DYNAMIC_KEYWORD_MAP_ATTR_KEY);
		if (dynamicKeywordMap == null) {
			dynamicKeywordMap = new HashMap();
			request.setAttribute(DYNAMIC_KEYWORD_MAP_ATTR_KEY,
					dynamicKeywordMap);
		}
		return dynamicKeywordMap;
	}
	
	/**
	 * 日付、時刻の置き換え用の置換キーワードの処理を行う。
	 * 
	 * @param target
	 * @return
	 */
	private String replaceSpecial(String target) {

	    if (target.startsWith("now")) {
	        Pattern p = Pattern.compile("now\\.?([ymdHMS]*)([\\+\\-][0-9]+[ymdHMS])?");
	        Matcher m = p.matcher(target);
	        
	        if(m.matches()) {
	            return this.replaceNow(ValueUtil.nullToStr(m.group(1)), ValueUtil.nullToStr(m.group(2)));
	        }
	    }
	    
        log.error("置換キーワードspecialに設定された補助指定子[" + target + "]が不正です。");
        return "";
	}
    
    private String replaceNow(String pattern, String option) {
        
        if (pattern.length() == 0) {
            pattern = "yyyymmddHHMMSS";
        }
        
        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < pattern.length(); i++) {
            switch(pattern.charAt(i)) {
            case 'm':
                sb.append('M');
                break;
            case 'M':
                sb.append('m');
                break;
            case 'S':
                sb.append('s');
                break;
            default :
                sb.append(pattern.charAt(i));
            }
        }
        
        pattern = sb.toString();
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(getTargetDate(option));
    }
	
	private Date getTargetDate(String target) {
	    
	    if(target.length() == 0) {
	        return new Date();
	    }
	    
	    int field = Calendar.DATE;
	    char ch = target.charAt(target.length() - 1);
	    switch(ch) {
	    case 'y':
	        field = Calendar.YEAR;
	        break;
        case 'm':
            field = Calendar.MONTH;
            break;
        case 'd':
            field = Calendar.DATE;
            break;
        case 'H':
            field = Calendar.HOUR_OF_DAY;
            break;
        case 'M':
            field = Calendar.MINUTE;
            break;
        case 'S':
            field = Calendar.SECOND;
            break;
	    }
	    
	    int amount = (target.startsWith("+") ? 1 : -1) * ValueUtil.toint(target.substring(1, target.length() - 1));
	    
        Calendar cal = Calendar.getInstance();
	    cal.add(field, amount);
	    
	    return cal.getTime();
	}

    /**
     * 置換キーワードに対してhtmlエンコードを行う。
     * 
     * @param target
     * @param request
     * @param response
     * @return
     */
    private String replaceHtmlenc(String target, HttpServletRequest request, HttpServletResponse response) {

        if (target.length() == 0) {
            return "";
        }

        if (target.length() >= 2
                && (target.charAt(0) == '"' && target.charAt(target.length() - 1) == '"' || target.charAt(0) == '\''
                        && target.charAt(target.length() - 1) == '\'')) {
            // 引用符でくくられている場合は、その中をそのまま対象とする。
            target = target.substring(1, target.length() - 1);
        } else {
            // 引用符でくくられていない場合は、その中を置換キーワードとして置き換えたものを対象とする。
            target = getReplaceWord(target, request, response);
        }

        // 対象をhtmlエンコードする。
        return ValueUtil.sanitize(target);
    }

    /**
     * 置換キーワードに対して、urlエンコードを行う。
     * 
     * @param target
     * @param request
     * @param response
     * @return
     */
    private String replaceUrlenc(String target, HttpServletRequest request, HttpServletResponse response) {

        if (target.length() == 0) {
            return "";
        }

        if (target.length() >= 2
                && (target.charAt(0) == '"' && target.charAt(target.length() - 1) == '"' || target.charAt(0) == '\''
                        && target.charAt(target.length() - 1) == '\'')) {
            // 引用符でくくられている場合は、その中をそのまま対象とする。
            target = target.substring(1, target.length() - 1);
        } else {
            // 引用符でくくられていない場合は、その中を置換キーワードとして置き換えたものを対象とする。
            target = getReplaceWord(target, request, response);
        }

        // 対象をurlエンコードする。
        String content = "";
        try {
            String s = target;
            String enc = response.getCharacterEncoding();
            content = URLEncoder.encode(s, enc);
        } catch (UnsupportedEncodingException e) {
            log.error("予期せぬエラー", e);
        }
        return content;
    }

    /**
     * oracleキーワードの置換を行う。
     * 
     * @param target
     * @param request
     * @param response
     * @return
     */
    private String replaceOracle(String target, HttpServletRequest request, HttpServletResponse response) {
        
        if (target.startsWith("sequence.")) {
            String[] param = target.substring("sequence.".length()).split("\\.", 2);
            if(param.length == 2) {
                try {
                    if(param[0].equals("next")) {
                        return DBAccessUtil.getSequenceNo(param[1], false);
                    } else if(param[0].equals("current")) {
                        return DBAccessUtil.getSequenceNo(param[1], true);
                    }
                } catch(SQLException e) {
                    log.error("順序値の取得に失敗しました。シーケンス名(" + param[1] + ")", e);
                }
            }
        }
        
        log.error("置換キーワードoracleに設定された補助指定子[" + target + "]が不正です。");
        return "";
    }
	
    private String replacePhoenix(String target, HttpServletRequest request, HttpServletResponse response) {
        try {
            Class phoenixReplacerClass = Class.forName("jp.co.webcrew.phoenix.sstag.replace.PhoenixReplacer");
            Replacer phoenixReplacer = (Replacer) phoenixReplacerClass.newInstance();
            return phoenixReplacer.replace(target, request, response);
        } catch(Exception e) {
            log.info("phoenix用キーワード置換の処理は省略");
            return null;
        }
    }
    
	public static final void main(String args[]) {

	    String[] sources = {
	            "$${ abc.edf }$$  gegege?  $${ ghi.jkl }$$"
	            };
	    for(int i = 0; i < sources.length; i++) {
	        String source = sources[i];
	        System.out.print("[" + source + "] -> ");
	        String regex = "(\\Q" + PREFIX + "\\E)\\Q" + PRE_BRACE + "\\E\\s*(.*?)\\s*\\Q" + POST_BRACE + "\\E(\\Q" + POSTFIX + "\\E)";
	        String replacement = "$1$2$3";
	        source = source.replaceAll(regex, replacement);
            System.out.print("[" + source + "]");
            System.out.println();
	    }
        System.out.println("----------");
        if(sources != null) {
            return ;
        }
	    
	    String[] test = {
	            "now", 
	            "now.yyyy",
	            "now.yy",
	            "now.mm",
	            "now.m",
	            "now.dd",
	            "now.d",
	            "now.HH",
	            "now.H",
	            "now.MM",
	            "now.M",
	            "now.SS",
	            "now.S",
                "now+2y", 
                "now.-3m", 
                "now.mm-50d", 
                "now.dd+100H", 
                "now.M+15M", 
                "now.M+120S", 
	    };
	    
	    for(int i = 0; i < test.length; i++) {
	        System.out.println(test[i] + " -> " + new KeywordReplacer().replaceSpecial(test[i]));
	    }
	    
	    System.out.println((new Date(2010, 10, 16).getTime() - new Date(2007, 2, 28).getTime()) / (3600 * 24 * 1000));
	}
}
