package jp.co.webcrew.login.common.db;

import java.io.Serializable;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.Record;

/**
 * SERVICE_HIST テーブルを扱うクラス
 * 
 * @author fu
 * 
 */
public class ServiceHist extends DBEntity implements Serializable {

    /** ロガー */
    private static final Logger log = Logger.getLogger(ServiceHist.class);

    public static final String TABLE = "SERVICE_HIST";

    /*
     * 列名定義
     */
    public static final String GUID = "GUID";
    public static final String SERVICE_ID = "SERVICE_ID";
    public static final String SUB_CODE = "SUB_CODE";
    public static final String SITE_ID = "SITE_ID";
    public static final String SERVICE_DATETIME = "SERVICE_DATETIME";

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
     */
    public void init() {
        setTable(TABLE);
    }

    /**
     * コンストラクタ
     */
    public ServiceHist() {
        super();
    }

    /**
     * コンストラクタ
     * 
     * @param guid
     */
    public ServiceHist(String guid) {
        super();
        setGuid(guid);
    }

    public void setGuid(String val) {
        set(GUID, val);
    }

    public final String getGUID() {
        return get(GUID);
    }

    /**
     * <pre>
     * 
     * SERVICE_HISTテーブルに一行検索する。
     * 
     * サービス利用日時を返す。
     * 
     * null : エラー
     * null : 処理中止（引数がNULLの場合など）
     * retTime : 成功
     * 
     * </pre>
     * 
     * @param guid
     * @param serviceId
     * @param subCode
     * @return サービス利用日時
     */
    public static String getLatestServiceDateTime(String guid, String serviceId, String subCode) {
        String retTime = null;
        if (guid == null || serviceId == null) {
            return retTime;
        }

        DBAccess db = null;
        try {

            db = new DBAccess();
            return getLatestServiceDateTime(db, guid, serviceId, subCode);

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function ServiceHist#insertToDB", e);
            return retTime;

        } finally {
            DBAccess.close(db);
        }
    }

    /**
     * <pre>
     * 
     * SERVICE_HISTテーブルに一行検索する。
     * 
     * サービス利用日時を返す。
     * 
     * null : エラー
     * null : 処理中止（引数がNULLの場合など）
     * retTime : 成功
     * 
     * </pre>
     * 
     * @param db
     * @param guid
     * @param serviceId
     * @param subCode
     * @param service
     * @return サービス利用日時
     */
    public static String getLatestServiceDateTime(DBAccess db, String guid, String serviceId, String subCode) {
        String retTime = null;
        if (db == null) {
            return retTime;
        }
        if (guid == null || serviceId == null) {
            return retTime;
        }

        try {

            // 検索SQL文を作成する
            StringBuffer sqlBuf = new StringBuffer();
            sqlBuf.append("SELECT ").append(SERVICE_DATETIME).append(" FROM ").append(TABLE);
            sqlBuf.append(" WHERE ").append(GUID).append(" = '").append(guid).append("'");
            sqlBuf.append(" AND ").append(SERVICE_ID).append(" = '").append(serviceId).append("'");
            if (subCode != null && subCode.length() != 0) {
                sqlBuf.append(" AND ").append(SUB_CODE).append(" = '").append(subCode).append("'");
            }
            // SERVICE_DATETIME DESC 最近登録したデータを取得
            sqlBuf.append(" ORDER BY ").append(SERVICE_DATETIME).append(" DESC ");

            // PreparedStatementを作成する
            db.prepareStatement(sqlBuf.toString());
            // 最初のレコードを取得する
            Record rec = Record.getFirstRowOf(db);
            if (rec == null) {
                log.info(TABLE + "の情報を読み込めませんでした。");
                return retTime;
            } else {
                retTime = rec.getString(SERVICE_DATETIME);
            }

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function ServiceHist#insertToDB", e);
            return retTime;
        }

        return retTime;
    }

    /**
     * <pre>
     * 
     * SERVICE_HISTテーブルに一行作成する。
     * 
     * 作成した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param db
     * @param service
     * @return 登録したレコード数
     */
    public static int insertToDB(DBAccess db, ServiceHist service) {

        if (db == null) {
            return -1;
        }

        if (service == null) {
            return -1;
        }

        try {

            return insert(db, service);

        } catch (Exception e) {
            log.error(TABLE + " テーブルに書き込み中に例外エラーが発生しました。Error in function ServiceHist#insertToDB", e);
            return -1;
        }

    }

    /**
     * <pre>
     * 
     * SERVICE_HISTテーブルに一行作成する。
     * 
     * 作成した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param service
     * @return 登録したレコード数
     */
    public static int insertToDB(ServiceHist service) {

        if (service == null) {
            return -1;
        }

        DBAccess db = null;
        try {

            db = new DBAccess();

            return ServiceHist.insertToDB(db, service);

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function ServiceHist#insertToDB", e);
            return -1;

        } finally {
            DBAccess.close(db);
        }

    }

}
