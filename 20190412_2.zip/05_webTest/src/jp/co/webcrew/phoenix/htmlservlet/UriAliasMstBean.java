package jp.co.webcrew.phoenix.htmlservlet;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;

public class UriAliasMstBean 
{
	
	/**
	 * サイトID
	 **/
	public int siteId;
	/***
	 * エイリアスURI
	 */
	public String aliasUri;
	/***
	 * パス名
	 */
	public String pathName;
	
	/***
	 * 置き換え処理を行うGET変数の名前
	 */
	public String getVarName;
	
	/***
	 * 置き換え処理を行うGET変数の名前
	 */
	public String getVarDefaultValue;
	
	
	public String suffix;
	
	
	public String splitWord;
	
	
	
	
	
}
