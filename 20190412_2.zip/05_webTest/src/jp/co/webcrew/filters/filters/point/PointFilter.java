package jp.co.webcrew.filters.filters.point;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.db.PointMstDb;

/**
 * ポイントを収集するためのfilterクラス。
 * 
 * @author kurinami
 */
public class PointFilter implements Filter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(PointFilter.class);

	/** ポイントチェックスレッド */
	private PointThread pointThread;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

		log.debug("init start.");

		try {
			pointThread = new PointThread();
			pointThread.start();

			// 必要なDBを初期化しておく
			PointMstDb.getInstance().init();

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			throw new ServletException(e);
		}

		log.debug("init end.");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		log.debug("doFilter start.");

		try {
			pointThread.push((HttpServletRequest) request,
					(HttpServletResponse) response);
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		chain.doFilter(request, response);

		log.debug("doFilter end.");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// 処理なし
	}

}
