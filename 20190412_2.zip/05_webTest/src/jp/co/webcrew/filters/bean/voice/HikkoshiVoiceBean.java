package jp.co.webcrew.filters.bean.voice;

import java.io.Serializable;
import java.text.DecimalFormat;

public class HikkoshiVoiceBean extends VoiceBean implements Serializable {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    private String numAdult 				= null;
    private String numChild 				= null;
    private String hDate 					= null;
    private String nextAddress1 			= null;
    private String companyIdMtm 			= null; // 引越し業者ID
    private String companyName 				= null; // 引越し業者漢字
    private String companyNameKana 			= null; // 引越し業者カナ
    private String price 					= null;
    private int payAmount = 0;
    private int payUnknown = 0;
    private String moveNumName 				= null;
    private String orderNewId 				= null;
    private String siteIdOrder 				= null;
    private String siteIdEnq 				= null;
    private String cmpnySvcCommentGood 		= null;
    private String cmpnySvcCommentBad 		= null;
    private String mtmAcceptFlg 			= null;

    public String getNumAdult() {
        if (numAdult == null || numAdult.length() == 0)
            numAdult = "0";
        return numAdult;
    }

    public void setNumAdult(String numAdult) {
        this.numAdult = numAdult;
    }

    public String getNumChild() {
        if (numChild == null || numChild.length() == 0)
            numChild = "0";
        return numChild;
    }

    public void setNumChild(String numChild) {
        this.numChild = numChild;
    }

    public String getHDate() {
        return hDate;
    }

    public String getHDateDisp() {
        if (getHDate() == null || getHDate().length() < 8) {
            return "-";
        }
        String strYear 	= getHDate().substring(0, 4);
        String strMonth = getHDate().substring(4, 6);
        String strDay 	= getHDate().substring(6, 8);
        return strYear + "年" + strMonth + "月" + strDay + "日";
    }

    public void setHDate(String hDate) {
        this.hDate = hDate;
    }

    public String getNextAddress1() {
        return nextAddress1;
    }

    public void setNextAddress1(String nextAddress1) {
        this.nextAddress1 = nextAddress1;
    }

    // 同じ県の場合「県内」、その他は「県外」で表示
    public String getAddressRange() {
        if (getAddress1() != null && getAddress1().equals(nextAddress1)) {
            return "県内";
        } else {
            return "県外";
        }
    }

    public String getCompanyIdMtm() {
        return companyIdMtm;
    }

    public void setCompanyIdMtm(String companyIdMtm) {
        this.companyIdMtm = companyIdMtm;
    }

    public String getCompanyName() {
        return nullToHyphen(companyName);
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyNameKana() {
        return companyNameKana;
    }

    public void setCompanyNameKana(String companyNameKana) {
        this.companyNameKana = companyNameKana;
    }

    public String getPriceOld() {
        return nullToHyphen(price);
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getPayAmount() {
      return payAmount;
    }

    public void setPayAmount(int payAmount) {
      this.payAmount = payAmount;
    }

    public int getPayUnknown() {
      return payUnknown;
    }

  public void setPayUnknown(int payUnknown) {
    this.payUnknown = payUnknown;
  }

  public String getPrice() {
    try {
      if (payAmount != 0) {
        DecimalFormat df = new DecimalFormat("#,###.#");
        return df.format(payAmount) + "円";
      }
      if (payUnknown == 1) {
        return "-";
      }
      return nullToHyphen(price);
    } catch (Exception ex) {
      return "-";
    }
  }

    public String getMoveNumName() {
        return nullToHyphen(moveNumName);
    }

    public void setMoveNumName(String moveNumName) {
        this.moveNumName = moveNumName;
    }

    public String getOrderNewId() {
        return orderNewId;
    }

    public void setOrderNewId(String orderNewId) {
        this.orderNewId = orderNewId;
    }

    public String getSiteIdOrder() {
        return siteIdOrder;
    }

    public void setSiteIdOrder(String siteIdOrder) {
        this.siteIdOrder = siteIdOrder;
    }

    public String getSiteIdEnq() {
        return siteIdEnq;
    }

    public void setSiteIdEnq(String siteIdEnq) {
        this.siteIdEnq = siteIdEnq;
    }

    public String getCmpnySvcCommentGood() {
        return toHtml(nullToHyphen(cmpnySvcCommentGood));
    }

    public void setCmpnySvcCommentGood(String cmpnySvcCommentGood) {
        this.cmpnySvcCommentGood = cmpnySvcCommentGood;
    }

    public String getCmpnySvcCommentBad() {
        return toHtml(nullToHyphen(cmpnySvcCommentBad));
    }

    public void setCmpnySvcCommentBad(String cmpnySvcCommentBad) {
        this.cmpnySvcCommentBad = cmpnySvcCommentBad;
    }

    public String getMtmAcceptFlg() {
        return mtmAcceptFlg;
    }

    public void setMtmAcceptFlg(String mtmAcceptFlg) {
        this.mtmAcceptFlg = mtmAcceptFlg;
    }
}
