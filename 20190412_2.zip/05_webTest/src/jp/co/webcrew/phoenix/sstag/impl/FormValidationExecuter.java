package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.loader.util.LoadUtil;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.logic.db.FormDb;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.db.FormItemDb;
import jp.co.webcrew.phoenix.sstag.util.FormItemUtil;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.sstag.util.ValidateUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * フォームを表示するためのsstagクラス。
 * 
 * @author kurinami
 */
public class FormValidationExecuter extends SSTagExecuter {

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：グループID */
    private static final String GROUP_ID_PARAM_KEY = "group_id";

    /** パラメータ名：含める項目 */
    private static final String INCLUDE_PARAM_KEY = "include";

    /** パラメータ名：含めない項目 */
    private static final String EXCLUDE_PARAM_KEY = "exclude";

    /** パラメータ名：group_id/include/exclude を使用せず直接項目IDを指定する際に使用 */
    private static final String ITEM_ID_PARAM_KEY = "item_id";

    /** パラメータ名：バリデーション用の追加モジュール名 */
    private static final String LOGIC_PARAM_KEY = "logic";

    /** パラメータ名：メッセージID */
    private static final String MSG_ID_PARAM_KEY = "msg_id";

    /** パラメータ名：バリデーションエラーが無い時のリダイレクト先URL */
    private static final String REDIRECT_OK_PARAM_KEY = "redirect_ok";

    /** パラメータ名：バリデーションエラーがある時のリダイレクト先URL */
    private static final String REDIRECT_ERR_PARAM_KEY = "redirect_err";

    /** パラメータ名：項目の値に応じて飛び先を変える場合の組み合わせ */
    private static final String REDIRECT_MAP_PARAM_KEY = "redirect_map";

    /** パラメータ名：項目ごとのバリデーションエラーメッセージの前側に付与する文字列 */
    private static final String ERRMSG_PREFIX_PARAM_KEY = "errmsg_prefix";

    /** パラメータ名：項目ごとのバリデーションエラーメッセージの後ろ側に付与する文字列 */
    private static final String ERRMSG_SUFFIX_PARAM_KEY = "errmsg_suffix";

    /** パラメータ名：スクリーニングも行うかのフラグ yes/no */
    private static final String SCREENING_PARAM_KEY = "screening";

    /** パラメータ名：スクリーニング結果(結果リスト)を保持するための一意なID */
    private static final String RESULT_ID_PARAM_KEY = "result_id";

    /** パラメータ名：結果保持期間 */
    private static final String LIFE_PARAM_KEY = "life";

    /** パラメータ名：スクリーニングの件数が全て０の場合にリダイレクトする場合の遷移先URL */
    private static final String ZERO_URL_PARAM_KEY = "zero_url";

    /** パラメータ名：スクリーニングの件数が１件でもある場合にリダイレクトする場合の遷移先URL */
    private static final String NO_ZERO_URL_PARAM_KEY = "not_zero_url";

    /** パラメータ名：バリデーション結果の順序指定 */
    private static final String RESULT_ORDER_PARAM_KEY = "result_order";

    /** ロガー */
    private static final Logger log = Logger.getLogger(FormValidationExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    @SuppressWarnings("unchecked")
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { FORM_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String[] groupId = PhoenixUtil.split((String) parameters.get(GROUP_ID_PARAM_KEY), ",");
            String[] include = PhoenixUtil.split((String) parameters.get(INCLUDE_PARAM_KEY), ",");
            String[] exclude = PhoenixUtil.split((String) parameters.get(EXCLUDE_PARAM_KEY), ",");
            String[] itemId = PhoenixUtil.split((String) parameters.get(ITEM_ID_PARAM_KEY), ",");
            String[] logic = PhoenixUtil.split((String) parameters.get(LOGIC_PARAM_KEY), " ");
            String msgId = ValueUtil.nullToStr(parameters.get(MSG_ID_PARAM_KEY));
            String redirectOk = ValueUtil.nullToStr(parameters.get(REDIRECT_OK_PARAM_KEY));
            String redirectErr = ValueUtil.nullToStr(parameters.get(REDIRECT_ERR_PARAM_KEY));
            String[][] redirectMap = splitRedirectMap((String) parameters.get(REDIRECT_MAP_PARAM_KEY));
            String errmsgPrefix = ValueUtil.nullToStr(parameters.get(ERRMSG_PREFIX_PARAM_KEY));
            String errmsgSuffix = ValueUtil.nullToStr(parameters.get(ERRMSG_SUFFIX_PARAM_KEY));
            boolean screening = ValueUtil.nullToStr(parameters.get(SCREENING_PARAM_KEY)).trim().equalsIgnoreCase("yes");
            String resultId = ValueUtil.nullToStr(parameters.get(RESULT_ID_PARAM_KEY));
            String life = ValueUtil.nullToStr(parameters.get(LIFE_PARAM_KEY));
            String zeroUrl = ValueUtil.nullToStr(parameters.get(ZERO_URL_PARAM_KEY));
            String notZeroUrl = ValueUtil.nullToStr(parameters.get(NO_ZERO_URL_PARAM_KEY));
            String resultOrder = ValueUtil.nullToStr(parameters.get(RESULT_ORDER_PARAM_KEY));

            // htmlを組み立てる。
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);

            // postのときだけ処理する。
            if (request.getMethod().equalsIgnoreCase("post")) {

                // サイトIDを取得
                int siteId = SstagUtil.getSiteId(null, request);

                // フォーム項目一覧を取得する。
                List<FormItemBean> formItemList = FormItemDb.getList(siteId, formId, groupId, include, exclude, null);

                // form内で使用するグループと項目
                FormUseInfo formUseInfo = new FormUseInfo(groupId, include, exclude, itemId);

                // デフォルトの入力チェックを行う。
                Map<String, String[]> vResult = defaultValidate(request, formItemList, formUseInfo, msgId,
                        errmsgPrefix, errmsgSuffix);

                Map<String, Map<String, Object[]>> sResult = null;

                // 条件判断ロジックが指定されている場合、
                if (!PhoenixUtil.isEmpty(logic)) {

                    // 共通情報を取得する。
                    SstagGlobalInfo sgInfo = SstagUtil.getSstagGlobalInfo(request);

                    // フォーム項目一覧を取得する。
                    FormInfo formInfo = FormDb.getFormInfo(siteId, formId);

                    // セッションストアで保持しているフォームデータを取得する。
                    PostInfo postInfo = StoreUtil.getPostInfo(request);

                    // 順序指定を取得する。
                    SortRequest[] sortReq = SstagUtil.getSortRequest(resultOrder);

                    // 入力チェックを行う。
                    BindLogicExtStatus status = customValidate(request, parameters, sgInfo, formInfo, postInfo,
                            formUseInfo, sortReq, logic, screening, vResult);
                    if (!status.result) {
                        status.writeLog(log);
                        return onerror(request, response, parameters, status.errStatus, status.errMsg);
                    }

                    // 結果htmlを出力する。
                    pw.println(ValueUtil.nullToStr(status.html));

                    vResult = status.vResult;
                    sResult = status.sResult;
                }

                // 入力チェック情報をセッションストアに書き込む。
                StoreUtil.setValidationResult(request, formId, vResult);

                if (screening) {
                    // スクリーニング結果をセッションストアに書き込む。
                    StoreUtil.setScreeningResult(request, resultId, sResult, life);
                }

                // チェック結果によって、遷移が必要であれば、遷移する。
                if (PhoenixUtil.isEmpty(vResult)) {
                    // 項目の値に応じて遷移先を変える
                    if (!PhoenixUtil.isEmpty(redirectMap)) {
                        PostInfo postInfo = StoreUtil.getPostInfo(request);
                        if (postInfo != null) {
                            for (String[] redirect : redirectMap) {
                                String[] values = postInfo.postItemMap.get(redirect[0]);
                                if (isRedirectMapMatch(redirect[1], values)) {
                                    response.sendRedirect(redirect[2]);
                                    return "";
                                }
                            }
                        }
                    }
                	
                    if (redirectOk.length() > 0) {
                        response.sendRedirect(redirectOk);
                        return "";
                    }
                } else {
                    if (redirectErr.length() > 0) {
                        response.sendRedirect(redirectErr);
                        return "";
                    }
                }

                if (screening) {
                    // スクリーニング結果によって、遷移が必要であれば、遷移する。
                    if (PhoenixUtil.isEmpty(sResult)) {
                        if (!PhoenixUtil.isEmpty(zeroUrl)) {
                            response.sendRedirect(zeroUrl);
                            return "";
                        }
                    } else {
                        if (!PhoenixUtil.isEmpty(notZeroUrl)) {
                            response.sendRedirect(notZeroUrl);
                            return "";
                        }
                    }
                }
            }

            pw.flush();
            return sw.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    private Map<String, String[]> defaultValidate(HttpServletRequest request, List<FormItemBean> formItemList,
            FormUseInfo formUseInfo, String msgId, String errmsgPrefix, String errmsgSuffix)
            throws InstantiationException, SQLException {

        Map<String, String> msgMap = null;
        // メッセージIDが指定されている場合、保存されているメッセージマップを取得する。
        if (!PhoenixUtil.isEmpty(msgId)) {
            msgMap = StoreUtil.getMsgMap(request, msgId);
        }
        // 指定されたメッセージマップがない場合、デフォルトのメッセージマップを使用する。
        if (PhoenixUtil.isEmpty(msgMap)) {
            msgMap = ValidateUtil.getDefaultMsgMap();
        }

        Map<String, String[]> vResult = new HashMap<String, String[]>();

        // 各項目ごとに、デフォルトの入力チェックを行う。
        // TODO kurinami 【未実装】 fileパラメータ
        for (FormItemBean formItem : formItemList) {
            if (SstagDynamicLogic.isTargetItem(formUseInfo, formItem.getItemId(), formItem.getGroupId())) {
                // 表示項目だけバリデーションする。
                if (formItem.getDispStat().equals("0")) {
                    FormItemUtil formItemUtil = FormItemUtil.getInstance(formItem, request);
                    String[] errors = formItemUtil.validate(msgMap, errmsgPrefix, errmsgSuffix);
                    if (!PhoenixUtil.isEmpty(errors)) {
                        vResult.put(formItem.getItemId(), errors);
                    }
                }
            }
        }

        return vResult;
    }

    /**
     * 入力チェックを行う。
     * 
     * @param request
     * @param sstagParam
     * @param sgInfo
     * @param formInfo
     * @param postInfo
     * @param formUseInfo
     * @param sortReq
     * @param logic
     * @param doScreening
     * @return
     * @throws Exception
     */
    private BindLogicExtStatus customValidate(HttpServletRequest request, Map<String, String> sstagParam,
            SstagGlobalInfo sgInfo, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
            SortRequest[] sortReq, String[] logic, boolean doScreening, Map<String, String[]> vResult) throws Exception {

        SstagDynamicLogic logicClass = (SstagDynamicLogic) LoadUtil.newInstanceFromId(request, logic[0]);

        List<String> userParam = Arrays.asList(logic);
        return logicClass.validationLogic(sgInfo, sstagParam, userParam, formInfo, postInfo, formUseInfo, sortReq,
                vResult, null, null, true, doScreening);
    }

    /**
     * パラメータで渡されたitem_mapを分割する。
     * 
     * @param source
     * @return
     * @throws Exception
     */
    private static String[][] splitRedirectMap(String source) throws Exception {

        source = ValueUtil.nullToStr(source).trim();

        if (PhoenixUtil.isEmpty(source)) {
            return new String[0][0];
        }

        String[] temp = PhoenixUtil.split(source.substring(1), source.substring(0, 1));

        if (temp.length % 3 != 0) {
            throw new Exception("パラメータエラー 個数が正しくありません。 [redirect_map:" + source + "]");
        }

        String[][] res = new String[temp.length / 3][3];
        for (int i = 0; i < res.length; i++) {
            res[i] = new String[3];
            res[i][0] = ValueUtil.nullToStr(temp[i * 3 + 0]).trim();
            res[i][1] = ValueUtil.nullToStr(temp[i * 3 + 1]).trim();
            res[i][2] = ValueUtil.nullToStr(temp[i * 3 + 2]).trim();
        }

        return res;
    }

    /**
     * redirect_mapで指定された値と一致しているかを判定する。
     * 
     * @param sourceValue
     * @param targetValues
     * @return
     */
    private boolean isRedirectMapMatch(String sourceValue, String[] targetValues) {
        if (PhoenixUtil.contains(targetValues, sourceValue)) {
            return true;
        } else {
            Matcher m = Pattern.compile("([\\+\\-\\.0-9]*)\\s*,\\s*([\\+\\-\\.0-9]*)").matcher(sourceValue);
            if (m.matches()) {
                String min = m.group(1);
                String max = m.group(2);
                double minValue = PhoenixUtil.isEmpty(min) ? Double.MIN_VALUE : ValueUtil.todouble(min);
                double maxValue = PhoenixUtil.isEmpty(max) ? Double.MAX_VALUE : ValueUtil.todouble(max);
                for (String targetValue : targetValues) {
                    double doubleValue = ValueUtil.todouble(targetValue);
                    if (doubleValue >= minValue && doubleValue <= maxValue) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
