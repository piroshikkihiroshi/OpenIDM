package jp.co.webcrew.phoenix.logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * スクリーニングの戻り値を扱うクラス。
 * </pre>
 * @author Takahashi
 *
 */
public class ScreeningLogicRetParam {

    private Map<String , Map<String , Object[]>> _sResult = new HashMap<String , Map<String , Object[]>>();
    
    
    /**
     * コンストラクタ
     * 
     * 内部に戻り値構造を生成する
     */
    public ScreeningLogicRetParam(){
        init();
    }
    
    private Map<String , Map<String , Object[]>> getRootMap() {
        if (_sResult == null) {
            _sResult = new HashMap<String , Map<String , Object[]>>();
        }
        return _sResult;
    }
    
    private void init() {
       
    }
    
    /**
     * <pre>
     * 指定された prm1 をセット名として追加する。
     * 既に指定されたセット名が存在する場合なにもしない。（正常終了）
     * </pre>
     * @param prm1
     */
    public boolean add( String prm1 ) {
        
        try {
            Map<String , Object[]> resultSet = get(prm1);
            
            if (resultSet == null) {
                _sResult.put(prm1, new HashMap<String , Object[]>());
            } 
            
            return true;

        } catch (RuntimeException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * <pre>
     * 指定された prm1セットの中に prm2を項目名として追加する。
     * 指定された prm1 がセットとして存在しない場合、prm1をセットとして追加する。
     * 指定された prm2が prm1内に存在する場合は何もしない（正常終了）
     * </pre>
     * @param prm1
     * @param prm2
     * @return
     */
    public boolean add( String prm1, String prm2 ) {
        
        add(prm1);
        
        Map<String , Object[]> resultSet = get(prm1);
        
        if (resultSet == null) {
            System.out.println("セットの追加に失敗しました。");
            return false;
        }
        
        Object[] items = resultSet.get(prm2);
        if (items == null) {
            resultSet.put(prm2 , newResultItem());
        } else {
            //何もしない
        }

        return true;
    }
    
    private Object[] newResultItem(){
        Object[] item = new Object[7];
        item[0] = "";
        item[1] = new ArrayList<String>();
        item[2] = new ArrayList<String>();
        item[3] = new ArrayList<String>();
        item[4] = new ArrayList<String>();
        item[5] = new ArrayList<String>();
        item[6] = new ArrayList<String>();
        
        return item;
    }

    /**
     * <pre>
     * 指定された prm1セットの中に prm2を項目名として追加する。
     * 指定された prm1 がセットとして存在しない場合、prm1をセットとして追加する。
     * 指定された prm2が prm1内に存在する場合は何もしない（正常終了）
     * 
     * add と同じ動作を行う。
     * </pre>
     * @param prm1
     * @param prm2
     * @return
     */
    public boolean set( String prm1, String prm2 ) {
        return add(prm1 , prm2);
    }

    /**
     * <pre>
     * 指定された value値を prm3, prm4 で指定される２次元配列に入れる。
     * 指定された prm1 がセットとして存在しない場合、prm1をセットとして追加する
     * 指定されたセットprm1 の中に 項目prm2が存在しない場合、項目 prm2 をセットする。
     * 
     * prm3 で指定する数値は以下の意味を持つ。
     *   prm3 == 0 ... 項目名（表示用）
     *        == 1 ... 項目の値
     *        == 2 ... 値の表示用テキスト
     *        == 3 ... 値が画像を伴う場合画像URL
     *        == 4 ... 値がURLに変換可能な場合URL
     *        == 5 ... 値がその他の属性を伴う場合（任意）
     *        == 6 ... 値が２つめの属性を伴う場合（任意）
     *        
     *         (以降任意数設定可能)
     *         
     * prm4 は 0以上の値で、順に行番号を表す。
     * valueは常に String 型となり、それ以外の値を設定することはできない。
     * （sstag側の制限による）
     *         
     * </pre>
     * @param prm1
     * @param prm2
     * @param prm3
     * @param prm4
     * @param value
     * @return
     */
    public boolean set( String prm1, String prm2, int prm3, int prm4, String value ){
       
        try {
            if (add(prm1 , prm2) == false) return false;
            
            
            Object[] items = get(prm1 , prm2);
            

            {
                int max_size = 7;
                
                if (max_size < prm3 + 1) {
                    max_size = prm3 + 1;
                }

                if (items == null) {
                    System.out.println("配列が見つからないため追加");
                    items = new Object[max_size];
                    Map<String , Object[]> resultSet = get(prm1);
                    resultSet.put(prm2 , items);
                }
                
            }

            {
                // prm3の値が大きすぎる場合、配列を再設定する
                if (items.length < prm3 + 1) {
                    Object[] newItems = new Object[prm3+1];
                    System.arraycopy(items, 0, newItems, 0, items.length);
                    for (int i = 0 ; i < newItems.length ; i++) {
                        if (newItems[i] == null) {
                            newItems[i] = new ArrayList<String>();
                        }
                    }
                    Map<String , Object[]> resultSet = get(prm1);
                    items = newItems;
                    resultSet.put(prm2 , items);
                }
            }

            if (prm3 == 0) {
                items[0] = value;
            } else {
               
                List<String> itemList = (List<String>)items[prm3];
                
                if (itemList == null) {
                    itemList = new ArrayList<String>();
                    items[prm3] = itemList;
                }
                
                // prm4の値が大きすぎる場合、listに要素を追加する
                int listSize = itemList.size();
                if (listSize < prm4 + 1) {
                    while (itemList.size() <(prm4+1)) {
                        itemList.add(null);
                    }
                }
                
                itemList.set(prm4, value);
            }
            
            return true;
        } catch (RuntimeException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * <pre>
     * 指定されたセット名 prm1 を取得する。
     *  prm1 が存在しない場合 null が返される。
     * </pre>
     * @param prm1
     * @return
     */
    public Map get(String prm1){
        return getRootMap().get(prm1);
    }
    
    /**
     * <pre>
     * 指定された prm1セットの中の項目名 prm2をを返す。
     * 実際には ２次元配列構造を 配列と List/String で表現しているため
     * Objectの配列が返される。
     * 
     * 指定された prm1 または prm2 が存在しない場合 null が返される。
     * 
     * </pre>
     * @param prm1
     * @param prm2
     * @return
     */
    public Object [] get( String prm1, String prm2 ){
        
        try {
            Map<String, Object[]>  resultSet = get(prm1);
            
            if (resultSet == null) return null;
            
            return resultSet.get(prm2);

        } catch (RuntimeException e) {
            e.printStackTrace();
            return null;
        }

    }
    
    /**
     * <pre>
     * 指定された prm1セットの中の項目名 prm2 の prm3番目の構造を返す。
     * 通常 List<String> が返されるが prm3==0 の場合だけ String 型が返される。
     * 指定された prm1, prm2, prm3 のどれかが存在しない場合 null が返される。
     * 
     * </pre>
     * @param prm1
     * @param prm2
     * @param prm3
     * @return
     */
    public Object get( String prm1, String prm2, int prm3 ) {
        
        try {
            Object[] items = get(prm1 , prm2);
            
            if (items == null) return null;
            
            if (items.length == 0) return null;
            
            if (items.length < prm3) {
                System.out.println("範囲外の値（セットされていない値）を取得しようとしました。");
                return null;
            }
            
            return items[prm3];
            
        } catch (RuntimeException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * <pre>
     * 指定された prm1セットの中の項目名 prm2 の２次元配列内の
     * prm3, prm4 番目の値(文字列型）が返される
     * 指定された prm1, prm2, prm3, prm4 のどれかが存在しない場合 
     * null が返される。
     * 
     * 
     * </pre>
     * @param prm1
     * @param prm2
     * @param prm3
     * @param prm4
     * @return
     */
    public String get( String prm1, String prm2, int prm3 , int prm4) {

        try {
            Object item = get(prm1 , prm2 , prm3 );
            
            if (item == null) return null;
            
            if (prm3 == 0 ) {
                return (String)item;
            }
            
            List<String> itemList = (List<String>)item;
            
            if (itemList.size() < prm4) {
                System.out.println("範囲外の値（セットされていない値）を取得しようとしました。");
                return null;
            }
            
            return itemList.get(prm4);

        } catch (RuntimeException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * <pre>
     * 構造全体を取得する。
     * </pre>
     * @return
     */
    public Map get(){
        return getRootMap();
    }
}
