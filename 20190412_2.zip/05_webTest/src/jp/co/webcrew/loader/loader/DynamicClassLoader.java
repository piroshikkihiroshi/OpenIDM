package jp.co.webcrew.loader.loader;

/**
 * ソースからクラスを動的に生成するclassloaderクラス
 * 
 * @author kurinami
 */
public class DynamicClassLoader extends ClassLoader {

	/** ソースのコンパイルを行うmanagerクラス */
	private RepositoryManager manager;

	/**
	 * コンストラクタ
	 * 
	 * @param manager
	 * @param loader
	 */
	public DynamicClassLoader(RepositoryManager manager, ClassLoader loader) {
		super(loader);
		this.manager = manager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.ClassLoader#findClass(java.lang.String)
	 */
	@Override
	protected Class<?> findClass(String className) throws ClassNotFoundException {
		try {
			return super.findClass(className);
		} catch (ClassNotFoundException e) {
		}
		return getClass(className);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.ClassLoader#loadClass(java.lang.String)
	 */
	@Override
	public Class<?> loadClass(String className) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		return super.loadClass(className);
	}

	/**
	 * クラスを返す。
	 * 
	 * @param className
	 * @return
	 * @throws ClassNotFoundException
	 */
	private Class<?> getClass(String className) throws ClassNotFoundException {
		byte[] buf = manager.getClass(className);
		return defineClass(className, buf, 0, buf.length);
	}

}
