package jp.co.webcrew.phoenix.sstag.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.logic.bean.PostFile;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.impl.FormDispExecuter;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * 入力チェックを行うためのutilクラス。
 * 
 * @author kurinami
 */
public class ValidateUtil {

    /** デフォルトのエラーメッセージテキストを保持するファイル名 */
    private static final String DEFAULT_ERROR_MESSAGE_FILE = "default_error_massges.txt";

    public static final String ERRNO_REQUIRE = "1";

    public static final String ERRNO_PATTERN = "2";

    public static final String ERRNO_LEAST = "3";

    public static final String ERRNO_MOST = "4";

    public static final String ERRNO_MIN = "5";

    public static final String ERRNO_MAX = "6";

    public static final String ERRNO_EMAIL_NOT_MATCH = "101";

    public static final String ERRNO_PASSWORD_NOT_MATCH = "102";

    public static final String ERRNO_INVALID_DATETIME = "103";

    /** ロガー */
    private static final Logger log = Logger.getLogger(ValidateUtil.class);

    /** デフォルトのエラーメッセージテキスト */
    private static String defaultErrorMessage = "";

    static {
        // デフォルトのエラーメッセージテキストをファイルから読み込む。
        try {
            InputStream is = null;
            try {
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);

                is = ValidateUtil.class.getResourceAsStream(DEFAULT_ERROR_MESSAGE_FILE);
                InputStreamReader isr = new InputStreamReader(is, "UTF-8");
                BufferedReader br = new BufferedReader(isr);

                String buf = null;
                while ((buf = br.readLine()) != null) {
                    pw.println(buf);
                }

                pw.flush();
                defaultErrorMessage = sw.toString();

                pw.close();
                sw.close();
            } finally {
                if (is != null) {
                    is.close();
                }
            }

        } catch (IOException e) {
            log.error("デフォルトのエラーメッセージファイルの読み込みに失敗しました。", e);
        }
    }

    public static String[] checkRequire(String[] postItems, PostFile[] postFiles, Map<String, String> msgMap,
            String errmsgPrefix, String errmsgSuffix, HttpServletRequest request, FormItemBean formItem) {

        // 必須チェックを行う。
        if (formItem.isRequire()) {
            if (PhoenixUtil.isArrayEmpty(postItems)) {
                return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_REQUIRE, request, formItem);
            }
        }

        return null;
    }

    public static String[] checkPattern(String pattern, String[] postItems, PostFile[] postFiles,
            Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix, HttpServletRequest request,
            FormItemBean formItem) {

        // 形式チェックを行う。
        if (!PhoenixUtil.isEmpty(pattern)) {
            if (!PhoenixUtil.isArrayEmpty(postItems)) {
                for (String value : postItems) {
                    if (!ValueUtil.nullToStr(value).matches(pattern)) {
                        return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_PATTERN, request, formItem);
                    }
                }
            }
        }

        return null;
    }

    public static String[] checkLeast(Integer least, String[] postItems, PostFile[] postFiles,
            Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix, HttpServletRequest request,
            FormItemBean formItem) {

        // 最少文字数チェックを行う。
        if (least != null) {
            if (!PhoenixUtil.isArrayEmpty(postItems)) {
                for (String value : postItems) {
                    if (ValueUtil.nullToStr(value).length() < least.intValue()) {
                        return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_LEAST, request, formItem);
                    }
                }
            }
        }

        return null;
    }

    public static String[] checkMost(Integer most, String[] postItems, PostFile[] postFiles,
            Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix, HttpServletRequest request,
            FormItemBean formItem) {

        // 最大文字数チェックを行う。
        if (most != null) {
            if (!PhoenixUtil.isArrayEmpty(postItems)) {
                for (String value : postItems) {
                    if (ValueUtil.nullToStr(value).length() > most.intValue()) {
                        return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_MOST, request, formItem);
                    }
                }
            }
        }

        return null;
    }

    public static String[] checkMin(Double min, String[] postItems, PostFile[] postFiles, Map<String, String> msgMap,
            String errmsgPrefix, String errmsgSuffix, HttpServletRequest request, FormItemBean formItem) {

        // 最小値チェックを行う。
        if (min != null) {
            if (!PhoenixUtil.isArrayEmpty(postItems)) {
                for (String value : postItems) {
                    if (ValueUtil.todouble(value) < min.doubleValue()) {
                        return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_MIN, request, formItem);
                    }
                }
            }
        }

        return null;
    }

    public static String[] checkMax(Double max, String[] postItems, PostFile[] postFiles, Map<String, String> msgMap,
            String errmsgPrefix, String errmsgSuffix, HttpServletRequest request, FormItemBean formItem) {

        // 最大値チェックを行う。
        if (max != null) {
            if (!PhoenixUtil.isArrayEmpty(postItems)) {
                for (String value : postItems) {
                    if (ValueUtil.todouble(value) > max.doubleValue()) {
                        return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_MAX, request, formItem);
                    }
                }
            }
        }

        return null;
    }

    public static String[] checkEmailMatch(String[] postItems, PostFile[] postFiles, Map<String, String> msgMap,
            String errmsgPrefix, String errmsgSuffix, HttpServletRequest request, FormItemBean formItem) {

        // emailの一致チェックを行う。
        if (!PhoenixUtil.isArrayEmpty(postItems)) {
            if (postItems.length < 2 || !ValueUtil.nullToStr(postItems[0]).equals(ValueUtil.nullToStr(postItems[1]))) {
                return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_EMAIL_NOT_MATCH, request, formItem);
            }
        }

        return null;
    }

    public static String[] checkPasswordMatch(String[] postItems, PostFile[] postFiles, Map<String, String> msgMap,
            String errmsgPrefix, String errmsgSuffix, HttpServletRequest request, FormItemBean formItem) {

        // パスワードの一致チェックを行う。
        if (!PhoenixUtil.isArrayEmpty(postItems)) {
            if (postItems.length < 2 || !ValueUtil.nullToStr(postItems[0]).equals(ValueUtil.nullToStr(postItems[1]))) {
                return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_PASSWORD_NOT_MATCH, request, formItem);
            }
        }

        return null;
    }

    public static String[] checkDatetime(String pattern, String value, Map<String, String> msgMap, String errmsgPrefix,
            String errmsgSuffix, HttpServletRequest request, FormItemBean formItem) {

        // 日時のフォーマットチェックを行う。
        if (!PhoenixUtil.isEmpty(value)) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(pattern);
                sdf.setLenient(false);
                sdf.parse(value);
            } catch (ParseException e) {
                return getErrorMessage(msgMap, errmsgPrefix, errmsgSuffix, ERRNO_INVALID_DATETIME, request, formItem);
            }
        }

        return null;
    }

    /**
     * エラー番号から、エラーメッセージを組み立てる。
     * 
     * @param errno
     * @param msgMap
     * @param errmsgPrefix
     * @param errmsgSuffix
     * @return
     */
    public static String[] getErrorMessage(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix,
            String errno, HttpServletRequest request, FormItemBean formItem) {
        String message = errmsgPrefix + ValueUtil.nullToStr(msgMap.get(errno)) + errmsgSuffix;
        try {
            Map<String, String> replaceMap = FormDispExecuter.getItemReplaceMap(request, formItem);
            message = ReplaceUtil.getReplacedHtml(message, replaceMap);
        } catch (Exception e) {
            log.error("予期せぬエラー", e);
        }
        return new String[] { errno, message };
    }

    /**
     * デフォルトのエラーメッセージマップを返す。
     * 
     * @return
     * @throws IOException
     */
    public static Map<String, String> getDefaultMsgMap() {

        Map<String, String> msgMap = new HashMap<String, String>();
        ValidateUtil.setMsgMap(defaultErrorMessage, msgMap);

        return msgMap;
    }

    /**
     * エラーメッセージ定義から、エラー番号とエラーメッセージのマップを組み立てる。
     * 
     * @param message
     * @param msgMap
     * @throws IOException
     */
    public static void setMsgMap(String message, Map<String, String> msgMap) {

        try {
            StringReader sr = new StringReader(message);
            BufferedReader br = new BufferedReader(sr);

            String errno = null;
            String errmsg = "";
            String line = null;
            while ((line = br.readLine()) != null) {
                line = line.trim();

                // 空白行は無視する。
                if (PhoenixUtil.isEmpty(line)) {
                    continue;
                }

                String tmpErrmsg = null;

                if (errno == null) {
                    // 新しいエラーメッセージの場合、

                    // 空白またはタブで、エラー番号とエラーメッセージを分割する。
                    int index = line.replaceFirst("\t", " ").indexOf(" ");
                    if (index < 0) {
                        // 分割できなかった場合、
                        // 行そのものをエラー番号として、エラーメッセージはなしとする。
                        errno = line;
                        tmpErrmsg = "";
                    } else {
                        // 分割できた場合、
                        errno = line.substring(0, index);
                        tmpErrmsg = line.substring(index + 1).trim();
                    }
                } else {
                    // 前の行からの続きの場合、
                    // その行そのものをエラーメッセージとして扱う。
                    tmpErrmsg = line;
                }

                if (tmpErrmsg.endsWith("|")) {
                    // 行が次に続いている場合、
                    // TODO kurinami 【確認】 <br>入れたほうがいい？
                    errmsg += tmpErrmsg.substring(0, tmpErrmsg.length() - 1);
                } else {
                    // 行が次に続いていない場合、

                    // エラー番号とエラーメッセージを登録する。
                    msgMap.put(errno, errmsg + tmpErrmsg);

                    errno = null;
                    errmsg = "";
                }
            }

            if (errno != null) {
                msgMap.put(errno, errmsg);
            }

        } catch (IOException e) {
            log.error("予期せぬエラー", e);
        }

    }

}
