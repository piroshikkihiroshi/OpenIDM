package jp.co.webcrew.common.mail.proc;

//import jp.co.webcrew.common.util.proc.StringUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * Models a single calculation within the XML for mail calculations
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: UpdateExpression.java,v 1.8 2006-12-08 13:34:37 rickk Exp $
 */
public class UpdateExpression extends Expression {
    static final String ELEM_SQL = "sql";

    private String sql;

    public UpdateExpression(Node node) {
        super(node);
        this.sql = node.getFirstChild().getNodeValue();
        
        // Read the body in, then override with child node values, so we can 
        // use both body and <sql> sub nodes to populate the sql
        this.sql = node.getFirstChild().getNodeValue();
        NodeList nodeList = node.getChildNodes();
        for (int n = 0; n < nodeList.getLength(); n++) {
            Node childNode = nodeList.item(n);

            if (childNode.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            } else if (childNode.getNodeName().equals(ELEM_SQL)) {
                this.sql = childNode.getFirstChild().getNodeValue();
            }
        }
    }

    /**
     * Executes the SQL select statement, and adds the results to the source array
     */
    public void evaluateExpression(Connection connection,
            List wildcardRows) throws SQLException {

        PreparedStatement qry = null;
        try {
            for (Iterator k = wildcardRows.iterator(); k.hasNext(); ) {
                Map wildcards = (Map) k.next();
                doReplace(wildcards);
                
                qry = QueryFunctions.buildQuery(connection, 
                        this.sql, wildcards, getOrderIndex(), qry);
                int rows = qry.executeUpdate();
                System.out.println("Rows affected: " + rows);
            }
        } finally {
            if (qry != null) {
                qry.close();
            }
        }
    }
}
