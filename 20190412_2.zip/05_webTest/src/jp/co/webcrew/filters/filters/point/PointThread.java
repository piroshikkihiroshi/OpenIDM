package jp.co.webcrew.filters.filters.point;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.PointMstDb;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.QueueThreadUtil;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;

/**
 * 各リクエストに対してポイントのチェックを行うthreadクラス。
 * 
 * @author kurinami
 */
public class PointThread extends QueueThreadUtil {

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.util.QueueThreadUtil#execute(java.lang.Object)
	 */
	protected void execute(HttpServletRequestCache request) throws Exception {

		int guid = ValueUtil.toint((String) request
				.getAttribute(UserInfo.GUID_ATTR_KEY));
		int ssid = ValueUtil.toint((String) request
				.getAttribute(UserInfo.SSID_ATTR_KEY));
		boolean formalFlag = ValueUtil.nullToStr(
				(String) request.getAttribute(UserInfo.MEMBER_MST_FORMAL_FLAG_ATTR_KEY))
				.equals("t");
		String afCode = (String) request
				.getAttribute(UserInfo.SITE_SESSION_AF_CODE_ATTR_KEY);

		String url = (String) request.getRequestURL().toString();

		List pointMstList = PointMstDb.getInstance().getPointMstList();

		for (int i = 0; i < pointMstList.size(); i++) {
			Map element = (Map) pointMstList.get(i);

			int pointId = ((Integer) element.get("point_id")).intValue();
			String pointName = (String) element.get("point_name");
			String conversionBaseUrl = (String) element
					.get("conversion_base_url");
			String conversionGoalUrl = (String) element
					.get("conversion_goal_url");
			String userType = (String) element.get("user_type");
			boolean repeatFlag = ((Boolean) element.get("repeat_flag"))
					.booleanValue();
			boolean sameDayFlag = ((Boolean) element.get("same_day_flag"))
					.booleanValue();
			int directPoint = ((Integer) element.get("direct_point"))
					.intValue();
			int introPoint = ((Integer) element.get("intro_point")).intValue();

			if (isMatch(url, conversionBaseUrl)) {
				// コンバージョン元ページの場合、

				// コンバージョン元をまだ通ってなく、かつ、
				// ポイント付与の条件を満たしている場合、
				if (!PointDb.existsPointTemp(ssid, pointId)
						&& isFulfill(pointId, userType, repeatFlag,
								sameDayFlag, guid, formalFlag, ssid)) {
					// ポイント発生ワーク情報を更新する。
					PointDb.insertPointTemp(ssid, pointId);

				}
			}

			if (isMatch(url, conversionGoalUrl)) {
				// コンバージョン成果ページの場合、

				// コンバージョン元が不要か、このサイトセッション内でコンバージョン元を通過済みで、かつ、
				// ポイント付与の条件を満たしている場合、
				if ((conversionBaseUrl.length() == 0 || PointDb
						.existsPointTemp(ssid, pointId))
						&& isFulfill(pointId, userType, repeatFlag,
								sameDayFlag, guid, formalFlag, ssid)) {

					// ポイントを発生させる。
					PointDb.insertPointCharge(guid, directPoint, pointId,
							pointName, url, afCode, introPoint, ssid);
				}
			}
		}

	}

	/**
	 * urlが一致しているかを判定する。
	 * 比較urlの最後が*で終わっていたら、前方一致、
	 * そうでなければ、完全一致で比較する。
	 * 
	 * @param url
	 * @param targetUrl
	 * @return
	 */
	private boolean isMatch(String url, String targetUrl) {
		if (targetUrl.endsWith("*")) {
			targetUrl = targetUrl.substring(0, targetUrl.length() - 1);
			return url.startsWith(targetUrl);
		} else {
			return url.equals(targetUrl);
		}
	}

	/**
	 * ポイント付与の条件に適合するかを判定する。
	 * 
	 * @param pointId
	 * @param userType
	 * @param repeatFlag
	 * @param sameDayFlag
	 * @param guid
	 * @param formalFlag
	 * @param ssid
	 * @return
	 * @throws SQLException
	 */
	private boolean isFulfill(int pointId, String userType, boolean repeatFlag,
			boolean sameDayFlag, int guid, boolean formalFlag, int ssid)
			throws SQLException {

		// 新規登録ユーザのみのポイント付与なのに、登録済みユーザの場合、
		if (userType.equals(PointMstDb.USER_TYPE_NEW) && formalFlag == true) {
			// 不適合とする。
			return false;
		}

		// 既登録ユーザのみのポイント付与なのに、未登録のユーザの場合、
		if (userType.equals(PointMstDb.USER_TYPE_REGISTED)
				&& formalFlag == false) {
			// 不適合とする。
			return false;
		}

		Set ssidSet = PointDb.getSsidSetOnPointConversion(guid, pointId);

		// リピートNGなのに、既にポイント付与済みの場合、
		if (repeatFlag == false && ssidSet.size() > 0) {
			// 不適合とする。
			return false;
		}

		// 同一セッションNGのポイント付与なのに、同一セッションでポイント付与済みの場合、
		if (sameDayFlag == false && ssidSet.contains(new Integer(ssid))) {
			// 不適合とする。
			return false;
		}

		// 適合とする。
		return true;
	}
}
