package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * URLカテゴリマップを管理するdbクラス。
 * 
 * @author fu
 */
public class UrlCategoryMapDb extends RefreshMstDb {

    /** URLカテゴリマップ一覧取得用SQL */
    private static final String URL_CATEGORY_MAP_SELECT = "select url, category_id, site_id, registered_date, valid_start_date, valid_end_date "
            + "from url_category_map "
            + "where to_char(sysdate, 'YYYYMMDDHH24MISS') > valid_start_date and (to_char(sysdate, 'YYYYMMDDHH24MISS') < valid_end_date or valid_end_date is null) "
            + "order by site_id, category_id";

    /** 唯一のインスタンス */
    private static UrlCategoryMapDb urlCategoryMapDb = new UrlCategoryMapDb();

    /** サイトURLカテゴリマップ一覧 */
    private Map siteUrlMap = null;

    /** 不明なカテゴリID -1 */
    public static final int UNKNOWN_CATEGORY_ID = -1;

    /**
     * 生成不能コンストラクタ
     */
    private UrlCategoryMapDb() {
    }

    /**
     * 唯一のインスタンスを返す。
     * 
     * @return
     */
    public static UrlCategoryMapDb getInstance() {
        return urlCategoryMapDb;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
     */
    public void init() throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess();

            Map _siteUrlMap = new HashMap();
            List siteList = null;
            int pre_site_id = -1;
            // URLカテゴリマップを検索する。
            rs = dbAccess.executeQuery(URL_CATEGORY_MAP_SELECT);

            while (dbAccess.next(rs)) {
                int siteId = rs.getInt("site_id");
                // サイトIDが変わる場合
                if (pre_site_id != siteId) {
                    if (siteList != null) { // 最初がNULLのため、判断が必要
                        _siteUrlMap.put(new Integer(pre_site_id), siteList);
                    }
                    siteList = new ArrayList();
                    pre_site_id = siteId; // 置き換える
                }
                Map element = new HashMap();
                element.put("url", ValueUtil.nullToStr(rs.getString("url")));
                element.put("category_id", new Integer(rs.getInt("category_id")));
                siteList.add(element);
            }
            if (siteList != null) {
                // 最後レコードの場合
                _siteUrlMap.put(new Integer(pre_site_id), siteList);
            }
            this.siteUrlMap = _siteUrlMap;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * サイトURLカテゴリマップ一覧を返す。
     * 
     * @return
     */
    public Map getSiteUrlMap() {
        return siteUrlMap;
    }

    /**
     * サイトURLよりカテゴリを返す。
     * 
     * @param siteId
     * @param reqUrl
     * @return categoryId
     */
    public int getCategoryId(int siteId, String reqUrl) {
        if (siteUrlMap == null || siteUrlMap.size() == 0) {
            return UNKNOWN_CATEGORY_ID;
        }
        List _urlList = (List) siteUrlMap.get(new Integer(siteId));
        if (_urlList == null || _urlList.size() == 0) {
            return UNKNOWN_CATEGORY_ID;
        }
        for (int i = 0; i < _urlList.size(); i++) {
            Map element = (Map) _urlList.get(i);
            String url = (String) element.get("url");
            if (reqUrl != null && reqUrl.equals(url)) {
                return ((Integer) element.get("category_id")).intValue();
            }
        }
        return UNKNOWN_CATEGORY_ID;
    }

}
