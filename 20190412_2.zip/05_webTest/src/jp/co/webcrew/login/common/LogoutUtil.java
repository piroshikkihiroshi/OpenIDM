package jp.co.webcrew.login.common;

import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.SiteSession;

/**
 * ログインに関連するユーティリティクラス
 * 
 * @author kurinami
 */
public class LogoutUtil {

   //============================================
   //  以下の定数は 
   //    jp.co.webcrew.filters.filters.session.UserInfo.java 
   //  内のコピー
   //  dbaccess.jar から webcrew_filters.jar は参照できないので
   //  ここにコピーしてきている。
   //  参照可能であれば UserInfo.xxx という形式でアクセスする方がよい
   //  2008.02.07 miyake
   //
	/** リクエスト属性の格納する場合のprefix */
	public static final String PREFIX = "faon.";

	/** サイトセッションプロパティ用の中間prefix */
	public static final String SS_PROPS = PREFIX + "ss_props.";

	/** 属性名：ユーザID */
	public static final String GUID_ATTR_KEY = PREFIX + "guid";

	/** 属性名：グローバルセッションID */
	public static final String GSID_ATTR_KEY = PREFIX + "gsid";

	/** 属性名：グローバルセッションコード */
	public static final String GS_CODE_ATTR_KEY = PREFIX + "gs_code";

	/** 属性名：サイトセッションID */
	public static final String SSID_ATTR_KEY = PREFIX + "ssid";

	/** 属性名：ローカルセッションコード */
	public static final String LS_CODE_ATTR_KEY = PREFIX + "ls_code";

	/** 属性名：ログイン済みフラグ */
	public static final String LOGIN_FLAG_ATTR_KEY = PREFIX + "login_flag";
	
	/** 属性名：携帯フラグ */
	public static final String MOBILE_FLAG_ATTR_KEY = PREFIX + "mobile_flag";
	
	/** 属性名：端末キャリア */
	public static final String SITE_MST_CARRIER_ATTR_KEY = PREFIX + "term_mst.carrier";

	/** 属性名：端末種別 */
	public static final String SITE_MST_TERM_TYPE_ATTR_KEY = PREFIX + "term_mst.term_type";
    
    
    
	/** ロガー */
	private static final Logger log = Logger.getLogger(LogoutUtil.class);

	/**
	 * グローバルセッションにつながるguidを書き換える。
	 * 
	 * @param gsid
	 * @param guid
	 * @param request
	 * @throws Exception
	 */
	public static void changeGuid( String             gsid, 
	                               String             guid,
			                       HttpServletRequest request 
			                     ) throws Exception {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();
			dbAccess.setAutoCommit(false);

			// 現在のユーザから指定されたユーザに置き換える。
			changeGuid(dbAccess, guid, gsid, request, true);

			// コミット
			dbAccess.commit();

		} catch (SQLException e) {
			log.error("ログアウト処理中にデータベースエラーが発生しました。", e);
			dbAccess.rollback();
			throw e;

		} catch (Exception e) {
			log.error("ログアウト認証中に例外エラーが発生しました。", e);
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

        // ----- reqest オブジェクトにセットされている各必要な値を取得
         String ssid     = (String)request.getAttribute( SSID_ATTR_KEY               );
         String gs_code  = (String)request.getAttribute( GS_CODE_ATTR_KEY            );
         String ls_code  = (String)request.getAttribute( LS_CODE_ATTR_KEY            );
         String mb_code  = (String)request.getAttribute( MOBILE_FLAG_ATTR_KEY        );
         String carrier  = (String)request.getAttribute( SITE_MST_CARRIER_ATTR_KEY   );
         String termType = (String)request.getAttribute( SITE_MST_TERM_TYPE_ATTR_KEY );
         
         
		// リクエスト属性上の値への処理
		Enumeration e = request.getAttributeNames();
		while (e.hasMoreElements()) {
			String attributeName = (String) e.nextElement();
			if (attributeName.startsWith("faon.")) {
				if (!attributeName.endsWith("_flag")) {
					request.setAttribute(attributeName, "");
				} else {
					request.setAttribute(attributeName, "f");
				}
			}
		}
		
	   // ----- request オブジェクトへ 再設定
	    request.setAttribute( GUID_ATTR_KEY              , guid    );
	    request.setAttribute( GSID_ATTR_KEY              , gsid    );
        request.setAttribute( SSID_ATTR_KEY              , ssid    );
        request.setAttribute( GS_CODE_ATTR_KEY           , gs_code );
        request.setAttribute( LS_CODE_ATTR_KEY           , ls_code );
        request.setAttribute( MOBILE_FLAG_ATTR_KEY       , mb_code );
        request.setAttribute( SITE_MST_CARRIER_ATTR_KEY  , carrier );
        request.setAttribute( SITE_MST_TERM_TYPE_ATTR_KEY, termType);
	    

	}

	/**
	 * ログアウトの状態にする。
	 * 
	 * @param gsid
	 * @param request
	 * @throws Exception
	 */
	public static void logout(String gsid, HttpServletRequest request)
			throws Exception {

		DBAccess db = null;
		try {
			db = new DBAccess();
			db.setAutoCommit(false);

			// ログイン済みフラグをおろす
			SiteSession.setLoginFlgOff(db, gsid);

			// コミット
			db.commit();

		} catch (SQLException e) {
			log.error("ログアウト処理中にデータベースエラーが発生しました。", e);
			db.rollback();
			throw e;

		} catch (Exception e) {
			log.error("ログアウト認証中に例外エラーが発生しました。", e);
			db.rollback();
			throw e;

		} finally {
			DBAccess.close(db);
		}

		// リクエスト属性上の値への処理
		request.setAttribute("faon.login_flag", "f");

	}

	/**
	 * 完全にログアウトする。
	 * 
	 * @param gsid
	 * @param request
	 * @throws Exception
	 */
	public static void logoutComplete(String gsid, HttpServletRequest request)
			throws Exception {

		logoutComplete(gsid, request, false);

	}

	/**
	 * 完全にログアウトする。
	 * 
	 * @param gsid
	 * @param request
	 * @param keepCodeFlag
	 * @throws Exception
	 */
	public static void logoutComplete(String gsid, HttpServletRequest request, boolean keepCodeFlag)
			throws Exception {

		DBAccess db = null;
		try {
			db = new DBAccess();
			db.setAutoCommit(false);

			// 空のユーザを作成する。
			String guid = SessionUtil.makeMemberMst(db, "", "");

			// 現在のユーザから空のユーザに置き換える。
			changeGuid(db, guid, gsid, request, keepCodeFlag);

			// コミット
			db.commit();

		} catch (SQLException e) {
			log.error("ログアウト処理中にデータベースエラーが発生しました。", e);
			db.rollback();
			throw e;

		} catch (Exception e) {
			log.error("ログアウト認証中に例外エラーが発生しました。", e);
			db.rollback();
			throw e;

		} finally {
			DBAccess.close(db);
		}

		// リクエスト属性上の値への処理
		Enumeration e = request.getAttributeNames();
		while (e.hasMoreElements()) {
			String attributeName = (String) e.nextElement();
			if (attributeName.startsWith("faon.")) {
				if (!attributeName.endsWith("_flag")) {
					request.setAttribute(attributeName, "");
				} else {
					request.setAttribute(attributeName, "f");
				}
			}
		}

	}
	
	/**
	 * グローバルセッションにつながるguidを書き換え、サイトセッションを作り直す。
	 * 
	 * @param dbAccess
	 * @param guid
	 * @param gsid
	 * @param request
	 * @throws SQLException
	 */
	private static void changeGuid(DBAccess dbAccess, String guid, String gsid,
			HttpServletRequest request, boolean keepCodeFlag) throws SQLException {

		// グローバルセッションにつながるユーザを切り替える。
		String sql = "update global_session set guid = ? where gsid = ?";
		dbAccess.prepareStatement(sql);
		dbAccess.setString(1, guid);
		dbAccess.setString(2, gsid);
		dbAccess.executeUpdate();

		// 現在のサイトセッション情報を取得しておく。
		Map siteSessionMap = SessionUtil.selectSiteSessionByGsid(dbAccess, gsid);

		// 現在のローカルセッション情報を取得しておく。
        String lsCode  = (String)request.getAttribute(LS_CODE_ATTR_KEY);
		Map localSessionMap = SessionUtil.selectLocalSession(dbAccess, lsCode);
		//Map localSessionMap = SessionUtil.selectLocalSessionByGsid(dbAccess, gsid);

		// サイトセッションを削除する。
		SessionUtil.deleteSiteSession(dbAccess, gsid);

		// サイトセッションを作成する。
		int siteId       = ((Integer) siteSessionMap.get("last_site_id")).intValue();
		String url       = keepCodeFlag ? ValueUtil.nullToStr(siteSessionMap.get("entry_site_url")) : request.getRequestURL().toString();
		String referer   = keepCodeFlag ? ValueUtil.nullToStr(siteSessionMap.get("referer")) : ValueUtil.nullToStr(request.getHeader("referer"));
		String remoteIp  = request.getRemoteAddr();
		String promoCode = keepCodeFlag ? ValueUtil.nullToStr(siteSessionMap.get("promo_code")) : "";
		String afCode    = keepCodeFlag ? ValueUtil.nullToStr(siteSessionMap.get("af_code")) : "";
		int termId       = ((Integer) siteSessionMap.get("term_id")).intValue();
		String ua        = ValueUtil.nullToStr(request.getHeader("User-Agent"));
		//String lsCode    = (String) localSessionMap.get("ls_code");
		String type      = (String) localSessionMap.get("type");
		
	   // ----- サイトセッションとローカルセッションを新規作成
		SessionUtil.makeSiteSession(dbAccess, gsid, siteId, url, referer, remoteIp, promoCode, afCode, termId, ua);
		SessionUtil.makeLocalSession(dbAccess, gsid, siteId, lsCode, type);

	}
}
