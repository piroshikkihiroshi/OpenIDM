/*
 * Copyright (c) 2004 WebCrew Inc. All rights reserved.
 *
 */
package jp.co.webcrew.common.validation;

import generator.runtime.db.DBConnectionWrapper;
import generator.runtime.exception.ApplicationException;
import generator.runtime.xml.XMLUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * {�N���X��}<BR>
 * {�N���X����}<BR>
 * <BR>
 * @version 1.0 2005/01/27
 *           �V�K�쐬
 * @author ������ЃE�F�u�N���[<BR>
 *          ��@����<BR>
 * <B>�X�V����</B><BR>
 *  �X�V��   : <BR>
 *  �쐬��   : <BR>
 *  �X�V���e : <BR>
 */
public class DbLookupValidation extends ValidationCheck {
    
    public ValidationFailure validate(Object valueObj, DBConnectionWrapper dbConn) {
        
	    if (valueObj == null || valueObj.equals("")) {
            return new ValidationFailure(getFieldName(), getErrorType(), null);
        } else {
            String value = (String) valueObj;
            String invalidValue = getConfigParameter("invalidValue");
            String sql = getConfigParameter("sql");
            
            boolean isInvalidValue = false;

            try {
                Connection conn = dbConn.getConnection(false);
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, value);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    if (rs.getString(1).equals(invalidValue)) {
                        isInvalidValue = true;
                    }
                } else {
                    isInvalidValue = true;
                }
                rs.close();
                stmt.close();
            } catch (SQLException e) {
                throw new ApplicationException("Error validating from database : " + sql, e);
            }

            if (isInvalidValue) {
                return new ValidationFailure(getFieldName(), getErrorType(), null);
            }
        }
        
        return null;
    }

    public void init(Node elm) {
        super.init(elm);
        NodeList children = elm.getChildNodes();
        for (int n = 0; n < children.getLength(); n++) {
            Node child = children.item(n);
            if (child.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            } else if (child.getNodeName().equals("sql")) {
                setConfigParameter("sql", XMLUtils.extractStringFromElement(child));
            }
        }
        
    }

}
