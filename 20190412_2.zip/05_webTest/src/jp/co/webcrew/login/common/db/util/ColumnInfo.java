package jp.co.webcrew.login.common.db.util;

public class ColumnInfo {
	private String columnName;
	private int columnPrecision;
	private int columnScale;
	private int columnType;
	
	public ColumnInfo(String name , int precision,int scale,int type){
		columnName = name;
		columnPrecision = precision;
		columnScale = scale;
		columnType = type;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public int getColumnPrecision() {
		return columnPrecision;
	}
	public void setColumnPrecision(int columnPrecision) {
		this.columnPrecision = columnPrecision;
	}
	public int getColumnScale() {
		return columnScale;
	}
	public void setColumnScale(int columnScale) {
		this.columnScale = columnScale;
	}
	public int getColumnType() {
		return columnType;
	}
	public void setColumnType(int columnType) {
		this.columnType = columnType;
	}
	
}