package jp.co.webcrew.filters.filters.point;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * ポイント情報を管理するdbクラス。
 * 
 * @author kurinami
 */
public class PointDb {

	/** ポイント発生ワーク情報取得用SQL */
	private static final String POINT_TEMP_SELECT = "select * from point_temp where ssid = ? and point_id = ?";

	/** ポイント発生ワーク情報挿入用SQL */
	private static final String POINT_TEMP_INSERT = "insert into point_temp(ssid, point_id, last_datetime) values(?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'))";

	/** ポイント発生ワーク情報更新用SQL */
	private static final String POINT_TEMP_DELETE = "delete from point_temp where ssid = ? and point_id = ?";

	/** ポイントコンバージョン情報取得用SQL */
	private static final String POINT_CONVERSION_SELECT = "select * from point_conversion where guid = ? and point_id = ?";

	/** ポイントコンバージョン情報挿入用SQL */
	private static final String POINT_CONVERSION_INSERT = "insert into point_conversion(point_conv_id, guid, ssid, point_id, point, last_datetime) values(seq_point_conv_id.nextval, ?, ?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'))";

	/** ポイント加算履歴挿入用SQL */
	private static final String POINT_CHARGE_INSERT = ""
			+ "insert into point_charge_hist(point_charge_id, guid, mk_datetime, point, type, point_id, url, reason, auto_kbn, user_flag, af_flag) "
			+ "values(seq_point_charge_id.nextval, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'), ?, '1', ?, ?, ?, '0', '1', ?)";

	/**
	 * ポイント発生ワークが存在するかをチェックする。
	 * 
	 * @param ssid
	 * @param pointId
	 * @return
	 * @throws SQLException
	 */
	public static boolean existsPointTemp(int ssid, int pointId)
			throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// ポイント発生ワーク情報を検索する。
			dbAccess.prepareStatement(POINT_TEMP_SELECT);
			dbAccess.setInt(1, ssid);
			dbAccess.setInt(2, pointId);
			rs = dbAccess.executeQuery();

			return dbAccess.next(rs);

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * ポイント発生ワーク情報をDBに挿入する。
	 * 
	 * @param ssid
	 * @param pointId
	 * @throws SQLException
	 */
	public static void insertPointTemp(int ssid, int pointId)
			throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// ポイント発生ワーク情報をDBに挿入する。
			dbAccess.prepareStatement(POINT_TEMP_INSERT);
			dbAccess.setInt(1, ssid);
			dbAccess.setInt(2, pointId);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * このユーザがこのポイント条件にコンバージョンしたssidの一覧を返す。
	 * 
	 * @param guid
	 * @param pointId
	 * @return
	 * @throws SQLException
	 */
	public static Set getSsidSetOnPointConversion(int guid, int pointId)
			throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			Set ssidSet = new HashSet();

			// ポイント発生ワーク情報を検索する。
			dbAccess.prepareStatement(POINT_CONVERSION_SELECT);
			dbAccess.setInt(1, guid);
			dbAccess.setInt(2, pointId);
			rs = dbAccess.executeQuery();

			while (dbAccess.next(rs)) {
				ssidSet.add(new Integer(rs.getInt("ssid")));
			}

			return ssidSet;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * ポイント加算履歴を挿入する。
	 * 
	 * @param guid
	 * @param directPoint
	 * @param pointId
	 * @param reason
	 * @param url
	 * @param afCode
	 * @param introPoint
	 * @param ssid
	 * @throws SQLException
	 */
	public static void insertPointCharge(int guid, int directPoint,
			int pointId, String reason, String url, String afCode,
			int introPoint, int ssid) throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			if (directPoint > 0) {

				// ポイント加算履歴に挿入する。
				dbAccess.prepareStatement(POINT_CHARGE_INSERT);
				dbAccess.setInt(1, guid);
				dbAccess.setInt(2, directPoint);
				dbAccess.setInt(3, pointId);
				dbAccess.setString(4, url);
				dbAccess.setString(5, reason);
				dbAccess.setString(6, "0");
				dbAccess.executeUpdate();

			}

			if (afCode.length() > 0 && introPoint > 0) {

				// 紹介者用にポイント加算履歴に挿入する。
				dbAccess.prepareStatement(POINT_CHARGE_INSERT);
				dbAccess.setInt(1, Integer.parseInt(afCode));
				dbAccess.setInt(2, introPoint);
				dbAccess.setInt(3, pointId);
				dbAccess.setString(4, url);
				dbAccess.setString(5, reason);
				dbAccess.setString(6, "1");
				dbAccess.executeUpdate();

			}

			// ポイントコンバージョンに挿入する。
			dbAccess.prepareStatement(POINT_CONVERSION_INSERT);
			dbAccess.setInt(1, guid);
			dbAccess.setInt(2, ssid);
			dbAccess.setInt(3, pointId);
			dbAccess.setInt(4, directPoint);
			dbAccess.executeUpdate();

			// ポイント発生ワークを削除する。
			dbAccess.prepareStatement(POINT_TEMP_DELETE);
			dbAccess.setInt(1, ssid);
			dbAccess.setInt(2, pointId);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}
	}
}
