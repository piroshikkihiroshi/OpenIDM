package jp.co.webcrew.filters.db;

import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * サイトマスタを管理するdbクラス。
 * 
 * @author kurinami
 */
public class SiteMstDb extends RefreshMstDb {

    /** サイトID取得用SQL */
	/*
	private static final String SITE_MST_SELECT = ""
			+ "select * \n"
            + "  from site_mst inner join site_recog_mst on site_mst.site_id = site_recog_mst.site_id \n"
			+ " where site_mst.invalid_flag = '0' \n"
			+ " order by site_recog_mst.context desc ";
	*/
	
	private static final String SITE_MST_SELECT = ""
		+ "select * \n"
        + "  from site_mst inner join site_recog_mst on site_mst.site_id = site_recog_mst.site_id \n"
		+ " where site_mst.invalid_flag = '0' \n"
		+ " order by ( "+
"case \n"+  
"when site_recog_mst.context like 'https://%' then substr(site_recog_mst.context,8) \n"+
"when site_recog_mst.context like 'http://%' then  substr(site_recog_mst.context,7) \n"+
"else site_recog_mst.context \n"+
"end \n"+
")desc ";
	
	

    /** 外部サイトを表すID */
    public static final int OUTSIDE_SITE_ID = -1;

    /** 唯一のインスタンス */
    private static SiteMstDb siteMstDb = new SiteMstDb();

    /** サイト識別URLとサイトIDの一覧 */
    private List siteList = null;

    /**
     * 生成不能コンストラクタ
     */
    private SiteMstDb() {
    }

    /**
     * 唯一のインスタンスを返す。
     * 
     * @return
     */
    public static SiteMstDb getInstance() {
        return siteMstDb;
    }

    
    private static final boolean LOCAL_DEBUG=false;
    
    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
     */
    @SuppressWarnings("unchecked")
	public void init() throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess();

            List siteList = new ArrayList();

            StringBuilder sb=new StringBuilder();
            
            // サイト情報一覧を検索する。
            rs = dbAccess.executeQuery(SITE_MST_SELECT);
            while (dbAccess.next(rs)) {
                Map element = new HashMap();
                element.put("site_id", new Integer(rs.getInt("site_id")));
                element.put("sub_num", new Integer(rs.getInt("sub_num")));
                element.put("site_name", ValueUtil.nullToStr(rs
                        .getString("site_name")));
                element.put("step_flag", new Boolean(ValueUtil.nullToStr(
                        rs.getString("step_flag")).equals("1")));
                element.put("schema", ValueUtil.nullToStr(rs.getString("schema")));
                element.put("context", cutProtocol(rs.getString("context")));
				element.put("site_url", ValueUtil.nullToStr(rs
						.getString("site_url")));
				element.put("step0_show_url", ValueUtil.nullToStr(rs
						.getString("step0_show_url")));
				element.put("step0_answer_url", ValueUtil.nullToStr(rs
						.getString("step0_answer_url")));
				element.put("promo_param_name", ValueUtil.nullToStr(rs
						.getString("promo_param_name")));
				element.put("id_erase_flag", new Boolean(ValueUtil.nullToStr(
						rs.getString("id_erase_flag")).equals("1")));
				// 新しいサイト名称を追加、PCとモバイル名称統一表示のため
				element.put("site_name_disp", ""/*ValueUtil.nullToStr(rs
						.getString("site_name_disp"))*/);
                siteList.add(element);
                
                if(LOCAL_DEBUG)
                {
                	sb.append(element.get("site_id")+"@1@"+element.get("context")+"\r\n");
                }
            }
            if(LOCAL_DEBUG)
            {
            	ps.println(sb);

            
	            //再度ソート処理を適用
	            //order by *** descでの並べ替えを再度適用
	            //（プロトコルを排除した状態で）
	            Collections.sort(siteList,new Comparator<Map<?,?> >() 
	            {
	            	
	            	@Override
	            	public int compare(Map<?, ?> map1, Map<?, ?> map2) 
	            	{
	            		String siteUrl1=ValueUtil.nullToStr(map1.get("context"));
	            		String siteUrl2=ValueUtil.nullToStr(map2.get("context"));
	            		return siteUrl2.compareTo(siteUrl1);
	            	}
	            	
	            	
				});
	            
	            
	            
	            for(Object _element:siteList)
	            {
	            	Map element=(Map)_element;
	                sb.append(element.get("site_id")+"@2@"+element.get("context")+"\r\n");
	                //System.out.println(element.get("site_id")+"@"+element.get("context"));
	            	
	            }
	            ps.println(sb);
            }
            this.siteList = siteList;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * urlを元にサイトIDを返す。<br>
     * 外部サイトのURLの場合は、SiteMstDb.OUTSIDE_SITE_IDが返る。
     * 
     * @param url
     * @return
     */
    public int getSiteId(String url) {

        Map siteInfo = getSiteInfo(url);
        return ((Integer) siteInfo.get("site_id")).intValue();

    }

	
	/**
	 * サイト識別URLとサイトIDの一覧を返す
	 * 
	 * @return siteList
	 */
	public List getSiteList(){
		return this.siteList;
	}

    /**
     * サイトへの進入時にQueryStringから削除するパラメータ名を返す。<br>
     * お気に入りに入れられても次回送ってほしくないパラメータのための対応。<br>
     * 
     * @param url
     * @return
     */
    public Map getSiteInfo(String url) {

        List siteList = this.siteList;

        for (int i = 0; i < siteList.size(); i++) {
            Map element = (Map) siteList.get(i);

			if (url.matches(".*"
					+ ValueUtil.replace((String) element.get("context"), "*",
							".*") + ".*")) {
                return element;
            }
        }

        // サイトが見つからなかった場合、
        Map element = new HashMap();
        element.put("site_id", new Integer(OUTSIDE_SITE_ID));
        element.put("sub_num", new Integer(0));
        element.put("site_name", "");
        element.put("step_flag", new Boolean(false));
        element.put("schema", "");
        element.put("context", "");
        element.put("site_url", "");
        element.put("step0_show_url", "");
        element.put("step0_answer_url", "");
        element.put("promo_param_name", "");
        element.put("id_erase_flag", new Boolean(false));
		element.put("site_name_disp", "");
        return element;
    }

    /**
     * urlの中からプロトコルの部分を省略する。
     * 
     * @param url
     * @return
     */
    private String cutProtocol(String url) {
        if (url == null) {
            return null;
        }

        int hostIndex = url.indexOf(":/");
        int paramIndex = url.indexOf("?");

        if (hostIndex >= 0 && (paramIndex < 0 || hostIndex < paramIndex)) {
            // プロトコル部分が存在する場合、
            return url.substring(hostIndex + ":/".length());
        } else {
            return url;
        }
    }

    /**
     * site_idに対応するテーマスキーマ名を返す。
     * 
     * @param siteId
     * @return
     */
    public String getSchema(int siteId) {

        for (int i = 0; i < siteList.size(); i++) {
            Map element = (Map) siteList.get(i);

            if (siteId == ((Integer) element.get("site_id")).intValue()) {
                return (String) element.get("schema");
            }
        }

        return "";

    }
    /*
	private static String eraseProtocol(Object urlTmp)
	{
		String url=(String)urlTmp;
		
		int indexof=((String)url).indexOf("://");
		if(indexof!=-1)
		{
			url=url.substring(indexof+3);
		}
		return url;
	}
	*/
	static PrintStream ps=null;
    /*
	
    public static void main(String[] args)
    throws Exception
    {
    	
    	ps=new PrintStream("sitemstdb.txt");
    	
    	
    	
    	SiteMstDb siteMstDb=SiteMstDb.getInstance();
    	siteMstDb.init();
    	
    	String url,url2;
    	url="https://www-dev.zba.jp/hikkoshi/";
    	
    	int siteId=siteMstDb.getSiteId(url);
    	Map<?,?> siteInfo=siteMstDb.getSiteInfo(url);
    	
    	System.out.println(siteId+":"+url);
    	
    	url="http://www-dev.zba.jp/hikkoshi/";
    	
    	siteId=siteMstDb.getSiteId(url);
    	siteInfo=siteMstDb.getSiteInfo(url);
    	
    	System.out.println(siteId+":"+url);
    }
    */
}
