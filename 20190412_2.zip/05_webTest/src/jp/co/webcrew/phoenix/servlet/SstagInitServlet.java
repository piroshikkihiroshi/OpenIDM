package jp.co.webcrew.phoenix.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import jp.co.webcrew.filters.filters.replace.sstag.BlankExecuter;
import jp.co.webcrew.filters.util.ReplaceFilterUtil;
import jp.co.webcrew.phoenix.htmlservlet.HtmlIncludeExecuter;
import jp.co.webcrew.phoenix.sstag.impl.AdminAuthExecuter;
import jp.co.webcrew.phoenix.sstag.impl.ContDispExecuter;
import jp.co.webcrew.phoenix.sstag.impl.DispControlExecuter;
import jp.co.webcrew.phoenix.sstag.impl.EndSessionExecuter;
import jp.co.webcrew.phoenix.sstag.impl.FormDispExecuter;
import jp.co.webcrew.phoenix.sstag.impl.FormItemAssignExecuter;
import jp.co.webcrew.phoenix.sstag.impl.FormItemConvExecuter;
import jp.co.webcrew.phoenix.sstag.impl.FormMailExecuter;
import jp.co.webcrew.phoenix.sstag.impl.FormValidationExecuter;
import jp.co.webcrew.phoenix.sstag.impl.FormWriteGroupExecuter;
import jp.co.webcrew.phoenix.sstag.impl.FormWriteItemExecuter;
import jp.co.webcrew.phoenix.sstag.impl.FormWriteTableExecuter;
import jp.co.webcrew.phoenix.sstag.impl.GetOrderInfoExecuter;
import jp.co.webcrew.phoenix.sstag.impl.IssueOrderIdExecuter;
import jp.co.webcrew.phoenix.sstag.impl.LogicExecuter;
import jp.co.webcrew.phoenix.sstag.impl.PagingIndexExecuter;
import jp.co.webcrew.phoenix.sstag.impl.PreloadExecuter;
import jp.co.webcrew.phoenix.sstag.impl.RecordIdExecuter;
import jp.co.webcrew.phoenix.sstag.impl.RedirectExecuter;
import jp.co.webcrew.phoenix.sstag.impl.ResetAssignExecuter;
import jp.co.webcrew.phoenix.sstag.impl.ScreeningExecuter;
import jp.co.webcrew.phoenix.sstag.impl.SetAssignExecuter;
import jp.co.webcrew.phoenix.sstag.impl.SetDispExecuter;
import jp.co.webcrew.phoenix.sstag.impl.SetDumpExecuter;
import jp.co.webcrew.phoenix.sstag.impl.SetMergeExecuter;
import jp.co.webcrew.phoenix.sstag.impl.SiteIdExecuter;
import jp.co.webcrew.phoenix.sstag.impl.StartSessionExecuter;
import jp.co.webcrew.phoenix.sstag.impl.TableConstructExecuter;
import jp.co.webcrew.phoenix.sstag.impl.ValidationErrorExecuter;
import jp.co.webcrew.phoenix.sstag.impl.ValidationErrorMsgExecuter;

/**
 * sstagのtype名とクラス名のマップをアプリケーション起動時に登録するためのservlet
 * 
 * @author kurinami
 */
public class SstagInitServlet extends HttpServlet {

    /** シリアルバージョン */
    private static final long serialVersionUID = 1L;

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.GenericServlet#init(javax.servlet.ServletConfig)
     */
    public void init(ServletConfig config) throws ServletException {
        // sstagのtype名とクラス名の組を登録する。
        ReplaceFilterUtil.registSstag("start_marker", BlankExecuter.class.getName());
        ReplaceFilterUtil.registSstag("end_marker", BlankExecuter.class.getName());
        
        ReplaceFilterUtil.registSstag("start_session", StartSessionExecuter.class.getName());
        ReplaceFilterUtil.registSstag("end_session", EndSessionExecuter.class.getName());
        ReplaceFilterUtil.registSstag("form_disp", FormDispExecuter.class.getName());
        ReplaceFilterUtil.registSstag("form_validation", FormValidationExecuter.class.getName());
        ReplaceFilterUtil.registSstag("validation_error_msg", ValidationErrorMsgExecuter.class.getName());
        ReplaceFilterUtil.registSstag("validation_error", ValidationErrorExecuter.class.getName());
        ReplaceFilterUtil.registSstag("screening", ScreeningExecuter.class.getName());
        ReplaceFilterUtil.registSstag("set_merge", SetMergeExecuter.class.getName());
        ReplaceFilterUtil.registSstag("set_disp", SetDispExecuter.class.getName());
        ReplaceFilterUtil.registSstag("set_dump", SetDumpExecuter.class.getName());
        ReplaceFilterUtil.registSstag("set_assign", SetAssignExecuter.class.getName());
        ReplaceFilterUtil.registSstag("reset_assign", ResetAssignExecuter.class.getName());
        ReplaceFilterUtil.registSstag("form_item_conv", FormItemConvExecuter.class.getName());
        ReplaceFilterUtil.registSstag("form_item_assign", FormItemAssignExecuter.class.getName());
        ReplaceFilterUtil.registSstag("issue_order_id", IssueOrderIdExecuter.class.getName());
        ReplaceFilterUtil.registSstag("form_write_group", FormWriteGroupExecuter.class.getName());
        ReplaceFilterUtil.registSstag("form_write_item", FormWriteItemExecuter.class.getName());
        ReplaceFilterUtil.registSstag("form_write_table", FormWriteTableExecuter.class.getName());
        ReplaceFilterUtil.registSstag("form_mail", FormMailExecuter.class.getName());
        ReplaceFilterUtil.registSstag("redirect", RedirectExecuter.class.getName());
        ReplaceFilterUtil.registSstag("cont_disp", ContDispExecuter.class.getName());
        ReplaceFilterUtil.registSstag("site_id", SiteIdExecuter.class.getName());
        ReplaceFilterUtil.registSstag("record_id", RecordIdExecuter.class.getName());
        ReplaceFilterUtil.registSstag("preload", PreloadExecuter.class.getName());
        ReplaceFilterUtil.registSstag("get_order_info", GetOrderInfoExecuter.class.getName());
        ReplaceFilterUtil.registSstag("logic", LogicExecuter.class.getName());
        ReplaceFilterUtil.registSstag("table_construct", TableConstructExecuter.class.getName());
        ReplaceFilterUtil.registSstag("paging_index", PagingIndexExecuter.class.getName());
        ReplaceFilterUtil.registSstag("disp_control", DispControlExecuter.class.getName());
        ReplaceFilterUtil.registSstag("admin_auth", AdminAuthExecuter.class.getName());
        
        ReplaceFilterUtil.registSstag("htmlinclude", HtmlIncludeExecuter.class.getName());

    }
}
