package jp.co.webcrew.login.common.db.step;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;



public class Hikkoshi_oUserInfo extends StepUserInfoCommonDb{
	
	/** スキーマ名　*/
	public static final String SCHEMA = "HIKKOSHI_O"; 
	/** テーブル名　*/
	public static final String TABLE = "USER_INFO"; 
	/** ORDER_HIST.ORDER_TEXTに転送する文字列　*/
	  public static final String ORDER_TEXT_CAPTION_PC = "引越大手比較";
	  public static final String ORDER_TEXT_CAPTION_MB = "引越大手比較モバイル";
	  public static final String ORDER_TEXT_CAPTION_PC_ZUBAT = "ズバット引越大手";
	  public static final String ORDER_TEXT_CAPTION_MB_ZUBAT = "ズバット引越大手モバイル";
	/** 法人向けサイトであるか否か   */
	public static final boolean CORPORATE_SERVICE_FLG = false;
	
    /** PCサイトＩＤ*/
    public static final String PC_SITE_ID = "3400";
    /** ズバットPCサイトＩＤ*/
    public static final String PC_SITE_ID_ZUBAT = "3430";
    public static final String MB_SITE_ID_ZUBAT = "3433";
	
	/*
	 * 列名定義
	 */
	public static final String USER_ID = "USER_ID";
	public static final String STEP_SITE_ID = "STEP_SITE_ID";
	public static final String NAME_KANJI_1 = "NAME_KANJI_1";
	public static final String NAME_KANJI_2 = "NAME_KANJI_2";
	public static final String NAME_KANA_1 = "NAME_KANA_1";
	public static final String NAME_KANA_2 = "NAME_KANA_2";
	public static final String TEL = "TEL";	
	public static final String EMAIL = "EMAIL";	
	public static final String BIRTH_DATE = "BIRTH_DATE";	
	public static final String PERMIT_WC_FLG = "PERMIT_WC_FLG";
	public static final String FINISH_FLG = "FINISH_FLG";	
	public static final String LAST_UPDATE = "LAST_UPDATE";
	public static final String DELETE_DATE = "DELETE_DATE";
	public static final String PERMIT_DM_FLG = "PERMIT_DM_FLG";	
	public static final String GUID = "GUID";	
	
	public static final String ZIP = "ZIP";
	public static final String ADDRESS_1 = "ADDRESS_1";
	public static final String ADDRESS_2 = "ADDRESS_2";
	public static final String ADDRESS_3 = "ADDRESS_3";
	public static final String ADDRESS_4 = "ADDRESS_4";
	public static final String ADDRESS_5 = "ADDRESS_5";
	public static final String PREF_ID = "PREF_ID";
	public static final String MOBILE_FLG = "MOBILE_FLG";

	public static final String SEX_ID = "SEX_ID";

	/** ロガー */
	private Logger log = Logger.getLogger(this.getClass());	
    private OrderInfo _orderInfo = new OrderInfo();
    
    public OrderInfo getOrderInfo() {
        return _orderInfo;
    }

    public void setOrderInfo(OrderInfo orderInfo) {
        _orderInfo = orderInfo;
    }
    /**
	 * オブジェクト初期化
	 */
	public void doInit(){
		setSchema(SCHEMA);
		setTable(TABLE);
		setCorporateService(CORPORATE_SERVICE_FLG);
	}
	
	/*
     * @override
     * 
     * ORDER_INFOの情報も読み込む。
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doLoad(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String, java.lang.String)
     */
    public boolean doLoad(DBAccess db , String orderId , String userId) throws SQLException{
        if (super.doLoad(db, orderId, userId)) { // USER_INFO読み込み
            OrderInfo orderInfo = getOrderInfo(); 
            orderInfo.setOrderId(orderId);
            return orderInfo.load(db); // ORDER_INFO読み込み
        
        } else {
            return false;
        }
    }
	
	private Hikkoshi_oUserInfo(){}
	
	/**
	 * コンストラクタ
	 * @param request
	 * @param siteId
	 */
	public Hikkoshi_oUserInfo(HttpServletRequest request , String siteId ){
		setSiteId(siteId);
		setHttpRequest(request);
	}	
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doCreateNewStepId(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	public void doCreateNewStepId(DBAccess db) throws SQLException{
	
		String userId = "";
		String requestId = "";
		ResultSet rs = null;
		try{
			String sql = "SELECT HIKKOSHI_O.SEQ_USER_ID.NEXTVAL AS USERID,HIKKOSHI_O.SEQ_ORDER_ID.NEXTVAL AS REQUESTID FROM DUAL";
			
			db.prepareStatement(sql);
			rs = db.executeQuery();
			if (db.next(rs)) {
				userId = ValueUtil.nullToStr(rs.getString("USERID"));
				requestId = ValueUtil.nullToStr(rs.getString("REQUESTID"));
			}
			
			setUserId(userId);
			setRequestId(requestId);

		} catch(SQLException e){
			// 例外エラー
			log.error("シーケンス取得中にデータベースエラーが発生しました。",e);
			throw e;
			
		} finally {
			DBAccess.close(rs);
		}
	    
	}	
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doPrepareStepDatabase(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	protected void doPrepareStepDatabase(DBAccess db) throws SQLException{

		// Hikkoshi_oでは、UserInfoとOrderInfoのレコードを一行ずつ作成する

		try{
			
			// USER_INFOに一行作成
			DBUpdater inserter = new DBUpdater(SCHEMA + ".USER_INFO");
			inserter.addString(USER_ID, getUserId());
			inserter.addString(STEP_SITE_ID, getSiteId());
			inserter.addString(NAME_KANJI_1, trimGet(NAME_KANJI_1));
			inserter.addString(NAME_KANJI_2, trimGet(NAME_KANJI_2));
			inserter.addString(NAME_KANA_1, trimGet(NAME_KANA_1));
			inserter.addString(NAME_KANA_2, trimGet(NAME_KANA_2));
			//inserter.addString(BIRTH_DATE, trimGet(BIRTH_DATE));			
			inserter.addString(TEL, trimGet(TEL));
			inserter.addString(EMAIL, trimGet(EMAIL));
			inserter.addString(PERMIT_WC_FLG, trimGet(PERMIT_WC_FLG));
			inserter.addString(FINISH_FLG, "0"); //TODO
			inserter.addString(LAST_UPDATE, DateUtil.currentDbDateStr());
			inserter.addString(GUID, get(GUID));

			inserter.insert(db);

			// ORDER_INFOに一行作成
			inserter = new DBUpdater(SCHEMA + ".ORDER_INFO");
			inserter.addString("ORDER_ID", getRequestId());
			inserter.addString("USER_ID", getUserId());
			inserter.addString("AUTH_KEY", " ");
			inserter.addString("FINISH_FLG", "0");
			inserter.addString("GUID", get(GUID));
			inserter.addString("CLIENT_IP_ADDRESS", getRemoteAddr());
			inserter.addString(ADDRESS_1, getOrderInfo().trimGet(ADDRESS_1));
			inserter.addString(ADDRESS_2, getOrderInfo().trimGet(ADDRESS_2));
			inserter.addString(ADDRESS_3, getOrderInfo().trimGet(ADDRESS_3));
			inserter.addString(ADDRESS_4, getOrderInfo().trimGet(ADDRESS_4));
			inserter.addString(ADDRESS_5, getOrderInfo().trimGet(ADDRESS_5));
			inserter.addString(ZIP, getOrderInfo().trimGet(ZIP));
			inserter.addString(PREF_ID, getOrderInfo().trimGet(PREF_ID));
			
            // モバイルの場合はMOBILE_FLGを1に設定する。
            if(this.getSiteId().equals(PC_SITE_ID) || this.getSiteId().equals(PC_SITE_ID_ZUBAT)) {
                inserter.addString(MOBILE_FLG, null);
            } else {
                inserter.addString(MOBILE_FLG, "1");
            }
			
			inserter.insert(db);
			
		} catch(SQLException e){
			// 例外エラー
			log.error("UserInfo,OrderInfoの新規レコード作成時にエラーが発生しました。",e);
			throw e;
		
		} finally {
			;
		}	
		
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doIsDifferentFromMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public boolean doIsDifferentFromMemberMst(MemberMst member){
		
//		log.info("引越大手も住所情報をORDER_INFOから取得します");
//		Record _rec;
//		String _zip = new String("");
//		String _pref_id = new String("");
//		String _address_1 = new String("");
//		String _address_2 = new String("");
//		String _address_3 = new String("");
//		String _address_4 = new String("");
//		String _address_5 = new String("");
//		
//		_rec = modifyAddress();
//		
//		_zip = _rec.getString(ZIP);
//		log.info("今しがたORDER_INFOから取得したZIPは " + _zip + " です。");
//		this.set(ZIP, _zip);
//		_zip = this.get(ZIP);
//		log.info("今しがたthisオブジェクトにセットして取得したZIPは " + _zip + " です。");
//
//		_pref_id = _rec.getString(PREF_ID);
//		log.info("今しがたORDER_INFOから取得したPREF_IDは " + _pref_id + " です。");
//		this.set(PREF_ID, _pref_id);
//		_pref_id = this.get(PREF_ID);
//		log.info("今しがたthisオブジェクトにセットして取得したPREF_IDは " + _pref_id + " です。");
//
//		_address_1 = _rec.getString(ADDRESS_1);
//		log.info("今しがたORDER_INFOから取得したADDRESS_1は " + _address_1 + " です。");
//		this.set(ADDRESS_1, _address_1);
//		_address_1 = this.get(ADDRESS_1);
//		log.info("今しがたthisオブジェクトにセットして取得したADDRESS_1は " + _address_1 + " です。");
//
//		_address_2 = _rec.getString(ADDRESS_2);
//		log.info("今しがたORDER_INFOから取得したADDRESS_2は " + _address_2 + " です。");
//		this.set(ADDRESS_2, _address_2);
//		_address_2 = this.get(ADDRESS_2);
//		log.info("今しがたthisオブジェクトにセットして取得したADDRESS_2は " + _address_2 + " です。");
//
//		_address_3 = _rec.getString(ADDRESS_3);
//		log.info("今しがたORDER_INFOから取得したADDRESS_3は " + _address_3 + " です。");
//		this.set(ADDRESS_3, _address_3);
//		_address_3 = this.get(ADDRESS_3);
//		log.info("今しがたthisオブジェクトにセットして取得したADDRESS_3は " + _address_3 + " です。");
//
//		_address_4 = _rec.getString(ADDRESS_4);
//		log.info("今しがたORDER_INFOから取得したADDRESS_4は " + _address_4 + " です。");
//		this.set(ADDRESS_4, _address_4);
//		_address_4 = this.get(ADDRESS_4);
//		log.info("今しがたthisオブジェクトにセットして取得したADDRESS_4は " + _address_4 + " です。");
//
//		_address_5 = _rec.getString(ADDRESS_5);
//		log.info("今しがたORDER_INFOから取得したADDRESS_5は " + _address_5 + " です。");
//		this.set(ADDRESS_5, _address_5);
//		_address_5 = this.get(ADDRESS_5);
//		log.info("今しがたthisオブジェクトにセットして取得したADDRESS_5は " + _address_5 + " です。");

		if (! get (NAME_KANJI_1).equals(member.get(MemberMst.NAME1)) ) return true;
		if (! get (NAME_KANJI_2).equals(member.get(MemberMst.NAME2)) ) return true;
		if (! get (NAME_KANA_1).equals(member.get(MemberMst.FURI1)) ) return true;
		if (! get (NAME_KANA_2).equals(member.get(MemberMst.FURI2)) ) return true;
		if (! getOrderInfo().get (ZIP).equals(member.get(MemberMst.ZIP)) ) return true;
		if (! getOrderInfo().get (PREF_ID).equals(member.get(MemberMst.PREF_ID)) ) return true;
		if (! getOrderInfo().get (ADDRESS_1).equals(member.get(MemberMst.ADDR1)) ) return true;
		if (! getOrderInfo().get (ADDRESS_2).equals(member.get(MemberMst.ADDR2)) ) return true;
		if (! getOrderInfo().get (ADDRESS_3).equals(member.get(MemberMst.ADDR3)) ) return true;
		if (! getOrderInfo().get (ADDRESS_4).equals(member.get(MemberMst.ADDR4)) ) return true;
		if (! getOrderInfo().get (ADDRESS_5).equals(member.get(MemberMst.ADDR5)) ) return true;
		//if (! get (BIRTH_DATE).equals(Util.toDbDateStr(member.get(MemberMst.BIRTHDAY))) ) return true;
		if (! get (SEX_ID).equals(member.get(MemberMst.SEX_ID)) ) return true;
        if(this.getSiteId().equals(PC_SITE_ID) || this.getSiteId().equals(PC_SITE_ID_ZUBAT)) {
            if (! get (TEL).equals(member.get(MemberMst.TEL)) ) return true;
        } else {
            if (! get (TEL).equals(member.get(MemberMst.MOBILE)) ) return true;
        }//		if (! get (EMAIL).equals(member.get(MemberMst.EMAIL)) ) return true; //EMAIL情報は自動更新の対象外
		
		return false;
	}
		
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateFromMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public void doPopulateFromMemberMst(MemberMst member){
		set (GUID , member.get(MemberMst.GUID));
		set (NAME_KANJI_1 , member.get(MemberMst.NAME1));
		set (NAME_KANJI_2 , member.get(MemberMst.NAME2));
		set (NAME_KANA_1 , member.get(MemberMst.FURI1));
		set (NAME_KANA_2 , member.get(MemberMst.FURI2));
		getOrderInfo().set (ZIP , member.get(MemberMst.ZIP));
		getOrderInfo().set (PREF_ID , member.get(MemberMst.PREF_ID));
		getOrderInfo().set (ADDRESS_1 , member.get(MemberMst.ADDR1));
		getOrderInfo().set (ADDRESS_2 , member.get(MemberMst.ADDR2));
		getOrderInfo().set (ADDRESS_3 , member.get(MemberMst.ADDR3));
		getOrderInfo().set (ADDRESS_4 , member.get(MemberMst.ADDR4));
		getOrderInfo().set (ADDRESS_5 , member.get(MemberMst.ADDR5));
		//set (BIRTH_DATE, Util.toDbDateStr(member.get(MemberMst.BIRTHDAY)));
		set (SEX_ID , member.get(MemberMst.SEX_ID));
        if(this.getSiteId().equals(PC_SITE_ID) || this.getSiteId().equals(PC_SITE_ID_ZUBAT)) {
            set (TEL , member.get(MemberMst.TEL));
        } else {
            set (TEL , member.get(MemberMst.MOBILE));
        }

		// メールアドレスは三種類を場合に応じて表示する
		if ( isMobileAccess() ) {
			set (EMAIL , member.get(MemberMst.MB_MAIL));
		} else {
			if ( isCorporateService() ) {
				set (EMAIL , member.get(MemberMst.CP_MAIL));
			} else {
				set (EMAIL , member.get(MemberMst.EMAIL));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public void doPopulateToMemberMst(MemberMst member){
		// メンバーオブジェクトを自動生成する時は、データを切り捨ててでも、なるべく生かす。
		// （文字数制限を自動的に行う）
		
		member.setTrimData(MemberMst.NAME1, get(NAME_KANJI_1));
		member.setTrimData(MemberMst.NAME2, get(NAME_KANJI_2));
		member.setTrimData(MemberMst.FURI1, get(NAME_KANA_1));
		member.setTrimData(MemberMst.FURI2, get(NAME_KANA_2));
		member.setTrimData(MemberMst.ZIP, getOrderInfo().get(ZIP));
		member.setTrimData(MemberMst.PREF_ID, getOrderInfo().get(PREF_ID));
		member.setTrimData(MemberMst.ADDR1, getOrderInfo().get(ADDRESS_1));
		member.setTrimData(MemberMst.ADDR2, getOrderInfo().get(ADDRESS_2));
		member.setTrimData(MemberMst.ADDR3, getOrderInfo().get(ADDRESS_3));
		member.setTrimData(MemberMst.ADDR4, getOrderInfo().get(ADDRESS_4));
		member.setTrimData(MemberMst.ADDR5, getOrderInfo().get(ADDRESS_5));
		member.setTrimData(MemberMst.BIRTHDAY, charBirthDate()); //YYYYMMDDに変換
		member.setTrimData(MemberMst.SEX_ID, get(SEX_ID));
        if(this.getSiteId().equals(PC_SITE_ID) || this.getSiteId().equals(PC_SITE_ID_ZUBAT)) {
            member.setTrimData(MemberMst.TEL, get(TEL));
        } else {
            member.setTrimData(MemberMst.MOBILE, get(TEL));            
        }
//		member.trimCopy(MemberMst.EMAIL, get(EMAIL)); // EMAIL情報は自動的には更新しない
//		member.trimCopy(MemberMst.MAG_FLAG, get(MAG_FLAG)); // 会員情報のMAG_FLAGはstepのとは独立した別物
	}	
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToOrderHist(jp.co.webcrew.login.util.db.OrderHist)
	 */
	public void doPopulateToOrderHist(OrderHist order){
		
		order.setTrimData(OrderHist.ORDER_DATETIME,DateUtil.currentDateTime()); //発注日
		order.setTrimData(OrderHist.ORDER_TYPE, OrderHist.TYPE_SHIRYO_SEIKYU); //資料請求に固定
		order.setTrimData(OrderHist.SITE_ID, getSiteId());
		// ORDER_IDからORDER_NEW_IDへ変更
		// order.setTrimData(OrderHist.ORDER_ID, getRequestId());
		order.setTrimData(OrderHist.ORDER_ID, getOrderInfo().get(OrderInfo.ORDER_NEW_ID));

		DBAccess db = null;
		try{
			db = new DBAccess();

			// ORDER_TEXT列にStepサイトの説明文をコピー
			order.setTrimData(OrderHist.ORDER_TEXT, getOrderText());

			// SUPPLIER_TEXT列に複数のサプライヤ情報をカンマ区切りでコピー

			StringBuffer sqlbuf = new StringBuffer("SELECT MST.NAME FROM ");
			sqlbuf.append("  HIKKOSHI_O.ORDER_COMPANY_INTER INTER, ");
			sqlbuf.append("  HIKKOSHI_O.COMPANY_MST MST ");
			sqlbuf.append("WHERE ");
			sqlbuf.append("  INTER.COMPANY_ID = MST.COMPANY_ID ");
			sqlbuf.append("AND ");
			sqlbuf.append("  INTER.ORDER_ID = ? ");
			
			db.prepareStatement(sqlbuf.toString());
			db.setString(1, getRequestId());
			db.executeQuery();
			List suppliers = Record.getResultListOf(db);
			StringBuffer supplier_text = new StringBuffer("");
			for (int i = 0 ; i < suppliers.size() ; i++) {
				Record supinfo = (Record)suppliers.get(i);
				if (i != 0) {
					supplier_text.append(",");
				}
				supplier_text.append(supinfo.getString("NAME"));
			}
			order.setTrimData(OrderHist.SUPPLIER_TEXT, supplier_text.toString()); 
					
		
		} catch (Exception e) {
			log.error("Stepデータを会員情報の履歴データに転送する際にデータベースエラーが発生しました。",e);
		} finally {
			DBAccess.close(db);
		}
		
	}

	  // Stepサイトの説明文を取得
	  private String getOrderText() {
	      String order_text = "";
	      if (PC_SITE_ID.equals(getSiteId())) {
	          order_text = ORDER_TEXT_CAPTION_PC;
	      } else if (PC_SITE_ID_ZUBAT.equals(getSiteId())) {
	          order_text = ORDER_TEXT_CAPTION_PC_ZUBAT;
	      } else if (MB_SITE_ID_ZUBAT.equals(getSiteId())) {
	          order_text = ORDER_TEXT_CAPTION_MB_ZUBAT;
	      } else {
	          order_text = ORDER_TEXT_CAPTION_MB;
	      }
	      return order_text;
	  }

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doDeleteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public void doDeleteGuid(DBAccess db , String guid) throws SQLException{
		DBUpdater updater = new DBUpdater(getSchema() + ".ORDER_INFO");
		updater.addString("GUID","");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		updater.update(db);

		updater = new DBUpdater(getSchema() + ".USER_INFO");
		updater.addString(GUID, "");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		updater.update(db);

	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doOverWriteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public boolean doOverWriteGuid (DBAccess db , String guid) {

		// UserInfoとOrderInfoのguidを更新する
		return super.updateGuidCommon(db, guid);
	}	
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getPrefId()
	 */
	public String getPrefId(){
		return getOrderInfo().get(PREF_ID);
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setPrefId(java.lang.String)
	 */
	public void setPrefId(String val){
	    getOrderInfo().set (PREF_ID , val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getUserId()
	 */
	public String getUserId(){
		return get(USER_ID);
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setUserId(java.lang.String)
	 */
	public void setUserId(String val) {
		set(USER_ID , val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getEmail()
	 */
	public String getEmail(){
		return get(EMAIL);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getSexId()
	 */
	public String getSexId() {
	    return get(SEX_ID);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDate()
	 */
	public String getBirthDate() {
		return get(BIRTH_DATE);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthYear()
	 */
	public String getBirthYear() {
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(0,4);
		}
		return ret;
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthMonth()
	 */
	public String getBirthMonth() {
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(5,7);
		}
		return ret;
	}		
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDay()
	 */
	public String getBirthDay(){
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(8,10);
		}
		return ret;		
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getZip()
	 */
	public String getZip(){
		return getOrderInfo().get(ZIP);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setZip(java.lang.String)
	 */
	public void setZip(String val){
	    getOrderInfo().set(ZIP,val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setSexId(java.lang.String)
	 */
	public void setSexId(String val){
	    set(SEX_ID,val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setBirthDate(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void setBirthDate(String year,String month,String day){
		set(BIRTH_DATE , year + "-" + month + "-" + day);
	}
	

	/*
	 * private method
	 */
	
	/**
	 * クライアントのIPアドレスを取得する
	 * @return String IPアドレス
	 */
	private String getRemoteAddr() {
		return getHttpRequest().getRemoteAddr();
	}

	/**
	 * 誕生日をYYYYMMDD形式の文字列で取得する
	 * @return String 誕生日 YYYYMMDD
	 */
	private String charBirthDate(){
		return getBirthYear() + getBirthMonth() + getBirthDay();		
	}
	
	private Record modifyAddress(){
		DBAccess ooteDb = null;
		Record _rec = new Record();
		
		try{
			ooteDb = new DBAccess();

			StringBuffer sqlbuf = new StringBuffer("SELECT ZIP, PREF_ID, ADDRESS_1, ADDRESS_2, ADDRESS_3, ADDRESS_4, ADDRESS_5 FROM ");
			sqlbuf.append("  HIKKOSHI_O.ORDER_INFO ");
			sqlbuf.append("WHERE ");
			sqlbuf.append("  ORDER_ID = ? ");
			
			ooteDb.prepareStatement(sqlbuf.toString());
			ooteDb.setString(1, getRequestId());
			ooteDb.executeQuery();
			_rec = Record.getFirstRowOf(ooteDb);		
		    return _rec;
		} catch (Exception e) {
			log.error("引越大手でORDER_INFOから住所データを取得する際にデータベースエラーが発生しました。",e);
			return _rec;
		} finally {
			DBAccess.close(ooteDb);
		}		
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getLastUpdateTime()
	 */
	public String getLastUpdate() {
		String ret = get(LAST_UPDATE);
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(0,4) + ret.substring(5,7) + ret.substring(8,10);
		}
		
		return ret;
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getMagFlag()
	 */
	public String getMagFlag() {
		String mag_flag = get(PERMIT_WC_FLG);
		
		if (mag_flag == null) {
			return "" ;
		}
		if (mag_flag.equals("0")) {
			return "0";
		}
		if (mag_flag.equals("1")) {
			return "1";
		}

		return "";
		
	}
	
    private class OrderInfo extends DBEntity{

        /** スキーマ名　*/
        public static final String SCHEMA = "HIKKOSHI_O"; 
        /** テーブル名　*/
        public static final String TABLE = "ORDER_INFO"; 

        /*
         * 列名
         */
        public static final String ORDER_ID = "ORDER_ID";
        public static final String USER_ID = "USER_ID";
        public static final String MOVE_TYPE_ID = "MOVE_TYPE_ID";
        public static final String AUTH_KEY = "AUTH_KEY";
        public static final String NUM_ADULT = "NUM_ADULT";
        public static final String ZIP = "ZIP";
        public static final String PREF_ID = "PREF_ID";
        public static final String ADDRESS_1 = "ADDRESS_1";
        public static final String ADDRESS_2 = "ADDRESS_2";
        public static final String ADDRESS_3 = "ADDRESS_3";
        public static final String ADDRESS_4 = "ADDRESS_4";
        public static final String ADDRESS_5 = "ADDRESS_5";
        public static final String NEXT_PREF_ID = "NEXT_PREF_ID";
        public static final String NEXT_ADDRESS_1 = "NEXT_ADDRESS_1";
        public static final String NEXT_ADDRESS_2 = "NEXT_ADDRESS_2";
        public static final String NEXT_ADDRESS_3 = "NEXT_ADDRESS_3";
        public static final String NEXT_ADDRESS_4 = "NEXT_ADDRESS_4";
        public static final String NEXT_ADDRESS_5 = "NEXT_ADDRESS_5";
        public static final String HOPE_H_MONTH = "HOPE_H_MONTH";
        public static final String HOPE_H_DAY = "HOPE_H_DAY";
        public static final String HOPE_M_MONTH = "HOPE_M_MONTH";
        public static final String HOPE_M_DAY = "HOPE_M_DAY"; 
        public static final String ORDER_COMMENT = "ORDER_COMMENT";
        public static final String PROM_CODE = "PROM_CODE";
        public static final String POINT_EMAIL = "POINT_EMAIL";
        public static final String POINT_NO = "POINT_NO";
        public static final String POINT_CD = "POINT_CD";
        public static final String FINISH_FLG = "FINISH_FLG";
        public static final String REFUSAL_FLG = "REFUSAL_FLG";
        public static final String LAST_UPDATE = "LAST_UPDATE";
        public static final String DELETE_DATE = "DELETE_DATE";
        public static final String ORDER_NEW_ID = "ORDER_NEW_ID";
        public static final String MOBILE_FLG = "MOBILE_FLG"; 
        public static final String CLEANING_FLG_1 = "CLEANING_FLG_1";
        public static final String CLEANING_FLG_2 = "CLEANING_FLG_2";
        public static final String CLIENT_IP_ADDRESS = "CLIENT_IP_ADDRESS";
        public static final String LAST_STEP = "LAST_STEP";
        public static final String GUID = "GUID";
        
        public OrderInfo() {}
        
        /**
         * オブジェクト初期化
         */
        public void init(){
            setSchema(OrderInfo.SCHEMA);
            setTable(OrderInfo.TABLE);
        }
    
        public void setOrderId(String val){
            set (OrderInfo.ORDER_ID , val);
        }
    }
}
