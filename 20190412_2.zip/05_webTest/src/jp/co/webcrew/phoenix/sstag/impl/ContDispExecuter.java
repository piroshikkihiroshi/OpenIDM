package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.loader.util.LoadUtil;
import jp.co.webcrew.phoenix.htmlservlet.HtmlPropertiesUtil;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.sstag.util.ClmMetaMstUtil;
import jp.co.webcrew.phoenix.sstag.util.ReplaceUtil;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;
import jp.co.webcrew.phoenix.vtable.bean.ConditionBean;
import jp.co.webcrew.phoenix.vtable.db.VDb;

/**
 * テーブルデータ一覧表示を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class ContDispExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：条件判断ロジック */
    private static final String LOGIC_PARAM_KEY = "logic";

    /** パラメータ名：対象テーブル */
    private static final String TABLE_ID_PARAM_KEY = "table_id";

    /** パラメータ名：出力したいレコードの範囲を指定する（開始レコード番号） */
    private static final String FROM_REC_ID_PARAM_KEY = "from_rec_id";

    /** パラメータ名：出力したいレコードの範囲を指定する（終了レコード番号） */
    private static final String TO_REC_ID_PARAM_KEY = "to_rec_id";

    /** パラメータ名：検索条件の項目名 */
    private static final String KEY_ITEM_PARAM_KEY = "key_item";

    /** パラメータ名：検索条件の文字列 */
    private static final String COND_TEXT_PARAM_KEY = "cond_text";

    /** パラメータ名：複合キー指定用の文字列 */
    private static final String COMPOSITE_KEY_PARAM_KEY = "composite_key";

    /** パラメータ名：並べ替えの基準になる項目名 */
    private static final String ORDER_ITEM_PARAM_KEY = "order_item";

    /** パラメータ名：並べ替えの降順/昇順 */
    private static final String ORDER_DIR_PARAM_KEY = "order_dir";

    /** パラメータ名：出力するレコードの先頭オフセット */
    private static final String OFFSET_PARAM_KEY = "offset";

    /** パラメータ名：出力する（最大の）レコード数 */
    private static final String LIMIT_PARAM_KEY = "limit";

    /** パラメータ名：公開フラグと公開期間を無視して出力する指定 */
    private static final String IGNORE_PUBFLAG_PARAM_KEY = "ignore_pubflag";

    /** パラメータ名：繰り返し前のヘッダ部分に相当するHTML */
    private static final String HEADER_PARAM_KEY = "header";

    /** パラメータ名：繰り返し後のフッタ部分に相当するHTML */
    private static final String FOOTER_PARAM_KEY = "footer";

    /** パラメータ名：繰り返し出力用のHTML */
    private static final String HTML_PARAM_KEY = "html";

    /** パラメータ名：偶数時に出力するHTML */
    private static final String EVEN_PARAM_KEY = "even";

    /** パラメータ名：奇数時に出力するHTML */
    private static final String ODD_PARAM_KEY = "odd";

    /** パラメータ名：初回のみ出力するHTML */
    private static final String FIRST_PARAM_KEY = "first";

    /** パラメータ名：最終回のみ出力するHTML */
    private static final String LAST_PARAM_KEY = "last";

    private static final String FETCH_SIZE_PARAM_KEY="db_fetch_size";
    private static final int DEFAULT_FETCH_SIZE;
    
    /** 置換変数名：カレントセットの最大繰り返し数 */
    private static final String SIZE_VAL_KEY = "size";

    /** 置換変数名：カレントの繰り返し回数 (1～) */
    private static final String COUNT_VAL_KEY = "count";

    /** 置換変数名：偶数・奇数の各回ごとのHTML */
    private static final String EVEN_ODD_VAL_KEY = "even_odd";

    /** 置換変数名：firstで指定されたHTML */
    private static final String FIRST_VAL_KEY = "first";

    /** 置換変数名：last で指定されたHTML */
    private static final String LAST_VAL_KEY = "last";

    /** 置換変数名：レコードID */
    private static final String REC_ID_VAL_KEY = "rec_id";

    /** 置換変数名：コンテンツテーブルの項目名（表示名） */
    private static final String ITEM_NAME_VAL_KEY = "cont.item.{0}.name";

    /** 置換変数名：コンテンツテーブルの項目の値の、先頭から 512バイト分 */
    private static final String ITEM_KEY_DATA_VAL_KEY = "cont.item.{0}.key_data";

    /** 置換変数名：コンテンツテーブルの項目のそのままの値 */
    private static final String ITEM_RAW_VAL_KEY = "cont.item.{0}.raw";

    /** 置換変数名：コンテンツテーブルの項目の値(出力変換した値） */
    private static final String ITEM_VALUE_VAL_KEY = "cont.item.{0}.value";

    /** 置換変数名：コンテンツテーブルの項目の値(出力変換した値） */
    private static final String ITEM_VALUE_NOENC_VAL_KEY = "cont.item.{0}.value_noenc";

    /** 置換変数名：コンテンツテーブルの項目の値(最終的な表示調整した値） */
    private static final String ITEM_DISP_VAL_KEY = "cont.item.{0}.disp";

    /** 置換変数名：コンテンツテーブルの項目の値(最終的な表示調整した値） */
    private static final String ITEM_DISP_NOENC_VAL_KEY = "cont.item.{0}.disp_noenc";

    /** ロガー */
    private static final Logger log = Logger.getLogger(ContDispExecuter.class);

    
    
    
    static
    {
    	int defaultFetchSize=100;

        try {
            HtmlPropertiesUtil prop = new HtmlPropertiesUtil("html_servlet.properties");
            String strVal=ValueUtil.nullToStr( prop.getProperty("dbaccess.fetchsize.contdisp.default"));
            defaultFetchSize=Integer.parseInt(strVal);
            
        } catch (Throwable e) {
        }
        
        DEFAULT_FETCH_SIZE=defaultFetchSize;
        
    }
    
    
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#getExcludeParamList
     * ()
     */
    @SuppressWarnings("unchecked")
    @Override
    protected List getExcludeParamList() {
        return Arrays.asList(HTML_PARAM_KEY, HEADER_PARAM_KEY, FOOTER_PARAM_KEY);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { TABLE_ID_PARAM_KEY, LIMIT_PARAM_KEY, HTML_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String[] logic = PhoenixUtil.split((String) parameters.get(LOGIC_PARAM_KEY), " ");
            String tableId = ValueUtil.nullToStr(parameters.get(TABLE_ID_PARAM_KEY));
            Long fromRecId = ValueUtil.toLong((String) parameters.get(FROM_REC_ID_PARAM_KEY));
            Long toRecId = ValueUtil.toLong((String) parameters.get(TO_REC_ID_PARAM_KEY));
            String keyItem = ValueUtil.nullToStr(parameters.get(KEY_ITEM_PARAM_KEY));
            String condText = ValueUtil.nullToStr(parameters.get(COND_TEXT_PARAM_KEY));
            String compositeKey = ValueUtil.nullToStr(parameters.get(COMPOSITE_KEY_PARAM_KEY));
            String orderItem = ValueUtil.nullToStr(parameters.get(ORDER_ITEM_PARAM_KEY));
            String orderDir = ValueUtil.nullToStr(parameters.get(ORDER_DIR_PARAM_KEY));
            int offset = ValueUtil.toint((String) parameters.get(OFFSET_PARAM_KEY));
            int limit = ValueUtil.toint((String) parameters.get(LIMIT_PARAM_KEY));
            boolean ignorePubflag = SstagUtil.getIgnorePubflag(request, (String) parameters
                    .get(IGNORE_PUBFLAG_PARAM_KEY));
            String header = SstagUtil.getFileData(parameters.get(HEADER_PARAM_KEY), request, response);
            String footer = SstagUtil.getFileData(parameters.get(FOOTER_PARAM_KEY), request, response);
            String html = SstagUtil.getFileData(parameters.get(HTML_PARAM_KEY), request, response);
            String even = ValueUtil.nullToStr(parameters.get(EVEN_PARAM_KEY));
            String odd = ValueUtil.nullToStr(parameters.get(ODD_PARAM_KEY));
            String first = ValueUtil.nullToStr(parameters.get(FIRST_PARAM_KEY));
            String last = ValueUtil.nullToStr(parameters.get(LAST_PARAM_KEY));

            String strFetchSize=ValueUtil.nullToStr(parameters.get(FETCH_SIZE_PARAM_KEY));
            
            
            long startTime=new Date().getTime();
            
            int fetchSize=DEFAULT_FETCH_SIZE;
            if(strFetchSize.length()!=0)
            {
            	fetchSize=Integer.parseInt(strFetchSize);
            }
            
            // offsetとlimitが指定されていない場合、
            if (offset <= 0) {
                offset = 1;
            }
            if (limit <= 0) {
                limit = 1;
            }

            // htmlを組み立てる。
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);

            // 条件判断ロジックが指定されている場合、
            if (!PhoenixUtil.isEmpty(logic)) {

                // 共通情報を取得する。
                SstagGlobalInfo sgInfo = SstagUtil.getSstagGlobalInfo(request);

                // セッションストアで保持しているフォームデータを取得する。
                PostInfo postInfo = StoreUtil.getPostInfo(request);

                JudgementLogicStatus status = logic(request, parameters, sgInfo, null, postInfo, null, logic);
                if (!status.result) {
                    status.writeLog(log);
                    return onerror(request, response, parameters, status.errStatus, status.errMsg);
                }

                // 結果htmlを出力する。
                pw.println(ValueUtil.nullToStr(status.html));

                // 条件判断が偽の場合、フォームを表示しない。
                if (!status.judge) {
                    pw.flush();
                    return sw.toString();
                }
            }

            // 検索条件を設定する。
            List<ConditionBean> conditions = new ArrayList<ConditionBean>();
            if (!PhoenixUtil.isEmpty(keyItem)) {
                conditions.add(new ConditionBean(keyItem, "=", condText));
            }
            if (!PhoenixUtil.isEmpty(compositeKey)) {
                conditions.addAll(ConditionBean.parse(compositeKey));
            }
            //long beforeQueryTime=new Date().getTime();

            
            // テーブルデータを取得する。
            List<Map<String, ClmDataBean>> list = VDb.getList(siteId, tableId, fromRecId, toRecId, conditions,
                    orderItem, orderDir, ignorePubflag,fetchSize);
            log.debug("取得データ数：" + list.size());
            //long endQueryTime=new Date().getTime();

            // ヘッダ部分を出力する。
            pw.println(ReplaceUtil.getReplacedHeader(header, request, offset, limit, list.size()));
            /*
            long startLoopTime=new Date().getTime();
            
            long replaceSum1=0;
            long replaceSum2=0;
            long replaceSum3=0;
            */
            for (int i = offset; i <= offset + limit - 1 && i <= list.size(); i++) {
            	
                //long replace1=new Date().getTime();
                Map<String, ClmDataBean> record = list.get(i - 1);

                // テーブルデータ自体には関係しない置換変数の設定。
                // TODO kurinami 【確認】 required even_odd first last
                // にもincludeある？置換変数入る？
                Map<String, String> replaceMap = new HashMap<String, String>();
                replaceMap.put(SIZE_VAL_KEY, Integer.toString(list.size()));
                replaceMap.put(COUNT_VAL_KEY, Integer.toString(i));
                replaceMap.put(EVEN_ODD_VAL_KEY, (i % 2 == 0 ? even : odd));
                replaceMap.put(FIRST_VAL_KEY, (i == offset ? first : ""));
                replaceMap.put(LAST_VAL_KEY, (i >= offset + limit - 1 || i >= list.size() ? last : ""));

                // テーブルデータに関する置換変数の設定。
                setRecordReplaceVal(request, replaceMap, record);
                //long replace2=new Date().getTime();

                //log.debug("----- replaceMap -----");
                //テスト環境のボトルネックを排除
                //for (Map.Entry<String, String> entry : replaceMap.entrySet()) {
                //    log.debug(entry.getKey() + ":" + entry.getValue());
                //}
                //log.debug("----------------------");

                //long replace3=new Date().getTime();
                
                // htmlの出力。
                pw.println(ReplaceUtil.getReplacedHtml(html, replaceMap));
                //long replace4=new Date().getTime();
                
                //replaceSum1+=(replace2-replace1);
                //replaceSum2+=(replace3-replace2);
                //replaceSum3+=(replace4-replace3);
                
            }
            //long endLoopTime=new Date().getTime();

            // フッタ部分を出力する。
            pw.println(ReplaceUtil.getReplacedHeader(footer, request, offset, limit, list.size()));

            pw.flush();
            
            //long endTime=new Date().getTime();

            
            
            
            
            /*
            log.debug("|contdisp_calc|"+request.getRequestURI()+"|siteid|"+siteId+ "|tblid|"+ tableId+"|cond|"+condText+"|cmpkey|"+compositeKey+
            		"|msec1|"+(endTime - startTime)+
            		"|msec2|"+(beforeQueryTime - startTime)+
            		"|msec3|"+(endQueryTime - beforeQueryTime)+
            		"|msec4|"+(startLoopTime - endQueryTime)+
            		"|msec5|"+(endLoopTime - startLoopTime)+
            		"|msec(rep1)|"+replaceSum1+
            		"|msec(rep2)|"+replaceSum2+
            		"|msec(rep3)|"+replaceSum3+
            		"|msec6|"+(endTime - endLoopTime)
            		);
            
            */
            return sw.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * 条件判断ロジックにより、表示内容を切り替える。
     * 
     * @param request
     * @param sstagParam
     * @param sgInfo
     * @param formInfo
     * @param postInfo
     * @param formUseInfo
     * @param logic
     * @return
     * @throws Exception
     */
    private JudgementLogicStatus logic(HttpServletRequest request, Map<String, String> sstagParam,
            SstagGlobalInfo sgInfo, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String[] logic)
            throws Exception {
        // TODO kurinami 【確認】 ★ 動作未確認
        SstagDynamicLogic logicClass = (SstagDynamicLogic) LoadUtil.newInstanceFromId(request, logic[0]);

        List<String> userParam = Arrays.asList(logic);
        return logicClass.judgementLogic(sgInfo, sstagParam, userParam, formInfo, postInfo, formUseInfo, null, null,
                null, null, true, false);

    }

    /**
     * テーブルデータに関する置換変数を設定する。
     * 
     * @param request
     * @param replaceMap
     * @param record
     * @throws InstantiationException
     * @throws SQLException
     */
    private void setRecordReplaceVal(HttpServletRequest request, Map<String, String> replaceMap,
            Map<String, ClmDataBean> record) throws InstantiationException, SQLException {

        for (ClmDataBean entry : record.values()) {
            String clmId = entry.getMeta().getClmId();

            replaceMap.put(REC_ID_VAL_KEY, Long.toString(entry.getRecId()));
            replaceMap.put(MessageFormat.format(ITEM_NAME_VAL_KEY, clmId), entry.getMeta().getDispName());

            ClmMetaMstUtil clmMetaMstUtil = ClmMetaMstUtil.getInstance(request, entry);

            SstagUtil.setValueToReplaceMap(replaceMap, clmMetaMstUtil.getKeyData(), ITEM_KEY_DATA_VAL_KEY, clmId);

            SstagUtil.setValueToReplaceMap(replaceMap, clmMetaMstUtil.getRaw(), ITEM_RAW_VAL_KEY, clmId);
            SstagUtil.setValueToReplaceMap(replaceMap, clmMetaMstUtil.getValue(), ITEM_VALUE_VAL_KEY, clmId);
            SstagUtil.setValueToReplaceMap(replaceMap, clmMetaMstUtil.getValueNoenc(), ITEM_VALUE_NOENC_VAL_KEY, clmId);
            SstagUtil.setValueToReplaceMap(replaceMap, clmMetaMstUtil.getDisp(), ITEM_DISP_VAL_KEY, clmId);
            SstagUtil.setValueToReplaceMap(replaceMap, clmMetaMstUtil.getDispNoenc(), ITEM_DISP_NOENC_VAL_KEY, clmId);

            SstagUtil.setValuesToReplaceMap(replaceMap, clmMetaMstUtil.getRaws(), ITEM_RAW_VAL_KEY, clmId);
            SstagUtil.setValuesToReplaceMap(replaceMap, clmMetaMstUtil.getValues(), ITEM_VALUE_VAL_KEY, clmId);
            SstagUtil.setValuesToReplaceMap(replaceMap, clmMetaMstUtil.getValuesNoenc(), ITEM_VALUE_NOENC_VAL_KEY,
                    clmId);
            SstagUtil.setValuesToReplaceMap(replaceMap, clmMetaMstUtil.getDisps(), ITEM_DISP_VAL_KEY, clmId);
            SstagUtil.setValuesToReplaceMap(replaceMap, clmMetaMstUtil.getDispsNoenc(), ITEM_DISP_NOENC_VAL_KEY, clmId);
        }

    }

    public static void main(String[] args) {

        String[] tests = new String[] {
                "%{offset.next}, %{ offset.prev}, %{offset.next.1}, %{ offset.prev.1}, %{offset.next.2}, %{ offset.prev.2}, %{offset.this}, %{offset.top}, %{offset.last}",
                "%{page.next}, %{ page.prev}, %{page.next.1}, %{ page.prev.1}, %{page.next.2}, %{ page.prev.2}, %{page.this}, %{page.top}, %{page.last}",
                "%{url.this}, %{ url.param.offset}, %{url.param.cc}, %{url.param.gegege} %{url.gegege}" };

        tests = new String[] { "%{pagelink.offset.5}" };
        // tests = new String[]
        // {"%{url.this} %{url.param.offset} %{url.param.cc} %{url.param.dd}"};

        // ContDispExecuter e = new ContDispExecuter();
        for (String test : tests) {
            System.out.println("----------");
            System.out.println(test);
            // System.out.println(e
            // .getReplacedHeader(test, "http://www.aa.co.jp/bb.html",
            // "offset=1&cc=2&dd=3", 1, 7, 140));
            // System.out.println(e
            // .getReplacedHeader(test, "http://www.aa.co.jp/bb.html",
            // "offset=1&cc=2&dd=3", 7, 7, 140));
            // System.out.println(e
            // .getReplacedHeader(test, "http://www.aa.co.jp/bb.html",
            // "offset=1&cc=2&dd=3", 8, 7, 140));
            // System.out.println(e.getReplacedHeader(test,
            // "http://www.aa.co.jp/bb.html", "offset=1&cc=2&dd=3", 14, 7,
            // 140));
            // System.out.println(e.getReplacedHeader(test,
            // "http://www.aa.co.jp/bb.html", "offset=1&cc=2&dd=3", 135, 7,
            // 140));
            // System.out.println(e.getReplacedHeader(test,
            // "http://www.aa.co.jp/bb.html", "offset=1&cc=2&dd=3", 180, 7,
            // 140));
            // System.out.println(e.getReplacedHeader(test,
            // "http://www.aa.co.jp/bb.html", "offset=1", 21, 7, 101));
        }

    }
}
