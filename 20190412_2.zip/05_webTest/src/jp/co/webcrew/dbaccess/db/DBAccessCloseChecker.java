/**
 * 
 */
package jp.co.webcrew.dbaccess.db;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.ref.WeakReference;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.QueueThreadUtilDBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * Connectionクローズ漏れをチェックする
 * 
 * [実装方式]
 * (1)リクエストスレッド側の処理
 * (1-1)DBAccessのコンストラクタ(オーバーロードしているコンストラクタと引数にjava.sql.Connectionを受け取るコンストラクタは除く)
 * の中で、このクラスのメソッド「doCheck」を呼び出す。
 * 
 * (1-2)メソッド「currentEnabled」がtrueの場合で、
 * DBAccessオブジェクトのdbProp名が
 * 変数「listOutOfTargetDbPropName」の一覧に含まれて『いない』場合、監視対象に加える。
 * ※クローズ済みか否かは、「DBAccess」の中のConnectionがnullの場合、対象から外している
 * 
 * (2)バックグラウンドスレッドの処理
 * 監視対象の一覧にあるDBAccessオブジェクトで、
 * (2-1)クローズ済みの場合、監視対象から除外する＆エラー処理はしない。
 * (2-2)クローズ済みでない＆監視対象期間を過ぎた場合、監視対象から除外する＆エラー処理(エラーログ出力＆エラーメール送信)を行う。
 * (2-3)クローズ済みでない＆監視対象期間内の場合、監視対象としてステイ＆次回のバックグラウンドスレッド起動時にチェックを行う。
 * 
 * @author kazuto.yano
 *
 */
public class DBAccessCloseChecker// implements Runnable
{
	private static Logger logger=Logger.getLogger(DBAccessCloseChecker.class);
	private static boolean currentEnabled=false;
	private static int staticWaitMilliSec=-1;
	
	//private static final long WAIT_MILLISEC=4000;
	
	private static List<String> listOutOfTargetDbPropName=new ArrayList<String>();
	
	/***
	 * クローズ漏れチェックを有効にする
	 * 
	 * @param waitMilliSec チェックまでのインターバル期間を指定する
	 */
	public static void doEnable(int waitMilliSec)
	{
		logger.warn("クローズ漏れチェックを有効にします。監視期間:"+waitMilliSec+"ミリ秒");
		currentEnabled=true;
		staticWaitMilliSec=waitMilliSec;
	}
	
	/***
	 * クローズ漏れチェックを無効にする
	 */
	public static void doDisable()
	{
		logger.info("クローズ漏れチェックを無効にします。");
		currentEnabled=false;
	}
	
	/***
	 * 
	 * @return
	 */
	public static boolean enabled()
	{
		return currentEnabled;
	}
	
	public static void doCheck(DBAccess dbAccess)
	{
		if(!currentEnabled || staticWaitMilliSec<=0)
		{
			return;
		}
		if(listOutOfTargetDbPropName.indexOf(dbAccess.__getName())!=-1)
		{
			return;
		}
		CheckThread4Push.pushChecker(new DBAccessCloseChecker(dbAccess, staticWaitMilliSec));
		
		//new Thread(new DBAccessCloseChecker(dbAccess,staticWaitMilliSec)).start();
		
	}
	
	/****
	 * 監視対象外のdbプロパティ名を設定する
	 * 
	 * @param outOfTargetDBPropNames
	 */
	public static void setOutOfTargetDBPropNames(String... outOfTargetDBPropNames)
	{
		if(outOfTargetDBPropNames.length==0)
		{
			listOutOfTargetDbPropName=new ArrayList<String>();
		}
		else
		{
			listOutOfTargetDbPropName=Arrays.asList(outOfTargetDBPropNames);
		}
	}
	
	private int waitMilliSec;
	private String stackTrace; 
	private DBAccess dbAccess;
	//private Thread transThread;
	private long startTime;

	DBAccessCloseChecker(DBAccess dbAccess,int waitMilliSec)
	{
		Throwable throwable=new Throwable();
		
		StringWriter strWriter=null;
		PrintWriter pWriter=null;
		
		try
		{
			strWriter=new StringWriter();
			pWriter=new PrintWriter(strWriter);
			throwable.printStackTrace(pWriter);
		}
		finally
		{
			try
			{
				pWriter.close();
			}catch(Exception exc){}
		}
		
		//StackTraceElement[] stackTraceElementArray=throwable.getStackTrace();
		
		
		
		this.stackTrace=strWriter.toString();
		this.waitMilliSec=waitMilliSec;
		this.dbAccess=dbAccess;
		this.startTime=new Date().getTime();
		
	}
	
	
	private boolean isClose()
	{
		if(this.dbAccess.__getConnection()==null)
		{
			return true;
		}
		return false;
	}
	
	private boolean isDealine(long currentTime)
	{
		//logger.debug("[start]"+this.startTime+"[wait]"+this.waitMilliSec+"[cur]"+currentTime);
		
		if((this.startTime+this.waitMilliSec)<currentTime)
		{
			return true;
		}
		return false;
	}
	
	
	
	private void check()
	{
		if(this.dbAccess.__getConnection()==null)
		{
			logger.debug("コネクションクローズ済み");
			return;
		}
		
		String message;
		//if(!this.transThread.isAlive())
		message=this.waitMilliSec+"ミリ秒経過しましたが、\nConnectionのcloseが確認できませんでした。\nConnectionの閉じ忘れの可能性が高いですので、確認をお願いします。\n[name]"+this.dbAccess.__getName()+"\n[stacktrace]\n"+this.stackTrace;
		logger.error(message);
	}
	
	
	
	private static List<DBAccessCloseChecker> monitorList=Collections.synchronizedList(new ArrayList<DBAccessCloseChecker>());
	
	static class CheckThread4Push extends QueueThreadUtilDBAccess<DBAccessCloseChecker>
	{
		static CheckThread4Push checkThread4Push;
		
		static
		{
			checkThread4Push=new CheckThread4Push();
			checkThread4Push.start();
			
		}
		
		static void pushChecker(DBAccessCloseChecker checker)
		{
			checkThread4Push.push(checker);
		}
		
		
		
		/* (non-Javadoc)
		 * @see jp.co.webcrew.dbaccess.util.QueueThreadUtilDBAccess#execute(java.lang.Object)
		 */
		@Override
		protected void execute(DBAccessCloseChecker chk) throws Exception 
		{
			monitorList.add(chk);
			List<DBAccessCloseChecker> removeTargetList=new ArrayList<DBAccessCloseChecker>();
			long currentTime=new Date().getTime();
			
			logger.debug("[monitor件数]"+monitorList.size());
			
			for(DBAccessCloseChecker chk2:monitorList)
			{
				//コネクションclose済み
				if(chk2.isClose())
				{
					removeTargetList.add(chk2);
				}
				//コネクションcloseしていない＆監視期間超過(close漏れとみなす)
				else if(chk2.isDealine(currentTime))
				{
					removeTargetList.add(chk2);
					chk2.check();
				}
			}
			
			for(DBAccessCloseChecker chk2:removeTargetList)
			{
				monitorList.remove(chk2);
			}
		}
	}

	
}
