package jp.co.webcrew.login.common;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.DBUtil;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.State3;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.GlobalSession;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.SiteSession;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.ChargeLoginPointUtil;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;

/**
 * ログインに関連するユーティリティクラス
 * 
 * @author Takahashi/miyake
 *
 */
public class LoginUtil {

    /** ロガー */
    private static final Logger log = Logger.getLogger(LoginUtil.class);

    /** サイトセッションのキー：必須項目チェックＯＫ後の遷移URL */
    public static final String SS_PROP_REQUIRE_OK_URL = "REQUIRE_OK_URL";

    /** サイトセッションのキー：必須項目チェックＮＧ（もしくはキャンセル）後の遷移URL */
    public static final String SS_PROP_REQUIRE_NG_URL = "REQUIRE_NG_URL";
    
    /** サイトセッションのキー：必須項目審査中 */
    public static final String SS_PROP_REQUIRE_UNDER_EXAM = "REQUIRE_UNDER_EXAM";
    
    /** 必須項目審査中であることを表すフラグ */
    public static final String FLG_REQUIRE_UNDER_EXAM_ON = "t";

    public static final String SS_PROP_REQUIRE_LOGIN_GUID = "REQUIRE_LOGIN_GUID";

    
    
    /**
     * ログイン処理 (サイトID指定なし）
     * 
     * @param  gsid    カレントの GSID をセットする。この値はフィルターが必ずセットしているのでそれを使用する。
     *                 nullや空文字はチェックエラーになる
     * @param  email ログインID（emailアドレス） null不可 空文字不可
     * @param  passwd パスワード nullを指定すると常にエラーを返すので渡さないこと
     * @return LoginResult
     */
    public static LoginResult login (String gsid , String email , String passwd ) { 
    
        log.info("ログイン login( gsid=" + gsid + " email=" + email + " passwd=" + passwd );
        
       // ----- パラメータチェック
        if( email == null ){
           LoginResult loginResult = new LoginResult();
           loginResult.status = LoginResult.LOGIN_EMAIL_ERROR;
           return loginResult;
        } else if( passwd == null ){
           LoginResult loginResult = new LoginResult();
           loginResult.status = LoginResult.LOGIN_PASSWD_ERROR;
           return loginResult;
        }
        
       // ----- ログイン処理実行
        return doLogin (gsid , email , passwd , null);
    }
    
    /**
     * ログイン処理 (サイトID指定あり）
     * 
     * @param  gsid    カレントの GSID をセットする。この値はフィルターが必ずセットしているのでそれを使用する。
     *                 nullや空文字はチェックエラーになる
     * @param  email   ログインID（emailアドレス） null,空文字はエラーが返る
     * @param  passwd  パスワード nullを指定すると常にエラーを返る
     * @param  siteId  サイトIDを渡す。ログインの認証自体には使用されないがどのサイトからログインしたかのログで使用。
     * @return LoginResult
     */
    public static LoginResult login (String gsid , String email , String passwd , String siteId) { 
    
        log.info("ログイン login( gsid=" + gsid + " email=" + email + " passwd=" + passwd + " siteId=" + siteId );
        
       // ----- パラメータチェック
        if( email == null ){
           LoginResult loginResult = new LoginResult();
           loginResult.status = LoginResult.LOGIN_EMAIL_ERROR;
           return loginResult;
        } else if( passwd == null ){
           LoginResult loginResult = new LoginResult();
           loginResult.status = LoginResult.LOGIN_PASSWD_ERROR;
           return loginResult;
        }
        
       // ----- ログイン処理実行
        return doLogin( gsid , email , passwd , siteId );
    }
    
    /**
     * ログイン処理 (パスワード指定なし、サイトID指定なし）
     * 
     * @param  gsid    カレントの GSID をセットする。この値はフィルターが必ずセットしているのでそれを使用する。
     *                 nullや空文字はチェックエラーになる
     * @param  email ログインID（emailアドレス） null不可 空文字不可
     * @return LoginResult
     */
    public static LoginResult loginWoPassword (String gsid , String email ) { 
    
        log.info("ログイン loginWoPassword( gsid=" + gsid + " email=" + email );
        
       // ----- パラメータチェック
        if( email == null ){
           LoginResult loginResult = new LoginResult();
           loginResult.status = LoginResult.LOGIN_EMAIL_ERROR;
           return loginResult;
        }
        
       // ----- ログイン処理実行
        return doLogin (gsid , email , null , null);
    }
    
    /**
     * ログイン処理 (パスワード指定なし、サイトID指定あり）
     * 
     * @param  gsid    カレントの GSID をセットする。この値はフィルターが必ずセットしているのでそれを使用する。
     *                 nullや空文字はチェックエラーになる
     * @param  email   ログインID（emailアドレス） null,空文字はエラーが返る
     * @param  siteId  サイトIDを渡す。ログインの認証自体には使用されないがどのサイトからログインしたかのログで使用。
     * @return LoginResult
     */
    public static LoginResult loginWoPassword (String gsid , String email , String siteId) { 
    
        log.info("ログイン loginWoPassword( gsid=" + gsid + " email=" + email + " siteId=" + siteId );
        
       // ----- パラメータチェック
        if( email == null ){
           LoginResult loginResult = new LoginResult();
           loginResult.status = LoginResult.LOGIN_EMAIL_ERROR;
           return loginResult;
        }
        
       // ----- ログイン処理実行
        return doLogin( gsid , email , null , siteId );
    }
    
    
    /**
     * ログイン処理を行う (共通内部処理）
     * 
     * 処理結果はLoginResultオブジェクトで返却
     * 
     * @param gsid   nullや空文字可でも受け付けるが有効性チェックでエラーになるので意味はない。
     * @param email   ログインID（emailアドレス） null,空文字はエラーが返る
     * @param passwd  パスワード nullを指定するとパスワード無しでのログイン
     * @param siteId  サイトIDを渡す。ログインの認証自体には使用されないがどのサイトからログインしたかのログで使用
     * @return
     */
    private static LoginResult doLogin (String gsid , String email , String passwd , String siteId) { 
    
        log.info("ログイン処理 doLogin: gsid=" + gsid + " email=" + email + " passwd=" + passwd + " siteId=" + siteId );
        LoginResult loginResult = new LoginResult();
        
        // GSIDをチェック
        if (! isValidGsid(gsid)) {
            log.info("不正なgsidが渡されました。");
            loginResult.status = LoginResult.LOGIN_GSID_ERROR;
            return loginResult;
        }
        
       // ----- Emailの null チェック 
        if( email == null ){
           loginResult.status = LoginResult.LOGIN_EMAIL_ERROR;
           return loginResult;
        }

        DBAccess db = null;
        try {
            db = new DBAccess();
            db.setAutoCommit(false);
            
            // ユーザIDとパスワードで認証
            loginResult = authUser(db, email, passwd);
            
            // 認証に失敗した場合はエラー
            if (! loginResult.isSuccess()) {
                db.rollback();
                log.info("ログイン認証失敗: gsid=" + gsid + " email=" + email + " passwd=" + passwd + " siteId=" + siteId );
                try {
                    Thread.sleep(1000); // １秒間停止
                    log.info("1秒スリープ" );
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                return loginResult;
            }

            // 認証後のguidを取得
            String loginGuid = loginResult.loginGuid;
            
            // guidとgsidの対応関係が異なる場合、データベースの整合性を取る
            adjustGuid(db , gsid , loginGuid);

            // 最終ログイン日付時刻を更新
            MemberMst.updateLastLoginDatetime(db , loginGuid);

            // リマインダ処理されていた場合、通常に戻す この処理はrequiredToChangePasswdOnly（）で処理します。
            // MemberMst.rollbackRemind(db , loginGuid);

            // ログイン済みフラグを立てる
            SiteSession.setLoginFlgOn(db , gsid);
            
            // コミット
            db.commit();

            log.info("ログイン認証OK: gsid=" + gsid + " email=" + email + " passwd=" + passwd + " siteId=" + siteId );
            
            ChargeLoginPointUtil objChargeLoginPoint = new ChargeLoginPointUtil(db);
            //初回ログインボーナスポイント付与処理
            if (objChargeLoginPoint.getFirstLoginPointCharge().equals("true"))
            {
                if (objChargeLoginPoint.checkFirstLogin(loginGuid))
                {
            		int nResultFirst = objChargeLoginPoint.chargeFirstLoginPoint(loginGuid);
					if (nResultFirst == ChargeLoginPointUtil.CHARGE_FIRST_FAILURE)
					{
						//ポイント付与処理で例外が発生
						log.error("例外が発生したためポイントを付与出来ませんでした。GUID=" + loginGuid);
					}
					else {
						// ポイント付与が正常に完了したのでコミットする
						db.commit();
					}
                }
            }
            
        } catch (SQLException e) {
            log.error("ログイン処理中にデータベースエラーが発生しました。" , e);
            loginResult.status = LoginResult.LOGIN_DB_ERROR;
            db.rollback();

        } catch (Exception e) { 
            log.error("ログイン認証中に例外エラーが発生しました。" , e);
            loginResult.status = LoginResult.LOGIN_OTHER_ERROR;
            db.rollback();
                    
        } finally {
            DBAccess.close(db);
        }
                
        return loginResult;
    }
    
    /**
     * 本登録ユーザのログイン認証処理を行い、認証後のguidを返す。
     * 
     * 処理に成功したら、整合性を取った後のguidを返す。
     * 認証処理に失敗した場合は、nullを返す。
     * 
     * @param db DBアクセサ
     * @param gsid ユーザのgsid
     * @param login_id ログインID（メールアドレス）
     * @param password ログインパスワード
     * @return
     * @throws SQLException
     */
    private static LoginResult authUser(DBAccess db ,  String login_id , String password)  {
        log.debug("認証処理開始");
        LoginResult ret = new LoginResult();

        /*
         * 引数チェック
         */
        // dbをチェック
        if (db == null) {
            log.error("データベース接続に失敗したか、接続が失われました。");
            ret.status = LoginResult.LOGIN_DB_CONNECTION_ERROR;
            return ret;
        }


        // ログインidをチェック
        if (login_id == null || login_id.equals("")) {
            log.info("不正なログインIDが渡されました。");
            ret.status = LoginResult.LOGIN_ID_ERROR;
            return ret;
        }

        // パスワードがnullの場合は、パスワード無しの特殊な認証処理を行う
        if (password == null) {
            return authUser(db, login_id);
        }
        
        // パスワードが指定されている場合は、通常の認証処理を行う
        try {
            // 抽出条件
            // ・本登録フラグ オン
            // ・ログイン禁止フラグ オフ
            String sql = "SELECT GUID FROM MEMBER_MST WHERE (EMAIL=? OR MB_MAIL=? OR CP_MAIL=?) AND PASSWD=? AND FORMAL_FLAG='1' AND INVALID_FLAG='0' ";
            
            db.prepareStatement(sql);
            db.setString(1, login_id);
            db.setString(2, login_id);
            db.setString(3, login_id);
            db.setString(4, DBUtil.getDigestOf(password)); // まず、sha1との比較を行う
        
            Record rec = Record.getFirstRowOf(db);
            if (rec == null) {
                db.setString(1, login_id);
                db.setString(2, login_id);
                db.setString(3, login_id);
                db.setString(4, password); // 次に、平パスワードで比較を行う
                rec = Record.getFirstRowOf(db);

                if (rec == null) {

                    //認証エラー
                    log.info("会員マスタ上に該当するレコードが見つかりませんでした");
                    ret.status = LoginResult.LOGIN_AUTH_ERROR;
                    return ret;
                }
            }
            
            String memberMst_guid = rec.getString("GUID");
            log.info("global login auth ok");
            log.info("guid=" + memberMst_guid);

            // guidの妥当性をチェック
            if (! isValidGuid(memberMst_guid)) {
                log.info("guidの取得に失敗しました。");
                ret.status = LoginResult.LOGIN_GUID_ERROR;
                return ret;
            }

            log.info("認証に成功しました。");
            
            ret.loginGuid = memberMst_guid;
            ret.status    = LoginResult.LOGIN_SUCCESS;
            
        } catch (SQLException e) { 
            log.error("ログイン認証中にデータベースエラーが発生しました。" , e);
            ret.status = LoginResult.LOGIN_DB_ERROR;
        } catch (Exception e) { 
            log.error("ログイン認証中に例外エラーが発生しました。" , e);
            ret.status = LoginResult.LOGIN_OTHER_ERROR;
        } 

        return ret;

    }

    /**
     * 本登録ユーザのログイン認証処理を行い、認証後のguidを返す。
     * （パスワード無しで認証する場合）
     * 
     * 処理に成功したら、整合性を取った後のguidを返す。
     * 認証処理に失敗した場合は、nullを返す。
     * 
     * @param db DBアクセサ
     * @param gsid ユーザのgsid
     * @param login_id ログインID（メールアドレス）
     * @param password ログインパスワード
     * @return
     * @throws SQLException
     */
    private static LoginResult authUser(DBAccess db ,  String login_id)  {
        log.debug("ユーザ認証処理開始：パスワード無し");
        LoginResult ret = new LoginResult();

        /*
         * 引数チェック
         */
        // dbをチェック
        if (db == null) {
            log.error("データベース接続に失敗したか、接続が失われました。");
            ret.status = LoginResult.LOGIN_DB_CONNECTION_ERROR;
            return ret;
        }


        // ログインidをチェック
        if (login_id == null || login_id.equals("")) {
            log.info("不正なログインIDが渡されました。");
            ret.status = LoginResult.LOGIN_ID_ERROR;
            return ret;
        }

        try {
            // 抽出条件
            // ・本登録フラグ オン
            // ・ログイン禁止フラグ オフ
            String sql = "SELECT GUID FROM MEMBER_MST WHERE (EMAIL=? OR MB_MAIL=? OR CP_MAIL=?) AND FORMAL_FLAG='1' AND INVALID_FLAG='0' ";
            
            db.prepareStatement(sql);
            db.setString(1, login_id);
            db.setString(2, login_id);
            db.setString(3, login_id);
            
            Record rec = Record.getFirstRowOf(db);
            if (rec == null) {
                //認証エラー
                log.info("会員マスタ上に該当するレコードが見つかりませんでした");
                ret.status = LoginResult.LOGIN_AUTH_ERROR;
                return ret;
            }
            
            String memberMst_guid = rec.getString("GUID");
            log.info("global login auth ok ; guid=" + memberMst_guid);

            // guidの妥当性をチェック
            if (! isValidGuid(memberMst_guid)) {
                log.info("guidの取得に失敗しました。");
                ret.status = LoginResult.LOGIN_GUID_ERROR;
                return ret;
            }

            log.info("認証に成功しました。");
            
            ret.loginGuid = memberMst_guid;
            ret.status    = LoginResult.LOGIN_SUCCESS;
            
        } catch (SQLException e) { 
            log.error("ログイン認証中にデータベースエラーが発生しました。" , e);
            ret.status = LoginResult.LOGIN_DB_ERROR;
        } catch (Exception e) { 
            log.error("ログイン認証中に例外エラーが発生しました。" , e);
            ret.status = LoginResult.LOGIN_OTHER_ERROR;
        } 

        return ret;

    }
    
    /**
     * 仮登録ユーザのログイン認証処理を行い、認証後のguidを返す。
     * 
     * 処理に成功したら、整合性を取った後のguidを返す。
     * 認証処理に失敗した場合は、nullを返す。
     * 
     * @param db DBアクセサ
     * @param gsid ユーザのgsid
     * @param email ログインID（メールアドレス）
     * @param password ログインパスワード
     * @param siteId 未使用
     * @return LoginResult 結果オブジェクト
     */
    public static LoginResult authTemporaryUser(DBAccess db ,  String gsid , String email , String password , String siteId)  {
        log.debug("認証処理開始");
        LoginResult ret = new LoginResult();

        /*
         * 引数チェック
         */
        // dbをチェック
        if (db == null) {
            log.error("データベース接続に失敗したか、接続が失われました。");
            ret.status = LoginResult.LOGIN_DB_CONNECTION_ERROR;
            return ret;
        }


        // ログインidをチェック
        if (email == null || email.equals("")) {
            log.info("不正なログインIDが渡されました。");
            ret.status = LoginResult.LOGIN_ID_ERROR;
            return ret;
        }

        try {
 
            SystemProperties props = new SystemProperties(db);
            String virtualCurrentDateTime = getVirtualCurrentDateTime(props);
            log.info("仮想の現在日付時刻=" + virtualCurrentDateTime);

            String sql = "SELECT GUID FROM MEMBER_MST WHERE (EMAIL=? OR MB_MAIL=? OR CP_MAIL=?) AND PASSWD=? AND LIMIT_DATETIME >=? ";
            db.prepareStatement(sql);
            db.setString(1, email);
            db.setString(2, email);
            db.setString(3, email);
            db.setString(4, DBUtil.getDigestOf(password));
            db.setString(5, virtualCurrentDateTime);
            Record rec = Record.getFirstRowOf(db);
            if (rec == null) {
                db.setString(1, email);
                db.setString(2, email);
                db.setString(3, email);
                db.setString(4, password);
                db.setString(5, virtualCurrentDateTime);
                rec = Record.getFirstRowOf(db);
                
                if (rec == null) {
                    log.info("認証に失敗しました。");
                    ret.status = LoginResult.LOGIN_AUTH_ERROR;
                    return ret;
                    
                }
                
            }
            
            String memberMst_guid = rec.getString("GUID");
            log.info("auth temporary user ok");
            log.info("guid=" + memberMst_guid);

            // guidの妥当性をチェック
            if (! isValidGuid(memberMst_guid)) {
                log.info("guidの取得に失敗しました。");
                ret.status = LoginResult.LOGIN_GUID_ERROR;
                return ret;
            }

            log.info("認証に成功しました。");

            adjustGuid(db, gsid, memberMst_guid);
            
            ret.loginGuid = memberMst_guid;
            ret.status    = LoginResult.LOGIN_SUCCESS;
            
        } catch (SQLException e) { 
            log.error("ログイン認証中にデータベースエラーが発生しました。" , e);
            ret.status = LoginResult.LOGIN_DB_ERROR;
        } catch (Exception e) { 
            log.error("ログイン認証中に例外エラーが発生しました。" , e);
            ret.status = LoginResult.LOGIN_OTHER_ERROR;
        } 

        return ret;

    }

    /**
     * 仮登録ユーザの認証処理を行い、認証後のguidを返す。
     * 
     * 処理に成功したら、整合性を取った後のguidを返す。
     * 認証処理に失敗した場合は、nullを返す。
     * 
     * @param gsid ユーザのgsid
     * @param email ログインID（メールアドレス）
     * @param password ログインパスワード
     * @param siteId 未使用
     * @return LoginResult 結果オブジェクト
     */
    public static LoginResult authTemporaryUser (String gsid , String email , String passwd , String siteId) { 
        LoginResult loginResult = new LoginResult();
        DBAccess db = null;
        try {
            db = new DBAccess();
            db.setAutoCommit(false);
            
            loginResult =  authTemporaryUser(db , gsid ,email , passwd , siteId );
            if (! loginResult.isSuccess()) {
                db.rollback();
            } else {
                db.commit();
            }
            
        } catch (SQLException e) {
            loginResult.status = LoginResult.LOGIN_DB_ERROR;
            db.rollback();
            log.error("ログイン処理中にデータベースエラーが発生しました。" , e);

        } finally {
            DBAccess.close(db);
        }
                
        return loginResult;
    }
    
    
    /**
     * gsidが指すguidがログイン前と異なる場合にはログイン後の guid をセットする
     * @param db
     * @param gsid    ブラウザベースのgsid（ブラウザのクッキー由来の、セッションフィルタで得られるgsid）
     * @param newGuid 認証後のguid（Member_Mstすなわち認証データベースから得られたguid）
     * @throws SQLException
     */
    private static void adjustGuid(DBAccess db , String gsid , String newGuid) throws SQLException
    {

        log.debug("global_session にログイン後の新GUIDをセットします");
        
       // ----- gsid から現在の GS 情報を取得
        GlobalSession gs = new GlobalSession();
        if (!gs.load(db , gsid)) {
            log.info("GlobalSessionにデータが見つかりませんでした。gsid = " + gsid);
            return;
        }
    
       // ----- GSが持っている GUID と、ログイン後の正しいGUIDを比較して異なる場合にはログイン後のGUID をGSにセットする
        if(! gs.getGuid().equals( newGuid )){
            log.info( "GLOBAL_SESSIONに新しい GUID がセットされました");
            log.info(" OLD GUID = " + gs.getGuid());
            log.info(" NEW GUID = " + newGuid);      
            GlobalSession.updateGuid( db, gsid, newGuid) ;
            
            // MemberMstの不要データを削除。
            MemberMst.deleteRedundantData(db, gs.getGuid());
        }   
        
    }
    
    /**
     * gsidが、アプリケーション上、論理的に有効な値か否か
     * 
     * 有効値ならtrue 無効値ならfalse
     * 
     * 有効・無効の論理値はセッションフィルタ側で決定されている
     * 
     * @param gsid
     * @return
     */
    public static boolean isValidGsid(String gsid) {
        if (gsid == null || gsid.equals("") || gsid.equals("0")
                || gsid.equals("-1")) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * guidが、アプリケーション上、論理的に有効な値か否か
     * 
     * 有効値ならtrue 無効値ならfalse
     * 
     * 有効・無効の論理値はセッションフィルタ側で決定されている
     *
     * @param guid
     * @return
     */
    public static boolean isValidGuid(String guid) {
        if (guid == null || guid.equals("") || guid.equals("0")
                || guid.equals("-1")) {
            return false;
        } else {
            return true;
        }
    }   



    
    private static String getVirtualCurrentDateTime(SystemProperties props ){
        String move_time = props.get(SystemProperties.TEST_MOVE_CURRENT_DATETIME);
        return DateUtil.getDateTime(move_time);
    }

    /**
     * <pre>
     * 会員パスワードが暗号化されているかどうかを判別して返す。
     * 
     * 暗号化されていれば true ，そうでなければ false を返す。
     * 
     * 渡された文字列が null の場合は false を返す。
     * 
     * </pre>
     * @param passwd 会員パスワード
     */
    public static boolean isHashedPasswd(String passwd) {

        return MemberMst.isHashedPasswd(passwd);
        
    }

    /**
     * <pre>
     * 会員情報の必須条件が満たされているかをチェックする。
     * 
     * 満たされていればTRUEを返す。
     * 
     * 満たされていなければ、必須入力画面にリダイレクトし、FALSEを返す。
     * 
     * 処理途中でエラーが発生したり、判別不可能な場合は N/A を返す。
     *
     * 
     * 1) 必須項目入力済み、かつ、パスワードが仮登録状態になければ、 TRUE。
     * 
     * 2) 未入力の必須項目があれば、FALSE。
     * 
     * 3) パスワードが仮登録状態にあれば FALSE。
     * 
     * 4) 仮登録会員であれば N/A (本登録会員のみが調査対象のはず)。
     * 
     * 5) 処理の途中でエラーが発生した場合は、 N/A。
     * 
     * 呼び出し側は、FALSE が返った場合、Servlet処理を終了すること。
     *  
     * </pre>
     * @param request
     * @param response
     * @param loginGuid ログインユーザのGUID（ログイン後の確定GUID）
     * @param ok_url
     * @param ng_url
     */
    public static State3 checkRequiredAndRedirect(
            HttpServletRequest  request ,
            HttpServletResponse response ,
            String              loginGuid ,
            String              ok_url ,
            String              ng_url
            
        ) {
        
        
        if (request == null) {
            log.info("引数が不正です。処理を中止します。request is null");
            return State3.NA();
        }

        if (ok_url == null || ok_url.trim().equals("")) {
            log.info("引数が不正です。処理を中止します。ok_url=" + ok_url);
            return State3.NA();
        }

        if (ng_url == null || ng_url.trim().equals("")) {
            log.info("引数が不正です。処理を中止します。ng_url=" + ng_url);
            return State3.NA();
        }

        
        if (! SessionFilterAlterUtil.isValidGuid(loginGuid)) {
            log.info("guidが不正です。guid=" + loginGuid);
            return State3.NA();
        }

// request はまだログイン済みとなっていない
//        if (! SessionFilterAlterUtil.isLoggedIn(request)) {
//            log.info("未ログインです。guidが確定していません。処理を中止します。guid=" + loginGuid);
//            return State3.NA();
//        }

        String gsid = SessionFilterAlterUtil.getGsid(request);
        if (! SessionFilterAlterUtil.isValidGsid(gsid)) {
            log.info("guidが不正です。gsid=" + gsid);
            return State3.NA();
        }
        
//        // 一度ログアウトする。
//        try {
//            LogoutUtil.logout(gsid, request);
//            
//        } catch (Exception e) {
//            // ログアウトできなかったらエラー
//            log.error("ログアウトに失敗しました。" , e);
//            return State3.NA;
//        }
        
        // 必須項目チェック中であることをサイトセッションに登録する。
        if (! setSiteSessionProp(request, SS_PROP_REQUIRE_UNDER_EXAM , FLG_REQUIRE_UNDER_EXAM_ON)) {
            return State3.NA();
        }

        try {
            

            // サイトセッションプロパティを削除
            removeSiteSessionProp(request, SS_PROP_REQUIRE_OK_URL);
            removeSiteSessionProp(request, SS_PROP_REQUIRE_NG_URL);

            State3 chkOK = MemberMst.isFilledRequiredInfo(loginGuid);
            
            if ( chkOK.isTrue() ) {

                // 必須入力済み。呼び出し元の処理を継続する。
                
                removeSiteSessionProp(request, SS_PROP_REQUIRE_UNDER_EXAM); // 審査フラグOFF
                return State3.TRUE();
            
            } else {

                // 必須項目チェックをパスできなかった場合、一度ログアウトする。
                try {
                    LogoutUtil.logout(gsid, request);
                  
                } catch (Exception e) {
                    // ログアウトできなかったらエラー
                    log.error("ログアウトに失敗しました。" , e);
                    return State3.NA();
                }
                
                if (chkOK.isNA()) {
                    // チェック中に論理エラーや例外エラーが発生したことを呼び出し元に通知。
                    
                    // 審査フラグはそのまま
                    // removeSiteSessionProp(request, SS_PROP_UNDER_EXAM_OF_REQUIRED_INFO);
                    return State3.NA();
                }

                // 必須項目チェックの結果が NG と確定した場合
                
                // サイトセッションに必要な情報を積み、必須入力画面にリダイレクト
                
                setSiteSessionProp(request, SS_PROP_REQUIRE_OK_URL , ok_url);
                setSiteSessionProp(request, SS_PROP_REQUIRE_NG_URL , ng_url);
                setSiteSessionProp(request, SS_PROP_REQUIRE_LOGIN_GUID , loginGuid);

                // パスワード変更だけの場合パスワード変更画面へ遷移それ以外は必須項目入力画面へ
                if (requiredToChangePasswdOnly(loginGuid).isTrue()) {
                    redirectToChangePasswdTop(request, response);
                } else {
                    redirectToRequireTop(request, response);
                }

                return State3.FALSE();
            }
        
        } catch (Exception e) {
            log.error("必須入力チェック処理中に例外エラーが発生しました。" , e);
            
            // 審査フラグはそのまま
//          removeSiteSessionProp(request, SS_PROP_UNDER_EXAM_OF_REQUIRED_INFO);
            return State3.NA();
        }

    }


    /**
     * <pre>
     * 本登録ユーザがパスワード仮登録であるか否かを返す。
     * 
     * 
     * ユーザが本登録ユーザで、かつ必須入力が未入力のものがあれば FALSE
     *
     * ユーザが本登録ユーザでは無い場合は N/A
     * 
     * パスワードが仮登録状態であれば FALSE
     * 
     * 処理途中でエラーが発生した場合は N/A
     * 
     * なお、パスワードが仮登録状態にある場合は、必須項目が入力されて
     * いないものとして扱い、FALSEを返す。
     * 
     * </pre>
     * @param guid
     * @return State3
     */
    public static State3 requiredToChangePasswdOnly(String guid) {

        if (! SessionFilterAlterUtil.isValidGuid(guid)){
            log.info("guidが不正です。guid=" + guid);
            return State3.NA();
        }
        
        MemberMst member = new MemberMst(guid);
        
        DBAccess db = null;
        try {
            db = new DBAccess();
            if (! member.load(db)) {
                log.info("MEMBER_MST の読み込みに失敗しました。guid=" + guid);
                return State3.NA();
            }
            
            if (! member.isHontouroku()) {
                return State3.NA();
            }

            if (! member.isFilledRequiredInfo()) {
                return State3.FALSE();
            }

            // 暗号化されてない場合
            if (!member.isHavingHashedPasswd()) {
                /*String nickName = ValueUtil.nullToStr(member.get(MemberMst.NICKNAME)).trim();
                String mailPrefix = ValueUtil.nullToStr(member.getPrimaryEmail()).replaceFirst("@.*$", "");
                if(mailPrefix.length() > 10) mailPrefix = mailPrefix.substring(0, 10);
                if (nickName.length() == 0 || nickName.equals(mailPrefix)) {
                    return State3.FALSE();
                }
                */
                // リマインダ処理されていた場合、通常に戻す
                if (MemberMst.FLG_REMINDER_SENT.equals(member.get(MemberMst.REMINDER_FLAG))) {
                    MemberMst.rollbackRemind(db, guid);
                    return State3.TRUE();
                }

            }

        } catch (SQLException e) {
            log.error("データベース処理で例外エラーが発生しました。" , e);
            return State3.NA();
        
        } finally {
            DBAccess.close(db);
        }
        return State3.FALSE;
    }

    /**
     * <pre>
     * パスワード変更画面に遷移（リダイレクト）する。
     * </pre>
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    private static boolean redirectToChangePasswdTop (HttpServletRequest request , HttpServletResponse response) 
            throws IOException , ServletException {

        DBAccess db = null;
        try {
            db = new DBAccess();
            
            SystemProperties sysProp = new SystemProperties(db);
            String url = ValueUtil.nullToStr(sysProp.get("MYPAGE_REQUIRE_CHANGE_PASSWORD_TOP"));
            if (url.equals("")) {
                return false;
            }
            
            response.sendRedirect(url);
 
            return true;
            
        } catch (SQLException e) {
            log.error("例外エラーが発生しました。" , e);
            return false;
        
        } finally {
            DBAccess.close(db);
        }
    
    }

    /**
     * <pre>
     * 必須入力画面に遷移（リダイレクト）する。
     * </pre>
     * @param request
     * @param response
     * @return
     * @throws IOException
     * @throws ServletException
     */
    private static boolean redirectToRequireTop (HttpServletRequest request , HttpServletResponse response) 
            throws IOException , ServletException {

        DBAccess db = null;
        try {
            db = new DBAccess();
            
            SystemProperties sysProp = new SystemProperties(db);
            String url = ValueUtil.nullToStr(sysProp.get("MYPAGE_REQUIRE_TOP"));
            if (url.equals("")) {
                return false;
            }
            
            response.sendRedirect(url);
 
            return true;
            
        } catch (SQLException e) {
            log.error("例外エラーが発生しました。" , e);
            return false;
        
        } finally {
            DBAccess.close(db);
        }
    
    }
    

    
    /**
     * <pre>
     * サイトセッションプロパティを削除する。
     * </pre>
     * @param request
     * @param key
     * @return
     */
    private static boolean removeSiteSessionProp(HttpServletRequest request , String key) {
        try {
            SessionFilterAlterUtil.removeSiteSessionProps(request, key);
            return true;
        
        } catch (SQLException e) {
            log.error("サイトセッションの登録に失敗しました。key=" + key  , e);
            return false;
        }
    }   
    
    /**
     * <pre>
     * サイトセッションプロパティをセットする。
     * </pre>
     * @param request
     * @param key
     * @return
     */
    private static boolean setSiteSessionProp(HttpServletRequest request , String key , String value) {
        try {
            SessionFilterAlterUtil.setSiteSessionProps(request, key, value);
            return true;
        
        } catch (SQLException e) {
            log.error("サイトセッションの登録に失敗しました。key=" + key + ", value=" + value , e);
            return false;
        }
    }

    /**
     * <pre>
     * ユーザのログインフラグをONにする。
     * </pre>
     * @param gsid
     * @param request
     * @throws Exception
     */
    public static void setLoginFlgOn(String gsid, HttpServletRequest request)
            throws Exception {

        DBAccess db = null;
        try {
            db = new DBAccess();
            db.setAutoCommit(false);

            // ログイン済みフラグをオンにする
            SiteSession.setLoginFlgOn(db, gsid);

            // コミット
            db.commit();

        } catch (SQLException e) {
            log.error("ログイン処理中にデータベースエラーが発生しました。", e);
            db.rollback();
            throw e;

        } catch (Exception e) {
            log.error("ログイン処理中に例外エラーが発生しました。", e);
            db.rollback();
            throw e;

        } finally {
            DBAccess.close(db);
        }

        // リクエスト属性上の値への処理
        request.setAttribute("faon.login_flag", "t");

    }

}
