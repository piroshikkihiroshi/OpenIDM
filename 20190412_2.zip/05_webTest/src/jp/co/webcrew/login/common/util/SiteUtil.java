/**
 *
 */
package jp.co.webcrew.login.common.util;


import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;


import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.SiteMst;
import jp.co.webcrew.login.common.db.util.DBException;
import jp.co.webcrew.login.common.db.util.Record;


/**
 * サイトマスタ (SITE_MST , SITE_RECOG_MST)に関連するユーティリティークラス
 *
 * @author Takahashi
 *
 */
public class SiteUtil {

	/** ロガー */
	private static final Logger log = Logger.getLogger(SiteUtil.class);

	/**
	 * サイトIDが、となしばのサイトIDであるか否かを返す
	 *
	 * @param siteId
	 * @return
	 */
	public static boolean isTonashibaSiteId (String siteId) {
		if (siteId == null || siteId.equals("")) {
			log.error("引数エラー：サイトIDにnullまたは空の文字列が渡されました。");
			throw new IllegalArgumentException("引数エラー：サイトIDにnullまたは空の文字列が渡されました。");
		}

		if (siteId.equals(AppConstants.SITE_ID_TONASHIBA)) {
			return true;
		} else {
			return false;
		}
	}

   /**
    * <pre>
    * 指定された siteID がステップサイトであるか否かを返す
    *
    * true  ステップサイトである
    * false ステップサイトではない
    *
    * </pre>
    *
    * @param db       DBAccess オブジェクト
    * @param siteId   サイトID
    *
    * @throws SQLException              データベースエラー
    * @throws IllegalArgumentException  引数エラー
    */
    public static boolean isStepSite ( DBAccess db , String  siteId) throws SQLException {
    	if (siteId == null ||  siteId.equals("")) {
			log.error("引数エラー：サイトIDが指定されていません。");
    		throw new IllegalArgumentException("引数エラー：サイトIDが指定されていません。");
    	}

    	String sql = "SELECT SITE_ID FROM SITE_MST WHERE SITE_ID=? AND STEP_FLAG=1";
    	db.prepareStatement(sql);
    	db.setString(1, siteId);
    	Record rec = Record.getFirstRowOf(db);
    	if (rec == null) {
    		return false;
    	} else {
    		return true;
    	}
    }

   /**
    *  指定された siteID, subNum で遷移先URL (step0) を探す
    *
    * @param db       DBAccess オブジェクト
    * @param request  HTTP request
    * @param siteId   サイトID
    * @param subNum   サイトサブ番号
    *
    * @auther Orig Takahashi/ Modify Miyake
    * @since 2007.11.01 subNum に対応
    */
    public static String getStep0URI( DBAccess db , HttpServletRequest request,String  siteId, String subNum )
      throws SQLException
    {

        String method = request.getMethod();
        log.info("method = " + method);
        String show_url  = "";
        String schema    = db.getSchema(".");

        StringBuffer sql = new StringBuffer();

       // ----- subNum 指定なし
       //  step への戻りURLが入っていて、かつ context が最長のものを採用
       //
        if( subNum == null || subNum.length() == 0 ){
           sql.append("SELECT  MST2.STEP0_SHOW_URL "
                    + "       ,MST2.STEP0_ANSWER_URL "
                    + " FROM " + schema + "SITE_MST MST, "
                    +            schema + "SITE_RECOG_MST MST2 "
                    + " WHERE MST.SITE_ID = MST2.SITE_ID "
                    + "   AND MST.STEP_FLAG = '1' "
                    + "   AND INVALID_FLAG  = '0' "
                    + "   AND MST.SITE_ID   = ?"
                    + "   AND ( ( MST2.STEP0_SHOW_URL IS NOT NULL AND"
                    + "           LENGTH(MST2.STEP0_SHOW_URL) > 0 "
                    + "          ) OR "
                    + "         ( MST2.STEP0_ANSWER_URL IS NOT NULL AND "
                    + "           LENGTH(MST2.STEP0_ANSWER_URL) > 0 "
                    + "       ) ) "
                    + " ORDER BY context DESC"
                    );
           db.prepareStatement(sql.toString());
           db.setString(1, siteId);
        } else {
           sql.append("SELECT  MST2.STEP0_SHOW_URL "
                    + "       ,MST2.STEP0_ANSWER_URL "
                    + " FROM " + schema + "SITE_MST MST,"
                    + "  "     + schema + "SITE_RECOG_MST MST2 "
                    + " WHERE MST.SITE_ID = MST2.SITE_ID "
                    + "   AND MST.STEP_FLAG = '1' "
                    + "   AND INVALID_FLAG  = '0' "
                    + "   AND MST.SITE_ID   = ?"
                    + "   AND MST2.SUB_NUM   = ?"
                    );
           db.prepareStatement(sql.toString());
           db.setString(1, siteId);
           db.setString(2, subNum);
        }

        Record rec = Record.getFirstRowOf(db);
        if (rec == null ) {
            throw new DBException("SITE_MST関係にデータが入っていないようです。");
        } else {
            show_url = rec.getString("STEP0_SHOW_URL");
        }

        return show_url;

    }

   /**
	*  指定された siteID, subNum で遷移先URL (step0) を探す
	*
	* @param db       DBAccess オブジェクト
	* @param request  HTTP request
	* @param siteId   サイトID
	* @param subNum   サイトサブ番号
	*
	* @auther Orig Takahashi/ Modify Miyake
	* @since 2007.11.01 subNum に対応
	*/
	public static String getStep0AnswerURI( DBAccess db , HttpServletRequest request,String  siteId, String subNum )
	  throws SQLException
	{

	    String method = request.getMethod();
	    log.info("method = " + method);
	    String ans_url   = "";
	    String schema    = db.getSchema(".");

	    StringBuffer sql = new StringBuffer();

	   // ----- subNum 指定なし
	   //  step への戻りURLが入っていて、かつ context が最長のものを採用
	   //
	    if( subNum == null || subNum.length() == 0 ){
	       sql.append("SELECT  MST2.STEP0_SHOW_URL "
	                + "       ,MST2.STEP0_ANSWER_URL "
	                + " FROM " + schema + "SITE_MST MST, "
	                +            schema + "SITE_RECOG_MST MST2 "
	                + " WHERE MST.SITE_ID = MST2.SITE_ID "
	                + "   AND MST.STEP_FLAG = '1' "
	                + "   AND INVALID_FLAG  = '0' "
	                + "   AND MST.SITE_ID   = ?"
	                + "   AND ( ( MST2.STEP0_SHOW_URL IS NOT NULL AND"
	                + "           LENGTH(MST2.STEP0_SHOW_URL) > 0 "
	                + "          ) OR "
	                + "         ( MST2.STEP0_ANSWER_URL IS NOT NULL AND "
	                + "           LENGTH(MST2.STEP0_ANSWER_URL) > 0 "
	                + "       ) ) "
	                + " ORDER BY context DESC"
	                );
	       db.prepareStatement(sql.toString());
	       db.setString(1, siteId);
	    } else {
	       sql.append("SELECT  MST2.STEP0_SHOW_URL "
	                + "       ,MST2.STEP0_ANSWER_URL "
	                + " FROM " + schema + "SITE_MST MST,"
	                + "  "     + schema + "SITE_RECOG_MST MST2 "
	                + " WHERE MST.SITE_ID = MST2.SITE_ID "
	                + "   AND MST.STEP_FLAG = '1' "
	                + "   AND INVALID_FLAG  = '0' "
	                + "   AND MST.SITE_ID   = ?"
	                + "   AND MST2.SUB_NUM   = ?"
	                );
	       db.prepareStatement(sql.toString());
	       db.setString(1, siteId);
	       db.setString(2, subNum);
	    }

	    Record rec = Record.getFirstRowOf(db);
	    if (rec == null ) {
	        throw new DBException("SITE_MST関係にデータが入っていないようです。");
	    } else {
	        ans_url  = rec.getString("STEP0_ANSWER_URL");
	    }

	    return ans_url;

	}


	/**
	 * サイトIDから、該当サイトのトップURLを取得する
	 *
	 * @param db
	 * @param siteId
	 * @return
	 * @throws SQLException
	 */
	public static String getSiteTopUrl(DBAccess db , String siteId)
			throws SQLException {

		// SITE_RECOG_MSTに該当サイトIDのデータが複数行ある場合は、SUB_NUMの昇順で一番上を持ってくる
		String sql = "SELECT  MST2.SITE_URL "
	                + " FROM SITE_MST MST, "
	                + "      SITE_RECOG_MST MST2 "
	                + " WHERE MST.SITE_ID = MST2.SITE_ID "
	                + "   AND INVALID_FLAG  = '0' "
	                + "   AND MST.SITE_ID   = ?"
	                + " ORDER BY SUB_NUM ASC";

		db.prepareStatement(sql);
		db.setString(1, siteId);

		Record rec = Record.getFirstRowOf(db);
		if (rec == null) {
			throw new DBException("SITE_RECOG_MSTにデータが見つかりませんでした。siteId = " + siteId);
		}

		return rec.getString("SITE_URL");

	}

	/**
	 * サイトIDが下記のサイトIDであるか否かを返す
	 * マイページ(200)/引越しダンドリ(300)/ウェブクルーリサーチ(400)/
	 * マイページサイト横断キャンペーン(500)/マイページFX攻略プレゼントキャンペーン(501)
	 *
	 * @param siteId
	 * @return
	 */
	public static boolean isTargetSite(String strSiteId)
	{
		if (strSiteId == null || strSiteId.equals("")) {
			log.error("引数エラー：サイトIDにnullまたは空の文字列が渡されました。");
			throw new IllegalArgumentException("引数エラー：サイトIDにnullまたは空の文字列が渡されました。");
		}

		if (strSiteId.equals(AppConstants.SITE_ID_MYPAGE)
				|| strSiteId.equals(AppConstants.SITE_ID_HKS_DANDORI)
				|| strSiteId.equals(AppConstants.SITE_ID_RESEARCH)
				|| strSiteId.equals(AppConstants.SITE_ID_CPN_SITE)
				|| strSiteId.equals(AppConstants.SITE_ID_CPN_FX))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

//	/**
//	 * ユーザのe-mailを元に、ユーザが仮登録した時のサイトIDを取得する
//	 *
//	 * @param db
//	 * @param email
//	 * @return
//	 */
//	public static String getSiteId(DBAccess db , String email) throws DBException{
//
//		email = ValueUtil.nullToStr(email);
//
//		if (email.equals("")) {
//			throw new DBException("引数エラー：emailが空です");
//		}
//
//		try {
//			// 会員情報を読み込む
//			MemberMst member = new MemberMst();
//			if (!member.load(db, email)) {
//				throw new DBException("会員情報の読み込みに失敗しました。email=" + email);
//			}
//
//			return member.get(MemberMst.SITE_ID);
//
//		} catch (Exception e) {
//
//			log.info("サイトIDの取得中に例外エラーが発生しました。");
//			throw new DBException(e);
//
//		}
//
//	}
}
