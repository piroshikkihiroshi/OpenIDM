package jp.co.webcrew.dbaccess.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;

public class DBUtil {

	/** ロガー */
    private static final Logger log = Logger.getLogger(DBUtil.class);
    
    /** パスワードハッシュのアルゴリズム*/
    public static final String PASSWD_HASH_ALGORITHM = "SHA-1";

    private DBUtil(){}
    
    /**
     * SHA-1のハッシュを返す
     * @param str 元文字列
     * @return SHA-1のダイジェスト アルゴリズムが見当たらない時は空文字を返します
     */
    public static String getDigestOf(String str) {

        StringBuffer s = new StringBuffer();
        try{
            MessageDigest md = MessageDigest.getInstance(PASSWD_HASH_ALGORITHM);
            byte[] dat = str.getBytes();
            md.update(dat);

            byte[] digest = md.digest();
            for (int i = 0; i < digest.length; i++) {
                int d = digest[i];

                if (d < 0) {  // byte 128-255
                    d += 256;
                }
                if (d < 16) { //0-15 16
                    s.append("0");
                }
                s.append(Integer.toString(d, 16));
            }
        }catch (NoSuchAlgorithmException e) {

        }
        return s.toString();
    }
    
    /** 
	 * ランダムな英数字からなる指定サイズの文字列を返す。 
	 * 
	 * @param size 文字列のサイズ 
	 * @return str 生成された文字列 
	 */ 
	public static String makeRandomPassword(int size){ 

		SecureRandom random = new SecureRandom(); 
		char[] pass = new char[size]; 
	
		for(int k = 0; k < pass.length;)
		{ 
			switch (random.nextInt(3))
			{ 
				case 0: // 'a' - 'z' 
					char cSmall = (char)(97 + random.nextInt(26));
					if (cSmall == 'l' || cSmall == 'o' || cSmall == 'q') {
						continue;
					}
					pass[k++] = cSmall; 
					break; 
				case 1: // 'A' - 'Z' 
					char cBig = (char)(65 + random.nextInt(26));
					if (cBig == 'I' || cBig == 'O') {
						continue;
					}
					pass[k++] = cBig; 
					break; 
				case 2: // '0' - '9' 
					char cDigit = (char)(48 + random.nextInt(10));
					if (cDigit == '0' || cDigit == '1' || cDigit == '9') {
						continue;
					}
					pass[k++] = cDigit; 
					break; 
				default: 
					pass[k++] = 'a'; 
			} 
		} 
		return new String(pass); 

	}

	/**
	 * GUIDを取得する
	 * @param db
	 * @return String guid 取得できなかった場合は空文字を返す
	 * @throws SQLException
	 */
	public static String createNewGuid(DBAccess db) throws SQLException{
		String sql = "SELECT SEQ_GUID.NEXTVAL AS GUID FROM DUAL";
		db.prepareStatement(sql);
		ResultSet rs = null;
		try{
			rs = db.executeQuery();
			if(rs.next()) {
				log.debug("success create new guid");
				return rs.getString("GUID");
			} else {
				log.debug("failed create new guid");
				return "";
			}
		
		} finally {
			DBAccess.close(rs);
		}
	}
}
