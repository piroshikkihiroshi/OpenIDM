package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.SearchWordReplaceFilter;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;

/**
 * <pre>
 * 
 *  条件により表示する内容を切り替えるExecuterクラス。
 *  パラメータは以下の3つ(if,then,else)必須、他のはオプション(elseif_1,elsethen_1,elseif_2,elsethen_2...)最大10個
 *    if = &quot;条件&quot;
 *    then = &quot;条件が真のときに表示する内容&quot;
 *    elseif_1 = &quot;条件が真のときに表示する内容&quot;
 *    elsethen_1 = &quot;条件が真のときに表示する内容&quot;
 *    elseif_2 = &quot;条件が真のときに表示する内容&quot;
 *    elsethen_2 = &quot;条件が真のときに表示する内容&quot;
 *    ・ ・ ・ 
 *    elseif_10 = &quot;条件が真のときに表示する内容&quot;
 *    elsethen_10 = &quot;条件が真のときに表示する内容&quot;
 *    else = &quot;条件が真のときに表示する内容&quot;
 *  
 *  条件は
 *    右辺 演算子 左辺
 *  の形式で指定する。
 *  演算子には、
 *    == != &lt; &lt;= &gt; &gt;= like notlike
 *  が指定できる。
 *  右辺左辺がともに数値の場合は、数値として比較する。
 *  そうでない場合は、文字列として比較する。
 *  
 * あいまい検索（LIKE演算子） SQLのLIKE機能と近く
 * 例：
 *   'ABC%': すべて 'ABC' を始めとする文字列。例えば、 'ABCD' と 'ABCABC' はこのパタンに合います。
 *   '%XYZ': すべて 'XYZ' で終わる文字列。例えば、 'WXYZ' と 'ZZXYZ' はこのパタンに適合します。
 *   '%AN%': すべて 'AN'を含む文字列。例えば、 'LOS ANGELES' と 'SAN FRANCISCO' はこのパタンに一致します。
 *   '%AB%YZ%': すべて 'AB'かつ'YZ'を含む文字列。例えば、 'ABCDXYZ' と 'YZEFGABC' はこのパタンに一致します。※但し、複数文字の順番は特定してない
 * 
 * </pre>
 * 
 * @author kurinami
 */
public class IfThenElseExecuter extends SSTagExecuter {

    /** ロガー */
    private static final Logger log = Logger.getLogger(IfThenElseExecuter.class);

    /** elseif判断の最大個数 ※検索キーワード数が多いため、大きい数字に設定します。 */
    private static final int ELSEIF_COUNT = 10000;

    /** like判断の文字 */
    private static final String LIKE_SIGN = "%";

    /** 半角スペースと置き換えたい文字 SearchWordReplaceFilter#doFilter()で設定しています */
    public static final String HANKAKU_SPACE = "hankaku_space";

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map mapParameters, HttpServletRequest request,
			HttpServletResponse response) {

        String strParamIf = ValueUtil.nullToStr(mapParameters.get("if"));
        String strParamThen = ValueUtil.nullToStr(mapParameters.get("then"));
        String strParamElse = ValueUtil.nullToStr(mapParameters.get("else"));
        int i = 0;
        try {

            // 対象外の検索エンジンからキーワード変数($$search_word$$)は変換されてないためELSEの値を返す
            if (strParamIf.indexOf(KeywordReplacer.PREFIX.concat(SearchWordReplaceFilter.SEARCH_WORD).concat(
                    KeywordReplacer.POSTFIX)) != -1) {
                return strParamElse;
            }

            // if条件と一致したら以下の処理は行わない
            boolean result = checkCondition(strParamIf);
            if (result) {
                return strParamThen;
            }

            // elseif条件の場合判断を追加
            String strElseIfPrefix = "elseif_";
            String strElseThenPrefix = "elsethen_";

            // elseif条件
            for (i = 1; i <= ELSEIF_COUNT; i++) {
                // 順番でelseif条件と一致したらそのelsethen値を返して、以下の処理は行わない
                if (mapParameters.containsKey(strElseIfPrefix + i) && mapParameters.containsKey(strElseThenPrefix + i)) {
                    if (checkCondition(ValueUtil.nullToStr(mapParameters.get(strElseIfPrefix + i)))) {
                        return ValueUtil.nullToStr(mapParameters.get(strElseThenPrefix + i));
                    }
                } else {
                    break; // 番号連続しないとそれ以下の条件は無視します
                }
            }

        } catch (Exception objExp) {
            String strErrMsg = "strParamIf:" + strParamIf;
            if (i > 0) {
                strErrMsg = strErrMsg + " index:" + i;
            }
            log.error("予期せぬエラー " + strErrMsg, objExp);
        }

        // デフォルトelse値を返す
        return strParamElse;

    }

    /**
     * 条件チェック
     * 
     * @param strParamCondition
     * @return true|false
     */
    protected boolean checkCondition(String strParamCondition) {

        boolean result = false;
        String[] strCondition = strParamCondition.split("[ \t]+", 3);

        String strLeftExpression = strCondition[0].toLowerCase();
        String strOperator = strCondition[1];
        String strRightExpression = strCondition[2].toLowerCase();

        try {
            // 上記conditionは半角スペースで区切っているため、leftExpressionが半角スペースがある場合先にHANKAKU_SPACEを変換して、ここで戻します。
            if (strLeftExpression.indexOf(HANKAKU_SPACE) != -1) {
                strLeftExpression = strLeftExpression.replaceAll(HANKAKU_SPACE, " ");
            }
            double leftNumber = Double.parseDouble(strLeftExpression);
            double rightNumber = Double.parseDouble(strRightExpression);

            if (strOperator.equals("==")) {
                result = leftNumber == rightNumber;
            } else if (strOperator.equals("!=")) {
                result = leftNumber != rightNumber;
            } else if (strOperator.equals("<")) {
                result = leftNumber < rightNumber;
            } else if (strOperator.equals("<=")) {
                result = leftNumber <= rightNumber;
            } else if (strOperator.equals(">")) {
                result = leftNumber > rightNumber;
            } else if (strOperator.equals(">=")) {
                result = leftNumber >= rightNumber;
            } else if (strOperator.equalsIgnoreCase("like")) {
                result = leftNumber == rightNumber;
            } else if (strOperator.equalsIgnoreCase("notlike")) {
                result = leftNumber != rightNumber;
            } else {
//                log.error("不正な演算子[" + strOperator + "]が指定されました。");
//                return result;
            	throw new RuntimeException("不正な演算子[" + strOperator + "]が指定されました。");
            }

        } catch (NumberFormatException e) {

            if (strOperator.equals("==")) {
                result = strLeftExpression.equals(strRightExpression);
            } else if (strOperator.equals("!=")) {
                result = !strLeftExpression.equals(strRightExpression);
            } else if (strOperator.equals("<")) {
                result = strLeftExpression.compareTo(strRightExpression) < 0;
            } else if (strOperator.equals("<=")) {
                result = strLeftExpression.compareTo(strRightExpression) <= 0;
            } else if (strOperator.equals(">")) {
                result = strLeftExpression.compareTo(strRightExpression) > 0;
            } else if (strOperator.equals(">=")) {
                result = strLeftExpression.compareTo(strRightExpression) >= 0;
            } else if (strOperator.equalsIgnoreCase("like")) { // あいまい検索（LIKE演算子） SQLと近く
                result = isLikes(strLeftExpression, strRightExpression);
            } else if (strOperator.equalsIgnoreCase("notlike")) {
                result = !isLikes(strLeftExpression, strRightExpression);
            } else {
//              log.error("不正な演算子[" + strOperator + "]が指定されました。");
//              return result;
            	throw new RuntimeException("不正な演算子[" + strOperator + "]が指定されました。");
            }
        }

        return result;
    }

    /**
     * <pre>
     * あいまい検索（LIKE演算子） SQLのLIKE機能と近く
     * 例：
     * 'ABC%': すべて 'ABC' を始めとする文字列。例えば、 'ABCD' と 'ABCABC' はこのパタンに合います。
     * '%XYZ': すべて 'XYZ' で終わる文字列。例えば、 'WXYZ' と 'ZZXYZ' はこのパタンに適合します。
     * '%AN%': すべて 'AN'を含む文字列。例えば、 'LOS ANGELES' と 'SAN FRANCISCO' はこのパタンに一致します。
     * '%AB%YZ%': すべて 'AB'かつ'YZ'を含む文字列。例えば、 'ABCDXYZ' と 'YZEFGABC' はこのパタンに一致します。※但し、二つ文字の順番は特定してない
     * 
     * </pre>
     * 
     * @param strLeft
     * @param strRight
     * @return true|false
     */
    private boolean isLikes(String strLeft, String strRight) {

        // 複数キーワードの可能性
        boolean hasMultiWord = false;
        for (int i = 0; i < strRight.length(); i++) {
            if (i != 0 && i != strRight.length() - 1 && LIKE_SIGN.equals(String.valueOf(strRight.charAt(i)))) {
                hasMultiWord = true;
                break;
            }
        }

        if (hasMultiWord) {
            String[] rightArr = strRight.split(LIKE_SIGN);
            List rightRawList = new ArrayList();
            for (int i = 0; i < rightArr.length; i++) {
                if (rightArr[i].trim().length() == 0) {
                    continue;
                }
                rightRawList.add(rightArr[i].trim()); // 先頭と最後の空白は省略されます
            }
            List rightList = new ArrayList();
            for (int i = 0; i < rightRawList.size(); i++) {
                if (i == 0) {
                    if (strRight.startsWith(LIKE_SIGN)) {
                        rightList.add(LIKE_SIGN + rightRawList.get(i) + LIKE_SIGN);
                    } else {
                        rightList.add(rightRawList.get(i) + LIKE_SIGN);
                    }
                } else if (i == rightRawList.size() - 1) {
                    if (strRight.endsWith(LIKE_SIGN)) {
                        rightList.add(LIKE_SIGN + rightRawList.get(i) + LIKE_SIGN);
                    } else {
                        rightList.add(LIKE_SIGN + rightRawList.get(i));
                    }
                } else {
                    rightList.add(LIKE_SIGN + rightRawList.get(i) + LIKE_SIGN);
                }
            }

            for (int i = 0; i < rightList.size(); i++) {
                if (isLike(strLeft, (String) rightList.get(i))) {
                    continue;
                } else {
                    return false;
                }
            }
            return true;
        } else {
            return isLike(strLeft, strRight);
        }

    }

    /**
     * 単一キーワードの比較
     * 
     * @param strLeftExpression
     * @param strRightExpression
     * @return true|false
     */
    private boolean isLike(String strLeftExpression, String strRightExpression) {
        boolean ret = false;
        if (strRightExpression.startsWith(LIKE_SIGN) || strRightExpression.endsWith(LIKE_SIGN)) {
            if (strRightExpression.startsWith(LIKE_SIGN) && strRightExpression.endsWith(LIKE_SIGN)) {
                if (strLeftExpression.indexOf(strRightExpression.replaceAll(LIKE_SIGN, "")) != -1) {
                    ret = true; // 部分一致
                }
            } else if (strRightExpression.startsWith(LIKE_SIGN)) {
                if (strLeftExpression.endsWith(strRightExpression.replaceAll(LIKE_SIGN, ""))) {
                    ret = true; // 後方一致
                }
            } else if (strRightExpression.endsWith(LIKE_SIGN)) {
                if (strLeftExpression.startsWith(strRightExpression.replaceAll(LIKE_SIGN, ""))) {
                    ret = true; // 前方一致
                }
            }
        } else {
            ret = strLeftExpression.equals(strRightExpression); // 完全一致
        }

        return ret;
    }

}
