/*
 * Generator Runtime Servlet Framework
 * Copyright (C) 2004 Rick Knowles
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package jp.co.webcrew.common.validation;

import generator.runtime.db.DBConnectionWrapper;
import generator.runtime.utils.StringUtils;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public abstract class ValidationCheck implements Serializable {
	
	private String fieldName;
    private String errorType;
    private Map configParameters = new Hashtable();
	
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
    
	protected String getFieldName() {
		return this.fieldName;
	}
    
    protected String getConfigParameter(String key) {
        return (String) this.configParameters.get(key);
    }
    
    protected void setConfigParameter(String key, String value) {
        this.configParameters.put(key, value);
    }
	
    protected String getErrorType() {
        String param = getConfigParameter("errorType");
        if (param != null) {
            return param;
        } else {
            String className = getClass().getName();
            String thisPackageName = ValidationCheck.class.getPackage().getName() + ".";
            if (className.startsWith(thisPackageName)) {
                className = className.substring(thisPackageName.length());
            }
            if (className.endsWith("Validation")) {
                className = className.substring(0, className.length() - "Validation".length());
            }
            return StringUtils.makeLowerMixedCase(className);
        }
    }
    
    public abstract ValidationFailure validate(Object value, DBConnectionWrapper 
            dbConnection);
    
    public void init(Map configParameters) {
        if (configParameters != null) {
            this.configParameters.putAll(configParameters);
        }
    }
    
    /**
     * By default extracts the attributes, and adds them to the map
     */
    public void init(Node node) {
        if (configParameters != null) {
            NamedNodeMap nnm = node.getAttributes();
            for (int n = 0; n < nnm.getLength(); n++) {
                Node att = nnm.item(n);
                setConfigParameter(att.getNodeName(), att.getNodeValue());
            }
        }
    }
}
