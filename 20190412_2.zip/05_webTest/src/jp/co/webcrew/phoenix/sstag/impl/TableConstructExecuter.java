package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * 表出力を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class TableConstructExecuter extends SSTagExecuter {

    /** パラメータ名：tableタグを含むヘッディング部分に出力する HTML文字列 */
    private static final String HEADER_PARAM_KEY = "header";

    /** パラメータ名：/table タグを含むフッタ部分に出力する HTML文字列 */
    private static final String FOOTER_PARAM_KEY = "footer";

    /** パラメータ名：行タイトルの行数 */
    private static final String ROW_T_CONUT_PARAM_KEY = "row_t_count";

    /** パラメータ名：列タイトルの列数 */
    private static final String COL_T_CONUT_PARAM_KEY = "col_t_count";

    /** パラメータ名：列の幅 */
    private static final String COL_WIDTH_PARAM_KEY = "col_width";

    /** パラメータ名：表内に入る実データを CSV形式で指定 */
    private static final String CSV_DATA_PARAM_KEY = "csv_data";

    /** パラメータ名：表内に入る実データを TSV形式で指定 */
    private static final String TSV_DATA_PARAM_KEY = "tsv_data";

    /** パラメータ名：行部分のTRに指定するクラス名を指定*/
    private static final String ROW_CLASS_NAME_PARAMETER_KEY = "row_class_name"; 
    
    
    /** 行部分のTRに指定するクラス名のデフォルト値 */
    private static final String DEFAULT_ROW_CLASS_NAME = "itemRow";
    
    /** ロガー */
    private static final Logger log = Logger.getLogger(TableConstructExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    @SuppressWarnings("unchecked")
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String header = SstagUtil.getFileData((String) parameters.get(HEADER_PARAM_KEY), request, response);
            String footer = SstagUtil.getFileData((String) parameters.get(FOOTER_PARAM_KEY), request, response);
            int rowTCount = ValueUtil.toint((String) parameters.get(ROW_T_CONUT_PARAM_KEY));
            int colTCount = ValueUtil.toint((String) parameters.get(COL_T_CONUT_PARAM_KEY));
            String rowClassName = (String)parameters.get(ROW_CLASS_NAME_PARAMETER_KEY);
            String[] colWidth = PhoenixUtil.split((String) parameters.get(COL_WIDTH_PARAM_KEY), ",");
            String[][] csvData = toTableData((String) parameters.get(CSV_DATA_PARAM_KEY), ',');
            String[][] tsvData = toTableData((String) parameters.get(TSV_DATA_PARAM_KEY), '\t');

            String[][] tableData = !PhoenixUtil.isEmpty(csvData) ? csvData : tsvData;

            // htmlを組み立てる。
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);

            pw.println(header);
            construct(pw, tableData, rowTCount, colTCount, rowClassName, colWidth);
            pw.println(footer);

            pw.flush();
            return sw.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * テーブルデータを配列にばらす。
     * 
     * @param source
     * @param sep
     * @return
     */
    private static String[][] toTableData(String source, char sep) {

        if (PhoenixUtil.isEmpty(source)) {
            return new String[][] {};
        }

        List<String[]> tableData = new ArrayList<String[]>();
        List<String> rowData = new ArrayList<String>();
        StringBuffer sb = new StringBuffer();
        boolean quoteFlag = false;

        for (int i = 0; i < source.length(); i++) {
            char ch = source.charAt(i);

            if (ch == '"') {
                if (quoteFlag) {
                    if (i + 1 < source.length() && source.charAt(i + 1) == '"') {
                        sb.append('"');
                        i++;
                    } else {
                        quoteFlag = false;
                    }
                } else {
                    if (sb.length() == 0) {
                        quoteFlag = true;
                    } else {
                        sb.append('"');
                    }
                }
            } else if (ch == sep && !quoteFlag) {
                rowData.add(sb.toString().trim());
                sb = new StringBuffer();
            } else if (ch == '\n' && !quoteFlag) {
                rowData.add(sb.toString().trim());
                sb = new StringBuffer();
                tableData.add(rowData.toArray(new String[0]));
                rowData.clear();
            } else if (ch == ' ' && !quoteFlag && sb.length() == 0) {

            } else {
                sb.append(ch);
            }

        }

        if (sb.length() > 0 || rowData.size() > 0) {
            rowData.add(sb.toString().trim());
            tableData.add(rowData.toArray(new String[0]));
        }

        return tableData.toArray(new String[][] {});

    }

    /**
     * テーブル表示部分を組み立てる。
     * 
     * @param pw
     * @param data
     * @param rowTCount
     * @param colTCount
     * @param colWidth
     */
    private void construct(PrintWriter pw, String[][] data, int rowTCount, int colTCount, String rowClassName, String[] colWidth) {

        if (ValueUtil.nullToStr(rowClassName).equals("")) {
            rowClassName = DEFAULT_ROW_CLASS_NAME;
        }
        for (int i = 0; i < data.length; i++) {
            //行部分にはCSSクラス名を指定する。
            if (i < rowTCount) {
                pw.println("  <tr class=\"" + rowClassName + "\">");
            } else {
                pw.println("  <tr>");
            }
            
            for (int j = 0; j < data[i].length; j++) {
                String tag = i < rowTCount || j < colTCount ? "th" : "td";

                pw.print("    <");
                pw.print(tag);
                if (colWidth.length > j && !PhoenixUtil.isEmpty(colWidth[j])) {
                    pw.print(" width=\"");
                    pw.print(colWidth[j]);
                    pw.print("\"");
                }
                pw.print(">");
                pw.print(data[i][j]);
                pw.print("</");
                pw.print(tag);
                pw.print(">");
                pw.println();
            }
            pw.println("  </tr>");
        }

    }

    public static void main(String[] args) {
        String source = "" + "\"タイトル1-1\",\"タイトル1-2\",\"タイトル1-3\",\"タイトル1-4\",\"タイトル1-5\"\n"
                + "                      \"タイトル2-1\",\"タイトル2-2\",\"タイトル2-3\",\"タイトル2-4\",\"タイトル2-5\"\n"
                + "                      タイトル3-1,データ3-2,データ3-3,データ3-4,データ3-5\n"
                + "                      タイトル4-1,データ4-2,データ4-3,データ4-4,データ4-5\n"
                + "                      タイトル5-1,データ5-2,データ5-3,データ5-4,データ5-5";
        String[][] data = toTableData(source, ',');
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                System.out.print("[");
                System.out.print(data[i][j]);
                System.out.print("]");
            }
            System.out.println();
        }

    }

}
