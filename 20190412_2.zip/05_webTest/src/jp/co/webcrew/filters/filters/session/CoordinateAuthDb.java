package jp.co.webcrew.filters.filters.session;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * 認証連携用テーブルを管理するdbクラス。
 * 
 * @author kurinami
 */
public class CoordinateAuthDb {

	/** 認証連携情報挿入用SQL */
	private static final String COORDINATE_AUTH_INSERT = "insert into coordinate_auth(ls_code, site_id, return_url, mk_datetime) values(?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'))";
	
	private static final String COORDINATE_AUTH_DELETE = "delete from coordinate_auth where ls_code = ?";

	/**
	 * 認証連携情報を新規挿入する。
	 * 
	 * @param lsCode
	 * @param siteId
	 * @param returnUrl
	 * @throws SQLException
	 */
	public static void insert(String lsCode, int siteId, String returnUrl)
			throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// 同じコードのものが残ってしまった時用に削除をしておく。
			dbAccess.prepareStatement(COORDINATE_AUTH_DELETE);
			dbAccess.setString(1, lsCode);
			dbAccess.executeUpdate();

			// 連携データを挿入する。
			dbAccess.prepareStatement(COORDINATE_AUTH_INSERT);
			dbAccess.setString(1, lsCode);
			dbAccess.setInt(2, siteId);
			dbAccess.setString(3, returnUrl);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

}
