package jp.co.webcrew.logic.lib._02_work;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.BindLogicStdStatus;
import jp.co.webcrew.phoenix.logic.ItemConvLogicStatus;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;

public class Kadai_3_2_LogicDeleteDebug extends SstagDynamicLogic {

	Logger logger = Logger.getLogger(Kadai_3_2_LogicDeleteDebug.class);

	public static void main(String[] args) {
		String strDriver = "oracle.jdbc.OracleDriver";
		String strUrli = "jdbc:oracle:thin:@10.81.50.164:1521:cairo";
		String strUser = "tatsuya.ueda";
		String strPassword = "gomainu55";

		ResultSet objRs = null;
		int intMax = 0;

		//sql作成
		String strSql = "";
		strSql +=" UPDATE \"TATSUYA.UEDA\".ORDER_INFO  ";
		strSql +=" SET ";
		strSql +="   DELETE_FLG = ?  ";
		strSql +=" WHERE ";
		strSql +="   ORDER_ID = ? ";

		try {
			Class.forName(strDriver);
			Connection objCon = DriverManager.getConnection(strUrli,
					strUser, strPassword);

			objCon.setAutoCommit(false); //一応明示的にオートコミット切る
			PreparedStatement objPs = null;

				objPs = objCon.prepareStatement(strSql);
				objPs.setInt(1, 1); //delflg
				objPs.setInt(2, 1); //where

				int intCnt = objPs.executeUpdate();
				objCon.commit();
//				logger.info("commit success");
		} catch (SQLException e) {
//			logger.error("SQL Error", e);
//			objDbAccess.rollback();
			e.printStackTrace();
		} catch (Exception e) {
//			logger.error("Unexpect Error", e);
			e.printStackTrace();
		} //try Exception
	} // main


	@Override
	public BindLogicStdStatus stdLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam, List<String> userParam,
			FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo) {
		String strDriver = "oracle.jdbc.OracleDriver";
		String strUrli = "jdbc:oracle:thin:@10.81.50.164:1521:cairo";
		String strUser = "tatsuya.ueda";
		String strPassword = "gomainu55";

		//sql作成
		String strSql = "";
		strSql += "INSERT ";
		strSql += "INTO \"TATSUYA.UEDA\".ORDER_INFO(";
		strSql += "  ORDER_ID";
		strSql += "  , NAME_KANJI_1";
		strSql += "  , NAME_KANJI_2";
		strSql += "  , NAME_KANA_1";
		strSql += "  , NAME_KANA_2";
		strSql += "  , EMAIL";
		strSql += "  , TEL";
		strSql += "  , CONTACT ";
		strSql += "  , DELETE_FLG ";
		strSql += ") ";
		strSql += "VALUES ( ";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?,";
		strSql += "  ?";
		strSql += ")";

		try {
			Class.forName(strDriver);
			Connection objCon = DriverManager.getConnection(strUrli,
					strUser, strPassword);

			objCon.setAutoCommit(false); //一応明示的にオートコミット切る
			PreparedStatement objPs = null;

			try {
				objPs = objCon.prepareStatement(strSql);
				objPs.setInt(1, 6);
				objPs.setString(2, "value2");
				objPs.setString(3, "value3");
				objPs.setString(4, "value4");
				objPs.setString(5, "value5");
				objPs.setString(6, "value6");
				objPs.setString(7, "value7");
				objPs.setInt(8, 1);
				objPs.setInt(9, 0);

				int intCnt = objPs.executeUpdate();
				objCon.commit();
				logger.info("commit success");
			} catch (SQLException e) {
				logger.error("SQLException Error", e);
				objCon.rollback(); //ロールバック処理
				throw e;
			} finally {
				//クローズ処理
				if (objPs != null)
					objPs.close();
				if (objCon != null)
					objCon.close();

			} //try SQLException
		} catch (Exception e) {
			logger.error("Unexpect Error", e);
			e.printStackTrace();
		} //try Exception


		//statusは必須
		BindLogicExtStatus objStatus = new BindLogicExtStatus();

		return objStatus;

	} // stdLogic

	@Override
	public BindLogicExtStatus validationLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public JudgementLogicStatus judgementLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public ItemConvLogicStatus itemConvLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String sub1,
			String sub2, String result) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
