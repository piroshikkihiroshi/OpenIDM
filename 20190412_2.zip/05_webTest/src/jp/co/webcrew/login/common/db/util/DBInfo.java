package jp.co.webcrew.login.common.db.util;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;

public final class DBInfo {

    /** ロガー */
    private static Logger log = Logger.getLogger(DBInfo.class);
    /** 認証用データベース */
    private static Map _authdb = new HashMap();
    /**
     *  データベースを取得する
     */
    public static Map getDb() {
        // TODO privateに戻す
        return _authdb;
    }
    
    /**
     * 
     * @param key
     * @param obj
     */
    public static void set (String key , Object obj) {
        getDb().put(key, obj);
    }

    /**
     * 
     * @param key
     * @param obj
     */
    private static void setTableInfo (String key , TableInfo info) {
        info.readColumnInfoFromDB();
        getDb().put(key, info);
    }

    public static void registTableInfo (TableInfo info) {
        setTableInfo(info.getFullTableName(), info);
    }

    
    /**
     * 
     * @param key
     * @return
     */
    public static Object get (String key) {
        return getDb().get(key);
    }

    /**
     * 
     * @param tableName
     * @return
     */
    public static TableInfo getTableInfo (String tableName) {
        TableInfo info = (TableInfo)getDb().get(tableName);
        
        if (info != null) {
            return (TableInfo)getDb().get(tableName);
        }
        
        synchronized (DBInfo.class) {
            log.info("テーブル定義情報が見つからないため、データベースから読み込みます。");
            if ((TableInfo)getDb().get(tableName) != null) {
                return (TableInfo)getDb().get(tableName);
            }
            // nullだった場合は、登録する
            String schema = null;
            String table = null;
            if (tableName.indexOf(".") < 0) {
                schema = "";
                table = tableName;
            } else {
                String[] tableArr = tableName.split("\\.");
                schema = tableArr[0];
                table = tableArr[1];
            }
            
            registerDbInfo (schema , table);
        }
        
        return (TableInfo)getDb().get(tableName);
    }

    /**
     * テーブル名から列情報を自動的に読み取ってDBInfoに登録する
     * schemaが指定されていない（nullもしくは空文字）の時は、接続ユーザ名を元にデータベースを検索し、
     * スキーマ無しのテーブル名でDBINFOに登録する
     * @param schema
     * @param tableName
     */
    public static void registerDbInfo (String schema , String tableName) {
        
        String dbCatalog = "%"; // Oracleの場合、指定する必要無し
        
        //テーブル名から列情報を自動的に読み取ってDBInfoに登録する
        TableInfo info = new TableInfo(schema , tableName);
        DBAccess db = null;
        try{
            db = new DBAccess();
            DatabaseMetaData metaData = db.getDatabaseMetaData();
            String targetSchema = schema;
            if (targetSchema == null || targetSchema.equals("")) {
                targetSchema = metaData.getUserName();
            }
            
            List PKList = new ArrayList();
            // テーブルの主キーを求める
            ResultSet pkRs = metaData.getPrimaryKeys(dbCatalog , targetSchema , tableName);
            while(pkRs.next()){ 
                String tblName = pkRs.getString("TABLE_NAME");
                String colName = pkRs.getString("COLUMN_NAME");
                log.info("PKey = " + tblName + "." + colName );
                PKList.add( colName );
//              PKList.add(pkRs.getString("COLUMN_NAME"));
            }
            
            // テーブルの列名を取得し、テーブル情報オブジェクトを生成する
            ResultSet tableInfoRs = metaData.getColumns(dbCatalog , targetSchema , tableName,"%");
            
            int columnInfoCnt = 0;
            while(tableInfoRs.next()){
                columnInfoCnt++;
                String colName = tableInfoRs.getString("COLUMN_NAME");
                // PKかどうかを判断する
                if (Collections.binarySearch(PKList , colName) >= 0 ) {
                    // PKである
                    info.addPK(colName);
                    
                } else {
                    // PKではない
                    info.addColumn(colName);
                }

            }
            
            if (columnInfoCnt >= 0) {
                // データベース情報にテーブル情報を登録
                DBInfo.registTableInfo(info);

            } else {
                // 実質エラー
                log.warn("該当テーブルが見つかりませんでした。");
                log.info("requested schema = " + schema);
                log.info("requested table = " + tableName);
                log.info("targeted catalog = " + dbCatalog);
                log.info("targeted schema = " + targetSchema);
            }
            
        } catch (Exception e) {
            log.error("テーブル情報の登録中に例外エラーが発生しました。" , e);
        } finally {
            DBAccess.close(db);
        }
        
        
    }   
    
    
    /**
     * 
     * @param schema
     * @param table
     * @return
     */
    public static String getFullTableName(String schema,String table){
        if (schema == null || schema.equals("")) {
            return table;
        } else {
            return schema + "." + table;
        }
    }
    
    /**
     * 
     * @param tableName
     * @return
     */
    public static List getPkColumns(String tableName){
        TableInfo ti = getTableInfo(tableName);
        if (ti == null) {
            log.info("テーブル情報がDBInfoに存在しませんでした。" + tableName);
            return new ArrayList();
        }
        
        return ti.getPkColumns();
        
    }
    
    /**
     * 
     * @param tableName
     * @return
     */
    public static List getColumns(String tableName){
        TableInfo ti = getTableInfo(tableName);
        if (ti == null) {
            log.info("テーブル情報がDBInfoに存在しませんでした。" + tableName);
            return new ArrayList();
        }
        
        return ti.getColumns();
        
    }
    
}
