package jp.co.webcrew.common.util;

import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * @author user
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class WcString {
    private final static char[] zenkaku = {
            'ａ', 'ｂ', 'ｃ', 'ｄ', 'ｅ', 'ｆ', 'ｇ', 'ｈ', 'ｉ', 'ｊ', 'ｋ', 'ｌ', 'ｍ', 'ｎ',
            'ｏ', 'ｐ', 'ｑ', 'ｒ', 'ｓ', 'ｔ', 'ｕ', 'ｖ', 'ｗ', 'ｘ', 'ｙ', 'ｚ', 'Ａ', 'Ｂ',
            'Ｃ', 'Ｄ', 'Ｅ', 'Ｆ', 'Ｇ', 'Ｈ', 'Ｉ', 'Ｊ', 'Ｋ', 'Ｌ', 'Ｍ', 'Ｎ', 'Ｏ', 'Ｐ',
            'Ｑ', 'Ｒ', 'Ｓ', 'Ｔ', 'Ｕ', 'Ｖ', 'Ｗ', 'Ｘ', 'Ｙ', 'Ｚ', '０', '１', '２', '３',
            '４', '５', '６', '７', '８', '９', '＠', '．', '＿', '－', '　', '（', '）'
        };
    private final static char[] hankaku = {
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
            'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B',
            'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
            'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3',
            '4', '5', '6', '7', '8', '9', '@', '.', '_', '-', ' ', '(', ')'
        };
    public static String[] JP_CHAR_TABLE = {
            "｡。##", "｢「##", "｣」##", "･・##", "ｦヲ##", "ｧァ##", "ｨィ##", "ｩゥ##",
            "ｪェ##", "ｫォ##", "ｬャ##", "ｭュ##", "ｮョ##", "ｯッ##", "ｰー##", "ｱア##",
            "ｲイ##", "ｳウ##", "ｴエ##", "ｵオ##", "ｶカガ#", "ｷキギ#", "ｸクグ#", "ｹケゲ#",
            "ｺコゴ#", "ｻサザ#", "ｼシジ#", "ｽスズ#", "ｾセゼ#", "ｿソゾ#", "ﾀタダ#", "ﾁチヂ#",
            "ﾂツヅ#", "ﾃテデ#", "ﾄトド#", "ﾅナ##", "ﾆニ##", "ﾇヌ##", "ﾈネ##", "ﾉノ##",
            "ﾊハバパ", "ﾋヒビピ", "ﾌフブプ", "ﾍヘベペ", "ﾎホボポ", "ﾏマ##", "ﾐミ##", "ﾑム##",
            "ﾒメ##", "ﾓモ##", "ﾔヤ##", "ﾕユ##", "ﾖヨ##", "ﾗラ##", "ﾘリ##", "ﾙル##",
            "ﾚレ##", "ﾛロ##", "ﾜワ##", "ﾝン##", "ﾞ゛##", "ﾟ゜##"
        };

    public WcString() {
    }

    public static String toH(String str) {
        StringBuffer ret = new StringBuffer();
        boolean flg = false;

        for (int i = 0; i < str.length(); i++) {
            for (int j = 0; j < hankaku.length; j++) {
                if ((str.charAt(i) == zenkaku[j]) ||
                        (str.charAt(i) == hankaku[j])) {
                    ret.append(hankaku[j]);
                    flg = true;

                    break;
                }
            }

            if (!flg) {
                ret.append(str.charAt(i));
            }

            flg = false;
        }

        return new String(ret);
    }

    public static String toZ(String str) {
        StringBuffer ret = new StringBuffer();
        boolean flg = false;

        for (int i = 0; i < str.length(); i++) {
            for (int j = 0; j < zenkaku.length; j++) {
                if ((str.charAt(i) == hankaku[j]) ||
                        (str.charAt(i) == zenkaku[j])) {
                    ret.append(zenkaku[j]);
                    flg = true;

                    break;
                }
            }

            if (!flg) {
                ret.append(str.charAt(i));
            }

            flg = false;
        }

        return new String(ret);
    }

    public static String toZKana(String str) {
        StringBuffer ret = new StringBuffer();
        int prevBase = 0;

        for (int i = 0; i < str.length(); i++) {
            //int base = -1;
            char code = str.charAt(i);

            if ((code == 'ﾞ') && (JP_CHAR_TABLE[prevBase].charAt(2) != '#')) {
                /* 濁点を受理し、1つ前の文字が濁点付与可能な文字の場合 */
                /* 1文字削除 */
                ret.deleteCharAt(ret.length() - 1);

                /* 濁点文字追加 */
                ret.append(JP_CHAR_TABLE[prevBase].charAt(2));

                prevBase = 0;

                continue;
            } else if ((code == 'ﾟ') &&
                    (JP_CHAR_TABLE[prevBase].charAt(2) != '#')) {
                /* 半濁点を受理し、1つ前の文字が濁点付与可能な文字の場合 */
                /* 1文字削除 */
                ret.deleteCharAt(ret.length() - 1);

                /* 半濁点文字追加 */
                ret.append(JP_CHAR_TABLE[prevBase].charAt(3));

                prevBase = 0;

                continue;
            }

            boolean flag = false;

            for (int j = 0; j < JP_CHAR_TABLE.length; j++) {
                /* テ－ブルを走査 */
                if (code == JP_CHAR_TABLE[j].charAt(0)) {
                    /* 文字が見つかれば追加 */
                    flag = true;
                    ret.append(JP_CHAR_TABLE[j].charAt(1));
                    prevBase = j;

                    break;
                }
            }

            if (!flag) {
                ret.append(code);
                prevBase = 0;
            }
        }

        return ret.toString();
    }

    public static String toKatakana(String str) {
        String ret = "";

        for (int i = 0; i < str.length(); i++) {
            char code = str.charAt(i);

            if ((code >= 0x3041) && (code <= 0x3093)) {
                /* 平仮名のときカタカナに変換  */
                ret = ret + (char) (code + 0x60);
                ;
            } else {
                /* 平仮名以外は、そのまま  */
                ret = ret + code;
            }
        }

        return ret;
    }

    public static String convertMS932(String s) {
        if (s != null) {
            char[] chr;

            chr = s.toCharArray();

            for (int i = 0; i < chr.length; ++i) {
                switch (chr[i]) {
                // 「－」
                case 0xFF0D:
                    chr[i] = 0x2212;

                    break;

                // 「～」
                case 0xFF5E:
                    chr[i] = 0x301C;

                    break;

                // 「∥」
                case 0x2225:
                    chr[i] = 0x2016;

                    break;

                // 「￠」
                case 0xFFE0:
                    chr[i] = 0x00A2;

                    break;

                // 「￡」
                case 0xFFE1:
                    chr[i] = 0x00A3;

                    break;

                // 「￢」
                case 0xFFE2:
                    chr[i] = 0x00AC;

                    break;

                // 「￥」
                case 0xFF3C:
                    chr[i] = 0x005C;

                    break;

                // 「―」
                case 0x2015:
                    chr[i] = 0x2014;

                    break;

                default:
                    break;
                }
            }

            return new String(chr);
        } else {
            return null;
        }
    }

    public static String convertSJIS(String s) {
        if (s != null) {
            char[] chr;

            chr = s.toCharArray();

            for (int i = 0; i < chr.length; ++i) {
                switch (chr[i]) {
                // 「－」
                case 0x2212:
                    chr[i] = 0xFF0D;

                    break;

                // 「～」
                case 0x301C:
                    chr[i] = 0xFF5E;

                    break;

                // 「∥」
                case 0x2016:
                    chr[i] = 0x2225;

                    break;

                // 「￠」
                case 0x00A2:
                    chr[i] = 0xFFE0;

                    break;

                // 「￡」
                case 0x00A3:
                    chr[i] = 0xFFE1;

                    break;

                // 「￢」
                case 0x00AC:
                    chr[i] = 0xFFE2;

                    break;

                // 「￥」
                case 0x005C:
                    chr[i] = 0xFF3C;

                    break;

                // 「―」
                case 0x2014:
                    chr[i] = 0x2015;

                    break;

                default:
                    break;
                }
            }

            return new String(chr);
        } else {
            return null;
        }
    }

    public static String Latin2SJIS(String str) {
        try {
            str = new String(str.getBytes("ISO-8859-1"), "JISAutoDetect");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return str;
    }

    public static String replace(String str, Hashtable replace_data) {
        try {
            int while_limit = 0;

            while (str.indexOf("%%") > -1) {
                while_limit++;

                if (while_limit > 1000) {
                    break;
                }

                Pattern pattern = Pattern.compile("%%");
                String[] strs = pattern.split(str);

                pattern = Pattern.compile("%%" + strs[1] + "%%");

                Matcher matcher = pattern.matcher(str);

                String replace_string = new String();

                if (replace_data.containsKey(strs[1])) {
                    replace_string = (String) replace_data.get(strs[1]);
                }

                str = matcher.replaceFirst(replace_string);
            }

            return str;
        } catch (Exception e) {
            return null;
        }
    }

    public static String replace(String str, String oldstr, String newstr) {
        String ret = null;

        try {
            Pattern pattern = Pattern.compile(oldstr);
            Matcher matcher = pattern.matcher(str);

            ret = matcher.replaceAll(newstr);
        } catch (Exception e) {
            return null;
        }

        return ret;
    }

    public static String removeChar(String str, String delim) {
        String ret = null;

        try {
            StringTokenizer st = new StringTokenizer(str);
            String value = "";

            while (st.hasMoreTokens()) {
                value += st.nextToken(delim);
            }

            ret = value;
        } catch (Exception e) {
            return null;
        }

        return ret;
    }

    public static Vector devideString(String str, String delim) {
        Vector ret = new Vector();

        try {
            StringTokenizer st = new StringTokenizer(str);

            while (st.hasMoreTokens()) {
                ret.add(st.nextToken(delim));
            }
        } catch (Exception e) {
            return null;
        }

        return ret;
    }
}
