package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.bean.voice.VoiceBean;
import jp.co.webcrew.filters.db.voice.HikkoshiVoiceMstDb;
import jp.co.webcrew.filters.db.voice.SateiomakaseVoiceMstDb;
import jp.co.webcrew.filters.util.VoiceNewHtmlUtil;

public class VoiceListNewExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(VoiceListNewExecuter.class);

	private static final String HIKKOSHI_SITE_ID		= "3054";
	private static final String SATEIOMAKASE_SITE_ID	= "4165";
	/**
	 * Returns the HTML contents based on the value of the Contents Id read from
	 * the parameter
	 * 
	 */
	public String execute(Map parameters, HttpServletRequest request,
			HttpServletResponse response) 
	{
		// Get Site Id, Company Id and Display Count from the parameter
		String strSiteId 	= ValueUtil.nullToStr(parameters.get("siteid"));
		if ("".equals(strSiteId)) {
			return "";
		}
		
		String strCompanyId 	= ValueUtil.nullToStr(parameters.get("companyid"));
		if ("".equals(strCompanyId)) {
			return "";
		}
		
		int nCompanyId  = 0;
		try 
		{
			nCompanyId = Integer.parseInt(strCompanyId);
			strCompanyId = String.valueOf(nCompanyId);
		}
		catch (NumberFormatException objNFexp) {
			// Do nothing, defaut is 5
		}
		
		int nDispCount	= 5;
		String strDispCount 	= ValueUtil.nullToStr(parameters.get("dispcount"));
		try {
			nDispCount = Integer.parseInt(strDispCount);
			
		}
		catch (NumberFormatException objNFexp) {
			// Do nothing, defaut is 5
		}
		
		try 
		{
			int nCount = 0;
			List lstData = new ArrayList();
			
			if (HIKKOSHI_SITE_ID.equals(strSiteId)) {
				lstData = HikkoshiVoiceMstDb.getInstance().getVoiceBeanListByDate();
			}
			else if (SATEIOMAKASE_SITE_ID.equals(strSiteId)) {
				lstData = SateiomakaseVoiceMstDb.getInstance().getVoiceBeanListByDate();
			}
			
log.info("************************************ strSiteId : " + strSiteId);	
log.info("************************************ strCompanyId : " + strCompanyId);
log.info("************************************ Voice Size : " + (lstData==null ? "NULL" : lstData.size()));

			List<VoiceBean> lstDispList = new ArrayList<VoiceBean>();
            VoiceBean objVoiceBean = null;
            for (int nCnt=0; nCnt<lstData.size(); nCnt++)
            {
                objVoiceBean = (VoiceBean) lstData.get(nCnt);
                log.info("************************************ objVoiceBean.getCompanyIdMtm() : " + objVoiceBean.getCompanyIdMtm());                
                if (strCompanyId.equals(objVoiceBean.getCompanyIdMtm())) {
                	lstDispList.add(objVoiceBean);
                	
                	log.info("************************************ Inside!");  
                	// Take total of 6, to judge whether to display　「すべての口コミを見る」 link
                	if (++nCount == nDispCount+1) {
                		break;
                	}
                }
            }
 
            log.info("************************************ lstDispList.size() : " + lstDispList.size());
            
			if (HIKKOSHI_SITE_ID.equals(strSiteId)) {
				return VoiceNewHtmlUtil.getHikkoshiHtml(strCompanyId, nDispCount, lstDispList);
			}
			else if (SATEIOMAKASE_SITE_ID.equals(strSiteId)) {
				return VoiceNewHtmlUtil.getSateiomakaseHtml(strCompanyId, nDispCount, lstDispList);
			}
		}
		catch (Exception objExp) {
			log.error("予期せぬエラー", objExp);
		}
		return "";
	}
}
