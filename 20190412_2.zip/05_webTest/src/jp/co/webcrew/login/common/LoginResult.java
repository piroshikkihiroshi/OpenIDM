package jp.co.webcrew.login.common;

public class LoginResult {
	
	/** ログイン成功を意味する定数 */
	public static final int LOGIN_SUCCESS             = 0;

	/** GSIDが不正であることを意味する定数 */
	public static final int LOGIN_GSID_ERROR          = 1;

	/** データベース接続に失敗したことを意味する定数 */
	public static final int LOGIN_DB_CONNECTION_ERROR = 2;

	/** ログインIDが不正であることを意味する定数 */
	public static final int LOGIN_ID_ERROR            = 3;

	/** ログインemailが不正(大抵の場合 null)であることを意味する定数 */
	public static final int LOGIN_EMAIL_ERROR         = 4;

	/** パスワードが不正(大抵の場合 null)であることを意味する定数 */
	public static final int LOGIN_PASSWD_ERROR        = 5;

	/** ログイン認証に失敗したことを意味する定数 */
	public static final int LOGIN_AUTH_ERROR          = 6;

	/** データベースエラーが発生したことを意味する定数 */
	public static final int LOGIN_DB_ERROR            = 7;
	
	/** guidの取得に失敗、もしくは取得したgiudが不正であることを意味する定数 */
	public static final int LOGIN_GUID_ERROR          = 8;

	/** 例外発生等、他のエラーが発生したことを意味する定数 */
	public static final int LOGIN_OTHER_ERROR         = 9;

	/** ステータスコード */
	public int status = -1 ;

	/** ログイン後に確定したGUID */
	public String loginGuid = "";

	/**
	 * ログイン処理の結果
	 * 
	 * 成功したらtrue 失敗したらfalseを返す
	 * 
	 * @return
	 */
	public boolean isSuccess() {

		if (status == LOGIN_SUCCESS) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * ログイン失敗の理由
	 * @return String エラー理由
	 */
	public String getErrorReason() {
		switch (status) {
			case(LOGIN_SUCCESS):
				return ""; // エラー無し

			case(LOGIN_AUTH_ERROR):
				return "認証に失敗しました。";

			case(LOGIN_DB_CONNECTION_ERROR):
				return "データベース接続に失敗したか、接続が失われました。";

			case(LOGIN_DB_ERROR):
				return "データベースエラーが発生しました。";

			case(LOGIN_GSID_ERROR):
				return "不正なgsidが渡されました。";

			case(LOGIN_ID_ERROR):
				return "不正なログインID(E-mail)が渡されました。";

			case(LOGIN_OTHER_ERROR):
				return "想定外の例外エラーが発生しました。";

			default:
				return "原因不明です。";
		}
		
		
	}
	


}
