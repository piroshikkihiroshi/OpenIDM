package jp.co.webcrew.common.db;

import generator.runtime.db.DBConnectionWrapper;
import generator.runtime.db.DBConnectionWrapperSource;
import generator.runtime.exception.ApplicationException;
import generator.runtime.log.Log;
import generator.runtime.servlet.ErrorNotificationMailProperties;
import generator.runtime.utils.ApplicationProperties;
import generator.runtime.utils.ContextFlushable;
import generator.runtime.utils.ParamUtils;

import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.sql.DataSource;

/**
 * Adds a connection pooling datasource to the local webapp
 * context. Uses DBCP by default, but could be reconfigured to
 * use other pooling libraries that implement javax.sql.DataSource
 * 
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: DBCPDBConnectionWrapperSource.java,v 1.3 2007-04-09 10:37:11 rickk Exp $
 */
public class DBCPDBConnectionWrapperSource implements DBConnectionWrapperSource, ContextFlushable {
    private static final Log log = new Log(DBCPDBConnectionWrapperSource.class);
        
    private final static String DEFAULT_POOLING_PROPS = "dbConnectionPool";
    private final static String DEFAULT_POOLING_IMPL = "org.apache.commons.dbcp.BasicDataSourceFactory";
    private final static String DEFAULT_CONSTRUCTOR_METHOD =  "createDataSource";
    private final static String DEFAULT_SHUTDOWN_METHOD = "close";

    private DataSource ds;
    private String poolingPropertiesFile;
    private String poolingImplClassName;
    private String poolingImplMethodName;
    private String poolingImplCloseName; 
    
    private String propertiesFilter;
    private String poolId;
    private String contextName;
    
    private Log readLogStream;
    private Log writeLogStream;
    
    private ErrorNotificationMailProperties errorMailProperties;
    
    public DBCPDBConnectionWrapperSource(String propertiesFilter, String poolId) {
        this.propertiesFilter = propertiesFilter;
        this.poolId = poolId;
    }
    
    public DBConnectionWrapper createConnectionWrapper() {
        return new DBCPDBConnectionWrapper(this, this.ds, this.readLogStream, this.writeLogStream);
    }

    public String getContextName() {
        return ParamUtils.nvl(this.contextName, "DBCPDBConnectionWrapperSource:" + this.poolId);
    }

    public void initialize(ApplicationProperties resources) {
        synchronized (this) {
            this.poolingPropertiesFile = resources.stringProperty(
                    this.propertiesFilter + "@properties", DEFAULT_POOLING_PROPS);
            this.poolingImplClassName = resources.stringProperty(
                    this.propertiesFilter + "impl/@class", DEFAULT_POOLING_IMPL);
            this.poolingImplMethodName = resources.stringProperty(
                    this.propertiesFilter + "impl/@constructor", DEFAULT_CONSTRUCTOR_METHOD);
            this.poolingImplCloseName = resources.stringProperty(
                    this.propertiesFilter + "impl/@shutdown", DEFAULT_SHUTDOWN_METHOD);
            
            // Log streams
            String readLogStream = resources.stringProperty(
                    this.propertiesFilter + "@readLogStream", "");
            String writeLogStream = resources.stringProperty(
                    this.propertiesFilter + "@writeLogStream", "");
            if (!readLogStream.equals("")) {
                this.readLogStream = new Log(readLogStream);
            }
            if (writeLogStream.equals(readLogStream)) {
                this.writeLogStream = this.readLogStream;
            } else if (!writeLogStream.equals("")) {
                this.writeLogStream = new Log(writeLogStream);
            }
            
            this.ds = createPool(poolingPropertiesFile, poolingImplClassName, 
                    poolingImplMethodName, poolingImplCloseName);

            this.errorMailProperties = new ErrorNotificationMailProperties(resources);
        }
    }

    public void destroy() {
        synchronized (this) {
            closePool(this.ds, this.poolingImplCloseName);
            this.ds = null;
            this.poolingPropertiesFile = null;
            this.poolingImplClassName = null;
            this.poolingImplMethodName = null;
            this.poolingImplCloseName = null;
            this.readLogStream = null;
            this.writeLogStream = null;
            this.errorMailProperties = null;
        }
    }

    public ErrorNotificationMailProperties getErrorMailProperties() {
        return this.errorMailProperties;
    }    
    
    /**
     * Creates a jdbc datasource object and adds it to the context
     */
    protected static DataSource createPool(String poolingPropertiesFile, String poolingImplClassName, 
            String poolingImplMethodName, String poolingImplCloseName) {
            
        // Load the pooling instance ourselves
        try {
            log.debug("Creating connection pool from local properties - " + 
                    poolingPropertiesFile);
            ResourceBundle poolResources = ResourceBundle.getBundle(poolingPropertiesFile);
            Properties props = new Properties();
            for (Enumeration iter = poolResources.getKeys(); iter.hasMoreElements(); ) {
                String key = (String) iter.nextElement();
                log.fullDebug("Adding db property: " + key + "=" + poolResources.getString(key));
                props.put(key, poolResources.getString(key));
            }
            
            // Get pooling instance 
            Class implClass = Class.forName(poolingImplClassName);
            Method createMeth = implClass.getDeclaredMethod(
                    poolingImplMethodName, new Class[] {Properties.class});
            DataSource ds = (DataSource) createMeth.invoke(null, 
                    new Object[] {props});
            return ds;
        } catch (Throwable err) {
            log.error( "Error initialising the jdbc connection pool", err);
            throw new ApplicationException("Error initialising the jdbc connection pool", err);
        }
    }
    
    protected static void closePool(DataSource ds, String poolingImplCloseName) {
        if (ds == null) {
            log.debug("Connection pool not found in context");
            return;
        }
        try {
            // Attempt shutdown
            Method methClose = ds.getClass().getMethod(poolingImplCloseName, new Class[0]);
            if (methClose != null) {
                log.debug("Closing connection pool found in context");
                methClose.invoke(ds, new Object[0]);
            } else {
                log.debug("WARNING: No close method found for connection pool");
            }
        } catch (Throwable err) {
            log.error( "Error shutting down the jdbc connection pool", err);
            throw new ApplicationException("Error shutting down the jdbc connection pool", err);
        }
    }
}
