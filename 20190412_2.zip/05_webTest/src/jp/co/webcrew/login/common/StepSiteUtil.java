/**
 * 
 */
package jp.co.webcrew.login.common;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.State3;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.db.step.StepUserInfo;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.StringUtil;

/**
 * <pre>
 * </pre>
 * @author Takahashi
 *
 */
public class StepSiteUtil {

    /** ロガー */
    private static final Logger log = Logger.getLogger(StepSiteUtil.class);

    /**
     * <pre>
     * StepのUSER_INFO等の情報を取得して（となしばの）会員情報に反映する場合、
     * あまりにStep側のデータが古い場合はそのデータは使用しないように、利用制限時間を
     * 設けている。（SystemProperty.PAST_DATA_COPY_LIMIT）
     * 
     * そのコピー制限時間を超過していたら TRUE, そうでなければFALSEを返す。
     * 
     * 処理中にエラーが発生した場合や、判断できない場合は N/A を返す。
     * 
     * </pre>
     * @param db
     * @param stepuser Step側のユーザ情報(USER_INFO,ORDER_INFO等）
     * @return
     */
    public static State3 isOverCopyLimit(DBAccess db , StepUserInfo stepuser) {
        
        if (db == null) {
            return State3.NA();
        }
        
        if (stepuser == null) {
            return State3.NA();
        }
        
        try {
            SystemProperties props = new SystemProperties(db);

            String limit = ValueUtil.nullToStr(props.get(SystemProperties.PAST_DATA_COPY_LIMIT));
            if (limit.equals("")) {
                log.warn("システムプロパティにPAST_DATA_COPY_LIMITがセットされていません。");
                return State3.NA();
            }
            
            // 符号を逆にする
            String offset;
            if (limit.startsWith("-")) {
                offset = limit.substring(1);
            } else {
                offset = "-" + limit;
            }
            
            long registerd   = StringUtil.forceLong(stepuser.getLastUpdate() + "000000");
            long copyTimeOut = StringUtil.forceLong(DateUtil.getDateTime(offset));

            if (copyTimeOut > registerd) {
                return State3.TRUE();
            } else {
                return State3.FALSE();
            }
            
        } catch (SQLException e) {
            log.error("データベース処理中に例外エラーが発生しました。" , e);
            return State3.NA();
        }

    }
}
