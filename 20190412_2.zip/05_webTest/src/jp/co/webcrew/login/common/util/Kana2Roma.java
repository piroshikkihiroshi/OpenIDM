package jp.co.webcrew.login.common.util;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class Kana2Roma {

    private final static Map m = new HashMap() {
        /**
         * serialVersionUID
         */
        private static final long serialVersionUID = 1L;

        {
            put("ア", "A");
            put("イ", "I");
            put("ウ", "U");
            put("エ", "E");
            put("オ", "O");
            put("カ", "KA");
            put("キ", "KI");
            put("ク", "KU");
            put("ケ", "KE");
            put("コ", "KO");
            put("サ", "SA");
            put("シ", "SHI");
            put("ス", "SU");
            put("セ", "SE");
            put("ソ", "SO");
            put("タ", "TA");
            put("チ", "CHI");
            put("ツ", "TU");
            put("テ", "TE");
            put("ト", "TO");
            put("ナ", "NA");
            put("ニ", "NI");
            put("ヌ", "NU");
            put("ネ", "NE");
            put("ノ", "NO");
            put("ハ", "HA");
            put("ヒ", "HI");
            put("フ", "FU");
            put("ヘ", "HE");
            put("ホ", "HO");
            put("マ", "MA");
            put("ミ", "MI");
            put("ム", "MU");
            put("メ", "ME");
            put("モ", "MO");
            put("ヤ", "YA");
            put("ユ", "YU");
            put("ヨ", "YO");
            put("ラ", "RA");
            put("リ", "RI");
            put("ル", "RU");
            put("レ", "RE");
            put("ロ", "RO");
            put("ワ", "WA");
            put("ヲ", "WO");
            put("ン", "N");
            put("ガ", "GA");
            put("ギ", "GI");
            put("グ", "GU");
            put("ゲ", "GE");
            put("ゴ", "GO");
            put("ザ", "ZA");
            put("ジ", "ZI");
            put("ズ", "ZU");
            put("ゼ", "ZE");
            put("ゾ", "ZO");
            put("ダ", "DA");
            put("ヂ", "DI");
            put("ヅ", "DU");
            put("デ", "DE");
            put("ド", "DO");
            put("バ", "BA");
            put("ビ", "BI");
            put("ブ", "BU");
            put("ベ", "BE");
            put("ボ", "BO");
            put("パ", "PA");
            put("ピ", "PI");
            put("プ", "PU");
            put("ペ", "PE");
            put("ポ", "PO");
            put("キャ", "KYA");
            put("キュ", "KYU");
            put("キョ", "KYO");
            put("シャ", "SYA");
            put("シュ", "SYU");
            put("ショ", "SYO");
            put("チャ", "TYA");
            put("チュ", "TYU");
            put("チョ", "TYO");
            put("ニャ", "NYA");
            put("ニュ", "NYU");
            put("ニョ", "NYO");
            put("ヒャ", "HYA");
            put("ヒュ", "HYU");
            put("ヒョ", "HYO");
            put("リャ", "RYA");
            put("リュ", "RYU");
            put("リョ", "RYO");
            put("ギャ", "GYA");
            put("ギュ", "GYU");
            put("ギョ", "GYO");
            put("ジャ", "ZYA");
            put("ジュ", "ZYU");
            put("ジョ", "ZYO");
            put("ヂャ", "DYA");
            put("ヂュ", "DYU");
            put("ヂョ", "DYO");
            put("ビャ", "BYA");
            put("ビュ", "BYU");
            put("ビョ", "BYO");
            put("ピャ", "PYA");
            put("ピュ", "PYU");
            put("ピョ", "PYO");
            put("ー", "-");
        }
    };

    public static String kana2roma(String s) {
        StringBuffer t = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            if (i <= s.length() - 2) {
                if (m.containsKey(s.substring(i, i + 2))) {
                    t.append(m.get(s.substring(i, i + 2)));
                    i++;
                } else if (m.containsKey(s.substring(i, i + 1))) {
                    t.append(m.get(s.substring(i, i + 1)));
                } else if (s.charAt(i) == 'ッ') {
                    t.append(((String) m.get(s.substring(i + 1, i + 2))).charAt(0));
                } else {
                    t.append(s.charAt(i));
                }
            } else {
                if (m.containsKey(s.substring(i, i + 1))) {
                    t.append(m.get(s.substring(i, i + 1)));
                } else {
                    t.append(s.charAt(i));
                }
            }
        }
        return t.toString();
    }

    private static final char[] HANKAKU_KATAKANA = { '｡', '｢', '｣', '､', '･', 'ｦ', 'ｧ', 'ｨ', 'ｩ', 'ｪ', 'ｫ', 'ｬ', 'ｭ',
            'ｮ', 'ｯ', 'ｰ', 'ｱ', 'ｲ', 'ｳ', 'ｴ', 'ｵ', 'ｶ', 'ｷ', 'ｸ', 'ｹ', 'ｺ', 'ｻ', 'ｼ', 'ｽ', 'ｾ', 'ｿ', 'ﾀ', 'ﾁ', 'ﾂ',
            'ﾃ', 'ﾄ', 'ﾅ', 'ﾆ', 'ﾇ', 'ﾈ', 'ﾉ', 'ﾊ', 'ﾋ', 'ﾌ', 'ﾍ', 'ﾎ', 'ﾏ', 'ﾐ', 'ﾑ', 'ﾒ', 'ﾓ', 'ﾔ', 'ﾕ', 'ﾖ', 'ﾗ',
            'ﾘ', 'ﾙ', 'ﾚ', 'ﾛ', 'ﾜ', 'ﾝ', 'ﾞ', 'ﾟ' };

    private static final char[] ZENKAKU_KATAKANA = { '。', '「', '」', '、', '・', 'ヲ', 'ァ', 'ィ', 'ゥ', 'ェ', 'ォ', 'ャ', 'ュ',
            'ョ', 'ッ', 'ー', 'ア', 'イ', 'ウ', 'エ', 'オ', 'カ', 'キ', 'ク', 'ケ', 'コ', 'サ', 'シ', 'ス', 'セ', 'ソ', 'タ', 'チ', 'ツ',
            'テ', 'ト', 'ナ', 'ニ', 'ヌ', 'ネ', 'ノ', 'ハ', 'ヒ', 'フ', 'ヘ', 'ホ', 'マ', 'ミ', 'ム', 'メ', 'モ', 'ヤ', 'ユ', 'ヨ', 'ラ',
            'リ', 'ル', 'レ', 'ロ', 'ワ', 'ン', '゛', '゜' };

    private static final char HANKAKU_KATAKANA_FIRST_CHAR = HANKAKU_KATAKANA[0];

    private static final char HANKAKU_KATAKANA_LAST_CHAR = HANKAKU_KATAKANA[HANKAKU_KATAKANA.length - 1];

    /**
     * 半角カタカナから全角カタカナへ変換します。
     * 
     * @param c
     *            変換前の文字
     * @return 変換後の文字
     */
    public static char hanKanaToZenKana(char c) {
        if (c >= HANKAKU_KATAKANA_FIRST_CHAR && c <= HANKAKU_KATAKANA_LAST_CHAR) {
            return ZENKAKU_KATAKANA[c - HANKAKU_KATAKANA_FIRST_CHAR];
        } else {
            return c;
        }
    }

    /**
     * 2文字目が濁点・半濁点で、1文字目に加えることができる場合は、合成した文字を返します。 合成ができないときは、c1を返します。
     * 
     * @param c1
     *            変換前の1文字目
     * @param c2
     *            変換前の2文字目
     * @return 変換後の文字
     */
    public static char mergeChar(char c1, char c2) {
        if (c2 == 'ﾞ') {
            if ("ｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾊﾋﾌﾍﾎ".indexOf(c1) > 0) {
                switch (c1) {
                case 'ｶ':
                    return 'ガ';
                case 'ｷ':
                    return 'ギ';
                case 'ｸ':
                    return 'グ';
                case 'ｹ':
                    return 'ゲ';
                case 'ｺ':
                    return 'ゴ';
                case 'ｻ':
                    return 'ザ';
                case 'ｼ':
                    return 'ジ';
                case 'ｽ':
                    return 'ズ';
                case 'ｾ':
                    return 'ゼ';
                case 'ｿ':
                    return 'ゾ';
                case 'ﾀ':
                    return 'ダ';
                case 'ﾁ':
                    return 'ヂ';
                case 'ﾂ':
                    return 'ヅ';
                case 'ﾃ':
                    return 'デ';
                case 'ﾄ':
                    return 'ド';
                case 'ﾊ':
                    return 'バ';
                case 'ﾋ':
                    return 'ビ';
                case 'ﾌ':
                    return 'ブ';
                case 'ﾍ':
                    return 'ベ';
                case 'ﾎ':
                    return 'ボ';
                }
            }
        } else if (c2 == 'ﾟ') {
            if ("ﾊﾋﾌﾍﾎ".indexOf(c1) > 0) {
                switch (c1) {
                case 'ﾊ':
                    return 'パ';
                case 'ﾋ':
                    return 'ピ';
                case 'ﾌ':
                    return 'プ';
                case 'ﾍ':
                    return 'ペ';
                case 'ﾎ':
                    return 'ポ';
                }
            }
        }
        return c1;
    }

    /**
     * 文字列中の半角カタカナを全角カタカナに変換します。
     * 
     * @param s
     *            変換前文字列
     * @return 変換後文字列
     */
    public static String hanKanaToZenKana(String s) {
        if (s.length() == 0) {
            return s;
        } else if (s.length() == 1) {
            return hanKanaToZenKana(s.charAt(0)) + "";
        } else {
            StringBuffer sb = new StringBuffer(s);
            int i = 0;
            for (i = 0; i < sb.length() - 1; i++) {
                char originalChar1 = sb.charAt(i);
                char originalChar2 = sb.charAt(i + 1);
                char margedChar = mergeChar(originalChar1, originalChar2);
                if (margedChar != originalChar1) {
                    sb.setCharAt(i, margedChar);
                    sb.deleteCharAt(i + 1);
                } else {
                    char convertedChar = hanKanaToZenKana(originalChar1);
                    if (convertedChar != originalChar1) {
                        sb.setCharAt(i, convertedChar);
                    }
                }
            }
            if (i < sb.length()) {
                char originalChar1 = sb.charAt(i);
                char convertedChar = hanKanaToZenKana(originalChar1);
                if (convertedChar != originalChar1) {
                    sb.setCharAt(i, convertedChar);
                }
            }
            return sb.toString();
        }

    }

    public static String getKana(String src) {
        if (src == null || src.length() == 0)
            return "";
        if (Pattern.compile("^([ア-オ]|[ヴ])").matcher(src).find())
            return "ア";
        if (Pattern.compile("^([カ-コ]|[ガ-ゴ])").matcher(src).find())
            return "カ";
        if (Pattern.compile("^([サ-ソ]|[ザ-ゾ])").matcher(src).find())
            return "サ";
        if (Pattern.compile("^([タ-ト]|[ダ-ド])").matcher(src).find())
            return "タ";
        if (Pattern.compile("^([ナ-ノ])").matcher(src).find())
            return "ナ";
        if (Pattern.compile("^([ハ-ホ]|[バ-ボ]|[パ-ポ])").matcher(src).find())
            return "ハ";
        if (Pattern.compile("^([マ-モ])").matcher(src).find())
            return "マ";
        if (Pattern.compile("^([ヤ-ヨ])").matcher(src).find())
            return "ヤ";
        if (Pattern.compile("^([ラ-ロ])").matcher(src).find())
            return "ラ";
        if (Pattern.compile("^([ワ-ヲ])").matcher(src).find())
            return "ワ";
        return "";
    }

}
