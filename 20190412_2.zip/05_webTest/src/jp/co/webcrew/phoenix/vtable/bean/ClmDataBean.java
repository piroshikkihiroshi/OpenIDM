package jp.co.webcrew.phoenix.vtable.bean;

import java.io.Serializable;

import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.db.VDb;

/**
 * カラムデータを保持するbeanクラス。
 * 
 * @author kurinami
 */
public class ClmDataBean implements Serializable {

    /** デフォルトシリアルバージョン */
    private static final long serialVersionUID = 1L;

    /** レコードID */
    private long recId = 0l;

    /** データ */
    private String data = "";

    /** カラムメタ情報 */
    private ClmMetaMstBean meta = null;

    /**
     * データの先頭512バイトを返す。
     * 
     * @return
     */
    public String getKeyData() {
        return PhoenixUtil.getLeft(data, VDb.KEY_DATA_LENGTH);
    }

    // 以下、アクセッサ。

    public long getRecId() {
        return recId;
    }

    public void setRecId(long recId) {
        this.recId = recId;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public ClmMetaMstBean getMeta() {
        return meta;
    }

    public void setMeta(ClmMetaMstBean meta) {
        this.meta = meta;
    }

}
