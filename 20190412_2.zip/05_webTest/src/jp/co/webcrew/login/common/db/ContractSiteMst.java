package jp.co.webcrew.login.common.db;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.util.DateUtil;

/**
 * 成約サイトマスタ関連のDBクラス
 * 
 * @author Fu
 * 
 */
public class ContractSiteMst extends DBEntity {

    /** ロガー */
    private static final Logger log = Logger.getLogger(ContractSiteMst.class);

    /** テーブル名 */
    public static final String TABLE = "CONTRACT_SITE_MST";

    /** フラグ有効 */
    public static final String FLG_INVALID_ON = "1";
    /** フラグ無効 */
    public static final String FLG_INVALID_OFF = "0";

    /** アンケート回答済み */
    public static final String FLG_ANSWER_ON = "1";
    /** アンケート回答済みではない */
    public static final String FLG_ANSWER_OFF = "0";

    /** 追加INパラメータ */
    private List<String> inOptionParams = new ArrayList<String>();

    public List<String> getInOptionParams() {
        return inOptionParams;
    }

    /**
     * INパラメータを追加する。
     * 
     * @param inOptionParam
     */
    public boolean addInParam(String inOptionParam) {
        return inOptionParams.add(inOptionParam);
    }

    /**
     * INパラメータをクリアする。
     * 
     * @param inOptionParam
     */
    public void clearInOptionParams() {
        this.inOptionParams.clear();
    }

    /*
     * 列名定義
     */
    /** ステップサイトID */
    public static final String SITE_ID = "SITE_ID";
    /** 成約ポイント対応済みステップサイトID */
    public static final String CONTRACT_SITE_ID = "CONTRACT_SITE_ID";
    public static final String CONTRACT_SITE_NAME = "CONTRACT_SITE_NAME";
    public static final String POINT_CALC_SQL = "POINT_CALC_SQL";
    public static final String JIGO_SQL = "JIGO_SQL";
    public static final String CONTRACT_SQL = "CONTRACT_SQL";
    public static final String LIMIT_SQL = "LIMIT_SQL";
    public static final String ENQURL_SQL = "ENQURL_SQL";
    public static final String BADUSER_SQL = "BADUSER_SQL";
    public static final String INVALID_FLAG = "INVALID_FLAG";
    public static final String ANSWER_SQL = "ANSWER_SQL";
    public static final String APPLY_SQL = "APPLY_SQL";
    public static final String NO_HIST_SQL = "NO_HIST_SQL";
    public static final String BGN_DATETIME = "BGN_DATETIME";
    public static final String UP_DATETIME = "UP_DATETIME";
    public static final String UP_ADMIN = "UP_ADMIN";

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
     */
    public void init() {
        setTable(TABLE);
    }

    public ContractSiteMst() {
        super();
    }

    /**
     * ステップサイトIDより取得する
     * 
     * @param db
     * @param siteId
     * @return
     * @throws SQLException
     */
    public boolean load(DBAccess db, String siteId) throws SQLException {
        set(SITE_ID, siteId);
        SiteMst siteMst = new SiteMst(get(SITE_ID));
        if (siteMst.load(db)) {
            return loadByContractSiteId(db, siteMst.get(SiteMst.CONTRACT_SITE_ID));
        }
        return false;
    }

    /**
     * ステップサイトIDと成約サイトIDより取得する
     * 
     * @param db
     * @param contractSiteId
     *            成約サイトマスタにのサイトID
     * @return
     * @throws SQLException
     */
    public boolean loadByContractSiteId(DBAccess db, String contractSiteId) throws SQLException {
        String siteId = getSiteId();
        setContractSiteId(contractSiteId);
        if (super.load(db)) {
            // 無効の場合設定しない
            if (isInvalid()) {
                setRecord(null);
                return false;
            }
            // 再設定が必要,load()でリセットされたため
            set(SITE_ID, siteId);
            return true;
        }
        return false;
    }

    public void setContractSiteId(String val) {
        set(CONTRACT_SITE_ID, val);
    }

    /**
     * 成約サイトマスタにのサイトID
     * 
     * @return
     */
    public final String getContractSiteId() {
        return get(CONTRACT_SITE_ID);
    }

    /**
     * ステップサイトID
     * 
     * @return
     */
    public final String getSiteId() {
        return get(SITE_ID);
    }

    /**
     * <pre>
     * 該当サイトは成約対応済みテーブルCONTRACT_SITE_MSTに存在かつ有効するか否かを返す
     * false サイト有効する true サイト有効ではないまたは存在しない
     * </pre>
     * 
     * @return
     * @throws SQLException
     */
    public boolean isInvalid() {
        String invalidFlag = get(INVALID_FLAG);
        if (FLG_INVALID_ON.equals(invalidFlag)) {
            return true;
        }

        // 開始日時設定がないと、無効となります。
        String bgnDatetime = ValueUtil.nullToStr(get(BGN_DATETIME));
        if (bgnDatetime.length() == 0) {
            return true;
        }

        Timestamp bgn_timestamp = DateUtil.toTimestamp(bgnDatetime);
        // 現在日付時刻を取得(YYYYMMDDHHMISS形式)
        Timestamp current_timestamp = DateUtil.toTimestamp(DateUtil.currentDateTime());
        // 現在は対応中か
        if (bgn_timestamp.after(current_timestamp)) {
            return true;
        }
        return false;

    }

    /**
     * <pre>
     * 悪質ユーザーかどうかをチェックする
     * true:悪質ユーザー 
     * false:悪質ユーザーではない　対応してないサイトはfalseです。
     * </pre>
     * 
     * @param db
     * @param orderId
     *            依頼者番号
     * @return true:悪質ユーザー false:悪質ユーザーではない　対応してないサイトはfalseです。
     * @throws SQLException
     */
    public boolean isBadUser(DBAccess db, String orderId) throws SQLException {

        // ファンクション名取得
        String funcName = get(BADUSER_SQL);
        String ret = execFunc(db, funcName, orderId);

        // 0:false 1:true
        if (OrderHist.FLG_BAD_USER_ON.equals(ret)) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * <pre>
     * 成約アンケートURLを取得する
     * アクセス端末よりURLは違います
     * </pre>
     * 
     * @param db
     * @param orderId
     *            依頼者番号
     * @param terminalType
     *            端末タイプ、現時点対応した端末、PC：0、モバイル：1 ※今後スマットフォンも追加かもしれません
     * @return 成約アンケートURL
     * @throws SQLException
     */
    public String getEnqUrl(DBAccess db, String orderId, String terminalType) throws SQLException {

        // ファンクション名取得
        String funcName = get(ENQURL_SQL);

        // モバイルフラグパラメータを追加する
        this.inOptionParams.add(terminalType);
        String ret = execFunc(db, funcName, orderId);
        // 入力パラメータをクリアする
        this.inOptionParams.clear();
        return ret;

    }

    /**
     * <pre>
     * 成約ポイントパターン番号を取得する
     * </pre>
     * 
     * @param db
     * @param orderId
     *            依頼者番号
     * @param fromType
     *            呼び出し元、現時点で対応した管理画面の場合、2／その他の場合、1
     * @param comIds
     *            成約会社ID、複数の場合「:」区切
     * @param comNames
     *            成約会社名、複数の場合「:」区切
     * @return 成約パターン番号
     * @throws SQLException
     */
    public String getPointPatternId(DBAccess db, String orderId, String fromType, String contractCompanyID,
            String contractCompanyName) throws SQLException {

        // ファンクション名取得
        String funcName = get(POINT_CALC_SQL);

        this.inOptionParams.add(fromType);
        this.inOptionParams.add(contractCompanyID);
        this.inOptionParams.add(contractCompanyName);

        String ret = execFunc(db, funcName, orderId);
        this.inOptionParams.clear();

        // 成約パターン番号
        return ret;

    }

    /**
     * <pre>
     * 制限日数を取得する
     * </pre>
     * 
     * @param db
     * @param orderId
     *            依頼者番号
     * @return 制限日数
     * @throws SQLException
     */
    public int getLimitDays(DBAccess db, String orderId) throws SQLException {

        // ファンクション名取得
        String funcName = get(LIMIT_SQL);
        String ret = execFunc(db, funcName, orderId);
        // 制限日数
        return ValueUtil.toint(ret);

    }

    /**
     * <pre>
     * アンケート回答済みかどうかをチェックする
     * true:回答済み 
     * false:回答済みではない
     * </pre>
     * 
     * @param db
     * @param orderId
     *            依頼者番号
     * @return
     * @throws SQLException
     */
    public boolean isEnqAnswered(DBAccess db, String orderId) throws SQLException {

        // ファンクション名取得
        String funcName = get(ANSWER_SQL);
        String ret = execFunc(db, funcName, orderId);

        // 1:true 0:false
        if (FLG_ANSWER_ON.equals(ret)) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * <pre>
     * 申請ページへの誘導ステータスを取得する
     * </pre>
     * 
     * @param db
     * @param orderId
     *            依頼者番号
     * @return 1:申請ページへの誘導を表示する 0:申請ページへの誘導を表示しない
     * @throws SQLException
     */
    public String getDisplayFlagForNoHist(DBAccess db, String orderId) throws SQLException {

        // ファンクション名取得
        String funcName = get(NO_HIST_SQL);
        String ret = execFunc(db, funcName, orderId);
        // 誘導ステータス
        return ret;

    }

    /**
     * <pre>
     * ファンクションを実行する
     * </pre>
     * 
     * @param db
     * @param funcName
     *            ファンクション名
     * @param orderId
     *            依頼者番号
     * @return 実行結果
     * @throws SQLException
     */
    private String execFunc(DBAccess db, String funcName, String orderId) throws SQLException {

        String outParam = "";
        ResultSet rs = null;

        try {
            if (funcName == null || funcName.length() == 0 || isInvalid()) {
                return outParam;
            }
            StringBuffer selectFuncSql = new StringBuffer("SELECT ");
            selectFuncSql.append(funcName);
            selectFuncSql.append("(?, ?");
            // 追加INパラメータを設定
            for (int i = 0; i < inOptionParams.size(); i++) {
                selectFuncSql.append(", ?");
            }

            selectFuncSql.append(") FROM DUAL");
            // prepareStatementを作成
            db.prepareStatement(selectFuncSql.toString());

            // INパラメータを設定
            db.setLong(1, ValueUtil.tolong(getSiteId()));
            db.setLong(2, ValueUtil.tolong(orderId));
            // 追加INパラメータを設定
            for (int i = 0; i < inOptionParams.size(); i++) {
                db.setString(3 + i, inOptionParams.get(i));
            }
            // 実行
            rs = db.executeQuery();

            if (db.next(rs)) {
                outParam = ValueUtil.nullToStr(rs.getString(1));
            }
            return outParam;

        } finally {
            DBAccess.close(rs);
        }

    }

    /**
     * <pre>
     * プロシージャで成約会社情報を取得する
     * 
     * 実行結果配列(varchar2):
     * [0]:1:成約 0:未成約
     * [1]:成約会社ID
     * [2]:成約会社名
     * [3]:予備1
     * [4]:予備2
     * [5]:予備3
     * [6]:予備4
     * [7]:予備5
     * </pre>
     * 
     * @param db
     * @param orderId
     *            依頼者番号
     * @return
     * @throws SQLException
     */
    public String[] getContractInfo(DBAccess db, String orderId) throws SQLException {

        CallableStatement cstmt = null;
        try {
            String procName = get(CONTRACT_SQL);
            if (procName == null || procName.length() == 0 || isInvalid()) {
                return null;
            }
            StringBuffer selectProcSql = new StringBuffer("{CALL ");
            selectProcSql.append(procName);
            selectProcSql.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?");
            int inCount = inOptionParams.size();
            // 追加INパラメータを設定
            for (int i = 0; i < inCount; i++) {
                selectProcSql.append(", ?");
            }
            selectProcSql.append(")}");

            // CallableStatementを作成
            cstmt = db.prepareCall(selectProcSql.toString());

            // INパラメータを設定
            cstmt.setLong(1, ValueUtil.tolong(getSiteId()));
            cstmt.setLong(2, ValueUtil.tolong(orderId));
            // 追加INパラメータを設定
            for (int i = 0; i < inCount; i++) {
                cstmt.setString(3 + i, inOptionParams.get(i));
            }

            // OUTパラメータを設定
            cstmt.registerOutParameter(3 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(4 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(5 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(6 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(7 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(8 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(9 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(10 + inCount, java.sql.Types.VARCHAR);

            // CALL文の実行
            int cnt = cstmt.executeUpdate();

            // OUTパラメータの取得(registerOutParameterで登録した位置のパラメータ)
            String[] outParams = {
                    ValueUtil.nullToStr(cstmt.getString(3 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(4 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(5 + inCount)),
                    // 以下は予備OUTパラメータ
                    ValueUtil.nullToStr(cstmt.getString(6 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(7 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(8 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(9 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(10 + inCount)) };

            return outParams;
        } finally {
            // CallableStatementをクローズ
            DBAccess.closeCallableStatement(cstmt);
        }

    }

    /**
     * <pre>
     * プロシージャで事後登録をチェックして、処理結果を返す
     * 
     * 実行結果配列(varchar2):
     * [0]:処理結果状態 0:成功 1:order_id不正 2:成りすましチェックエラー
     * [1]:ユーザーID
     * [2]:見積もりサイトID
     * [3]:見積もり日時
     * [4]:予備1
     * [5]:予備2
     * [6]:予備3
     * [7]:予備4
     * [8]:予備5
     * 
     * </pre>
     * 
     * @param db
     * @param orderId
     * @param email
     * @param mbMail
     * @param cpMail
     * @param nameKanji1
     * @param nameKanji2
     * @return
     * @throws SQLException
     */
    public String[] checkPostRegist(DBAccess db, String orderId, String email, String mbMail, String cpMail,
            String nameKanji1, String nameKanji2) throws SQLException {

        CallableStatement cstmt = null;
        try {
            String procName = get(JIGO_SQL);
            if (procName == null || procName.length() == 0 || isInvalid()) {
                return null;
            }
            StringBuffer selectProcSql = new StringBuffer("{CALL ");
            selectProcSql.append(procName);
            selectProcSql.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?");
            int inCount = inOptionParams.size();
            // 追加INパラメータを設定
            for (int i = 0; i < inCount; i++) {
                selectProcSql.append(", ?");
            }
            selectProcSql.append(")}");

            // CallableStatementを作成
            cstmt = db.prepareCall(selectProcSql.toString());

            // INパラメータを設定
            cstmt.setLong(1, ValueUtil.tolong(orderId));
            cstmt.setString(2, email);
            cstmt.setString(3, mbMail);
            cstmt.setString(4, cpMail);
            cstmt.setString(5, nameKanji1);
            cstmt.setString(6, nameKanji2);

            // 追加INパラメータを設定
            for (int i = 0; i < inCount; i++) {
                cstmt.setString(7 + i, inOptionParams.get(i));
            }
            // OUTパラメータを設定
            cstmt.registerOutParameter(7 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(8 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(9 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(10 + inCount, java.sql.Types.VARCHAR);
            // 以下は予備OUTパラメータ
            cstmt.registerOutParameter(11 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(12 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(13 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(14 + inCount, java.sql.Types.VARCHAR);
            cstmt.registerOutParameter(15 + inCount, java.sql.Types.VARCHAR);

            // CALL文の実行
            int cnt = cstmt.executeUpdate();

            // OUTパラメータの取得(registerOutParameterで登録した位置のパラメータ)
            String[] outParams = { ValueUtil.nullToStr(cstmt.getString(7 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(8 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(9 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(10 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(11 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(12 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(13 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(14 + inCount)),
                    ValueUtil.nullToStr(cstmt.getString(15 + inCount)) };

            return outParams;
        } finally {
            // CallableStatementをクローズ
            DBAccess.closeCallableStatement(cstmt);
        }

    }

    // TODO FOR TEST
    public static void main(String[] args) {
        DBAccess db = null;
        try {

            db = new DBAccess();
            ContractSiteMst site = new ContractSiteMst();
            if (!site.load(db, "4100")) {
                System.out.println("invalid!");
                return;
            }
            // site.addInParam("eerer");
            // site.addInParam("eereewrwerr");
            boolean boo1 = site.isBadUser(db, "34343");
            System.out.println(boo1);
            boolean boo2 = site.isEnqAnswered(db, "324234");
            System.out.println(boo2);
            // site.addInParam("0");
            String enqUrl = site.getEnqUrl(db, "4545", "0");
            System.out.println(enqUrl);
            // site.clearInOptionParams();
            int ret = site.getLimitDays(db, "34343");
            System.out.println(ret);
            String[] retA = site.checkPostRegist(db, "", "", "", "", "", "");
            String[] retArr = site.getContractInfo(db, "3434");
            System.out.println(retArr[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // DBをクローズ
            DBAccess.close(db);
        }

    }

}