package jp.co.webcrew.phoenix.sstag.util;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.sstag.bean.AdminAuthBean;
import jp.co.webcrew.phoenix.sstag.bean.SelectItemBean;
import jp.co.webcrew.phoenix.store.bean.SessionStoreBean;
import jp.co.webcrew.phoenix.store.util.SessionStoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;

/**
 * 各種情報を保存するためのutilクラス。
 * 
 * @author kurinami
 */
public class StoreUtil {

    /** 保存用キー値：フォームデータ */
    private static final String POST_INFO_ATTR_KEY = "phoenix.post_info";

    /** 保存用キー値：入力チェック情報 */
    private static final String VALIDATION_RESULT_ATTR_KEY = "phoenix.validation_result.{0}";

    /** 保存用キー値：スクリーニング情報 */
    private static final String SCREEING_RESULT_ATTR_KEY = "phoenix.screening_result.{0}";

    /** 保存用キー値：前回のスクリーニング結果 */
    private static final String LAST_S_RESULT_ATTR_KEY = "phoenix.last_s_result";

    /** 保存用キー値：前回の補助結果 */
    private static final String LAST_AUX_RESULT_ATTR_KEY = "phoenix.last_aux_result";

    /** 保存用キー値：スクリーニング結果とformの関連づけ */
    private static final String ASSIGN_ATTR_KEY = "phoenix.assign.{0}.{1}.{2}";

    /** 保存用キー値：エラーメッセージマップ */
    private static final String MSG_MAP_ATTR_KEY = "phoenix.msg_map.{0}";

    /** 保存用キー値：オーダーID */
    private static final String GOID_ATTR_KEY = "phoenix.goid";

    /** 保存用キー値：オーダー情報 */
    private static final String ORDER_INFO_ATTR_KEY = "phoenix.order_info";

    /** 保存用キー値：認証情報 */
    private static final String ADMIN_AUTH_ATTR_KEY = "phoenix.admin_auth.{0}";

    /** 保存用キー値：管理者ログイン済み */
    private static final String ADMIN_LOGIN_ATTR_KEY = "phoenix.admin_login";

    /** 保存用キー値：サイトID */
    private static final String SITE_ID_ATTR_KEY = "phoenix.site_id";

    /** 保存用キー値：handover */
    private static final String HANDOVER_ATTR_KEY = "phoenix.handover";

    /** 保存用キー値：選択肢マスタ */
    private static final String SELECT_MST_ATTR_KEY = "phoenix.select_mst.{0}";

    /** 保存用キー値：置換変数一覧 */
    private static final String REPLACE_PARAM_SET_KEY = "phoenix.replace_param_set";

    /**
     * カレントのセッションストアを設定する。
     * 
     * @param request
     * @param shortId
     * @param life
     * @throws SQLException
     */
    public static void setCurrent(HttpServletRequest request, String shortId, String life) throws SQLException {
        String scope = SessionStoreBean.SCOPE_SHORT;
        if (PhoenixUtil.contains(new String[] { "1", "local" }, life.toLowerCase())) {
            scope = SessionStoreBean.SCOPE_LOCAL;
        } else if (PhoenixUtil.contains(new String[] { "2", "site" }, life.toLowerCase())) {
            scope = SessionStoreBean.SCOPE_SITE;
        } else if (PhoenixUtil.contains(new String[] { "3", "global" }, life.toLowerCase())) {
            scope = SessionStoreBean.SCOPE_GLOBAL;
        } else if (PhoenixUtil.contains(new String[] { "4", "login" }, life.toLowerCase())) {
            scope = SessionStoreBean.SCOPE_LOGIN;
        }
        SessionStoreUtil.setCurrentSessionStore(request, shortId);

        if (getPostInfo(request) == null) {
            SessionStoreUtil.setAttribute(request, POST_INFO_ATTR_KEY, new PostInfo(), scope);
        }
    }

    /**
     * ポスト情報を設定する。
     * 
     * @param request
     * @param postInfo
     * @throws SQLException
     */
    public static void setPostInfo(HttpServletRequest request, PostInfo postInfo) throws SQLException {
        SessionStoreUtil.setAttribute(request, POST_INFO_ATTR_KEY, postInfo);
    }

    /**
     * ポスト情報を返す。
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    public static PostInfo getPostInfo(HttpServletRequest request) throws SQLException {
        return (PostInfo) SessionStoreUtil.getAttribute(request, POST_INFO_ATTR_KEY);
    }

    /**
     * バリデーション結果保存用のキーを返す。
     * 
     * @param formId
     * @return
     */
    private static String getValidationKey(String formId) {
        return MessageFormat.format(VALIDATION_RESULT_ATTR_KEY, formId);
    }

    /**
     * バリデーション結果を設定する。
     * 
     * @param request
     * @param formId
     * @param vResult
     * @throws SQLException
     */
    public static void setValidationResult(HttpServletRequest request, String formId, Map<String, String[]> vResult)
            throws SQLException {
        String scope = SessionStoreUtil.getScope(request, POST_INFO_ATTR_KEY);
        SessionStoreUtil.setAttribute(request, getValidationKey(formId), vResult, scope);
    }

    /**
     * バリデーション結果を返す。
     * 
     * @param request
     * @param formId
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static Map<String, String[]> getValidationResult(HttpServletRequest request, String formId)
            throws SQLException {
        return (Map<String, String[]>) SessionStoreUtil.getAttribute(request, getValidationKey(formId));
    }

    /**
     * スクリーニング結果保存用のキーを返す。
     * 
     * @param resultId
     * @return
     */
    private static String getScreeningKey(String resultId) {
        return MessageFormat.format(SCREEING_RESULT_ATTR_KEY, resultId);
    }

    /**
     * スクリーニング結果を設定する。
     * 
     * @param request
     * @param resultId
     * @param sResult
     * @param life
     * @throws SQLException
     */
    public static void setScreeningResult(HttpServletRequest request, String resultId,
            Map<String, Map<String, Object[]>> sResult, String life) throws SQLException {
        if (PhoenixUtil.contains(new String[] { "1", "session" }, life.toLowerCase())) {
            SessionStoreUtil.setAttribute(request, getScreeningKey(resultId), sResult, SessionStoreBean.SCOPE_SHORT);
        } else {
            request.setAttribute(getScreeningKey(resultId), sResult);
        }
    }

    /**
     * セッションに保存されている全てのスクリーニング結果を返す。
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Map<String, Map<String, Object[]>>> getAllScreeningResult(HttpServletRequest request)
            throws SQLException {
        Map<String, Map<String, Map<String, Object[]>>> allScreeningResult = new HashMap<String, Map<String, Map<String, Object[]>>>();

        String prefix = getScreeningKey("");
        for (Map.Entry<String, Object> entry : SessionStoreUtil.getAllAttribute(request, prefix).entrySet()) {
            allScreeningResult.put(entry.getKey().substring(prefix.length()),
                    (Map<String, Map<String, Object[]>>) entry.getValue());
        }
        return allScreeningResult;
    }

    /**
     * スクリーニング結果を返す。
     * 
     * @param request
     * @param resultId
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Map<String, Object[]>> getScreeningResult(HttpServletRequest request, String resultId)
            throws SQLException {
        Map<String, Map<String, Object[]>> sResult = (Map<String, Map<String, Object[]>>) request
                .getAttribute(getScreeningKey(resultId));
        if (sResult == null) {
            sResult = (Map<String, Map<String, Object[]>>) SessionStoreUtil.getAttribute(request,
                    getScreeningKey(resultId));
        }
        return sResult;
    }

    /**
     * 前回のスクリーニング結果保存用のキーを返す。
     * 
     * @return
     */
    private static String getLastSResultKey() {
        return LAST_S_RESULT_ATTR_KEY;
    }

    /**
     * 前回のスクリーニング結果を設定する。
     * 
     * @param request
     * @param vResult
     * @throws SQLException
     */
    public static void setLastSResult(HttpServletRequest request, Map<String, Map<String, Object[]>> sResult,
            String life) throws SQLException {
        if (PhoenixUtil.contains(new String[] { "1", "session" }, life.toLowerCase())) {
            SessionStoreUtil.setAttribute(request, getLastSResultKey(), sResult, SessionStoreBean.SCOPE_SHORT);
        } else {
            request.setAttribute(getLastSResultKey(), sResult);
        }
    }

    /**
     * 前回のスクリーニング結果を返す。
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Map<String, Object[]>> getLastSResult(HttpServletRequest request) throws SQLException {
        Map<String, Map<String, Object[]>> sResult = (Map<String, Map<String, Object[]>>) request
                .getAttribute(getLastSResultKey());
        if (sResult == null) {
            sResult = (Map<String, Map<String, Object[]>>) SessionStoreUtil.getAttribute(request, getLastSResultKey());
        }
        return sResult;
    }

    /**
     * 前回の補助結果保存用のキーを返す。
     * 
     * @return
     */
    private static String getLastAuxResultKey() {
        return LAST_AUX_RESULT_ATTR_KEY;
    }

    /**
     * 前回の補助結果を設定する。
     * 
     * @param request
     * @param vResult
     * @throws SQLException
     */
    public static void setLastAuxResult(HttpServletRequest request, Map<String, Object[]> auxResult, String life)
            throws SQLException {
        if (PhoenixUtil.contains(new String[] { "1", "session" }, life.toLowerCase())) {
            SessionStoreUtil.setAttribute(request, getLastAuxResultKey(), auxResult, SessionStoreBean.SCOPE_SHORT);
        } else {
            request.setAttribute(getLastAuxResultKey(), auxResult);
        }
    }

    /**
     * 前回の補助結果を返す。
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object[]> getLastAuxResult(HttpServletRequest request) throws SQLException {
        Map<String, Object[]> auxResult = (Map<String, Object[]>) request.getAttribute(getLastAuxResultKey());
        if (auxResult == null) {
            auxResult = (Map<String, Object[]>) SessionStoreUtil.getAttribute(request, getLastAuxResultKey());
        }
        return auxResult;
    }

    /**
     * スクリーニング結果が保持されている場所を返す。
     * 
     * @param request
     * @param resultId
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static String getLifeOfScreeningResult(HttpServletRequest request, String resultId) throws SQLException {
        Map<String, Map<String, Object[]>> sResult = (Map<String, Map<String, Object[]>>) request
                .getAttribute(getScreeningKey(resultId));
        if (sResult != null) {
            return "page";
        }
        sResult = (Map<String, Map<String, Object[]>>) SessionStoreUtil
                .getAttribute(request, getScreeningKey(resultId));
        if (sResult != null) {
            return "session";
        }
        return null;
    }

    /**
     * 関連付け保存用のキーを返す。
     * 
     * @param siteId
     * @param formId
     * @param itemId
     * @return
     */
    private static String getAssignKey(int siteId, String formId, String itemId) {
        return MessageFormat.format(ASSIGN_ATTR_KEY, Integer.toString(siteId), formId, itemId);
    }

    /**
     * 関連付けを設定する。
     * 
     * @param request
     * @param siteId
     * @param formId
     * @param itemId
     * @param selectItemList
     * @throws SQLException
     */
    public static void setAssign(HttpServletRequest request, int siteId, String formId, String itemId,
            List<SelectItemBean> selectItemList) throws SQLException {
        SessionStoreUtil.setAttribute(request, getAssignKey(siteId, formId, itemId), selectItemList);
    }

    /**
     * 関連付けを返す。
     * 
     * @param request
     * @param siteId
     * @param formId
     * @param itemId
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static List<SelectItemBean> getAssign(HttpServletRequest request, int siteId, String formId, String itemId)
            throws SQLException {
        return (List<SelectItemBean>) SessionStoreUtil.getAttribute(request, getAssignKey(siteId, formId, itemId));

    }

    /**
     * 関連付けを削除する。
     * 
     * @param request
     * @param siteId
     * @param formId
     * @param itemId
     * @throws SQLException
     */
    public static void removeAssign(HttpServletRequest request, int siteId, String formId, String itemId)
            throws SQLException {
        SessionStoreUtil.removeAttribute(request, getAssignKey(siteId, formId, itemId));
    }

    /**
     * エラーメッセージマップ保存用のキーを返す。
     * 
     * @param msgId
     * @return
     */
    private static String getMsgMapKey(String msgId) {
        return MessageFormat.format(MSG_MAP_ATTR_KEY, msgId);
    }

    /**
     * エラーメッセージマップを設定する。
     * 
     * @param request
     * @param msgId
     * @param msgMap
     */
    public static void setMsgMap(HttpServletRequest request, String msgId, Map<String, String> msgMap) {
        request.setAttribute(getMsgMapKey(msgId), msgMap);
    }

    /**
     * エラーメッセージマップを返す。
     * 
     * @param request
     * @param msgId
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Map<String, String> getMsgMap(HttpServletRequest request, String msgId) {
        return (Map<String, String>) request.getAttribute(getMsgMapKey(msgId));
    }

    /**
     * オーダーID保存用のキーを返す。
     * 
     * @param msgId
     * @return
     */
    private static String getGoidKey() {
        return GOID_ATTR_KEY;
    }

    /**
     * オーダーIDを設定する。
     * 
     * @param request
     * @param goid
     * @throws SQLException
     */
    public static void setGoid(HttpServletRequest request, String goid, String recentGoid) throws SQLException {
        SessionStoreUtil.setAttribute(request, getGoidKey(), new String[] { goid, recentGoid },
                SessionStoreBean.SCOPE_SHORT);
    }

    /**
     * オーダーIDを返す。
     * 
     * @param request
     * @param resultId
     * @return
     * @throws SQLException
     */
    public static String getGoid(HttpServletRequest request) throws SQLException {
        String[] goids = (String[]) SessionStoreUtil.getAttribute(request, getGoidKey());
        if (PhoenixUtil.isEmpty(goids)) {
            return "";
        }
        return goids[0];
    }

    /**
     * 1つ前のオーダーIDを返す。
     * 
     * @param request
     * @param resultId
     * @return
     * @throws SQLException
     */
    public static String getRecentGoid(HttpServletRequest request) throws SQLException {
        String[] goids = (String[]) SessionStoreUtil.getAttribute(request, getGoidKey());
        if (PhoenixUtil.isEmpty(goids)) {
            return "";
        }
        return goids[1];
    }

    /**
     * オーダー情報保存用のキーを返す。
     * 
     * @return
     */
    private static String getOrderInfoKey() {
        return ORDER_INFO_ATTR_KEY;
    }

    /**
     * オーダー情報を設定する。
     * 
     * @param request
     * @param orderInfo
     * @param bind
     * @throws SQLException
     */
    public static void setOrderInfo(HttpServletRequest request, Map<String, ClmDataBean> orderInfo, String bind)
            throws SQLException {
        if (PhoenixUtil.contains(new String[] { "1", "local" }, bind.toLowerCase())) {
            request.getSession().setAttribute(getOrderInfoKey(), orderInfo);
        } else if (PhoenixUtil.contains(new String[] { "2", "short" }, bind.toLowerCase())) {
            SessionStoreUtil.setAttribute(request, getOrderInfoKey(), orderInfo, SessionStoreBean.SCOPE_SHORT);
        } else {
            request.setAttribute(getOrderInfoKey(), orderInfo);
        }
    }

    /**
     * プリロードした内容を設定する。
     * 
     * @param request
     * @param resultId
     * @param sResult
     * @param bind
     * @throws SQLException
     */
    public static void setPreload(HttpServletRequest request, String resultId,
            Map<String, Map<String, Object[]>> sResult, String bind) throws SQLException {
        if (PhoenixUtil.contains(new String[] { "1", "local" }, bind.toLowerCase())) {
            request.getSession().setAttribute(getScreeningKey(resultId), sResult);
        } else if (PhoenixUtil.contains(new String[] { "2", "short" }, bind.toLowerCase())) {
            SessionStoreUtil.setAttribute(request, getScreeningKey(resultId), sResult, SessionStoreBean.SCOPE_SHORT);
        } else {
            request.setAttribute(getScreeningKey(resultId), sResult);
        }
    }

    /**
     * 認証情報保存用のキーを返す。
     * 
     * @param authId
     * @return
     */
    private static String getAdminAuthKey(String authId) {
        return MessageFormat.format(ADMIN_AUTH_ATTR_KEY, authId);
    }

    /**
     * 認証情報を設定する。
     * 
     * @param request
     * @param authId
     * @param adminAuth
     * @throws SQLException
     */
    public static void setAdminAuth(HttpServletRequest request, String authId, AdminAuthBean adminAuth)
            throws SQLException {
        SessionStoreUtil.setAttribute(request, getAdminAuthKey(authId), adminAuth);
    }

    /**
     * 認証情報を返す。
     * 
     * @param request
     * @param authId
     * @return
     * @throws SQLException
     */
    public static AdminAuthBean getAdminAuth(HttpServletRequest request, String authId) throws SQLException {
        return (AdminAuthBean) SessionStoreUtil.getAttribute(request, getAdminAuthKey(authId));
    }

    /**
     * 管理者ログイン済み保存用のキーを返す。
     * 
     * @param authId
     * @return
     */
    private static String getAdminLoginKey() {
        return ADMIN_LOGIN_ATTR_KEY;
    }

    /**
     * 管理者ログイン済みを設定する。
     * 
     * @param request
     */
    public static void setAdminLogin(HttpServletRequest request) {
        request.setAttribute(getAdminLoginKey(), "true");
    }

    /**
     * 管理者ログイン済みかを返す。
     * 
     * @param request
     * @return
     */
    public static boolean isAdminLogin(HttpServletRequest request) {
        Object adminLogin = request.getAttribute(getAdminLoginKey());
        return adminLogin != null;
    }

    /**
     * 管理者ログイン済みを解除する。
     * 
     * @param request
     */
    public static void clearAdminLogin(HttpServletRequest request) {
        request.removeAttribute(getAdminLoginKey());
    }

    /**
     * サイトID保存用のキーを返す。
     * 
     * @return
     */
    private static String getSiteIdKey() {
        return SITE_ID_ATTR_KEY;
    }

    /**
     * サイトIDを設定する。
     * 
     * @param request
     * @param siteId
     */
    public static void setSiteId(HttpServletRequest request, int siteId) {
        request.setAttribute(getSiteIdKey(), Integer.toString(siteId));
    }

    /**
     * サイトIDを返す。
     * 
     * @param request
     * @return
     */
    public static int getSiteId(HttpServletRequest request) {
        return ValueUtil.toint((String) request.getAttribute(getSiteIdKey()));
    }

    /**
     * サイトIDをデフォルトに戻す。
     * 
     * @param request
     * @return
     */
    public static void removeSiteId(HttpServletRequest request) {
        request.removeAttribute(getSiteIdKey());
    }

    /**
     * handoverMap保存用のキーを返す。
     * 
     * @return
     */
    private static String getHandoverMapKey() {
        return HANDOVER_ATTR_KEY;
    }

    /**
     * handoverMapを設定する。
     * 
     * @param request
     * @param handoverMap
     * @throws SQLException
     */
    public static void setHandoverMap(HttpServletRequest request, Map<String, String> handoverMap) throws SQLException {
        SessionStoreUtil.setAttribute(request, getHandoverMapKey(), handoverMap);
    }

    /**
     * handoverMapを返す。
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static Map<String, String> getHandoverMap(HttpServletRequest request) throws SQLException {
        return (Map<String, String>) SessionStoreUtil.getAttribute(request, getHandoverMapKey());
    }

    /**
     * handoverMapを削除する。
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    public static void removeHandoverMap(HttpServletRequest request) throws SQLException {
        SessionStoreUtil.removeAttribute(request, getHandoverMapKey());
    }

    /**
     * 選択肢マスタ保存用のキーを返す。
     * 
     * @param key
     * @return
     */
    private static String getSelectMstKey(String key) {
        return MessageFormat.format(SELECT_MST_ATTR_KEY, key);
    }

    /**
     * 選択肢マスタを設定する。
     * 
     * @param request
     * @param key
     * @param selectMst
     */
    public static void setSelectMst(HttpServletRequest request, String key, List<SelectItemBean> selectMst) {
        request.setAttribute(getSelectMstKey(key), selectMst);
    }

    /**
     * 選択肢マスタを返す。
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public static List<SelectItemBean> getSelectMst(HttpServletRequest request, String key) {
        return (List<SelectItemBean>) request.getAttribute(getSelectMstKey(key));
    }

    /**
     * phoenix用の置換変数の一覧を保持するsetを返す。
     * 
     * @param request
     * @return
     */
    @SuppressWarnings("unchecked")
    private static Set<String> getPhoenixReplaceParamSet(HttpServletRequest request) {
        Set<String> phoenixReplaceParamSet = (Set<String>) request.getAttribute(REPLACE_PARAM_SET_KEY);
        if (phoenixReplaceParamSet == null) {
            phoenixReplaceParamSet = new HashSet<String>();
            request.setAttribute(REPLACE_PARAM_SET_KEY, phoenixReplaceParamSet);
        }
        return phoenixReplaceParamSet;
    }

    /**
     * phoenix用の置換変数を登録する。(後で削除できるように一覧を別途保持しておく。)
     * 
     * @param request
     * @param kwd_name
     * @param content
     */
    public static void addPhoenixReplaceParam(HttpServletRequest request, String kwd_name, String content) {
        KeywordReplacer.addDynamicKeyword(request, kwd_name, content);
        getPhoenixReplaceParamSet(request).add(kwd_name);
    }

    /**
     * phoenix用の置換変数を登録する。(後で削除できるように一覧を別途保持しておく。)
     * 
     * @param request
     * @param prefix
     * @param kwd_name
     * @param content
     */
    public static void addPhoenixReplaceParam(HttpServletRequest request, String prefix, String kwd_name, String content) {
        KeywordReplacer.addDynamicKeyword(request, prefix, kwd_name, content);
        getPhoenixReplaceParamSet(request).add(kwd_name);
        getPhoenixReplaceParamSet(request).add(prefix + kwd_name);
    }

    /**
     * phoenix用の置換変数をまとめて削除する。
     * 
     * @param request
     */
    public static void removePhoenixReplaceParam(HttpServletRequest request) {
        Set<String> phoenixReplaceParamSet = getPhoenixReplaceParamSet(request);
        for (String phoenixReplaceParam : phoenixReplaceParamSet) {
            KeywordReplacer.removeDynamicKeyword(request, phoenixReplaceParam);
        }
        phoenixReplaceParamSet.clear();
    }

}
