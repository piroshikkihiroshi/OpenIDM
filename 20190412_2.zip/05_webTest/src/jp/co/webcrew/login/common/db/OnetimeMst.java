/**
 * 
 */
package jp.co.webcrew.login.common.db;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.StringUtil;

/**<pre>
 * </pre>
 * @author Takahashi
 *
 */
public class OnetimeMst extends DBEntity{

    /** ロガー */
    private static final Logger log = Logger.getLogger(OnetimeMst.class);

    
    /** テーブル名 */
    public static final String TABLE = "ONETIME_MST"; 

    /*
     * 列名定義
     */
    public static final String GUID        = "GUID"; 
    public static final String ONETIME_ID  = "ONETIME_ID"; 
    public static final String EMAIL       = "EMAIL"; 
    public static final String MK_DATETIME = "MK_DATETIME";
    
    
    public static final String DEFAULT_LIMIT = "3d";

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
     */
    public void init(){
        setTable(TABLE);
    }
    
    public OnetimeMst(){
        super();
    }
    
    public OnetimeMst(String guid) {
        super();
        set(GUID , guid);
    }
    
    public boolean load (DBAccess db , String oneTimeId) {
        try {
            String sql = "SELECT * FROM " + TABLE + " WHERE " + ONETIME_ID + "=?";
            db.prepareStatement(sql);
            db.setString(1 , oneTimeId);
            
            Record rec = Record.getFirstRowOf(db);
            
            if (rec == null) {
                return false;
            } else {
                setRecord(rec);
                return true;
            }
            
        } catch (Exception e) {
            
            log.error("ワンタイムIDの読み込み中に例外エラーが発生しました。oneTimeId=" + oneTimeId , e);
            
            return false;

        }
        
    }
    
    /**
     * <pre>
     * guidが一致するデータを削除する
     * </pre>
     * @param db
     * @param guid
     * @return
     */
    public static boolean delete (DBAccess db , String guid) {
        
        try {
        
            String sql = "DELETE FROM " + TABLE + " WHERE " + GUID + "=?";
            db.prepareStatement(sql);
            db.setString(1, guid);
            db.executeUpdate();
            
            return true;
        
        } catch (Exception e) {
            
            log.error("ワンタイムIDのデータ削除に失敗しました。guid=" + guid , e);
            
            return false;
        }        
        
    }

    /**
     * <pre>
     * 古いデータを一括削除する。
     * </pre>
     * @param db
     * @return
     */
    public static boolean deleteOldData (DBAccess db) {
        
        String limit = getOneTimeLimit(db);
        
        if (! limit.startsWith("-")) {
            limit = "-" + limit;
        }

        // ワンタイムID有効期限の2倍より古いものを「古い不要データ」とみなす。
        String old_date_border = DateUtil.getDateTime(limit);
        old_date_border = DateUtil.getDateTime(old_date_border , limit);
        

        // 念のため、old_date_borderが現在日付より6日以上古いかどうかを確認する。
        // (消去対象のデータは最低でも6日以上古いものとする)

        long now = StringUtil.forceLong(DateUtil.currentDateTime());
        long old = StringUtil.forceLong(old_date_border);
        
        if (old <= 0) {
            log.error("削除対象過去日付の取得に失敗しました。処理を中止します。");
            return false;
        }
        
        if (old >= now) {
            log.error("削除対象過去日付が未来になっています。処理を中止します。");
            return false;
        }
        
        long minimum_border = StringUtil.forceLong(DateUtil.getDateTime("-6d"));
        
        if (old > minimum_border && minimum_border > 0) {
            log.info("ワンタイム有効期間が短いため、削除対象過去日付を6日に再設定します。");
            old_date_border = String.valueOf(minimum_border);
        }

        log.info("これ以前の古いデータを削除します：date=" + old_date_border);

        try {
        
            String sql = "DELETE FROM " + TABLE + " WHERE " + MK_DATETIME + "<= ? ";
            db.prepareStatement(sql);
            db.setString(1, old_date_border);
            db.executeUpdate();
            
            return true;
        
        } catch (Exception e) {
            
            log.error("ワンタイムIDの古いデータ削除に失敗しました。");
            
            return false;
        }        
        
        
    }

    /**
     * <pre>
     * ワンタイムIDの有効期間を取得する。
     * 
     * </pre>
     * @param db
     * @return
     */
    public static String getOneTimeLimit(DBAccess db) {
        
        String limit = null;
        String defaultLimit = OnetimeMst.DEFAULT_LIMIT;
        
        try {
            SystemProperties prop = new SystemProperties(db);
            
            limit = ValueUtil.nullToStr(prop.get("MYPAGE_ONETIME_ID_LIMIT"));
            
            if (limit.equals("")) {
                return defaultLimit;
            } else {
                return limit;
            }
        } catch (Exception e) {
            log.error("ワンタイムIDの有効期限を取得中に例外エラーが発生しました。デフォルト値を使用します。" , e);
            return defaultLimit;
        }
        
    }
}
