package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.login.common.point.ContractPointUtil;

/**
 * アンケート完了画面更新を行うsstag
 * 
 * @author Fu
 */
public class ContractEnqAnswerExecuter extends SSTagExecuter {

    /** ロガー */
    private static final Logger log = Logger.getLogger(ContractEnqAnswerExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
     * javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        String htmlNg = "";
        try {

            // --------------------------------------------------------------------------------
            // sstagのパラメータを取得する。
            String siteId = ValueUtil.nullToStr(parameters.get("site_id"));
            String orderId = ValueUtil.nullToStr((String) parameters.get("order_id"));
            String htmlOk = ValueUtil.nullToStr(parameters.get("html_ok"));
            htmlNg = ValueUtil.nullToStr(parameters.get("html_ng"));
            String htmlOther = ValueUtil.nullToStr(parameters.get("html_other"));

            // --------------------------------------------------------------------------------
            // sstagのパラメータをチェックする。

            // サイトIDがパラメータで指定されなかった場合は、filterで保持するサイトIDを使用する。
            if (siteId.length() == 0) {
                siteId = (String) request.getAttribute(UserInfo.SITE_ID_ATTR_KEY);
            }

            // siteIdが指定されていない場合、
            if (siteId.length() == 0) {
                // パラメータエラーとする
                log.error("パラメータエラー パラメータ[siteId]が指定されていません。");
                return "";
            }

            // orderIdが指定されていない場合、
            if (orderId.length() == 0) {
                // パラメータエラーとする
                log.error("パラメータエラー パラメータ[orderId]が指定されていません。");
                return "";
            }

            int ret = ContractPointUtil.updateAnswer(siteId, orderId);
            if (ContractPointUtil.RETURN_OK == ret) {
                return htmlOk;
            } else if (ContractPointUtil.RETURN_NG == ret) {
                return htmlNg;
            } else {
                return htmlOther;
            }

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return htmlNg;
        }

    }

}
