package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;

/**
 * TimeSwitchingExecuterで指定されるコンテンツIDとコンテンツデータを管理するdbクラス。
 * 
 * @author amit, katsuno
 */
public class TimeSwitchingContentsMstDb extends RefreshMstDb {

	/** Sorting Mobile Contentsマスタ情報取得用SQL */
	private static final String TIME_SWITCHING_CONTENTS_MST_SELECT = "select * from common.time_switching_contents_mst";

	/** 唯一のインスタンス */
	private static TimeSwitchingContentsMstDb objTimeSwitchingContentsMstDb = new TimeSwitchingContentsMstDb();

	/** 変換キーワードの一覧 */
	private Map mapContents = null;

	/**
	 * 生成不能コンストラクタ
	 */
	private TimeSwitchingContentsMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static TimeSwitchingContentsMstDb getInstance() {
		return objTimeSwitchingContentsMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();
			mapContents = new HashMap();

			dbAccess.prepareStatement(TIME_SWITCHING_CONTENTS_MST_SELECT);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				String strContentsId = rs.getString("contents_id");
				String strContents = rs.getString("contents");
				mapContents.put(strContentsId, strContents);
			}
		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * 
	 * @return
	 */
	public Map getContents() {
		return mapContents;
	}
}
