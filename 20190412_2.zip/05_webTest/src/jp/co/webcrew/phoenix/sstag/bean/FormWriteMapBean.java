package jp.co.webcrew.phoenix.sstag.bean;

/**
 * フォーム登録先テーブルマップを保持するbeanクラス。
 * 
 * @author kurinami
 */
public class FormWriteMapBean {

    /** サイトID */
    private int siteId = 0;

    /** フォームID */
    private String formId = "";

    /** グループID */
    private String groupId = "";

    /** 書き込み先サイトID */
    private int mapSiteId = 0;

    /** 書き込み先テーブルID */
    private String mapTblId = "";

    // 以下、アクセッサ。

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public int getMapSiteId() {
        return mapSiteId;
    }

    public void setMapSiteId(int mapSiteId) {
        this.mapSiteId = mapSiteId;
    }

    public String getMapTblId() {
        return mapTblId;
    }

    public void setMapTblId(String mapTblId) {
        this.mapTblId = mapTblId;
    }

}
