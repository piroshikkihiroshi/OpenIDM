package jp.co.webcrew.phoenix.util;

import java.text.MessageFormat;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/***
 * 各ロジックからHttpServletRequest、HttpServletResponseが参照するために追加
 * 
 * 
 * @author kazuto.yano
 *
 */
public class PhoenixRequestContext 
{
	private static ThreadLocal<__ServletContext> __context=new ThreadLocal<__ServletContext>();
	private static final Logger logger=Logger.getLogger(PhoenixRequestContext.class);
	
	//private static ServletContext __servletContext;
	
    private static String NEW_LINE_CODE;
    static
    {
    	try
    	{
    		NEW_LINE_CODE=System.getProperty("line.separator");
    	}
    	catch(Exception exc)
    	{
    		
    	}
    	if(NEW_LINE_CODE==null)
    	{
    		NEW_LINE_CODE="\n";
    	}
    }
	
	
	/****
	 * リクエスト関連のオブジェクトを割り当てる
	 * 
	 * @param req
	 * @param res
	 */
	public static void bindServletObject(ServletRequest req, ServletResponse res)
	{
		HttpServletRequest request=(HttpServletRequest)req;
		HttpServletResponse response=(HttpServletResponse)res;
		__context.set(new __ServletContext(request, response));
	}
	
	/***
	 * リクエストの解放処理
	 * 
	 */
	public static void releaseServletObject()
	{
		
		__context.remove();
		/*
		try
		{
		}
		catch(Exception exc)
		{
			
		}
		*/
	}
	
//	/***
//	 * サーブレットコンテキスト
//	 * 
//	 * @param context
//	 */
//	public static void bindServletContext(ServletContext context)
//	{
//		//フェニックス独自実装
//		__servletContext=context;
//		PhoenixBackgroundRefreshMstDB.getInstance().init();
//	}
//	
//	public static void releaseServletContext()
//	{
//		__servletContext=null;
//	}
	
	
	
	/*****
	 * リクエストオブジェクトを取得する。
	 * 
	 * @return
	 */
	public static HttpServletRequest getServletRequest()
	{
		return __context.get().request;
	}
	
	/*****
	 * レスポンスオブジェクトを取得する。
	 * 
	 * @return
	 */
	public static HttpServletResponse getServletResponse()
	{
		return __context.get().response;
	}
	
	
//	public static ServletContext getServletContext()
//	{
//		return __servletContext;
//	}


	/***
	 * リクエストに関する基本情報を取得する
	 * 
	 * @rerurn 配列(0:サーバー名/1:リクエストURI/2:クエリー文字列)
	 */
	public static String getRequestInfo()
	{
		String tpl="[]";
		final String HEADER_TPL=
			"[URL]{0}{1}[QueryString]{2}{3}[IPAddress]{4}{5}{6}{7}";

		
		__ServletContext srvCtxt=__context.get();
		if(srvCtxt==null || srvCtxt.request==null)
		{
			return "";
		}
		HttpServletRequest request=srvCtxt.request;
		if(request==null)
		{
			return "";
		}
		
		StringBuilder bld=new StringBuilder();
		
		Enumeration<?> enums=request.getHeaderNames();
		if(enums!=null)
		{
			while(enums.hasMoreElements())
			{
				Object headerName=(Object)enums.nextElement();
				String strHeaderName=headerName.toString();
				bld.append("[");
				bld.append(strHeaderName);
				bld.append("]");
				bld.append(request.getHeader(strHeaderName));
				bld.append(NEW_LINE_CODE);
			}
		}
		
		
		String msg=MessageFormat.format(HEADER_TPL, 
				request.getRequestURL().toString()
				,NEW_LINE_CODE
				,request.getQueryString()
				,NEW_LINE_CODE
				,request.getRemoteAddr()
				,NEW_LINE_CODE
				,bld.toString()
				,NEW_LINE_CODE
		);
		
		
		/*
		msg="[ServerName]"+requestInfo[1]+"\n[URI]"+requestInfo[2]+"\n[QueryString]"+requestInfo[3]+"\n"+msg;
		*/
		
		//String 
		return msg;
	}
	
	/*
	public static String[] getRequestInfo()
	{
		__ServletContext srvCtxt=__context.get();
		if(srvCtxt==null || srvCtxt.request==null)
		{
			return new String[]{"CTXT_NOT_FOUND","","",""};
		}
		HttpServletRequest request=srvCtxt.request;
		if(request==null)
		{
			return new String[]{"REQUEST_NOT_FOUND","","",""};
		}
		String reqUri=request.getRequestURI();
		String serverName=request.getServerName();
		String queryString=request.getQueryString();
		return new String[]{"success",serverName,reqUri,queryString};
	}
	*/
	
	private static final String REQ_ATTE_NAME_NO_CACHE=PhoenixRequestContext.class.getSimpleName()+"_NO_CACHE";
	
	/***
	 * 
	 * レスポンスヘッダにNoCache属性を付与するか否か
	 * 
	 * true:ReplaceFilterにて、強制的にNoCache属性付与
	 * false:ReplaceFilterにて、強制的にNoCache属性しない
	 * null:ReplaceFilterにて、Replace処理適用前のHTMLと適用後のHTMLを比較し、違う場合はNoCache属性付与
	 * 
	 * 
	 * @param ignore
	 */
	public static void reserveResponseNoCache(Boolean ignore)
	{
		HttpServletRequest request=getServletRequest();
		if(request==null)return;
		if(ignore==null)
		{
			request.removeAttribute(REQ_ATTE_NAME_NO_CACHE);
		}
		else
		{
			request.setAttribute(REQ_ATTE_NAME_NO_CACHE, ignore.toString());
		}
	}
	
	
	public static Boolean isReserved_ResponseNoCache()
	{
		HttpServletRequest request=getServletRequest();
		if(request==null){return null;}
		
		String val=ValueUtil.nullToStr(request.getAttribute(REQ_ATTE_NAME_NO_CACHE));
		
		if(val.length()==0)
		{
			return null;
		}
		else if(val.equals("true"))
		{
			return true;
		}
		else if(val.equals("false"))
		{
			return false;
		}
		else
		{
			logger.warn("リクエスト属性値["+REQ_ATTE_NAME_NO_CACHE+"]の値が不正です。設定されている値"+val);
			return null;
		}
	}
	
	
	private static final class __ServletContext
	{
		HttpServletRequest request;
		HttpServletResponse response;
		
		public __ServletContext(HttpServletRequest request,HttpServletResponse response)
		{
			this.request=request;
			this.response=response;
		}
	}
}
