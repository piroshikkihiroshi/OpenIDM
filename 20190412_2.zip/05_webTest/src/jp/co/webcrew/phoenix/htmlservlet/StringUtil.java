/**
 * 
 */
package jp.co.webcrew.phoenix.htmlservlet;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import jp.co.webcrew.dbaccess.util.Logger;

/**
 * @author Takahashi
 *
 */
public class StringUtil {

	/** ロガー */
    private static final Logger log = Logger.getLogger(StringUtil.class);

    /** 半角カナ・全角カナ変換テーブル */
    private static final String kanaHanZenTblUnicode[][] = {
//    	 ｶﾞｷﾞｸﾞｹﾞｺﾞ 
    	{ "\uFF76\uFF9E", "\u30AC" }, { "\uFF77\uFF9E", "\u30AE" }, { "\uFF78\uFF9E", "\u30B0" }, { "\uFF79\uFF9E", "\u30B2" }, { "\uFF7A\uFF9E", "\u30B4" },
//    	 ｻﾞｼﾞｽﾞｾﾞｿﾞ
    	{ "\uFF7B\uFF9E", "\u30B6" }, { "\uFF7C\uFF9E", "\u30B8" }, { "\uFF7D\uFF9E", "\u30BA" }, { "\uFF7E\uFF9E", "\u30BC" }, { "\uFF7F\uFF9E", "\u30BE" }, 
//    	 ﾀﾞﾁﾞﾂﾞﾃﾞﾄﾞ
    	{ "\uFF80\uFF9E", "\u30C0" }, { "\uFF81\uFF9E", "\u30C2" }, { "\uFF82\uFF9E", "\u30C5" }, { "\uFF83\uFF9E", "\u30C7" }, { "\uFF84\uFF9E", "\u30C9" }, 
//    	 ﾊﾞﾋﾞﾌﾞﾍﾞﾎﾞ
    	{ "\uFF8A\uFF9E", "\u30D0" }, { "\uFF8B\uFF9E", "\u30D3" }, { "\uFF8C\uFF9E", "\u30D6" }, { "\uFF8D\uFF9E", "\u30D9" }, { "\uFF8E\uFF9E", "\u30DC" }, 
//    	 ﾊﾟﾋﾟﾌﾟﾍﾟﾎﾟ 
    	{ "\uFF8A\uFF9F", "\u30D1" }, { "\uFF8B\uFF9F", "\u30D4" }, { "\uFF8C\uFF9F", "\u30D7" }, { "\uFF8D\uFF9F", "\u30DA" }, { "\uFF8E\uFF9F", "\u30DD" },
//    	 ｳﾞ
    	{ "\uFF73\uFF9E", "\u30F4" },

//    	 1文字構成の半角カナ
//    	 ｡｢｣､･ 
    	{ "\uFF61", "\u3002" }, { "\uFF62", "\u300C" }, { "\uFF63", "\u300D" }, { "\uFF64", "\u3001" }, { "\uFF65", "\u30FB" },
//    	 ｦ 
    	{ "\uFF66", "\u30F2" },
//    	 ｧｨｩｪｫ 
    	{ "\uFF67", "\u30A1" }, { "\uFF68", "\u30A3" }, { "\uFF69", "\u30A5" }, { "\uFF6A", "\u30A7" }, { "\uFF6B", "\u30A9" },
//    	 ｬｭｮｯ 
    	{ "\uFF6C", "\u30E3" }, { "\uFF6D", "\u30E5" }, { "\uFF6E", "\u30E7" }, { "\uFF6F", "\u30C3" },
//    	 ｰ 
    	{ "\uFF70", "\u30FC" },
//    	 ｱｲｳｴｵ 
    	{ "\uFF71", "\u30A2" }, { "\uFF72", "\u30A4" }, { "\uFF73", "\u30A6" }, { "\uFF74", "\u30A8" }, { "\uFF75", "\u30AA" },
//    	 ｶｷｸｹｺ 
    	{ "\uFF76", "\u30AB" }, { "\uFF77", "\u30AD" }, { "\uFF78", "\u30AF" }, { "\uFF79", "\u30B1" }, { "\uFF7A", "\u30B3" },
//    	 ｻｼｽｾｿ 
    	{ "\uFF7B", "\u30B5" }, { "\uFF7C", "\u30B7" }, { "\uFF7D", "\u30B9" }, { "\uFF7E", "\u30BB" }, { "\uFF7F", "\u30BD" }, 
//    	 ﾀﾁﾂﾃﾄ 
    	{ "\uFF80", "\u30BF" }, { "\uFF81", "\u30C1" }, { "\uFF82", "\u30C4" }, { "\uFF83", "\u30C6" }, { "\uFF84", "\u30C8" }, 
//    	 ﾅﾆﾇﾈﾉ 
    	{ "\uFF85", "\u30CA" }, { "\uFF86", "\u30CB" }, { "\uFF87", "\u30CC" }, { "\uFF88", "\u30CD" }, { "\uFF89", "\u30CE" }, 
//    	 ﾊﾋﾌﾍﾎ 
    	{ "\uFF8A", "\u30CF" }, { "\uFF8B", "\u30D2" }, { "\uFF8C", "\u30D5" }, { "\uFF8D", "\u30D8" }, { "\uFF8E", "\u30DB" }, 
//    	 ﾏﾐﾑﾒﾓ 
    	{ "\uFF8F", "\u30DE" }, { "\uFF90", "\u30DF" }, { "\uFF91", "\u30E0" }, { "\uFF92", "\u30E1" }, { "\uFF93", "\u30E2" },
//    	 ﾔﾕﾖ 
    	{ "\uFF94", "\u30E4" }, { "\uFF95", "\u30E6" }, { "\uFF96", "\u30E8" }, 
//    	 ﾗﾘﾙﾚﾛ 
    	{ "\uFF97", "\u30E9" }, { "\uFF98", "\u30EA" }, { "\uFF99", "\u30EB" }, { "\uFF9A", "\u30EC" }, { "\uFF9B", "\u30ED" },
//    	 ﾜﾝ 
    	{ "\uFF9C", "\u30EF" }, { "\uFF9D", "\u30F3" }, 
// 	    ﾞﾟ
    	{ "\uFF9E", "\u309B" }, { "\uFF9F", "\u309C" },
// 	    (trim)
    	{ "", "" }
    	
    };
    
    /**
	 * 半角英数字チェック
	 * @param target 対象文字列
	 * @return true targetが半角英数字である時
	 * @return true targetが+-.等の記号の時
	 * @return false targetが半角英数字でない文字を含む時
	 * @return false targetがnullの時
	 */
	public static boolean checkHankakuEisuu(String target) {
		// 半角英数字のチェック
		if(target == null){
			return false;
		}
		boolean rs = true;
		for (int i=0; i<target.length(); i++) {
			if (!(target.charAt(i) > 0x0020 && target.charAt(i) < 0x007F)) {
				rs = false;
				break;
			}
		}
		return rs;
	}

	/**
	 * 文字列を数値に変換
	 * 変換に失敗した場合は0を返します
	 * @param str 文字列
	 * @return int 数値
	 */
	public static int forceInt(String str) {
		int ret = 0;
		try{
			ret = Integer.parseInt(str);			
		}catch(Exception e){
			log.debug("数値変換に失敗しました。: " + str);
		}
		return ret;
	}

	/**
	 * 文字列を数値に変換
	 * 変換に失敗した場合は0を返します
	 * @param str 文字列
	 * @return int 数値
	 */
	public static long forceLong(String str) {
		long ret = 0;
		try{
			ret = Long.parseLong(str);			
		}catch(Exception e){
			log.debug("数値変換に失敗しました。: " + str);
		}
		return ret;
	}
	
	/**
	 * 文字列が数値であるか否かを返す
	 * nullの時はfalse
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isNumber (String str) {
		if (str == null) {
			return false;
		}
		
		try{
			Long.parseLong(str);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * サニタイジング処理
	 */
	public static String sanitize( String src ) {
		if(src == null){
			return "";
		}
		src = src.replaceAll( "&", "&amp;" );
		src = src.replaceAll( "<", "&lt;" );
		src = src.replaceAll( ">", "&gt;" );
		src = src.replaceAll( "\"", "&quot;" );
		src = src.replaceAll( "'", "&#39;" );
		return src;
	}

	/**
	 * 文字列を指定桁数まで'0'で左詰めします
	 * @param src  変換元の文字列
	 * @param keta 桁数
	 * @return 変換後の文字列
	 * @throws IllegalDataException
	 */
	public static String lpadZero( String src ,int keta ) {
		return lpad(src,keta,"0");
	}
	/**
	 * 文字列を指定桁数まで左詰めします
	 * @param src  変換元の文字列
	 * @param keta 桁数
	 * @param str  埋める文字
	 * @return
	 * @throws IllegalDataException
	 */
	public static String lpad( String src ,int keta,String str ) {
		if(src == null){
			src = "";
		}
		
		int len = src.length();
		if(keta < len){
			log.warn("桁数の合わないデータが渡されました。");
			return "";
		}

		StringBuffer wk = new StringBuffer();
		for ( int i=0 ; i < keta - len ; i++ ){
			wk.append(str);
		}
		wk.append( src );
		
		return wk.toString();
	}
	
	/**
	 * <pre>
	 * 全角カタカナチェック
	 * 
	 * 全ての文字が全角カタカナならtrue
	 * そうでないならfalse
	 * 
	 * ・文字列がnullの場合はfalse
	 * ・文字列が空文字の場合もfalse
	 * ・漢字空白は全角とみなす
	 * 
	 * 必要に応じて、trimしてからチェックをかけること
	 * 
	 * </pre>
	 * @param str
	 * @return
	 */
	public static boolean checkZenKana(String str) {
		
		if(str == null) return false; 

		if(str.equals("")) return false;

		// 1文字ずつチェックする
		for(int idx = 0; idx < str.length() ; idx ++){
			char targetChar = str.charAt(idx);

			if( targetChar < 0x30A1 || targetChar > 0x30FE ) {
				return false;
			}
		}
	
		return true;
	}

	/**
	 * <pre>
	 * ニックネームの文字変換と文字列チェックを同時に行う。
	 * 
	 * ・正しい文字列が使用されている場合は、変換後の文字列を返す。
	 * ・文字列に使用不可能な文字列が含まれている場合は、nullを返す。
	 * ・srcがnullの場合はnullを返す。
	 * ・srcが空文字列の場合は空文字列を返す。
	 * 
	 * チェックの過程で、
	 * 
	 * 1) 空白を削除
	 * 
	 * 2) 半角カナを全角カナに変換
	 * 
	 * 3) 変換後の文字列に半角があった場合、英数・記号（-と_）のみを許可する
	 * 
	 * OKの場合は変換後の文字列、
	 * NGの場合はnullを返却する
	 * 
	 * srcがnullの場合はnullを返す
	 * 
	 * srcが空文字列の場合は空文字列を返す
	 * 
	 * </pre>
	 * @param src
	 * @return
	 */
	public static String checkNickName (String src) {
		
		if (src == null) {
			return null;
		}
		
		if (src.equals("")) {
			return "";
		}
		
		// 空白(0x0020 , 0x3000)を削除する
		String ret = removeSpace (src);
		
		// 半角カナを全角カナに変換
		ret = hanKana2FullKana (ret);
		
		// 半角の場合、半角英数と記号（-と_）のみを許可する
		for(int idx = 0; idx < ret.length() ; idx ++){
			char targetChar = ret.charAt(idx);

			if( targetChar < 0x0020 ) {
				// 制御文字は全て不可
				return null;
			}

			if( targetChar > 0x007F ) {
				// 全角は全て許可
				continue;
			}
			
			if (0x0041 <= targetChar && targetChar <= 0x005A) {
				// 半角英字は許可
				continue;
			}

			if (0x0061 <= targetChar && targetChar <= 0x007A) {
				// 半角英字は許可
				continue;
			}

			if ( Character.isDigit(targetChar) ) {
				// 数字は許可
				continue;
			}
			
			if( targetChar != 0x002D && targetChar != 0x005F) {
				// ハイフンとアンダースコア以外は全て不許可とする
				return null;
			}
		}
		
		return ret;
	}
	
	/**
	 * 空白を削除する
	 * 
	 * @param src
	 * @return
	 */
	public static String removeSpace (String src) {
		if (src == null) {
			return null;
		}
		
		if (src.equals("")) {
			return "";
		}
		
		return src.replaceAll("[　 ]", "");
		
	}
	
	/**
	 * <pre>
	 * 半角カタカナ → 全角カタカナ変換
	 * </pre> 
	 * 
	 * @param str 入力文字列
	 * @return 変換後の文字列
	 */
	public static String hanKana2FullKana(String str) {
		if(str == null) {
			return null;
		}

		if(str.equals("")) {
			return "";
		}
	
		String changedStr = "";
	
		for(int loopIndex = 0; loopIndex < str.length(); loopIndex++) {
			char targetChar = str.charAt(loopIndex);
	
			// Unicode半角カタカナのコード範囲をチェック
			if( 0xFF61 <= targetChar && targetChar <= 0xFF9F ) {
				int iKanaTableMax = kanaHanZenTblUnicode.length;
				int i;
				for(i = 0; i < iKanaTableMax; i++) {
					if(str.substring(loopIndex).startsWith(kanaHanZenTblUnicode[i][0])) {
						changedStr += kanaHanZenTblUnicode[i][1];
					//	 濁音・半濁音を処理した場合2文字分を処理として扱う
						if(i < 26){
							loopIndex++;
						}
						
						break;
					}
				}
	
				//	 半角全角変換テーブルの全角カナにマッチするエントリがなければ
				if(i >= iKanaTableMax) {
					changedStr += targetChar;
				}
				
			} else	{
			//	 全角カタカナ以外なら変換せずにそのまま戻り文字列へセットします
				changedStr += targetChar;
			}
		}
	
		return changedStr;

	}

	/**
	 * <pre>
	 * 文字列をスペースもしくはカンマで分割する
	 * 
	 * {return}
	 * 分割された文字列
	 * エラーが発生した時はnull
	 * 
	 * </pre>
	 * 
	 * @param src
	 * @return
	 */
	public static String[] split (String src) {
		if (src == null) {
			return null;
		}
		
		try {

			Pattern pattern = Pattern.compile("[, ]+");
			return  pattern.split(src);

		} catch (RuntimeException e) {
			log.error("文字列の分割中に例外エラーが発生しました。" , e);
			return null;
		}
		

	}
	/**
	 * 半角数値チェック
	 * @param target 対象文字列
	 * @return true targetが半角数値である時
	 * @return false targetが数値でない文字を含む時や全角文字を含む時
	 * @return false targetがnullの時
	 * @return false targetが+-.等の記号の時
	 */
	public static boolean checkHankakuNumeric(String target){
		//半角数値チェック
		//全角は通さない
		if(!checkHankaku(target)){
			return false;
		}
		
		return checkNumeric(target);
	}

	/**
	 * 半角文字列チェック
	 * @param target 対象文字列 
	 * @return true targetが半角の時
	 * @return true targetが空文字の時
	 * @return false targetが半角以外の文字を含む時
	 * @return false targetがnullの時
	 * 
	 */
	public static boolean checkHankaku(String target){
		//半角チェック
		//NULLに対してはfalse
		//空文字に対してはtrue
		if(target == null){
			return false;
		}
		if(target.equals("")){
			return true;
		}

		byte[] bytes = target.getBytes();
		int beams = target.length();
		if (beams == bytes.length) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 数値チェック
	 * @param target 対象文字列
	 * @return true targetが数値である時（全角でも）
	 * @return false targetが数値でない文字を含む時
	 * @return false targetがnullの時
	 * @return false targetが+-.等の記号の時
	 */
	public static boolean checkNumeric(String target){
		//数値チェック
		//+-.は通さない
		//全角は通す
		//空文字は通す
		//NULLに対してはfalse
		if(target == null){
			return false;
		}
		if(target.equals("")){
			return true;
		}
				
		for (int i = 0 ; i < target.length() ; i++ ){
			if(!Character.isDigit(target.charAt(i))){
				return false;				
			}
		}
		return true;
	}
	
	/**
	 * <pre>
	 * 対象文字列をkeyで分割し、分割された文字のリストを返す。
	 * 
	 * エラーが発生した時はnullを返す。
	 * 
	 * </pre>
	 * @param str 分割対象文字列
	 * @param key 分割する区切り文字
	 * @param trim trueを渡すと、分割した文字をtrimします。
	 * falseを渡すと、何もせず、そのまま格納します。
	 * @return 
	 */
	public static List divide(String str, String key , boolean trim) {

		
		try {
			if(str == null){
				// 空のリストを返す
				return null;
			}

			List list = new ArrayList();

			int	index1, index2;

			index1 = 0;
			while (true) {
				index2 = str.indexOf(key,index1);
				if (index2 >= 0) {
					String s = str.substring(index1,index2);

					if(trim){				
						list.add(s.trim());
					} else {
						list.add(s);
					}
					index1 = index2+1;
				}
				else {
					String s = str.substring(index1);
					if(trim){				
						list.add(s.trim());
					} else {
						list.add(s);
					}
					break;
				}
			}

			return list;
			
		} catch (RuntimeException e) {
			log.error("文字列分割時に例外エラーが発生しました。" , e);
			return null;
		}

	}	
}
