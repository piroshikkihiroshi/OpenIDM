﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PasteForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tgtTextArea = New System.Windows.Forms.TextBox()
        Me.BikouGet = New System.Windows.Forms.Button()
        Me.BikouPaste = New System.Windows.Forms.Button()
        Me.HistoryGet = New System.Windows.Forms.Button()
        Me.HistoryPaste = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'tgtTextArea
        '
        Me.tgtTextArea.AcceptsReturn = True
        Me.tgtTextArea.AcceptsTab = True
        Me.tgtTextArea.Location = New System.Drawing.Point(116, 24)
        Me.tgtTextArea.Multiline = True
        Me.tgtTextArea.Name = "tgtTextArea"
        Me.tgtTextArea.Size = New System.Drawing.Size(439, 304)
        Me.tgtTextArea.TabIndex = 0
        '
        'BikouGet
        '
        Me.BikouGet.Location = New System.Drawing.Point(116, 356)
        Me.BikouGet.Name = "BikouGet"
        Me.BikouGet.Size = New System.Drawing.Size(75, 23)
        Me.BikouGet.TabIndex = 1
        Me.BikouGet.Text = "備考取得"
        Me.BikouGet.UseVisualStyleBackColor = True
        '
        'BikouPaste
        '
        Me.BikouPaste.Location = New System.Drawing.Point(220, 356)
        Me.BikouPaste.Name = "BikouPaste"
        Me.BikouPaste.Size = New System.Drawing.Size(75, 23)
        Me.BikouPaste.TabIndex = 2
        Me.BikouPaste.Text = "備考貼付"
        Me.BikouPaste.UseVisualStyleBackColor = True
        '
        'HistoryGet
        '
        Me.HistoryGet.Location = New System.Drawing.Point(354, 356)
        Me.HistoryGet.Name = "HistoryGet"
        Me.HistoryGet.Size = New System.Drawing.Size(75, 23)
        Me.HistoryGet.TabIndex = 3
        Me.HistoryGet.Text = "略歴取得"
        Me.HistoryGet.UseVisualStyleBackColor = True
        '
        'HistoryPaste
        '
        Me.HistoryPaste.Location = New System.Drawing.Point(480, 356)
        Me.HistoryPaste.Name = "HistoryPaste"
        Me.HistoryPaste.Size = New System.Drawing.Size(75, 23)
        Me.HistoryPaste.TabIndex = 4
        Me.HistoryPaste.Text = "略歴貼付"
        Me.HistoryPaste.UseVisualStyleBackColor = True
        '
        'PasteForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(697, 435)
        Me.Controls.Add(Me.HistoryPaste)
        Me.Controls.Add(Me.HistoryGet)
        Me.Controls.Add(Me.BikouPaste)
        Me.Controls.Add(Me.BikouGet)
        Me.Controls.Add(Me.tgtTextArea)
        Me.Name = "PasteForm"
        Me.Text = "PasteForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tgtTextArea As System.Windows.Forms.TextBox
    Friend WithEvents BikouGet As System.Windows.Forms.Button
    Friend WithEvents BikouPaste As System.Windows.Forms.Button
    Friend WithEvents HistoryGet As System.Windows.Forms.Button
    Friend WithEvents HistoryPaste As System.Windows.Forms.Button
End Class
