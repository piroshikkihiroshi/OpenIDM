package jp.co.webcrew.filters.util;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * <pre>
 * データベースユーティティ
 * 
 * </pre>
 * @author Fu
 *
 */
public class DBAccessUtil {

    /** logdbへ接続名 */
    public final static String LOG_DB = "logdb";

    /**
     * @return logdb用接続
     * @throws SQLException
     */
    public static DBAccess getLogDB() throws SQLException {
        // logdb用の接続を返す
        return new DBAccess(LOG_DB);
    }

    /**
     * 順序値を返す。
     * 
     * @param sequenceName
     * @param currentFlag
     * @return
     * @throws SQLException
     */
    public static String getSequenceNo(String sequenceName, boolean currentFlag) throws SQLException {
        String sql;
        if (currentFlag) {
            sql = "select " + sequenceName + ".currval from dual";
        } else {
            sql = "select " + sequenceName + ".nextval from dual";
        }
        DBAccess dbAccess = null;
        try {
            dbAccess = new DBAccess();
            return Long.toString(dbAccess.getSequenceNo(sql));
        } catch (SQLException e) {
            // 現在値取得で未定義エラーの場合はエラーとしない。
            if (currentFlag && e.getErrorCode() == 8002) {
                return "";
            } else {
                throw e;
            }
        } finally {
            DBAccess.close(dbAccess);
        }
    }
    
}
