package jp.co.webcrew.filters.filters.replace.htmlparser;

import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * htmlの内容を解析しながら、置換を行うクラス。
 * 
 * @author kurinami
 */
public class HtmlReplaceParser {

	/** タグ表記内の区切りを表す文字配列 */
	public static final char[] TOKEN_SEP_CHARS = new char[] { '=', '<', '>',
			'/', '!' };

	/** 引用符を表す文字配列 */
	public static final char[] QUOTE_CHARS = new char[] { '\'', '"' };

	/**
	 * htmlの内容を解析しながら置換する。
	 * 
	 * @param contents
	 *            元のhtml
	 * @param cb
	 *            置換ルールを持つパーサーコールバック
	 * @return 置換後のhtml
	 */
	public static String parse(String contents, HtmlReplaceParserCallback cb) {

		StringBuffer sb = new StringBuffer();

		int fromIndex = 0;
		int toIndex;
		String temp;

		while (true) {
			// 次のタグの位置を求める。
			toIndex = contents.indexOf("<", fromIndex);
			toIndex = toIndex >= 0 ? toIndex : contents.length();

			// 次のタグまでにテキストが存在していた場合、
			if (fromIndex != toIndex) {
				temp = contents.substring(fromIndex, toIndex);
				temp = cb.handleText(temp);
				sb.append(temp);
				fromIndex = toIndex;
			}

			// htmlの内容をすべて処理した場合、解析/置換を終了する。
			if (fromIndex == contents.length()) {
				break;
			}

			// タグの終了位置を求める。
			toIndex = contents.indexOf(">", fromIndex + 1);
			toIndex = toIndex >= 0 ? toIndex + 1 : contents.length();

			// タグ部分のみを抜き出す。
			temp = contents.substring(fromIndex, toIndex);

			// タグの種類によりそれぞれ置換処理を行う。
			String tempTrim = temp.substring(1).trim();
			if(tempTrim.startsWith("!--")) {
				temp = cb.handleComment(temp);
			} else if(tempTrim.startsWith("/")) {
				temp = cb.handleEndTag(temp);
			} else {
				temp = cb.handleStartTag(temp);
			}
			
			sb.append(temp);
			fromIndex = toIndex;

			// htmlの内容をすべて処理した場合、解析/置換を終了する。
			if (fromIndex == contents.length()) {
				break;
			}
		}

		return sb.toString();
	}

	/**
	 * 次のトークンの位置を返す。
	 * 
	 * @param data
	 *            トークンを参照する文字列
	 * @param fromIndex
	 *            検索開始位置
	 * @param tokenSepChar
	 *            トークンの区切りとなる文字
	 * @return
	 */
	public static int nextTokenPos(String data, int fromIndex,
			char[] tokenSepChar) {

		int pos = fromIndex;
		
		if (data.charAt(pos) > ' ') {
			// 現状の位置にトークンが着ている場合、
			// そのトークンの終了位置まで進める。
			
			pos++;
			if (contains(data.charAt(fromIndex), QUOTE_CHARS)) {
				// 引用符でくくられている場合、

				// 引用符の終わりの位置を探す。
				for (; pos < data.length(); pos++) {
					if (data.charAt(pos) == data.charAt(fromIndex)) {
						pos++;
						break;
					} else if (data.charAt(pos) == '\\') {
						pos++;
					}
				}
			} else if (!contains(data.charAt(fromIndex), tokenSepChar)) {
				// 最初の文字がトークン区切り文字でない場合、

				// 次の文字から順にトークン区切り位置を探す。
				for (; pos < data.length(); pos++) {
					if (data.charAt(pos) <= ' ') {
						break;
					}
					if (contains(data.charAt(pos), tokenSepChar)) {
						return pos;
					}
				}
			}
		}

		// 空白類の終わりまで進める。
		for (; pos < data.length(); pos++) {
			if (data.charAt(pos) > ' ') {
				return pos;
			}
		}

		// 途中で開始位置が見つからなかった場合、
		// 文字列の終わりの次の位置を返す。
		return data.length();
	}

	/**
	 * 指定の文字が対象文字一覧に含まれているかをチェックする。
	 * 
	 * @param ch
	 *            指定の文字
	 * @param chars
	 *            対象文字一覧
	 * @return
	 */
	public static boolean contains(char ch, char[] chars) {
		for (int i = 0; i < chars.length; i++) {
			if (ch == chars[i]) {
				return true;
			}
		}
		return false;
	}

	/**
	 * タグの中の属性マップを返す。(キー値はすべて小文字に変換される)
	 * 
	 * @param data
	 *            タグ文字列
	 * @param fromIndex
	 *            タグの中での属性の開始位置
	 * @return
	 */
	public static Map getParameterMap(String data, int fromIndex) {

		// 文字列が空の場合、
		if (ValueUtil.nullToStr(data).trim().length() == 0) {
			// 空のマップを返す。
			return new HashMap();
		}
		
		// 開始位置が属性の頭になっていない場合、開始位置を進める。
		if (data.charAt(fromIndex) <= ' ') {
			fromIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
					HtmlReplaceParser.TOKEN_SEP_CHARS);
		}

		Map map = new HashMap();
		int toIndex = fromIndex;

		// 属性を順に処理していく。
		while (!(fromIndex >= data.length() || data.charAt(fromIndex) == '>')) {

			String key = "";
			String value = "";

			// 属性名を抜き出す。
			toIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
					HtmlReplaceParser.TOKEN_SEP_CHARS);
			key = data.substring(fromIndex, toIndex).trim();
			fromIndex = toIndex;

			// 属性値が存在する場合、
			if (fromIndex < data.length() && data.charAt(fromIndex) == '=') {

				// 「=」を読み飛ばす。
				fromIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
						HtmlReplaceParser.TOKEN_SEP_CHARS);
				
				if (!(fromIndex >= data.length() || data.charAt(fromIndex) == '>')) {

					// 属性値を求める
					toIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
							HtmlReplaceParser.TOKEN_SEP_CHARS);
					value = data.substring(fromIndex, toIndex).trim();

					// ' " を取り除く
					value = quoteTrim(value);

                    // \ を取り除く
                    value = escapeTrim(value);

					fromIndex = toIndex;
				}
			}

			map.put(key.toLowerCase(), value);
		}

		return map;
	}

	/**
	 * 文字列が引用符でくくられている場合、引用符を取り除く。
	 * 
	 * @param source
	 * @return
	 */
	public static String quoteTrim(String source) {

		// 属性値が引用符でくくられている場合、引用符を取り除いたものを返す。
		if (HtmlReplaceParser.contains(source.charAt(0), QUOTE_CHARS)
				&& (source.length() >= 2 && source.charAt(0) == source
						.charAt(source.length() - 1))) {

			return source.substring(1, source.length() - 1);
		}

		return source;
	}

    /**
     * エスケープのための\を取り除く
     * 
     * @param source
     * @return
     */
    public static String escapeTrim(String source) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < source.length(); i++) {
            char ch = source.charAt(i);
            if (ch == '\\') {
                i++;
                if (i < source.length()) {
                    sb.append(source.charAt(i));
                }
            } else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    /**
     * 引用不要のエスケープを追加する。
     * 
     * @param source
     * @return
     */
    public static String escapeAdd(String source) {
        String result = source;
        result = ValueUtil.replace(result, "\\", "\\\\");
        result = ValueUtil.replace(result, "\'", "\\\'");
        result = ValueUtil.replace(result, "\"", "\\\"");
        return result;
    }
    
	public static void main(String[] args) {

		String htmlContents = "gagaga\nbibibi\ndododo\n<!-- comment! --><html><head></head><body>hello world!</body></htmldododo";

		HtmlReplaceParserCallback cb = new HtmlReplaceParserCallback() {
		};
		parse(htmlContents, cb);
	}
}
