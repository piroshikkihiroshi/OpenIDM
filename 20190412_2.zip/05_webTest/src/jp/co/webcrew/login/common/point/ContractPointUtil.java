package jp.co.webcrew.login.common.point;

import java.sql.SQLException;
import java.sql.Timestamp;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.ContractPointMst;
import jp.co.webcrew.login.common.db.ContractSiteMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.util.DateUtil;

/**
 * @author Fu
 * 
 */
public class ContractPointUtil {

    /** 処理戻り値 1:正常 */
    public static final int RETURN_OK = 1;
    /** 処理戻り値 2:異常 */
    public static final int RETURN_NG = 2;
    /** 処理戻り値 3:期限切れ */
    public static final int RETURN_EXPIRED = 3;
    /** 処理戻り値 4:その他 */
    public static final int RETURN_OTHER = 4;

    /**
     * 成約アンケートのステータスを回答待から申請待に変更する。
     * 
     * @param siteId
     *            サイトID
     * @param orderId
     *            orderId
     * @return
     * @throws SQLException
     */
    public static int updateAnswer(String siteId, String orderId) throws SQLException {
        DBAccess db = null;
        try {
            db = new DBAccess();
            return updateAnswerInternal(db, siteId, orderId, true);

        } finally {
            DBAccess.close(db);
        }
    }

    public static int updateAnswer(DBAccess db, String siteId, String orderId) throws SQLException {
        return updateAnswerInternal(db, siteId, orderId, true);
    }

    /****
     * 成約せずから成約済みに変更する
     * 
     * @param db
     * @param siteId
     * @param orderId
     * @param contractCompanyIDs
     * @param contractCompanyNames
     * @param memo
     * @return
     * @throws SQLException
     */
    public static int update90To3(DBAccess db, String siteId, String orderId, String contractCompanyIDs,
            String contractCompanyNames, String memo) throws SQLException {
        OrderHist orderHist = new OrderHist();
        if (!orderHist.load(db, siteId, orderId)) {
            throw new RuntimeException("order_histが見つかりません。" + siteId + ":" + orderId);
        }
        if (orderHist.getContractStatus() != OrderHist.STATUS_90_NO_CONTRACT) {
            throw new RuntimeException("現在のステータスが成約せずではありません。" + siteId + ":" + orderId);
        }
        ContractSiteMst contractSite = new ContractSiteMst();
        if (!contractSite.load(db, siteId)) {
            // 対応してないサイトの場合以下の処理は行わないです。
            throw new RuntimeException("CONTRACT_SITE_MSTに登録してないようです。siteId:" + siteId + " orderId:" + orderId);
        }

        String patternId = contractSite.getPointPatternId(db, orderId, "2", contractCompanyIDs, contractCompanyNames);

        ContractPointMst pointMst = new ContractPointMst(siteId);
        if (!pointMst.load(db, patternId)) {
            // 対応してないサイトの場合以下の処理は行わないです。
            throw new RuntimeException("CONTRACT_POINT_MSTがみつかりませんでした。siteId:" + siteId + ":orderId:" + orderId
                    + ":pointNo:" + patternId);
        }

        String point = pointMst.get(ContractPointMst.POINT);

        // 成約会社の情報を
        orderHist.set(OrderHist.CONTRACT_SITE_ID, contractSite.getContractSiteId());
        orderHist.set(OrderHist.CONTRACT_POINT_NO, pointMst.get(ContractPointMst.CONTRACT_POINT_NO));
        orderHist.set(OrderHist.CONTRACT_POINT, point);
        orderHist.set(OrderHist.CONTRACT_STATUS, String.valueOf(OrderHist.STATUS_3_CONFIRM));
        // 強制的に１
        orderHist.set(OrderHist.CONTRACT_FLAG, OrderHist.FLG_CONTRACT_FLAG_ON);
        orderHist.set(OrderHist.CONTRACT_COMPANY_ID, contractCompanyIDs);
        orderHist.set(OrderHist.CONTRACT_COMPANY_NAME, contractCompanyNames);
        orderHist.set(OrderHist.STATUS_UP_DATETIME, DateUtil.currentDateTime());
        orderHist.set(OrderHist.REJECT_REASON, memo); // メモ追加
        OrderHist.updateToDB(db, orderHist);

        return RETURN_OK;

    }

    /**
     * 成約アンケートのステータスを回答待から申請待に変更する。
     * 
     * @param db
     * @param siteId
     * @param orderId
     * @param answerSSTag
     *            呼び出し元が成約アンケート回答画面SSTAGの場合、trueを指定。
     * @throws SQLException
     */
    private static int updateAnswerInternal(DBAccess db, String siteId, String orderId, boolean answerSSTag)
            throws SQLException {

        OrderHist orderHist = new OrderHist();

        if (!orderHist.load(db, siteId, orderId)) {
        	
	        	//追加対応
	        	//履歴がない場合は、アンケートの結果などから申請可能なユーザーか否か判定する
	        	if(answerSSTag)
	        	{
	        		ContractSiteMst contractSiteMst=new ContractSiteMst();
	        		if(contractSiteMst.load(db, siteId))
	        		{
		        			/*
	        				//log.info("getDisplayFlagForNoHist:param"+siteId+":"+orderId);
	        				String functionName=contractSiteMst.get(ContractSiteMst.NO_HIST_SQL);
		        			String sqlNoHist="SELECT "+functionName+"(?,?) FROM DUAL";
		        			db.prepareStatement(sqlNoHist);
		        			db.setString(1, siteId);
		        			db.setString(2, orderId);
		        			rset=db.executeQuery();
		        			String ret;
		        			if(rset.next())
		        			{
		        				ret=rset.getString(1);
		        			}
		        			else
		        			{
		        				ret="";
		        			}
		                    //log.info("getDisplayFlagForNoHist:ret:"+ret);
		        			
		        			if(ret.equals("1"))
		        			{
		        				return RETURN_OK;
		        			}
		        			*/
		        			// 対処済みのはずなので。復活
	        				String ret=ValueUtil.nullToStr(contractSiteMst.getDisplayFlagForNoHist(db, orderId));
		        			if(ret.equals("1"))
		        			{
		        				return RETURN_OK;
		        			}
		        			
	        		}
	        	}
        	
            // TODO　今後ここでneedDisplayForNoHist()を追加予定 
            return RETURN_OTHER;
        }

        if (answerSSTag) {
            int currentStatus = orderHist.getContractStatus();
            switch (currentStatus) {
            case OrderHist.STATUS_3_CONFIRM: // 確認中
            case OrderHist.STATUS_2_APPLICATION_WAIT: // 申請待
                return RETURN_OK;
            case OrderHist.STATUS_90_NO_CONTRACT: // 成約せず
                return RETURN_NG;
            default:
                break;
            }
            // ステータスが対象外の場合
            if (orderHist.getContractStatus() == OrderHist.STATUS_0_OUT) {
                return RETURN_OTHER;
            }
        } else {
            // ステータスが対象外の場合
            if (orderHist.getContractStatus() == OrderHist.STATUS_0_OUT) {
                throw new RuntimeException("ステータスが対象外です。siteId:" + siteId + " orderId:" + orderId);
            }
        }

        // ステータスが「回答待」以外の場合
        if (orderHist.getContractStatus() != OrderHist.STATUS_1_ANSWER_WAIT) {
            throw new RuntimeException("ステータスが不正です。「回答待」ではないです。siteId:" + siteId + " orderId:" + orderId);
        }

        // order_histの有効期限が現在日時以下の場合、期限内
        if (isExpired(db, orderHist)) {
            return RETURN_EXPIRED;
        }

        ContractSiteMst contractSite = new ContractSiteMst();
        if (!contractSite.load(db, siteId)) {
            // 対応してないサイトの場合以下の処理は行わないです。
            throw new RuntimeException("CONTRACT_SITE_MSTに登録してないようです。siteId:" + siteId + " orderId:" + orderId);
        }

        // 成約会社情報を取得する
        String[] contractInfo = contractSite.getContractInfo(db, orderId);
        if (contractInfo == null || contractInfo.length == 0) {
            throw new RuntimeException(siteId + orderId);
        }

        // 成約フラグ
        String contractFlagFromDB = contractInfo[0];
        // 成約会社ID
        String contractCompanyIds = contractInfo[1];
        // 成約会社名
        String contractCompanyNames = contractInfo[2];

        // 未成約の場合
        if (!contractFlagFromDB.equals(OrderHist.FLG_CONTRACT_FLAG_ON)) {

            orderHist.set(OrderHist.CONTRACT_STATUS, String.valueOf(OrderHist.STATUS_90_NO_CONTRACT));
            orderHist.set(OrderHist.STATUS_UP_DATETIME, DateUtil.currentDateTime());
            OrderHist.updateToDB(db, orderHist);
            return RETURN_NG;
        }
        // 成約した場合
        else {

            // 成約ポイントパターン番号を取得する
            String pointNo = contractSite.getPointPatternId(db, orderId, "1", contractCompanyIds, contractCompanyNames);

            // 成約ポイントマスタを検索
            ContractPointMst pointMst = new ContractPointMst(siteId);
            if (!pointMst.load(db, pointNo)) {
                // 成約ポイントマスタが見つからなかった場合
                throw new RuntimeException("成約ポイントマスタが見つからなかった。siteId:" + siteId + " orderId:" + orderId);
            }

            // 付与ポイント
            String point = pointMst.get(ContractPointMst.POINT);

            orderHist.set(OrderHist.CONTRACT_SITE_ID, contractSite.getContractSiteId());
            orderHist.set(OrderHist.CONTRACT_POINT_NO, pointMst.get(ContractPointMst.CONTRACT_POINT_NO));
            orderHist.set(OrderHist.CONTRACT_POINT, point);
            orderHist.set(OrderHist.CONTRACT_STATUS, String.valueOf(OrderHist.STATUS_2_APPLICATION_WAIT));
            orderHist.set(OrderHist.CONTRACT_FLAG, OrderHist.FLG_CONTRACT_FLAG_ON);
            orderHist.set(OrderHist.CONTRACT_COMPANY_ID, contractCompanyIds);
            orderHist.set(OrderHist.CONTRACT_COMPANY_NAME, contractCompanyNames);
            orderHist.set(OrderHist.STATUS_UP_DATETIME, DateUtil.currentDateTime());
            OrderHist.updateToDB(db, orderHist);

            return RETURN_OK;
        }
    }

    /**
     * ORDER_HISTにデータがない場合申請ページへの誘導が必要かどうかチェック。
     * 
     * @param db
     * @param siteId
     * @param orderId
     * return 1:申請ページへの誘導を表示する 0:申請ページへの誘導を表示しない
     * @throws SQLException
     */
    public static boolean needDisplayForNoHist(DBAccess db, String siteId, String orderId) throws SQLException {
        ContractSiteMst contractSite = new ContractSiteMst();
        if (!contractSite.load(db, siteId)) {
            // 対応してないサイトの場合誘導しない。
            return false;
        }
        String ret = contractSite.getDisplayFlagForNoHist(db, orderId);
        return "1".equals(ret) ? true : false;
    }

    /**
     * 成約アンケートのステータスを申請待ちから確認中に変更する
     * 
     * @param guid
     * @param siteId
     * @param orderId
     * @throws SQLException
     */
    public static int updateApplication(String guid, String siteId, String orderId) throws SQLException {
        DBAccess db = null;
        try {
            db = new DBAccess();
            return updateApplication(db, guid, siteId, orderId);

        } finally {
            DBAccess.close(db);
        }
    }

    /**
     * 成約アンケートのステータスを申請待ちから確認中に変更する
     * 
     * @param db
     * @param guid
     * @param siteId
     * @param orderId
     * @throws SQLException
     */
    public static int updateApplication(DBAccess db, String guid, String siteId, String orderId) throws SQLException {

        // 有効なorder_histデータが見つからなかった場合
        OrderHist orderHist = new OrderHist();

        if (!orderHist.load(db, siteId, orderId)) {
            // 有効なorder_histデータが見つからなかった場合
            throw new RuntimeException("ORDER_HISTにデータは見つかりませんでした。siteId:" + siteId + " orderId:" + orderId);
        }
        // ステータスが「申請待」以外の場合
        if (orderHist.getContractStatus() != OrderHist.STATUS_2_APPLICATION_WAIT) {
            throw new RuntimeException("ステータスが不正です。「申請待」ではないです。siteId:" + siteId + " orderId:" + orderId);
        }

        // TODO order_histの有効期限が現在日時以下の場合、期限内
        if (isExpired(db, orderHist)) {
            return RETURN_EXPIRED;
        }

        orderHist.set(OrderHist.CONTRACT_STATUS, String.valueOf(OrderHist.STATUS_3_CONFIRM));
        orderHist.set(OrderHist.STATUS_UP_DATETIME, DateUtil.currentDateTime());
        OrderHist.updateToDB(db, orderHist);
        return RETURN_OK;
    }

    /**
     * 成約アンケートのステータスを確認中からポイント付与に変更する
     * 
     * @param siteId
     * @param orderId
     * @param memo
     * @throws Exception
     */
    public static void updateComplete(String siteId, String orderId, String memo) throws Exception {
        DBAccess db = null;
        try {
            db = new DBAccess();

            db.setAutoCommit(false);
            updateComplete(db, siteId, orderId, memo);
            db.commit();
            db.setAutoCommit(true);
        } catch (Exception ex) {
            db.rollback();
            throw ex;
        } finally {

            DBAccess.close(db);
        }
    }

    /**
     * 成約アンケートのステータスを確認中からポイント付与に変更する
     * 
     * @param db
     * @param siteId
     * @param orderId
     * @param memo
     * @throws Exception
     */
    public static void updateComplete(DBAccess db, String siteId, String orderId, String memo) throws Exception {

        // オートコミットtrueのままこのメソッドを呼び出されると、
        // 不測の障害が発生するおそれがあるため
        // 例外を投げている
        if (db.getAutoCommit()) {
            throw new IllegalArgumentException("dbaccessオブジェクトのトランザクションモードがautocommitのままです。");
        }

        // 有効なorder_histデータが見つからなかった場合
        OrderHist orderHist = new OrderHist();

        if (!orderHist.load(db, siteId, orderId)) {
            // 有効なorder_histデータが見つからなかった場合
            return;
        }

        // ステータスが「確認中」以外の場合
        if (orderHist.getContractStatus() != OrderHist.STATUS_3_CONFIRM) {
            return;
        }

        long point = orderHist.getContractPoint();

        // 付随パラメータには何を？？
        String url = "";
        int type = 106;
        String reason = "成約付与ポイント";
        String bgn_datetime = "";
        boolean auto_kbn = false;
        boolean user_flag = true;
        boolean af_flag = false;

        long pointChargeId = PointUtilRenewal.chargeWithoutTxControl(db, orderHist.getGUID(), point, type, -1,
                ValueUtil.toint(siteId), url, reason, bgn_datetime, auto_kbn, user_flag, af_flag);

        orderHist.set(OrderHist.CONTRACT_STATUS, String.valueOf(OrderHist.STATUS_4_COMPLETE));
        orderHist.set(OrderHist.POINT_CHARGE_ID, String.valueOf(pointChargeId));
        orderHist.set(OrderHist.REJECT_REASON, memo); // メモ追加
        orderHist.set(OrderHist.STATUS_UP_DATETIME, DateUtil.currentDateTime());
        OrderHist.updateToDB(db, orderHist);

    }

    /**
     * 成約アンケートのステータスをポイント付与から取り消しに変更する
     * 
     * @param siteId
     * @param orderId
     * @param reason
     * @throws Exception
     */
    public static void updateCancel(String siteId, String orderId, String reason) throws Exception {
        DBAccess db = null;
        try {
            db = new DBAccess();
            db.setAutoCommit(false);
            updateCancel(db, siteId, orderId, reason);
            db.commit();
            db.setAutoCommit(true);
        } catch (Exception ex) {
            db.rollback();
            throw ex;
        } finally {

            DBAccess.close(db);
        }
    }

    /**
     * 成約アンケートのステータスをポイント付与から取り消しに変更する
     * 
     * @param db
     * @param siteId
     * @param orderId
     * @param reason
     * @throws Exception
     */
    public static void updateCancel(DBAccess db, String siteId, String orderId, String reason) throws Exception {

        // オートコミットtrueのままこのメソッドを呼び出されると、
        // 不測の障害が発生するおそれがあるため
        // 例外を投げている
        if (db.getAutoCommit()) {
            throw new IllegalArgumentException("dbaccessオブジェクトのトランザクションモードがautocommitのままです。");
        }

        // 有効なorder_histデータが見つからなかった場合
        OrderHist orderHist = new OrderHist();

        if (!orderHist.load(db, siteId, orderId)) {
            // 有効なorder_histデータが見つからなかった場合
            return;
        }

        // ステータスが「ポイント付与済」以外の場合
        if (orderHist.getContractStatus() != OrderHist.STATUS_4_COMPLETE) {
            return;
        }

        orderHist.set(OrderHist.CONTRACT_STATUS, String.valueOf(OrderHist.STATUS_6_CANCEL));
        orderHist.set(OrderHist.STATUS_UP_DATETIME, DateUtil.currentDateTime());
        orderHist.set(OrderHist.REJECT_REASON, reason);
        OrderHist.updateToDB(db, orderHist);

        long point = orderHist.getContractPoint();

        int type = 106;
//        String reason = "成約付与ポイントの取消";
        String bgn_datetime = "";
        long giftId = 0;
        boolean auto_kbn = false;
        boolean user_flag = true;

        // TODO 付随パラメータには何を？？
        PointUtilRenewal.spendWithoutTxControl(db, orderHist.getGUID(), point, type, ValueUtil.toint(siteId), giftId, reason,
                bgn_datetime, auto_kbn, user_flag);
        // PointUtilRenewal.chargeWithoutTxControl(db, guid, point, type, siteId, url, reason,
        // bgn_datetime, auto_kbn, user_flag, af_flag);

    }

    /**
     * 成約アンケートのステータスを確認中から未承認に変更する
     * 
     * @param siteId
     * @param orderId
     * @param reason
     * @throws SQLException
     */
    public static void updateReject(String siteId, String orderId, String reason) throws SQLException {
        DBAccess db = null;
        try {
            db = new DBAccess();
            updateReject(db, siteId, orderId, reason);

        } finally {
            DBAccess.close(db);
        }
    }

    /**
     * 成約アンケートのステータスを確認中から未承認に変更する
     * 
     * @param db
     * @param siteId
     * @param orderId
     * @param reason
     * @throws SQLException
     */
    public static void updateReject(DBAccess db, String siteId, String orderId, String reason)
            throws SQLException {

        // 有効なorder_histデータが見つからなかった場合
        OrderHist order = new OrderHist();

        if (!order.load(db, siteId, orderId)) {
            // 有効なorder_histデータが見つからなかった場合
            return;
        }

        // ステータスが「回答待」以外の場合
        if (order.getContractStatus() != OrderHist.STATUS_3_CONFIRM) {
            return;
        }

        order.set(OrderHist.CONTRACT_STATUS, String.valueOf(OrderHist.STATUS_5_REJECT));
        order.set(OrderHist.STATUS_UP_DATETIME, DateUtil.currentDateTime());
        order.set(OrderHist.REJECT_REASON, reason);
        OrderHist.updateToDB(db, order);

    }

    /**
     * 成約アンケートが申請期限を超過しているか否かを確認する
     * 
     * @param siteId
     * @param orderId
     * @throws SQLException
     */
    public static boolean isExpired(String siteId, String orderId) throws SQLException {
        DBAccess db = null;
        try {
            db = new DBAccess();
            return isExpired(db, siteId, orderId);

        } finally {
            DBAccess.close(db);
        }
    }

    /**
     * 成約アンケートが申請期限を超過しているか否かを確認する
     * 
     * @param db
     * @param siteId
     * @param orderId
     * @return
     * @throws SQLException
     */
    public static boolean isExpired(DBAccess db, String siteId, String orderId) throws SQLException {

        // 有効なorder_histデータが見つからなかった場合
        OrderHist orderHist = new OrderHist();

        if (!orderHist.load(db, siteId, orderId)) {
            // 有効なorder_histデータが見つからなかった場合
            // TODO
            throw new IllegalArgumentException("order_histがみつかりませんでした。検索キー:" + siteId + "/" + orderId);
            // return false;
        }
        // ステータスが「回答待」以外の場合
        // if (orderHist.getContractStatus() != OrderHist.STATUS_2_APPLICATION_WAIT) {
        // TODO 下記エラー必要か？
        // throw new IllegalArgumentException("order_histのステータスが不正です。検索キー:" + guid + "/" + siteId +
        // "/" + orderId
        // + ":status:" + orderHist.getContractStatus());
        // }
        return isExpired(db, orderHist);

    }

    /**
     * 成約アンケートが申請期限を超過しているか否かを確認する
     * 
     * @param db
     * @param orderHist
     * @return
     * @throws SQLException
     */
    public static boolean isExpired(DBAccess db, OrderHist orderHist) throws SQLException {
        int status = orderHist.getContractStatus();
        // 回答待と申請待以外は期限がない
        if (status != OrderHist.STATUS_1_ANSWER_WAIT && status != OrderHist.STATUS_2_APPLICATION_WAIT) {
            return false;
        }

        // 有効終了日時
        Timestamp end_timestamp = DateUtil.toTimestamp(orderHist.get(OrderHist.CONTRACT_LIMIT_DATE));
        // 現在日付時刻を取得(YYYYMMDDHHMISS形式)
        Timestamp current_timestamp = DateUtil.toTimestamp(DateUtil.currentDateTime());
        if (end_timestamp.after(current_timestamp)) {
            return false;
        }

        // 期限切れたら更新します
        orderHist.set(OrderHist.CONTRACT_STATUS, String.valueOf(OrderHist.STATUS_91_EXPIRED));
        orderHist.set(OrderHist.STATUS_UP_DATETIME, DateUtil.currentDateTime());
        OrderHist.updateToDB(db, orderHist);
        return true;

    }

    // TODO TEST
    public static void main(String[] args) {
        DBAccess db = null;
        try {
            db = new DBAccess();

            db.setAutoCommit(false);
//            int cnt = ContractPointUtil.updateAnswer("4100", "1697691");
            ContractPointUtil.updateComplete(db, "4160","1702109", "手で更新2");
            db.rollback();
        } catch (Exception ex) {
            db.rollback();
            ex.printStackTrace();
        } finally {

            DBAccess.close(db);
        }
    }
}
