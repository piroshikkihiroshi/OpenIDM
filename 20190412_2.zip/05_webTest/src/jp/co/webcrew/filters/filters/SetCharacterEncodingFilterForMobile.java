package jp.co.webcrew.filters.filters;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.TermMstDb;
import jp.co.webcrew.filters.util.httputil.CustomHttpServletResponse;

/**
 * mobile用に強制的に入力と出力のエンコードを変更する。<br>
 * mobileでない場合は、入力のエンコードの指定だけ行う。<br><br>
 * 
 * param : encoding - mobileでない場合のエンコード指定<br>
 * param : mobileEncoding - mobileの場合のエンコード指定<br>
 * param : targetContentType[*] - フィルタ処理の対象とするContentTypeを指定する。HTTPヘッダのcontentTypeが比較対象となる。<br>
 *                               [*]部分を変更して複数のtargetContentTypeを指定する。数字指定が望ましいが、その他の文字列でも正常に動作する。<br>
 *                               また本パラメータで設定されてもされなくても、"text/html"は必ず対象となる。<br>
 * param : metaContent - metaタグ内のcontent指定の置換データを指定<br>
 *         ・http_header - HTTP HEADER に設定されているContentTypeに置換する<br>
 *         ・not_modify - content指定を置換しない。ただしcharset指定の置換は実行される<br>
 *         	              ※置換対象ファイルの最初に出現するcharset指定のあるmetaタグのみに有効。コメントアウトは無関係なので要注意。<br>
 *         ・「その他」(contentType直書き) - 指定された文字列(contentType)に置換する<br>
 *         ・「指定なし」 - http_headerの指定と同じ扱い
 * 
 * @author kurinami
 * @edit katsuno
 */
public class SetCharacterEncodingFilterForMobile implements Filter {

	/** デフォルトの文字コード */
	private String encoding = "";

	/** モバイル用の文字コード */
	private String mobileEncoding = "";
	
	/** 置換対象ContentTypeリスト */
	private List targetContentTypes = null;
	
	/** metaタグcontent指定の置換 */
	private String metaContent = "";

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(SetCharacterEncodingFilterForMobile.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

		log.debug("init SetCharacterEncodingFilterForMobile start.");

		try {
			
			targetContentTypes = new ArrayList();
			
			// initParameterを一つずつ確認する。
			Enumeration initParamNames = filterConfig.getInitParameterNames();
			while (initParamNames.hasMoreElements()) {
				String name = (String) initParamNames.nextElement();
				String value = ValueUtil.nullToStr(filterConfig.getInitParameter(name));
				
				// デフォルトの文字エンコーディングを設定する。
				if(name.equalsIgnoreCase("encoding")) {
					encoding = value;
					continue;
				}
				
				// 携帯用のエンコーディングを設定する。
				if(name.equalsIgnoreCase("mobileEncoding")) {
					mobileEncoding = value;
					continue;
				}
				
				// 置換対象となるContentTypeのリストを設定する。
				if(name.startsWith("targetContentType")) {
					targetContentTypes.add(value);
					continue;
				}
				
				// metaタグ内content指定の置換設定
				if(name.equalsIgnoreCase("metaContent")) {
					metaContent = value;
				}
				
			}
			
			// デフォルトの文字エンコーディングが設定されていない場合はException発生。
			if (encoding.length() == 0) {
				throw new Exception(
						"init parameter 'encoding' is not set");
			}
			
			

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			throw new ServletException(e);
		}

		log.debug("init SetCharacterEncodingFilterForMobile end.");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		log.debug("doFilter SetCharacterEncodingFilterForMobile start.");

		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;

		String ua = ValueUtil.nullToStr(httpServletRequest.getHeader("user-agent"));

		// UAがなかったらエラー画面へ遷移する。
		if (ua.length() == 0) {
			log.info("User-Agentが指定されていないリクエストです。");
			httpServletResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
			return;
		}

		if (TermMstDb.isMobileUa(ua) && mobileEncoding.length() > 0) {
			// モバイルからのリクエストでモバイル用の文字コードが指定されていた場合、

			// 入力パラメータのエンコーディングの設定をmobile用にする。
			request.setCharacterEncoding(mobileEncoding);

			CustomHttpServletResponse customHttpServletResponse = new CustomHttpServletResponse(
					httpServletResponse, encoding);

			chain.doFilter(httpServletRequest, customHttpServletResponse);

			try {
				// HTTPヘッダーコンテンツタイプの取得
				String httpHeaderContentType = ValueUtil.nullToStr(customHttpServletResponse.getContentType());
				
				log.debug("uri         : " + httpServletRequest.getRequestURI());
				log.debug("content-type: " + httpHeaderContentType);

				byte[] buf;
				
				if(httpHeaderContentType.length() == 0
				|| httpHeaderContentType.toLowerCase().startsWith("text/html")
				|| httpHeaderContentType.toLowerCase().startsWith("application/xhtml+xml")
				|| targetContentTypes.contains(httpHeaderContentType)) {
					
					// レスポンスがテキストデータの場合、
					log.debug("レスポンスを置換対象ContentTypeと判定し置換処理開始");

					// キャッシュしていたhtmlを取得する。
					String resultHtml = customHttpServletResponse.getHtml();
					
					// meta内のcharsetを置換する。
					resultHtml = replaceMetaCharset(resultHtml, httpHeaderContentType);

					// mobile用のcharsetでバイトデータにする。
					buf = resultHtml.getBytes(mobileEncoding);

					// レスポンスのcharsetを指定する。
					response.setCharacterEncoding(mobileEncoding);

				} else {
					// レスポンスがテキストデータ以外の場合、
					log.debug("レスポンスを置換対象以外のContentTypeと判定し置換処理をスキップ");

					// 置換は行なわない。
					buf = customHttpServletResponse.getByte();
				}

				// リダイレクトをチェックする。
				String location = customHttpServletResponse.getLocation();
				if (location != null) {
					httpServletResponse.sendRedirect(location);
				}

				// ContentLengthを設定する。
				httpServletResponse.setContentLength(buf.length);

				// 置換した結果を本来のstreamに出力する。
				ServletOutputStream sos = httpServletResponse.getOutputStream();
				sos.write(buf);
				sos.close();

			} catch (Exception e) {
				log.error("予期せぬエラー", e);
				httpServletResponse
						.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			}

		} else {
			// PCからのリクエストか、モバイル用の文字コードが指定されていない場合、

			// 入力パラメータのエンコーディングの設定だけする。
			request.setCharacterEncoding(encoding);

			chain.doFilter(request, response);
		}

		log.debug("doFilter SetCharacterEncodingFilterForMobile end.");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// 処理なし
	}

	/**
	 * meta内のcontent指定とcharset指定を変更する。
	 * 
	 * @param sourceHtml
	 * @return 置換後のhtml文字列
	 */
	private String replaceMetaCharset(String sourceHtml, String httpHeaderContentType) {
		
		String replacedHtml = "";

		Pattern pattern = Pattern.compile("\\s*<meta\\s+http-equiv\\s*=\\s*[\'\"]?content-type[\'\"]?\\s+content\\s*=[^>]*>", Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(sourceHtml);
		
		//何故かフェニックスになってcontentTypeに「text/html;charset=UTF-8」のようにcharsetが付いてくるようになったので削除
		int index = httpHeaderContentType.indexOf(";");
		if (index != -1) {
		    httpHeaderContentType = httpHeaderContentType.substring(0, index);
		}
		
		if(metaContent.equalsIgnoreCase("http_header") || metaContent.equals("")) {
			// content(HTTPヘッダ設定されているcontentType) と charset を置換する
			replacedHtml = matcher.replaceAll("<meta http-equiv=\"Content-Type\" content=\"" + httpHeaderContentType + "; charset=" + mobileEncoding + "\" />");
			
		} else if(metaContent.equalsIgnoreCase("not_modify")) {
			// charset設定のみ置換する
			
			// まずは置換後のmetaタグ文字列を作成する
			// 置換前metaタグ文字列の取得
			String metaStr = "";
			while(matcher.find()) {
				metaStr = matcher.group();
				break;
			}
			
			// charset指定部分を置換するためのMatcherを作成
			Pattern charset_pattern = Pattern.compile("charset\\s*=[^\\s\"\';]*", Pattern.CASE_INSENSITIVE);
			Matcher charset_matcher = charset_pattern.matcher(metaStr);
						
			// metaタグのcharset部分を置換
			String replacedMetaStr = charset_matcher.replaceAll("charset=" + mobileEncoding);
			
			// 置換されたmetaタグ文字列に置換する
			replacedHtml = matcher.replaceAll(replacedMetaStr);
			
		} else {
			// contentTypeが直指定されていた場合
			replacedHtml = matcher.replaceAll("<meta http-equiv=\"Content-Type\" content=\"" + metaContent + "; charset=" + mobileEncoding + "\" />");
		}

		return replacedHtml;
	}
}