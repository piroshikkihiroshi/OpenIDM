﻿Imports WHandleTool.DeclareCs
Imports System.Text 'stringbuilder用
Imports System.Management
Imports NPOI.SS.UserModel
Imports NPOI.XSSF.UserModel
Imports System.IO
Imports NPOI.HSSF.UserModel


Public Class commonFunc

    Function getExcelObj(ByVal fileName_i As String, ByVal sheetName_i As String) As HSSFSheet
        Dim stCurrentDir As String = System.IO.Directory.GetCurrentDirectory()
        Dim filePath As String = stCurrentDir + "\" + fileName_i

        Dim stRow As Long = ST_ROW
        Dim stClm As Long = ST_CLM

        Dim tgtSh As HSSFSheet

        getExcelObj = Nothing

        Using fs As New FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
            Dim book As HSSFWorkbook


            book = New HSSFWorkbook(fs)

            'シート数を取得
            Dim sheetCount = book.NumberOfSheets
            For i = 0 To sheetCount - 1
                Dim sht = book.GetSheetAt(i)
                If sht.SheetName = sheetName_i Then
                    tgtSh = sht
                    Exit For
                End If

            Next i

            ''Diagnostics.Debug.WriteLine("----- End -----")
        End Using

        getExcelObj = tgtSh


    End Function

    Function imporIni() As Integer
        Const DEF_STR As String = vbNullString
        Dim buffer As String = New String(" ", 1024) 'Spaceが1024文字
        Dim iniFileName As String = Application.StartupPath & "\" & INI_FILE 'INIファイル名
        Dim ret As Integer

        ret = GetPrivateProfileString( _
           "EXCEL_SETTING", "TGT_BOOK_NAME", DEF_STR, buffer, buffer.Length, iniFileName _
           )
        TGT_BOOK_NAME = buffer.Substring(0, buffer.IndexOf(vbNullChar))

        ret = GetPrivateProfileString( _
           "EXCEL_SETTING", "TGT_SHEET_NAME", DEF_STR, buffer, buffer.Length, iniFileName _
           )
        TGT_SHEET_NAME = buffer.Substring(0, buffer.IndexOf(vbNullChar))

        'ret = GetPrivateProfileString( _
        '   "DB_SETTING", "TGT_USER", DEF_STR, buffer, buffer.Length, iniFileName _
        '   )
        'TGT_USER = buffer.Substring(0, buffer.IndexOf(vbNullChar))

        'ret = GetPrivateProfileString( _
        '   "DB_SETTING", "TGT_PASS", DEF_STR, buffer, buffer.Length, iniFileName _
        '   )
        'TGT_PASS = buffer.Substring(0, buffer.IndexOf(vbNullChar))

        imporIni = 0

    End Function




    Function tgtDirGet() As String
        ' FolderBrowserDialog の新しいインスタンスを生成する (デザイナから追加している場合は必要ない)
        Dim FolderBrowserDialog1 As New FolderBrowserDialog()

        ' ダイアログの説明を設定する
        FolderBrowserDialog1.Description = "Excelファイルを出力するフォルダを選択してください。"

        ' ルートになる特殊フォルダを設定する (初期値 SpecialFolder.Desktop)
        'FolderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.MyComputer
        FolderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.Desktop

        ' 初期選択するパスを設定する
        'FolderBrowserDialog1.SelectedPath = "C:\Windows\"
        FolderBrowserDialog1.SelectedPath = System.Environment.SpecialFolder.Desktop

        ' [新しいフォルダ] ボタンを表示する (初期値 True)
        FolderBrowserDialog1.ShowNewFolderButton = True

        ' ダイアログを表示し、戻り値が [OK] の場合は、選択したディレクトリを表示する
        If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then

            tgtDirGet = FolderBrowserDialog1.SelectedPath
        Else
            tgtDirGet = ""
        End If

        'C直下対応
        If tgtDirGet = "C:\" Then
            tgtDirGet = "C:"
        End If

        ' 不要になった時点で破棄する (正しくは オブジェクトの破棄を保証する を参照)
        FolderBrowserDialog1.Dispose()

    End Function


    Function IsNumeric(ByVal stTarget As String) As Boolean
        Return Double.TryParse( _
            stTarget, _
            System.Globalization.NumberStyles.Any,
            Nothing, _
            0.0# _
        )
    End Function


    '20170502

    Function hwndAct(ByRef tgtData_i) As Long
        Dim ret As Long
        Dim tmpVal As Object
        Dim tmpVal2 As Object
        Dim splitArr As Object
        Dim loopIdx As Long
        Dim objJson As Object
        Dim colJson As Collection
        ret = 0
        hwndAct = 0



        glTgtStr = tgtData_i.tgtVal

        Select Case tgtData_i.tgtStatus
            Case Is = 100
                '0,初期処理 トップから探して最大化する
                ret = EnumChildWindows(0, AddressOf getHndlByText, 0)

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                'ウィンドウが最小化されていれば元に戻す
                If IsIconic(glTgtHwnd) Then
                    ret = ShowWindowAsync(glTgtHwnd, SW_RESTORE)
                End If
                ret = SetForegroundWindow(glTgtHwnd) '画面を全面にする
                ret = ShowWindowAsync(glTgtHwnd, SW_MAXIMIZE) '画面を最大化にする


            Case 101
                '1,トップから探してクリックする
                ret = EnumChildWindows(0, AddressOf getHndlByText, 0)

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                'ボタンをクリック
                ret = SendMessageTimeout(glTgtHwnd, WM_ACTIVATE, 1, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)
                ret = SendMessageTimeout(glTgtHwnd, BM_CLICK, 0, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)


            Case 102
                'ウィンドウハンドルから探してクリックする

                ret = EnumChildWindows(glTgtHwnd, AddressOf getHndlByText, 0)

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                'ボタンをクリック
                ret = SendMessageTimeout(glTgtHwnd, WM_ACTIVATE, 1, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)
                ret = SendMessageTimeout(glTgtHwnd, BM_CLICK, 0, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)

            Case 200
                '0,初期処理 トップから探して最大化する
                ret = EnumChildWindows(0, AddressOf getHndlByClass, 0)

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                'ウィンドウが最小化されていれば元に戻す
                If IsIconic(glTgtHwnd) Then
                    ret = ShowWindowAsync(glTgtHwnd, SW_RESTORE)
                End If
                ret = SetForegroundWindow(glTgtHwnd) '画面を全面にする
                ret = ShowWindowAsync(glTgtHwnd, SW_MAXIMIZE) '画面を最大化にする

            Case 201
                'トップから値のを探してクリックする(クラス名部分一致)
                ret = EnumChildWindows(0, AddressOf getHndlByClass, 0)

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                'ボタンをクリック
                ret = SendMessageTimeout(glTgtHwnd, WM_ACTIVATE, 1, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)
                ret = SendMessageTimeout(glTgtHwnd, BM_CLICK, 0, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)


            Case 202
                '202,ウィンドウハンドルから探してクリックする(クラス名部分一致)
                ret = EnumChildWindows(glTgtHwnd, AddressOf getHndlByClass, 0)

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If


                'ボタンをクリック
                ret = SendMessageTimeout(glTgtHwnd, WM_ACTIVATE, 1, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)
                ret = SendMessageTimeout(glTgtHwnd, BM_CLICK, 0, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)


            Case 300
                '3,キーコード表を値に入れると、その仮想キーを送る
                ret = EnumChildWindows(glTgtHwnd, AddressOf getHndlByText, 0)

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                ret = SendMessageTimeout(glTgtHwnd, WM_ACTIVATE, 1, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)
                ret = PostMessage(glTgtHwnd, WM_KEYDOWN, tgtData_i.tgtVal, 0&) ' WM_KEYDOWN → WM_CHAR の変換をさせるため、PostMessageで送る
                System.Threading.Thread.Sleep(WAIT_TIME) 'postは非同期なので、WAIT_TIMEmsまつ
                '        ret = PostMessage(glTgtHwnd, WM_KEYUP, tgtData_i.tgtVal, 0&) ' WM_KEYDOWN → WM_CHAR の変換をさせるため、PostMessageで送る
                ''        System.Threading.Thread.Sleep WAIT_TIME 'postは非同期なので、WAIT_TIMEmsまつ



            Case 400
                '5,glTgtHwndに対して値を格納(setText)
                ret = SendMessageTimeout(glTgtHwnd, WM_SETTEXT, 0, CStr(tgtData_i.tgtVal), SMTO_ABORTIFHUNG, WAIT_TIME, 0&)



            Case 500
                'sendkeys 出来るだけ使わない
                SendKeys.SendWait(tgtData_i.tgtVal)
                System.Threading.Thread.Sleep(WAIT_TIME)

            Case 600
                'mouse_event click 出来るだけ使わない
                Dim arrXY As Object

                arrXY = Split(tgtData_i.tgtVal, ",")
                'arrXY(0):x arrXY(1):y

                Call mouse_event(MOUSE_MOVED Or MOUSEEVENTF_ABSOLUTE, arrXY(0), arrXY(1), 0, 0)
                System.Threading.Thread.Sleep(WAIT_TIME)
                Call mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                System.Threading.Thread.Sleep(WAIT_TIME)
                Call mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)


            Case 700
                'ウィンドウハンドルから値の(クラス名部分一致)を探してglHwndColに格納し、全てに値を格納する
                'json形式(エスケープはプログラム側)
                'キー：strName クラス名
                'キー：arrVal 配列 要素 strVal 送る値 カンマ区切りで複数

                objJson = getJson(tgtData_i.tgtVal)
                glTgtStr = objJson.strName

                glHwndCol = Nothing
                glHwndCol = New Collection
                glRet = -1
                ret = EnumChildWindows(glTgtHwnd, AddressOf getHndlByClassCol, 0)

                ret = glRet

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                'jsonの配列はforeach じゃないと取れないので いったんcolectionに格納
                colJson = New Collection
                For Each tmpVal In objJson.arrVal
                    colJson.Add(tmpVal.strVal)
                Next tmpVal

                loopIdx = 1
                For Each tmpVal In glHwndCol
                    'メッセージを格納
                    ret = SendMessageTimeout(tmpVal, WM_SETTEXT, 0, CStr(colJson(loopIdx)), SMTO_ABORTIFHUNG, WAIT_TIME, 0&)
                    loopIdx = loopIdx + 1
                Next tmpVal

                colJson = Nothing


            Case 701
                'ウィンドウハンドルから値の(クラス名部分一致)を探してglHwndColに格納し、コマンドを発行する
                'json形式(エスケープはプログラム側)
                'キー：strName クラス名
                'キー：arrVal 配列 要素 strVal 送るコマンド カンマ区切りで複数回コマンド発行

                objJson = getJson(tgtData_i.tgtVal)
                glTgtStr = objJson.strName

                glHwndCol = Nothing
                glHwndCol = New Collection
                glRet = -1
                ret = EnumChildWindows(glTgtHwnd, AddressOf getHndlByClassCol, 0)

                ret = glRet

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                'jsonの配列はforeach じゃないと取れないので いったんcolectionに格納
                colJson = New Collection
                For Each tmpVal In objJson.arrVal
                    colJson.Add(tmpVal.strVal)
                Next tmpVal

                loopIdx = 1
                For Each tmpVal In glHwndCol

                    'もしJSONの定義が足りなかったら、残りのハンドルには送らずforを抜ける
                    If loopIdx > colJson.Count Then
                        Exit For
                    End If


                    'コマンド送信
                    ret = SendMessageTimeout(tmpVal, WM_ACTIVATE, 1, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)

                    'カンマ区切りで複数コマンド送る
                    splitArr = Split(CStr(colJson(loopIdx)), ",")

                    For Each tmpVal2 In splitArr
                        ret = PostMessage(CStr(tmpVal), WM_KEYDOWN, CStr(tmpVal2), 0&) ' WM_KEYDOWN → WM_CHAR の変換をさせるため、PostMessageで送る
                        System.Threading.Thread.Sleep(WAIT_TIME) 'postは非同期なので、WAIT_TIMEmsまつ
                    Next tmpVal2


                    loopIdx = loopIdx + 1
                Next tmpVal

                colJson = Nothing


            Case 702
                'ウィンドウハンドルから値の(クラス名部分一致)を探してglHwndColに格納し、コマンドを発行する(高速版)
                'json形式(エスケープはプログラム側)
                'キー：strName クラス名
                'キー：arrVal 配列 要素 strVal 送るコマンド カンマ区切りで複数回コマンド発行

                objJson = getJson(tgtData_i.tgtVal)
                glTgtStr = objJson.strName

                glHwndCol = Nothing
                glHwndCol = New Collection
                glRet = -1
                ret = EnumChildWindows(glTgtHwnd, AddressOf getHndlByClassCol, 0)

                ret = glRet

                '結果チェック
                If ret <> 0 Then
                    hwndAct = -1
                    Exit Function
                Else
                    hwndAct = 0
                End If

                'jsonの配列はforeach じゃないと取れないので いったんcolectionに格納
                colJson = New Collection
                For Each tmpVal In objJson.arrVal
                    colJson.Add(tmpVal.strVal)
                Next tmpVal

                loopIdx = 1
                For Each tmpVal In glHwndCol

                    'もしJSONの定義が足りなかったら、残りのハンドルには送らずforを抜ける
                    If loopIdx > colJson.Count Then
                        Exit For
                    End If


                    'コマンド送信
                    ret = SendMessageTimeout(CLng(tmpVal), WM_ACTIVATE, 1, 0&, SMTO_ABORTIFHUNG, WAIT_TIME, 0&)

                    'カンマ区切りで複数コマンド送る
                    splitArr = Split(CStr(colJson(loopIdx)), ",")

                    For Each tmpVal2 In splitArr
                        ret = PostMessage(CStr(tmpVal), WM_KEYDOWN, CStr(tmpVal2), 0&) ' WM_KEYDOWN → WM_CHAR の変換をさせるため、PostMessageで送る
                        System.Threading.Thread.Sleep(WAIT_MIN_TIME) 'postは非同期なので、WAIT_TIMEmsまつ
                    Next tmpVal2


                    loopIdx = loopIdx + 1
                Next tmpVal

                colJson = Nothing



        End Select


    End Function



    '-------------------------------------------------
    '■関数名　　　EnumWindowCallBack
    '■用途　　　　全てのWindow列挙関数
    '■引数　　　　hWnd：親ウインドウのハンドル,0なら親がない奴全て
    '-------------------------------------------------

    Function EnumWindowCallBack(ByVal hwnd As IntPtr, ByVal lParam As Long) As Long


        'ウィンドウのタイトルを取得する
        Dim tsb As New StringBuilder(256)
        GetWindowText(hwnd, tsb, tsb.Capacity)

        'ウィンドウのクラス名を取得する
        Dim csb As New StringBuilder(256)
        GetClassName(hwnd, csb, csb.Capacity)

        glLoopIdx = glLoopIdx + 1

        '結果を表示する
        Debug.Print("クラス名:" & csb.ToString())
        Debug.Print("タイトル:" & tsb.ToString())

        EnumWindowCallBack = -1

    End Function



    '-------------------------------------------------
    '■関数名　　　getHndlByText
    '■用途　　　　グローバル変数「glTgtStr」に格納された値と、Windowハンドルに対するテキストが部分一致したらグローバル変数「glTgtHwnd」にWindowハンドルを格納する
    '■引数　　　　hWnd：親ウインドウのハンドル,0なら親がない奴全て
    '-------------------------------------------------

    Function getHndlByText(ByVal hwnd As Long, ByVal lParam As Long) As Long

        Dim ret As Long

        Dim strName As String
        Dim strClass As String

        'ウィンドウのタイトルの長さを取得する
        Dim textLen As Integer = GetWindowTextLength(hwnd)
        'If 0 < textLen Then

        'ウィンドウのタイトルを取得する
        Dim tsb As New StringBuilder(256)
        ret = GetWindowText(hwnd, tsb, tsb.Capacity)

        'ウィンドウのクラス名を取得する
        Dim csb As New StringBuilder(256)
        ret = GetClassName(hwnd, csb, csb.Capacity)


        strName = tsb.ToString()
        strClass = csb.ToString()
        '結果を表示する
        Debug.Print("タイトル:" & tsb.ToString())
        Debug.Print("クラス名:" & csb.ToString())



        'strName = Left(tsb.ToString(), InStr(1, tsb.ToString(), Chr(0)) - 1)
        'strClass = Left(csb.ToString(), InStr(1, csb.ToString(), Chr(0)) - 1)

        If InStr(1, strName, glTgtStr) > 0 Then
            glTgtHwnd = hwnd
            getHndlByText = 0
            Exit Function
        End If

        'End If

        getHndlByText = -1

    End Function



    '-------------------------------------------------
    '■関数名　　　getHndlByClass
    '■用途　　　　グローバル変数「glTgtStr」に格納された値と、Windowハンドルに対するクラス名が部分一致したらグローバル変数「glTgtHwnd」にWindowハンドルを格納する
    '■引数　　　　hWnd：親ウインドウのハンドル,0なら親がない奴全て
    '-------------------------------------------------

    Function getHndlByClass(ByVal hwnd As Long, ByVal lParam As Long) As Long

        Dim ret As Long

        Dim strName As String
        Dim strClass As String

        'ウィンドウのタイトルの長さを取得する
        Dim textLen As Integer = GetWindowTextLength(hwnd)
        'If 0 < textLen Then



        'ウィンドウのタイトルを取得する
        Dim tsb As New StringBuilder(256)
        ret = GetWindowText(hwnd, tsb, tsb.Capacity)

        'ウィンドウのクラス名を取得する
        Dim csb As New StringBuilder(256)
        ret = GetClassName(hwnd, csb, csb.Capacity)


        strName = tsb.ToString()
        strClass = csb.ToString()
        '結果を表示する
        Debug.Print("タイトル:" & tsb.ToString())
        Debug.Print("クラス名:" & csb.ToString())

        If InStr(1, strClass, glTgtStr) > 0 Then
            glTgtHwnd = hwnd
            getHndlByClass = 0
            Exit Function
        End If
        'End If

        getHndlByClass = -1

    End Function



    '-------------------------------------------------
    '■関数名　　　getHndlByClassCol
    '■用途　　　　グローバル変数「glTgtStr」に格納された値と、Windowハンドルに対するクラス名が部分一致したらグローバル変数「glHwndCol」にWindowハンドルを追記していく
    '■引数　　　　hWnd：親ウインドウのハンドル,0なら親がない奴全て
    '-------------------------------------------------

    Function getHndlByClassCol(ByVal hwnd As Long, ByVal lParam As Long) As Long

        Dim ret As Long

        Dim strName As String
        Dim strClass As String

        'ウィンドウのタイトルの長さを取得する
        Dim textLen As Integer = GetWindowTextLength(hwnd)


        'ウィンドウのタイトルを取得する
        Dim tsb As New StringBuilder(256)
        ret = GetWindowText(hwnd, tsb, tsb.Capacity)

        'ウィンドウのクラス名を取得する
        Dim csb As New StringBuilder(256)
        ret = GetClassName(hwnd, csb, csb.Capacity)


        strName = tsb.ToString()
        strClass = csb.ToString()
        '結果を表示する
        Debug.Print("タイトル:" & tsb.ToString())
        Debug.Print("クラス名:" & csb.ToString())

        If InStr(1, strClass, glTgtStr) > 0 Then
            glHwndCol.Add(hwnd)
            glRet = 0
        End If

        getHndlByClassCol = -1

    End Function




    Private Function PostMessageA(ByVal hwd As Long, ByVal msg As Long, ByVal wpara As Long, ByVal lpara As Long) As Long
        Throw New NotImplementedException
    End Function


    Function getJson(ByVal strJson_i) As Object
        Dim objSC = CreateObject("ScriptControl") 'Script Control
        Dim strFunc As String '関数文字列

        Dim strJSON As String 'JSONデータ(文字列)
        Dim objJson As Object

        objSC.Language = "JScript"
        strFunc = "function jsonParse(s) { return eval('(' + s + ')'); }"
        objSC.AddCode(strFunc)

        'エスケープ処理
        strJSON = Replace(strJson_i, "\", "\\")
        objJson = objSC.CodeObject.jsonParse(strJSON)

        getJson = objJson
    End Function









End Class
