﻿Imports System.Text 'stringbuilder用
Imports CRMForm.DeclareCs
Imports CRMForm.commonFunc
Imports CRMForm.sqlMng

Public Class SearchMainForm

    'Public Sub optionPaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optionPaste.Click

    '    Dim objCmFn As New commonFunc
    '    Dim tmpAry As Object

    '    tmpAry = Split(optionText.Text, vbCrLf)
    '    Call objCmFn.copyMain(tmpAry, 1)


    'End Sub


    'Public Sub historyPaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles historyPaste.Click
    '    Dim objCmFn As New commonFunc
    '    Dim tmpAry As Object

    '    tmpAry = Split(optionText.Text, vbCrLf)
    '    Call objCmFn.copyMain(tmpAry, 2)
    'End Sub

    Private Sub mainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Dim objSqlFn As New sqlMng
        Dim objCmFn As New commonFunc
        Dim strSeverName As String
        Dim strDbName As String
        Dim strSqlCom As String
        Dim strCommboCom As String
        Dim loopIdx As Long


        Dim formLayout As New Collection
        Dim formLabel As New Collection
        Dim tgtX As Long
        Dim textX As Long
        Dim tgtY As Long

        Dim strName As String
        Dim strUserId As String
        Dim strPass As String

        Dim besicY As Long = 0
        Dim maxY As Long = 0
        Dim strGroupName As String = ""


        '設定ファイル読み込み

        objCmFn.imporIni()

        strSeverName = TGT_SERVER_NAME
        strDbName = TGT_DB
        strUserId = TGT_USER
        strPass = TGT_PASS

        'サーバに接続
        Dim objSqlCon As System.Data.SqlClient.SqlConnection = objSqlFn.sqlCon(strSeverName, strDbName, strUserId, strPass)

        'sql発行  顧客名暫定対応
        'strSqlCom = "select DISTINCT iKmkCd,cKmkNm,cGroupNm,iTabOrder,iCtrlType,iKkyakCardStartX,iKkyakCardStartY,iKkyakCardEndX,iKkyakCardEndY from [dbo].[KmkLayout] where (cGroupNm is not null) and (iHyj <> 0) and (cDispID = 'N010' ) AND cKmkNm <> '顧客コード' AND cKmkNm <> '個人・法人区分' AND cKmkNm <> '付箋１' AND cKmkNm <> '付箋２' AND cKmkNm <> '管理区分' AND cKmkNm <> '担当者名' AND cKmkNm <> 'イニシャルキーカナ' AND cKmkNm <> 'イニシャルキー英字' AND cGroupNm <> '' order by iTabOrder;"
        strSqlCom = "select DISTINCT iKmkCd,cKmkNm,cGroupNm,iTabOrder,iCtrlType,iKkyakCardStartX,iKkyakCardStartY,iKkyakCardEndX,iKkyakCardEndY from [dbo].[KmkLayout] where (cGroupNm is not null) and (iHyj <> 0) and (cDispID = 'N010' ) AND cKmkNm <> '顧客コード' AND cKmkNm <> '個人・法人区分' AND cKmkNm <> '付箋１' AND cKmkNm <> '付箋２' AND cKmkNm <> '担当者名' AND cKmkNm <> 'イニシャルキーカナ' AND cKmkNm <> 'イニシャルキー英字' AND cGroupNm <> '' AND cKmkNm <> '顧客名' order by iTabOrder;"
        Dim objLyaoutData As Object = objSqlFn.sqlQuery(objSqlCon, strSqlCom)

        'フォームのレイアウトロジックを中断する
        Me.SuspendLayout()

        Me.AcceptButton = Me.SerachBtn  ' エンターで検索
        Me.Size = New Point(glDispWidth - 70, glDispHeight - 70)    'フォームのサイズ(ディスプレイサイズから計算)

        loopIdx = 1

        glHdInfoDic = New Dictionary(Of String, String)

        ' 次のレコードに進める (次のレコードがない場合は False になるため実行されない)
        While (objLyaoutData.Read())
            strName = ""

            If (loopIdx <> 1) And (strGroupName <> objLyaoutData("cGroupNm").ToString()) Then
                besicY = besicY + maxY + 50
            End If

            strGroupName = objLyaoutData("cGroupNm").ToString()



            If objLyaoutData("cGroupNm").ToString() <> "" Then

                If objLyaoutData("iCtrlType").ToString() = "6" Then 'iCtrlType = 6 はプルダウン
                    formLayout.Add(New ComboBox)
                Else
                    formLayout.Add(New TextBox)
                End If


                formLabel.Add(New Label)

                If Not glHdInfoDic.ContainsKey(objLyaoutData("iKmkCd").ToString()) Then

                    'iCtrlType = 1 は文字 iCtrlType = 8 は郵便番号
                    If objLyaoutData("iCtrlType").ToString() = "1" Or objLyaoutData("iCtrlType").ToString() = "8" Then
                        strName = "cMoji" & objLyaoutData("iKmkCd").ToString()
                        If Not glHdInfoDic.ContainsKey(strName) Then
                            glHdInfoDic.Add(strName, objLyaoutData("cKmkNm").ToString())
                        End If

                        'iCtrlType = 4 は数値
                    ElseIf objLyaoutData("iCtrlType").ToString() = "4" Then

                        strName = "mSuuti" & objLyaoutData("iKmkCd").ToString()
                        If Not glHdInfoDic.ContainsKey(strName) Then
                            glHdInfoDic.Add(strName, objLyaoutData("cKmkNm").ToString())

                            '通常数値フラグ
                            gliCtrlTypeDic.Add(strName, objLyaoutData("iCtrlType").ToString())

                        End If
                        'iCtrlType = 6 はプルダウン
                    ElseIf objLyaoutData("iCtrlType").ToString() = "6" Then
                        strName = "mSuuti" & objLyaoutData("iKmkCd").ToString()
                        If Not glHdInfoDic.ContainsKey(strName) Then

                            '通常数値フラグ
                            gliCtrlTypeDic.Add(strName, objLyaoutData("iCtrlType").ToString())

                            'コンボボックスの項目を取得
                            strCommboCom = "select iKmkCd,cKmkNm,iKoteiKbnCd from [dbo].[KmkLayout] where iKmkCd = " & objLyaoutData("iKmkCd").ToString() & " AND cKmkNm <> '" & objLyaoutData("cKmkNm").ToString() & "' ORDER BY iKoteiKbnCd;"
                            Dim objSqlCommboCon As System.Data.SqlClient.SqlConnection = objSqlFn.sqlCon(strSeverName, strDbName, strUserId, strPass)
                            Dim objCommboDatas As Object = objSqlFn.sqlQuery(objSqlCommboCon, strCommboCom)
                            Dim tmpDic As New Dictionary(Of String, String)

                            While (objCommboDatas.Read())
                                formLayout(loopIdx).Items.Add(objCommboDatas("cKmkNm").ToString())
                                tmpDic.Add(objCommboDatas("iKoteiKbnCd").ToString(), objCommboDatas("cKmkNm").ToString())

                            End While

                            glComboDic.Add(strName, tmpDic)

                            glHdInfoDic.Add(strName, objLyaoutData("cKmkNm").ToString())
                            tmpDic = Nothing
                            objSqlCommboCon = Nothing
                            objCommboDatas = Nothing
                        End If
                    End If



                End If


                Dim textLenIdx As Long

                textLenIdx = CLng(objLyaoutData("iKkyakCardEndX").ToString()) / CLng(objLyaoutData("iKkyakCardStartX").ToString())

                If textLenIdx = 1 Then
                    textX = 100
                ElseIf textLenIdx = 2 Then
                    textX = 200
                Else
                    textX = 300
                End If

                formLabel(loopIdx).text = objLyaoutData("cKmkNm").ToString()
                tgtX = CLng(objLyaoutData("iKkyakCardEndX").ToString()) * 400 + (CLng(objLyaoutData("iKkyakCardEndX").ToString()) / CLng(objLyaoutData("iKkyakCardStartX").ToString()))
                tgtY = CLng(objLyaoutData("iKkyakCardEndY").ToString()) * 33 + (CLng(objLyaoutData("iKkyakCardEndY").ToString()) / CLng(objLyaoutData("iKkyakCardStartY").ToString()))
                formLabel(loopIdx).Location = New Point(tgtX - 390, tgtY + besicY)
                formLayout(loopIdx).Location = New Point(tgtX - 220, tgtY + besicY)


                formLabel(loopIdx).size = New Point(120, 20)
                formLayout(loopIdx).size = New Point(textX, tgtY + besicY)

                If tgtY > maxY Then
                    maxY = tgtY
                End If

                If strName <> "" Then formLayout(loopIdx).Name = strName

                Me.Controls.Add(formLabel(loopIdx))
                Me.Controls.Add(formLayout(loopIdx))
                loopIdx = loopIdx + 1


            End If

        End While

        'SQLを作成しておく
        Dim strInfoSchSql As String

        Dim DicTableName As New Dictionary(Of String, String)

        'テーブル定義取得
        strInfoSchSql = "SELECT   TABLE_NAME,   COLUMN_NAME,   DATA_TYPE,   COLUMN_DEFAULT FROM   INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME <> 'Kkyak' AND TABLE_NAME <> 'KkyakKmk' AND COLUMN_NAME <> 'iKkyakEDPNo' AND TABLE_NAME LIKE 'Kkyak%'  AND ( COLUMN_NAME IN ( 'iKkyakEDPNo', 'cKkyakCd' ) OR COLUMN_NAME LIKE 'cMoji%' OR COLUMN_NAME LIKE 'mSuuti%' ) ORDER BY   TABLE_NAME, ORDINAL_POSITION;"
        Dim objInfoSchCon As System.Data.SqlClient.SqlConnection = objSqlFn.sqlCon(strSeverName, strDbName, strUserId, strPass)
        Dim objInfoSchDatas As Object = objSqlFn.sqlQuery(objInfoSchCon, strInfoSchSql)
        glSqlCom = "SELECT [dbo].[Kkyak].cKkyakCd AS 顧客コード , "

        '顧客名暫定対応
        glSqlCom = glSqlCom & " [dbo].[Kkyak_Kmk01].cMoji40011 AS 顧客名 , "

        While (objInfoSchDatas.Read())
            '初めて出るテーブルなら格納
            If Not DicTableName.ContainsKey(objInfoSchDatas("TABLE_NAME").ToString()) Then
                DicTableName.Add(objInfoSchDatas("TABLE_NAME").ToString(), "")
            End If
            For Each tmpVal In glHdInfoDic
                If tmpVal.Key = objInfoSchDatas("COLUMN_NAME").ToString() Then

                    Dim suuchiStatus As Integer = 0

                    If InStr(tmpVal.Key, "mSuuti") > 0 Then

                        'gliCtrlTypeDic
                        For Each checkTmpVal In gliCtrlTypeDic
                            If checkTmpVal.Key = tmpVal.Key Then
                                If checkTmpVal.Value = 4 Then   '4は通常数値
                                    '20170331 数値丸める対応
                                    'glSqlCom = glSqlCom & "[dbo].[" & objInfoSchDatas("TABLE_NAME").ToString() & "]." & tmpVal.Key & " AS " & """" & tmpVal.Value & """" & " , "
                                    glSqlCom = glSqlCom & "CAST([dbo].[" & objInfoSchDatas("TABLE_NAME").ToString() & "]." & tmpVal.Key & " AS int) AS " & """" & tmpVal.Value & """" & " , "
                                    Exit For
                                Else
                                    For Each tmpVal2 In glComboDic
                                        If tmpVal2.Key = tmpVal.Key Then
                                            glSqlCom = glSqlCom & " CASE "
                                            For Each tmpVal3 In tmpVal2.Value
                                                glSqlCom = glSqlCom & " WHEN [dbo].[" & objInfoSchDatas("TABLE_NAME").ToString() & "]." & tmpVal.Key & " = " & tmpVal3.Key & " THEN '" & tmpVal3.value & "' "
                                            Next tmpVal3
                                            glSqlCom = glSqlCom & " WHEN [dbo].[" & objInfoSchDatas("TABLE_NAME").ToString() & "]." & tmpVal.Key & " = 0 THEN '未設定' END AS " & """" & tmpVal.Value & """" & " , "
                                            Exit For
                                        End If

                                    Next tmpVal2

                                    Exit For
                                End If

                            End If


                        Next checkTmpVal


                        'For Each tmpVal2 In glComboDic
                        '    If tmpVal2.Key = tmpVal.Key Then
                        '        glSqlCom = glSqlCom & " CASE "
                        '        For Each tmpVal3 In tmpVal2.Value
                        '            glSqlCom = glSqlCom & " WHEN [dbo].[" & objInfoSchDatas("TABLE_NAME").ToString() & "]." & tmpVal.Key & " = " & tmpVal3.Key & " THEN '" & tmpVal3.value & "' "
                        '        Next tmpVal3
                        '        glSqlCom = glSqlCom & " WHEN [dbo].[" & objInfoSchDatas("TABLE_NAME").ToString() & "]." & tmpVal.Key & " = 0 THEN '未設定' END AS " & """" & tmpVal.Value & """" & " , "
                        '        Exit For
                        '    End If

                        'Next tmpVal2

                    Else
                        glSqlCom = glSqlCom & "[dbo].[" & objInfoSchDatas("TABLE_NAME").ToString() & "]." & tmpVal.Key & " AS " & """" & tmpVal.Value & """" & " , "
                    End If
                End If
            Next tmpVal

        End While

        'JOIN句の作成
        glSqlCom = glSqlCom.Remove(glSqlCom.Length - 2, 2)

        glSqlCom = glSqlCom & " FROM  [dbo].[Kkyak] "

        For Each tmpVal In DicTableName
            glSqlCom = glSqlCom & " LEFT OUTER JOIN [dbo].[" & tmpVal.Key & "] "
            glSqlCom = glSqlCom & " ON [dbo].[Kkyak].iKkyakEDPNo = [dbo].[" & tmpVal.Key & "].iKkyakEDPNo "

        Next tmpVal

        Me.AutoScroll = True
        Me.Location = New Point(10, 10)
        Me.SerachBtn.Location = New Point(1200, 10)
        Me.clearBtn.Location = New Point(1200, 50)

        'フォームのレイアウトロジックを再開する
        Me.ResumeLayout(False)
    End Sub

    Private Sub SerachBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SerachBtn.Click
        'SearchFormクラスのインスタンスを作成する
        Dim f As New SearchForm()
        'SearchFormを表示する
        'ここではモーダルダイアログボックスとして表示する
        'オーナーウィンドウにMeを指定する
        '20170328 モーダルからモードレスウィンドウへ変更
        'f.ShowDialog(Me)
        f.Show(Me)

        'フォームが必要なくなったところで、Disposeを呼び出す
        'f.Dispose()
    End Sub


    Private Sub clearBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearBtn.Click



        For Each tmpCnt In Me.Controls
            If TypeOf tmpCnt Is TextBox Then 'テキストボックスの処理
                CType(tmpCnt, TextBox).Text = ""
            ElseIf TypeOf tmpCnt Is ComboBox Then
                tmpCnt.SelectedIndex = -1
            End If

        Next tmpCnt


    End Sub



End Class


