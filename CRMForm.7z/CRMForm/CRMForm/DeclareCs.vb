﻿'宣言クラス

Imports System.Runtime.InteropServices
Imports System.Diagnostics
Imports System.Text 'stringbuilder用
Public Class DeclareCs
    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function FindWindow(ByVal lpClassName As String, _
        ByVal lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll")> _
    Public Shared Function IsIconic(ByVal hWnd As IntPtr) As _
    <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("user32.dll")> _
    Public Shared Function ShowWindowAsync(ByVal hWnd As IntPtr, ByVal nCmdShow As Integer) As _
    <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("user32.dll")> _
    Public Shared Function SetForegroundWindow(ByVal hWnd As IntPtr) As _
    <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    Public Delegate Function EnumWindowsProc(ByVal hWnd As IntPtr, ByVal lParam As IntPtr) As Boolean

    <DllImport("user32.dll", CharSet:=CharSet.Auto)> _
    Public Shared Function EnumChildWindows(ByVal hWndParent As System.IntPtr, ByVal lpEnumFunc As EnumWindowsProc, ByVal lParam As Integer) As Boolean
    End Function


    'functionの宣言
    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function GetClassName(ByVal hWnd As IntPtr, _
        ByVal lpClassName As StringBuilder, ByVal nMaxCount As Integer) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function GetWindowText(ByVal hWnd As IntPtr, _
        ByVal lpString As StringBuilder, ByVal nMaxCount As Integer) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function GetWindowTextLength(ByVal hWnd As IntPtr) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function SendMessage( _
     ByVal hwnd As IntPtr, _
     ByVal wMsg As Integer, _
     ByVal wParam As Integer, _
     ByVal lParam As String _
   ) As Integer
    End Function

    Public Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" ( _
              ByVal lpApplicationName As String, _
              ByVal lpKeyName As String, _
              ByVal lpDefault As String, _
              ByVal lpReturnedString As String, _
              ByVal nSize As Integer, _
              ByVal lpFileName As String) As Integer

    'グローバル変数
    Public Shared glTgtClassTitle As String
    Public Shared glTgtHndl As IntPtr

    Public Shared glTLEDITCol As Collection

    Public Shared glHdInfoDic As Dictionary(Of String, String)
    Public Shared glComboDic As New Dictionary(Of String, Object)
    '通常数値かコンボボックスなどを見分ける
    Public Shared gliCtrlTypeDic As New Dictionary(Of String, String)

    Public Shared glSqlCom As String

    'ディスプレイの高さ
    Public Shared glDispHeight As Integer = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height
    'ディスプレイの幅
    Public Shared glDispWidth As Integer = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width


    '定数

    Public Const MAX_ROW = 50
    Public Const HISTORY_ST_ROW = 100


    Public Const WM_ACTIVATE = &H6
    Public Const WM_SETTEXT = &HC
    Public Const WM_KEYDOWN = &H100
    Public Const VK_RETURN = &HD   '   Enter

    Public Const SW_HIDE = 0                                       '' ウィンドウを非表示にし、他のウィンドウをアクティブにします。
    Public Const SW_MAXIMIZE = 3                                   '' ウィンドウを最大化します。
    Public Const SW_MINIMIZE = 6                                   '' ウィンドウを最小化し、Z 順位が次のトップレベルウィンドウをアクティブにします。
    Public Const SW_RESTORE = 9                                    '' ウィンドウをアクティブにし、表示します。ウィンドウが最小化されていたり最大化されていたりすると、元の位置とサイズに戻ります。
    Public Const SW_SHOW = 5                                       '' ウィンドウをアクティブにして、現在の位置とサイズで表示します。
    Public Const SW_SHOWDEFAULT = 10                               '' アプリケーションを起動させたプログラムが CreateProcess 関数に渡すSTARTUPINFO 構造体の wShowWindow メンバで指定された SW_ フラグを基にして、表示状態を設定します。
    Public Const SW_SHOWMAXIMIZED = 3                              '' ウィンドウをアクティブにして、最大化します。
    Public Const SW_SHOWMINIMIZED = 2                              '' ウィンドウをアクティブにして、最小化します。
    Public Const SW_SHOWMINNOACTIVE = 7                            '' ウィンドウを最小化します。アクティブなウィンドウは、アクティブな状態を維持します。非アクティブなウィンドウは、非アクティブなままです。
    Public Const SW_SHOWNA = 8                                     '' ウィンドウを現在の状態で表示します。アクティブなウィンドウはアクティブな状態を維持します。
    Public Const SW_SHOWNOACTIVATE = 4                             '' ウィンドウを直前の位置とサイズで表示します。アクティブなウィンドウはアクティブな状態を維持します。
    Public Const SW_SHOWNORMAL = 1                                 '' ウィンドウをアクティブにして、表示します。ウィンドウが最小化または最大化されているときは、位置とサイズを元に戻します。


    Public Const INI_FILE = "Setting.ini"

    '設定ファイルから取得するように変更
    Public Shared TGT_SERVER_NAME As String = ""
    Public Shared TGT_DB As String = ""
    Public Shared TGT_USER As String = ""
    Public Shared TGT_PASS As String = ""


End Class
