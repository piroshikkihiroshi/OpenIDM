package jp.co.webcrew.external.priority.proc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.common.mail.proc.CalculationSet;
import jp.co.webcrew.common.mail.proc.WildcardValue;

/**
 * External interface for the priority calculator
 * 
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: PriorityCalculator.java,v 1.8 2005-07-20 10:28:07 rickk Exp $
 */
public class PriorityCalculator {
	
	public static Integer applicationServerEvaluate(Connection connection,
			String rulesetXML, long companyId, long userId) throws SQLException, IOException {
	    return applicationServerEvaluate(connection, rulesetXML, 
	            makeInputXML(companyId, userId));
	}

    public static String makeInputXML(long companyId, long userId) {
        return "<in><parameter name=\"companyId\">" + companyId + "</parameter>" + 
            "<parameter name=\"customerId\">" + userId + "</parameter></in>";
    }

    public static Integer getPriorityValueFromOutput(Map wildcards) {
        WildcardValue wc = (WildcardValue) wildcards.get("priority");
        if ((wc != null) && (wc.getValue() != null)) {
            return new Integer(wc.getValue() + "");
        } else {
            return null;
        }
    }
    
	public static Integer applicationServerEvaluate(Connection connection,
			String rulesetXML, String inputXML) throws SQLException, IOException {
	    List wildcardRows = CalculationSet.applicationServerEvaluate(connection, 
                rulesetXML, inputXML);
        if (wildcardRows != null) {
            return getPriorityValueFromOutput(wildcardRows.isEmpty() ? new HashMap() : 
                (Map) wildcardRows.iterator().next());
        } else {
            return null;
        }
        
	}
//    
//	public static Integer dbServerEvaluate(Clob rulesetXML, 
//	        long companyId, long userId) throws SQLException, IOException {
//        CLOB clobInXML = CLOB.createTemporary(((CLOB) rulesetXML).getJavaSqlConnection(), false, CLOB.DURATION_SESSION);
//        clobInXML.setString(1,  makeInputXML(companyId, userId));
//        Clob clob = CalculationSet.dbServerEvaluate(rulesetXML, clobInXML);
//        Map wildcards = CalculationSet.populateOutputFromResultSet(rst);
//        return getPriorityValueFromOutput(wildcards);
//	}
	
	
}