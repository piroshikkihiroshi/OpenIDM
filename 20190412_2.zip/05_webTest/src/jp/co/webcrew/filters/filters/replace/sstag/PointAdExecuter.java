package jp.co.webcrew.filters.filters.replace.sstag;

import java.net.URLEncoder;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.filters.replace.PointAdDb;
import jp.co.webcrew.filters.util.PointAdUtil;
import jp.co.webcrew.filters.util.SessionFilterUtil;

/**
 * ポイント広告を表示するExecuterクラス。
 * 
 */
public class PointAdExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(PointAdExecuter.class);

	/** 広告種別：テキスト */
	private static final int TYPE_TEXT = 1;

	/** 広告種別：画像 */
	private static final int TYPE_IMAGE = 2;

	/** 広告種別：flash */
	private static final int TYPE_FLASH = 3;

	/** 広告種別：html */
	private static final int TYPE_HTML = 4;

	/** system_properties上のクリック履歴計測用のURL */
	private static final String POINT_AD_CLICK_LOG_URL_TEMPLATE = "POINT_AD_CLICK_LOG_URL_TEMPLATE";

  //--- ログインしている時の広告 -------------------------------
	/** テキスト用出力テンプレート */
	private static final String TEMPLATE_TEXT = "<a href=\"{0}\" target=\"_blank\">{1}</a>";

	/** 画像用出力テンプレート */
	private static final String TEMPLATE_IMAGE = "<a href=\"{0}\" target=\"_blank\"><img src=\"{1}\" {2} {3} alt=\"{4}\"></a>";

	/** 広告の下に表示するコメントテンプレート */
	private static final String TEMPLATE_SUB_TEXT = "<br /><a href=\"{0}\" target=\"_blank\">{1}</a>";
	
  //--- ログインしていない時の広告 -------------------------------
  /** テキスト用出力テンプレート */
  private static final String TEMPLATE_TEXT_NOT_LOGIN = "<a href=\"javascript:void(0)\" onmouseover=\"TagToTip({0}, BALLOON, true, WIDTH, 260, STICKY, true, CLICKCLOSE, true, PADDING, 8, TEXTALIGN, ''justify'', OFFSETX, -17, OPACITY, 95, DELAY, 0, FIX, [this, 0, 0])\" onclick=\"TagToTip({1}, BALLOON, true, WIDTH, 260, STICKY, true, CLICKCLOSE, true, PADDING, 8, TEXTALIGN, ''justify'', OFFSETX, -17, OPACITY, 95, DELAY, 0, FIX, [this, 0, 0])\" onmouseout=\"UnTip()\">{2}</a>";

  /** 画像用出力テンプレート */
  private static final String TEMPLATE_IMAGE_NOT_LOGIN = "<a href=\"javascript:void(0)\" onmouseover=\"TagToTip({0}, BALLOON, true, WIDTH, 260, STICKY, true, CLICKCLOSE, true, PADDING, 8, TEXTALIGN, ''justify'', OFFSETX, -17, OPACITY, 95, DELAY, 0, FIX, [this, 0, 0])\" onclick=\"TagToTip({1}, BALLOON, true, WIDTH, 260, STICKY, true, CLICKCLOSE, true, PADDING, 8, TEXTALIGN, ''justify'', OFFSETX, -17, OPACITY, 95, DELAY, 0, FIX, [this, 0, 0])\" onmouseout=\"UnTip()\"><img src=\"{2}\" {3} {4} alt=\"{5}\"></a>";

  private static final String NOT_LOGIN_MESSAGE  = "<span style=\"visibility: hidden\" id=\"{0}\">ズバットIDを取得後、ログインして広告をクリックするとポイントが貯まります。<br /><a href=\"/login/Member.jsp\"><font color=\"red\">[ズバットID取得（無料）はこちら]</font></a><br /><a href=\"/loginStart\">[ログインはこちら]</a><br /><a href=\"{1}\" target=\"_blank\">[広告を見る(ポイントは付きません)]</a></span>";
  private static final String SOFT_LOGIN_MESSAGE = "<span style=\"visibility: hidden\" id=\"{0}\">広告をクリックするにはログインが必要です。<br /><a href=\"/loginStart\">[ログインはこちら]</a><br /><a href=\"{1}\" target=\"_blank\">[広告を見る(ポイントは付きません)]</a></span>";
  
  /** 広告の下に表示するコメントテンプレート */
  private static final String TEMPLATE_SUB_TEXT_NOT_LOGIN = "<br /><a href=\"javascript:void(0)\" onmouseover=\"TagToTip({0}, BALLOON, true, WIDTH, 260, STICKY, true, CLICKCLOSE, true, PADDING, 8, TEXTALIGN, ''justify'', OFFSETX, -17, OPACITY, 95, DELAY, 0, FIX, [this, 0, 0])\" onclick=\"TagToTip({1}, BALLOON, true, WIDTH, 260, STICKY, true, CLICKCLOSE, true, PADDING, 8, TEXTALIGN, ''justify'', OFFSETX, -17, OPACITY, 95, DELAY, 0, FIX, [this, 0, 0])\" onmouseout=\"UnTip()\">{2}</a>";
  
  /** 同一日にクリックしていたときに表示するコメント */
  private static final String TODAY_CLICKED_MESSAGE = "<br /><em>本日はすでにクリックされています。</em>";
  
	/** インプレッションログ出力用スレッド */
	private static PointAdThread pointAdThread;
	
	static {
		// インプレッションログ出力スレッドを開始する。
    pointAdThread = new PointAdThread();
    pointAdThread.start();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {

		try {

			String spaceId = ValueUtil.nullToStr(parameterMap.get("space_id"));
			int siteId = SiteMstDb.getInstance().getSiteId(request.getRequestURL().toString());
			String codes = ValueUtil.nullToStr(parameterMap.get("codes"));
			int pageSpaceNum = ValueUtil.toint((String) parameterMap.get("page_space_num"));

			// 場所IDが指定されていない場合、
			if (spaceId.length() == 0 && codes.length() > 0) {
				// 場所IDを検索する。
				spaceId = ValueUtil.nullToStr(PointAdDb.getSpaceId(siteId, codes.split("/"), pageSpaceNum));
        
        log.info("場所IDを検索  site_id[" + siteId + "] codes[" + codes + "] page_space_num[" + pageSpaceNum + "] -> space_id[" + spaceId + "]");
			}

			// 場所IDが見つけられなかった場合、
			if (spaceId.length() == 0) {
				return "";
			}

			// 広告情報を取得する。
			Map map = PointAdDb.getAdDetail(spaceId);

			if (map != null) {
        //広告IDを取得
        String adId = (String) map.get("adId");
        
        //表示しようとしている広告がポイント広告かどうかチェック
        if(PointAdUtil.getPointAmount(adId) == PointAdDb.POINT_AD_DB_ERROR) {
          log.error("ポイント数未設定 or ポイント広告ではありません。広告の設定を確認して下さい ad_id[" + adId + "]");
          return "";
        }
        
        //広告枠IDを取得
        int adWindowId  = ((Integer) map.get("adWindowId")).intValue();

        // 表示しようとしている広告のクリック件数を集計
        int clickCount = PointAdUtil.getClickCount(adId, siteId);
        if(clickCount <= PointAdDb.POINT_AD_DB_ERROR) {
          log.error("point_ad_click_count_infoからクリック件数を取得出来ませんでした ad_id[" + adId + "]");
          return "";
        }
        
        // 表示しようとしている広告の上限件数を取得
        int maxClickCount = PointAdUtil.getMaxClickCount(adId);
        if(maxClickCount == PointAdDb.POINT_AD_DB_ERROR) {
          log.error("クリック上限数未設定 ad_id[" + adId + "]");
          return ""; //上限未設定
        }
        
        //表示上限チェック
        if(clickCount >= maxClickCount) {
          return ""; //上限を超えているため表示しない
        }
        
        String guid = SessionFilterUtil.getGuid(request);
        String clickDate = PointAdUtil.getNowDate();
        
        //同一日にクリックしているか状態を取得
        boolean todayClicked = PointAdUtil.isPointAdClicked(guid, siteId, clickDate, adId);
        
        //広告の下に表示するコメントを取得し、マップに保存する
        String adSubText = PointAdDb.getAdSubText(adId);
        map.put("adSubText", adSubText);
        
        //インプレッションログをimpression_logテーブルに登録
        request.setAttribute(AdThread.AD_THREAD_AD_ID_ATTR_KEY, adId);
        request.setAttribute(AdThread.AD_THREAD_AD_WINDOW_ID_ATTR_KEY, new Integer(adWindowId));
        request.setAttribute(AdThread.AD_THREAD_SPACE_ID_ATTR_KEY, spaceId);
        pointAdThread.push(request, response);

        //広告を取得する
        return getContent(map, adId, adWindowId, spaceId, siteId, SessionFilterUtil.isLogined(request), SessionFilterUtil.isFormal(request), todayClicked); 
        
			} else {
				log.warn("広告が未決定 space_id[" + spaceId + "]");
				return "";
			}

		} catch (SQLException e) {
			log.error("DBエラー", e);
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		return "";

	}

  /**
   * 広告を取得する
   * 
   * @param map
   * @param spaceId
   * @param siteId
   * @param isLogin
   * @return
   * @throws Exception
   */
  private String getContent(Map map, String adId, int adWindowId, String spaceId, int siteId, boolean isLogin, boolean isSoftLogin, boolean todayClicked) throws Exception {
    
    String content = "";
    String clickLogUrlTemplate = "";
    String clickLogUrl = "";
    String widthStr = "";
    String heightStr = "";
    
    int spaceWidth  = ((Integer) map.get("spaceWidth")).intValue();
    int spaceHeight = ((Integer) map.get("spaceHeight")).intValue();
    int adType      = ((Integer) map.get("adType")).intValue();
    int width       = ((Integer) map.get("width")).intValue();
    int height      = ((Integer) map.get("height")).intValue();
    
    String imgPathPrefix = (String) map.get("imgPathPrefix");
    String image1        = (String) map.get("image1");
    String altText1      = (String) map.get("altText1");
    String linkUrl1      = URLEncoder.encode((String) map.get("linkUrl1"), "UTF-8");
    String fixedHtml     = (String) map.get("fixedHtml");
    String adSubText     = (String) map.get("adSubText");

    log.info("ポイント広告が決定 space_id[" + spaceId + "] ad_id[" + adId + "] ad_window_id[" + adWindowId + "] ad_type[" + adType + "] site_id[" + siteId + "]");
    
    //広告の種別ごとにhtmlを組み立てる。
    switch (adType) {
      case TYPE_TEXT:
        // クリック計測ができるように遷移先URLを組み立てる。
        clickLogUrlTemplate = SystemPropertiesDb.getInstance().get(POINT_AD_CLICK_LOG_URL_TEMPLATE);
        clickLogUrl = new MessageFormat(clickLogUrlTemplate).format(new String[] { linkUrl1, spaceId, Integer.toString(adWindowId), adId, Integer.toString(siteId), "1" });
        
        // 広告htmlを組み立てる。
        if(isLogin) {
        	//クリック可能な広告を表示
          content  = new MessageFormat(TEMPLATE_TEXT).format(new String[] { clickLogUrl, fixedHtml });
          content += new MessageFormat(TEMPLATE_SUB_TEXT).format(new String[] { clickLogUrl, adSubText });
          if(todayClicked) {
          	content += TODAY_CLICKED_MESSAGE;
          }
        } else {
        	if(isSoftLogin) {
        		//ソフトログイン
        		if(todayClicked) {
        			//クリック可能な広告を表示
        			content  = new MessageFormat(TEMPLATE_TEXT).format(new String[] { clickLogUrl, fixedHtml });
              content += new MessageFormat(TEMPLATE_SUB_TEXT).format(new String[] { clickLogUrl, adSubText });
              content += TODAY_CLICKED_MESSAGE;
        		} else {
        			//吹き出し付きでクリック出来ない広告を表示
        			content  = new MessageFormat(TEMPLATE_TEXT_NOT_LOGIN).format(new String[] { "'" + adId + "'", "'" + adId + "'", fixedHtml });
              content += new MessageFormat(TEMPLATE_SUB_TEXT_NOT_LOGIN).format(new String[] { "'" + adId + "'", "'" + adId + "'",adSubText });
              content += new MessageFormat(SOFT_LOGIN_MESSAGE).format(new String[] { adId, clickLogUrl });
        		}
        	} else {
        		//ログインしていない
        		//吹き出し付きでクリック出来ない広告を表示
        		content  = new MessageFormat(TEMPLATE_TEXT_NOT_LOGIN).format(new String[] { "'" + adId + "'", "'" + adId + "'", fixedHtml });
            content += new MessageFormat(TEMPLATE_SUB_TEXT_NOT_LOGIN).format(new String[] { "'" + adId + "'", "'" + adId + "'",adSubText });
            content += new MessageFormat(NOT_LOGIN_MESSAGE).format(new String[] { adId, clickLogUrl });
        	}
        }
        break;

      case TYPE_IMAGE:
        // クリック計測ができるように遷移先URLを組み立てる。
        clickLogUrlTemplate = SystemPropertiesDb.getInstance().get(POINT_AD_CLICK_LOG_URL_TEMPLATE);
        clickLogUrl = new MessageFormat(clickLogUrlTemplate).format(new String[] { linkUrl1, spaceId, Integer.toString(adWindowId), adId, Integer.toString(siteId), "1" });

        // 画像のサイズが場所のサイズを超えている場合、
        if (spaceWidth != 0 && spaceHeight != 0 && (width > spaceWidth || height > spaceHeight)) {

          // 縦横比を維持するために、超過率の高いほうだけ指定する。
          if (width / spaceWidth > height / spaceHeight) {
            widthStr = "width=\"" + spaceWidth + "\"";
          } else {
            heightStr = "height=\"" + spaceHeight + "\"";
          }
        }

        // 広告htmlを組み立てる。
        if(isLogin) {
        	//クリック可能な広告を表示
          content  = new MessageFormat(TEMPLATE_IMAGE).format(new String[] { clickLogUrl, imgPathPrefix + image1, widthStr, heightStr, altText1 });
          content += new MessageFormat(TEMPLATE_SUB_TEXT).format(new String[] { clickLogUrl, adSubText });
          if(todayClicked) {
          	content += TODAY_CLICKED_MESSAGE;
          }
        } else {
        	if(isSoftLogin) {
        		//ソフトログイン
        		if(todayClicked) {
        			//クリック可能な広告を表示
        			content  = new MessageFormat(TEMPLATE_IMAGE).format(new String[] { clickLogUrl, imgPathPrefix + image1, widthStr, heightStr, altText1 });
              content += new MessageFormat(TEMPLATE_SUB_TEXT).format(new String[] { clickLogUrl, adSubText });
              content += TODAY_CLICKED_MESSAGE;
        		} else {
        			//吹き出し付きでクリック出来ない広告を表示
        			content  = new MessageFormat(TEMPLATE_IMAGE_NOT_LOGIN).format(new String[] { "'" + adId + "'", "'" + adId + "'",imgPathPrefix + image1, widthStr, heightStr, altText1 });
              content += new MessageFormat(TEMPLATE_SUB_TEXT_NOT_LOGIN).format(new String[] { "'" + adId + "'", "'" + adId + "'", adSubText });
              content += new MessageFormat(SOFT_LOGIN_MESSAGE).format(new String[] { adId, clickLogUrl });
        		}
        	} else {
        		//ログインしていない
        		//吹き出し付きでクリック出来ない広告を表示
        		content  = new MessageFormat(TEMPLATE_IMAGE_NOT_LOGIN).format(new String[] { "'" + adId + "'", "'" + adId + "'",imgPathPrefix + image1, widthStr, heightStr, altText1 });
            content += new MessageFormat(TEMPLATE_SUB_TEXT_NOT_LOGIN).format(new String[] { "'" + adId + "'", "'" + adId + "'", adSubText });
            content += new MessageFormat(NOT_LOGIN_MESSAGE).format(new String[] { adId, clickLogUrl });
        	}
        }
        break;

      case TYPE_FLASH:
        //TODO FLASHを用いたポイント広告を使用する場合は、ココにその機能を記述する
        break;

      case TYPE_HTML:
        //TODO HTMLを用いたポイント広告を使用する場合、ココにその機能を記述する
        break;
    }

    return content;
  }
}
