package jp.co.webcrew.filters.filters.replace.sstag;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.bean.CResearchOnBallotListBean;
import jp.co.webcrew.filters.util.CResearchUtil;

/**
 * クリックリサーチ用のExceuerクラス。
 * 
 * @author Amit Parmar
 */
public class CResearchOnBallotListExecuter extends SSTagExecuter {
	/** ロガー */
	private static final Logger log = Logger.getLogger(CResearchOnBallotListExecuter.class);

	private static final String TONASHIBA_URL = "TONASHIBA_URL";
	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map mapParameter, HttpServletRequest request,
			HttpServletResponse response) {

		try 
		{
			// Getting the Tonashiba URL
			String strTonashibaURL = SystemPropertiesDb.getInstance().get(TONASHIBA_URL);
			
			// Setting target as _blank when accessed from mypage
			String strTarget = "";
			String strNewImg = "";
			String strResearchImg = "<img src=\"/images/research/click_research.gif\" alt=\"とな芝クリックリサーチ\" width=\"200\" height=\"28\">";
			String strSiteId = (String)mapParameter.get("site_id");
			if (strSiteId != null && "200".equals(strSiteId))
			{	
				strNewImg = "/mypage";
				strTarget = " target=\"_blank\"";
				strResearchImg = "<img src=\"/mypage/images/click_research.gif\" alt=\"とな芝クリックリサーチ\" width=\"180\" height=\"28\">";
			}	
			
			//表示タイプを取得
			String strShowType = ((String)mapParameter.get("show_type") == null) ? "" : (String)mapParameter.get("show_type");
			
			//パラメータを読み込んでプロパティに設定する
			Properties objProperties = readProperties(mapParameter);

			CResearchOnBallotListBean objBallotBean = new CResearchOnBallotListBean(objProperties);

			//アンケート一覧を生成する
			if(objBallotBean.init() == false) {
				response.sendError(javax.servlet.http.HttpServletResponse.SC_NOT_FOUND);
				return "";
			}
		  
			//現在日時を取得
			String strNowDate = objBallotBean.getNowDate();
		    
			//アンケート一覧を取得
			List lstEnquete = objBallotBean.getEnquetesList();

			//取得したアンケート一覧を表示する
			Map mapEnquete = null;			
			if(lstEnquete.size() != 0) 
			{
				StringBuffer sbufReturnHTML = new StringBuffer();
				if(strShowType.equals("list") == true) 
				{
			    	//投票受付中一覧
			    } 
				else 
				{
					//TOPページ右側のパーツ
					sbufReturnHTML.append("<div class=\"click-research\">");
			    	sbufReturnHTML.append("<a href=\"" + strTonashibaURL + "/research/index.html\"" + strTarget + ">" + strResearchImg + "</a><br>");
			    	sbufReturnHTML.append("<ul>");
			    }
			  	
			  	int nEnqueteSize = lstEnquete.size();
			  	int nRowNo = 0;
			    for(int i = 0; i < nEnqueteSize; i++) 
			    {
			    	mapEnquete = (HashMap)lstEnquete.get(i);
			    
			    	//アンケートID取得
			    	int nId = ((Integer)mapEnquete.get("id")).intValue();
			    
			    	//質問文取得
			    	//String question = (String)enqueteMap.get("question");

			    	//タイトルを取得する
			    	String strTitle = (String)mapEnquete.get("title");
			      
			    	//カテゴリアイコン表示制御
			    	String strIcon = "";
			    	if(objProperties.getProperty("show_category_icon").equals("on")) 
			    	{
			    		strIcon = " class=\"" + (String)mapEnquete.get("categoryId") + "\""; 
			    	}
			      
			    	//実施期間表示制御
			    	//String startDate = ""; 
			    	//if(property.getProperty("show_start_date").equals("on")) 
			    	//{
			    		//開始日を取得
			    		//startDate = (String)enqueteMap.get("startDate");
			    	//}
			    	
			    	String strEndDate = "";
			    	if(objProperties.getProperty("show_end_date").equals("on")) 
			    	{
			    		//終了日を取得
			    		strEndDate = (String)mapEnquete.get("endDate");
			    		strEndDate = strEndDate.substring(5, 10) + "まで";
			    		//endDate = (String)enqueteMap.get("endDate") + "まで";
			    	}
			      
			    	//投票数表示制御
			    	String strVoteCount = "";
			    	if(objProperties.getProperty("show_vote_count").equals("on")) 
			    	{
			    		//投票件数を取得
			    		strVoteCount = String.valueOf(((Integer)mapEnquete.get("voteCount")).intValue());
			    	}
			      
			    	//NEWアイコン表示掲載開始日＆掲載終了日を取得し、NEWアイコンの表示制御を行う
			    	String strNewStartDate = (mapEnquete.get("newStartDate") == null) ? "" : (String)mapEnquete.get("newStartDate");
			    	String strNewEndDate   = (mapEnquete.get("newEndDate")   == null) ? "" : (String)mapEnquete.get("newEndDate");
			    	String strNewIcon = "";
			    	if(CResearchUtil.isNew(strNewStartDate, strNewEndDate, strNowDate).equals(CResearchUtil.IS_NEW) == true) 
			    	{
			    		strNewIcon = "<img src=\"" + strNewImg + "/images/new.gif\" alt=\"new\" width=\"18\" height=\"7\">";
			    	}

			    	if(strShowType.equals("list") == true) 
			    	{
			    		//投票受付中一覧
			    		if(nRowNo % 2 == 0) 
			    		{
			    			sbufReturnHTML.append("<tr>");
			    		} 
			    		else 
			    		{
			      	  		sbufReturnHTML.append("<tr class=\"stripe\">");
			    		}
			    		sbufReturnHTML.append("<td" + strIcon + "><a href=\"" + strTonashibaURL + "/research/ballot.html?eid=" + nId + "\"" + strTarget + ">" + strTitle + strNewIcon + "</a></td>");
			    		sbufReturnHTML.append("<td class=\"term\">" + strEndDate + "</td>");
			    		sbufReturnHTML.append("<td class=\"poll\">" + strVoteCount + "票</td>");
			    		sbufReturnHTML.append("</tr>");
			    	} 
			    	else 
			    	{
			    		//TOPページ右側のパーツ
			    		if(i == nEnqueteSize) 
			    		{
			    			//sbufReturnHTML.append("<li class=\"research-end\"><a href=\"./research/index.html\">" + title + "</a>" + newIcon + "</li>");
			    			sbufReturnHTML.append("<li class=\"research-end\"><a href=\"" + strTonashibaURL + "/research/ballot.html?eid=" + nId + "\"" + strTarget + ">" + strTitle + "</a>" + strNewIcon + "</li>");
			    		} 
			    		else 
			    		{
			    			//sbufReturnHTML.append("<li><a href=\"./research/index.html\">" + title + "</a>" + newIcon + "</li>");
			    			sbufReturnHTML.append("<li><a href=\"" + strTonashibaURL + "/research/ballot.html?eid=" + nId + "\"" + strTarget + ">" + strTitle + "</a>" + strNewIcon + "</li>");
			    		}
			    	}
			      
			    	nRowNo = nRowNo + 1;
			    }
			    
			    if(strShowType.equals("list") == true) 
			    {
			    	//投票受付中一覧
			    } 
			    else 
			    {
			    	//TOPページ右側のパーツ
			    	sbufReturnHTML.append("</ul>");
			    	sbufReturnHTML.append("</div>");
			    }
			    
			    return sbufReturnHTML.toString();
			}
		} 
		catch(Throwable e) 
		{
			try {
				response.sendError(javax.servlet.http.HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			} catch (IOException objIOExp) {
				log.error("予期せぬエラー", objIOExp);
			}
		}
		
		return "";
	}
	
	// パラメータを読み込んでプロパティに設定する
	Properties readProperties(Map mapParameter) {
		//パラメータを取得
		String strSort  = ((String)mapParameter.get("sort")               == null) ? ""    : (String)mapParameter.get("sort");
		String strMax   = ((String)mapParameter.get("show_max")           == null) ? "1"   : (String)mapParameter.get("show_max");
		String strIcon  = ((String)mapParameter.get("show_category_icon") == null) ? "off" : (String)mapParameter.get("show_category_icon");
	  	String strStart = ((String)mapParameter.get("show_start_date")    == null) ? "off" : (String)mapParameter.get("show_start_date");
	  	String strEnd   = ((String)mapParameter.get("show_end_date")      == null) ? "off" : (String)mapParameter.get("show_end_date");
	  	String strVote  = ((String)mapParameter.get("show_vote_count")    == null) ? "off" : (String)mapParameter.get("show_vote_count");
	  
	  	//プロパティに設定
	  	Properties objProperties = new Properties();
	  	objProperties.setProperty("sort",               strSort);
	  	objProperties.setProperty("show_max",           strMax);
	  	objProperties.setProperty("show_category_icon", strIcon);
	  	objProperties.setProperty("show_start_date",    strStart);
	  	objProperties.setProperty("show_end_date",      strEnd);
	  	objProperties.setProperty("show_vote_count",    strVote);
	  
	  	return objProperties;
	}	
}
