package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.db.EmojiDb;
import jp.co.webcrew.filters.db.TermMstDb;

/**
 * 携帯絵文字を表示するためのSSTAG
 * 
 * @author kadota
 *
 */
public class EmojiExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(EmojiExecuter.class);

	private static final String DOCOMO   = "1";
	private static final String AU       = "2";
	private static final String SOFTBANK = "3";
	
	private static final String DEFAULT_PICTURE_CHARACTER = "〓";
	
	/**
	 * Returns the HTML contents based on the value of the Contents Id read from
	 * the parameter
	 * 
	 */
	public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response)
	{
		try
		{
			if(parameters.get("emojiid") == null)
			{
				//SSTAGのパラメータにidが指定されていない
				log.error("絵文字表示SSTAG[emoji]に絵文字ID[emojiId]が指定されていません。");
				
				return "";
			}
			
			// user-agentの取得
			String strUserAgent = (String) request.getHeader("user-agent");

			// carrierIdの取得
			String strCareerId = TermMstDb.getCarrier(strUserAgent);
			if (TermMstDb.TYPE_DOCOMO.equals(strCareerId))
			{
				strCareerId = DOCOMO;
			}
			else if (TermMstDb.TYPE_AU.equals(strCareerId)) 
			{
				strCareerId = AU;
			}
			else if (TermMstDb.TYPE_SOFTBANK.equals(strCareerId)) 
			{
				strCareerId = SOFTBANK;
			}
			else
			{
				//Docomo,AU,SoftBank以外は「〓」を表示させる
				return DEFAULT_PICTURE_CHARACTER;
			}
			
			int nEmojiId   = Integer.parseInt((String)parameters.get("emojiid"));
			int nCareerId = Integer.parseInt(strCareerId);
				
			//DBに登録されている絵文字コードを取得する
			String nPicCode = EmojiDb.getInstance().getEmojiCode(nEmojiId, nCareerId);
			if (nPicCode.equals(""))
			{
				log.warn("絵文字を取得出来ませんでした。設定を確認して下さい。絵文字ID[" + nEmojiId + "] キャリアID[" + nCareerId + "]");
				
				return "";
			}
			else
			{    
				//キャリア毎に絵文字を作り直す
				if (DOCOMO.equals(strCareerId))
				{
					//ドコモはDBから取得した値をそのまま出力すると表示できる
				}
				else if (AU.equals(strCareerId))
				{
					nPicCode = "<img localsrc=\"" + nPicCode + "\" />";
				}
				else if (SOFTBANK.equals(strCareerId))
				{
           nPicCode = "$" + nPicCode + "";
				}
				
        return nPicCode;
			}
		}
		catch (Exception objExp)
		{
			log.error("予期せぬエラー", objExp);
		}
		
		return "";
	}
}
