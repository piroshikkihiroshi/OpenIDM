package jp.co.webcrew.phoenix.htmlservlet;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;

/**
 * 
 */
public class HtmlIncludeExecuter extends SSTagExecuter {

    public static final String TYPE_INCLUDE    = "0";
    public static final String TYPE_HTML       = "1";
    public static final String TYPE_CSS_JS_SWF = "2";
    public static final String TYPE_IMAGE      = "3";

    public static final String STORE_TYPE_HTML       = "1";
    public static final String STORE_TYPE_INCLUDE    = "2";
    public static final String STORE_TYPE_CSS_JS_SWF = "3";
    public static final String STORE_TYPE_IMAGE      = "4";

//	/** ロガー */
//	private static final Logger log = Logger.getLogger(HtmlIncludeExecuter.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {

	    try {
	        
	        
			String site_id = ValueUtil.nullToStr(parameterMap.get("site_id"));
			
            if (site_id.length() == 0) {
                // 省略時はセッションフィルタのサイトIDを使用
                site_id = ValueUtil.nullToStr(HtmlServletUtil.getSiteId(request));
            }

            if (site_id.length() == 0) {
                // サイトIDを取得できない場合はエラー
			    return SStagUtil.onSystemError(parameterMap, request, response, "site_id を指定してください。");
			}
			
            String path    = ValueUtil.nullToStr(parameterMap.get("path"));

            if (path.length() == 0) {
                return SStagUtil.onSystemError(parameterMap, request, response, "path を指定してください。");
            }
            
            
            String type = ValueUtil.nullToStr(parameterMap.get("pathtype"));
            
            if (type.length() == 0) {
                type = TYPE_INCLUDE; //デフォルト
            }

//            String encoding = ValueUtil.nullToStr(parameterMap.get("encoding"));
//            if (encoding.length() == 0) {
//                encoding = "UTF-8"; //デフォルト
//            }

            String html_store_type = STORE_TYPE_INCLUDE;
            
            if (type.equals(TYPE_INCLUDE)) {
                html_store_type = STORE_TYPE_INCLUDE;
            } else if (type.equals(TYPE_HTML)) {
                html_store_type = STORE_TYPE_HTML;
            } else if (type.equals(TYPE_CSS_JS_SWF)) {
                html_store_type = STORE_TYPE_CSS_JS_SWF;
            } else if (type.equals(TYPE_IMAGE)) {
                html_store_type = STORE_TYPE_IMAGE;
            } else {
                return SStagUtil.onSystemError(parameterMap, request, response, "typeの指定が不正です。0～3を指定してください。");
            }


            DBAccess db = null;
            try {
                
                db = HtmlServletUtil.getDB();

                HttpEntry entry = readHttpEntry(db , site_id , path , html_store_type);
                
                if (entry == null || entry.isEmpty() ) {
                    throw new HttpServletException("404 Not Found");
                }

                if ( entry.isBinary()) {
                    // バイナリかどうかの判断は怪しいので、ここでは判断しない。
                    // String に変換して確かめる。
                    //    return "<!-- File found, but cannot output binary file -->";
                }

                try {

                    String ret = entry.getContentsStr();
                    
                    if (ret == null) {
                    
                        return "<!-- The specified path is likely NULL -->";
                        
                    } else {
                        
                        return ret;
                    }
                
                } catch (RuntimeException e) {
                    e.printStackTrace();
                    return "<!-- The specified path file contains invalid string. It may be a binary file. -->";
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    return "<!-- Bad charset is specified. -->";
                }
                    
                

            } catch (HttpServletException e) {
                return "<!-- " + e.getMessage() + " -->";

            } catch (SQLException e) {
                System.out.println("データベースエラーが発生しました。");
                e.printStackTrace();
                return SStagUtil.onSystemError(parameterMap, request, response, e.getMessage());

            } catch (Exception e) {
                System.out.println("例外エラーが発生しました。");
                e.printStackTrace();
                return SStagUtil.onSystemError(parameterMap, request, response, e.getMessage());

            
            } finally {
                
                DBAccess.close(db);
            
	        }
            
            
		} catch (Exception e) {
            System.out.println("予期せぬエラー");
		    e.printStackTrace();
            return SStagUtil.onSystemError(parameterMap, request, response, e.getMessage());
		}
	}

	class HttpServletException extends RuntimeException {
	    public HttpServletException(String s) {
	        super(s);
	    }
	}
	
	private HttpEntry readHttpEntry(DBAccess db , String site_id , String path ,  String html_store_type) {
        HttpEntry entry = null;
        
        String theme = HtmlServletUtil.getTheme(site_id);
        
        if (theme == null) throw new HttpServletException("404 Not Found");
        
        if (! path.endsWith("/")) {

            // pathの最後の部分を取得
            String lastPath = HtmlServletUtil.getLastPathOf(path);
            
            if (lastPath.indexOf(".") >= 0 ) {
                
                // 拡張子あり
                
                entry = HtmlServletUtil.getEntry(db , theme , site_id , path , html_store_type);
                
                if (entry == null || entry.isEmpty() ) {
                    throw new HttpServletException("404 Not Found");
                }
                
            } else {
                
                // 拡張子なし
                
                entry = HtmlServletUtil.getEntry(db , theme , site_id , path , html_store_type);
                
                if (entry == null || entry.isEmpty() ) {

                    // ディレクトリかもしれないので、/をつけて読み直し
                    path = path + "/";
                    
                    return readHttpEntry(db , path , site_id , html_store_type);
                }
                
            }

            
        } else {
            
            entry = HtmlServletUtil.getDefaultIndexEntry(db , theme , site_id , path ,  html_store_type);
            
            if (entry == null || entry.isEmpty()) {
                throw new HttpServletException("403 Forbidden");
            }
            
        }
        
        return entry;

	}
	
}
