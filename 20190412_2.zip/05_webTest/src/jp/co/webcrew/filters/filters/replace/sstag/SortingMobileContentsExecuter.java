package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.MobileUserAgentMstDb;
import jp.co.webcrew.filters.db.SortingMobileContentsMstDb;
import jp.co.webcrew.filters.db.TermMstDb;

/**
 * <pre>
 *  UserAgentからキャリアとモバイルタイプを判断し、指定URLへリダイレクトさせるExecuterクラス。
 *  モバイルアクセスにのみ対応。PCアクセスの場合はすべてキャリア指定指定無し"0"、タイプ指定無し"0" として扱われる。
 *  パラメータは以下の1つ。省略不可。
 *    contentsId = HTMLコンテンツのID
 *  
 *  出力条件と出力コンテンツはDB上で管理する。
 *  &quot;SortingMobileContentsMst&quot;
 *  
 *  ※キャリアとモバイルタイプの指定はAND関係となる。
 *  ※"0"指定はワールドカードとなり、アクセス情報について明示的な条件が設定されていなければ"0"として扱う。
 * </pre>
 * 
 * @author amit, katsuno
 */
public class SortingMobileContentsExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(AdExecuter.class);

	/**
	 * Returns the HTML contents based on the value of the Contents Id read from
	 * the parameter
	 * 
	 */
	public String execute(Map parameters, HttpServletRequest request,
			HttpServletResponse response) {

		// Get Contents Id from the parameter
		String strContentsId = ValueUtil.nullToStr(parameters.get("contentsid"));

		try {
			// user-agentマスタの取得
			MobileUserAgentMstDb objMobileUserAgentMstDb = MobileUserAgentMstDb.getInstance();
			Map mapUserAgent = objMobileUserAgentMstDb.getUserAgentMap();

			// user-agentの取得
			String strUserAgent = (String) request.getHeader("user-agent");

			// carrierIdの取得
			String strCarrierId = TermMstDb.getCarrier(strUserAgent);
			if (TermMstDb.TYPE_DOCOMO.equals(strCarrierId)) {
				strCarrierId = "1";
			}
			else if (TermMstDb.TYPE_AU.equals(strCarrierId)) {
				strCarrierId = "2";
			}
			else if (TermMstDb.TYPE_SOFTBANK.equals(strCarrierId)) {
				strCarrierId = "3";
			}
			else {
				strCarrierId = "0";
			}
			
			// mobileTypeの取得
			String strMobileType = "0";
			Iterator iterUserAgents = mapUserAgent.keySet().iterator();
			while (iterUserAgents.hasNext()) {
				String strUA = (String) iterUserAgents.next();
				if (strUserAgent.indexOf(strUA) != -1) {
					strMobileType = (String) mapUserAgent.get(strUA);
					break;
				}
			}
			
			String strMapKey = strContentsId
					+ SortingMobileContentsMstDb.DELIMITER + strMobileType
					+ SortingMobileContentsMstDb.DELIMITER + strCarrierId;
			
			// Get the HTML contents from the database
			SortingMobileContentsMstDb objSortingMobileContentsMstDb = SortingMobileContentsMstDb.getInstance();
			Map mapContents = objSortingMobileContentsMstDb.getContents();			
			if (mapContents != null && mapContents.containsKey(strMapKey)) {
				return (String) mapContents.get(strMapKey);
			}
		} catch (Exception objExp) {
			log.error("予期せぬエラー", objExp);
		}
		return "";
	}
}
