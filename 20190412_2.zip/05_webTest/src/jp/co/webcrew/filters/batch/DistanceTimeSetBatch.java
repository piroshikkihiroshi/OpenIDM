package jp.co.webcrew.filters.batch;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * 前回アクセス日時差分を設定するbatchクラス。
 * 
 * @author kurinami
 */
public class DistanceTimeSetBatch extends BaseBatch {

	/** メンバマスタ削除用SQL */
	private static final String DISTANCE_TIME_UPDATE = ""
			+ "update session_log \n"
			+ "   set distance_time = coalesce(trunc(to_date(mk_datetime, 'YYYYMMDDHH24MISS')) - (select max(trunc(to_date(sub.mk_datetime, 'YYYYMMDDHH24MISS'))) from session_log sub where sub.gsid = session_log.gsid and sub.ssid < session_log.ssid), 0) \n"
			+ " where distance_time is null\n";

	/**
	 * 前回アクセス日時差分を設定する。
	 * 
	 * @param dbAccess
	 * @throws SQLException
	 */
	protected void execute(DBAccess dbAccess) throws SQLException {

		try {

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// 前回アクセス日時差分を設定する。
			dbAccess.executeUpdate(DISTANCE_TIME_UPDATE);

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		}

	}

	/**
	 * 起動する。
	 * 
	 * @param argv
	 */
	public static void main(String[] argv) {
		new DistanceTimeSetBatch().batch(argv);
	}
}
