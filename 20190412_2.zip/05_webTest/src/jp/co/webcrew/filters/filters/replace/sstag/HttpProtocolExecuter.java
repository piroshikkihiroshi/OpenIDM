package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.filters.filters.replace.replacer.HttpProtocolReplacer;

/**
 * 空のサーバサイドタグを意味するExecuterクラス。
 * 
 * @author kurinami
 * @see HttpProtocolReplacer
 */
public class HttpProtocolExecuter extends SSTagExecuter {

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    public String execute(Map parameterMap, HttpServletRequest request, HttpServletResponse response) {
        // このsstagの処理は実際にはHttpProtocolReplacerで行われるため、
        // 制御が流れてきた時点でエラーにする。
        String message = "sstag http_protocol はファイル上部に直接記載する必要があります。";
        return onerror(request, response, parameterMap, message);
    }

}
