package jp.co.webcrew.filters.filters.replace.sstag;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.util.LogicUtil;
import jp.co.webcrew.filters.util.QueueThreadUtil;
import jp.co.webcrew.filters.util.RowData;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;
import jp.co.webcrew.login.common.util.DateUtil;

/**
 * コールリスト登録処理を行うthreadクラス。
 * 
 * @author fu
 */
public class CallListRegistThread extends QueueThreadUtil {

  /** ロガー */
  private static final Logger log = Logger.getLogger(CallListRegistThread.class);

  /**
   * デフォルト文字コード
   */
  private static final String UTF8 = "UTF-8";

  /**
   * CTIのコールリスト用APIの接続URL
   */
  private static final String CTI_API_CALLLIST_URL = "CTI_API_CALLLIST_URL";

  /** guid ※ログインと新規登録時値を設定して、ソフトログインの場合空を設定します、常にStep見積時の電話番号と紐付け */
  public static final String CALLLIST_REGIST_THREAD_GUID_ATTR_KEY = "call_list_regist_thread_guid";

  /** task_id */
  public static final String CALLLIST_REGIST_THREAD_TASK_ID_ATTR_KEY =
      "call_list_regist_thread_task_id";

  /** cl_disp_id */
  public static final String CALLLIST_REGIST_THREAD_CL_DISP_ID_ATTR_KEY =
      "call_list_regist_thread_cl_disp_id";

  /** top_title */
  public static final String CALLLIST_REGIST_THREAD_TOP_TITLE_ATTR_KEY =
      "call_list_regist_thread_top_title";

  /** sep */
  public static final String CALLLIST_REGIST_THREAD_SEP_ATTR_KEY = "call_list_regist_thread_sep";

  /** charset */
  public static final String CALLLIST_REGIST_THREAD_CHARSET_ATTR_KEY =
      "call_list_regist_thread_charset";

  /** dup_ok */
  public static final String CALLLIST_REGIST_THREAD_DUP_OK_ATTR_KEY =
      "call_list_regist_thread_dup_ok";

  /** auth_code */
  public static final String CALLLIST_REGIST_THREAD_AUTH_CODE_ATTR_KEY =
      "call_list_regist_thread_auth_code";

  /** csv_data */
  public static final String CALLLIST_REGIST_THREAD_CSV_DATA_ATTR_KEY =
      "call_list_regist_thread_csv_data";

  /*
   * (non-Javadoc)
   * 
   * @see jp.co.webcrew.filters.util.QueueThreadUtil#execute(jp.co.webcrew.filters.util.httputil.
   * HttpServletRequestCache)
   */
  protected void execute(HttpServletRequestCache request) throws Exception {

    String task_id =
        ValueUtil.nullToStr(request.getAttribute(CALLLIST_REGIST_THREAD_TASK_ID_ATTR_KEY));
    String cl_disp_id =
        ValueUtil.nullToStr(request.getAttribute(CALLLIST_REGIST_THREAD_CL_DISP_ID_ATTR_KEY));
    String top_title =
        ValueUtil.nullToStr(request.getAttribute(CALLLIST_REGIST_THREAD_TOP_TITLE_ATTR_KEY));
    String sep = ValueUtil.nullToStr(request.getAttribute(CALLLIST_REGIST_THREAD_SEP_ATTR_KEY));
    String charset =
        ValueUtil.nullToStr(request.getAttribute(CALLLIST_REGIST_THREAD_CHARSET_ATTR_KEY));
    String dup_ok =
        ValueUtil.nullToStr(request.getAttribute(CALLLIST_REGIST_THREAD_DUP_OK_ATTR_KEY));
    String auth_code =
        ValueUtil.nullToStr(request.getAttribute(CALLLIST_REGIST_THREAD_AUTH_CODE_ATTR_KEY));
    String csv_data =
        ValueUtil.nullToStr(request.getAttribute(CALLLIST_REGIST_THREAD_CSV_DATA_ATTR_KEY));

    DBAccess db = null;

    try {
      db = new DBAccess(false);
      log.info("cl_disp_id:" + cl_disp_id);
      String cl_id = getCalllistId(db, cl_disp_id); // コールリストID
      log.info("cl_id:" + cl_id);

      if (cl_id.length() == 0) {
        log.error("パラメータエラー 仮想テーブル[cti.site_calllist_id_map]にデータ[" + cl_disp_id + "]を登録されていません。");
        return;
      }

      log.info("csv_data:" + csv_data);
      Map<String, String> retMap =
          addCalllist(task_id, cl_id, top_title, sep, charset, dup_ok, auth_code, csv_data);

      log.info("status:" + retMap.get("status_code") + " msg:" + retMap.get("status_msg"));

    } catch (SQLException e) {
      log.error("DBエラー", e);
    } catch (Exception e) {
      log.error("予期せぬエラー", e);
    } finally {
      DBAccess.close(db);
    }
  }

  /**
   * <pre>
     * ※URLパラメータ (*) 付きの項目は指定必須項目
     * 
     *   task_id(*) ... 業務ID
     *   cl_id(*)...... コールリストID
     *   top_title .... 先頭行がタイトル行の時 = 1
     *                  先頭行もデータ(タイトル行なし)の時 = 0
     *                  指定がない場合には「タイトルなし」がデフォルト。
     *   sep .......... セパレータ文字。特殊な文字を使用する場合にはURLエンコードする必要がある。
     *                    例. タブの場合 sep=%09 となる
     *                  指定がない場合にはカンマがデフォルト。
     *   charset ...... 文字コードを指定する。
     *                    UTF-8の場合 ....... utf-8 utf8 
     *                    シフトJISの場合 ... shift_jis sjis ms932 
     *                  を指定可能。
     *                  指定がない場合は HTTP ヘッダ content-type の charset属性と同じとみなす。
     *                  注意: content-type のcharset属性とURLパラメータの charset で異なる指定を
     *                  行った場合には誤変換の可能性があるため、どちらか一方だけを指定すること。
     *                  また両方共指定がない場合には シフトJISがデフォルトとなる。
     *   dup_ok ....... 1 または true の場合は重複を許す（デフォルト）
     *                  0 または false の場合には重複を許可せずエラーとする。
     *                  （重複とは同一業務IDで同一の電話番号を持つ顧客のこと）
     *   auth_code(*).. コールリストIDの MD5値。
     *   csv_data.......CSV型文字列データ。
     *   
     *   
     * ※戻る値（コード.....メセッジ）
     *          200.....コールリスト取り込みステータスコード－正常
     *                  
     *          401.....コールリスト取り込みステータスコード－auth_code 不正
     *          404.....コールリスト取り込みステータスコード－指定業務ID or コールリストID不正
     *          400.....コールリスト取り込みステータスコード－パラメータ指定間違い
     *                    
     *          550.....コールリスト取り込みステータスコード－CSVフォーマットエラー
     *          551.....コールリスト取り込みステータスコード－データの重複
     *          552.....コールリスト取り込みステータスコード－その他CSV関連エラー(※未使用)
     *          560.....コールリスト取り込みステータスコード－CSV関連以外のエラー(※未使用)
     *          599.....コールリスト取り込みステータスコード－システムエラー(データベース等)
     * </pre>
   * 
   * @param task_id
   * @param cl_id
   * @param top_title
   * @param sep
   * @param charset
   * @param auth_code
   * @param csv_data
   * @return retMap
   * @throws Exception
   */
  private Map<String, String> addCalllist(String task_id, String cl_id, String top_title,
      String sep, String charset, String dup_ok, String auth_code, String csv_data)
      throws Exception {

    Map<String, String> retMap = new HashMap<String, String>();

    // 先頭行がタイトル行か否か
    top_title = ValueUtil.nullToStr(top_title).length() == 0 ? "0" : top_title;
    // セパレータ文字
    // sep = ValueUtil.nullToStr(sep);
    // 文字コード
    charset = ValueUtil.nullToStr(charset).length() == 0 ? UTF8 : charset;
    // 重複を許すか
    // dup_ok = ValueUtil.nullToStr(dup_ok).length() == 0 ? "1" : dup_ok;
    // cl_id のMD5値
    auth_code = ValueUtil.nullToStr(auth_code).length() == 0 ? getMD5(cl_id) : auth_code;

    // コールするAPIのURL
    String param = "task_id=" + encode(task_id, UTF8);
    param += "&cl_id=" + encode(cl_id, UTF8);
    param += "&top_title=" + encode(top_title, UTF8);
    param += "&sep=" + encode(sep, UTF8);
    param += "&charset=" + encode(charset, UTF8);
    param += "&dup_ok=" + encode(dup_ok, UTF8);
    param += "&auth_code=" + encode(auth_code, UTF8);

    HttpURLConnection httpUrlConn = null;
    OutputStreamWriter out = null;
    BufferedReader reader = null;

    try {

      // API接続サーバURLは変数CTI_API_CALLLIST_URL（TONASHIBA.SYSTEM_PROPERTIES）に登録しています
      String calllistUrl = SystemPropertiesDb.getInstance().get(CTI_API_CALLLIST_URL);
      String strUrl = calllistUrl + "?" + param;

      log.info("url:" + strUrl);
      URL url = new URL(strUrl);
      URLConnection urlConn = url.openConnection();
      httpUrlConn = (HttpURLConnection) urlConn;

      httpUrlConn.setDoOutput(true);
      httpUrlConn.setDoInput(true);
      httpUrlConn.setUseCaches(false);

      httpUrlConn.setRequestProperty("Content-Type", "text/plain; charset=" + charset);

      // Post
      httpUrlConn.setRequestMethod("POST");

      // 接続確立のタイムアウト設定(ms)
      httpUrlConn.setConnectTimeout(5000);
      // 接続後のタイムアウト設定(ms)　 TODO　時間要確認
      httpUrlConn.setReadTimeout(5 * 60 * 1000);

      OutputStream outputStream = httpUrlConn.getOutputStream();
      out = new OutputStreamWriter(new BufferedOutputStream(outputStream), charset);
      out.write(csv_data);
      out.flush();

      // Stream output
      int status = ((HttpURLConnection) httpUrlConn).getResponseCode();

      // サーバが4xxまたは5xxのエラーレスポンスを返したときにはInputStreamは生成されない。getErrorStream()で取得します。
      InputStream inputStream = null;
      if (status == 200) {
        inputStream = httpUrlConn.getInputStream();
      } else {
        inputStream = httpUrlConn.getErrorStream();
      }

      StringBuilder result = new StringBuilder();
      if (inputStream != null) {
        reader = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        while ((line = reader.readLine()) != null) {
          result.append(line).append("\n");
        }
      }

      retMap.put("status_code", ValueUtil.nullToStr(status));
      retMap.put("status_msg", ValueUtil.nullToStr(result));

    } finally {
      if (httpUrlConn != null) {
        httpUrlConn.disconnect();
      }
      if (out != null) {
        try {
            out.close();
        } catch (IOException ioe) {
          ioe.printStackTrace();
        }
      }
      if (reader != null) {
        try {
            reader.close();
        } catch (IOException ioe) {
          ioe.printStackTrace();
        }
      }
    }
    return retMap;

  }

  /*
   * エンコード
   */
  private String encode(String str, String enc) {

    if (str == null) {
      return ("");
    }

    try {
      return (URLEncoder.encode(str, enc));
    } catch (UnsupportedEncodingException ex) {
      return (str);
    }

  }

  /**
   * 
   * <PRE>
     * 指定文字列のMD5値取得
     * </PRE>
   * 
   * @since 1.0
   * 
   * @param str [in]文字列(エラーの場合は、null)
   * 
   * @return String MD5値
   * @throws NoSuchAlgorithmException
   * 
   */
  private String getMD5(String str) throws NoSuchAlgorithmException {

    if (str == null) {
      return ("");
    }

    // md5値を取得
    MessageDigest md = MessageDigest.getInstance("MD5");
    byte[] data = str.getBytes();
    md.update(data);
    byte[] digest = md.digest();
    StringBuilder sb = new StringBuilder();
    for (int ii = 0; ii < digest.length; ii++) {
      int b = (0xFF & digest[ii]);
      if (b < 16) {
        sb.append("0");
      }
      sb.append(Integer.toHexString(b));
    }

    // Stringにして返す
    return (sb.toString());

  } /*- getMD5() -*/

  /**
   * 仮想テーブルのマップリストデータを返す(sort by default)
   * 
   * @return String
   * @throws SQLException
   */
  private String getCalllistId(DBAccess db, String cl_disp_id) throws SQLException {
    List<RowData> lstListingData = new ArrayList<RowData>();
    final String schema_id = "kanri_internal";
    final String table_id = "site_calllist_id_map";

    ResultSet rs = null;

    try {

      // KEYを指定して「site_calllist_id_map」テーブルを検索
      String condition =
          "AND EXISTS ( select 1 from " + schema_id + ".clm_data data2 where \n"
              + " data.rec_id = data2.rec_id and data2.tbl_id = '" + table_id + "' \n"
              + " AND data2.clm_id = 'calllist_disp_id' and data2.key_data = '" + cl_disp_id
              + "') \n";

      // コールリストIDは仮想テーブルcti.calllist_disp_idに登録しています。
      rs = query(db, 50900, schema_id, table_id, condition.toString());
      // ここで審査条件のリストを作成する。
      while (rs.next()) {
        LogicUtil.setRowData(lstListingData, rs.getLong("rec_id"), rs.getString("clm_id"), rs
            .getString("key_data"), rs.getString("lob_data"), rs.getString("up_datetime"));
      }

    } finally {
      DBAccess.close(rs);
    }
    if (lstListingData.size() > 0) {
      return ValueUtil.nullToStr(lstListingData.get(0).get("calllist_id"));
    }
    return "";
  }

  /**
   * 仮想テーブルの検索を指定された条件で実行する。 本番機の場合は、公開データのみを抽出するようにする。
   * 
   * @param db PhoenixDBAccess
   * @param nSiteId サイトＩＤ
   * @param strTableName 検索対象のテーブル名
   * @param strCondition 検索条件
   * @return ResultSet 検索結果
   * @throws SQLException
   */
  private static ResultSet query(DBAccess db, int nSiteId, String strSchemaName,
      String strTableName, String strCondition) throws SQLException {
    String strNow = DateUtil.currentDateTime();
    String strSql = "";
    if (LogicUtil.isProductionEnv()) {
      strSql =
          " select data.* \n" + " from \n" + strSchemaName + ".clm_data data, \n" + strSchemaName
              + ".rec_meta_data meta \n" + " where \n" + "   meta.site_id=data.site_id \n"
              + " and \n" + "   meta.tbl_id=data.tbl_id \n" + " and \n"
              + "   meta.rec_id=data.rec_id \n" + " and \n" + "   meta.pub_flag='1' \n" + " and \n"
              + "  (meta.bgn_datetime <= ? and ? <= meta.end_datetime) \n" + " and \n"
              + "  data.site_id=? \n" + " and \n" + "  data.tbl_id=? \n" + strCondition
              + " order by data.rec_id asc,data.sort_num asc ";

      db.prepareStatement(strSql);
      db.setString(1, strNow);
      db.setString(2, strNow);
      db.setInt(3, nSiteId);
      db.setString(4, strTableName);
    } else {
      strSql =
          "select data.* from \n " + strSchemaName + ".clm_data data \n" + " where \n"
              + "  site_id=? \n" + " and \n" + "  tbl_id=? \n" + strCondition
              + " order by rec_id asc,sort_num asc";

      db.prepareStatement(strSql);
      db.setInt(1, nSiteId);
      db.setString(2, strTableName);
    }
    // log.info("sql:" + strSql);
    return db.executeQuery();
  }

}