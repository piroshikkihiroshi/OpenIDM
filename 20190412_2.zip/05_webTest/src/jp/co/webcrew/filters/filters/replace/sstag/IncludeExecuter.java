package jp.co.webcrew.filters.filters.replace.sstag;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * 空のサーバサイドタグを意味するExecuterクラス。
 * 
 * @author kurinami
 */
public class IncludeExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(IncludeExecuter.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {

		try {
			String src = ValueUtil.nullToStr(parameterMap.get("src"));

			if (src.length() == 0) {
				throw new Exception("パラメータ src が指定されていません。");
			}

			String pathname = request.getSession().getServletContext()
					.getRealPath(src);
			File file = new File(pathname);
			if (!file.isFile()) {
				throw new Exception("パラメータ src に指定された値[" + src
						+ "]によりあらわされるファイル[" + pathname + "]が存在しません。");
			}

			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);

			FileInputStream fis = new FileInputStream(file);
			BufferedReader br = new BufferedReader(new InputStreamReader(fis,
					response.getCharacterEncoding()));

			while (true) {
				String buf;
				buf = br.readLine();
				if (buf == null) {
					break;
				}
				pw.println(buf);
			}

			fis.close();

			return sw.toString();

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			return "";
		}
	}

}
