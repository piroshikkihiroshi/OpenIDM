package jp.co.webcrew.phoenix.logic.bean;

/**
 * 共通パラメータ
 * 
 * @author kurinami
 */
public class SstagGlobalInfo {
    public String guid; // global user id
    public String gsid; // global session id
    public String ssid; // site session id
    public String short_id; // short session id
    public String ls_code; // local session id(for DOCOMO)
    public String goid; // global oprder id
    public String site_id; // site id
    public boolean login_flag; // is login now
    public String promo_code; // promotion code(if exists)
    public String af_code; // afiliate code (if exists)
}
