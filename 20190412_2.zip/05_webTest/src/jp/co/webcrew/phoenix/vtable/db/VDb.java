package jp.co.webcrew.phoenix.vtable.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
//import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
//import jp.co.webcrew.log4wc.Logger2;
//import jp.co.webcrew.log4wc.internal.LogLevel;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.htmlservlet.HtmlPropertiesUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;
import jp.co.webcrew.phoenix.vtable.bean.ClmMetaMstBean;
import jp.co.webcrew.phoenix.vtable.bean.ConditionBean;
import jp.co.webcrew.phoenix.vtable.bean.TblMetaMstBean;
import jp.co.webcrew.phoenix.vtable.bean.VResultSet;

/**
 * 仮想テーブルを管理するdbクラス。
 * 
 * @author kurinami
 */
public class VDb {

    /** 格納データキー部の長さ（バイト数） */
    public static final int KEY_DATA_LENGTH = 512;

    /** 汎用仮想テーブルカラムデータの一覧を取得するためのsql */
    private static final String SELECT_CLM_DATA_LIST = ""
            + "select clm_data.* from (schema_name).clm_data \n{0} where clm_data.site_id = ? and clm_data.tbl_id = ? \n{1} order by {2} clm_data.rec_id, clm_data.sort_num";
    		//+ "select clm_data.* from (select * from (schema_name).clm_data where site_id={3} and tbl_id={4} )clm_data \n{0} where clm_data.site_id = ? and clm_data.tbl_id = ? \n{1} order by {2} clm_data.rec_id, clm_data.sort_num";

    /** オーダー情報可変部カラムデータの一覧を取得するためのsql */
    private static final String SELECT_ORDER_INFO_CLM_DATA_LIST = ""
            + "select clm_data.* from (schema_name).order_info_clm_data clm_data \n{0} where clm_data.site_id = ? and clm_data.tbl_id = ? \n{1} order by {2} clm_data.order_id, clm_data.sort_num";

    /** オーダー情報ソート用の結合sql */
    private static String JOIN_FOR_CLM_DATA_SORT = ""
            + " left outer join (select rec_id, key_data as sort_key from (schema_name).clm_data where site_id = ? and tbl_id = ? and clm_id = ?) sort_tbl on clm_data.rec_id = sort_tbl.rec_id \n";

    /** 汎用仮想テーブルの検索用の結合sql */
    private static String JOIN_FOR_CLM_DATA_CONDITION = ""
            + " inner join (select rec_id from (schema_name).clm_data where site_id = ? and tbl_id = ? and clm_id = ? and key_data {1}) cond_tbl{0} on clm_data.rec_id = cond_tbl{0}.rec_id \n";

    /** オーダー情報可変部の検索用の結合sql */
    private static String JOIN_FOR_ORDER_INFO_CLM_DATA_CONDITION = ""
            + " inner join (select order_id from (schema_name).order_info_clm_data where site_id = ? and tbl_id = ? and clm_id = ? and key_data {1}) cond_tbl{0} on clm_data.order_id = cond_tbl{0}.order_id \n";

    /** オーダー情報ソート用のキーsql */
    private static String KEY_FOR_CLM_DATA_SORT = "sort_tbl.sort_key {0}, ";

    /** 最大のレコードIDを取得するためのsql */
    private static final String SELECT_MAX_REC_ID = ""
            + "select max(rec_id) from (schema_name).rec_meta_data where site_id = ? and tbl_id = ? ";

    /** 汎用仮想テーブルカラムデータを挿入するためのsql */
    private static final String INSERT_CLM_DATA = ""
            + "insert into (schema_name).clm_data(site_id, tbl_id, rec_id, clm_id, sort_num, key_data, lob_data, up_datetime, up_admin) \n"
            + "                            values(?, ?, ?, ?, ?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'), null) \n";

    /** オーダー情報可変部カラムデータを挿入するためのsql */
    private static final String INSERT_ORDER_INFO_CLM_DATA = ""
            + "insert into (schema_name).order_info_clm_data(site_id, tbl_id, order_id, clm_id, sort_num, key_data, lob_data, up_datetime, up_admin) \n"
            + "                                       values(?, ?, ?, ?, ?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'), null) \n";

    /** 汎用仮想テーブルカラムデータを更新するためのsql */
    private static final String UPDATE_CLM_DATA = ""
            + "update (schema_name).clm_data set key_data = ?, lob_data = ?, up_datetime = to_char(sysdate, 'YYYYMMDDHH24MISS'), up_admin = null \n"
            + "                            where site_id = ? and tbl_id = ? and rec_id = ? and clm_id = ? \n";

    /** オーダー情報可変部カラムデータを更新するためのsql */
    private static final String UPDATE_ORDER_INFO_CLM_DATA = ""
            + "update (schema_name).order_info_clm_data set key_data = ?, lob_data = ?, up_datetime = to_char(sysdate, 'YYYYMMDDHH24MISS'), up_admin = null \n"
            + "                                       where site_id = ? and tbl_id = ? and order_id = ? and clm_id = ? \n";

    /** 仮想レコードメタ情報を挿入するためのsql */
    private static final String INSERT_REC_META_DATA = ""
            + "insert into (schema_name).rec_meta_data(site_id, tbl_id, rec_id, acc_level, pub_flag, bgn_datetime, end_datetime, link_flag, up_datetime, up_admin) \n"
            + "                                 values(?, ?, ?, null, 0, null, null, 0, to_char(sysdate, 'YYYYMMDDHH24MISS'), null) \n";

    /** 仮想レコードメタ情報を更新するためのsql */
    private static final String UPDATE_REC_META_DATA = ""
            + "update (schema_name).rec_meta_data set up_datetime = to_char(sysdate, 'YYYYMMDDHH24MISS') where site_id = ? and tbl_id = ? and rec_id = ? ";

    //private static final Logger2 logger2=Logger2.getInstance("phoenix");
    //private static final int FETCHSIZE_UNSET=-1;
    private static final int DEFAULT_FETCH_SIZE;
    
    static
    {
    	int defaultFetchSize=-1;

        try {
            HtmlPropertiesUtil prop = new HtmlPropertiesUtil("html_servlet.properties");
            String strVal=ValueUtil.nullToStr( prop.getProperty("dbaccess.fetchsize.vdb.default"));
            defaultFetchSize=Integer.parseInt(strVal);
            
        } catch (Throwable e) {
        }
        
        DEFAULT_FETCH_SIZE=defaultFetchSize;
        
    }
    
    
    
    /**
     * 仮想テーブルからデータを取得する。
     * 
     * @param siteId
     * @param tblId
     * @param fromRecId
     * @param toRecId
     * @param conditions
     * @param orderItem
     * @param orderDir
     * @return
     * @throws SQLException
     */
    public static List<Map<String, ClmDataBean>> getList(int siteId, String tblId, Long fromRecId, Long toRecId,
            List<ConditionBean> conditions, String orderItem, String orderDir) throws SQLException {
        return getList(siteId, tblId, fromRecId, toRecId, conditions, orderItem, orderDir, false,DEFAULT_FETCH_SIZE);
    }

    /**
     * 仮想テーブルからデータを取得する。
     * 
     * @param siteId
     * @param tblId
     * @param fromRecId
     * @param toRecId
     * @param conditions
     * @param orderItem
     * @param orderDir
     * @param ignorePubflag
     * @return
     * @throws SQLException
     */
    public static List<Map<String, ClmDataBean>> getList(int siteId, String tblId, Long fromRecId, Long toRecId,
            List<ConditionBean> conditions, String orderItem, String orderDir, boolean ignorePubflag)
            throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);
            return getList(dbAccess, siteId, tblId, fromRecId, toRecId, conditions, orderItem, orderDir, ignorePubflag,DEFAULT_FETCH_SIZE);
        } finally {
            DBAccess.close(dbAccess);
        }
    }

    /**
     * 仮想テーブルからデータを取得する。
     * 
     * @param siteId
     * @param tblId
     * @param fromRecId
     * @param toRecId
     * @param conditions
     * @param orderItem
     * @param orderDir
     * @return
     * @throws SQLException
     */
    public static List<Map<String, ClmDataBean>> getList(int siteId, String tblId, Long fromRecId, Long toRecId,
            List<ConditionBean> conditions, String orderItem, String orderDir,int fetchSize) throws SQLException {
        return getList(siteId, tblId, fromRecId, toRecId, conditions, orderItem, orderDir, false,fetchSize);
    }

    /**
     * 仮想テーブルからデータを取得する。
     * 
     * @param siteId
     * @param tblId
     * @param fromRecId
     * @param toRecId
     * @param conditions
     * @param orderItem
     * @param orderDir
     * @param ignorePubflag
     * @return
     * @throws SQLException
     */
    public static List<Map<String, ClmDataBean>> getList(int siteId, String tblId, Long fromRecId, Long toRecId,
            List<ConditionBean> conditions, String orderItem, String orderDir, boolean ignorePubflag,int fetchSize)
            throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);
            return getList(dbAccess, siteId, tblId, fromRecId, toRecId, conditions, orderItem, orderDir, ignorePubflag,fetchSize);
        } finally {
            DBAccess.close(dbAccess);
        }
    }

    
    /**
     * 仮想テーブルからデータを取得する。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @param fromRecId
     * @param toRecId
     * @param conditions
     * @param orderItem
     * @param orderDir
     * @param ignorePubflag
     * @return
     * @throws SQLException
     */
    private static List<Map<String, ClmDataBean>> getList(DBAccess dbAccess, int siteId, String tblId, Long fromRecId,
            Long toRecId, List<ConditionBean> conditions, String orderItem, String orderDir, boolean ignorePubflag,int fetchSize)
            throws SQLException {

        boolean orderAscFlag = !ValueUtil.nullToStr(orderDir).toLowerCase().startsWith("d");

        //int fetchSize=300;
        
        ResultSet rs = null;
        try {

            TblMetaMstBean tblMetaMst = MetaDb.getTblMetaMst(siteId, tblId);
            List<ClmMetaMstBean> clmMetaMstList = MetaDb.getClmMetaMstList(siteId, tblId);

            List<Map<String, ClmDataBean>> list = new ArrayList<Map<String, ClmDataBean>>();

            // テーブルタイプによって、ResultSetを作成する。
            if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_NORMAL_REAL_TBL)) {
                // TODO kurinami 【未実装】 エラー form-to recid conditionsが指定された場合、
                rs = getRealTblRs(dbAccess, tblMetaMst.getTblSchema(), tblMetaMst.getTblName(), conditions, orderItem,
                        orderAscFlag);
            } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_NORMAL_VIRTUAL_TBL)) {
                rs = getVirtualTblRs(dbAccess, clmMetaMstList, siteId, tblId, false, fromRecId, toRecId, conditions,
                        orderItem, orderAscFlag, ignorePubflag,fetchSize);
            } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_ORDER_REAL_TBL)) {
                // TODO kurinami 【未実装】 エラー form-to recid conditionsが指定された場合、
                rs = getRealTblRs(dbAccess, tblMetaMst.getTblSchema(), tblMetaMst.getTblName(), conditions, orderItem,
                        orderAscFlag);
            } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_ORDER_VIRTUAL_TBL)) {
                rs = getVirtualTblRs(dbAccess, clmMetaMstList, siteId, tblId, true, fromRecId, toRecId, conditions,
                        orderItem, orderAscFlag, ignorePubflag,fetchSize);
            } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_FORM_VIRTUAL_TBL)) {
                rs = getVirtualTblRs(dbAccess, clmMetaMstList, siteId, tblId, false, fromRecId, toRecId, conditions,
                        orderItem, orderAscFlag, ignorePubflag,fetchSize);
            } else {
                String message = MessageFormat.format("不明なテーブルタイプ({0})です。[site_id:{1}][tbl_id:{2}]", tblMetaMst
                        .getTblType(), tblMetaMst.getSiteId(), tblMetaMst.getTblId());
                throw new SQLException(message);
            }

            
            //long startTime=new Date().getTime();
            //int count=0;
            // １レコードずつ読み込んでいく。
            while (dbAccess.next(rs)) {

            	//count++;
                Map<String, ClmDataBean> record = new HashMap<String, ClmDataBean>();

                for (ClmMetaMstBean clmMetaMst : clmMetaMstList) {
                    ClmDataBean clmData = new ClmDataBean();
                    // テーブルタイプによって、rec_idを設定する。
                    long recId = 0l;
                    if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_NORMAL_REAL_TBL)) {
                        recId = 0l;
                    } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_NORMAL_VIRTUAL_TBL)) {
                        recId = rs.getLong("rec_id");
                    } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_ORDER_REAL_TBL)) {
                        recId = 0l;
                    } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_ORDER_VIRTUAL_TBL)) {
                        recId = rs.getLong("order_id");
                    } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_FORM_VIRTUAL_TBL)) {
                        recId = rs.getLong("rec_id");
                    }
                    clmData.setRecId(recId);

                    // 実テーブルの日付型だけ取得時に変換して受け取る。
                    if (tblMetaMst.isRealTbl() && clmMetaMst.getType().equals("P7")) {
                        clmData.setData(ValueUtil.toDateString(rs.getDate(clmMetaMst.getClmId())));
                    } else if (tblMetaMst.isRealTbl() && clmMetaMst.getType().equals("P9")) {
                        clmData.setData(ValueUtil.toDateTimeString(rs.getTimestamp(clmMetaMst.getClmId())));
                    } else {
                        clmData.setData(ValueUtil.nullToStr(rs.getString(clmMetaMst.getClmId())));
                    }

                    clmData.setMeta(clmMetaMst);
                    record.put(clmMetaMst.getClmId(), clmData);
                }

                list.add(record);
            }
            //long endTime=new Date().getTime();

            //logger2.doLog(LogLevel.INFO, "[siteid]"+siteId+"[tblid]"+tblId+"[count]"+count+"[msec]"+(endTime-startTime));
            return list;

        } finally {
            DBAccess.close(rs);
        }

    }

    /**
     * 汎用固定テーブルからデータを読み取るResultSetを返す。
     * 
     * @param dbAccess
     * @param schemaName
     * @param tableName
     * @return
     * @throws SQLException
     */
    private static ResultSet getRealTblRs(DBAccess dbAccess, String schemaName, String tableName,
            List<ConditionBean> conditions, String orderItem, boolean orderAscFlag) throws SQLException {
        // 汎用固定テーブルから取得する。

        StringBuffer sb = new StringBuffer();
        if (!PhoenixUtil.isEmpty(conditions)) {
            sb.append(" where 1 = 1");
            for (ConditionBean condition : conditions) {
                sb.append(" and ");
                sb.append(condition.getItemId());
                sb.append(condition.getCondition());
            }
        }

        String selectSql = "select * from " + schemaName + "." + tableName;
        String whereSql = sb.toString();
        String orderSql = (!PhoenixUtil.isEmpty(orderItem) ? " order by " + orderItem + (orderAscFlag ? " asc" : " desc")
                : "");

        dbAccess.prepareStatement(selectSql + whereSql + orderSql);
        if (!PhoenixUtil.isEmpty(conditions)) {
            int i = 0;
            for (ConditionBean condition : conditions) {
                if (condition.isNeedSetParam()) {
                    dbAccess.setString(++i, condition.getParamValue());
                }
            }
        }
        return dbAccess.executeQuery();
    }

    /**
     * 汎用仮想テーブルからデータを読み取るResultSetを返す。
     * 
     * @param dbAccess
     * @param clmMetaMstList
     * @param siteId
     * @param tblId
     * @param orderTblFlag
     * @param fromRecId
     * @param toRecId
     * @param conditions
     * @param orderItem
     * @param orderAscFlag
     * @param ignorePubflag
     * @return
     * @throws SQLException
     */
    private static ResultSet getVirtualTblRs(DBAccess dbAccess, List<ClmMetaMstBean> clmMetaMstList, int siteId,
            String tblId, boolean orderTblFlag, Long fromRecId, Long toRecId, List<ConditionBean> conditions,
            String orderItem, boolean orderAscFlag, boolean ignorePubflag,int fetchSize) throws SQLException {
        // 汎用仮想テーブルから取得する。

        // ========================================
        // 結合(join)を組み立てる。
        StringBuffer sbJoin = new StringBuffer();

        // ソートのための結合
        if (!PhoenixUtil.isEmpty(orderItem)) {
            String orderSql = JOIN_FOR_CLM_DATA_SORT;
            // 数値型かそうでないかでソートのしかたを変える。
            if (ClmMetaMstBean.isNumber(clmMetaMstList, orderItem)) {
                orderSql = ValueUtil.replace(orderSql, "key_data", "to_number(key_data)");
            }
            sbJoin.append(orderSql);
        }

        // 検索条件のための結合
        if (!PhoenixUtil.isEmpty(conditions)) {
            int i = 0;
            for (ConditionBean condition : conditions) {
                String conditionSql = MessageFormat.format(!orderTblFlag ? JOIN_FOR_CLM_DATA_CONDITION
                        : JOIN_FOR_ORDER_INFO_CLM_DATA_CONDITION, i, condition.getCondition());
                if (condition.isNeedTrim()) {
                    conditionSql = ValueUtil.replace(conditionSql, "key_data",
                            "translate(key_data, '# ' || CHR(10) || CHR(13), '#')");
                } else if (ClmMetaMstBean.isNumber(clmMetaMstList, condition.getItemId())) {
                    // 比較対象のデータが数値型の場合は、数値化してから比較する。
                    conditionSql = ValueUtil.replace(conditionSql, "key_data", "to_number(key_data)");
                }
                sbJoin.append(conditionSql);
                i++;
            }
        }

        // 公開フラグのための結合
        if (!ignorePubflag && !PhoenixUtil.isTestMode()) {
            String JOIN_REC_META_MST = " inner join (select rec_id from (schema_name).rec_meta_data where site_id = ? and tbl_id = ? and pub_flag = '1' and to_char(sysdate, 'YYYYMMDDHH24MISS') between bgn_datetime and end_datetime) rec_meta_data on clm_data.rec_id = rec_meta_data.rec_id \n";
            sbJoin.append(JOIN_REC_META_MST);
        }

        // ========================================
        // 検索（where）を組み立てる。
        StringBuffer sbWhere = new StringBuffer();

        // TODO kurinami 【確認】 汎用テーブルでも、オーダー情報様には、rec_idが無いぞ。
        if (fromRecId != null) {
            sbWhere.append(" and clm_data.rec_id >= ?");
        }
        if (toRecId != null) {
            sbWhere.append(" and clm_data.rec_id <= ?");
        }

        // ========================================
        // ソート（order）を組み立てる。
        StringBuffer sbOrder = new StringBuffer();

        if (!PhoenixUtil.isEmpty(orderItem)) {
            sbOrder.append(MessageFormat.format(KEY_FOR_CLM_DATA_SORT, orderAscFlag ? " asc" : " desc"));
        }

        // ========================================
        // 上記で組み立てたものからsqlを作成する。
        String sql = MessageFormat.format(!orderTblFlag ? SELECT_CLM_DATA_LIST : SELECT_ORDER_INFO_CLM_DATA_LIST,
                sbJoin.toString(), sbWhere.toString(), sbOrder.toString());
        dbAccess.prepareStatement(sql);

        // ========================================
        // 各置換パラメータの値を設定する。
        int i = 0;

        // join部分用のパラメータの設定
        if (!PhoenixUtil.isEmpty(orderItem)) {
            dbAccess.setInt(++i, siteId);
            dbAccess.setString(++i, tblId);
            dbAccess.setString(++i, orderItem);
        }
        if (!PhoenixUtil.isEmpty(conditions)) {
            for (ConditionBean condition : conditions) {
                dbAccess.setInt(++i, siteId);
                dbAccess.setString(++i, tblId);
                dbAccess.setString(++i, condition.getItemId());
                if (condition.isNeedSetParam()) {
                    dbAccess.setString(++i, condition.getParamValue());
                }
            }
        }
        if (!ignorePubflag && !PhoenixUtil.isTestMode()) {
            dbAccess.setInt(++i, siteId);
            dbAccess.setString(++i, tblId);
        }

        // where部分用のパラメータの設定
        dbAccess.setInt(++i, siteId);
        dbAccess.setString(++i, tblId);
        if (fromRecId != null) {
            dbAccess.setLong(++i, fromRecId.longValue());
        }
        if (toRecId != null) {
            dbAccess.setLong(++i, toRecId.longValue());
        }

        // ========================================
        // 組み立てたsqlを実行して、resultsetを返す。
        //引数に渡された値が0以上の場合だけ、設定。
        ResultSet originalResultSet=dbAccess.executeQuery();
        if(fetchSize>=0)
        {
        	originalResultSet.setFetchSize(fetchSize);        
        }
        return new VResultSet(originalResultSet, clmMetaMstList, orderTblFlag);
    }

    /**
     * 仮想レコードメタ情報に、次に割り当てるレコードIDを返す。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @return
     * @throws SQLException
     */
    private static long getNextRecId(DBAccess dbAccess, int siteId, String tblId) throws SQLException {

        ResultSet rs = null;
        try {

            // テーブルメタ情報マスタの情報を取得する。
            dbAccess.prepareStatement(SELECT_MAX_REC_ID);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, tblId);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                return rs.getLong(1) + 1;
            } else {
                return 1l;
            }

        } finally {
            DBAccess.close(rs);
        }

    }

    /**
     * キー情報をもとに、汎用仮想テーブルカラムデータ/オーダー情報可変部カラムデータから該当するレコードIDを検索する。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @param keyName
     * @param clmData
     * @param orderTblFlag
     * @return
     * @throws SQLException
     */
    public static long getRecId(DBAccess dbAccess, int siteId, String tblId, String[] keyName,
            Map<String, String> clmData, boolean orderTblFlag) throws SQLException {

        // キーのカラムが指定されていない場合、
        if (PhoenixUtil.isEmpty(keyName)) {
            return 0l;
        }

        ResultSet rs = null;
        try {

            // ========================================
            // 結合(join)を組み立てる。
            StringBuffer sbJoin = new StringBuffer();

            // 検索条件のための結合
            List<ConditionBean> conditions = new ArrayList<ConditionBean>();
            for (String key : keyName) {
                String value = clmData.get(key);
                conditions.add(new ConditionBean(key, "=", value));
            }
            int i = 0;
            for (ConditionBean condition : conditions) {
                String conditionSql = MessageFormat.format(!orderTblFlag ? JOIN_FOR_CLM_DATA_CONDITION
                        : JOIN_FOR_ORDER_INFO_CLM_DATA_CONDITION, i, condition.getCondition());
                if (condition.isNeedTrim()) {
                    conditionSql = ValueUtil.replace(conditionSql, "key_data",
                            "translate(key_data, '# ' || CHR(10) || CHR(13), '#')");
                }
                sbJoin.append(conditionSql);
                i++;
            }

            // ========================================
            // 上記で組み立てたものからsqlを作成する。
            String sql = (!orderTblFlag ? "select clm_data.rec_id from (schema_name).clm_data "
                    : "select clm_data.order_id from (schema_name).order_info_clm_data clm_data")
                    + sbJoin.toString();
            dbAccess.prepareStatement(sql);

            // ========================================
            // 各置換パラメータの値を設定する。
            i = 0;

            // join部分用のパラメータの設定
            if (!PhoenixUtil.isEmpty(conditions)) {
                for (ConditionBean condition : conditions) {
                    dbAccess.setInt(++i, siteId);
                    dbAccess.setString(++i, tblId);
                    dbAccess.setString(++i, condition.getItemId());
                    if (condition.isNeedSetParam()) {
                        dbAccess.setString(++i, condition.getParamValue());
                    }
                }
            }

            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                return rs.getLong(1);
            } else {
                return 0l;
            }

        } finally {
            DBAccess.close(rs);
        }

    }

    /**
     * キー情報をもとに、固定テーブルから該当するrowidを検索する。
     * 
     * @param dbAccess
     * @param schemaName
     * @param tableName
     * @param keyName
     * @param clmData
     * @return
     * @throws SQLException
     */
    public static String getRowId(DBAccess dbAccess, String schemaName, String tableName, String[] keyName,
            Map<String, String> clmData) throws SQLException {

        // キーのカラムが指定されていない場合、
        if (PhoenixUtil.isEmpty(keyName)) {
            return null;
        }

        ResultSet rs = null;
        try {

            // ROWIDを取得するためのsqlを組み立てる。
            StringBuffer sb = new StringBuffer("select rowid from " + schemaName + "." + tableName + " where 1 = 1 ");
            for (int i = 0; i < keyName.length; i++) {
                sb.append(" and " + keyName[i] + " = ?");
            }

            // ROWIDを取得する。
            dbAccess.prepareStatement(sb.toString());
            int i = 0;
            for (String key : keyName) {
                dbAccess.setString(++i, ValueUtil.nullToStr(clmData.get(key)));
            }
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                return rs.getString(1);
            } else {
                return null;
            }

        } finally {
            DBAccess.close(rs);
        }

    }

    /**
     * 書き込み先のテーブルごとに書き込み処理を行う。
     * 
     * @param siteId
     * @param tblMetaMstList
     * @param clmDataList
     * @param keyNameList
     * @param overwriteFlag
     * @param recId
     * @param appendFlag
     * @throws SQLException
     */
    public static void writeRecords(int siteId, List<TblMetaMstBean> tblMetaMstList,
            List<Map<String, String>> clmDataList, List<String[]> keyNameList, boolean overwriteFlag, long recId,
            boolean appendFlag) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            for (int i = 0; i < tblMetaMstList.size(); i++) {
                writeRecord(dbAccess, tblMetaMstList.get(i), clmDataList.get(i), keyNameList.get(i), overwriteFlag,
                        recId, appendFlag);
            }

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * テーブルメタ情報マスタをもとに、出力先を判断して、レコードを書き込む。
     * 
     * @param siteId
     * @param tblId
     * @param clmData
     * @param keyName
     * @param overwriteFlag
     * @param recId
     * @param appendFlag
     * @throws SQLException
     */
    public static void writeRecord(int siteId, String tblId, Map<String, String> clmData, String[] keyName,
            boolean overwriteFlag, long recId, boolean appendFlag) throws SQLException {
        TblMetaMstBean tblMetaMst = MetaDb.getTblMetaMst(siteId, tblId);
        writeRecord(siteId, tblMetaMst, clmData, keyName, overwriteFlag, recId, appendFlag);

    }

    /**
     * テーブルメタ情報マスタをもとに、出力先を判断して、レコードを書き込む。
     * 
     * @param siteId
     * @param tblMetaMst
     * @param clmData
     * @param keyName
     * @param overwriteFlag
     * @param recId
     * @param appendFlag
     * @throws SQLException
     */
    public static void writeRecord(int siteId, TblMetaMstBean tblMetaMst, Map<String, String> clmData,
            String[] keyName, boolean overwriteFlag, long recId, boolean appendFlag) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            writeRecord(dbAccess, tblMetaMst, clmData, keyName, overwriteFlag, recId, appendFlag);

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * テーブルメタ情報マスタをもとに、出力先を判断して、レコードを書き込む。
     * 
     * @param dbAccess
     * @param tblMetaMst
     * @param clmData
     * @param keyName
     * @param overwriteFlag
     * @param recId
     * @param appendFlag
     * @throws SQLException
     */
    private static void writeRecord(DBAccess dbAccess, TblMetaMstBean tblMetaMst, Map<String, String> clmData,
            String[] keyName, boolean overwriteFlag, long recId, boolean appendFlag) throws SQLException {

        if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_NORMAL_REAL_TBL)) {
            // TODO kurinami 【未実装】 エラー recidが指定された場合、
            writeRealRecord(dbAccess, tblMetaMst.getTblSchema(), tblMetaMst.getTblName(), clmData, keyName,
                    overwriteFlag);
        } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_NORMAL_VIRTUAL_TBL)) {
            writeVirtualRecord(dbAccess, tblMetaMst.getSiteId(), tblMetaMst.getTblId(), clmData, keyName,
                    overwriteFlag, recId, appendFlag, false,-1);
        } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_ORDER_REAL_TBL)) {
            // TODO kurinami 【未実装】 エラー recidが指定された場合、
            writeRealRecord(dbAccess, tblMetaMst.getTblSchema(), tblMetaMst.getTblName(), clmData, keyName,
                    overwriteFlag);
        } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_ORDER_VIRTUAL_TBL)) {
            writeVirtualRecord(dbAccess, tblMetaMst.getSiteId(), tblMetaMst.getTblId(), clmData, keyName,
                    overwriteFlag, recId, appendFlag, true,-1);
        } else if (tblMetaMst.getTblType().equals(TblMetaMstBean.TYPE_FORM_VIRTUAL_TBL)) {
            writeVirtualRecord(dbAccess, tblMetaMst.getSiteId(), tblMetaMst.getTblId(), clmData, keyName,
                    overwriteFlag, recId, appendFlag, false,-1);
        } else {
            String message = MessageFormat.format("不明なテーブルタイプ({0})です。[site_id:{1}][tbl_id:{2}]", tblMetaMst
                    .getTblType(), tblMetaMst.getSiteId(), tblMetaMst.getTblId());
            throw new SQLException(message);
        }

    }

    /**
     * 挿入か更新かを判断して、固定テーブルにレコードを書き込む。
     * 
     * @param dbAccess
     * @param schemaName
     * @param tableName
     * @param clmData
     * @param keyName
     * @param overwriteFlag
     * @throws SQLException
     */
    private static void writeRealRecord(DBAccess dbAccess, String schemaName, String tableName,
            Map<String, String> clmData, String[] keyName, boolean overwriteFlag) throws SQLException {

        String rowId = getRowId(dbAccess, schemaName, tableName, keyName, clmData);

        if (rowId == null) {
            insertReal(dbAccess, schemaName, tableName, clmData);
        } else if (overwriteFlag) {
            updateReal(dbAccess, schemaName, tableName, rowId, clmData);
        } else {
            throw new SQLException("キーが重複しています。");
        }

    }

    /**
     * 固定テーブルにレコードを挿入する。
     * 
     * @param dbAccess
     * @param schemaName
     * @param tableName
     * @param clmData
     * @throws SQLException
     */
    private static void insertReal(DBAccess dbAccess, String schemaName, String tableName, Map<String, String> clmData)
            throws SQLException {

        // 固定テーブル挿入用sqlを組み立てる。
        StringBuffer sb = new StringBuffer();
        sb.append("insert into " + schemaName + "." + tableName + "(");
        String sep = "";
        for (Map.Entry<String, String> entry : clmData.entrySet()) {
            sb.append(sep);
            sb.append(entry.getKey());
            sep = ", ";
        }
        sb.append(") ");
        sb.append("values(");
        sep = "";
        for (int i = 0; i < clmData.size(); i++) {
            sb.append(sep);
            sb.append("?");
            sep = ", ";
        }
        sb.append(") ");

        // 固定テーブルにデータを挿入する。
        dbAccess.prepareStatement(sb.toString());
        int i = 0;
        for (Map.Entry<String, String> entry : clmData.entrySet()) {
            dbAccess.setString(++i, entry.getValue());
        }
        dbAccess.executeUpdate();
    }

    /**
     * 固定テーブルのレコードを更新する。
     * 
     * @param dbAccess
     * @param schemaName
     * @param tableName
     * @param rowId
     * @param clmData
     * @throws SQLException
     */
    private static void updateReal(DBAccess dbAccess, String schemaName, String tableName, String rowId,
            Map<String, String> clmData) throws SQLException {

        // 固定テーブル更新用sqlを組み立てる。
        StringBuffer sb = new StringBuffer();
        sb.append("update " + schemaName + "." + tableName + " set ");
        String sep = "";
        for (Map.Entry<String, String> entry : clmData.entrySet()) {
            sb.append(sep);
            sb.append(entry.getKey() + " = ?");
            sep = ", ";
        }
        sb.append(" where rowid = ? ");

        // 固定テーブルのデータを更新する。
        dbAccess.prepareStatement(sb.toString());
        int i = 0;
        for (Map.Entry<String, String> entry : clmData.entrySet()) {
            dbAccess.setString(++i, entry.getValue());
        }
        dbAccess.setString(++i, rowId);
        dbAccess.executeUpdate();
    }

    /**
     * 挿入か更新かを判断して、汎用仮想テーブルカラムデータ/オーダー情報可変部カラムデータにレコードを書き込む。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @param clmData
     * @param keyName
     * @param overwriteFlag
     * @param recId
     * @param appendFlag
     * @param orderTblFlag
     * @throws SQLException
     */
    private static void writeVirtualRecord(DBAccess dbAccess, int siteId, String tblId, Map<String, String> clmData,
            String[] keyName, boolean overwriteFlag, long recId, boolean appendFlag, boolean orderTblFlag,int fetchSize)
            throws SQLException {

        if (recId == 0l) {
            recId = getRecId(dbAccess, siteId, tblId, keyName, clmData, orderTblFlag);

            if (recId == 0l) {
                insertVirtual(dbAccess, siteId, tblId, clmData, orderTblFlag);
            } else if (overwriteFlag) {
                updateVirtual(dbAccess, siteId, tblId, recId, clmData, orderTblFlag);
            } else {
                throw new SQLException("キーが重複しています。");
            }
        } else {
            boolean exist = getList(dbAccess, siteId, tblId, new Long(recId), new Long(recId), null, null, null, false,fetchSize)
                    .size() > 0;

            if (exist) {
                updateVirtual(dbAccess, siteId, tblId, recId, clmData, orderTblFlag);
            } else if (appendFlag) {
                insertVirtual(dbAccess, siteId, tblId, clmData, orderTblFlag);
            } else {
                String message = MessageFormat.format("対象のレコードが存在しません。[rec_id:{0}]", recId);
                throw new SQLException(message);
            }
        }

    }

    /**
     * 仮想テーブルにレコードを挿入する。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @param clmData
     * @param orderTblFlag
     * @throws SQLException
     */
    private static void insertVirtual(DBAccess dbAccess, int siteId, String tblId, Map<String, String> clmData,
            boolean orderTblFlag) throws SQLException {

        List<ClmMetaMstBean> clmMetaMstList = MetaDb.getClmMetaMstList(siteId, tblId);
        long recId = getNextRecId(dbAccess, siteId, tblId);

        // レコードメタ情報を挿入する。
        dbAccess.prepareStatement(INSERT_REC_META_DATA);
        int i = 0;
        dbAccess.setInt(++i, siteId);
        dbAccess.setString(++i, tblId);
        dbAccess.setLong(++i, recId);
        dbAccess.executeUpdate();

        // 汎用仮想テーブルカラムデータを挿入する。
        dbAccess.prepareStatement(!orderTblFlag ? INSERT_CLM_DATA : INSERT_ORDER_INFO_CLM_DATA);
        for (ClmMetaMstBean clmMetaMst : clmMetaMstList) {
            insertVirtualClmData(dbAccess, siteId, tblId, recId, clmMetaMst.getClmId(), clmMetaMst.getSortNum(),
                    clmData.get(clmMetaMst.getClmId()));
        }
    }

    /**
     * 1項目分のデータを挿入する。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @param recId
     * @param clmId
     * @param sortNum
     * @param data
     * @return
     * @throws SQLException
     */
    private static int insertVirtualClmData(DBAccess dbAccess, int siteId, String tblId, long recId, String clmId,
            int sortNum, String data) throws SQLException {
        int i = 0;
        dbAccess.setInt(++i, siteId);
        dbAccess.setString(++i, tblId);
        dbAccess.setLong(++i, recId);
        dbAccess.setString(++i, clmId);
        dbAccess.setInt(++i, sortNum);

        if (PhoenixUtil.isEmpty(data)) {
            dbAccess.setNull(++i);
            dbAccess.setNull(++i);
        } else if (PhoenixUtil.getByteLength(data) <= KEY_DATA_LENGTH) {
            dbAccess.setString(++i, data);
            dbAccess.setNull(++i);
        } else {
            dbAccess.setString(++i, PhoenixUtil.getLeft(data, KEY_DATA_LENGTH));
            dbAccess.setString(++i, data);
        }

        return dbAccess.executeUpdate();
    }

    /**
     * 仮想テーブルのレコードを更新する。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @param recId
     * @param clmData
     * @param orderTblFlag
     * @throws SQLException
     */
    private static void updateVirtual(DBAccess dbAccess, int siteId, String tblId, long recId,
            Map<String, String> clmData, boolean orderTblFlag) throws SQLException {

        List<ClmMetaMstBean> clmMetaMstList = MetaDb.getClmMetaMstList(siteId, tblId);

        // レコードメタ情報を更新する。
        dbAccess.prepareStatement(UPDATE_REC_META_DATA);
        int i = 0;
        dbAccess.setInt(++i, siteId);
        dbAccess.setString(++i, tblId);
        dbAccess.setLong(++i, recId);
        dbAccess.executeUpdate();

        for (ClmMetaMstBean clmMetaMst : clmMetaMstList) {
            if (clmData.containsKey(clmMetaMst.getClmId())) {
                // 汎用仮想テーブルカラムデータを更新する。
                dbAccess.prepareStatement(!orderTblFlag ? UPDATE_CLM_DATA : UPDATE_ORDER_INFO_CLM_DATA);
                int count = updateVirtualClmData(dbAccess, siteId, tblId, recId, clmMetaMst.getClmId(), clmData
                        .get(clmMetaMst.getClmId()));
                if (count == 0) {
                    // 更新できなかった場合は、挿入する。
                    dbAccess.prepareStatement(!orderTblFlag ? INSERT_CLM_DATA : INSERT_ORDER_INFO_CLM_DATA);
                    insertVirtualClmData(dbAccess, siteId, tblId, recId, clmMetaMst.getClmId(),
                            clmMetaMst.getSortNum(), clmData.get(clmMetaMst.getClmId()));
                }

            }
        }
    }

    /**
     * 1項目分のデータを更新する。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @param recId
     * @param clmId
     * @param data
     * @return
     * @throws SQLException
     */
    private static int updateVirtualClmData(DBAccess dbAccess, int siteId, String tblId, long recId, String clmId,
            String data) throws SQLException {
        int i = 0;

        if (PhoenixUtil.isEmpty(data)) {
            dbAccess.setNull(++i);
            dbAccess.setNull(++i);
        } else if (PhoenixUtil.getByteLength(data) <= KEY_DATA_LENGTH) {
            dbAccess.setString(++i, data);
            dbAccess.setNull(++i);
        } else {
            dbAccess.setString(++i, PhoenixUtil.getLeft(data, KEY_DATA_LENGTH));
            dbAccess.setString(++i, data);
        }

        dbAccess.setInt(++i, siteId);
        dbAccess.setString(++i, tblId);
        dbAccess.setLong(++i, recId);
        dbAccess.setString(++i, clmId);

        return dbAccess.executeUpdate();

    }

}
