/**
 * 
 */
package jp.co.webcrew.login.common.point;

import java.text.MessageFormat;

import jp.co.webcrew.login.common.util.DateUtil;

/**
 * @author kazuto.yano
 *
 */
public class TestPoint 
{
	public static void main(String[] args)
	throws Exception
	{
		String guid="5294371";
		long spendPoint=100;
		boolean canSpend=PointUtilRenewal.canSpendPoint(guid, spendPoint);
		 
		System.out.println(MessageFormat.format("guid:{0}/point:{1}/canSpend:{2}", guid,spendPoint,canSpend));
		
		
		
		long currentPoint=PointUtilRenewal.getCurrentPoint(guid);
		
		System.out.println(MessageFormat.format("guid:{0}/point:{1}", guid,currentPoint));
		
		
		long chargePoint=6800;
		
		PointUtilRenewal.chargeWithTxControl(guid, chargePoint, 1, 10230, -1, "", "test-PointUtilRenewal", DateUtil.currentDateTime(), false, true, false);
		/*
		spendPoint=1000;
		
		PointUtilRenewal.spend(guid, spendPoint, 1, 10230, 0, null, DateUtil.currentDateTime(), false, true);
		*/
		
		
		long pointSnapshot=PointUtilRenewal.getPointFindByDateTime("5294371", "20110614140715");
		
		System.out.println("snapshot:"+pointSnapshot);
		
		
		ThreadObject th1=new ThreadObject();
		ThreadObject th2=new ThreadObject();
		
		th1.spendPoint=3000;
		th2.spendPoint=4500;
		th1.guid=guid;
		th2.guid=guid;
		th1.start();
		th2.start();
		
		while(true)
		{
			if(!th1.isAlive() && !th2.isAlive())
			{
				try
				{
					Thread.sleep(1000);
				}catch(Exception exc){}
				
				break;
			}
			
		}
		
		currentPoint=PointUtilRenewal.getCurrentPoint(guid);
		
		System.out.println(MessageFormat.format("guid:{0}/point:{1}", guid,currentPoint));
		
	}
	
	static class ThreadObject extends Thread
	{
		public long spendPoint;
		public String guid;
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() 
		{
			try
			{
				System.out.println("#1#"+spendPoint);
				PointUtilRenewal.spendWithTxControl(guid, spendPoint, 1, 10230, 0, null, DateUtil.currentDateTime(), false, true);
				System.out.println("#2#"+spendPoint);
			}
			catch(Exception exc)
			{
				System.out.println("#3#"+spendPoint);
				exc.printStackTrace();
			}
		}
		
	}
	
	
}
