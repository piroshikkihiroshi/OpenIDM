package jp.co.webcrew.filters.filters.session;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.filters.util.DBAccessUtil;

/**
 * クッキーエラー時のログを管理するdbクラス。
 * 
 * @author tobe
 */
public class CookieErrorLogDb {

	/** クッキーエラーログ記録用SQL */
	private static final String COOKIE_ERROR_INSERT = "insert into cookie_error_log (seq, user_agent, insert_date) values(seq_cookie_error_log.nextval, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'))";

	/**
	 * クッキーエラーログを新規登録する。
	 * 
	 * @param ua ユーザエージェント
	 * @throws SQLException
	 */
	public static void insert(String ua)
			throws SQLException {

		DBAccess dbAccess = null;
		try {
		    
		    // 登録フラグ ※Issue0061655: cookieエラーログの集計再開（2013.10.22）
            String cookieErrorInsertFlg = SystemPropertiesDb.getInstance().get("COOKIE_ERROR_INSERT_FLG");
            if (!"1".equals(cookieErrorInsertFlg)) {
                return;
            }
		    
			dbAccess = DBAccessUtil.getLogDB();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// cookieエラーの記録処理を行う。
			dbAccess.prepareStatement(COOKIE_ERROR_INSERT);
			dbAccess.setString(1, ua);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

}
