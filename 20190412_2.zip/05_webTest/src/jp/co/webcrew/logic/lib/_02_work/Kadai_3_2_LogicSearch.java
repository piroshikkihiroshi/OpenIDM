package jp.co.webcrew.logic.lib._02_work;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.BindLogicStdStatus;
import jp.co.webcrew.phoenix.logic.ItemConvLogicStatus;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.util.PhoenixRequestContext;
import net.arnx.jsonic.JSON;

public class Kadai_3_2_LogicSearch extends SstagDynamicLogic {

	Logger logger = Logger.getLogger(Kadai_3_2_LogicSearch.class);

	//Trainingの検索ロジック
	@Override
	public BindLogicStdStatus stdLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam, List<String> userParam,
			FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo) {

		logger.info("PostInfo:" + JSON.encode(postInfo.postItemMap));

		//member変数
		int intSiteId = 91076;
		PhoenixDBAccess objDbAccess = null;
		ResultSet objRs = null;
		int intCnt = 0;
		String strOutJson = "";
		//検索対象初期化
		String strORDER_ID = "";
		String strNAME_KANJI_1="";
		String strNAME_KANJI_2="";
		String strNAME_KANA_1="";
		String strNAME_KANA_2="";
		String strEMAIL="";
		String strTEL="";
		String strCONTACT="";
		int intPrepareCnt = 0;

		if (postInfo.postItemMap.containsKey("ORDER_ID")) { strORDER_ID = postInfo.postItemMap.get("ORDER_ID")[0];}
		if (postInfo.postItemMap.containsKey("NAME_KANJI_1")) { strNAME_KANJI_1 = postInfo.postItemMap.get("NAME_KANJI_1")[0];}
		if (postInfo.postItemMap.containsKey("NAME_KANJI_2")) { strNAME_KANJI_2 = postInfo.postItemMap.get("NAME_KANJI_2")[0];}
		if (postInfo.postItemMap.containsKey("NAME_KANA_1")) { strNAME_KANA_1 = postInfo.postItemMap.get("NAME_KANA_1")[0];}
		if (postInfo.postItemMap.containsKey("NAME_KANA_2")) { strNAME_KANA_2 = postInfo.postItemMap.get("NAME_KANA_2")[0];}
		if (postInfo.postItemMap.containsKey("EMAIL")) { strEMAIL = postInfo.postItemMap.get("EMAIL")[0];}
		if (postInfo.postItemMap.containsKey("TEL")) { strTEL = postInfo.postItemMap.get("TEL")[0];}
		if (postInfo.postItemMap.containsKey("CONTACT")) { strCONTACT = postInfo.postItemMap.get("CONTACT")[0];}

//		logger.info(strORDER_ID);
//		logger.info(strNAME_KANJI_1);
//		logger.info(strNAME_KANJI_2);
//		logger.info(strNAME_KANA_1);
//		logger.info(strNAME_KANA_2);
//		logger.info(strEMAIL);
//		logger.info(strTEL);
//		logger.info(strCONTACT);



		Kadai_3_2_UserBean objBean = null;
		List<Kadai_3_2_UserBean> listBean = new ArrayList<Kadai_3_2_UserBean>();

		//sql作成
		String strSql = "";
		strSql += "SELECT  ";
		strSql += "  ORDER_ID";
		strSql += "  , NAME_KANJI_1";
		strSql += "  , NAME_KANJI_2";
		strSql += "  , NAME_KANA_1";
		strSql += "  , NAME_KANA_2";
		strSql += "  , EMAIL";
		strSql += "  , TEL";
		strSql += "  , CONTACT ";
		strSql += "  , DELETE_FLG ";
		strSql += "FROM ";
		strSql += " \"TATSUYA.UEDA\".ORDER_INFO ";
		strSql += " WHERE DELETE_FLG = 0 ";

		//UPDATE_TGT
		if (!strORDER_ID.equals("")) {
			strSql += " AND ORDER_ID = ? ";
		} //if

		try {
			objDbAccess = new PhoenixDBAccess(intSiteId);
			objDbAccess.setAutoCommit(false); //一応明示的にオートコミット切る
			objDbAccess.prepareStatement(strSql);
			if (!strORDER_ID.equals("")) {
				objDbAccess.setInt(1, Integer.parseInt(strORDER_ID));
			} //if
			objRs = objDbAccess.executeQuery();
			while (objRs.next()) {
				objBean = new Kadai_3_2_UserBean();
				objBean.setORDER_ID(objRs.getInt("ORDER_ID"));
				objBean.setNAME_KANJI_1(objRs.getString("NAME_KANJI_1"));
				objBean.setNAME_KANJI_2(objRs.getString("NAME_KANJI_2"));
				objBean.setNAME_KANA_1(objRs.getString("NAME_KANA_1"));
				objBean.setNAME_KANA_2(objRs.getString("NAME_KANA_2"));
				objBean.setEMAIL(objRs.getString("EMAIL"));
				objBean.setTEL(objRs.getString("TEL"));
				listBean.add(objBean);
				intCnt++;
			} //while
		} catch (Exception e) {
			logger.error("例外発生", e);
		} finally {
			PhoenixDBAccess.close(objRs);
			PhoenixDBAccess.close(objDbAccess);
		} //try Exception

		//$$変数の埋め込み
		logger.info("logic埋め込みtest");
		HttpServletRequest request = PhoenixRequestContext.getServletRequest();
		KeywordReplacer.addDynamicKeyword(request, "Kadai_3_2_LogicSearch", JSON.encode(listBean));
		logger.info("logic埋め込み成功");

		//statusは必須
		BindLogicExtStatus objStatus = new BindLogicExtStatus();

		return objStatus;

	} // stdLogic

	@Override
	public BindLogicExtStatus validationLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public JudgementLogicStatus judgementLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public ItemConvLogicStatus itemConvLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String sub1,
			String sub2, String result) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
