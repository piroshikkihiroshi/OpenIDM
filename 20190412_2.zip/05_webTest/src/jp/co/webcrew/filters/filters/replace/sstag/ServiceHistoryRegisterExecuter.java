package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.login.common.db.ServiceHist;
import jp.co.webcrew.login.common.util.DateUtil;

/**
 * サービス利用履歴を登録するExecuterクラス。
 * 
 */
public class ServiceHistoryRegisterExecuter extends SSTagExecuter {

    /** ロガー */
    private static final Logger log = Logger.getLogger(ServiceHistoryRegisterExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map, javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse)
     */
    public String execute(Map parameterMap, HttpServletRequest request, HttpServletResponse response) {

        try {
            int siteId = SiteMstDb.getInstance().getSiteId(request.getRequestURL().toString());
            boolean isLogin = SessionFilterUtil.isLogined(request);

            // ログイン状態だけ登録する
            if (isLogin) {
                // requestからGUIDを取得
                String guid = SessionFilterUtil.getGuid(request);

                // sstagのパラメータを取得する。
                String serviceId = ValueUtil.nullToStr(parameterMap.get("service_id"));
                String subCode = ValueUtil.nullToStr(parameterMap.get("sub_code"));

                // 現在日付時刻を取得
                String current_datatime = DateUtil.currentDateTime();

                // guidを確認する。
                if (!SessionFilterUtil.isValidGuid(guid)) {
                    // パラメータエラーとする
                    log.error("パラメータエラー パラメータ[guid:" + guid + "]が不正です。");
                    return "";
                }
                // serviceIdを確認する。
                if (ValueUtil.nullToStr(serviceId).length() == 0) {
                    // パラメータエラーとする
                    log.error("パラメータエラー パラメータ[serviceId:" + serviceId + "]が不正です。");
                    return "";
                }
                // siteIdを確認する。
                if (siteId == -1) {
                    // パラメータエラーとする
                    log.error("RequestURL[" + request.getRequestURL() + "]がsite_recog_mstに登録されていません。");
                }
                // service_datatimeを確認する。
                if (ValueUtil.nullToStr(current_datatime).length() == 0) {
                    // パラメータエラーとする
                    log.error("現在日付時刻[current_datatime:" + current_datatime + "]を取得失敗しました。");
                    return "";
                }

                // 登録フラグ
                boolean register_flg = false;
                // DBから最近同じサービスの利用日時を取得する
                String latest_service_datatime = ServiceHist.getLatestServiceDateTime(guid, serviceId, subCode);
                // 登録してない場合
                if (latest_service_datatime == null) {
                    register_flg = true;
                } else {
                    // DBの利用日時により制限時間ズレた日時を取得する
                    String offset_service_datatime = DateUtil.getDateTime(latest_service_datatime, getServiceUsePeriod());
                    // 現在日付時刻は制限時間ズレた日時と判断する。現在日付時刻のほうが大きい場合再登録可にする
                    if (Long.parseLong(current_datatime) > Long.parseLong(offset_service_datatime)) {
                        register_flg = true;
                    }
                }

                // 登録可
                if (register_flg) {
                    // サービス利用履歴登録
                    int regCnt = registerServiceHistory(guid, serviceId, subCode, siteId, current_datatime);
                }

            }

        } catch (Exception e) {
            log.error("予期せぬエラー。Error in function ServiceHistoryRegisterExecuter#execute", e);
        }

        return "";

    }

    // サービス利用履歴登録
    private int registerServiceHistory(String guid, String serviceId, String subCode, int siteId, String service_datatime) {
        ServiceHist service = new ServiceHist(guid);
        service.set(ServiceHist.SERVICE_ID, serviceId);
        service.set(ServiceHist.SUB_CODE, subCode);
        service.set(ServiceHist.SITE_ID, String.valueOf(siteId));
        service.set(ServiceHist.SERVICE_DATETIME, service_datatime);
        // サービス利用履歴登録
        int cnt = ServiceHist.insertToDB(service);
        return cnt;
    }

    /*
     * サービス利用制限期間を取得する
     * 
     * @return 秒
     */
    private String getServiceUsePeriod() {
        try {
            int serviceUsePeriod = SystemPropertiesDb.getInstance().getSecondValue("SERVICE_USE_PERIOD_LIMIT");
            return String.valueOf(serviceUsePeriod);

        } catch (Exception e) {
            log.error("サービス利用制限期間を取得出来ませんでした", e);
        }

        return "0";
    }
}
