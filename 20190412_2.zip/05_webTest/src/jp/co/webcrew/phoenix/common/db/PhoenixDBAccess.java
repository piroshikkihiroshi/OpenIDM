package jp.co.webcrew.phoenix.common.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;

/**
 * phoenixプロジェクト用のカスタムDBAccessクラス。<br>
 * siteIdをもとに参照先スキーマを自動で識別する。<br>
 *
 * @author kurinami
 */
public class PhoenixDBAccess extends DBAccess {

    /** 接続用の識別子 */
    private static final String NAME = "phoenix";

    /** スキーマ名変換用のキーワード */
    private static final String REPLACE_SCHEMA_KEY = "(schema_name)";

    /** スキーマ名 */
    private String phoenixSchema = null;

    /**
     * コンストラクタ
     *
     * @param siteId
     * @throws SQLException
     */
    public PhoenixDBAccess(int siteId) throws SQLException {
        super(NAME);
        phoenixSchema = SiteMstDb.getInstance().getSchema(siteId);
    }

    /*
     * (non-Javadoc)
     *
     * @see jp.co.webcrew.dbaccess.db.DBAccess#executeQuery(java.lang.String)
     */
    @Override
    public ResultSet executeQuery(String sql) throws SQLException {
        sql = replaceSchema(sql);
        return super.executeQuery(sql);
    }

    /*
     * (non-Javadoc)
     *
     * @see jp.co.webcrew.dbaccess.db.DBAccess#executeUpdate(java.lang.String)
     */
    @Override
    public int executeUpdate(String sql) throws SQLException {
        sql = replaceSchema(sql);
        return super.executeUpdate(sql);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * jp.co.webcrew.dbaccess.db.DBAccess#prepareStatement(java.lang.String,
     * int, int)
     */
    @Override
    public void prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
        sql = replaceSchema(sql);
        super.prepareStatement(sql, resultSetType, resultSetConcurrency);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * jp.co.webcrew.dbaccess.db.DBAccess#prepareStatement(java.lang.String)
     */
    @Override
    public void prepareStatement(String sql) throws SQLException {
        sql = replaceSchema(sql);
        super.prepareStatement(sql);
    }

    /**
     * sql上のスキーマ名部分を、実際のスキーマ名に変換する。
     *
     * @param sql
     * @return
     */
    private String replaceSchema(String sql) {
        return ValueUtil.replace(sql, REPLACE_SCHEMA_KEY, phoenixSchema);
    }

    /**
     * スキーマ名を返す。
     *
     * @return
     */
    public String getPhoenixSchema() {
        return phoenixSchema;
    }

}
