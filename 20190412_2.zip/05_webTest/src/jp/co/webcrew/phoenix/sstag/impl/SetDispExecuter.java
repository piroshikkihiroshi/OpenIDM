package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.sstag.util.ReplaceUtil;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * スクリーニング結果の出力を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class SetDispExecuter extends SSTagExecuter {

    /** パラメータ名：スクリーニング結果が入っている一意なID(必須) */
    private static final String RESULT_ID_PARAM_KEY = "result_id";

    /** パラメータ名：スクリーニング結果内の set名(必須) */
    private static final String SET_ID_PARAM_KEY = "set_id";

    /** パラメータ名：出力するレコードの先頭オフセット */
    private static final String OFFSET_PARAM_KEY = "offset";

    /** パラメータ名：出力する（最大の）レコード数 */
    private static final String LIMIT_PARAM_KEY = "limit";

    /** パラメータ名：繰り返し前のヘッダ部分に相当するHTML */
    private static final String HEADER_PARAM_KEY = "header";

    /** パラメータ名：繰り返し後のフッタ部分に相当するHTML */
    private static final String FOOTER_PARAM_KEY = "footer";

    /** パラメータ名：繰り返し出力用HTML */
    private static final String HTML_PARAM_KEY = "html";

    /** パラメータ名：偶数時に出力するHTML */
    private static final String EVEN_PARAM_KEY = "even";

    /** パラメータ名：奇数時に出力するHTML */
    private static final String ODD_PARAM_KEY = "odd";

    /** パラメータ名：初回のみ出力するHTML */
    private static final String FIRST_PARAM_KEY = "first";

    /** パラメータ名：最終回のみ出力するHTML */
    private static final String LAST_PARAM_KEY = "last";

    /** 置換変数名：カレントセットの最大繰り返し数 */
    private static final String SIZE_VAL_KEY = "size";

    /** 置換変数名：カレントの繰り返し回数 (1～) */
    private static final String COUNT_VAL_KEY = "count";

    /** 置換変数名：偶数・奇数の各回ごとのHTML */
    private static final String EVEN_ODD_VAL_KEY = "even_odd";

    /** 置換変数名：firstで指定されたHTML */
    private static final String FIRST_VAL_KEY = "first";

    /** 置換変数名：last で指定されたHTML */
    private static final String LAST_VAL_KEY = "last";

    /** 置換変数名：スクリーニング結果表示用名称 */
    private static final String SET_NAME_VAL_KEY = "set.{0}.name";

    /** 置換変数名：スクリーニング結果値 */
    private static final String SET_VALUE_VAL_KEY = "set.{0}.value";

    /** 置換変数名：スクリーニング結果表示用値 */
    private static final String SET_DISP_VAL_KEY = "set.{0}.disp";

    /** 置換変数名：スクリーニング結果画像URL */
    private static final String SET_IMAGE_VAL_KEY = "set.{0}.image";

    /** 置換変数名：スクリーニング結果URL値 */
    private static final String SET_URL_VAL_KEY = "set.{0}.url";

    /** 置換変数名：スクリーニング結果その他値 */
    private static final String SET_OPTION_VAL_KEY = "set.{0}.option";

    /** 置換変数名：スクリーニング結果その他の数 */
    private static final String SET_COUNT_VAL_KEY = "set.{0}.count";

    /** ロガー */
    private static final Logger log = Logger.getLogger(SetDispExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#getExcludeParamList
     * ()
     */
    @SuppressWarnings("unchecked")
    @Override
    protected List getExcludeParamList() {
        return Arrays.asList(HTML_PARAM_KEY, HEADER_PARAM_KEY, FOOTER_PARAM_KEY);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { RESULT_ID_PARAM_KEY, SET_ID_PARAM_KEY, LIMIT_PARAM_KEY, HTML_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String resultId = ValueUtil.nullToStr(parameters.get(RESULT_ID_PARAM_KEY));
            String setId = ValueUtil.nullToStr(parameters.get(SET_ID_PARAM_KEY));
            int offset = ValueUtil.toint((String) parameters.get(OFFSET_PARAM_KEY));
            int limit = ValueUtil.toint((String) parameters.get(LIMIT_PARAM_KEY));
            String header = SstagUtil.getFileData(parameters.get(HEADER_PARAM_KEY), request, response);
            String footer = SstagUtil.getFileData(parameters.get(FOOTER_PARAM_KEY), request, response);
            String html = SstagUtil.getFileData(parameters.get(HTML_PARAM_KEY), request, response);
            String even = ValueUtil.nullToStr(parameters.get(EVEN_PARAM_KEY));
            String odd = ValueUtil.nullToStr(parameters.get(ODD_PARAM_KEY));
            String first = ValueUtil.nullToStr(parameters.get(FIRST_PARAM_KEY));
            String last = ValueUtil.nullToStr(parameters.get(LAST_PARAM_KEY));

            // offsetとlimitが指定されていない場合、
            if (offset <= 0) {
                offset = 1;
            }
            if (limit <= 0) {
                limit = 1;
            }

            // セッションストアで保持しているフォームデータを取得する。
            Map<String, Map<String, Object[]>> sResult = StoreUtil.getScreeningResult(request, resultId);
            if (sResult == null || PhoenixUtil.isEmpty(sResult.get(setId))) {
                return "";
            }

            Map<String, Object[]> resultSet = sResult.get(setId);

            // htmlを組み立てる。
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);

            // データの件数を数える。
            int size = 0;
            for (Map.Entry<String, Object[]> entry : resultSet.entrySet()) {
                Object[] resultItem = entry.getValue();
                for (int j = 1; !PhoenixUtil.isEmpty(resultItem) && j < resultItem.length; j++) {
                    List<String> list = (List<String>) resultItem[j];
                    if (!PhoenixUtil.isEmpty(list)) {
                        size = Math.max(size, list.size());
                    }
                }
            }

            // ヘッダ部分を出力する。
            pw.println(ReplaceUtil.getReplacedHeader(header, request, offset, limit, size));

            for (int i = offset; i <= offset + limit - 1 && i <= size; i++) {

                // 項目自体には関係しない置換変数の設定。
                Map<String, String> replaceMap = new HashMap<String, String>();
                replaceMap.put(SIZE_VAL_KEY, Integer.toString(size));
                replaceMap.put(COUNT_VAL_KEY, Integer.toString(i));
                replaceMap.put(EVEN_ODD_VAL_KEY, (i % 2 == 0 ? even : odd));
                replaceMap.put(FIRST_VAL_KEY, (i == offset ? first : ""));
                replaceMap.put(LAST_VAL_KEY, (i >= offset + limit - 1 || i >= size ? last : ""));

                // 項目に関する置換変数の設定。
                setSetReplaceVal(replaceMap, resultSet, i - 1);

                // htmlの出力。
                pw.println(ReplaceUtil.getReplacedHtml(html, replaceMap));
            }

            // フッタ部分を出力する。
            pw.println(ReplaceUtil.getReplacedHeader(footer, request, offset, limit, size));

            pw.flush();
            return sw.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * スクリーニング結果に関する置換変数を設定する。
     * 
     * @param replaceMap
     * @param resultSet
     * @param index
     */
    private void setSetReplaceVal(Map<String, String> replaceMap, Map<String, Object[]> resultSet, int index) {

        for (Map.Entry<String, Object[]> entry : resultSet.entrySet()) {
            String key = entry.getKey();
            Object[] resultItem = entry.getValue();

            replaceMap.put(MessageFormat.format(SET_NAME_VAL_KEY, key), getName(resultItem));
            replaceMap.put(MessageFormat.format(SET_VALUE_VAL_KEY, key), getValue(resultItem,
                    Constants.VALUE_ITEM_INDEX, index));
            replaceMap.put(MessageFormat.format(SET_DISP_VAL_KEY, key), getValue(resultItem, Constants.DISP_ITEM_INDEX,
                    index));
            replaceMap.put(MessageFormat.format(SET_IMAGE_VAL_KEY, key), getValue(resultItem,
                    Constants.IMAGE_ITEM_INDEX, index));
            replaceMap.put(MessageFormat.format(SET_URL_VAL_KEY, key), getValue(resultItem, Constants.URL_ITEM_INDEX,
                    index));

            if (resultItem != null) {
                for (int i = 0; i < resultItem.length - Constants.OPTION_ITEM_INDEX; i++) {
                    replaceMap.put(MessageFormat.format(SET_OPTION_VAL_KEY, key) + "." + (i + 1), getValue(resultItem,
                            Constants.OPTION_ITEM_INDEX + i, index));
                }
                replaceMap.put(MessageFormat.format(SET_COUNT_VAL_KEY, key), Integer.toString(resultItem.length
                        - Constants.OPTION_ITEM_INDEX));
            } else {
                replaceMap.put(MessageFormat.format(SET_COUNT_VAL_KEY, key), "0");
            }
        }

    }

    private String getName(Object[] resultItem) {
        if (PhoenixUtil.isEmpty(resultItem)) {
            return "";
        }
        String setName = (String) (resultItem.length > Constants.NAME_ITEM_INDEX ? resultItem[Constants.NAME_ITEM_INDEX]
                : "");
        return ValueUtil.nullToStr(setName);
    }

    @SuppressWarnings("unchecked")
    private String getValue(Object[] resultItem, int resultItemIndex, int index) {
        if (PhoenixUtil.isEmpty(resultItem)) {
            return "";
        }
        List<String> setValues = (List<String>) (resultItem.length > resultItemIndex ? resultItem[resultItemIndex]
                : null);
        String result = (!PhoenixUtil.isEmpty(setValues) && index < setValues.size() ? ValueUtil.nullToStr(setValues
                .get(index)) : "");
        return result;
    }
}
