//C:\Workspace\webcrew_filters\src\java\jp\co\webcrew\filters\filters\replace\sstag
package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.HashMap;
import java.util.Map;

public class RowData  {
    private Long   lngRecId;
    Map<String , String> mapColData;
    String strUpDatetime;
    
    public void set (String strColName , String strKeyData , String strLobData , String strUpdatetime) {
        if (strLobData == null || strLobData.length() == 0) {
            getColData().put(strColName, strKeyData);
        } else {
            getColData().put(strColName, strLobData);
        }
        if (strUpdatetime != null) 
        {
            if (strUpDatetime == null) {
                strUpDatetime = strUpdatetime;
            }
        }
    }

    public void set (String strColName , String strKeyData , String strLobData) {
        set (strColName , strKeyData , strLobData , null);
    }

    
    public String get(String strKey) {
        return getColData().get(strKey);
    }
    
    public Map<String , String > getColData() 
    {
        if (mapColData == null) {
            mapColData = new HashMap<String , String>();
        }
        return mapColData;
    }
    
    public String getUpdatetime() {
        return strUpDatetime;
    }
    
    public Long getRecId() {
        return this.lngRecId;
    }
    
    public void setRecId(Long lngRecId) {
        this.lngRecId = lngRecId;
    }
}