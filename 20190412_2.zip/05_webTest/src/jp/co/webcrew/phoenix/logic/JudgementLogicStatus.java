package jp.co.webcrew.phoenix.logic;

/**
 * 条件判断ロジックの結果を保持するstatusクラス。
 * 
 * @author kurinami
 */
public class JudgementLogicStatus extends BindLogicStdStatus {

    /** true =条件判断は TRUE となる false=条件判断は FALSE となる */
    public boolean judge;

}
