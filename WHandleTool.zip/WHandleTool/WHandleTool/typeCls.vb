﻿Public Class typeCls
    Public tgtVal As String
    Public tgtStatus As Long
    Public tgtRow As Long
    Public tgtClm As Long
    Public actStatus As String
End Class
