package jp.co.webcrew.login.common.db.step;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;



public class PetBangUserInfo extends StepUserInfoCommonDb{

	/** スキーマ名　*/
	public static final String SCHEMA = "PETBANG"; 
	/** テーブル名　*/
	public static final String TABLE = "USER_INFO"; 
	/** ORDER_HIST.ORDER_TEXTに転送する文字列　*/
	public static final String ORDER_TEXT_CAPTION = "保険スクエアbang！/ペット保険";
	   /** ORDER_HIST.ORDER_TEXTに転送する文字列　*/
    public static final String ORDER_TEXT_CAPTION_ZUBAT = "ズバットペット保険";
	/** 法人向けサイトであるか否か   */
	public static final boolean CORPORATE_SERVICE_FLG = false;
	
	/** PCサイトＩＤ*/
    public static final String PC_SITE_ID = "1003";
    
    public static final String PC_SITE_ID_ZUBAT = "1017";
    
    /** ズバットモバイルサイトＩＤ*/
    public static final String PC_SITE_ID_ZUBAT_MB = "1018";
  
	/*
	 * USER_INFOの列名定義
	 */
	public static final String USER_ID = "USER_ID";
	public static final String NAME_KANJI_1 = "NAME_KANJI_1";
	public static final String NAME_KANJI_2 = "NAME_KANJI_2";
	public static final String NAME_KANA_1 = "NAME_KANA_1";
	public static final String NAME_KANA_2 = "NAME_KANA_2";
	public static final String ZIP = "ZIP";
	public static final String PREF_ID = "PREF_ID";
	public static final String ADDRESS_1 = "ADDRESS_1";
	public static final String ADDRESS_2 = "ADDRESS_2";
	public static final String ADDRESS_3 = "ADDRESS_3";
	public static final String ADDRESS_4 = "ADDRESS_4";
	public static final String EMAIL = "EMAIL";
	public static final String TEL = "TEL";
	public static final String BIRTH_DATE = "BIRTH_DATE";
	public static final String SEX_ID = "SEX_ID";

	public static final String OCCUPATION_ID = "OCCUPATION_ID";
	public static final String HONNIN_FLG = "HONNIN_FLG";
	public static final String PET_TOTAL = "PET_TOTAL";
	public static final String WC_PERMIT_FLG = "WC_PERMIT_FLG";
	public static final String LAST_UPDATE = "LAST_UPDATE";
	public static final String DELETE_DATE = "DELETE_DATE";
	public static final String FINISH_FLG = "FINISH_FLG";
	public static final String PROM_CODE = "PROM_CODE";
	public static final String CLIENT_IP_ADDRESS = "CLIENT_IP_ADDRESS";
	public static final String MOBILE_FLG = "MOBILE_FLG";
	public static final String LAST_STEP = "LAST_STEP";
	public static final String GUID = "GUID";
	public static final String PREF_NAME = "PREF_NAME";

 
	/** ロガー */
	private Logger log = Logger.getLogger(this.getClass());

	/**
	 * オブジェクト初期化
	 */
	public void doInit(){
		setSchema(SCHEMA);
		setTable(TABLE);
		setCorporateService(CORPORATE_SERVICE_FLG);
	}
	
	private PetBangUserInfo(){}

	/**
	 * コンストラクタ
	 * @param request
	 * @param siteId
	 */
	public PetBangUserInfo(HttpServletRequest request , String siteId ){
		setSiteId(siteId);
		setHttpRequest(request);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doCreateNewStepId(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	public void doCreateNewStepId(DBAccess db) throws SQLException{
		
		// petbangではuserIdのみ生成する
		String userId = "";
		ResultSet rs = null;
		try{
			String sql = "SELECT PETBANG.SEQ_USER_INFO_USER_ID.NEXTVAL  AS USERID FROM DUAL";
			
			db.prepareStatement(sql);
			rs = db.executeQuery();
			if (db.next(rs)) {
				userId = ValueUtil.nullToStr(rs.getString("USERID"));
			}
			
			setUserId(userId);
			setRequestId(userId);

		} catch(SQLException e){
			// 例外エラー
			log.error("シーケンス取得中にデータベースエラーが発生しました。",e);
			throw e;
			
		} finally {
			DBAccess.close(rs);
		}
	    
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doPrepareStepDatabase(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	protected void doPrepareStepDatabase(DBAccess db) throws SQLException{

		// stepのinitialCalculationsにおけるinsert処理と同じことをする
		// ただしログイン機能無しの時と異なり、コピーした会員情報もDB登録する
		
		try{
			
			// USER_INFOに一行作成
			DBUpdater inserter = new DBUpdater(SCHEMA + ".USER_INFO");
			inserter.addString(USER_ID, getUserId());
			inserter.addString(NAME_KANJI_1, trimGet(NAME_KANJI_1));
			inserter.addString(NAME_KANJI_2, trimGet(NAME_KANJI_2));
			inserter.addString(NAME_KANA_1, trimGet(NAME_KANA_1));
			inserter.addString(NAME_KANA_2, trimGet(NAME_KANA_2));
			inserter.addString(SEX_ID, trimGet(SEX_ID));
			inserter.addString(ZIP, trimGet(ZIP));
			inserter.addString(PREF_ID, trimGet(PREF_ID));
			inserter.addString(ADDRESS_1, trimGet(ADDRESS_1));
			inserter.addString(ADDRESS_2, trimGet(ADDRESS_2));
			inserter.addString(ADDRESS_3, trimGet(ADDRESS_3));
			inserter.addString(ADDRESS_4, trimGet(ADDRESS_4));
			inserter.addString(TEL, trimGet(TEL));
			inserter.addString(EMAIL, trimGet(EMAIL));
			inserter.addString(BIRTH_DATE, trimGet(BIRTH_DATE));
			inserter.addString(WC_PERMIT_FLG , trimGet(WC_PERMIT_FLG));
			inserter.addString(FINISH_FLG, "0"); //TODO
            // モバイルの場合はMOBILE_FLGを1に設定する。
            if(this.getSiteId().equals(PC_SITE_ID) || this.getSiteId().equals(PC_SITE_ID_ZUBAT)) {
                inserter.addString(MOBILE_FLG, null);
            } else {
                inserter.addString(MOBILE_FLG, "1");
            }
			inserter.addString(LAST_UPDATE, DateUtil.currentDbDateStr());
			inserter.addString(CLIENT_IP_ADDRESS, getRemoteAddr());
			inserter.addString(GUID, get(GUID));
			inserter.addString(PREF_NAME, trimGet(PREF_NAME));
			inserter.insert(db);

		
		} catch(SQLException e){
			// 例外エラー
			log.error("UserInfo,OrderInfoの新規レコード作成時にエラーが発生しました。",e);
			throw e;
		
		} finally {
			;
		}	
		
	}

	/**
	 * 会員情報とステップのユーザ情報に違いがあるか否かを判別する
	 * @return true 違いがある false 違いが無い
	 */
	public boolean doIsDifferentFromMemberMst(MemberMst member){
		if (! get (NAME_KANJI_1).equals(member.get(MemberMst.NAME1)) ) return true;
		if (! get (NAME_KANJI_2).equals(member.get(MemberMst.NAME2)) ) return true;
		if (! get (NAME_KANA_1).equals(member.get(MemberMst.FURI1)) ) return true;
		if (! get (NAME_KANA_2).equals(member.get(MemberMst.FURI2)) ) return true;
		if (! get (ZIP).equals(member.get(MemberMst.ZIP)) ) return true;
		if (! get (PREF_ID).equals(member.get(MemberMst.PREF_ID)) ) return true;
// change 080516 Takahashi バグ修正 --
		if (! get (PREF_NAME).equals(member.get(MemberMst.ADDR1)) ) return true;
		if (! get (ADDRESS_1).equals(member.get(MemberMst.ADDR2)) ) return true;
		if (! get (ADDRESS_2).equals(member.get(MemberMst.ADDR3)) ) return true;
		if (! get (ADDRESS_3).equals(member.get(MemberMst.ADDR4)) ) return true;
		if (! get (ADDRESS_4).equals(member.get(MemberMst.ADDR5)) ) return true;
// --

// change 080516 Takahashi バグ修正 --
//		if (! get (BIRTH_DATE).equals(Util.toDbDateStr(member.get(MemberMst.BIRTHDAY))) ) return true;
		if (! charBirthDate().equals(member.get(MemberMst.BIRTHDAY))) return true;
// --
		if (! get (SEX_ID).equals(member.get(MemberMst.SEX_ID)) ) return true;
        if(this.getSiteId().equals(PC_SITE_ID) || this.getSiteId().equals(PC_SITE_ID_ZUBAT)) {
            if (! get (TEL).equals(member.get(MemberMst.TEL)) ) return true;
        } else {
            if (! get (TEL).equals(member.get(MemberMst.MOBILE)) ) return true;
        }
//		if (! get (EMAIL).equals(member.get(MemberMst.EMAIL)) ) return true; //EMAIL情報は自動更新の対象外
		
		return false;
	}
	
	/**
	 * 会員情報を自分（ステップのユーザ情報オブジェクト）にコピーする
	 */
	public void doPopulateFromMemberMst(MemberMst member){
		set (GUID , member.get(MemberMst.GUID));
		set (NAME_KANJI_1 , member.get(MemberMst.NAME1));
		set (NAME_KANJI_2 , member.get(MemberMst.NAME2));
		set (NAME_KANA_1 , member.get(MemberMst.FURI1));
		set (NAME_KANA_2 , member.get(MemberMst.FURI2));
		set (ZIP , member.get(MemberMst.ZIP));
		set (PREF_ID , member.get(MemberMst.PREF_ID));
		
// change 080516 Takahashi バグ修正 --
		// petbang は、他のstepとADDRESSの定義がズレている
		set (PREF_NAME , member.get(MemberMst.ADDR1));
		set (ADDRESS_1 , member.get(MemberMst.ADDR2));
		set (ADDRESS_2 , member.get(MemberMst.ADDR3));
		set (ADDRESS_3 , member.get(MemberMst.ADDR4));
		set (ADDRESS_4 , member.get(MemberMst.ADDR5));
// --

		set (BIRTH_DATE, DateUtil.toDbDateStr(member.get(MemberMst.BIRTHDAY)));
		set (SEX_ID , member.get(MemberMst.SEX_ID));

        if(this.getSiteId().equals(PC_SITE_ID) || this.getSiteId().equals(PC_SITE_ID_ZUBAT)) {
            set (TEL , member.get(MemberMst.TEL));
        } else {
            set (TEL , member.get(MemberMst.MOBILE));
        }
		
		// メールアドレスは三種類を場合に応じて表示する
		if ( isMobileAccess() ) {
			set (EMAIL , member.get(MemberMst.MB_MAIL));
		} else {
			if ( isCorporateService() ) {
				set (EMAIL , member.get(MemberMst.CP_MAIL));
			} else {
				set (EMAIL , member.get(MemberMst.EMAIL));
			}
		}
	}

	/**
	 * ステップのユーザ情報を会員情報オブジェクトにコピーする
	 */
	public void doPopulateToMemberMst(MemberMst member){
		// メンバーオブジェクトを自動生成する時は、データを切り捨ててでも、なるべく生かす。
		// （文字数制限を自動的に行う）
		
		member.setTrimData(MemberMst.NAME1, get(NAME_KANJI_1));
		member.setTrimData(MemberMst.NAME2, get(NAME_KANJI_2));
		member.setTrimData(MemberMst.FURI1, get(NAME_KANA_1));
		member.setTrimData(MemberMst.FURI2, get(NAME_KANA_2));
		member.setTrimData(MemberMst.ZIP, get(ZIP));
		member.setTrimData(MemberMst.PREF_ID, get(PREF_ID));
		member.setTrimData(MemberMst.ADDR1, get(PREF_NAME));
		member.setTrimData(MemberMst.ADDR2, get(ADDRESS_1));
		member.setTrimData(MemberMst.ADDR3, get(ADDRESS_2));
		member.setTrimData(MemberMst.ADDR4, get(ADDRESS_3));
		member.setTrimData(MemberMst.ADDR5, get(ADDRESS_4));
		member.setTrimData(MemberMst.BIRTHDAY, charBirthDate()); //YYYYMMDDに変換
		member.setTrimData(MemberMst.SEX_ID, get(SEX_ID));
		
		/* 電話番号が2重で登録される問題の修正
		  member.setTrimData(MemberMst.TEL, get(TEL));
		 */
//		member.trimCopy(MemberMst.EMAIL, get(EMAIL)); // EMAIL情報は自動的には更新しない
//		member.trimCopy(MemberMst.MAG_FLAG, get(MAG_FLAG)); // 会員情報のMAG_FLAGはstepのとは独立した別物
        if(this.getSiteId().equals(PC_SITE_ID) || this.getSiteId().equals(PC_SITE_ID_ZUBAT)) {
            member.setTrimData(MemberMst.TEL, get(TEL));
        } else {
            member.setTrimData(MemberMst.MOBILE, get(TEL));            
        }
	}

	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToOrderHist(jp.co.webcrew.login.util.db.OrderHist)
	 */
	public void doPopulateToOrderHist(OrderHist order){
		
		order.setTrimData(OrderHist.ORDER_DATETIME,DateUtil.currentDateTime()); //発注日
		order.setTrimData(OrderHist.ORDER_TYPE, OrderHist.TYPE_SHIRYO_SEIKYU); //資料請求に固定
		order.setTrimData(OrderHist.SITE_ID, getSiteId());
		order.setTrimData(OrderHist.ORDER_ID, getRequestId());

		DBAccess db = null;
		try{
			db = new DBAccess();

			// ORDER_TEXT列にStepサイトの説明文をコピー
			order.setTrimData(OrderHist.ORDER_TEXT, getOrderText());

			// SUPPLIER_TEXT列に複数のサプライヤ情報をカンマ区切りでコピー

			StringBuffer sqlbuf = new StringBuffer("SELECT MST.NAME FROM ");
			sqlbuf.append("  PETBANG.USER_COMPANY_INTER INTER, ");
			sqlbuf.append("  PETBANG.COMPANY_MST MST ");
			sqlbuf.append("WHERE ");
			sqlbuf.append("  INTER.COMPANY_ID = MST.COMPANY_ID ");
			sqlbuf.append("AND ");
			sqlbuf.append("  INTER.USER_ID = ? ");
			
			db.prepareStatement(sqlbuf.toString());
			db.setString(1, getRequestId());
			db.executeQuery();
			List suppliers = Record.getResultListOf(db);
			StringBuffer supplier_text = new StringBuffer("");
			for (int i = 0 ; i < suppliers.size() ; i++) {
				Record supinfo = (Record)suppliers.get(i);
				if (i != 0) {
					supplier_text.append(",");
				}
				supplier_text.append(supinfo.getString("NAME"));
			}
			order.setTrimData(OrderHist.SUPPLIER_TEXT, supplier_text.toString()); 
					
		
		} catch (Exception e) {
			log.error("Stepデータを会員情報の履歴データに転送する際にデータベースエラーが発生しました。",e);
		} finally {
			DBAccess.close(db);
		}
		
	}
	
	  // Stepサイトの説明文を取得
	  private String getOrderText() {
	      String order_text = "";
	      if (PC_SITE_ID.equals(getSiteId())) {
	          order_text = ORDER_TEXT_CAPTION;
	      } else if (PC_SITE_ID_ZUBAT.equals(getSiteId()) || PC_SITE_ID_ZUBAT_MB.equals(getSiteId())) {
	          order_text = ORDER_TEXT_CAPTION_ZUBAT;
	      } else {
	          order_text = ORDER_TEXT_CAPTION;
	      }
	      return order_text;
	  }
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doDeleteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public void doDeleteGuid(DBAccess db , String guid) throws SQLException{
/*		DBUpdater updater = new DBUpdater(getSchema() + ".ORDER_INFO");
		updater.addString("GUID","");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		updater.update(db);
*/
		DBUpdater updater = new DBUpdater(getSchema() + ".USER_INFO");
		updater.addString(GUID, "");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		updater.update(db);

	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doOverWriteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public boolean doOverWriteGuid (DBAccess db , String guid) {

	// 入力チェック
		
		// GUIDが不正ならエラー
		if (! SessionFilterAlterUtil.isValidGuid(guid)){
			log.error("GUIDが不正です。");
			return false;
		}

		// USER_IDが不正ならエラー
		String userId = ValueUtil.nullToStr(getUserId());
		if (userId.equals("")) {
			log.error("USER_IDが不正です。");
			return false;
		}

	// 更新
		
		try {
			// USER_INFOのGUIDを更新する
			String sql = "UPDATE " + getSchema() + ".USER_INFO SET GUID = ? ";
			sql += "WHERE USER_ID = ? ";
			db.prepareStatement(sql);
			db.setString(1, guid);
			db.setString(2, getUserId());
			db.executeUpdate();
			
			log.info("GUIDの上書き処理が完了しました。");
			return true;
		
		} catch (Exception e) {

			log.error("guid上書き処理中に例外エラーが発生しました。" , e);
			return false;
		}		

	}	
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getPrefId()
	 */
	public String getPrefId(){
		return get(PREF_ID);
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setPrefId(java.lang.String)
	 */
	public void setPrefId(String val){
		set (PREF_ID , val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getUserId()
	 */
	public String getUserId(){
		return get(USER_ID);
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setUserId(java.lang.String)
	 */
	public void setUserId(String val) {
		set(USER_ID , val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getEmail()
	 */
	public String getEmail(){
		return get(EMAIL);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getSexId()
	 */
	public String getSexId() {
		return get(SEX_ID);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDate()
	 */
	public String getBirthDate() {
		return get(BIRTH_DATE);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthYear()
	 */
	public String getBirthYear() {
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(0,4);
		}
		return ret;
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthMonth()
	 */
	public String getBirthMonth() {
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(5,7);
		}
		return ret;
	}		
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDay()
	 */
	public String getBirthDay(){
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(8,10);
		}
		return ret;		
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getZip()
	 */
	public String getZip(){
		return get(ZIP);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setZip(java.lang.String)
	 */
	public void setZip(String val){
		set(ZIP,val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setSexId(java.lang.String)
	 */
	public void setSexId(String val){
		set(SEX_ID,val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setBirthDate(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void setBirthDate(String year,String month,String day){
		set(BIRTH_DATE , year + "-" + month + "-" + day);
	}
	

	/*
	 * private method
	 */
	
	/**
	 * クライアントのIPアドレスを取得する
	 * @return String IPアドレス
	 */
	private String getRemoteAddr() {
		return getHttpRequest().getRemoteAddr();
	}

	/**
	 * 誕生日をYYYYMMDD形式の文字列で取得する
	 * @return String 誕生日 YYYYMMDD
	 */
	private String charBirthDate(){
		return getBirthYear() + getBirthMonth() + getBirthDay();		
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getLastUpdateTime()
	 */
	public String getLastUpdate() {
		String ret = get(LAST_UPDATE);
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(0,4) + ret.substring(5,7) + ret.substring(8,10);
		}
		
		return ret;
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getMagFlag()
	 */
	public String getMagFlag() {
		String mag_flag = get(WC_PERMIT_FLG);
		
		if (mag_flag == null) {
			return "" ;
		}
		if (mag_flag.equals("0")) {
			return "0";
		}
		if (mag_flag.equals("1")) {
			return "1";
		}

		return "";
		
	}
	
//	/*
//	 * (non-Javadoc)
//	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getOrderId(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
//	 */
//	public String getOrderId (DBAccess db , String guid) {
//
//		// PetBangにはOrderIdは無い
//		return "";
//	}
//
//	/*
//	 * (non-Javadoc)
//	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getUserId(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
//	 */
//	public String getUserId (DBAccess db , String guid) {
//		
//		/*
//		 * USER_INFO の 直近のUSER_IDを返す
//		 * 
//		 * 特殊なstepではサブクラスでオーバーライドする
//		 * 
//		 */
//		
//	
//		String sql = "SELECT USER_ID FROM " + getSchema() + ".USER_INFO WHERE GUID=? ORDER BY LAST_UPDATE DESC";
//		try {
//			db.prepareStatement(sql);
//			db.setString(1, guid);
//			Record rec = Record.getFirstRowOf(db);
//			
//			if (rec == null) {
//				return "";
//			} else {
//				return rec.getString("USER_ID");
//			}
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//			log.info("USER_ID取得中に例外エラーが発生しました。");
//			
//			return "";
//		}
//		
//		
//	
//		
//	}	
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#getOrderIDs(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public String[] getOrderIDs (DBAccess db , String guid) {
		
		/*
		 * PetBangはORDER_IDが存在しないのでUSER_IDだけを返す
		 * 
		 */
		
		String sql = "SELECT USER_ID FROM " + getSchema() + ".USER_INFO WHERE GUID=? ORDER BY LAST_UPDATE DESC";
		try {
			db.prepareStatement(sql);
			db.setString(1, guid);
			Record rec = Record.getFirstRowOf(db);
			
			if (rec == null) {
				return null;
			} else {
				String[] ret = { rec.getString("USER_ID") , rec.getString("USER_ID") };
				return ret;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			log.info("ORDER_ID取得中に例外エラーが発生しました。");
			
			return null;
		}
	}	
}
