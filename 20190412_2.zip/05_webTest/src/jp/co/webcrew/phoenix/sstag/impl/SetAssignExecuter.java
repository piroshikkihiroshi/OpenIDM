package jp.co.webcrew.phoenix.sstag.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.sstag.bean.SelectItemBean;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * スクリーニング結果とformの関連づけを行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class SetAssignExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：項目ID */
    private static final String ITEM_ID_PARAM_KEY = "item_id";

    /** パラメータ名：スクリーニング結果が入っている一意なID(必須) */
    private static final String RESULT_ID_PARAM_KEY = "result_id";

    /** パラメータ名：スクリーニング結果内の set名(必須) */
    private static final String SET_ID_PARAM_KEY = "set_id";

    /** パラメータ名：スクリーニング結果セット内の項目名 */
    private static final String RESULT_ITEM_PARAM_KEY = "result_item";

    /** ロガー */
    private static final Logger log = Logger.getLogger(SetAssignExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { FORM_ID_PARAM_KEY, ITEM_ID_PARAM_KEY, RESULT_ID_PARAM_KEY, SET_ID_PARAM_KEY,
                    RESULT_ITEM_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String itemId = ValueUtil.nullToStr(parameters.get(ITEM_ID_PARAM_KEY));
            String resultId = ValueUtil.nullToStr(parameters.get(RESULT_ID_PARAM_KEY));
            String setId = ValueUtil.nullToStr(parameters.get(SET_ID_PARAM_KEY));
            String resultItem = ValueUtil.nullToStr(parameters.get(RESULT_ITEM_PARAM_KEY));

            Map<String, Map<String, Object[]>> sResult = StoreUtil.getScreeningResult(request, resultId);
            List<SelectItemBean> selectItemList = toSelectItemList(sResult, setId, resultItem);
            if (PhoenixUtil.isEmpty(selectItemList)) {
                String message = MessageFormat.format("結果セットが存在しません。[{0}:{1}][{2}:{3}][{4}:{5}]", RESULT_ID_PARAM_KEY,
                        resultId, SET_ID_PARAM_KEY, setId, RESULT_ITEM_PARAM_KEY, resultItem);
                return onerror(request, response, parameters, message);
            }

            // 関連付けを保存する。
            StoreUtil.setAssign(request, siteId, formId, itemId, selectItemList);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * スクリーニング結果を選択肢マスタの形式に変換する。
     * 
     * @param sResult
     * @param setId
     * @param resultItemName
     * @return
     */
    @SuppressWarnings("unchecked")
    private List<SelectItemBean> toSelectItemList(Map<String, Map<String, Object[]>> sResult, String setId,
            String resultItemName) {

        if (PhoenixUtil.isEmpty(sResult)) {
            return null;
        }

        Map<String, Object[]> resultSet = sResult.get(setId);
        if (PhoenixUtil.isEmpty(resultSet)) {
            return null;
        }

        Object[] resultItem = resultSet.get(resultItemName);
        if (PhoenixUtil.isEmpty(resultItem)) {
            return null;
        }

        List<String> valueList = (List<String>) resultItem[Constants.VALUE_ITEM_INDEX];
        List<String> dispList = (List<String>) resultItem[Constants.DISP_ITEM_INDEX];

        List<SelectItemBean> selectItemList = new ArrayList<SelectItemBean>();
        for (int i = 0; i < valueList.size() && i < dispList.size(); i++) {
            SelectItemBean selectItem = new SelectItemBean();
            selectItem.setValue(valueList.get(i));
            selectItem.setName(dispList.get(i));
            selectItemList.add(selectItem);
        }

        return selectItemList;

    }
}
