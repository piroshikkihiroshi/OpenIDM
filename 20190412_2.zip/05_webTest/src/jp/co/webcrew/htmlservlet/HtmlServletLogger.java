package jp.co.webcrew.htmlservlet;

import java.text.MessageFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

public class HtmlServletLogger 
{
	private static final Logger logger=Logger.getLogger(HtmlServletLogger.class);
	private static final String REQ_ATTRNAME_ACLOG_START_TIME=HtmlServletLogger.class.getSimpleName()+"__accesslog_starttime__";
	private static final String REQ_ATTRNAME_ACLOG_MSG=HtmlServletLogger.class.getSimpleName()+"__accesslog_msg__";

	
	public static final void info(String msg)
	{
		logger.info(msg);
	}
	
	public static final void warn(String msg)
	{
		logger.warn(msg);
	}
	
	public static final void error(String msg,Throwable th)
	{
		logger.error(msg, th);
	}
	
	/****
	 * アクセスログの計測を開始する
	 * 
	 * @param request
	 */
	public static final void accesslog_start(HttpServletRequest request)
	{
		request.setAttribute(REQ_ATTRNAME_ACLOG_START_TIME, new Date());
	}
	
	/***
	 * 結果を書き込む
	 * 
	 * @param request
	 * @param status
	 */
	public static final void accesslog_tempSaveInfo(HttpServletRequest request,int status)
	{
		accesslog_tempSaveInfo_Internal(request,status,null);
	}
	
	/***
	 * 結果を書き込む
	 * 
	 * @param request
	 * @param status
	 * @param nextUrl
	 */
	public static final void accesslog_tempSaveInfo(HttpServletRequest request,int status,String nextUrl)
	{
		accesslog_tempSaveInfo_Internal(request,status,nextUrl);
	}
	
	/***
	 * 結果を書き込む
	 * 実装
	 * 
	 * @param request
	 * @param status
	 * @param nextUrl
	 */
	private static final void accesslog_tempSaveInfo_Internal(HttpServletRequest request,int status,String nextUrl)
	{
		//リクエストメソッド取得
		String method=request.getMethod();
		//URI取得
		String uri=request.getRequestURI();
		String url="";//request.getRequestURL().toString();
		//サイトID取得(判別)
		String siteId=ValueUtil.nullToStr(request.getAttribute("faon.site_id"));
		//Request変数にバインド
		request.setAttribute(REQ_ATTRNAME_ACLOG_MSG, new String[]
		 {method,uri,url,siteId,String.valueOf(status),nextUrl});
	}
	/***
	 * アクセスログの計測を完了し、所要日時をログ(レベルinfo)で記載する
	 * @param request
	 */
	public static final void accesslog_end(HttpServletRequest request)
	{
		
		final String LOG_LINE_TPL="|calc|time(msec)|{0}|method|{1}|uri|{2}|siteid|{3}|status|{4}|ip|{5}|referer|{6}|";
		
		try
		{
			Date startDate=(Date)request.getAttribute(REQ_ATTRNAME_ACLOG_START_TIME);
			String[] strArray=(String[])request.getAttribute(REQ_ATTRNAME_ACLOG_MSG);
			
			String method,uri,url,siteId,status,nextUrl;
			
			if(strArray!=null && strArray.length==6)
			{
				method=strArray[0];
				uri=strArray[1];
				url=strArray[2];
				siteId=strArray[3];
				status=strArray[4];
				nextUrl=ValueUtil.nullToStr(strArray[5]);
			}
			else
			{
				method="";uri="";url="";siteId="";status="";nextUrl="";
			}
			Date endDate=new Date();
			
			String strSpanTime;
			if(startDate!=null)
			{
				strSpanTime=String.valueOf(endDate.getTime() - startDate.getTime());
			}
			else
			{
				strSpanTime="failed";
			}
			
			
			info(MessageFormat.format(LOG_LINE_TPL
					, strSpanTime
					,method
					,uri
					,siteId
					,status
					,request.getRemoteAddr()
					,request.getHeader("REFERER")
					));
			
			//info("|calc|time(msec)|"+strSpanTime+"|method|"+method+"|uri|"+uri+"|siteid|"+siteId+"|status|"+status+"|");
			//info("|calc|time(msec)|"+strSpanTime+"|method|"+method+"|uri|"+uri+"|url|"+url+"|siteid|"+siteId+"|status|"+status);
		}
		catch(Throwable th)
		{
			logger.error("フェニックスアクセスログの書き込み処理でエラーを検知しました", th);
		}
	}
	
}

