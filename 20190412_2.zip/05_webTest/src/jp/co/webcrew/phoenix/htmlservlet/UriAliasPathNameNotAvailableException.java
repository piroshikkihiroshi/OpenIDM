package jp.co.webcrew.phoenix.htmlservlet;

public class UriAliasPathNameNotAvailableException extends Exception
{
	
	
	public UriAliasPathNameNotAvailableException()
	{
		super();
	}
	
}
