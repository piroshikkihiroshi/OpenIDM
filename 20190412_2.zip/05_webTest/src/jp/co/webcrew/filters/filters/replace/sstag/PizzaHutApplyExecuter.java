package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.CampaignApplyDb;

/**
 * <pre>
 *  ピザプレゼントクーポン申込み用Executerクラス。 
 * </pre>
 * 
 * @author amit
 */
public class PizzaHutApplyExecuter extends SSTagExecuter {
	
	/** ロガー */
	private static final Logger log = Logger.getLogger(PizzaHutApplyExecuter.class);
	
	/**
	 * Inserts data into PIZZA_HUT_APPLY table
	 * 
	 */
	public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {
		
		//Get auth_key and order_id from the parameter
		String strAuthKey = ValueUtil.nullToStr(parameters.get("auth_key"));
		String strOrderId = ValueUtil.nullToStr(parameters.get("order_id"));
		
		// パラメータチェック
		if (strAuthKey.length() == 0 || strOrderId.length() == 0) 
		{
			// パラメータエラーとする
			log.error("パラメータエラー パラメータ[auth_keyまたはorder_id]が指定されていません。");
			return "";
		}
		
		try 
		{
			//Get the HTML contents from the database
			CampaignApplyDb objCampaignApplyDb = new CampaignApplyDb();
			objCampaignApplyDb.insertIntoCampaignApply(strAuthKey, strOrderId);
		}
		catch (SQLException objSQLExp) 
		{
			if (objSQLExp.getMessage() != null && objSQLExp.getMessage().indexOf("ORA-00001") != -1)
			{
				log.info("既に申し込みされております　「tonashiba.XXXX_apply」:　" +
					"Order Id=" + strOrderId + " | Auth Key=" + strAuthKey);
			}
			else
			{	
				log.error("SQL Exception while inserting into tonashiba.XXXX_apply:　" +
					"Order Id=" + strOrderId + " | Auth Key=" + strAuthKey, objSQLExp);
			}
		}
		catch(Exception objExp) 
		{
			log.error("予期せぬエラー", objExp);
		}
		return "";
	}

}
