package jp.co.webcrew.filters.filters.replace.replacer;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.util.ReplaceFilterUtil;
import jp.co.webcrew.phoenix.htmlservlet.HtmlServletUtil;

/**
 * 画像用urlを本番サーバ向けに変換するReplacerクラス。
 * 
 * @author kurinami
 */
public class ImageUrlReplacer extends Replacer {

    /** system_property値：画像サーバ名 */
    private static final String PHOENIX_IMG_SERVER_PROP_KEY = "PHOENIX_IMG_SERVER";

    /** imgタグ用置換パターン */
    private static final Pattern IMG_PATTERN = Pattern
            .compile(
                    "<(\\s*img\\s+[^>]*)(src\\s*)=(\\s*['\"]{1}\\s*)/([^'\"]+)(.gif|.jpg|.jpeg|.png|.bmp)(\\s*['\"]{1})([^>]*)>",
                    Pattern.CASE_INSENSITIVE);

    /** input type="image" 用置換パターン1 */
    private static final Pattern INPUT_PATTERN_1 = Pattern
            .compile(
                    "<(\\s*input\\s+[^>]*)(type\\s*=\\s*['\"]{1}image['\"]{1}[^>]*)(src\\s*)=(\\s*['\"]{1}\\s*)/([^'\"]+)(.gif|.jpg|.jpeg|.png|.bmp)(\\s*['\"]{1})([^>]*)>",
                    Pattern.CASE_INSENSITIVE);

    /** input type="image" 用置換パターン2 */
    private static final Pattern INPUT_PATTERN_2 = Pattern
            .compile(
                    "<(\\s*input\\s+[^>]*)(src\\s*)=(\\s*['\"]{1}\\s*)/([^'\"]+)(.gif|.jpg|.jpeg|.png|.bmp)(\\s*['\"]{1})([^>]*)(type\\s*=\\s*['\"]{1}image['\"]{1}[^>]*)>",
                    Pattern.CASE_INSENSITIVE);

    private static final Pattern CSS_URL = Pattern.compile(
            "(url\\(\\s*['\"]?\\s*)/([^\\)]+)(.gif|.jpg|.jpeg|.png|.bmp)(\\s*['\"]?\\s*\\))", Pattern.CASE_INSENSITIVE);
    
    /** ロガー */
    private static final Logger log = Logger.getLogger(ImageUrlReplacer.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.replacer.Replacer#replace(java.
     * lang.String, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    public String replace(String source, HttpServletRequest request, HttpServletResponse response) {
        String urlPrefix = getPrefix(request);
        return addPrefix(source, urlPrefix);
    }

    /**
     * 画像サーバ名を画像urlの前につける。
     * 
     * @param source
     * @param urlPrefix
     * @return
     */
    private static String addPrefix(String source, String urlPrefix) {
        String result = source;

        String imgReplacement = "<$1$2=$3" + urlPrefix + "/$4$5$6$7>";
        Matcher imgMatcher = IMG_PATTERN.matcher(result);
        result = imgMatcher.replaceAll(imgReplacement);

        String inputReplacement1 = "<$1$2$3=$4" + urlPrefix + "/$5$6$7$8>";
        Matcher inputMatcher1 = INPUT_PATTERN_1.matcher(result);
        result = inputMatcher1.replaceAll(inputReplacement1);

        String inputReplacement2 = "<$1$2=$3" + urlPrefix + "/$4$5$6$7$8>";
        Matcher inputMatcher2 = INPUT_PATTERN_2.matcher(result);
        result = inputMatcher2.replaceAll(inputReplacement2);

        String cssUrlReplacement = "$1" + urlPrefix + "/$2$3$4";
        Matcher cssUrlMatcher = CSS_URL.matcher(result);
        result = cssUrlMatcher.replaceAll(cssUrlReplacement);
        
        return result;
    }

    /**
     * 画像サーバを表すprefixを返す。
     * 
     * @param request
     * @return
     */
    public static String getPrefix(HttpServletRequest request) {

        String protocol = HttpProtocolReplacer.isSsl(request) ? "https://" : "http://";

        String serverName = SystemPropertiesDb.getInstance().get(PHOENIX_IMG_SERVER_PROP_KEY);
        if (ValueUtil.nullToStr(serverName).length() == 0) {
            String message = "system_property に画像サーバ名【" + PHOENIX_IMG_SERVER_PROP_KEY + "】が設定されていません。";
            log.error(message, new Exception());
            return "";
        }

        int siteId = SiteMstDb.getInstance().getSiteId(request.getRequestURL().toString());
        if (siteId == -1)
        {
			//既存サイトからフェニックスへリダイレクトされた再に
			//「,」で同一ドメインが区切られたURLになり、サイトID
			//が取得できない問題を考慮
        	siteId = ValueUtil.toint(ReplaceFilterUtil.getActualSiteId(request));
        }

        String urlPrefix = protocol + serverName + "/" + siteId;
        return urlPrefix;
        
    }
    
    public static void main(String[] args) {

        String html = "<img src='/img/gegege.gif'> \n" + "<img src='/img/dadada.jpg' width='100' height='60'> \n"
                + "<img width='100' height='60' src='/img/dadada.jpg'> \n" + "<IMG SRC='/img/GEGEGE.gif'> \n"
                + "<IMG SRC='/img/dadada.jpg' width='100' height='60'> \n"
                + "<IMG width='100' height='60' SRC='/img/dadada.jpg'> \n" + "<img src='/img/gegege.gif' /> \n"
                + "<img src='/img/dadada.jpg' width='100' height='60' /> \n"
                + "<img width='100' height='60' src='/img/dadada.jpg' /> \n"
                + "<input type='image' src='/img/dadada.jpg' /> \n" + "<input src='/img/dadada.jpg' type='image' /> \n"
                + "<input src='/img/dadada.jpg' type='text' /> \n";

        html = "background:url(/pet-sougi/images/inner_wrapper_bottom.gif) no-repeat left bottom;";
        
        String urlPrefix = "http://localhost/99999";

        System.out.println(html);
        System.out.println(addPrefix(html, urlPrefix));
    }
}
