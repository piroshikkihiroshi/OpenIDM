
declare
	cur  refcursor;
	ret  integer;
	tmpSql	text;
	l_returnValue  text;
begin
	
	-- tmp�e�[�u�����݊m�F
	
	SELECT count("relname") into l_returnValue  FROM "pg_class" WHERE "relkind" = 'r' AND "relname" = 'callertmptable' ;
	
	if (l_returnValue = 0) then
	    execute ' drop table callertmptable';	
	end if;
	
    execute ' create temp table callertmptable(l_caller text)';
    
    if (val_i is not null) then
	    execute 'insert into callertmptable 
	    	values('''
	    	|| val_i ||
	    	''')';
	    
	    ret := 1;
	    return ret;
	else
	    execute 'insert into callertmptable 
	    	values('''
	    	|| 'null' ||
	    	''')';
	    
	    ret := 1;
	    return ret;
    end if;
    
end;    
