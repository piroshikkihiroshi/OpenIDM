package jp.co.webcrew.filters.filters.accesslog;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.db.UrlCategoryMapDb;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.QueueThreadUtil;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;
import jp.co.webcrew.login.common.util.DateUtil;

/**
 * 各リクエストに対してポイントのチェックを行うthreadクラス。
 * 
 * @author kurinami
 */
public class AccesslogThread extends QueueThreadUtil {

    /* ロガー */
    private static final Logger log = Logger.getLogger(AccesslogThread.class);

    private static final String URL_HTTP_PREFIX = "http://";
    private static final String URL_HTTPS_PREFIX = "https://";
    private static final String URL_HTTPS_PORT = ":443";

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.filters.util.QueueThreadUtil#execute(java.lang.Object)
     */
    protected void execute(HttpServletRequestCache request) throws Exception {

        Date accDatetime = request.getMkDatetime();
        String method = request.getMethod();
        String reqUrl = request.getRequestURL().toString()
                + (request.getQueryString() == null ? "" : "?" + request.getQueryString());
        String remoteIp = request.getRemoteAddr();
        String userAgent = ValueUtil.nullToStr(request.getHeader("User-Agent"));
        String referer = ValueUtil.nullToStr(request.getHeader("Referer"));
        int status = request.getStatus();
        int gsid = ValueUtil.toint((String) request.getAttribute(UserInfo.GSID_ATTR_KEY));
        int guid = ValueUtil.toint((String) request.getAttribute(UserInfo.GUID_ATTR_KEY));
        int ssid = ValueUtil.toint((String) request.getAttribute(UserInfo.SSID_ATTR_KEY));

        Map siteInfo = SiteMstDb.getInstance().getSiteInfo(reqUrl);
        int siteId = ((Integer) siteInfo.get("site_id")).intValue();
        int subNum = ((Integer) siteInfo.get("sub_num")).intValue();

        AccessInfoDb.insert(accDatetime, method, reqUrl, remoteIp, userAgent, referer, status, guid, gsid, ssid,
                siteId, subNum);

        // サイトアクセス履歴記録
        insertToSiteAccessHist(guid, siteId, reqUrl);

    }

    // サイトアクセス履歴記録
    private void insertToSiteAccessHist(int guid, int siteId, String reqUrl) throws SQLException {

        // 該当URLが登録必要かどうかを判断します
        // クローラの場合GUIDが「0」です。外部サイトの場合SITE_IDが「0」です。
        if (UserInfo.CRAWLER_ID.equals(Integer.toString(guid)) || !isNeedRegisterUrl(reqUrl) || siteId == SiteMstDb.OUTSIDE_SITE_ID) {
            return;
        }

        // インスタンスを取得する
        UrlCategoryMapDb urlCategory = UrlCategoryMapDb.getInstance();
        String editedUrl = editUrl(reqUrl);
        int categoryId = urlCategory.getCategoryId(siteId, editedUrl);
        // 登録してないURLからの場合処理なし返す
        if (categoryId == UrlCategoryMapDb.UNKNOWN_CATEGORY_ID) {
            log.debug("サイトアクセス履歴に登録されてない[URL]: " + editedUrl);
            return;
        }

        // 該当カテゴリがサイトアクセス履歴が既に存在するかどうかを検索する
        Map histMap = SiteAccessHistDb.getAccessHistMap(guid, categoryId);

        // 存在しない場合新規登録する
        if (histMap == null) {
            SiteAccessHistDb.insertSiteAccessHist(guid, categoryId, 1);// アクセス回数が1から
            log.debug("サイトアクセス履歴に新規登録された[URL]: " + editedUrl + "   [GUID]: " + guid);
        } else {
            String lastAccessTime = (String) histMap.get(SiteAccessHistDb.LAST_ACCESS_TIME);
            // 存在した場合更新する（更新期間制限が過ぎる場合）
            if (isUpdateable(lastAccessTime)) {
                String accessCount = (String) histMap.get(SiteAccessHistDb.ACCESS_COUNT);
                int newCount = Integer.parseInt(accessCount) + 1; // アクセス回数をインクリメントして更新する
                SiteAccessHistDb.updateSiteAccessHist(guid, categoryId, newCount);
                log.debug("サイトアクセス履歴に更新された[URL]: " + editedUrl + "   [GUID]: " + guid + "   [新アクセス回数]: " + newCount);
            }
        }

    }

    /*
     * 登録必要性を判定する。 判定条件は下記の通り。
     * 
     * 1. 文字列[data] が長さ 0 まはた # で始まっていたら登録対象外。<br> 2. 文字列[data] が http: または https: で始まってなく、登録対象外。 3.
     * 1,2以外の場合は登録対象。
     * 
     * @param data 判定対象URL
     * 
     * @return true:必要あり, false:必要なし
     */
    private boolean isNeedRegisterUrl(String reqUrl) {

        // URLは長さ 0 まはた # で始まっていたら登録対象外。
        if (reqUrl.length() == 0 || reqUrl.startsWith("#")) {
            return false;
        }

        // http: or https: で始まって登録対象外。
        if (!reqUrl.startsWith(URL_HTTP_PREFIX) && !reqUrl.startsWith(URL_HTTPS_PREFIX)) {
            return false;
        }

        // 登録必要なURLパターン。
        String urlPattern = SystemPropertiesDb.getInstance().get(SiteAccessHistDb.SITE_ACCESS_REGISTER_URL_PATTERN);
        Pattern pat = Pattern.compile(urlPattern);
        Matcher mat = pat.matcher(editUrl(reqUrl));
        if (!mat.find()) {
            return false;
        }

        return true;
    }

    // URL編集
    private String editUrl(String reqUrl) {
        // クエスチョンマーク"?"がある場合
        int indexOfQstMark = reqUrl.indexOf("?");
        if (indexOfQstMark != -1) {
            reqUrl = reqUrl.substring(0, indexOfQstMark);
        }

        // http:// or https://があると外す
        reqUrl = reqUrl.replaceAll(URL_HTTP_PREFIX, "");
        reqUrl = reqUrl.replaceAll(URL_HTTPS_PREFIX, "");
        // :443があると外す
        reqUrl = reqUrl.replaceAll(URL_HTTPS_PORT, "");

        return reqUrl;
    }

    // 更新可能かどうかを判断する
    private boolean isUpdateable(String last_access_time) {

        // 更新制限期間を取得する
        String update_limit = String.valueOf(SystemPropertiesDb.getInstance().getSecondValue(
                SiteAccessHistDb.SITE_ACCESS_HIST_UPDATE_LIMIT));

        // DBの最終アクセス日時により制限時間ズレた日時を取得する
        Timestamp updateable_datatime = DateUtil.toTimestamp(DateUtil.getDateTime(last_access_time, update_limit));

        // 現在日付時刻を取得(YYYYMMDDHHMISS形式)
        Timestamp current_timestamp = DateUtil.toTimestamp(DateUtil.currentDateTime());

        // 更新可能の場合
        if (current_timestamp.after(updateable_datatime)) {
            return true;
        }

        return false;
    }

}
