package jp.co.webcrew.phoenix.vtable.bean;

import java.sql.SQLException;
import java.text.MessageFormat;

/**
 * テーブルメタ情報マスタを保持するbeanクラス。
 * 
 * @author kurinami
 */
public class TblMetaMstBean {

    /** テーブルタイプ：汎用固定テーブル */
    public static final String TYPE_NORMAL_REAL_TBL = "1";

    /** テーブルタイプ：汎用固定テーブル */
    public static final String TYPE_NORMAL_VIRTUAL_TBL = "2";

    /** テーブルタイプ：汎用固定テーブル */
    public static final String TYPE_ORDER_REAL_TBL = "3";

    /** テーブルタイプ：汎用固定テーブル */
    public static final String TYPE_ORDER_VIRTUAL_TBL = "4";

    /** テーブルタイプ：フォーム連動仮想テーブル */
    public static final String TYPE_FORM_VIRTUAL_TBL = "5";

    /** サイトID */
    private int siteId = 0;

    /** テーブルID */
    private String tblId = "";

    /** テーブルタイプ */
    private String tblType = "";

    /** 実テーブルスキーマ名 */
    private String tblSchema = "";

    /** 実テーブル名 */
    private String tblName = "";

    /** テーブル名 */
    private String name = "";

    /** テーブル説明 */
    private String description = "";

    /**
     * 実テーブルかどうかを返す。
     * 
     * @return
     * @throws SQLException
     */
    public boolean isRealTbl() throws SQLException {
        if (tblType.equals(TblMetaMstBean.TYPE_NORMAL_REAL_TBL) || tblType.equals(TblMetaMstBean.TYPE_ORDER_REAL_TBL)) {
            return true;
        } else if (tblType.equals(TblMetaMstBean.TYPE_NORMAL_VIRTUAL_TBL)
                || tblType.equals(TblMetaMstBean.TYPE_ORDER_VIRTUAL_TBL)
                || tblType.equals(TblMetaMstBean.TYPE_FORM_VIRTUAL_TBL)) {
            return false;
        } else {
            String message = MessageFormat
                    .format("不明なテーブルタイプ({0})です。[site_id:{1}][tbl_id:{2}]", tblType, siteId, tblId);
            throw new SQLException(message);
        }
    }

    // 以下、アクセッサ

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public String getTblId() {
        return tblId;
    }

    public void setTblId(String tblId) {
        this.tblId = tblId;
    }

    public String getTblType() {
        return tblType;
    }

    public void setTblType(String tblType) {
        this.tblType = tblType;
    }

    public String getTblSchema() {
        return tblSchema;
    }

    public void setTblSchema(String tblSchema) {
        this.tblSchema = tblSchema;
    }

    public String getTblName() {
        return tblName;
    }

    public void setTblName(String tblName) {
        this.tblName = tblName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
