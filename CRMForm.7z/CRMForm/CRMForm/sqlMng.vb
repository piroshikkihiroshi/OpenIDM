﻿Public Class sqlMng

    Function sqlCon(ByVal ServerName_i As String, ByVal Database_i As String, ByVal strUserId_i As String, ByVal strPass_i As String) As System.Data.SqlClient.SqlConnection
        ' 接続文字列を生成する
        Dim stConnectionString As String = String.Empty
        stConnectionString &= "Data Source         = " & ServerName_i & ";"
        stConnectionString &= "Database            = " & Database_i & ";"
        stConnectionString &= "User ID            = " & strUserId_i & ";"
        stConnectionString &= "Password            = " & strPass_i & ";"
        stConnectionString &= "Integrated Security = false;" '

        ' SqlConnection の新しいインスタンスを生成する (接続文字列を指定)
        Dim cSqlConnection As New System.Data.SqlClient.SqlConnection(stConnectionString)

        ' データベース接続を開く
        cSqlConnection.Open()

        ' 接続に成功した旨を表示する
        'MessageBox.Show("Microsoft SQL Server に接続されました")

        ' データベース接続を閉じる (正しくは オブジェクトの破棄を保証する を参照)
        'cSqlConnection.Close()
        'cSqlConnection.Dispose()

        sqlCon = cSqlConnection
    End Function


    Function sqlQuery(ByVal objSqlCon_i As System.Data.SqlClient.SqlConnection, ByVal strSqlCom_i As String)
        ' objSqlCon_i から SqlCommand のインスタンスを生成する
        Dim hCommand As System.Data.SqlClient.SqlCommand = objSqlCon_i.CreateCommand()

        ' 実行する SQL コマンドを設定する
        hCommand.CommandText = strSqlCom_i

        ' 指定した SQL コマンドを実行して SqlDataReader を構築する
        Dim cReader As System.Data.SqlClient.SqlDataReader = hCommand.ExecuteReader()

        ' hCommand を破棄する (正しくは オブジェクトの破棄を保証する を参照)
        hCommand.Dispose()

        Dim stPrompt As String = String.Empty

        '' 次のレコードに進める (次のレコードがない場合は False になるため実行されない)
        'While (cReader.Read())
        '    ' 列の序数を元に値を取得する
        '    stPrompt &= cReader(0).ToString()
        '    ' 列名を元に値を取得する
        '    'stPrompt &= cReader("FirstName").ToString()
        '    ' 改行コードを追加する
        '    stPrompt &= System.Environment.NewLine
        'End While

        ' cReader を閉じる (正しくは オブジェクトの破棄を保証する を参照)
        'cReader.Close()

        ' 結果を表示する
        'MessageBox.Show(stPrompt)


        sqlQuery = cReader

    End Function



End Class
