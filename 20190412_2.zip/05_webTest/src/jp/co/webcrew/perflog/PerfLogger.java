/**
 * 
 */
package jp.co.webcrew.perflog;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import jp.co.webcrew.dbaccess.util.Logger;

/**
 * 処理ごとの処理時間を計測するログ
 * (1)Filterの開始
 * (2)Filterの終了
 * (3)sstagの開始
 * (4)sstagの終了
 * (5)Connection取得開始
 * (6)Connection取得終了
 * (7)ResultSetクローズ
 * 
 * 
 * @author kazuto.yano
 *
 */
public final class PerfLogger 
{
	private static final Logger logger=Logger.getLogger(PerfLogger.class);
	
	/*
	private static ThreadLocal<StringBuilder> tlBuffer=new ThreadLocal<StringBuilder>();
	private static ThreadLocal<SimpleDateFormat> tlFmt=new ThreadLocal<SimpleDateFormat>();
	private static ThreadLocal<Date> tlStartDate=new ThreadLocal<Date>();
	private static ThreadLocal<Long> tlBeforeTime=new ThreadLocal<Long>();
	*/
	private static ThreadLocal<__ThreadObject> tl=new ThreadLocal<PerfLogger.__ThreadObject>();
	
	
	private static boolean _currentStatus=false;
	private static boolean _forceOneLine=false;
	private static int _frequency=1;
	private static String[] _enableSuffixes=null;
	private static String[] _enableUrlPrefixes=null;
	


		
	private static final String EMPTY="(empty)"; 
	
	private PerfLogger(){}
	
	
	

	
	public static void doEnable(boolean forceOneLine,int frequency,String[] enableSuffixes,String[] enableUrlPrefixes)
	{
		_currentStatus=true;
		_forceOneLine=forceOneLine;
		if(_frequency!=frequency)
		{
			synchronized (PerfLogger.class) 
			{
				logger.debug("ログ出力頻度が変更になっているので、出力頻度累計を初期化します。[現在]"+_frequency+"[変更後]"+frequency);
				_counter4Frequency=0;
			}
		}
		_frequency=frequency;
		_enableSuffixes=enableSuffixes;
		_enableUrlPrefixes=enableUrlPrefixes;
	}

	
	public static void doDisable()
	{
		_currentStatus=false;
		logger.debug("ログ出力無効化のため、出力頻度累計を初期化します。");
		synchronized (PerfLogger.class) 
		{
			_counter4Frequency=0;
		}
	}
	
	public static boolean enabled()
	{
		return _currentStatus;
	}

	private static int _counter4Frequency=0;
	
	public static void initEnv(String serverName,String requestUrl,String requestUri)
	{
		
		
		if(!_currentStatus)
		{
			logger.debug("disable(status):"+requestUrl);
			return;
		}
		if(!checkUrlUri(requestUrl,requestUri))
		{
			logger.debug("disable(suffix):"+requestUrl);
			return;
		}
		switch(_frequency)
		{
		case 0:
			logger.debug("disable(freq0):"+requestUrl);
			//スレッド管理オブジェクトの生成なし
			return;
		case 1:
			//完全OK
			logger.debug("enable(all):"+requestUrl);
			break;
		default:
			synchronized(PerfLogger.class) 
			{
				_counter4Frequency++;
				if(_counter4Frequency % _frequency==0)
				{
					logger.debug("enable(freq):"+requestUri);
					//完全OK
					_counter4Frequency=0;
					break;
				}
				else
				{
					logger.debug("disable:"+requestUri+":"+_counter4Frequency);
					//スレッド管理オブジェクトの生成なし
					return;
				}
			}
		}
		
		__ThreadObject to=new __ThreadObject();
		to.serverName=serverName;
		to.requestUri=requestUri;
		tl.set(to);
	}

	
	
	/***
	 * sstag実行直前で呼び出す
	 * @param cls
	 * @param params
	 */
	public static void sstag_Start(Class<?> cls,Map<?,?> params)
	{
		/*
		writeBuffer(
		"SSTAG開始"
		,cls
		,"|params|"+params.toString()
		);
		*/
		__ThreadObject to=tl.get();
		if(to!=null)
		{
			__StackElement element=new __StackElement(cls, params);
			to.stack.push(element);
		}
		
	}
	
	/***
	 * sstag実行終了直後で呼び出す
	 * @param cls
	 */
	public static void sstag_End(Class<?> cls)
	{
		__ThreadObject to=tl.get();
		if(to!=null)
		{
			if(!to.stack.isEmpty())
			{
				__StackElement element=to.stack.pop();
				
				writeBuffer(
						"SSTAG完了"
						,element.sstagClass
						,"|sstagtime|"+(new Date().getTime() -element.startTime)+"|params|"+element.params
						);		
				
			}
			else
			{
				writeBuffer(
						"SSTAG完了"
						,cls,null
						);		
				
			}
			
		}
		
	}
	

	/*
	public static void sqlGetConnection_Start(Class<?> cls)
	{
		writeBuffer(
			"getConn開始"
			,cls
			,null
			);		
		
	}

	public static void sqlGetConnection_End(Class<?> cls)
	{
		writeBuffer(
			"getConn終了"
			,cls
			,null
			);		
		
	}
	*/
	
	/***
	 * executeQuery直前で呼び出す
	 * 
	 * @param cls
	 * @param sql
	 */
	public static void sqlStmt_Start(Class<?> cls,String sql)
	{
		writeBuffer(
			"SQL開始"
			,cls
			,null
			);		
		if(tl.get()!=null)
		{
			tl.get().sql=sql;
		}
		
	}
	
	/****
	 * executeQuery直後で呼び出す
	 * 
	 * @param cls
	 */
	public static void sqlStmt_End(Class<?> cls)
	{
		String sql;
		if(tl.get()!=null)
		{
			sql=tl.get().sql;
			tl.get().sql=EMPTY;
			
		}
		else
		{
			sql=EMPTY;
			
		}
		writeBuffer(
			"SQL終了"
				,cls
				,"|sql|"+sql
			);		
		
		
	}
	
	/***
	 * Connectionクローズで呼び出す
	 * 
	 * @param cls
	 */
	public static void sqlConn_Close(Class<?> cls)
	{
		writeBuffer(
			"ConnectionClose"
				,cls,null
			);		
		
	}

	/***
	 * ResultSetクローズで呼び出す
	 * 
	 * @param cls
	 */
	public static void sqlRSet_Close(Class<?> cls)
	{
		writeBuffer(
			"ResultSetClose"
				,cls,null
			);		
		
	}

	/***
	 * Connection取得時に呼びだす
	 * 
	 * 
	 * @param cls
	 */
	public static void sqlGetConn_Start(Class<?> cls)
	{
		writeBuffer(
				"GetConn開始"
				,cls,null
				);		
	}
	
	/***
	 * Connectionクローズ時に呼び出す
	 * 
	 * @param cls
	 */
	public static void sqlGetConn_End(Class<?> cls)
	{
		writeBuffer(
				"GetConn完了"
				,cls,null
				);		
		
	}

	/***
	 * フィルター先頭で呼び出す
	 * 
	 * @param cls
	 */
	public static void filter_Start(Class<?> cls)
	{
		writeBuffer(
			"filter開始"
			,cls,null
			);		
		
	}
	
	/***
	 * フィルター最後で呼び出す
	 * 
	 * @param cls
	 */
	public static void filter_End(Class<?> cls)
	{
		writeBuffer(
			"filter終了"
			,cls,null
			);		
		
	}
	
	
	private static void writeBuffer(String summary,Class<? extends Object> cls,Object detail)//,int diff)
	{
		
		__ThreadObject to=tl.get();
		if(to==null)
		{
			return;
		}
		
		
		
		Long beforeTime=to.beforeTime;
		StringBuilder buff=to.buffer;
		Date nowTime=new Date();
		buff.append("|detail|");
		buff.append(to.fmt.format(nowTime));
		buff.append("|uri|");
		buff.append(to.requestUri);
		
		buff.append("|diff|");
		/*
		if(diff!=-1)
		{
			buff.append(diff);
		}
		else
		*/ 
		if(beforeTime==-1)
		{
			buff.append("-1");
		}
		else
		{
			buff.append(nowTime.getTime()-beforeTime);
		}
		
		buff.append("|thread|");
		buff.append(Thread.currentThread().getId());
		buff.append("|");
		buff.append(summary);
		buff.append("|class|");
		buff.append(cls.getSimpleName());
		//buff.append("\n");
		if(detail!=null)
		{
			if(!_forceOneLine)
			{
				buff.append(detail);
			}
			else
			{
				buff.append(detail.toString().replaceAll("\r\n|\r|\n", " "));
			}
		}
		buff.append("\n");
		/*
		for(String line:messages)
		{
			buff.append(line);
			buff.append("\n");
		}
		*/
		to.beforeTime=(nowTime.getTime());
		
	}
	/*
	public static void snapFilter(String title)
	{
		StringBuilder buff=threadLocal.get();
		buff.append(tlFmt.get().format(new Date()));
		buff.append("\n[title]\n");
		buff.append("Filter.");
		buff.append(title);
		buff.append("\n");
		
	}
	
	public static void snapSQL(String title,String sql,String option)
	{
		init();
		StringBuilder buff=threadLocal.get();
		buff.append(tlFmt.get().format(new Date()));
		buff.append("\n[title]");
		buff.append("DBAccess.");
		buff.append(title);
		buff.append("\n[sql]\n");
		buff.append(sql);
		if(option==null)
		{
			buff.append("\n[option]\n");
		}
		buff.append(option);
		buff.append("\n");
	}
	

	public static void snapDB(String title)
	{
		init();
		StringBuilder buff=threadLocal.get();
		buff.append(tlFmt.get().format(new Date()));
		buff.append("\n[title]");
		buff.append("DBAccess.");
		buff.append(title);
		buff.append("\n");
	}

	*/
	
	
	/***
	 * ログ出力処理
	 * 
	 * @param requestUri
	 */
	public static void doLog()
	{
		try
		{
			__ThreadObject to=tl.get();
			
			if(to==null)
			{
				return;
			}
			
			
			String requestUri=to.requestUri;
			String strStartDate=to.fmt.format(to.startDate);
			Date nowDate=new Date();
			String strEndDate=to.fmt.format(nowDate);
			
			long diff=nowDate.getTime() - to.startDate.getTime();
			
			StringBuilder buff1=new StringBuilder();
			buff1.append("|req_go|uri|");
			buff1.append(to.requestUri);
			buff1.append("|thread|");
			buff1.append(Thread.currentThread().getId());
			buff1.append("|startDate|");
			buff1.append(strStartDate);
			buff1.append("|endDate|");
			buff1.append(strEndDate);
			buff1.append("|time|");
			buff1.append(diff);
			buff1.append("\n");
			
			buff1.append(to.buffer.toString());
			//buff1.append("********************\n");
			
			//StringBuilder buff=threadLocal.get();
			//wrong-code
			//buff1.insert(0, buff1.toString());
			buff1.append("|reqend|uri|");
			buff1.append(to.requestUri);
			buff1.append("|thread|");
			buff1.append(Thread.currentThread().getId());
			buff1.append("|startDate|");
			buff1.append(strStartDate);
			buff1.append("|endDate|");
			buff1.append(strEndDate);
			buff1.append("|time|");
			buff1.append(diff);
			buff1.append("\n");
			
			logger.info(buff1.toString());
		}
		catch(Throwable exc)
		{
		}
		finally
		{
			tl.set(null);
		}
	}
	
	private static boolean checkUrlUri(String url,String uri)
	{
		
		boolean matchUrl=false;
		if(_enableUrlPrefixes!=null && _enableUrlPrefixes.length!=0)
		{
			
			for(String aPrefix:_enableUrlPrefixes)
			{
				if(url.startsWith(aPrefix))
				{
					matchUrl=true;
					break;
				}
			}
			
			if(!matchUrl)
			{
				return false;
			}
		}
		else
		{
			matchUrl=true;
		}
		
		if(!matchUrl)
		{
			logger.debug("[URL:startwith:false]"+url);
			return false;
		}
		
		if(_enableSuffixes==null || _enableSuffixes.length==0)
		{
			logger.debug("[URI:endwith:empty]"+url);
			return true;
		}
		
		for(String aSuffix:_enableSuffixes)
		{
			if(uri.endsWith(aSuffix))
			{
				logger.debug("[URI:endwith:true]"+url);
				return true;
			}
		}
		
		logger.debug("[URI:endwith:false]"+url);
		return false;
	}
	
	
	private static class __ThreadObject
	{
		StringBuilder buffer=new StringBuilder();
		SimpleDateFormat fmt=new SimpleDateFormat("yyyy/MM/dd-HH:mm:ss.SSS");
		Date startDate=new Date();
		long beforeTime=-1;
		String requestUri=EMPTY;
		String serverName=EMPTY;
		String sql=EMPTY;
		
		Stack<__StackElement> stack=new Stack<PerfLogger.__StackElement>();
		
		
		
	}
	
	private static class __StackElement
	{
		Class<?> sstagClass=null;
		String params=null;
		long startTime;
		
		__StackElement(Class cls,Map<?,?> params)
		{
			this.startTime=new Date().getTime();
			this.sstagClass=cls;
			if(params!=null)
			{
				this.params=params.toString();
			}
			else
			{
				this.params=EMPTY;
			}
		}
	}
	
	
	
	
}
