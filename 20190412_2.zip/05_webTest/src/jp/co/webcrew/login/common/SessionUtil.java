package jp.co.webcrew.login.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * セッション管理に関連するユーティリティクラス
 * 
 * @author kurinami
 */
public class SessionUtil {

	/** 会員マスタ用seqno取得SQL */
	private static final String MEMBER_MST_SEQNO = "select seq_guid.nextval from dual";

	/** 会員マスタ挿入用SQL */
	private static final String MEMBER_MST_INSERT = "insert into member_mst(guid, promo_code, af_code, mk_datetime, up_datetime) values(?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'), to_char(sysdate, 'YYYYMMDDHH24MISS'))";

	/** 永続セッション情報用seqno取得SQL */
	private static final String GLOBAL_SESSION_SEQNO = "select seq_gsid.nextval from dual";

	/** 永続セッション情報挿入用SQL */
	private static final String GLOBAL_SESSION_INSERT = "insert into global_session(gsid, guid, gs_code, mk_datetime) values(?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'))";

	/** 永続セッション情報削除用SQL */
	private static final String GLOBAL_SESSION_DELETE = "delete from global_session where gs_code = ?";

	/** サイトセッション情報取得用SQL */
	private static final String SITE_SESSION_SELECT_BY_GSID = "select * from site_session where gsid = ? order by mk_datetime desc";

	/** サイトセッション情報用seqno取得SQL */
	private static final String SITE_SESSION_SEQNO = "select seq_ssid.nextval from dual";

	/** サイトセッション情報挿入用SQL */
	private static final String SITE_SESSION_INSERT = ""
			+ "insert into site_session(ssid, gsid, login_flag, entry_site_id, last_site_id, entry_site_URL, last_site_URL, referer, remote_ip, promo_code, af_code, term_id, ua, mk_datetime, last_datetime) \n"
			+ "values(?, ?, '0', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'), to_char(sysdate, 'YYYYMMDDHH24MISS')) \n";

	/** サイトセッション情報削除用SQL */
	private static final String SITE_SESSION_DELETE = "delete from site_session where gsid = ?";

	/** サイトセッション情報ログ出力用SQL */
	private static final String SITE_SESSION_COPY = ""
			+ "insert into session_log(ssid, gsid, guid, entry_site_id, last_site_id, entry_site_url, last_site_url, referer, remote_ip, promo_code, af_code, term_id, ua, distance_time, stay_time, login_datetime, mk_datetime, last_datetime) \n"
			+ "select site_session.ssid, \n"
			+ "       site_session.gsid, \n"
			+ "       global_session.guid, \n"
			+ "       site_session.entry_site_id, \n"
			+ "       site_session.last_site_id, \n"
			+ "       site_session.entry_site_url, \n"
			+ "       site_session.last_site_url, \n"
			+ "       site_session.referer, \n"
			+ "       site_session.remote_ip, \n"
			+ "       site_session.promo_code, \n"
			+ "       site_session.af_code, \n"
			+ "       site_session.term_id, \n"
			+ "       site_session.ua, \n"
			+ "       null, \n"
			+ "       (to_date(site_session.last_datetime, 'YYYYMMDDHH24MISS') - to_date(site_session.mk_datetime, 'YYYYMMDDHH24MISS')) * 24 * 60 * 60, \n"
			+ "       site_session.login_datetime, \n"
			+ "       site_session.mk_datetime, \n"
			+ "       site_session.last_datetime \n"
			+ "  from site_session inner join global_session on site_session.gsid = global_session.gsid \n"
			+ " where site_session.gsid = ? \n";

	/** サイトセッション情報最終アクセス日時更新用SQL */
	private static final String SITE_SESSION_LAST_ACCESS_UPDATE = "update site_session set login_flag = ?, last_site_id = ?, last_site_URL = ?, last_datetime = to_char(sysdate, 'YYYYMMDDHH24MISS') where ssid = ?";

	/** サイトセッションプロパティ削除用sql */
	private static final String SITE_SESSION_PROPS_DELETE_ALL = "delete from site_session_props where ssid in (select ssid from site_session where gsid = ?)";

	/** ローカルセッション情報取得用SQL 
	 * @deprecated */
	private static final String LOCAL_SESSION_SELECT_BY_GSID = "select * from local_session where gsid = ? order by mk_datetime desc";

	/** ローカルセッション情報取得用SQL */
	private static final String LOCAL_SESSION_SELECT = "select * from local_session where ls_code = ?";

	/** ローカルセッション情報挿入用SQL */
	private static final String LOCAL_SESSION_INSERT = "insert into local_session(ls_code, gsid, type, site_id, mk_datetime) values(?, ?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'))";

	/** ローカルセッション情報削除用SQL */
	private static final String LOCAL_SESSION_DELETE = "delete from local_session where gsid = ?";

	/** ポイント発生ワーク削除用sql */
	private static final String POINT_CONVERSION_DELETE = "delete from point_temp where ssid in (select ssid from site_session where gsid = ?)";

	/** コンバージョン経過ワーク削除用sql */
	private static final String CONV_PROCESS_DELETE = "delete from conv_process where ssid in (select ssid from site_session where gsid = ?)";

	/**
	 * 新規に会員マスタを作成する。
	 * 
	 * @param dbAccess
	 * @param promoCode
	 * @param afCode
	 * @return
	 * @throws SQLException
	 */
	public static String makeMemberMst(DBAccess dbAccess, String promoCode,
			String afCode) throws SQLException {

		// 各IDを作成する。
		String guid = Long.toString(dbAccess.getSequenceNo(MEMBER_MST_SEQNO));

		// 会員マスタを作成する。
		dbAccess.prepareStatement(MEMBER_MST_INSERT);
		dbAccess.setString(1, guid);
		dbAccess.setString(2, promoCode);
		dbAccess.setString(3, afCode);
		dbAccess.executeUpdate();

		return guid;

	}

	/**
	 * 新規にグローバルセッションを作成する。
	 * 
	 * @param dbAccess
	 * @param gsCode
	 * @param guid
	 * @return
	 * @throws SQLException
	 */
	public static String makeGlobalSession(DBAccess dbAccess, String gsCode,
			String guid) throws SQLException {

		String gsid = Long.toString(dbAccess
				.getSequenceNo(GLOBAL_SESSION_SEQNO));

		// GS_CODEがぶつかるものを削除しておく。
		dbAccess.prepareStatement(GLOBAL_SESSION_DELETE);
		dbAccess.setString(1, gsCode);
		dbAccess.executeUpdate();
		
		// グローバルセッション情報を作成する。
		dbAccess.prepareStatement(GLOBAL_SESSION_INSERT);
		dbAccess.setString(1, gsid);
		dbAccess.setString(2, guid);
		dbAccess.setString(3, gsCode);
		dbAccess.executeUpdate();

		return gsid;

	}

	/**
	 * サイトセッション情報を返す。
	 * 
	 * @param dbAccess
	 * @param gsid
	 * @return
	 * @throws SQLException
	 */
	public static Map selectSiteSessionByGsid(DBAccess dbAccess, String gsid)
			throws SQLException {

		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// 会員マスタを検索する。
			dbAccess.prepareStatement(SITE_SESSION_SELECT_BY_GSID);
			dbAccess.setString(1, gsid);
			rs = dbAccess.executeQuery();
			if (dbAccess.next(rs)) {

				Map map = new HashMap();
				map.put("ssid", new Integer(rs.getInt("ssid")));
				map.put("gsid", new Integer(rs.getInt("gsid")));
				map.put("login_flag", ValueUtil.nullToStr(rs
						.getString("login_flag")));
				map.put("entry_site_id",
						new Integer(rs.getInt("entry_site_id")));
				map.put("last_site_id", new Integer(rs.getInt("last_site_id")));
				map.put("entry_site_url", ValueUtil.nullToStr(rs
						.getString("entry_site_url")));
				map.put("last_site_url", ValueUtil.nullToStr(rs
						.getString("last_site_url")));
				map
						.put("referer", ValueUtil.nullToStr(rs
								.getString("referer")));
				map.put("remote_ip", ValueUtil.nullToStr(rs
						.getString("remote_ip")));
				map.put("promo_code", ValueUtil.nullToStr(rs
						.getString("promo_code")));
				map
						.put("af_code", ValueUtil.nullToStr(rs
								.getString("af_code")));
				map.put("term_id", new Integer(rs.getInt("term_id")));
				map.put("ua", ValueUtil.nullToStr(rs.getString("ua")));
				map.put("login_datetime", ValueUtil.toDate(rs
						.getString("login_datetime")));
				map.put("mk_datetime", ValueUtil.toDate(rs
						.getString("mk_datetime")));
				map.put("last_datetime", ValueUtil.toDate(rs
						.getString("last_datetime")));

				return map;
			} else {
				return null;
			}

		} finally {
			DBAccess.close(rs);
		}
	}

	/**
	 * 指定されたgsidに関連するサイトセッションとローカルセッションを削除する。
	 * 
	 * @param dbAccess
	 * @param gsid
	 * @throws SQLException
	 */
	public static void deleteSiteSession(DBAccess dbAccess, String gsid)
			throws SQLException {

		// 古いコンバージョン経過ワークを削除する。
		dbAccess.prepareStatement(CONV_PROCESS_DELETE);
		dbAccess.setString(1, gsid);
		dbAccess.executeUpdate();

		// 古いポイント発生ワークを削除する。
		dbAccess.prepareStatement(POINT_CONVERSION_DELETE);
		dbAccess.setString(1, gsid);
		dbAccess.executeUpdate();

		// 古いサイトセッションプロパティを削除する。
		dbAccess.prepareStatement(SITE_SESSION_PROPS_DELETE_ALL);
		dbAccess.setString(1, gsid);
		dbAccess.executeUpdate();

		// サイトセッション情報をログに移す
		dbAccess.prepareStatement(SITE_SESSION_COPY);
		dbAccess.setString(1, gsid);
		dbAccess.executeUpdate();

		// 古いサイトセッション情報を削除する。
		dbAccess.prepareStatement(SITE_SESSION_DELETE);
		dbAccess.setString(1, gsid);
		dbAccess.executeUpdate();

		// 古いローカルセッション情報を削除する。
		dbAccess.prepareStatement(LOCAL_SESSION_DELETE);
		dbAccess.setString(1, gsid);
		dbAccess.executeUpdate();
	}

	/**
	 * 新規にサイトセッションを作成する。
	 * 
	 * @param dbAccess
	 * @param gsid
	 * @param siteId
	 * @param url
	 * @param referer
	 * @param remoteIp
	 * @param promoCode
	 * @param afCode
	 * @param termId
	 * @param ua
	 * @return
	 * @throws SQLException
	 */
	public static String makeSiteSession(DBAccess dbAccess, String gsid,
			int siteId, String url, String referer, String remoteIp,
			String promoCode, String afCode, int termId, String ua)
			throws SQLException {

		String ssid = Long.toString(dbAccess.getSequenceNo(SITE_SESSION_SEQNO));

		// サイトセッション情報を作成する。
		dbAccess.prepareStatement(SITE_SESSION_INSERT);
		dbAccess.setString(1, ssid);
		dbAccess.setString(2, gsid);
		dbAccess.setInt(3, siteId);
		dbAccess.setInt(4, siteId);
		dbAccess.setString(5, url.substring(0, Math.min(url.length(), 300)));
		dbAccess.setString(6, url.substring(0, Math.min(url.length(), 300)));
		dbAccess.setString(7, referer.substring(0, Math.min(referer.length(),
				300)));
		dbAccess.setString(8, remoteIp);
		dbAccess.setString(9, promoCode);
		dbAccess.setString(10, afCode);
		dbAccess.setInt(11, termId);
		dbAccess.setString(12, ua.substring(0, Math.min(ua.length(), 300)));
		dbAccess.executeUpdate();

		return ssid;
	}

	/**
	 * サイトセッションのアクセス情報を更新する。
	 * 
	 * @param dbAccess
	 * @param ssid
	 * @param loginFlag
	 * @param siteId
	 * @param url
	 * @throws SQLException
	 */
	public static void updateSiteSession(DBAccess dbAccess, int ssid,
			boolean loginFlag, int siteId, String url) throws SQLException {

		// 最終アクセス日時を更新する。
		dbAccess.prepareStatement(SITE_SESSION_LAST_ACCESS_UPDATE);
		dbAccess.setString(1, loginFlag ? "1" : "0");
		dbAccess.setInt(2, siteId);
		dbAccess.setString(3, url.substring(0, Math.min(url.length(), 300)));
		dbAccess.setInt(4, ssid);
		dbAccess.executeUpdate();

	}

	/**
	 * 新規にサイトセッションを作成する。
	 * 
	 * @param dbAccess
	 * @param gsid
	 * @return
	 * @throws SQLException
	 */
	public static void makeLocalSession(DBAccess dbAccess, String gsid,
			int siteId, String lsCode, String type) throws SQLException {
		
		// ローカルセッション情報を作成する。
		dbAccess.prepareStatement(LOCAL_SESSION_INSERT);
		dbAccess.setString(1, lsCode);
		dbAccess.setString(2, gsid);
		dbAccess.setString(3, type);
		dbAccess.setInt(4, siteId);
		dbAccess.executeUpdate();

	}

	/**
	 * ローカルセッション情報を返す。
	 * 
	 * @param dbAccess
	 * @param gsid
	 * @return
	 * @deprecated
	 * @throws SQLException
	 */
	public static Map selectLocalSessionByGsid(DBAccess dbAccess, String gsid)
			throws SQLException {

		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// 会員マスタを検索する。
			dbAccess.prepareStatement(LOCAL_SESSION_SELECT_BY_GSID);
			dbAccess.setString(1, gsid);
			rs = dbAccess.executeQuery();
			if (dbAccess.next(rs)) {

				Map map = new HashMap();
				map
						.put("ls_code", ValueUtil.nullToStr(rs
								.getString("ls_code")));
				map.put("gsid", new Integer(rs.getInt("gsid")));
				map.put("type", ValueUtil.nullToStr(rs.getString("type")));
				map.put("site_id", new Integer(rs.getInt("site_id")));
				map.put("mk_datetime", ValueUtil.toDate(rs
						.getString("mk_datetime")));

				return map;
			} else {
				return null;
			}

		} finally {
			DBAccess.close(rs);
		}
	}

	/**
	 * ローカルセッション情報を返す。
	 * 
	 * @param dbAccess
	 * @param lsCode
	 * @return
	 * @throws SQLException
	 */
	public static Map selectLocalSession(DBAccess dbAccess, String lsCode)
			throws SQLException {

		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// 会員マスタを検索する。
			dbAccess.prepareStatement(LOCAL_SESSION_SELECT);
			dbAccess.setString(1, lsCode);
			rs = dbAccess.executeQuery();
			if (dbAccess.next(rs)) {

				Map map = new HashMap();
				map
						.put("ls_code", ValueUtil.nullToStr(rs
								.getString("ls_code")));
				map.put("gsid", new Integer(rs.getInt("gsid")));
				map.put("type", ValueUtil.nullToStr(rs.getString("type")));
				map.put("site_id", new Integer(rs.getInt("site_id")));
				map.put("mk_datetime", ValueUtil.toDate(rs
						.getString("mk_datetime")));

				return map;
			} else {
				return null;
			}

		} finally {
			DBAccess.close(rs);
		}
	}
}
