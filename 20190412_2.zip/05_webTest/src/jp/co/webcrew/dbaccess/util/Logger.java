package jp.co.webcrew.dbaccess.util;

import java.io.PrintWriter;
import java.io.StringWriter;

import jp.co.webcrew.log4wc.LogOut;

/**
 * ログ出力用のutilクラス。
 *
 * @author kurinami
 */
public class Logger {

    /** log4wcのインスタンス */
    private LogOut logOut = new LogOut("", "", Logger.class.getName());

    /**
     * 生成不能コンストラクタ
     */
    private Logger() {
    }

    /**
     * 唯一のインスタンスを返す。
     *
     * @return
     */
    public static Logger getLogger(Class _class) {
        return new Logger();
    }

    /**
     * log4wcのインスタンスを返す。
     *
     * @return
     */
    private LogOut getLogOut() {
        return logOut;
    }

    /**
     * デバッグ情報を出力する。
     *
     * @param message
     */
    public void debug(String message) {
        LogOut logOut = getLogOut();
        logOut.debug(message);
    }

    /**
     * 一般情報を出力する。
     *
     * @param message
     */
    public void info(String message) {
        LogOut logOut = getLogOut();
        logOut.info(message);
    }

    /**
     * 警告情報を出力する。
     *
     * @param message
     */
    public void warn(String message) {
        LogOut logOut = getLogOut();
        logOut.warn(message);
    }

    /**
     * エラー情報を出力する。
     *
     * @param message
     */
    public void error(String message) {
        LogOut logOut = getLogOut();
        logOut.error(message);
    }

    /**
     * エラー情報を出力する。
     *
     * @param message
     * @param t
     */
    public void error(String message, Throwable t) {
        LogOut logOut = getLogOut();
        logOut.error(message + "\n" + getStackTrace(t));
    }

    /**
     * 発生した例外のスタックトレースの作成する。
     *
     * @param t
     * @return
     */
    private String getStackTrace(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        sw.flush();
        return sw.toString();
    }

}
