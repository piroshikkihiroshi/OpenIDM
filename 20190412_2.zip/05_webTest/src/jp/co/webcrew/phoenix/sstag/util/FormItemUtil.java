package jp.co.webcrew.phoenix.sstag.util;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;
import jp.co.webcrew.filters.filters.replace.replacer.Replacer;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.phoenix.logic.bean.PostFile;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.bean.SelectItemBean;
import jp.co.webcrew.phoenix.sstag.db.OrderInfoDb;
import jp.co.webcrew.phoenix.sstag.db.SelectMstDb;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmMetaMstBean;

public class FormItemUtil {

    private static Map<String, Class<? extends FormItemUtil>> classMap = new HashMap<String, Class<? extends FormItemUtil>>();

    static {
        classMap.put("1", Type1.class);
        classMap.put("2", Type2.class);
        classMap.put("3", Type3.class);
        classMap.put("4", Type4.class);
        classMap.put("7", Type7.class);
        classMap.put("8", Type8.class);
        classMap.put("9", Type9.class);
        classMap.put("11", Type11.class);
        classMap.put("12", Type12.class);
        classMap.put("13", Type13.class);
        classMap.put("14", Type14.class);
        classMap.put("15", Type15.class);
        classMap.put("16", Type16.class);
        classMap.put("17", Type17.class);
        classMap.put("18", Type18.class);
        classMap.put("19", Type19.class);
        classMap.put("20", Type20.class);
        classMap.put("21", Type21.class);
        classMap.put("22", Type22.class);
        classMap.put("23", Type23.class);
        classMap.put("24", Type24.class);
        classMap.put("25", Type25.class);
        classMap.put("26", Type26.class);
        classMap.put("27", Type27.class);
        classMap.put("28", Type28.class);
        classMap.put("30", Type30.class);
        classMap.put("51", Type51.class);
        classMap.put("52", Type52.class);
        classMap.put("53", Type53.class);
        classMap.put("54", Type54.class);
        classMap.put("55", Type55.class);
        classMap.put("56", Type56.class);
        classMap.put("57", Type57.class);
        classMap.put("58", Type58.class);
        classMap.put("G1", TypeG1.class);
        classMap.put("G2", TypeG2.class);
        classMap.put("G3", TypeG3.class);
        classMap.put("G4", TypeG4.class);
        classMap.put("G5", TypeG5.class);
    }

    public static FormItemUtil getInstance(FormItemBean formItem, HttpServletRequest request)
            throws InstantiationException {

        Class<? extends FormItemUtil> tmp = classMap.get(formItem.getType());
        if (tmp == null) {
            throw new InstantiationException("不明なtype[" + formItem.getType() + "]です。");
        }
        FormItemUtil formItemUtil;
        try {
            formItemUtil = tmp.newInstance();
        } catch (IllegalAccessException e) {
            throw new InstantiationException(e.getMessage());
        }

        formItemUtil.formItem = formItem;
        formItemUtil.request = request;
        PostInfo postInfo;
        try {
            postInfo = StoreUtil.getPostInfo(request);
        } catch (SQLException e) {
            throw new InstantiationException(e.getMessage());
        }
        if (postInfo != null) {
            formItemUtil.postItems = postInfo.postItemMap.get(formItem.getItemId());
            formItemUtil.postFiles = postInfo.postFileMap.get(formItem.getItemId());
        } else {
            formItemUtil.postItems = new String[0];
            formItemUtil.postFiles = new PostFile[0];
        }

        // 半角/全角の変換が必要の場合
        switch (formItemUtil.getWcharConv()) {
        case ClmMetaMstBean.WCHAR_CONV_NONE:
            break;
        case ClmMetaMstBean.WCHAR_CONV_WIDE:
            formItemUtil.postItems = WcharConvUtil.toWide(formItemUtil.postItems);
            break;
        case ClmMetaMstBean.WCHAR_CONV_NARROW:
            formItemUtil.postItems = WcharConvUtil.toNarraw(formItemUtil.postItems);
            break;
        }

        return formItemUtil;
    }

    protected FormItemBean formItem;

    protected HttpServletRequest request;

    protected String[] postItems;

    protected PostFile[] postFiles;

    protected FormItemUtil() {
    }

    private String[] getInitData() {
        String initData;
        if (SessionFilterUtil.isLogined(request)) {
            initData = formItem.getInitData1();
        } else {
            initData = formItem.getInitData2();
        }
        if (PhoenixUtil.isEmpty(initData)) {
            return new String[0];
        }
        Replacer keywordReplacer = new KeywordReplacer();
        String initValue = keywordReplacer.replace(initData, request, null);
        return SstagUtil.splitNewLine(initValue);
    }

    protected String getRawDelimiter() {
        return "\n";
    }

    protected String getValueDelimiter() {
        return " ";
    }

    protected String getDispDelimiter() {
        return " ";
    }

    protected int getWcharConv() {
        return formItem.getWcharConv();
    }

    public String getRaw() throws SQLException {
        return PhoenixUtil.concat(getRaws(), getRawDelimiter());
    }

    public String[] getRaws() throws SQLException {
        if (postItems == null) {
            postItems = getInitData();
        }
        return postItems.clone();
    }

    public String getValue() throws SQLException {
        return ValueUtil.sanitize(getValueNoenc());
    }

    public String[] getValues() throws SQLException {
        return SstagUtil.sanitize(getValuesNoenc());
    }

    public String getValueNoenc() throws SQLException {
        return PhoenixUtil.dataCat(getValuesNoenc(), getValueDelimiter());
    }

    public String[] getValuesNoenc() throws SQLException {
        return getRaws();
    }

    public String getDisp() throws SQLException {
        return ValueUtil.sanitize(getDispNoenc());
    }

    public String[] getDisps() throws SQLException {
        return SstagUtil.sanitize(getDispsNoenc());
    }

    public String getDispNoenc() throws SQLException {
        return PhoenixUtil.dataCat(getDispsNoenc(), getDispDelimiter());
    }

    public String[] getDispsNoenc() throws SQLException {
        return getValuesNoenc();
    }

    public String getDbValue() throws SQLException {
        return PhoenixUtil.dataCat(getRaws(), "\n");
    }

    public String[] validate(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix) throws SQLException {

        String[] result = null;

        /* 必須フラグチェック */
        result = ValidateUtil.checkRequire(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request, formItem);
        if (!PhoenixUtil.isEmpty(result)) {
            return result;
        }

        return result;
    }

    public List<SelectItemBean> getSelectMst() throws SQLException {

        // 関連付けされた選択肢マスタを取得する。
        List<SelectItemBean> selectItemList = StoreUtil.getAssign(request, formItem.getSiteId(), formItem.getFormId(),
                formItem.getItemId());
        // 関連付けが存在しない場合、
        if (selectItemList == null) {
            // カラムメタ情報に登録されている選択肢マスタを使用する。
            if (formItem.getSelMstSiteId() != 0 && !PhoenixUtil.isEmpty(formItem.getSelMstId())) {
                selectItemList = SelectMstDb.getItemList(request, formItem.getSelMstSiteId(), formItem.getSelMstId());
            }
        }

        return selectItemList;

    }

    /**
     * 数値 type=1
     * 
     * @author kurinami
     */
    protected static class Type1 extends FormItemUtil {

        private static final String NORMAL_PATTERN = "[\\+\\-]?[0-9]*(\\.[0-9]+)?";

        @Override
        public String[] validate(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix) {

            String[] result = null;

            /* 必須フラグチェック */
            result = ValidateUtil.checkRequire(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 標準チェック */
            result = ValidateUtil.checkPattern(NORMAL_PATTERN, postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 最少文字数チェック */
            result = ValidateUtil.checkLeast(formItem.getLeast(), postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 最大文字数チェック */
            result = ValidateUtil.checkMost(formItem.getMost(), postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 最小値チェック */
            result = ValidateUtil.checkMin(formItem.getMin(), postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix,
                    request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 最大値チェック */
            result = ValidateUtil.checkMax(formItem.getMax(), postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix,
                    request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 入力文字種別チェック */
            result = ValidateUtil.checkPattern(formItem.getLimitRegex(), postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            return result;
        }

    }

    /**
     * テキスト type=2
     * 
     * @author kurinami
     */
    protected static class Type2 extends FormItemUtil {

        @Override
        public String[] validate(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix) {

            String[] result = null;

            /* 必須フラグチェック */
            result = ValidateUtil.checkRequire(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 最少文字数チェック */
            result = ValidateUtil.checkLeast(formItem.getLeast(), postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 最大文字数チェック */
            result = ValidateUtil.checkMost(formItem.getMost(), postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 入力文字種別チェック */
            result = ValidateUtil.checkPattern(formItem.getLimitRegex(), postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            return result;
        }

    }

    /**
     * 複数行テキスト type=3
     * 
     * @author kurinami
     */
    protected static class Type3 extends Type2 {

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();
            return toBr(disps);
        }

        @Override
        public String[] getDisps() throws SQLException {
            String[] disps = SstagUtil.sanitize(super.getDispsNoenc());
            return toBr(disps);
        }

        @Override
        public String getDispNoenc() throws SQLException {
            return PhoenixUtil.concat(getDispsNoenc(), getDispDelimiter());
        }

        @Override
        public String getDisp() throws SQLException {
            return PhoenixUtil.concat(getDisps(), getDispDelimiter());
        }

        private String[] toBr(String[] disps) {
            for (int i = 0; i < disps.length; i++) {
                disps[i] = disps[i].replaceAll("\r\n", "<br />");
                disps[i] = disps[i].replaceAll("\r", "<br />");
                disps[i] = disps[i].replaceAll("\n", "<br />");
            }
            return disps;
        }

    }

    /**
     * タグテキスト(HTML,xml等) type=4
     * 
     * @author kurinami
     */
    protected static class Type4 extends FormItemUtil {

        @Override
        public String getValue() throws SQLException {
            return getValueNoenc();
        }

        @Override
        public String[] getValues() throws SQLException {
            return getValuesNoenc();
        }

        @Override
        public String getDisp() throws SQLException {
            return getDispNoenc();
        }

        @Override
        public String[] getDisps() throws SQLException {
            return getDispsNoenc();
        }

    }

    /**
     * 日付 type=7
     * 
     * @author kurinami
     */
    protected static class Type7 extends FormItemUtil {

        @Override
        public String getRaw() throws SQLException {
            return PhoenixUtil.dataCat(get(getRaws()), "");
        }

        @Override
        public String getValueNoenc() throws SQLException {
            return PhoenixUtil.dataCat(get(getValuesNoenc()), formItem.getDateTimeSep());
        }

        @Override
        public String getDispNoenc() throws SQLException {
            return PhoenixUtil.dataCat(get(getDispsNoenc()), formItem.getDateTimeSep());
        }

        @Override
        public String getDbValue() throws SQLException {
            return PhoenixUtil.dataCat(get(getRaws()), "");
        }

        protected String[] get(String[] data) {
            if (PhoenixUtil.isArrayEmpty(data)) {
                return new String[] { "", "", "" };
            } else if (data.length == 1 && data[0].length() == "yyyyMMdd".length()) {
                String year = data[0].substring(0, 4);
                String month = data[0].substring(4, 6);
                String day = data[0].substring(6, 8);
                return new String[] { year, month, day };
            } else {
                String year = data.length > 0 ? ValueUtil.nullToStr(data[0]).trim() : "";
                year = ValueUtil.lpad(year, '0', 4);
                String month = data.length > 1 ? ValueUtil.nullToStr(data[1]).trim() : "";
                month = ValueUtil.lpad(month, '0', 2);
                String day = data.length > 2 ? ValueUtil.nullToStr(data[2]).trim() : "";
                day = ValueUtil.lpad(day, '0', 2);
                return new String[] { year, month, day };
            }
        }

        @Override
        public String[] validate(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix)
                throws SQLException {

            String[] result = null;

            /* 必須フラグチェック */
            result = ValidateUtil.checkRequire(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 標準チェック */
            result = ValidateUtil.checkDatetime(getPattern(), getRaw(), msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            return result;
        }

        protected String getPattern() {
            return "yyyyMMdd";
        }

    }

    /**
     * 時刻 type=8
     * 
     * @author kurinami
     */
    protected static class Type8 extends Type7 {

        protected String[] get(String[] data) {
            if (PhoenixUtil.isArrayEmpty(data)) {
                return new String[] { "", "", "" };
            } else if (data.length == 1 && data[0].length() == "HHmmss".length()) {
                String hour = data[0].substring(0, 2);
                String minute = data[0].substring(2, 4);
                String second = data[0].substring(4, 6);
                return new String[] { hour, minute, second };
            } else {
                String hour = data.length > 0 ? ValueUtil.nullToStr(data[0]).trim() : "";
                hour = ValueUtil.lpad(hour, '0', 2);
                String minute = data.length > 1 ? ValueUtil.nullToStr(data[1]).trim() : "";
                minute = ValueUtil.lpad(minute, '0', 2);
                String second = data.length > 2 ? ValueUtil.nullToStr(data[2]).trim() : "";
                second = ValueUtil.lpad(second, '0', 2);
                return new String[] { hour, minute, second };
            }
        }

        protected String getPattern() {
            return "HHmmss";
        }

    }

    /**
     * タイムスタンプ(日時） type=9
     * 
     * @author kurinami
     */
    protected static class Type9 extends FormItemUtil {

        @Override
        public String getRaw() throws SQLException {
            return PhoenixUtil.dataCat(get(getRaws()), "");
        }

        @Override
        public String getValueNoenc() throws SQLException {
            String[] values = get(getValuesNoenc());
            if (PhoenixUtil.isArrayEmpty(values)) {
                return "";
            } else {
                return MessageFormat.format("{0}年 {1}月 {2}日 {3}時 {4}分 {5}秒", (Object[]) values);
            }
        }

        @Override
        public String getDispNoenc() throws SQLException {
            return getValueNoenc();
        }

        @Override
        public String getDbValue() throws SQLException {
            return PhoenixUtil.dataCat(get(getRaws()), "");
        }

        protected String[] get(String[] data) {
            if (PhoenixUtil.isArrayEmpty(data)) {
                return new String[] { "", "", "", "", "", "" };
            } else if (data.length == 1 && data[0].length() == "yyyyMMddHHmmss".length()) {
                String year = data[0].substring(0, 4);
                String month = data[0].substring(4, 6);
                String day = data[0].substring(6, 8);
                String hour = data[0].substring(8, 10);
                String minute = data[0].substring(10, 12);
                String second = data[0].substring(12, 14);
                return new String[] { year, month, day, hour, minute, second };
            } else {
                String year = data.length > 0 ? ValueUtil.nullToStr(data[0]).trim() : "";
                year = ValueUtil.lpad(year, '0', 4);
                String month = data.length > 1 ? ValueUtil.nullToStr(data[1]).trim() : "";
                month = ValueUtil.lpad(month, '0', 2);
                String day = data.length > 2 ? ValueUtil.nullToStr(data[2]).trim() : "";
                day = ValueUtil.lpad(day, '0', 2);
                String hour = data.length > 3 ? ValueUtil.nullToStr(data[3]).trim() : "";
                hour = ValueUtil.lpad(hour, '0', 2);
                String minute = data.length > 4 ? ValueUtil.nullToStr(data[4]).trim() : "";
                minute = ValueUtil.lpad(minute, '0', 2);
                String second = data.length > 5 ? ValueUtil.nullToStr(data[5]).trim() : "";
                second = ValueUtil.lpad(second, '0', 2);
                return new String[] { year, month, day, hour, minute, second };
            }
        }

        @Override
        public String[] validate(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix)
                throws SQLException {

            String[] result = null;

            /* 必須フラグチェック */
            result = ValidateUtil.checkRequire(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 標準チェック */
            result = ValidateUtil.checkDatetime(getPattern(), getRaw(), msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            return result;
        }

        protected String getPattern() {
            return "yyyyMMddHHmmss";
        }

    }

    /**
     * 氏名(氏+名) type=11
     * 
     * @author kurinami
     */
    protected static class Type11 extends FormItemUtil {

        @Override
        protected String getValueDelimiter() {
            return getDelimiter();
        }

        @Override
        protected String getDispDelimiter() {
            return getDelimiter();
        }

        protected String getDelimiter() {
            return "　";
        }

    }

    /**
     * フリガナ(シ+メイ) type=12
     * 
     * @author kurinami
     */
    protected static class Type12 extends Type11 {

        @Override
        protected String getDelimiter() {
            // 全角→半角変換の場合のみ半角空白
            if (formItem.getWcharConv() == ClmMetaMstBean.WCHAR_CONV_NARROW) {
                return " ";
            } else {
                return "　";
            }
        }

    }

    /**
     * 西暦生年月日(年+月+日） type=13
     * 
     * @author kurinami
     */
    protected static class Type13 extends Type7 {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }
    }

    /**
     * 和暦混合生年月日(年+月+日） type=14
     * 
     * @author kurinami
     */
    protected static class Type14 extends Type7 {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }
    }

    /**
     * 和暦元号選択(明治、大正、昭和、平成） type=15
     * 
     * @author kurinami
     */
    protected static class Type15 extends FormItemUtil {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }
    }

    /**
     * 年齢 type=16
     * 
     * @author kurinami
     */
    protected static class Type16 extends FormItemUtil {

        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();
            for (int i = 0; i < disps.length; i++) {
                if (!PhoenixUtil.isEmpty(disps[i])) {
                    disps[i] = disps[i] + "歳";
                }
            }
            return disps;
        }

    }

    /**
     * 性別 type=17
     * 
     * @author kurinami
     */
    protected static class Type17 extends FormItemUtil {

        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }

        @Override
        public String[] getRaws() throws SQLException {
            String[] raws = super.getRaws();
            String[] result = new String[raws.length];
            for (int i = 0; i < result.length; i++) {
                if (raws[i].equalsIgnoreCase("m")) {
                    result[i] = "1";
                } else if (raws[i].equalsIgnoreCase("f")) {
                    result[i] = "0";
                } else {
                    result[i] = "";
                }
            }
            return result;
        }

        @Override
        public String[] getValuesNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            String[] result = new String[values.length];
            for (int i = 0; i < result.length; i++) {
                if (values[i].equalsIgnoreCase("1")) {
                    result[i] = "m";
                } else if (values[i].equalsIgnoreCase("0")) {
                    result[i] = "f";
                } else {
                    result[i] = "";
                }
            }
            return result;
        }

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();
            String[] result = new String[disps.length];
            for (int i = 0; i < result.length; i++) {
                if (disps[i].equalsIgnoreCase("m")) {
                    result[i] = "男性";
                } else if (disps[i].equalsIgnoreCase("f")) {
                    result[i] = "女性";
                } else {
                    result[i] = "";
                }
            }
            return result;
        }

    }

    /**
     * 個人住所 type=18
     * 
     * @author kurinami
     */
    protected static class Type18 extends FormItemUtil {
        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_PREF_MST);
        }

        @Override
        public String[] getValuesNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            if (values.length > 2 && !PhoenixUtil.isEmpty(values[2])) {
                List<SelectItemBean> selectItemList = getSelectMst();
                for (SelectItemBean selectItem : selectItemList) {
                    if (selectItem.getValue().equals(values[2])) {
                        values[2] = selectItem.getName();
                        break;
                    }
                }

            }
            return values;
        }

        @Override
        public String getValueNoenc() throws SQLException {
            String[] values = get(getValuesNoenc());
            if (!PhoenixUtil.isEmpty(values) && !PhoenixUtil.isEmpty(values[0])) {
                values[0] = "〒" + values[0];
            }
            return PhoenixUtil.dataCat(values, "\n");
        }

        @Override
        public String getDispNoenc() throws SQLException {
            String[] disps = get(getDispsNoenc());
            if (!PhoenixUtil.isEmpty(disps) && !PhoenixUtil.isEmpty(disps[0])) {
                disps[0] = "〒" + disps[0];
            }
            return PhoenixUtil.dataCat(disps, "<br />");
        }

        @Override
        public String getDisp() throws SQLException {
            String[] disps = get(getDisps());
            if (!PhoenixUtil.isEmpty(disps) && !PhoenixUtil.isEmpty(disps[0])) {
                disps[0] = "〒" + disps[0];
            }
            return PhoenixUtil.dataCat(disps, "<br />");
        }

        @Override
        public String getDbValue() throws SQLException {
            return PhoenixUtil.dataCat(get(getRaws()), "\n");
        }

        private String[] get(String[] raws) {
            if (raws.length >= 2) {
                // 郵便番号だけは1つにつなげてまとめる。
                String[] result = new String[raws.length - 1];
                String sep = PhoenixUtil.isEmpty(raws[0]) && PhoenixUtil.isEmpty(raws[1]) ? "" : "-";
                result[0] = raws[0] + sep + raws[1];
                for (int i = 1; i < result.length; i++) {
                    result[i] = raws[i + 1];
                }
                raws = result;
            }
            return raws;
        }
    }

    /**
     * 会社住所 type=19
     * 
     * @author kurinami
     */
    protected static class Type19 extends Type18 {
    }

    /**
     * 国コード type=20
     * 
     * @author kurinami
     */
    protected static class Type20 extends Type51 {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }

        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_COUNTRY_MST);
        }
    }

    /**
     * 都道府県 type=21
     * 
     * @author kurinami
     */
    protected static class Type21 extends Type51 {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }

        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_PREF_MST);
        }
    }

    /**
     * エリアコード type=22
     * 
     * @author kurinami
     */
    protected static class Type22 extends Type51 {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }

        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_AREA_MST);
        }
    }

    /**
     * 郵便番号 type=23
     * 
     * @author kurinami
     */
    protected static class Type23 extends Type24 {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }

        @Override
        public String getDispNoenc() throws SQLException {
            String disp = super.getDispNoenc();
            return PhoenixUtil.isEmpty(disp) ? "" : "〒" + disp;
        }

    }

    /**
     * 電話番号 type=24
     * 
     * @author kurinami
     */
    protected static class Type24 extends FormItemUtil {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }

        @Override
        protected String getRawDelimiter() {
            return "";
        }

        @Override
        protected String getValueDelimiter() {
            return "-";
        }

        @Override
        protected String getDispDelimiter() {
            return "-";
        }

    }

    /**
     * E-mail type=25
     * 
     * @author kurinami
     */
    protected static class Type25 extends FormItemUtil {
        @Override
        protected int getWcharConv() {
            return ClmMetaMstBean.WCHAR_CONV_NARROW;
        }

        private static final String NORMAL_PATTERN = "[0-9a-zA-Z_\\,\\-\\.]+@[0-9a-zA-Z_\\,\\-\\.]+\\.[a-zA-Z]{2,3}";

        @Override
        public String[] validate(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix) {

            String[] result = null;

            /* 必須フラグチェック */
            result = ValidateUtil.checkRequire(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 標準チェック */
            result = ValidateUtil.checkPattern(NORMAL_PATTERN, postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 最少文字数チェック */
            result = ValidateUtil.checkLeast(new Integer(8), postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix,
                    request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 最大文字数チェック */
            result = ValidateUtil.checkMost(formItem.getMost(), postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* 入力文字種別チェック */
            result = ValidateUtil.checkPattern(formItem.getLimitRegex(), postItems, postFiles, msgMap, errmsgPrefix,
                    errmsgSuffix, request, formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            return result;
        }
    }

    /**
     * E-mail(確認入力付き） type=26
     * 
     * @author kurinami
     */
    protected static class Type26 extends Type25 {

        @Override
        public String getRaw() throws SQLException {
            String[] result = super.getRaws();
            if (PhoenixUtil.isEmpty(result)) {
                return "";
            } else {
                return result[0];
            }
        }

        @Override
        public String getValueNoenc() throws SQLException {
            return getRaw();
        }

        @Override
        public String getDispNoenc() throws SQLException {
            return getRaw();
        }

        @Override
        public String getDbValue() throws SQLException {
            return getRaw();
        }

        @Override
        public String[] validate(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix) {

            String[] result = null;

            /* 必須フラグチェック */
            result = ValidateUtil.checkRequire(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* email一致チェック */
            result = ValidateUtil.checkEmailMatch(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            return super.validate(msgMap, errmsgPrefix, errmsgSuffix);
        }

    }

    /**
     * 秘匿入力 type=27
     * 
     * @author kurinami
     */
    protected static class Type27 extends FormItemUtil {

        @Override
        public String[] getValuesNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            for (int i = 0; i < values.length; i++) {
                values[i] = ValueUtil.lpad("", '*', values[i].length());
            }
            return values;
        }

    }

    /**
     * 秘匿入力（確認入力付き) type=28
     * 
     * @author kurinami
     */
    protected static class Type28 extends Type27 {

        @Override
        public String getRaw() throws SQLException {
            String[] result = super.getRaws();
            if (PhoenixUtil.isEmpty(result)) {
                return "";
            } else {
                return result[0];
            }
        }

        @Override
        public String getValueNoenc() throws SQLException {
            String[] values = super.getValuesNoenc();
            if (PhoenixUtil.isEmpty(values)) {
                return "";
            } else {
                return values[0];
            }
        }

        @Override
        public String getDispNoenc() throws SQLException {
            return getValueNoenc();
        }

        @Override
        public String getDbValue() throws SQLException {
            return getRaw();
        }

        @Override
        public String[] validate(Map<String, String> msgMap, String errmsgPrefix, String errmsgSuffix)
                throws SQLException {

            String[] result = null;

            /* 必須フラグチェック */
            result = ValidateUtil.checkRequire(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            /* パスワード一致チェック */
            result = ValidateUtil.checkPasswordMatch(postItems, postFiles, msgMap, errmsgPrefix, errmsgSuffix, request,
                    formItem);
            if (!PhoenixUtil.isEmpty(result)) {
                return result;
            }

            return super.validate(msgMap, errmsgPrefix, errmsgSuffix);
        }

    }

    /**
     * 通貨単位 type=30
     * 
     * @author kurinami
     */
    protected static class Type30 extends Type51 {
        @Override
        public List<SelectItemBean> getSelectMst() throws SQLException {
            return SelectMstDb.getItemList(request, Constants.PHOENIX_MSTER_CURRENCY_MST);
        }
    }

    /**
     * 単一選択肢(radio) type=51
     * 
     * @author kurinami
     */
    protected static class Type51 extends FormItemUtil {

        @Override
        public String getDispDelimiter() {
            return ",";
        }

        @Override
        public String[] getDispsNoenc() throws SQLException {
            String[] disps = super.getDispsNoenc();

            List<SelectItemBean> selectItemList = getSelectMst();
            if (selectItemList != null) {
                // 選択肢マスタが存在した場合、
                String[] result = new String[disps.length];
                for (int i = 0; i < result.length; i++) {
                    result[i] = "";
                    for (SelectItemBean selectItem : selectItemList) {
                        if (disps[i].equals(selectItem.getValue())) {
                            result[i] = selectItem.getName();
                            break;
                        }
                    }
                }
                disps = result;
            }

            return disps;
        }

    }

    /**
     * 単一選択肢(select) type=52
     * 
     * @author kurinami
     */
    protected static class Type52 extends Type51 {
    }

    /**
     * 複数選択肢(checkbox) type=53
     * 
     * @author kurinami
     */
    protected static class Type53 extends Type51 {

        @Override
        public String[] getRaws() throws SQLException {
            String[] raws = super.getRaws();
            if (PhoenixUtil.isEmpty(raws) || raws.length == 1) {
                return raws;
            } else {
                // 選択肢が1つも選択されなかった時のhiddenフィールドの値を取り除く。
                List<String> list = new ArrayList<String>();
                for (String raw : raws) {
                    if (!PhoenixUtil.isEmpty(raw)) {
                        list.add(raw);
                    }
                }
                return list.toArray(new String[0]);
            }
        }

    }

    /**
     * 複数選択肢(list) type=54
     * 
     * @author kurinami
     */
    protected static class Type54 extends Type51 {
    }

    /**
     * 単一選択肢(radio)→画像使用 type=55
     * 
     * @author kurinami
     */
    protected static class Type55 extends Type51 {
    	//単一選択肢(radio)を継承するかたちで修正
    }

    /**
     * 単一選択肢(select)→画像使用 type=56
     * 
     * @author kurinami
     */
    protected static class Type56 extends Type52 {
    	//単一選択肢(select)を継承するかたちで修正
    }

    /**
     * 複数選択肢(checkbox)→画像使用 type=57
     * 
     * @author kurinami
     */
    protected static class Type57 extends Type53 {
    	//複数選択肢(checkbox)を継承するかたちで修正
    }

    /**
     * 複数選択肢(list)→画像使用 type=58
     * 
     * @author kurinami
     */
    protected static class Type58 extends Type54 {
    	//複数選択肢(list)を継承するかたちで修正
    }

    /**
     * GUID type=G1
     * 
     * @author kurinami
     */
    protected static class TypeG1 extends FormItemUtil {
        @Override
        public String[] getRaws() {
            String guid = SessionFilterUtil.getGuid(request);
            return new String[] { guid };
        }
    }

    /**
     * GSID type=G2
     * 
     * @author kurinami
     */
    protected static class TypeG2 extends FormItemUtil {
        @Override
        public String[] getRaws() {
            String gsid = SessionFilterUtil.getGsid(request);
            return new String[] { gsid };
        }
    }

    /**
     * SSID type=G3
     * 
     * @author kurinami
     */
    protected static class TypeG3 extends FormItemUtil {
        @Override
        public String[] getRaws() {
            String ssid = SessionFilterUtil.getSsid(request);
            return new String[] { ssid };
        }
    }

    /**
     * GOID type=G4
     * 
     * @author kurinami
     */
    protected static class TypeG4 extends FormItemUtil {
        @Override
        public String[] getRaws() throws SQLException {
            String goid = StoreUtil.getGoid(request);
            if (PhoenixUtil.isEmpty(goid)) {
                return new String[] {};
            } else {
                return new String[] { goid };
            }
        }

        @Override
        public String getDbValue() throws SQLException {
            String value = super.getDbValue();
            if (PhoenixUtil.isEmpty(value)) {
                int siteId = formItem.getSiteId();
                String goid = OrderInfoDb.getGoid(siteId);
                value = goid;
            }
            return value;
        }
    }

    /**
     * TOID type=G5
     * 
     * @author kurinami
     */
    protected static class TypeG5 extends FormItemUtil {
    }

}
