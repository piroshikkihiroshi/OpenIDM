package jp.co.webcrew.phoenix.sstag.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;

/**
 * 認証情報を保持するbeanクラス。
 * 
 * @author kurinami
 */
public class AdminAuthBean implements Serializable {

    /** デフォルトシリアルバージョン */
    private static final long serialVersionUID = 1L;

    /** 認証タイプ：ADとDB両方使用 */
    public static final int AUTH_TYPE_BOTH = 0;

    /** 認証タイプ：ActiveDirectory */
    public static final int AUTH_TYPE_AD = 1;

    /** 認証タイプ：database */
    public static final int AUTH_TYPE_DB = 2;

    /** ログイン認証ID */
    private String authId = "";

    /** ユーザId */
    private String userId = "";

    /** パスワード */
    private String password = "";

    /** ログイン日時 */
    private Date loginDate = null;

    /** 最終アクセス日時 */
    private Date lastAccessDate = null;

    /** 認証種別 */
    private int authType = AUTH_TYPE_BOTH;

    /** テーブル認証時のテーブルid */
    private String authTableId = "";

    /** テーブル認証時のテーブル情報 */
    private Map<String, ClmDataBean> authRecord = null;

    /**
     * コンストラクタ
     */
    public AdminAuthBean() {
    }

    /**
     * コンストラクタ
     * 
     * @param authId
     * @param userId
     * @param password
     * @param loginDate
     * @param lastAccessDate
     * @param authType
     * @param authTableId
     * @param authRecord
     */
    public AdminAuthBean(String authId, String userId, String password, Date loginDate, Date lastAccessDate,
            int authType, String authTableId, Map<String, ClmDataBean> authRecord) {
        this.authId = authId;
        this.userId = userId;
        this.password = password;
        this.loginDate = loginDate;
        this.lastAccessDate = lastAccessDate;
        this.authType = authType;
        this.authTableId = authTableId;
        this.authRecord = authRecord;
    }

    // 以下、アクセッサ。

    public String getAuthId() {
        return authId;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(Date loginDate) {
        this.loginDate = loginDate;
    }

    public Date getLastAccessDate() {
        return lastAccessDate;
    }

    public void setLastAccessDate(Date lastAccessDate) {
        this.lastAccessDate = lastAccessDate;
    }

    public int getAuthType() {
        return authType;
    }

    public void setAuthType(int authType) {
        this.authType = authType;
    }

    public String getAuthTableId() {
        return authTableId;
    }

    public void setAuthTableId(String authTableId) {
        this.authTableId = authTableId;
    }

    public Map<String, ClmDataBean> getAuthRecord() {
        return authRecord;
    }

    public void setAuthRecord(Map<String, ClmDataBean> authRecord) {
        this.authRecord = authRecord;
    }

}
