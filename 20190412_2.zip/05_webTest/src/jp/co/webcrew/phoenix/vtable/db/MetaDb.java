package jp.co.webcrew.phoenix.vtable.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.vtable.bean.ClmMetaMstBean;
import jp.co.webcrew.phoenix.vtable.bean.TblMetaMstBean;

public class MetaDb {

    /** テーブルメタ情報マスタの情報を取得するためのsql */
    private static final String SELECT_TBL_META_MST = ""
            + "select * from (schema_name).tbl_meta_mst where site_id = ? and tbl_id = ? ";

    /** カラムメタ情報マスタの一覧を取得するためのsql */
    private static final String SELECT_CLM_META_MST_LIST = ""
            + "select * from (schema_name).clm_meta_mst where site_id = ? and tbl_id = ? order by sort_num ";

    /**
     * テーブルメタ情報マスタの情報を取得する。
     * 
     * @param siteId
     * @param tblId
     * @return
     * @throws SQLException
     */
    public static TblMetaMstBean getTblMetaMst(int siteId, String tblId) throws SQLException {
        DBAccess dbAccess = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);
            return getTblMetaMst(dbAccess, siteId, tblId);
        } finally {
            DBAccess.close(dbAccess);
        }
    }

    /**
     * テーブルメタ情報マスタの情報を取得する。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @return
     * @throws SQLException
     */
    public static TblMetaMstBean getTblMetaMst(DBAccess dbAccess, int siteId, String tblId) throws SQLException {

        ResultSet rs = null;
        try {

            // テーブルメタ情報マスタの情報を取得する。
            dbAccess.prepareStatement(SELECT_TBL_META_MST);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, tblId);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                TblMetaMstBean tblMetaMst = new TblMetaMstBean();
                tblMetaMst.setSiteId(rs.getInt("site_id"));
                tblMetaMst.setTblId(ValueUtil.nullToStr(rs.getString("tbl_id")));
                tblMetaMst.setTblType(ValueUtil.nullToStr(rs.getString("tbl_type")));
                tblMetaMst.setTblSchema(ValueUtil.nullToStr(rs.getString("tbl_schema")));
                tblMetaMst.setTblName(ValueUtil.nullToStr(rs.getString("tbl_name")));
                tblMetaMst.setName(ValueUtil.nullToStr(rs.getString("name")));
                tblMetaMst.setDescription(ValueUtil.nullToStr(rs.getString("description")));
                // TODO kurinami 【確認】 アクセスレベルどうしよう。。。
                return tblMetaMst;
            } else {
                throw new SQLException("テーブルが存在しません。[site_id:" + siteId + "][tbl_id:" + tblId + "]");
            }

        } finally {
            DBAccess.close(rs);
        }
    }

    /**
     * カラムメタ情報マスタの一覧を取得する。
     * 
     * @param siteId
     * @param tblId
     * @return
     * @throws SQLException
     */
    public static List<ClmMetaMstBean> getClmMetaMstList(int siteId, String tblId) throws SQLException {
        DBAccess dbAccess = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);
            return getClmMetaMstList(dbAccess, siteId, tblId);
        } finally {
            DBAccess.close(dbAccess);
        }
    }

    /**
     * カラムメタ情報マスタの一覧を取得する。
     * 
     * @param dbAccess
     * @param siteId
     * @param tblId
     * @return
     * @throws SQLException
     */
    public static List<ClmMetaMstBean> getClmMetaMstList(DBAccess dbAccess, int siteId, String tblId)
            throws SQLException {

        ResultSet rs = null;
        try {

            List<ClmMetaMstBean> list = new ArrayList<ClmMetaMstBean>();

            // カラムメタ情報マスタの一覧を取得する。
            dbAccess.prepareStatement(SELECT_CLM_META_MST_LIST);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, tblId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                ClmMetaMstBean clmMetaMst = new ClmMetaMstBean();
                clmMetaMst.setSiteId(rs.getInt("site_id"));
                clmMetaMst.setTblId(ValueUtil.nullToStr(rs.getString("tbl_id")));
                clmMetaMst.setClmId(ValueUtil.nullToStr(rs.getString("clm_id")));
                clmMetaMst.setSortNum(rs.getInt("sort_num"));
                clmMetaMst.setDispName(ValueUtil.nullToStr(rs.getString("disp_name")));
                clmMetaMst.setType(ValueUtil.nullToStr(rs.getString("type")));
                clmMetaMst.setWcharConv(rs.getInt("wchar_conv"));
                clmMetaMst.setTimeOption(ValueUtil.nullToStr(rs.getString("time_option")));
                clmMetaMst.setOutStyleComma(ValueUtil.nullToStr(rs.getString("out_style_comma")));
                clmMetaMst.setOutStyleDate(ValueUtil.nullToStr(rs.getString("out_style_date")));
                clmMetaMst.setOutStyleTime(ValueUtil.nullToStr(rs.getString("out_style_time")));
                clmMetaMst.setPrefix(ValueUtil.nullToStr(rs.getString("prefix")));
                clmMetaMst.setSuffix(ValueUtil.nullToStr(rs.getString("suffix")));
                clmMetaMst.setSelMstSiteId(rs.getInt("sel_mst_site_id"));
                clmMetaMst.setSelMstId(ValueUtil.nullToStr(rs.getString("sel_mst_id")));
                list.add(clmMetaMst);
            }

            return list;

        } finally {
            DBAccess.close(rs);
        }
    }

}
