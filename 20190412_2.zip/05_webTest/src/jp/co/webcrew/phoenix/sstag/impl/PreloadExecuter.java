package jp.co.webcrew.phoenix.sstag.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.Constants;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;
import jp.co.webcrew.phoenix.vtable.db.VDb;

/**
 * マスタ情報のプリロードを行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class PreloadExecuter extends SSTagExecuter {

    /** パラメータ名：結果ID */
    private static final String RESULT_ID_PARAM_KEY = "result_id";

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：対象テーブル */
    private static final String TABLE_ID_PARAM_KEY = "table_id";

    /** パラメータ名：並べ替えの基準になる項目名 */
    private static final String ORDER_ITEM_PARAM_KEY = "order_item";

    /** パラメータ名：並べ替えの降順/昇順 */
    private static final String ORDER_DIR_PARAM_KEY = "order_dir";

    /** パラメータ名：検索条件 */
    private static final String WHERE_PARAM_KEY = "where";

    /** パラメータ名：読み込んだ情報をどこに保存するか */
    private static final String BIND_PARAM_KEY = "bind";

    /** ロガー */
    private static final Logger log = Logger.getLogger(PreloadExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            String resultId = ValueUtil.nullToStr(parameters.get(RESULT_ID_PARAM_KEY));
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String tableId = ValueUtil.nullToStr(parameters.get(TABLE_ID_PARAM_KEY));
            // TODO kurinami 【未実装】 パラメータ
            String orderItem = ValueUtil.nullToStr(parameters.get(ORDER_ITEM_PARAM_KEY));
            String orderDir = ValueUtil.nullToStr(parameters.get(ORDER_DIR_PARAM_KEY));
            // TODO kurinami 【未実装】 検索条件は実テーブルのときだけ
            String where = ValueUtil.nullToStr(parameters.get(WHERE_PARAM_KEY));
            String bind = ValueUtil.nullToStr(parameters.get(BIND_PARAM_KEY));

            // テーブルデータを取得する。
            List<Map<String, ClmDataBean>> list = VDb.getList(siteId, tableId, null, null, null, orderItem, orderDir);

            Map<String, Map<String, Object[]>> sResult = toSResult(tableId, list);

            // スクリーニング結果をセッションストアに書き込む。
            StoreUtil.setPreload(request, resultId, sResult, bind);

            // 置換パラメータに登録する。
            SstagUtil.setScreeningResultReplaceParam(request, resultId, sResult);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * 取得したテーブルデータを、スクリーニング結果と同じ形式にする。
     * 
     * @param tableId
     * @param list
     * @return
     */
    private Map<String, Map<String, Object[]>> toSResult(String tableId, List<Map<String, ClmDataBean>> list) {

        Map<String, Object[]> resultSet = new HashMap<String, Object[]>();

        if (!PhoenixUtil.isEmpty(list)) {
            for (Map.Entry<String, ClmDataBean> entry : list.get(0).entrySet()) {
                String dispName = entry.getValue().getMeta().getDispName();
                List<String> valueList = new ArrayList<String>();
                List<String> dispList = new ArrayList<String>();
                List<String> imageList = new ArrayList<String>();
                List<String> urlList = new ArrayList<String>();
                for (int i = 0; i < list.size(); i++) {
                    ClmDataBean clmData = list.get(i).get(entry.getKey());
                    valueList.add(clmData.getData());
                    dispList.add(ValueUtil.sanitize(clmData.getData()));
                    imageList.add("");
                    urlList.add("");
                }

                Object[] resultItem = new Object[Constants.OPTION_ITEM_INDEX];
                resultItem[Constants.NAME_ITEM_INDEX] = dispName;
                resultItem[Constants.VALUE_ITEM_INDEX] = valueList;
                resultItem[Constants.DISP_ITEM_INDEX] = dispList;
                resultItem[Constants.IMAGE_ITEM_INDEX] = imageList;
                resultItem[Constants.URL_ITEM_INDEX] = urlList;

                resultSet.put(entry.getKey(), resultItem);
            }
        }

        Map<String, Map<String, Object[]>> sResult = new HashMap<String, Map<String, Object[]>>();
        sResult.put(tableId, resultSet);

        return sResult;

    }

}
