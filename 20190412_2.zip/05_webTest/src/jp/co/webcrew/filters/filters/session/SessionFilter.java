package jp.co.webcrew.filters.filters.session;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.DBAccessCloseChecker;
import jp.co.webcrew.dbaccess.db.DBConnectionFactory;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.ProxyIpMstDb;
import jp.co.webcrew.filters.db.ProxyMstDb;
import jp.co.webcrew.filters.db.RefererMstDb;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.db.TermMstDb;
import jp.co.webcrew.filters.filters.replace.replacer.LsCodeReplacer;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.filters.util.httputil.CustomHttpServletRequest;
import jp.co.webcrew.login.common.SessionUtil;
import jp.co.webcrew.perflog.PerfLogger;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.fwsetting.FrameworkSettingRefreshMstDb;
import jp.co.webcrew.phoenix.htmlservlet.HtmlServletUtil;
import jp.co.webcrew.phoenix.util.PhoenixBackgroundRefreshMstDB;
import jp.co.webcrew.phoenix.util.PhoenixRequestContext;

/**
 * セッションを管理するためのfilterクラス。
 * 
 * @author kurinami
 */
public class SessionFilter implements Filter {

	/** 認証サーバのURL */
	public static final String AUTH_SERVER_URL = "{0}/checkUser.do?ls_code={1}&promo_code={2}&af_code={3}&time={4}";

	/** 認証サーバから帰ってきたときのリクエストにつけられているパラメータ名 */
	public static final String AUTH_RES_PARAM_KEY = "webcrew_auth_res";

	/** ローカルセッションコードをパラメータで渡す場合のパラメータ名 */
	public static final String LS_CODE_PARAM_KEY = "webcrew_ls_code";

	/** リクエストのパラメータマップを格納するセッションキー */
	public static final String REQUEST_PARAMETER_MAP_SES_KEY = "webcrew_parameter_map";

	/** リクエストのクエリストリングを格納するセッションキー */
	public static final String REQUEST_QUERY_STRING_SES_KEY = "webcrew_query_string";

	/** リクエストのボディを格納するセッションキー */
	public static final String REQUEST_REQUEST_BODY_SES_KRY = "webcrew_request_body";

	/** セッション種別：cookie */
	public static final String SESSION_TYPE_COOKIE = "0";

	/** セッション種別：uid */
	public static final String SESSION_TYPE_UID = "1";

	/** セッション種別：url */
	public static final String SESSION_TYPE_URL = "2";

	/** GUIDをヘッダに格納するためのキー名 */
	public static final String GUID_HEADER_KEY = "X-Webcrew-GUID";

	/** GSIDをヘッダに格納するためのキー名 */
	public static final String GSID_HEADER_KEY = "X-Webcrew-GSID";

	/** SSIDをヘッダに格納するためのキー名 */
	public static final String SSID_HEADER_KEY = "X-Webcrew-SSID";

	/** GS_CODEをヘッダに格納するためのキー名 */
	public static final String GS_CODE_HEADER_KEY = "X-Webcrew-GS_CODE";
	
	/** ロガー */
	private static final Logger log = Logger.getLogger(SessionFilter.class);

	/** プロキシリクエスタスレッド */
	private ProxyRequesterThread proxyRequesterThread;

	private static final String NO_AUTH_URL_SELECT = "SELECT count(1) AS count \n"
													 + " FROM dual \n"
													 + " WHERE \n"
													 + " (EXISTS \n"
													 + " ( \n"
													 + " SELECT 1 FROM (schema_name).clm_data d \n"
													 + " WHERE d.tbl_id = 'no_auth_url_start' AND d.clm_id = 'url' \n"
													 + " AND ? \n"
													 + " LIKE d.key_data || '%' \n"
													 + " ) \n"
													 + " OR \n"
													 + " EXISTS \n"
													 + " ( \n"
													 + " SELECT 1 FROM (schema_name).clm_data d \n"
													 + " WHERE d.tbl_id = 'no_auth_url_end' AND d.clm_id = 'url' \n"
													 + " AND ? \n"
													 + " LIKE '%' || d.key_data \n" 
													 + " ) \n"
													 + " )";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

		log.info("init start.");

		try {

			// 必要なDBを初期化しておく
			SiteMstDb.getInstance().init();
			TermMstDb.getInstance().init();
			RefererMstDb.getInstance().init();
			SystemPropertiesDb.getInstance().init();
			ProxyMstDb.getInstance().init();
			ProxyIpMstDb.getInstance().init();
			FrameworkSettingRefreshMstDb.getInstance().init();
			

			// 必須プロパティ確認用
			final String[] normalKeys = new String[] {
					SystemPropertiesDb.SITE_SESSION_TIMEOUT,
					SystemPropertiesDb.SITE_SESSION_STAY_LIMIT,
					SystemPropertiesDb.SITE_SESSION_STAY_LIMIT_CHECK_TERM,
					SystemPropertiesDb.SITE_SESSION_OUTER_SITE_CHECK_TERM,
					SystemPropertiesDb.LOGIN_TIMEOUT,
					SystemPropertiesDb.COOKIE_ERROR_REDIRECT_URL,
					SystemPropertiesDb.AUTH_HTTP_SERVER,
					SystemPropertiesDb.AUTH_HTTPS_SERVER, };

			// 時間を表すプロパティ確認用
			final String[] termKeys = new String[] {
					SystemPropertiesDb.SITE_SESSION_TIMEOUT,
					SystemPropertiesDb.SITE_SESSION_STAY_LIMIT,
					SystemPropertiesDb.SITE_SESSION_STAY_LIMIT_CHECK_TERM,
					SystemPropertiesDb.SITE_SESSION_OUTER_SITE_CHECK_TERM,
					SystemPropertiesDb.LOGIN_TIMEOUT, };

			// 必要なプロパティがそろっているかを確認する。
			SystemPropertiesDb.getInstance().check(normalKeys, termKeys);
			
			// プロキシリクエスタスレッドを開始する。
			proxyRequesterThread = new ProxyRequesterThread();
			proxyRequesterThread.start();
			
			//ここであえてコールしている
			DBAccessCloseChecker.setOutOfTargetDBPropNames("");

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			throw new ServletException(e);
		}

		log.info("init end.");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		try {
			try
			{	
				HttpServletRequest httpReq=(HttpServletRequest)request;
				
				PerfLogger.initEnv(httpReq.getServerName(),httpReq.getRequestURL().toString(),httpReq.getRequestURI());
				
			}
			catch(Throwable exc){}
			//PhoenixRequestContext.bindServletObject(request, response);
	        PerfLogger.filter_Start(this.getClass());
			
			
			// DBコネクションをスレッドに関連付ける。
			DBConnectionFactory.registConnectionOnThread();
	        //PerfLogger.snapFilter("SessionFilter#registConnectionOnThread");

			// filterの実処理を行う。
			execute(request, response, chain);
		} finally {
			// スレッドへのDBコネクションの関連付けを破棄する。
			DBConnectionFactory.unregistConnectionOnThread();
	        PerfLogger.filter_End(this.getClass());
	        try
	        {
				PerfLogger.doLog();
	        }
	        catch(Throwable th)
	        {
				PerfLogger.doLog();
	        }
			//PhoenixRequestContext.releaseServletObject();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// 処理なし
	}

	/**
	 * SessionFilterの実処理を行う
	 * 
	 * @param request
	 * @param response
	 * @param chain
	 * @throws IOException
	 * @throws ServletException
	 */
	private void execute(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		log.info("doFilter start.");

		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;

		String url = httpServletRequest.getRequestURL().toString();
		String referer = ValueUtil.nullToStr(httpServletRequest
				.getHeader("referer"));
		String remoteIp = httpServletRequest.getRemoteAddr();
		String ua = ValueUtil.nullToStr(httpServletRequest
				.getHeader("User-Agent"));
		
		if (remoteIp.equals("10.10.4.105") || remoteIp.equals("10.10.4.106")) {
		    log.debug("BigIPからのアクセスです");
		    ua = "Wget/BigIP " + remoteIp;
		}
		
		if (ua.length() == 0) {
			log.info("User-Agentが指定されていないリクエストです。");
			httpServletResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
			return;
		}

		try {

			Map siteInfo = SiteMstDb.getInstance().getSiteInfo(url);
			int siteId = ((Integer) siteInfo.get("site_id")).intValue();
			String promoParamName = (String) siteInfo.get("promo_param_name");
			if(siteId == SiteMstDb.OUTSIDE_SITE_ID) {
				if (url.indexOf(",") == -1)
				{
					log.error("url[" + url + "] がsite_recog_mstに登録されていません。");
				} else {
					log.info("url[" + url + "] がsite_recog_mstに登録されていません。恐らくincludeファイルです。");
				}
			}

			String promoCode = RefererMstDb.getInstance().getPromoCode(
					request.getParameter(promoParamName), referer);
			String afCode = ValueUtil.nullToStr(request.getParameter("afid"));

			Map termInfo = TermMstDb.getInstance().getTermInfo(ua);
			int termId = ((Integer) termInfo.get("term_id")).intValue();
			String carrier = (String) termInfo.get("carrier");

			UserInfo userInfo = null;
			
			if (ValueUtil.nullToStr(httpServletRequest.getHeader(GS_CODE_HEADER_KEY)).length() > 0 &&
					ProxyIpMstDb.getInstance().isProxyHost(request.getRemoteAddr())) {
				
				// プロキシリクエストによリクエストを受けた場合、
				log.info("case: proxy");
				
				String gsCode = ValueUtil.nullToStr(httpServletRequest.getHeader(GS_CODE_HEADER_KEY));

				// DBからユーザ情報を取得する。
				userInfo = MemberMstDb.getUserInfoByGsCode(gsCode, siteId,
						url, referer, log);

				// ユーザ情報を取得できなかった場合は、
				if (userInfo == null) {
					log.error("プロキシリクエストでユーザ情報が見つけられません。[gs_code: " + gsCode + "]");
					return;
				}
				
			} else if (carrier.equals(TermMstDb.TYPE_DOCOMO)) {
				// docomoの場合、
				log.info("case: docomo");

				String gwid = getDocomoGwid(httpServletRequest);
				String guid = getDocomoGuid(httpServletRequest);

				if(gwid != null || guid != null) {
					// 端末IDが取得できた場合、
					log.info("case: docomo  端末番号あり [docomo_gwid:" + gwid + "][docomo_guid:" + guid + "]");

					// 端末IDからグローバルセッションを検索する。
					GlobalSessionDb globalSession = null;
					
					if(gwid != null && globalSession == null) {
						globalSession = GlobalSessionDb.getInstance(" where ca_uniq_id1 = ?", new String[]{gwid});
					}
					
					if(guid != null && globalSession == null) {
						globalSession = GlobalSessionDb.getInstance(" where ca_uniq_id2 = ?", new String[]{guid});
					}

					if(globalSession != null) {
						// グローバルセッションが作成済みの場合
						log.info("case: docomo  グローバルセッションあり [docomo_gwid:" + gwid + "][docomo_guid:" + guid + "]");
						
						String gsCode = globalSession.getGsCode();
						userInfo = MemberMstDb.getUserInfoByGsCode(gsCode, siteId, url, referer, log);

						// 取得できなかった(サイトセッションがタイムアウト)場合は、作成する。
						if (userInfo == null) {
							log.info("case: docomo  グローバルセッションからサイトセッション作成 [gs_code: " + gsCode
									+ "]");
							userInfo = MemberMstDb.makeUserInfoByGsCode(gsCode,
									SESSION_TYPE_UID, siteId, url, referer,
									remoteIp, promoCode, afCode, termId, ua);
							// MemberMstDb.makeUserInfoByGsCode()の中でGlobalSessionが作り直される可能性があるので、再取得しておく。
							globalSession = new GlobalSessionDb();
							globalSession.setGsid(ValueUtil.toint(userInfo.getGsid()));
							globalSession.setGsCode(userInfo.getGsCode());
						}

					} else {
						// グローバルセッションが未作成の場合
						log.info("case: docomo  グローバルセッションなし [docomo_gwid:" + gwid + "][docomo_guid:" + guid + "]");
						
						// グローバルセッションから作成する。
						String gsCode = carrier + "-" + MemberMstDb.getLsCode();
						userInfo = MemberMstDb.makeUserInfoByGsCode(gsCode, SESSION_TYPE_UID, siteId, url, referer, remoteIp, promoCode, afCode, termId, ua);
						globalSession = new GlobalSessionDb();
						globalSession.setGsid(ValueUtil.toint(userInfo.getGsid()));
						globalSession.setGsCode(userInfo.getGsCode());
					}
					
					// グローバルセッション情報端末IDを更新する。
					globalSession.setCaUniqId1(gwid);
					globalSession.setCaUniqId2(guid);
					globalSession.save();

				} else {
					// 端末IDが取得できなかった場合、
					log.info("case: docomo  端末番号なし");

					// パラメータでローカルセッションコードが渡された場合、
					String lsCode = httpServletRequest
							.getParameter(LS_CODE_PARAM_KEY);
					if (lsCode != null) {
						log.info("case: docomo  パラメータにls_codeあり [ls_code: "
								+ lsCode + "]");
						userInfo = MemberMstDb.getUserInfoByLsCode(lsCode,
								siteId, url, referer, log);
					}

					// 有効なユーザ情報と関連付けられたローカルセッションコードがパラメータで渡されなかった場合、
					if (userInfo == null) {
						
						if (httpServletRequest.getParameter("uid") == null
								&& httpServletRequest.getParameter("guid") == null
								&& httpServletRequest.getMethod().equals("GET")) {  // TODO kurinami POSTでくるとスルーする。
							String requestUrl = httpServletRequest
									.getRequestURL().toString();
							String queryString = ValueUtil.nullToStr(httpServletRequest.getQueryString()).trim();
							requestUrl += "?" + (queryString.length() > 0 ? queryString + "&" : "") + "uid=NULLGWDOCOMO&guid=ON";

							// 端末ID取得用のパラメータを付与して自分自身にリダイレクトする。
							log.info("case: docomo  自分自身にリダイレクト");
							httpServletResponse.sendRedirect(requestUrl);
							return;

						} else {
							// ローカルセッションコードを生成する。
							lsCode = MemberMstDb.getLsCode();

							// ユーザ情報を作成する。
							log.info("case: docomo  ローカルセッションからユーザ情報作成 [ls_code: "
									+ lsCode + "]");
							userInfo = MemberMstDb.makeUserInfoByLsCode(lsCode,
									SESSION_TYPE_URL, siteId, url, referer,
									remoteIp, promoCode, afCode, termId, ua,
									carrier);
						}
					}
				}

				// urlのパラメータにローカルセッションコードを付与するために、それをリクエストの属性に格納する。
				httpServletRequest.setAttribute(
						LsCodeReplacer.REPLACE_LS_CODE_ATTR_KEY, userInfo
								.getLsCode());

			} else if (carrier.equals(TermMstDb.TYPE_AU)) {
				// auの場合、
				log.info("case: au");

				// 固体識別番号からグローバルセッションコードを生成する。
				String gsCode = getAuUid(httpServletRequest);

				if (gsCode != null) {
					// グローバルセッションコードが生成できた場合、
					log.info("case: au  端末番号あり");

					// DBからユーザ情報を取得する。
					userInfo = MemberMstDb.getUserInfoByGsCode(gsCode, siteId,
							url, referer, log);

					// 取得できなかった場合は、ユーザ情報を作成する。
					if (userInfo == null) {
						log.info("case: au  端末番号からユーザ情報作成 [gs_code: " + gsCode
								+ "]");
						userInfo = MemberMstDb.makeUserInfoByGsCode(gsCode,
								SESSION_TYPE_UID, siteId, url, referer,
								remoteIp, promoCode, afCode, termId, ua);
					}
				} else {
					// グローバルセッションコードが生成できなかった場合、
					log.info("case: au  端末番号なし");

					// パラメータでローカルセッションコードが渡された場合、
					String lsCode = httpServletRequest
							.getParameter(LS_CODE_PARAM_KEY);
					if (lsCode != null) {
						log.info("case: au  パラメータにls_codeあり [ls_code: "
								+ lsCode + "]");
						userInfo = MemberMstDb.getUserInfoByLsCode(lsCode,
								siteId, url, referer, log);
					}

					// 有効なユーザ情報と関連付けられたローカルセッションコードがパラメータで渡されなかった場合、
					if (userInfo == null) {

						// ローカルセッションコードを生成する。
						lsCode = MemberMstDb.getLsCode();

						// ユーザ情報を作成する。
						log.info("case: au  ローカルセッションからユーザ情報作成 [ls_code: "
								+ lsCode + "]");
						userInfo = MemberMstDb.makeUserInfoByLsCode(lsCode,
								SESSION_TYPE_URL, siteId, url, referer,
								remoteIp, promoCode, afCode, termId, ua,
								carrier);
					}

					// urlのパラメータにローカルセッションコードを付与するために、それをリクエストの属性に格納する。
					httpServletRequest.setAttribute(
							LsCodeReplacer.REPLACE_LS_CODE_ATTR_KEY, userInfo
									.getLsCode());
				}
			} else if (carrier.equals(TermMstDb.TYPE_SOFTBANK)) {
				// softbankの場合、
				log.info("case: softbank");

				// 固体識別番号からグローバルセッションコードを生成する。
				String gsCode = getSoftbankUid(httpServletRequest);

				if (gsCode != null) {
					// グローバルセッションコードが生成できた場合、
					log.info("case: softbank  端末番号あり");

					// DBからユーザ情報を取得する。
					userInfo = MemberMstDb.getUserInfoByGsCode(gsCode, siteId,
							url, referer, log);

					// 取得できなかった場合は、ユーザ情報を作成する。
					if (userInfo == null) {
						log.info("case: softbank  端末番号からユーザ情報作成 [gs_code: "
								+ gsCode + "]");
						userInfo = MemberMstDb.makeUserInfoByGsCode(gsCode,
								SESSION_TYPE_UID, siteId, url, referer,
								remoteIp, promoCode, afCode, termId, ua);
					}
				} else {
					// グローバルセッションコードが生成できなかった場合、
					log.info("case: softbank  端末番号なし");

					// パラメータでローカルセッションコードが渡された場合、
					String lsCode = httpServletRequest
							.getParameter(LS_CODE_PARAM_KEY);
					if (lsCode != null) {
						log.info("case: softbank  パラメータにls_codeあり [ls_code: "
								+ lsCode + "]");
						userInfo = MemberMstDb.getUserInfoByLsCode(lsCode,
								siteId, url, referer, log);
					}

					// 有効なユーザ情報と関連付けられたローカルセッションコードがパラメータで渡されなかった場合、
					if (userInfo == null) {

						// ローカルセッションコードを生成する。
						lsCode = MemberMstDb.getLsCode();

						// ユーザ情報を作成する。
						log
								.info("case: softbank  ローカルセッションからユーザ情報作成 [ls_code: "
										+ lsCode + "]");
						userInfo = MemberMstDb.makeUserInfoByLsCode(lsCode,
								SESSION_TYPE_URL, siteId, url, referer,
								remoteIp, promoCode, afCode, termId, ua,
								carrier);
					}

					// urlのパラメータにローカルセッションコードを付与するために、それをリクエストの属性に格納する。
					httpServletRequest.setAttribute(
							LsCodeReplacer.REPLACE_LS_CODE_ATTR_KEY, userInfo
									.getLsCode());
				}
			} else if (carrier.equals(TermMstDb.TYPE_CRAWLER)) {
				// クローラの場合、
				log.info("case: crawler");

				// クローラ用のユーザ情報を作成する。
				userInfo = UserInfo.getCrawlerUserInfo();

			} else if (isNoAuthUrl(url))
			{
				// 対象外URLの場合
				log.info("case: 対象外URL：" + url);

				try
				{
					//CSSやJSの場合はクローラと同じ扱い。
					if (url.endsWith(".css") || url.endsWith(".js"))
					{
						userInfo = UserInfo.getCrawlerUserInfo();
					} else {
						// 対象外でかつHTMLのアクセスの場合はSSIDのみシーケンスから取得する（フェニックスを考慮）。
						userInfo = UserInfo.getNoAuthUserInfo();
					}
					
				} catch (Exception e)
				{
					log.error("対象外ユーザ情報生成処理でエラーが発生しました。URL：" + url + "、エラーメッセージ：" + e.getMessage());
					//失敗することはないと思うが万一失敗したらもうクローラ扱いでよい。
					userInfo = UserInfo.getCrawlerUserInfo();
				}
			
			}  else {
				// PCの場合、
				log.info("case: pc");

				// ローカルセッション作成済みの場合
				if (httpServletRequest.getSession(false) != null) {
					log.info("case: pc  ローカルセッション作成済み");

					// DBからユーザ情報を取得する。
					String lsCode = MemberMstDb.getLsCode(httpServletRequest);
					userInfo = MemberMstDb.getUserInfoByLsCode(lsCode, siteId,
							url, referer, log);

					// 認証サーバからの戻りで、無事ユーザ情報が作れている場合、
					if (userInfo != null
							&& httpServletRequest
									.getParameter(AUTH_RES_PARAM_KEY) != null) {

						// 認証サーバからの戻りをあらわすパラメータを消すために自分自身にもう1度リダイレクトする。
						HttpSession session = httpServletRequest.getSession();
						String requestUrl = httpServletRequest.getRequestURL()
								.toString();
						String queryString = ValueUtil.nullToStr(session
								.getAttribute(REQUEST_QUERY_STRING_SES_KEY));
						boolean idEraseFlag = ((Boolean) siteInfo
								.get("id_erase_flag")).booleanValue();
						if (idEraseFlag) {
							queryString = paramEraseFilter(queryString,
									promoParamName);
						}
						String redirectUrl = requestUrl
								+ (queryString.length() > 0 ? "?" : "")
								+ queryString;

						log.info("case: pc  自分自身にもう1度リダイレクト [redirect_url: "
								+ redirectUrl + "]");
						httpServletResponse.sendRedirect(redirectUrl);
						return;
					}
				} else {
					log.info("case: pc  ローカルセッション未作成");
				}

				// DBからユーザ情報を取得できなかった場合
				if (userInfo == null) {
					log.info("case: pc  ローカルの情報からは有効なサイトセッション見つけられず");

					if (httpServletRequest.getParameter(AUTH_RES_PARAM_KEY) == null) {
						// 認証サーバからの戻りでなく、直接リクエストが呼ばれた場合、

						// このリクエストの情報をセッションに格納しておく。
						setRequestInfoToSession(httpServletRequest);

						// 認証連携用テーブルに格納する。
						String lsCode = MemberMstDb
								.getLsCode(httpServletRequest);
						String requestUrl = httpServletRequest.getRequestURL()
								.toString();
						CoordinateAuthDb.insert(lsCode, siteId, requestUrl);

						// 認証サーバにリダイレクトする。
						log.info("case: pc  認証サーバにリダイレクト [ls_code: " + lsCode
								+ "]");
						String authServer;
						if (request.getScheme().equals("http")) {
							authServer = SystemPropertiesDb.getInstance().get(
									SystemPropertiesDb.AUTH_HTTP_SERVER);
						} else {
							authServer = SystemPropertiesDb.getInstance().get(
									SystemPropertiesDb.AUTH_HTTPS_SERVER);
						}
						String time = ValueUtil.toDateTimeString(new Date());
						httpServletResponse.sendRedirect(new MessageFormat(
								AUTH_SERVER_URL).format(new String[] {
								authServer, lsCode, promoCode, afCode, time }));

						return;
					} else {
						// 認証サーバからの戻りの場合(クッキーoffの場合)
						log.info("case: pc  クッキーエラー。DB登録処理開始");
						// クッキーエラーログをDBに記録する。
						//wcdbi障害発生時にサービスに影響がでる可能性あり。よってコメント化(2013.06.12)
						// Issue0061655: cookieエラーログの集計再開（2013.10.22）
						CookieErrorLogDb.insert(ua);
						sendCookieError(httpServletResponse);
						return;
					}
				}

				// リダイレクト前のリクエストの情報がセッションに退避してあった場合、
				HttpSession session = httpServletRequest.getSession();
				if (session.getAttribute(REQUEST_PARAMETER_MAP_SES_KEY) != null) {
					// もともとのリクエストの情報を今回のリクエストに乗せる。
					request = httpServletRequest = getWrappedRequestFromSession(httpServletRequest);
				}

			}

			// ユーザ情報をアプリから見えるようにリクエストスコープに格納する。
			userInfo.setUserInfoToRequest(httpServletRequest);
			
			// プロキシするリクエストの場合、ここで終了とする。
			if (checkProxyRequest(httpServletRequest, httpServletResponse)) {
				return;
			}

		} catch (Exception e) {
			log.error("予期せぬエラー \n" +
					  "その際のユーザ情報 \n" +
					  "UA：" + ua + "\n" +
					  "requrl：" + url + "\n" +
					  "refer：" + referer + "\n", e);
			httpServletResponse
					.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return;
		}

		chain.doFilter(request, response);

		log.info("doFilter end.");
	}

	/**
	 * このリクエストの情報をセッションに格納する。<br>
	 * リダイレクトして戻ってきたときに、そのリクエストにこの情報を設定しなおすため。<br>
	 * 
	 * @param httpServletRequest
	 * @throws IOException
	 */
	private void setRequestInfoToSession(HttpServletRequest httpServletRequest)
			throws IOException {
		HttpSession session = httpServletRequest.getSession();

		// パラメータ一覧を退避させる。
		Map parameterMap = httpServletRequest.getParameterMap();
		session.setAttribute(REQUEST_PARAMETER_MAP_SES_KEY, new HashMap(
				parameterMap));

		// クエリ文字列を退避させる。
		String queryString = ValueUtil.nullToStr(httpServletRequest
				.getQueryString());
		session.setAttribute(REQUEST_QUERY_STRING_SES_KEY, queryString);

		// リクエストボディを退避させる。
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		int len = 0;
		byte[] buf = new byte[64 * 1024];
		ServletInputStream inputStream = httpServletRequest.getInputStream();
		while ((len = inputStream.read(buf)) >= 0) {
			baos.write(buf, 0, len);
		}
		baos.flush();
		session.setAttribute(REQUEST_REQUEST_BODY_SES_KRY, baos.toByteArray());
	}

	/**
	 * 今回のリクエストをセッションに格納したリクエスト情報に置き換えたラップリクエストを返す。
	 * 
	 * @param httpServletRequest
	 * @return
	 */
	private HttpServletRequest getWrappedRequestFromSession(
			HttpServletRequest httpServletRequest) {

		HttpSession session = httpServletRequest.getSession();
		CustomHttpServletRequest customHttpServletRequest = new CustomHttpServletRequest(
				httpServletRequest);
		customHttpServletRequest.setParameterMap((Map) session
				.getAttribute(REQUEST_PARAMETER_MAP_SES_KEY));
		customHttpServletRequest.setQueryString((String) session
				.getAttribute(REQUEST_QUERY_STRING_SES_KEY));
		customHttpServletRequest.setRequestBody((byte[]) session
				.getAttribute(REQUEST_REQUEST_BODY_SES_KRY));
		session.removeAttribute(REQUEST_PARAMETER_MAP_SES_KEY);
		session.removeAttribute(REQUEST_QUERY_STRING_SES_KEY);
		session.removeAttribute(REQUEST_REQUEST_BODY_SES_KRY);
		return customHttpServletRequest;

	}

	/**
	 * docomo端末の公式サイト用の端末IDを返す。
	 * 
	 * @param request
	 * @return
	 */
	private String getDocomoGwid(HttpServletRequest request) {
		String gwid = ValueUtil.nullToStr(request.getParameter("uid"));
		if(!gwid.equals("NULLGWDOCOMO") && gwid.length() == "NULLGWDOCOMO".length()) {
			return "docomo-" + gwid;
		}
		return null;
	}
	
	/**
	 * docomo端末のiモードIDを返す。
	 * 
	 * @param request
	 * @return
	 */
	private String getDocomoGuid(HttpServletRequest request) {
		String guid =ValueUtil.nullToStr(request.getHeader("X-DCMGUID"));
		if(!guid.equals("") && guid.length() == "DCMGUID".length()) {
			return "docomo-" + guid;
		}
		return null;
	}

	/**
	 * AU端末の固体識別番号にmd5をかけて 当システムで使用するグローバルセッションコードを作成する。
	 * 
	 * @param request
	 * @return
	 */
	private String getAuUid(HttpServletRequest request) {
		String id = ValueUtil.nullToStr(request.getHeader("X-Up-Subno"));
		if (id.length() > 0) {
			log.info("case: au  get [端末番号: " + id + "]");
			return ValueUtil.getMd5Digest(id);
		} else {
			return null;
		}
	}

	/**
	 * softbank端末の固体識別番号にmd5をかけて 当システムで使用するグローバルセッションコードを作成する。
	 * 
	 * @param request
	 * @return
	 */
	private String getSoftbankUid(HttpServletRequest request) {

		String ua = ValueUtil.nullToStr(request.getHeader("User-Agent"))
				.toLowerCase();
		log.info("case: softbank  [ua: " + ua + "]");

		int serialPartPos = ua.startsWith("j-phone") ? 3 : 4;
		int startIndex = 0;
		for (int i = 0; i < serialPartPos; i++) {
			startIndex = ua.indexOf('/', startIndex + 1);
			if (startIndex < 0) {
				break;
			}
		}

		if (startIndex >= 0
				&& ua.substring(startIndex).toLowerCase().startsWith("/sn")) {
			int endIndex = ua.indexOf(' ', startIndex + 1);
			endIndex = endIndex < 0 ? ua.length() : endIndex;

			String id = ua.substring(startIndex + "/sn".length(), endIndex)
					.trim();
			if (id.length() > 0) {
				log.info("case: softbank  get [端末番号: " + id + "]");
				return ValueUtil.getMd5Digest(id);
			}
		}

		return null;
	}

	/**
	 * QueryStringにつけられたパラメータで見た目上削除したいものを削除する。
	 * 
	 * @param source
	 * @param paramName
	 * @return
	 */
	private static String paramEraseFilter(String source, String paramName) {

		// 制御しやすいように頭に&をつける。
		source = "&" + source;

		StringBuffer sb = new StringBuffer();

		int index = 0;
		while (index < source.length()) {

			// パラメータの終わりの部分を検索する。
			int nextIndex = source.indexOf("&", index + 1);
			nextIndex = nextIndex >= 0 ? nextIndex : source.length();

			if (source.startsWith("&" + paramName + "=", index)
					|| source.startsWith("&" + paramName + "&", index)
					|| source.substring(index).equals("&" + paramName)) {
				// 削除対象パラメータの場合、結果に含めない。
			} else {
				// 削除対象パラメータでない場合、結果に含める。
				sb.append(source.substring(index, nextIndex));
			}

			index = nextIndex;
		}

		String ret = sb.toString();
		return ret.length() == 0 ? "" : ret.substring(1);
	}

	/**
	 * クッキーエラー画面に遷移する。
	 * 
	 * @param response
	 * @throws IOException
	 */
	private void sendCookieError(HttpServletResponse response)
			throws IOException {
		String redirectUrl = SystemPropertiesDb.getInstance().get(
				SystemPropertiesDb.COOKIE_ERROR_REDIRECT_URL);
		log.info("クッキーエラー画面に遷移");
		response.sendRedirect(redirectUrl);
	}

	/**
	 * プロキシリクエストを送るかを判定する。
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	private boolean checkProxyRequest(HttpServletRequest request, HttpServletResponse response) {
		String servletPath = request.getServletPath();
		if (servletPath.equals(ProxyRequesterThread.PROXY_REQUEST_PATH)) {
			proxyRequesterThread.push(request, response);
			
			// 空画像を返す。
			try {
				response.setContentType("image/gif");
				ServletOutputStream sos = response.getOutputStream();
				InputStream is = SessionFilter.class.getResourceAsStream("spacer.gif");
				byte[] buf = new byte[1024];
				while(is.read(buf) > 0) {
					sos.write(buf);
				}
				sos.flush();
			} catch (IOException e) {
				log.error("予期せぬエラー", e);
			}
			
			return true;
		} else {
			return false;
		}
	}
	
	private boolean isNoAuthUrl(String url)
	{
		PhoenixDBAccess db = null;
		ResultSet rs = null;
		
		boolean result = false;
		
		try
		{
			//CSSとJSは無条件に対象外。
			if (url.endsWith(".css") || url.endsWith(".js"))
			{
				return true;
			}
			//includeも無条件に除外
			//既存サイトからフェニックスへリダイレクトされた再に
			//「,」で同一ドメインが区切られたURLになり、サイトID
			//が取得できない問題を考慮
			if (url.indexOf("/include/") != -1)
			{
				return true;
			}
			
			db = new PhoenixDBAccess(800);
			
			db.prepareStatement(NO_AUTH_URL_SELECT);
			db.setString(1, url);
			db.setString(2, url);
			
			rs = db.executeQuery();
			
			if (rs.next())
			{
				int count = ValueUtil.toint(rs.getString("count"));
				if (count > 0)
				{
					result = true;
				}
			}
			
		} catch (Exception e) {
			log.error("認証サーバリダイレクト対象外判断でエラーです。URL：" + url + "エラーメッセージ：" + e.getMessage());
		} finally
		{
			PhoenixDBAccess.close(db);
			PhoenixDBAccess.close(rs);
		}
		return result;
	}
}
