package jp.co.webcrew.dbaccess.db;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * プールコネクションrefresh用threadクラス。
 * 
 * @author kurinami
 */
public class DBConnectionThread implements Runnable {

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(DBConnectionThread.class);

	/** コネクション名とインスタンスとのmap */
	private static Map dbConnectionThreadMap = Collections
			.synchronizedMap(new HashMap());

	/** コネクション名 */
	private String name = "";

	/** リフレッシュ間隔 */
	private int connectionRefreshMinutes = 0;

	/** リフレッシュを行うかのプールコネクション使用頻度上限回数 */
	private int limitUseCountPerMinuteForReferesh = 0;

	/** 直近1分間でのコネクション使用回数 */
	private int useCount = 0;

	/**
	 * コンストラクタ
	 */
	private DBConnectionThread() {
	}

	/**
	 * コネクションプールのリフレッシュが必要かをチェックする。
	 */
	public void run() {

		int minutes = 0;

		while (true) {

			if (minutes >= connectionRefreshMinutes) {
				log.debug("name:[" + name + "] DBコネクションのプールをリフレッシュする間隔が経過しました");
				if (useCount < limitUseCountPerMinuteForReferesh) {
					log.debug("name:[" + name + "] DBコネクションのプールをリフレッシュします");
					DBConnectionFactory.poolRefresh(name);
					minutes = 0;
				} else {
					log.debug("name:[" + name
							+ "] DBコネクションの使用頻度が高いためリフレッシュを後回しにします");
				}
			}

			useCount = 0;

			try {
				Thread.sleep(60 * 1000);
			} catch (InterruptedException e) {
				log.error("name:[" + name + "] 予期せぬエラー", e);
			}
			minutes++;
		}
	}

	/**
	 * コネクションを使用したことを通知する。
	 */
	public static void noticeUse(String name) {

		DBConnectionThread dbConnectionThread = null;
		if (!dbConnectionThreadMap.containsKey(name)) {
			int connectionRefreshMinutes = ValueUtil.toint(DBConnectionFactory
					.getDBProperty(name, "connectionRefreshMinutes"));

			int limitUseCountPerMinuteForReferesh = ValueUtil
					.toint(DBConnectionFactory.getDBProperty(name,
							"limitUseCountPerMinuteForReferesh"));

			if (connectionRefreshMinutes > 0) {
				// リフレッシュ間隔が指定されている場合、デーモンスレッドを起動する。
				dbConnectionThread = new DBConnectionThread();
				dbConnectionThreadMap.put(name, dbConnectionThread);
				dbConnectionThread.name = name;
				dbConnectionThread.connectionRefreshMinutes = connectionRefreshMinutes;
				dbConnectionThread.limitUseCountPerMinuteForReferesh = limitUseCountPerMinuteForReferesh;

				log.debug("name:[" + name + "] start daemon thread ["
						+ dbConnectionThread.getClass().getName() + "]");
				Thread thread = new Thread(dbConnectionThread);
				thread.setDaemon(true);
				thread.start();
			} else {
				// リフレッシュ間隔が指定されていない場合、何もしない。
				return;
			}

		} else {
			dbConnectionThread = (DBConnectionThread) dbConnectionThreadMap
					.get(name);
		}

		// 使用回数をカウントしておく。
		dbConnectionThread.useCount++;
	}

}
