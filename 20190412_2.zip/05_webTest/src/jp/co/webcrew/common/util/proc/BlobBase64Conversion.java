package jp.co.webcrew.common.util.proc;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.SQLException;

import oracle.sql.BLOB;
import oracle.sql.CLOB;

/**
 * A hack function set intended to be run as a java stored procedure. This
 * converts between blobs and base 64, so that we can easily access blob data
 * in the kanri engine.
 * 
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: BlobBase64Conversion.java,v 1.2 2005-04-27 08:28:35 rickk Exp $
 */
public class BlobBase64Conversion {
    
    public static Clob blobToBase64(Blob blob) throws SQLException {
        try {
            if (blob == null) {
                return null;
            } else {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                BLOB oracleBlob = (BLOB) blob;
                byte buffer[] = new byte[oracleBlob.getBufferSize()];
                int read = 0;
                InputStream in = blob.getBinaryStream();
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
                in.close();
                CLOB clob = CLOB.createTemporary(oracleBlob.getJavaSqlConnection(), false, CLOB.DURATION_SESSION);
                clob.setString(1,  Base64.encodeBase64(out.toByteArray()));
                return clob;
            }
        } catch (SQLException err) {
            err.printStackTrace();
            throw err;
        } catch (IOException err) {
            err.printStackTrace();
            throw new SQLException("IOException: " + err.toString());
        }
    }
    
    public static Blob base64ToBlob(Clob clob) throws SQLException {
        try {
            if (clob == null) {
                return null;
            } else {
                StringWriter out = new StringWriter();
                CLOB oracleClob = (CLOB) clob;
                char buffer[] = new char[oracleClob.getBufferSize()];
                int read = 0;
                Reader in = clob.getCharacterStream();
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
                in.close();
                BLOB blob = BLOB.createTemporary(oracleClob.getJavaSqlConnection(), false, BLOB.DURATION_SESSION);
                blob.setBytes(1,  Base64.decodeBase64(out.toString()));
                return blob;
            }
        } catch (SQLException err) {
            err.printStackTrace();
            throw err;
        } catch (IOException err) {
            err.printStackTrace();
            throw new SQLException("IOException: " + err.toString());
        }
    }
}
