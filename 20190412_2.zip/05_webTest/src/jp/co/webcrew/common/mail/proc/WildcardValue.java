package jp.co.webcrew.common.mail.proc;


/**
 * Encapsulates a wildcard that we send to the calculation set. Holds the
 * value (which can be null) and the type of the object.
 */
public class WildcardValue {

    private String name;
    private Object value;
    private String type;
    
    public WildcardValue(String name, Object value, String type) {
        this.name = name;
        this.value = value;
        this.type = type;
    }
    
    public String getName() {
        return name;
    }
    public String getType() {
        return type;
    }
    public Object getValue() {
        return value;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setType(String type) {
        this.type = type;
    }
    public void setValue(Object value) {
        this.value = value;
    }
    
    public String toString() {
        return "Wildcard: name=" + this.name + 
                " value=" + this.value + " type=" + this.type;
    }
}
