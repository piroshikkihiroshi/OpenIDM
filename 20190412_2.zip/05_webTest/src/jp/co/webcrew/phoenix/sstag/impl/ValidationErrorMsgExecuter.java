package jp.co.webcrew.phoenix.sstag.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.sstag.util.ValidateUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * バリデーションエラー時のメッセージを指定するsstagクラス。
 * 
 * @author kurinami
 */
public class ValidationErrorMsgExecuter extends SSTagExecuter {

    /** パラメータ名：メッセージID */
    private static final String MSG_ID_PARAM_KEY = "msg_id";

    /** パラメータ名：エラー番号とエラーメッセージの組み合わせ */
    private static final String MESSAGE_PARAM_KEY = "message";

    /** パラメータ名：ファイルのパス名 */
    private static final String FILE_PARAM_KEY = "file";

    /** ロガー */
    private static final Logger log = Logger.getLogger(ValidationErrorMsgExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#getExcludeParamList
     * ()
     */
    @SuppressWarnings("unchecked")
    @Override
    protected List getExcludeParamList() {
        return Arrays.asList(MESSAGE_PARAM_KEY);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    @SuppressWarnings("unchecked")
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            String msgId = ValueUtil.nullToStr(parameters.get(MSG_ID_PARAM_KEY));
            String message = ValueUtil.nullToStr(parameters.get(MESSAGE_PARAM_KEY));
            String file = ValueUtil.nullToStr(parameters.get(FILE_PARAM_KEY));

            String fileMessage = "";
            // ファイル名が指定されている場合、
            if (!PhoenixUtil.isEmpty(file)) {
                // ファイルの中身を取り込む。
                fileMessage = SstagUtil.getInclude(file, request, response);
            }

            // エラーメッセージマップを作成する。
            Map<String, String> msgMap = ValidateUtil.getDefaultMsgMap();
            ValidateUtil.setMsgMap(fileMessage, msgMap);
            ValidateUtil.setMsgMap(message, msgMap);

            // エラーメッセージマップを保存する。
            StoreUtil.setMsgMap(request, msgId, msgMap);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    public static void main(String[] args) {

        String message = "1\t\t %{form.item.title}は入力必須です\n"
                + "                         2 %{form.item.title}に%{form.item.value} は入力できません\n"
                + "                         3 %{form.item.title}は以下の値だけが入力できます |\n"
                + "                             aaa, bbb, ccc |\n" + "                             ddd, eee, fff\n"
                + "                         4 %{form.item.title} は %{form.item.min} ～ %{form.item.max} の範囲で入力してください\n"
                + "                        ";

        Map<String, String> msgMap = new HashMap<String, String>();
        ValidateUtil.setMsgMap(message, msgMap);
        for (Map.Entry<String, String> entry : msgMap.entrySet()) {
            System.out.println("[" + entry.getKey() + "] " + entry.getValue());
        }

    }

}
