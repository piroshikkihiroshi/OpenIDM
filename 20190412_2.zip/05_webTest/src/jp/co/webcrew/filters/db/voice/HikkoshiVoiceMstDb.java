package jp.co.webcrew.filters.db.voice;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.bean.voice.HikkoshiVoiceBean;
import jp.co.webcrew.filters.bean.voice.VoiceBean;
import jp.co.webcrew.login.common.util.Kana2Roma;

/**
 * 口コミ一覧を管理するdbクラス。
 * 
 * @author Fu
 */
public class HikkoshiVoiceMstDb extends RefreshMstDb {

    /** ロガー */
    private static final Logger objLog = Logger.getLogger(HikkoshiVoiceMstDb.class);

    /** 口コミ一覧情報取得用SQL 検索対象は最近5年間のデータです。 */
    private static final StringBuffer SELECT_BY_DATE = new StringBuffer()
    		//.append("SELECT * FROM (SELECT")
            //.append(" (SELECT 'NUM_ADULT=' || OI.NUM_ADULT || ':NUM_CHILD=' || OI.NUM_CHILD || ':H_DATE_FIX_ID=' || OI.H_DATE_FIX_ID ")
    		.append("SELECT ")
    		.append("(SELECT 'NUM_ADULT=' || OI.NUM_ADULT || ':NUM_CHILD=' || OI.NUM_CHILD || ':H_DATE_FIX_ID=' || OI.H_DATE_FIX_ID ")
            .append(" || ':H_DATE=' || OI.H_MONTH || OI.H_DAY || ':JIKI_DATE=' || OI.JIKI_MONTH || OI.JIKI_DAY ||':ADDRESS_1=' || OI.ADDRESS_1 ")
            .append(" ||':ADDRESS_2=' || OI.ADDRESS_2 || ':NEXT_ADDRESS_1=' || OI.NEXT_ADDRESS_1 || ':NAME_KANA_1=' || UI.NAME_KANA_1 || ':NAME_KANA_2=' || UI.NAME_KANA_2")
            .append(" FROM HIKKOSHI.ORDER_INFO OI, HIKKOSHI.USER_INFO UI")
            .append(" WHERE OI.ORDER_ID = EI.ORDER_ID AND OI.USER_ID = UI.USER_ID AND OI.ORDER_NEW_ID = EI.ORDER_NEW_ID")
            .append(" UNION SELECT 'NUM_ADULT=' || OI.NUM_ADULT || ':NUM_CHILD=' || OI.NUM_CHILD || ':H_DATE_FIX_ID=' || OI.H_DATE_FIX_ID ")
            .append(" || ':H_DATE=' || OI.H_MONTH || OI.H_DAY || ':JIKI_DATE=' || OI.JIKI_MONTH || OI.JIKI_DAY ||':ADDRESS_1=' || OI.ADDRESS_1 ")
            .append(" ||':ADDRESS_2=' || OI.ADDRESS_2 || ':NEXT_ADDRESS_1=' || OI.NEXT_ADDRESS_1 || ':NAME_KANA_1=' || UI.NAME_KANA_1 || ':NAME_KANA_2=' || UI.NAME_KANA_2")
            .append(" FROM HIKKOSHI.ORDER_INFO_HISTORY OI, HIKKOSHI.USER_INFO_HISTORY UI")
            .append(" WHERE OI.ORDER_ID = EI.ORDER_ID AND OI.USER_ID = UI.USER_ID AND OI.ORDER_NEW_ID = EI.ORDER_NEW_ID) AS STEP_DATA ,")
            .append("    DECODE(EI.SEX_ID, 2, '女性', '男性') SEX_NAME,")
            .append("     (SELECT NAME")
            .append("    FROM HIKKOSHI.ENQV2_AGE_RANGE_MST ARM")
            .append("    WHERE DELETE_DATE IS NULL")
            .append("    AND ARM.AGE_RANGE_ID = EI.AGE_RANGE_ID) AS AGE_RANGE,")
            .append("    (CASE WHEN EI.CONTRACT_COMPANY_ID IS NULL OR EI.CONTRACT_COMPANY_ID >= 9997 ")
            .append("    THEN NULL ELSE (SELECT 'COMPANY_ID_MTM=' || CMM.COMPANY_ID_MTM || ':COMPANY_NAME=' || CMM.NAME || ':COMPANY_NAME_KANA=' || CMM.NAME_KANA")
            .append("        FROM HIKKOSHI.COMPANY_MTM_MST CMM, HIKKOSHI.COMPANY_MST CM")
            .append("        WHERE CMM.COMPANY_ID_MTM = CM.COMPANY_ID_MTM")
//            .append("        AND CMM.DELETE_DATE IS NULL")
            .append("        AND CM.COMPANY_ID = EI.CONTRACT_COMPANY_ID) END) AS COMPANY_NAME, (SELECT NAME")
            .append("    FROM HIKKOSHI.ENQV2_PRICE_MST WHERE PRICE_ID = EI.PRICE_ID")
            .append("    AND DELETE_DATE IS NULL) AS PRICE, EI.PYATVL, EI.PAUKFG, (SELECT NAME FROM HIKKOSHI.ENQV2_MOVE_NUM_MST")
            .append("    WHERE DELETE_DATE IS NULL AND MOVE_NUM_ID = EI.MOVE_NUM_ID) AS MOVE_NUM_NAME,")
            .append("    EI.ORDER_ID, EI.USER_ID, EI.ENQUETE_ID, EI.ORDER_NEW_ID,")
            .append("    EI.SITE_ID_ORDER, EI.SITE_ID_ENQ, TO_CHAR(EI.LAST_UPDATE, 'YYYY/MM/DD') AS LAST_UPDATE,")
            .append("    EI.CMPNY_SVC_COMMENT_GOOD, EI.CMPNY_SVC_COMMENT_BAD, EI.ADVICE,")
            .append("    ACI.ADVICE_CTG_ID, EI.USEFUL_VOTE_NUM, EI.MTM_ACCEPT_FLG, EI.MTM_SHOW_FLG")
            .append(" FROM HIKKOSHI.ENQV2_INFO EI, HIKKOSHI.ENQV2_ADVICE_CTG_INTER ACI")
            .append(" WHERE EI.LAST_UPDATE > ADD_MONTHS(SYSDATE, - 60) AND EI.ENQUETE_ID = ACI.ENQUETE_ID(+) AND ACI.ADVICE_CTG_ID(+) < 99")
            .append(" AND EI.MTM_ACCEPT_FLG = 1 AND EI.MTM_SHOW_FLG = 1")
            //.append(" ORDER BY EI.LAST_UPDATE DESC NULLS LAST, EI.ENQUETE_ID) WHERE ROWNUM <= 5");
            .append(" ORDER BY EI.LAST_UPDATE DESC NULLS LAST, EI.ENQUETE_ID");

    /** 口コミ会社一覧(参加中のみ)を取得するSQL */
    private static final StringBuffer COMPANY_MTM_MST_SELECT = new StringBuffer()
    		.append("SELECT DISTINCT CMM.COMPANY_ID_MTM, CMM.NAME, CMM.NAME_KANA FROM HIKKOSHI.COMPANY_MTM_MST CMM,")
            .append(" HIKKOSHI.COMPANY_MST CM WHERE CMM.COMPANY_ID_MTM = CM.COMPANY_ID_MTM ")
//            .append(" AND CM.DELETE_DATE IS NULL AND CMM.DELETE_DATE IS NULL AND (CM.START_DATE IS NULL OR CM.START_DATE < SYSDATE) AND (CM.END_DATE IS NULL OR CM.END_DATE > SYSDATE) ")
            .append(" ORDER BY NLSSORT(CMM.NAME_KANA,'NLS_SORT=JAPANESE_M')");

    /** アドバイスリスト一覧取得SQL */
    private static final StringBuffer ADVICE_CTG_MST_SELECT = new StringBuffer()
    		.append("SELECT ADVICE_CTG_ID, NAME FROM HIKKOSHI.ENQV2_ADVICE_CTG_MST ")
    		.append(" WHERE DELETE_DATE IS NULL AND ADVICE_CTG_ID < 99 ORDER BY SORT");

    /** 唯一のインスタンス */
    private static HikkoshiVoiceMstDb voiceDb = new HikkoshiVoiceMstDb();

    /** 新着順口コミ一覧リスト一覧 */
    private List voiceBeanListByDate = new ArrayList();

    /** アドバイスリスト一覧 */
    private List adviceList;

    /** 口コミ会社リスト一覧 */
    private List companyList;

    /**
     * 生成不能コンストラクタ
     */
    private HikkoshiVoiceMstDb() {
    }

    /**
     * 唯一のインスタンスを返す。
     * 
     * @return
     */
    public static HikkoshiVoiceMstDb getInstance() {
        return voiceDb;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
     */
    public void init() throws SQLException 
    {
        DBAccess db 	= null;
        ResultSet rs 	= null;
        try 
        {
            long lStart = System.currentTimeMillis();
            
            // db = ZubatDbUtil.getHikkoshiDb();
            db = new DBAccess();
            
            // アドバイス一覧を検索する。
            db.prepareStatement(ADVICE_CTG_MST_SELECT.toString());
            rs = db.executeQuery();
            List<Map> lstAdviceList = new ArrayList<Map>();
            Map<String, String> mapAdviceMap = null;
            while (db.next(rs)) 
            {
                mapAdviceMap = new HashMap<String, String>();
                mapAdviceMap.put("ADVICE_CTG_ID", rs.getString("ADVICE_CTG_ID"));
                mapAdviceMap.put("NAME", rs.getString("NAME"));
                lstAdviceList.add(mapAdviceMap);
            }
            this.adviceList = lstAdviceList;

            // 口コミ参加会社一覧を検索する。
            db.prepareStatement(COMPANY_MTM_MST_SELECT.toString());
            rs = db.executeQuery();
            this.companyList = getCompanyList(db, rs);

            // 新着順口コミ一覧を検索する。
            db.prepareStatement(SELECT_BY_DATE.toString());
            rs = db.executeQuery();
            this.voiceBeanListByDate = getVoiceBeanList(db, rs);

            long lDuration = System.currentTimeMillis() - lStart;

            objLog.info("VoiceMstDb#init() duration:" + lDuration + "ミリ秒");
        } 
        finally 
        {
            DBAccess.close(rs);
            DBAccess.close(db);
        }
    }

    /**
     * @param db
     * @param rs
     * @return _voiceBeanList
     * @throws SQLException
     */
    private List getVoiceBeanList(DBAccess db, ResultSet rs) throws SQLException 
    {
        List<VoiceBean> lstVoiceBean = new ArrayList<VoiceBean>();
        Map mapStep 					= null;
        Map mapCompany 					= null;
        HikkoshiVoiceBean objVoiceBean 	= null;
        String strPreEnqId 				= "";
        String strCurrEnqId 			= "";
        int nIdx 						= 0;
        while (db.next(rs)) 
        {
            if (rs.getString("CMPNY_SVC_COMMENT_GOOD") == null && rs.getString("CMPNY_SVC_COMMENT_BAD") == null
                    && rs.getString("ADVICE") == null) 
            {
                continue;
            }
            
            // アンケートIDが変わる場合
            strCurrEnqId = rs.getString("ENQUETE_ID");
            if (strPreEnqId.equals(strCurrEnqId)) 
            {
                if (rs.getString("ADVICE_CTG_ID") != null) 
                {
                    if (objVoiceBean.getAdviceIdSb().length() > 0) 
                    {
                        objVoiceBean.getAdviceIdSb().append(":").append(
                                ValueUtil.nullToStr(rs.getString("ADVICE_CTG_ID")));
                        objVoiceBean.getAdviceNameSb().append("\n").append(
                                ValueUtil.nullToStr(getAdviceName(rs.getString("ADVICE_CTG_ID"))));
                    } 
                    else 
                    {
                        objVoiceBean.getAdviceIdSb().append(ValueUtil.nullToStr(rs.getString("ADVICE_CTG_ID")));
                        objVoiceBean.getAdviceNameSb().append(
                                ValueUtil.nullToStr(getAdviceName(rs.getString("ADVICE_CTG_ID"))));
                    }
                }
                continue;
            }
            
            if (objVoiceBean != null) {
                lstVoiceBean.add(objVoiceBean); // 最初レコードの場合
            }
            
            objVoiceBean = new HikkoshiVoiceBean();
            strPreEnqId = strCurrEnqId; // 置き換える
            objVoiceBean.setIndex(nIdx++);
            mapStep = parseStepParameter(rs.getString("STEP_DATA"));
            if (mapStep != null && mapStep.size() != 0) 
            {
                objVoiceBean.setNumAdult((String) mapStep.get("NUM_ADULT"));
                objVoiceBean.setNumChild((String) mapStep.get("NUM_CHILD"));
                String strFixId = (String)mapStep.get("H_DATE_FIX_ID");
                
                // 決定または未定の場合
                if("1".equals(strFixId)){
                    objVoiceBean.setHDate((String) mapStep.get("H_DATE"));
                }
                else{
                    objVoiceBean.setHDate((String) mapStep.get("JIKI_DATE"));
                }
                
                objVoiceBean.setAddress1((String) mapStep.get("ADDRESS_1"));
                objVoiceBean.setAddress2((String) mapStep.get("ADDRESS_2"));
                objVoiceBean.setNextAddress1((String) mapStep.get("NEXT_ADDRESS_1"));
                objVoiceBean.setNameKana1((String) mapStep.get("NAME_KANA_1"));
                objVoiceBean.setNameKana2((String) mapStep.get("NAME_KANA_2"));
                
                String strName1 = (String) mapStep.get("NAME_KANA_1");
                String strName2 = (String) mapStep.get("NAME_KANA_2");
                String strNickName = "t.n";
                if (strName1.length() > 0) {
                    strNickName = Kana2Roma.kana2roma(Kana2Roma.hanKanaToZenKana(strName1)).substring(0, 1).toLowerCase();
                }
                if (strName2.length() > 0) {
                    strNickName = strNickName + "."
                            + Kana2Roma.kana2roma(Kana2Roma.hanKanaToZenKana(strName2)).substring(0, 1).toLowerCase();
                }
                objVoiceBean.setNickName(strNickName);
            }
            objVoiceBean.setSexName(rs.getString("SEX_NAME"));
            objVoiceBean.setAgeRange(rs.getString("AGE_RANGE"));

            // 引越し業者
            mapCompany = parseStepParameter(rs.getString("COMPANY_NAME"));
            objVoiceBean.setCompanyName((String) mapCompany.get("COMPANY_NAME"));
            objVoiceBean.setCompanyNameKana((String) mapCompany.get("COMPANY_NAME_KANA"));
            objVoiceBean.setCompanyIdMtm((String) mapCompany.get("COMPANY_ID_MTM"));
            objVoiceBean.setPrice(rs.getString("PRICE"));
            objVoiceBean.setPayAmount(rs.getInt("PYATVL"));
            objVoiceBean.setPayUnknown(rs.getInt("PAUKFG"));
            objVoiceBean.setMoveNumName(rs.getString("MOVE_NUM_NAME"));
            objVoiceBean.setMtmAcceptFlg(rs.getString("MTM_ACCEPT_FLG"));
            objVoiceBean.setMtmShowFlg(rs.getString("MTM_SHOW_FLG"));
            objVoiceBean.setOrderId(rs.getString("ORDER_ID"));
            objVoiceBean.setUserId(rs.getString("USER_ID"));
            objVoiceBean.setEnqueteId(rs.getString("ENQUETE_ID"));
            objVoiceBean.setOrderNewId(rs.getString("ORDER_NEW_ID"));

            objVoiceBean.setSiteIdOrder(rs.getString("SITE_ID_ORDER"));
            objVoiceBean.setSiteIdEnq(rs.getString("SITE_ID_ENQ"));
            objVoiceBean.setCmpnySvcCommentGood(rs.getString("CMPNY_SVC_COMMENT_GOOD"));
            objVoiceBean.setCmpnySvcCommentBad(rs.getString("CMPNY_SVC_COMMENT_BAD"));
            objVoiceBean.setAdvice(rs.getString("ADVICE"));
            // アドバイスリスト　「：」で区切
            objVoiceBean.getAdviceIdSb().append(ValueUtil.nullToStr(rs.getString("ADVICE_CTG_ID")));
            objVoiceBean.getAdviceNameSb().append(ValueUtil.nullToStr(getAdviceName(rs.getString("ADVICE_CTG_ID"))));
            objVoiceBean.setUsefulVoteNum(rs.getInt("USEFUL_VOTE_NUM"));
            objVoiceBean.setLastUpadte(rs.getString("LAST_UPDATE"));
        }

        if (objVoiceBean != null) {
            lstVoiceBean.add(objVoiceBean); // 最後レコードの場合
        }

        return lstVoiceBean;
    }

    /**
     * @param dbAccess
     * @param rs
     * @return _voiceBeanList
     * @throws SQLException
     */
    private List getCompanyList(DBAccess dbAccess, ResultSet rs) throws SQLException 
    {
        List<Map> lstCompany = new ArrayList<Map>();
        Map<String, String> mapCompany = null;
        while (dbAccess.next(rs)) 
        {
            String strKana = Kana2Roma.getKana(rs.getString("NAME_KANA"));
            if (strKana.length() == 0) {
                continue;
            }
            mapCompany = new HashMap<String, String>();
            // アンケートIDが変わる場合
            mapCompany.put("NAME_KANA", strKana);
            mapCompany.put("COMPANY_ID_MTM", rs.getString("COMPANY_ID_MTM"));
            mapCompany.put("NAME", rs.getString("NAME"));
            
            lstCompany.add(mapCompany); // 最後レコードの場合
        }
        
        return lstCompany;
    }

    /**
     * 新着順口コミ一覧リストを返す
     * 
     * @return voiceBeanListByDate
     */
    public List getVoiceBeanListByDate() {
        return voiceBeanListByDate;
    }

    /**
     * アドバイス一覧リストを返す
     * 
     * @return adviceList
     */
    public List getAdviceList() {
        return adviceList;
    }

    /**
     * アドバイス名を返す
     * 
     * @return adviceList
     */
    private String getAdviceName(String strAdviceId) 
    {
        if (strAdviceId == null || strAdviceId.length() == 0) {
            return "";
        }
        
        List lstAdviceList = this.getAdviceList();
        for (int nCnt=0; nCnt<lstAdviceList.size(); nCnt++) 
        {
            if (strAdviceId.equals(((Map) lstAdviceList.get(nCnt)).get("ADVICE_CTG_ID"))) {
                return "・" + ((Map) lstAdviceList.get(nCnt)).get("NAME");
            }
        }
        
        return "";
    }

    public List getCompanyList() {
        return companyList;
    }

    /**
     * Parses the struts parameter into a map of name/value pairs, so that we can put many params in
     * the one string. Delimiter is comma, and the sub-delimiter is =. So param example is:
     * name1=value1,name2=value2 etc
     */
    private Map<String, String> parseStepParameter(String strParameter) 
    {
        if (strParameter == null) {
            return new HashMap<String, String>();
        } 
        else 
        {
            StringTokenizer objStringTokenizer = new StringTokenizer(strParameter, ":", false);
            Map<String, String> mapResults = new HashMap<String, String>();
            for (int nCnt=0; objStringTokenizer.hasMoreTokens(); nCnt++) 
            {
                String strPair = objStringTokenizer.nextToken();
                int nEqualPos = strPair.indexOf('=');
                String strName = (nEqualPos == -1 ? strPair.trim() : strPair.substring(0, nEqualPos).trim());
                String strValue = (nEqualPos == -1 ? "" : strPair.substring(nEqualPos + 1).trim());
                mapResults.put(strName, strValue);
            }
            
            return mapResults;
        }
    }
}
