package jp.co.webcrew.filters.util;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.NoSuchElementException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;

/**
 * queueを制御するためのutilクラス。
 * 
 * @author kurinami
 */
abstract public class QueueThreadUtil implements Runnable {

	/** ロガー */
	private static final Logger log = Logger.getLogger(QueueThreadUtil.class);

	/** スレッド待機時間 */
	private static final int WAIT_TIME = 60000;

	/** 処理するためのキュー */
	private LinkedList queue = new LinkedList();

	/**
	 * スレッドを開始する。
	 */
	public void start() {
		log.debug("start daemon thread [" + this.getClass().getName() + "]");
		Thread thread = new Thread(this);
		thread.setDaemon(true);
		thread.start();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		while (true) {
			try {
				HttpServletRequestCache request = poll();
				if (request != null) {
					execute(request);
				} else {
					synchronized (this) {
						this.wait(WAIT_TIME);
					}
				}
			} catch (Exception e) {
				log.error("予期せぬエラー", e);
			}
		}

	}

	/**
	 * キューから処理対象を取得する。
	 * 
	 * @return
	 */
	public HttpServletRequestCache poll() {
		HttpServletRequestCache request = null;

		synchronized (queue) {
			try {
				request = (HttpServletRequestCache) queue.removeFirst();
			} catch (NoSuchElementException e) {
			}
		}

		return request;
	}

	/**
	 * キューに処理対象を登録する。
	 * 
	 * @param object
	 */
	public void push(HttpServletRequest request, HttpServletResponse response) {

		synchronized (queue) {
			queue.addLast(new HttpServletRequestCache(request, response));
		}
		synchronized (this) {
			this.notify();
		}
	}

	/**
	 * 処理対象に対して処理を行う。
	 * 
	 * @param request
	 * @throws SQLException
	 */
	abstract protected void execute(HttpServletRequestCache request)
			throws Exception;
}
