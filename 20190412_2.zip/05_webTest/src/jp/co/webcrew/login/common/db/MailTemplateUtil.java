package jp.co.webcrew.login.common.db;

import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.internet.MimeUtility;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.DBConnectionFactory;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.MailBody;
import jp.co.webcrew.login.common.MailInfo;
import jp.co.webcrew.login.common.MailSubject;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.Mail;

/**
 * 【メール送信処理共通化用】
 * メールテンプレートを扱うクラス
 *
 * @author Takahashi
 *
 */
public class MailTemplateUtil extends DBEntity
{
	/** ロガー */
	private static final Logger log = Logger.getLogger(MailTemplate.class);

	/** スキーマ */
	public static final String SCHEMA = DBConnectionFactory.getSchemaFromPropeties();

	/** テーブル名 */
	public static final String TABLE  = "MAIL_TEMPL";

	/** デフォルトの仮登録完了通知 */
	public static final String ID_STEP_TEMP_REGIST      = "STEP_TEMP_REGIST";

	/** デフォルトの本登録完了通知 */
	public static final String ID_STEP_REAL_REGIST      = "STEP_REAL_REGIST";

	/** デフォルトのユーザ更新通知 */
	public static final String ID_STEP_REAL_UPDATE      = "STEP_REAL_UPDATE";

	/** デフォルトのリマインダ通知(仮登録者用)  */
	public static final String ID_STEP_TEMP_REMINDER    = "STEP_TEMP_REMINDER";

	/** デフォルトのリマインダ通知(本登録者用)  */
	public static final String ID_STEP_REAL_REMINDER    = "STEP_REAL_REMINDER";

	/** TNS_LOGINの仮登録完了通知 */
	public static final String ID_TNS_TEMP_REGIST       = "TNS_TEMP_REGIST";

	/** TNS_LOGINの本登録完了通知 */
	public static final String ID_TNS_REAL_REGIST       = "TNS_REAL_REGIST";

	/** TNS_LOGINのリマインダ通知(仮登録者用)  */
	public static final String ID_TNS_TEMP_REMINDER     = "TNS_TEMP_REMINDER";

	/** TNS_LOGINのリマインダ通知(本登録者用)  */
	public static final String ID_TNS_REAL_REMINDER     = "TNS_REAL_REMINDER";

	/** MYPAGEのリマインダ通知(仮登録者用)  */
	public static final String ID_MYPAGE_TEMP_REMINDER  = "MYPAGE_TEMP_REMINDER";

	/** MYPAGEのリマインダ通知(本登録者用)  */
	public static final String ID_MYPAGE_REAL_REMINDER  = "MYPAGE_REAL_REMINDER";

	/** MYPAGEの退会処理  */
	public static final String ID_MYPAGE_RESIGN         = "MYPAGE_RESIGN";

	/** TNS_LOGINの仮登録完了通知 */
	public static final String ID_DANDORI_TEMP_REGIST       	= "DANDORI_TEMP_REGIST";

	/** TNS_LOGINの本登録完了通知 */
	public static final String ID_DANDORI_REAL_REGIST       	= "DANDORI_REAL_REGIST";

	/** TNS_LOGINのリマインダ通知(仮登録者用)  */
	public static final String ID_DANDORI_TEMP_REMINDER     	= "DANDORI_TEMP_REMIND";

	/** TNS_LOGINのリマインダ通知(本登録者用)  */
	public static final String ID_DANDORI_REAL_REMINDER     	= "DANDORI_REAL_REMIND";

	/** メールテンプレートID */
	public static final String SSTAG_REGIST_MAIL_TEMPLATE_ID 	= "STEP_SSTAG_REGIST";

	/** メールテンプレートID(モバイル用) */
	public static final String SSTAG_MB_REGIST_MAIL_TEMPLATE_ID = "STEP_SSTAG_MB_REGIST";

	/** WC会員がSTEPを完了させた時に送信する変更のお知らせメール */
	public static final String SSTAG_UPDATE_MAIL_TEMPLATE_ID 	= "STEP_SSTAG_UPDATE";
	
	/** ピザハットクーポン申込み用　*/
	public static final String PIZZA_HUT_HIKKOSHI_TEMPLATE_ID 	= "PIZZA_HUT_CAMPAIGN";
	
	public static final String PIZZA_HUT_ZUBAT_TEMPLATE_ID 		= "PIZZA_HUT_ZUBAT";
	
	/** メルマガパーミッション用　*/
	public static final String MAIL_MAGA_REGIST_TEMPLATE_ID 	= "MAIL_MAGA_REGIST";
	public static final String MAIL_MAGA_SITEWISE_TEMPLATE_ID 	= "MAIL_SITEWISE_REGIST";

	/*
	 * 列名定義 （定数定義）
	 */
	public static final String TEMPL_ID         = "TEMPL_ID";
	public static final String PURPOSE          = "PURPOSE";
	public static final String MAIL_FROM        = "MAIL_FROM";
	public static final String MAIL_TO          = "MAIL_TO";
	public static final String MAIL_CC          = "MAIL_CC";
	public static final String MAIL_BCC         = "MAIL_BCC";
	public static final String SUBJECT          = "SUBJECT";
	public static final String BODY             = "BODY";
	public static final String MEMO             = "MEMO";
	public static final String UP_DATETIME      = "UP_DATETIME";
	public static final String UP_ADMIN         = "UP_ADMIN";
	public static final String SUBJECT_MOBILE   = "SUBJECT_MOBILE";
	public static final String BODY_MOBILE      = "BODY_MOBILE";
	public static final String MAIL_FROM_LABEL  = "MAIL_FROM_LABEL";

	private SystemProperties objSysProp;
	private MemberMst objMemberMst;
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
	 */
	public void init()
	{
		setSchema(SCHEMA);
		setTable(TABLE);
	}

	/**
	 * 非公開コンストラクタ
	 */
	private MailTemplateUtil(){}

	/**
		* コンストラクタ
		*
		* @param strTemplateId メールテンプレートID
		*/
	public MailTemplateUtil(String strTemplateId)
	{
		set(TEMPL_ID , strTemplateId);
		this.objSysProp = getSystemProperty();
	}

	/**
		* コンストラクタ
		*
		* @param strTemplateId メールテンプレートID
		* @param strGuid guid
		*/
	public MailTemplateUtil(String strTemplateId, String strGuid)
	{
		set(TEMPL_ID , strTemplateId);
		this.objSysProp = getSystemProperty();
		this.objMemberMst = getMemberMstData(strGuid);
	}
	
	/**
	 * 差出人名を取得する
	 * 
	 * @return
	 */
	public String getMailFromLabel()
	{
		return get(MAIL_FROM_LABEL);
	}
	
	/**
	 * メールテンプレートのsubjectを取得する
	 *
	 * @return
	 */
	public String getSubject()
	{
		return get(SUBJECT);
	}

	/**
	 * メールテンプレートの本文を取得する
	 *
	 * @return
	 */
	public String getBody()
	{
		return get(BODY);
	}

	/**
	 * メールテンプレートの件名を取得する
	 * 携帯メールアドレスの場合は、携帯用の件名(登録されていない場合は、PC用の件名)
	 * その他メールアドレスの場合は、PC用の件名
	 * を返す
	 *
	 * @return
	 */
	public String getSubject(boolean blnMobileFlg)
	{
		if (blnMobileFlg)
		{
			String strSubject = ValueUtil.nullToStr(get(SUBJECT_MOBILE));
			
			if (strSubject.equals(""))
			{
				return get(SUBJECT);
			}
			else
			{
				return get(SUBJECT_MOBILE);
			}
		}
		else
		{
			return get(SUBJECT);
		}
	}

	/**
	 * メールテンプレートの本文を取得する
	 * 携帯メールアドレスの場合は、携帯用の本文(登録されていない場合は、PC用の本文)
	 * その他メールアドレスの場合は、PC用の本文
	 * を返す
	 * 
	 * @return
	 */
	public String getBody(boolean blnMobileFlg)
	{
		if (blnMobileFlg)
		{
			String strBody = ValueUtil.nullToStr(get(BODY_MOBILE));
			
			if (strBody.equals(""))
			{
				return get(BODY);
			}
			else
			{
				return get(BODY_MOBILE);
			}
		}
		else
		{
			return get(BODY);
		}
	}
	
	/**
	 * メールテンプレートのfromを取得する
	 *
	 * @return String
	 */
	public String getFrom()
	{
		return get(MAIL_FROM);
	}

	/**
	 * メールテンプレートの差出人(mail_from_label)を取得する
	 * 
	 * @return
	 */
	public String getFromLabel()
	{
		return get(MAIL_FROM_LABEL);
	}
	
	/**
	 * <pre>
	 * メールテンプレートに埋め込まれたシステムプロパティの置換変数を、
	 * システムプロパティ値に変換する。
	 *
	 * 置換変数は、$$SYSPROP_システムプロパティのキー名$$とする。
	 *
	 * 例）
	 *
	 * キーがXXX, 値がAAA のシステムプロパティが設定されているとき
	 *
	 * 置換前
	 *   $$SYSPROP_XXX$$
	 *
	 * 置換後
	 *   AAA
	 *
	 * </pre>
	 * @param strBody メールテンプレート本文
	 * @return
	 */
	public String replaceSysProp (String strBody)
	{
		if (strBody == null || "".equals(strBody))
				return null;
		
		try
		{
			// システムプロパティを取得
			// SystemProperties props = getSystemProperty();

			// 全ての$$Sysprop.xxx$$ に対して、$$SYSPROP_xxx$$ をシステムプロパティ(xxx)の値で置換する
			Pattern objPattern = Pattern.compile("\\$\\$SYSPROP_(.+?)\\$\\$");
			Matcher objMatcher = objPattern.matcher(strBody);
			StringBuffer sbufBody = new StringBuffer();
			while (objMatcher.find())
			{
				//　(.+?)の中身 を取得
					String strKey = objMatcher.group(1);
					//　システムプロパティの値を取得
					String strVal = ValueUtil.nullToStr(objSysProp.get(strKey));
					if (strVal.equals(""))
					{
							log.error("システムプロパティキー 「 " + strKey + "」が見つかりませんでした。");
							// return null; //TODO 要確認。メール送信を中止する場合はnullを返す。
							strVal = "!";
					}
					objMatcher.appendReplacement(sbufBody, strVal);
			}
			objMatcher.appendTail(sbufBody);

			return sbufBody.toString();
		}
		catch (Exception objExp)
		{
			return null;
		}
	}

	/**
	 * <pre>
	 * メールテンプレートに埋め込まれたサイトコンテンスの置換変数を、
	 * サイトコンテンス値に変換する。
	 *
	 * 置換変数は、$$SITECONT_サイトコンテンスのキー名$$とする。
	 *
	 * 例）
	 *
	 * キーがXXX, 値がAAA のサイトコンテンスが設定されているとき
	 *
	 * 置換前
	 *   $$SITECONT_XXX$$
	 *
	 * 置換後
	 *   AAA
	 *
	 * </pre>
	 * @param strBody メールテンプレート本文
	 * @return
	 */
	public String replaceSiteCont (String strBody, String strSiteId)
	{
		if (strBody == null || "".equals(strBody))
			return null;

		DBAccess db = null;
		try
		{
			db = new DBAccess();

			// サイト固有文言を取得
			MailPerSiteContents objPerSiteContents = new MailPerSiteContents(strSiteId);
			if (! objPerSiteContents.load(db))
			{
				// throw new Exception("サイト固有文言　サイトＩＤ：" + strSiteId + "の読み込みに失敗しました。");
			    // strSiteIdがnullの場合TONASHIBA.MAIL_PER_SITE_CONTENTSへの登録が必要ないため。エラーメールも必要ないです。
			    if(ValueUtil.nullToStr(strSiteId).length() != 0){
			        log.error("サイト固有文言TONASHIBA.MAIL_PER_SITE_CONTENTSテーブルに　サイトＩＤ「" + strSiteId + "」のデータは登録されていません。\n");
			    }
			}

			// 全ての$$SiteCont.xxx$$ に対して、$$SITECONT_xxx$$ をサイトコンテンス(xxx)の値で置換する
			//Pattern objPattern = Pattern.compile("\\$\\$SITECONT_(.+?)\\$\\$");
			Pattern objPattern = Pattern.compile("\\$\\$site_var_contents_(.+?)\\$\\$");
			Matcher objMatcher = objPattern.matcher(strBody);
			StringBuffer sbufBody = new StringBuffer();
			while (objMatcher.find())
			{
				//　(.+?)の中身 を取得
				//String strKey = objMatcher.group(1);
				String strKey = "var_contents_" + objMatcher.group(1);
				strKey = strKey.toUpperCase();
				//　サイトコンテンスの値を取得
				//String strVal = ValueUtil.nullToStr(objPerSiteContents.get(strKey));
				//if (strVal.equals(""))
				//{
				//	log.error("サイトコンテンスのキー 「" + strKey + "」が見つかりませんでした。");
					// return null; //TODO 要確認。メール送信を中止する場合はnullを返す。
					//strVal = "!";
				//}
				String strVal = ValueUtil.nullToStr(objPerSiteContents.get(strKey));
				
				objMatcher.appendReplacement(sbufBody, strVal);
			}
			objMatcher.appendTail(sbufBody);

			strBody = sbufBody.toString();
			
			//$$site_name$$を変換
			objPattern = Pattern.compile("\\$\\$site_name\\$\\$");
			objMatcher = objPattern.matcher(strBody.toString());
			if (objMatcher.find())
			{
				strBody = strBody.replaceAll("\\$\\$site_name\\$\\$", ValueUtil.nullToStr(objPerSiteContents.get("SITE_NAME")));
			}
			
			return strBody;
		}
		catch (Exception objExp)
		{
			return null;
		}
		finally
		{
				DBAccess.close(db);
		}
	}

	/**
	 * <pre>
	 * メールテンプレートに埋め込まれたメンバーマスターの置換変数を、
	 * メンバーマスター値に変換する。
	 *
	 * 置換変数は、$$MEMMST_メンバーマスターのキー名$$とする。
	 *
	 * 例）
	 *
	 * キーがXXX, 値がAAA のメンバーマスターが設定されているとき
	 *
	 * 置換前
	 *   $$SITECONT_XXX$$
	 *
	 * 置換後
	 *   AAA
	 *
	 * </pre>
	 * @param strBody メールテンプレート本文
	 * @return
	 */
	public String replaceMemberMst (String strBody)
	{
		if (strBody == null || "".equals(strBody))
			return null;

		try
		{
			// 全ての$$MemMst.xxx$$ に対して、$$MEMMST_xxx$$ をメンバーマスター(xxx)の値で置換する
			Pattern objPattern = Pattern.compile("\\$\\$MEMMST_(.+?)\\$\\$");
			Matcher objMatcher = objPattern.matcher(strBody);
			StringBuffer sbufBody = new StringBuffer();
			while (objMatcher.find())
			{
				//　(.+?)の中身 を取得
				String strKey = objMatcher.group(1);
				//　メンバーマスターの値を取得
				String strVal = ValueUtil.nullToStr(objMemberMst.get(strKey));
				if (strVal.equals(""))
				{
					log.error("メンバーマスターのキー 「" + strKey + "」が見つかりませんでした。");
					// return null; //TODO 要確認。メール送信を中止する場合はnullを返す。
					strVal = "!";
				}
				objMatcher.appendReplacement(sbufBody, strVal);
			}
			objMatcher.appendTail(sbufBody);

			return sbufBody.toString();
		}
		catch (Exception objExp)
		{
			return null;
		}
	}

	/**
	 * <pre>
	 * Getting the System properties
	 *
	 * </pre>
	 * @return SystemProperties
	 */
	public SystemProperties getSystemProperty()
	{
		DBAccess db = null;
		try
		{
			db = new DBAccess();

			// システムプロパティを取得
			return new SystemProperties(db);

		}
		catch (Exception objExp)
		{
			return null;
		}
		finally
		{
			DBAccess.close(db);
		}
	}

	/**
	 * <pre>
	 * Getting the Member Master data
	 *
	 * </pre>
	 * @return MemberMst
	 */
	public MemberMst getMemberMstData(String strGuid)
	{
		DBAccess db = null;
		try
		{
			db = new DBAccess();

			// MemberMstデータを取得
			MemberMst objMemMst = new MemberMst(strGuid);
			if (!objMemMst.load(db))
			{
				log.info("仮登録情報を取得できませんでした。guid=" + strGuid);
				return null;
			}

			return objMemMst;

		}
		catch (Exception objExp)
		{
			return null;
		}
		finally
		{
			DBAccess.close(db);
		}
	}

	/**
	 * 変数を置き換えてメールを送信する
	 * CC、BCCを指定してメールを送信したい場合に利用する
	 * 
	 * @param objMailSubject
	 * @param objMailBody
	 * @param objMailInfo
	 * @param strCc
	 * @param strBcc
	 * @return
	 */
	public boolean doReplaceAndMail(
			MailSubject objMailSubject,
			MailBody objMailBody,
			MailInfo objMailInfo,
			String strCc,
			String strBcc)
	{
		HashMap hmapSubjectParam = (HashMap)objMailSubject.getSubjectParam();
		HashMap hmapBodyParam    = (HashMap)objMailBody.getBodyParam();
		String strSiteId         = objMailInfo.getSiteId();
		String strMailTo         = objMailInfo.getMailTo();
		String strMailFrom       = objMailInfo.getMailFrom();
		boolean blnMobileFlag    = objMailInfo.getMobileFlag();
		
		return doReplaceAndMail(hmapSubjectParam, hmapBodyParam, strMailTo, strMailFrom, strSiteId, blnMobileFlag, strCc, strBcc);
	}
	
	/**
	 * 変数を置き換えてメールを送信する
	 * 
	 * @param objMailSubject
	 * @param objMailBody
	 * @param strFrom
	 * @param blnMobileFlg
	 * @return
	 */
	public boolean doReplaceAndMail(
			MailSubject objMailSubject,
			MailBody objMailBody,
			MailInfo objMailInfo)
	{
		HashMap hmapSubjectParam = (HashMap)objMailSubject.getSubjectParam();
		HashMap hmapBodyParam    = (HashMap)objMailBody.getBodyParam();
		String strSiteId         = objMailInfo.getSiteId();
		String strMailTo         = objMailInfo.getMailTo();
		String strMailFrom       = objMailInfo.getMailFrom();
		boolean blnMobileFlag    = objMailInfo.getMobileFlag();
		
		return doReplaceAndMail(hmapSubjectParam, hmapBodyParam, strMailTo, strMailFrom, strSiteId, blnMobileFlag);
	}
	
	/**
	 * <pre>
	 * Call this method from outside for sending mail
	 *
	 * </pre>
	 * @param hmapSubjectParam - HashMap of variables to be replaced in Subject
	 * @param hmapBodyParam - HashMap of variables to be replaced in Body
	 * @param strMailTo - 「To」 E-mail address
	 * @param strFrom - 「From」 E-mail address
	 * @param strFromLabel - 送信者名
	 * @param strSiteId - Site ID
	 * @return bollean
	 */
	public boolean doReplaceAndMail(
			HashMap hmapSubjectParam,
			HashMap hmapBodyParam,
			String strMailTo,
			String strFrom,
			String strSiteId,
			boolean blnMobileFlg)
	{
		return doReplaceAndMail(hmapSubjectParam, hmapBodyParam, strMailTo, strFrom, strSiteId, blnMobileFlg, null, null);
	}

	/**
	 * 変数の置き換えとメール送信処理を行う
	 * 
	 * @param hmapSubjectParam
	 * @param hmapBodyParam
	 * @param strMailTo
	 * @param strFrom
	 * @param strSiteId
	 * @param blnMobileFlg
	 * @param strCc
	 * @param strBcc
	 * @return
	 */
	public boolean doReplaceAndMail(
			HashMap hmapSubjectParam,
			HashMap hmapBodyParam,
			String strMailTo,
			String strFrom,
			String strSiteId,
			boolean blnMobileFlg,
			String strCc,
			String strBcc)
	{
		try
		{
			if (strFrom == null)
			{
				strFrom = ValueUtil.nullToStr(this.getFrom());
			}
			
			String strSmtpHost = ValueUtil.nullToStr(objSysProp.getSmtpHost());
			String strSmtpPort = ValueUtil.nullToStr(objSysProp.get(SystemProperties.MAIL_SMTP_PORT));
			String strSubject  = ValueUtil.nullToStr(this.getSubject(blnMobileFlg));
			String strBody     = ValueUtil.nullToStr(this.getBody(blnMobileFlg));

			//件名の変数を置き換える
			Iterator objIterator = hmapSubjectParam.keySet().iterator();
			while (objIterator.hasNext())
			{
				String strKey = ValueUtil.nullToStr(objIterator.next());
				strSubject = strSubject.replaceAll(strKey, ValueUtil.nullToStr(hmapSubjectParam.get(strKey)));
			}

			//本文の変数を置き換える
			objIterator = hmapBodyParam.keySet().iterator();
			while (objIterator.hasNext())
			{
				String strKey = ValueUtil.nullToStr(objIterator.next());
				strBody = strBody.replaceAll(strKey, ValueUtil.nullToStr(hmapBodyParam.get(strKey)));
			}

			//システムプロパティ変数を置き換える
			strBody = replaceSysProp(strBody);
			if (strBody == null || strBody.equals(""))
			{
				log.error("メール本文の取得に失敗しました。データベースに登録されていないか、必要なシステムプロパティの取得に失敗した可能性があります。メール送信を中断します。");
				return false;
			}

			//サイト固有変数を置き換える
			if (strSiteId != null)
			{
				//本文のサイト固有変数を置き換える
				strBody = replaceSiteCont(strBody, strSiteId);
				if (strBody == null || strBody.equals("")) {
					log.error("メール本文の取得に失敗しました。データベースに登録されていないか、必要なコンテンツの取得に失敗した可能性があります。メール送信を中断します。");
					return false;
				}
				
				//件名のサイト固有変数を置き換える
				strSubject = replaceSiteCont(strSubject, strSiteId);
				if (strSubject == null || strSubject.equals("")) {
					log.error("メールタイトルの取得に失敗しました。データベースに登録されていないか、必要なコンテンツの取得に失敗した可能性があります。メール送信を中断します。");
					return false;
				}
			}

			//本文の日付変数を置き換える
			strBody = replaceDateTime(strBody);
			
			//－と～の文字化けに対応
			strBody = strBody.replace((char) 0xFF0D, (char) 0x2212);
			strBody = strBody.replace((char) 0xFF5E, (char) 0x301C);
			
			//送信者名を取得
			String strFromLabel = ValueUtil.nullToStr(getFromLabel());
			if(!strFromLabel.trim().equals(""))
			{
				strFromLabel = MimeUtility.encodeText(strFromLabel, "iso-2022-jp", "b");
			}
			
			//メール送信
			Mail.sendMailWithCharCheck(strSmtpHost, strSmtpPort, strMailTo, strCc, strBcc, strFrom, strFromLabel, strSubject, strBody);

			log.info("本登録完了通知メールを送信しました。");
			return true;

		} catch (Exception objExp) {
			log.error("メール送信中に例外エラーが発生しました。" , objExp);
			return false;
		}
	}
	
	/**
	 * <pre>
	 * Call this method from outside for sending mail
	 *
	 * </pre>
	 * @param hmapSubjectParam - HashMap of variables to be replaced in Subject
	 * @param hmapBodyParam - HashMap of variables to be replaced in Body
	 * @param strMailTo - 「To」 E-mail address
	 * @param strFrom - 「From」 E-mail address
	 * @param strSiteId - Site ID
	 * @return bollean
	 */
	public boolean doReplaceAndMail(
			HashMap hmapSubjectParam,
			HashMap hmapBodyParam,
			String strMailTo,
			String strFrom,
			boolean blnMobileFlg)
	{
		return doReplaceAndMail(hmapSubjectParam, hmapBodyParam, strMailTo, strFrom, "", blnMobileFlg);
	}

	/**
	 * <pre>
	 * Call this method from outside for sending mail
	 *
	 * </pre>
	 * @param hmapSubjectParam - HashMap of variables to be replaced in Subject
	 * @param hmapBodyParam - HashMap of variables to be replaced in Body
	 * @param strMailTo - 「To」 E-mail address
	 * @param strFrom - 「From」 E-mail address
	 * @param strSiteId - Site ID
	 * @return bollean
	 */
	public boolean doReplaceAndMail(
			HashMap hmapSubjectParam,
			HashMap hmapBodyParam,
			String strMailTo,
			boolean blnMobileFlg)
	{
		return doReplaceAndMail(hmapSubjectParam, hmapBodyParam, strMailTo, null, "", blnMobileFlg);
	}

	/**
	 * <pre>
	 * メールテンプレートの日時変数を現在時刻で置換する
	 *
	 * 現在時刻がyyyymmddhhmissの14桁として、次のように置換。
	 *
	 * $$year$$   → 年 yyyy
	 * $$month$$  → 月 mm
	 * $$day$$    → 日 dd
	 * $$hour$$   → 時 hh
	 * $$minute$$ → 分 mi
	 * $$second$$ → 秒 ss
	 *
	 * 本文bodyがnullの時はnull
	 * 空文字の時は空文字で返す
	 *
	 * </pre>
	 *
	 * @param strBody メール本文
	 */
	public static String replaceDateTime (String strBody)
	{
		if (strBody == null || "".equals(strBody))
			return null;

		String strDate   = DateUtil.currentDateTime();
		String strYYYY = strDate.substring( 0 ,  4);
		String strMM   = strDate.substring( 4 ,  6);
		String strDD   = strDate.substring( 6 ,  8);
		String strHH   = strDate.substring( 8 , 10);
		String strMI   = strDate.substring(10 , 12);
		String strSS   = strDate.substring(12 , 14);

		strBody = strBody.replaceAll("\\$\\$year\\$\\$"       , strYYYY);
		strBody = strBody.replaceAll("\\$\\$month\\$\\$"      , strMM);
		strBody = strBody.replaceAll("\\$\\$day\\$\\$"        , strDD);
		strBody = strBody.replaceAll("\\$\\$hour\\$\\$"       , strHH);
		strBody = strBody.replaceAll("\\$\\$minute\\$\\$"     , strMI);
		strBody = strBody.replaceAll("\\$\\$second\\$\\$"     , strSS);

		return strBody;
	}

	private static final String SELECT_MOBILE_ADDRESS_MST = "SELECT count(1) as cnt FROM tonashiba.mobile_address_mst WHERE ? LIKE domain";
	
	/**
	 * 送信先メールアドレス(strMailto)が携帯のメールアドレスかどうか判定する
	 * 携帯メールアドレスの場合はtrue、それ以外のメールアドレスの場合はfalseを返す
	 * 
	 * @param db
	 * @param strMailTo
	 * @return
	 */
	public static boolean isMobileEmail(DBAccess db, String strMailTo) throws Exception
	{
		if (strMailTo == null)
		{
			throw new Exception("携帯メールアドレス判定で例外が発生しました。送信先メールアドレスがNULLです。");
		}
		
		int nIndex = strMailTo.indexOf("@");
		if (nIndex == -1)
		{
			throw new Exception("携帯メールアドレス判定で例外が発生しました。送信先メールアドレスが間違っています。送信先=" + strMailTo);
		}
		
		String strDomain = strMailTo.substring(nIndex + 1);
		
		db.prepareStatement(SELECT_MOBILE_ADDRESS_MST);
		db.setString(1, strDomain);

		Record rec = Record.getFirstRowOf(db);

		if (rec != null) {
			if(rec.getInt("cnt") == 0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else
		{
			throw new Exception("携帯メールアドレス判定で例外が発生しました。MOBILE_ADDRESS_MSTから結果を取得出来ませんでした。");
		}
	}
}
