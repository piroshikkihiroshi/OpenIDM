package jp.co.webcrew.common.util.proc;


/**
 * Replacement for Comparator in collections classes.
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: Comparator.java,v 1.1 2004-09-15 08:37:11 rickk Exp $
 */
public interface Comparator {
    public int compare(Object one, Object two);
}
