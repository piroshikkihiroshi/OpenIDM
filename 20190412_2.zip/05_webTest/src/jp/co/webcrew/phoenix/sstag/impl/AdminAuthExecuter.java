package jp.co.webcrew.phoenix.sstag.impl;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.bean.AdminAuthBean;
import jp.co.webcrew.phoenix.sstag.util.AdAuth;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;
import jp.co.webcrew.phoenix.vtable.bean.ConditionBean;
import jp.co.webcrew.phoenix.vtable.db.VDb;

/**
 * 管理用認証を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class AdminAuthExecuter extends SSTagExecuter {

    /** パラメータ名：ログイン認証ID */
    private static final String AUTH_ID_PARAM_KEY = "auth_id";

    /** パラメータ名：ログインタイムアウトまでの秒数 */
    private static final String TIMEOUT_PARAM_KEY = "timeout";

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：対象テーブル */
    private static final String TABLE_ID_PARAM_KEY = "table_id";

    /** パラメータ名：ID項目1 */
    private static final String ID_ITEM1_PARAM_KEY = "id_item1";

    /** パラメータ名：ID項目2 */
    private static final String ID_ITEM2_PARAM_KEY = "id_item2";

    /** パラメータ名：ID項目3 */
    private static final String ID_ITEM3_PARAM_KEY = "id_item3";

    /** パラメータ名：ID項目1と比較する値 */
    private static final String ID_VALUE1_PARAM_KEY = "id_value1";

    /** パラメータ名：ID項目2と比較する値 */
    private static final String ID_VALUE2_PARAM_KEY = "id_value2";

    /** パラメータ名：ID項目3と比較する値 */
    private static final String ID_VALUE3_PARAM_KEY = "id_value3";

    /** パラメータ名：AD認証サーバパス */
    private static final String AD_SERVER_PARAM_KEY = "ad_server";

    /** パラメータ名：AD認証ユーザ名 */
    private static final String AD_USER_PARAM_KEY = "ad_user";

    /** パラメータ名：AD認証パスワード */
    private static final String AD_PW_PARAM_KEY = "ad_pw";

    /** パラメータ名：AD認証ドメイン名 */
    private static final String AD_DOMAIN_PARAM_KEY = "ad_domain";

    /** パラメータ名：認証OKの場合のリダイレクト先URL */
    private static final String AUTH_OK_PARAM_KEY = "auth_ok";

    /** パラメータ名： 認証できなかった場合のリダイレクト先URL */
    private static final String AUTH_NG_PARAM_KEY = "auth_ng";

    /** パラメータ名： 認証できなかった場合の保存メッセージ */
    private static final String NG_MSG_PARAM_KEY = "ng_msg";

    /** system_property値：ADサーバ名 */
    private static final String AD_SERVER_URL_PROP_KEY = "AD_SERVER_URL";

    /** system_property値：ADドメイン名 */
    private static final String AD_DOMAIN_NAME_PROP_KEY = "AD_DOMAIN_NAME";

    /** デフォルトのタイムアウト値(秒) */
    private static final int DEFAULT_TIMEOUT = 1800;

    /** ロガー */
    private static final Logger log = Logger.getLogger(AdminAuthExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { AUTH_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String authId = ValueUtil.nullToStr(parameters.get(AUTH_ID_PARAM_KEY));
            int timeout = ValueUtil.toint((String) parameters.get(TIMEOUT_PARAM_KEY));
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String tableId = ValueUtil.nullToStr(parameters.get(TABLE_ID_PARAM_KEY));
            String idItem1 = ValueUtil.nullToStr(parameters.get(ID_ITEM1_PARAM_KEY));
            String idItem2 = ValueUtil.nullToStr(parameters.get(ID_ITEM2_PARAM_KEY));
            String idItem3 = ValueUtil.nullToStr(parameters.get(ID_ITEM3_PARAM_KEY));
            String idValue1 = ValueUtil.nullToStr(parameters.get(ID_VALUE1_PARAM_KEY));
            String idValue2 = ValueUtil.nullToStr(parameters.get(ID_VALUE2_PARAM_KEY));
            String idValue3 = ValueUtil.nullToStr(parameters.get(ID_VALUE3_PARAM_KEY));
            String adServer = ValueUtil.nullToStr(parameters.get(AD_SERVER_PARAM_KEY));
            String adUser = ValueUtil.nullToStr(parameters.get(AD_USER_PARAM_KEY));
            String adPw = ValueUtil.nullToStr(parameters.get(AD_PW_PARAM_KEY));
            String adDomain = ValueUtil.nullToStr(parameters.get(AD_DOMAIN_PARAM_KEY));
            String authOk = ValueUtil.nullToStr(parameters.get(AUTH_OK_PARAM_KEY));
            String authNg = ValueUtil.nullToStr(parameters.get(AUTH_NG_PARAM_KEY));
            // TODO kurinami 【確認】 なにに使用する？
            String ngMsg = ValueUtil.nullToStr(parameters.get(NG_MSG_PARAM_KEY));

            AdminAuthBean adminAuth = null;
            if (!PhoenixUtil.isEmpty(tableId) && !PhoenixUtil.isEmpty(adUser)) {
                adminAuth = bothAuth(authId, adServer, adUser, adPw, adDomain, siteId, tableId, idItem1, idItem2,
                        idItem3, idValue1, idValue2, idValue3);
            } else if (!PhoenixUtil.isEmpty(tableId)) {
                adminAuth = tableAuth(authId, siteId, tableId, idItem1, idItem2, idItem3, idValue1, idValue2, idValue3);
            } else if (!PhoenixUtil.isEmpty(adUser)) {
                adminAuth = adAuth(authId, adServer, adUser, adPw, adDomain);
            } else {
                adminAuth = checkAuth(request, authId, timeout);
            }

            if (adminAuth != null) {

                // 認証情報をセッションに保存する。
                StoreUtil.setAdminAuth(request, authId, adminAuth);

                // 管理者ログイン済みを設定する。
                StoreUtil.setAdminLogin(request);
                
                if (!PhoenixUtil.isEmpty(authOk)) {
                    response.sendRedirect(authOk);
                    return "";
                } else {
                    // 置換変数の登録を行う。
                    SstagUtil.setAdminAuthReplaceParam(request, adminAuth);
                }
            } else {

                // 認証情報をセッションから削除する。
                StoreUtil.setAdminAuth(request, authId, null);

                // 管理者ログイン済みを解除する。
                StoreUtil.clearAdminLogin(request);
                
                if (!PhoenixUtil.isEmpty(authNg)) {
                    response.sendRedirect(authNg);
                    return "";
                }
            }

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * テーブルとADサーバと両方使用してユーザ認証を行う。
     * 
     * @param authId
     * @param adServer
     * @param adUser
     * @param adPw
     * @param adDomain
     * @param siteId
     * @param tableId
     * @param idItem1
     * @param idItem2
     * @param idItem3
     * @param idValue1
     * @param idValue2
     * @param idValue3
     * @return
     * @throws LoginException
     * @throws SQLException
     */
    public AdminAuthBean bothAuth(String authId, String adServer, String adUser, String adPw, String adDomain,
            int siteId, String tableId, String idItem1, String idItem2, String idItem3, String idValue1,
            String idValue2, String idValue3) throws LoginException, SQLException {
        AdminAuthBean adminAuth = null;

        adminAuth = adAuth(authId, adServer, adUser, adPw, adDomain);
        if (adminAuth != null) {

            adminAuth = tableAuth(authId, siteId, tableId, idItem1, idItem2, idItem3, idValue1, idValue2, idValue3);
            if (adminAuth != null) {
                adminAuth.setUserId(adUser);
                adminAuth.setPassword(adPw);
                adminAuth.setAuthType(AdminAuthBean.AUTH_TYPE_BOTH);
            }

        }

        return adminAuth;
    }

    /**
     * テーブルを使用してのユーザ認証を行う。
     * 
     * @param authId
     * @param siteId
     * @param tableId
     * @param idItem1
     * @param idItem2
     * @param idItem3
     * @param idValue1
     * @param idValue2
     * @param idValue3
     * @return
     * @throws SQLException
     */
    public AdminAuthBean tableAuth(String authId, int siteId, String tableId, String idItem1, String idItem2,
            String idItem3, String idValue1, String idValue2, String idValue3) throws SQLException {
        AdminAuthBean adminAuth = null;

        List<ConditionBean> conditions = new ArrayList<ConditionBean>();
        if (!PhoenixUtil.isEmpty(idItem1)) {
            conditions.add(new ConditionBean(idItem1, "=", idValue1));
        }
        if (!PhoenixUtil.isEmpty(idItem2)) {
            conditions.add(new ConditionBean(idItem2, "=", idValue2));
        }
        if (!PhoenixUtil.isEmpty(idItem3)) {
            conditions.add(new ConditionBean(idItem3, "=", idValue3));
        }

        List<Map<String, ClmDataBean>> list = VDb.getList(siteId, tableId, null, null, conditions, null, null);
        if (!PhoenixUtil.isEmpty(list)) {
            adminAuth = new AdminAuthBean();
            adminAuth.setAuthId(authId);
            adminAuth.setUserId(idValue1);
            adminAuth.setPassword(idValue2);
            adminAuth.setLoginDate(new Date());
            adminAuth.setLastAccessDate(new Date());
            adminAuth.setAuthType(AdminAuthBean.AUTH_TYPE_DB);
            adminAuth.setAuthTableId(tableId);
            adminAuth.setAuthRecord(list.get(0));
        }

        return adminAuth;
    }

    /**
     * ADサーバを使用してのユーザ認証を行う。
     * 
     * @param authId
     * @param adServer
     * @param adUser
     * @param adPw
     * @param adDomain
     * @return
     * @throws LoginException
     */
    public AdminAuthBean adAuth(String authId, String adServer, String adUser, String adPw, String adDomain)
            throws LoginException {
        AdminAuthBean adminAuth = null;

        if (PhoenixUtil.isEmpty(adServer)) {
            adServer = SystemPropertiesDb.getInstance().get(AD_SERVER_URL_PROP_KEY);
        }
        if (PhoenixUtil.isEmpty(adServer)) {
            String message = MessageFormat.format("ADサーバ名がパラメータ[{0}]からも、system_property[{1}]からも取得できませんでした。",
                    AD_SERVER_PARAM_KEY, AD_SERVER_URL_PROP_KEY);
            throw new LoginException(message);
        }

        if (PhoenixUtil.isEmpty(adDomain)) {
            adDomain = SystemPropertiesDb.getInstance().get(AD_DOMAIN_NAME_PROP_KEY);
        }
        if (PhoenixUtil.isEmpty(adDomain)) {
            String message = MessageFormat.format("ADドメイン名がパラメータ[{0}]からも、system_property[{1}]からも取得できませんでした。",
                    AD_DOMAIN_PARAM_KEY, AD_DOMAIN_NAME_PROP_KEY);
            throw new LoginException(message);
        }

        if (AdAuth.auth(adUser, adPw, adDomain, adServer)) {
            adminAuth = new AdminAuthBean();
            adminAuth.setAuthId(authId);
            adminAuth.setUserId(adUser);
            adminAuth.setPassword(adPw);
            adminAuth.setLoginDate(new Date());
            adminAuth.setLastAccessDate(new Date());
            adminAuth.setAuthType(AdminAuthBean.AUTH_TYPE_AD);
            adminAuth.setAuthTableId(null);
            adminAuth.setAuthRecord(null);
        }

        return adminAuth;
    }

    /**
     * ユーザ認証が維持されているかのチェックそ行う。
     * 
     * @param authId
     * @param timeout
     * @return
     * @throws SQLException
     */
    public static AdminAuthBean checkAuth(HttpServletRequest request, String authId, int timeout) throws SQLException {

        if (timeout <= 0) {
            timeout = DEFAULT_TIMEOUT;
        }

        AdminAuthBean adminAuth = StoreUtil.getAdminAuth(request, authId);
        if (adminAuth == null) {
            return null;
        } else if (adminAuth.getLastAccessDate().getTime() + timeout * 1000 < System.currentTimeMillis()) {
            return null;
        }

        adminAuth.setLastAccessDate(new Date());
        return adminAuth;

    }

}
