package jp.co.webcrew.phoenix.store.db;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.store.bean.SessionStoreBean;

/**
 * セッションストア情報を管理するdbクラス。
 * 
 * @author kurinami
 */
public class SessionStoreDb {

    /** セッションストア情報の一覧を取得するためのsql */
    private static final String SELECT_STORE = "select * from session_store where ssid = ? and short_id = ? ";

    /** セッションストア情報を挿入するためのsql */
    private static final String INSERT_STORE = "insert into session_store(ssid, short_id, gsid, guid, key_name, store, site_id, scope, last_datetime) values(?, ?, ?, ?, ?, ?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS')) ";

    /** セッションストア情報を更新するためのsql */
    private static final String UPDATE_STORE = "update session_store set store = ?, last_datetime = to_char(sysdate, 'YYYYMMDDHH24MISS') where ssid = ? and short_id = ? and key_name = ? ";

    /** セッションストア情報を削除するためのsql */
    private static final String DELETE_STORE = "delete from session_store where ssid = ? and short_id = ? and key_name = ?";

    /** セッションストア情報をすべて削除するためのsql */
    private static final String DELETE_ALL_STORE = "delete from session_store where ssid = ? ";

    /** ロガー */
    private static final Logger log = Logger.getLogger(SessionStoreDb.class);

    /**
     * DBAccessを作成する。
     * 
     * @return
     * @throws SQLException
     */
    private static DBAccess newDBAccess() throws SQLException {
        return new DBAccess("session_store");
    }

    /**
     * セッションストア情報を返す。
     * 
     * @param ssid
     * @param shortId
     * @return
     * @throws SQLException
     */
    public static SessionStoreBean getSessionStore(long ssid, String shortId) throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = newDBAccess();

            SessionStoreBean sessionStore = new SessionStoreBean();

            // セッションストア情報を取得する。
            dbAccess.prepareStatement(SELECT_STORE);
            dbAccess.setLong(1, ssid);
            dbAccess.setString(2, shortId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                String keyName = ValueUtil.nullToStr(rs.getString("key_name"));
                Object store = deserialize(rs.getString("store"));
                String scope = Integer.toString(rs.getInt("scope"));
                sessionStore.set(keyName, store, scope);
            }

            return sessionStore;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報を挿入する。
     * 
     * @param ssid
     * @param shortId
     * @param gsid
     * @param guid
     * @param keyName
     * @param store
     * @param siteId
     * @param scope
     * @throws SQLException
     */
    public static void insert(long ssid, String shortId, long gsid, long guid, String keyName, Object store,
            int siteId, String scope) throws SQLException {

        DBAccess dbAccess = null;
        
        //ssid、gsid、guidがいずれも0の場合、insert処理を適用しない。
        if(ssid==0 && gsid==0 && guid==0)
        {
        	log.warn(
        			"ssid,gsid,guidいずれも0のため、" +
        			"ph_session.session_storeへのinsert処理は適用していません。" +
        			"[short_id:key_name]#["+shortId+":"+keyName+"]");
        	return;
        }
        
        try {
            dbAccess = newDBAccess();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // セッションストア情報を挿入する。
            dbAccess.prepareStatement(INSERT_STORE);

            int i = 0;
            dbAccess.setLong(++i, ssid);
            dbAccess.setString(++i, shortId);
            dbAccess.setLong(++i, gsid);
            dbAccess.setLong(++i, guid);
            dbAccess.setString(++i, keyName);
            dbAccess.setString(++i, serialize(store));
            dbAccess.setInt(++i, siteId);
            dbAccess.setInt(++i, ValueUtil.toint(scope));
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
        	
        	log.error("ph_session.session_storeへの" +
        			"insert処理にて例外検知" +
        			"[err]"+e.getMessage()+
        			"[ssid:gsid:guid:short_id:key_name]#" +
        			"["+ssid+":"+gsid+":"+guid+":"+shortId+":"+keyName+"]",e);
        	
            // ロールバックする。
            dbAccess.rollback();
            throw e;
        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報を更新する。
     * 
     * @param ssid
     * @param shortId
     * @param keyName
     * @param store
     * @throws SQLException
     */
    public static void update(long ssid, String shortId, String keyName, Object store) throws SQLException {
        DBAccess dbAccess = null;
        try {
            dbAccess = newDBAccess();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // セッションストア情報を更新する。
            dbAccess.prepareStatement(UPDATE_STORE);

            int i = 0;
            dbAccess.setString(++i, serialize(store));
            dbAccess.setLong(++i, ssid);
            dbAccess.setString(++i, shortId);
            dbAccess.setString(++i, keyName);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;
        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報を削除する。
     * 
     * @param ssid
     * @param shortId
     * @param keyName
     * @throws SQLException
     */
    public static void delete(long ssid, String shortId, String keyName) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = newDBAccess();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // セッションストア情報を削除する。
            dbAccess.prepareStatement(DELETE_STORE);
            int i = 0;
            dbAccess.setLong(++i, ssid);
            dbAccess.setString(++i, shortId);
            dbAccess.setString(++i, keyName);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報をすべて削除する。
     * 
     * @param ssid
     * @param shortId
     * @throws SQLException
     */
    public static void deleteAll(long ssid, String shortId) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = newDBAccess();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // sqlを組み立てる。
            StringBuffer sb = new StringBuffer(DELETE_ALL_STORE);
            if (shortId.length() > 0) {
                sb.append(" and short_id = '" + shortId + "'");
            }

            // セッションストア情報を削除する。
            dbAccess.prepareStatement(sb.toString());
            int i = 0;
            dbAccess.setLong(++i, ssid);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報を文字列に変換する。
     * 
     * @param storeMap
     * @return
     * @throws SQLException
     */
    public static String serialize(Object store) throws SQLException {
        // TODO kurinami 【確認】 このやり方で問題ないか。
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(store);
            oos.flush();
            return new String(baos.toByteArray(), "ISO-8859-1");
        } catch (Exception e) {
            throw new SQLException("シリアライズに失敗しました。", e);
        }
    }

    /**
     * 文字列をセッションストア情報に戻す。
     * 
     * @param store
     * @return
     * @throws SqlException
     */
    public static Object deserialize(String store) {
        // TODO kurinami 【確認】 このやり方で問題ないか。
        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(store.getBytes("ISO-8859-1"));
            ObjectInputStream ois = new ObjectInputStream(bais);
            return (Object) ois.readObject();
        } catch (ClassNotFoundException e) {
            // TODO kurinami 【確認】 ★ ちゃんとここでエラーが発生するか。
            log.error("オブジェクトの復元に失敗しました。", e);
            return null;
        } catch (IOException e) {
            log.error("デコードに失敗しました。", e);
            return null;
        }
    }

}
