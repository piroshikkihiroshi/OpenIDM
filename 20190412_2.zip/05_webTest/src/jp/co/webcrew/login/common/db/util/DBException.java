package jp.co.webcrew.login.common.db.util;
import java.sql.SQLException;
public class DBException extends SQLException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1501455857750744362L;

	public DBException(){
		super();
	}
	
	public DBException(String s){
		super(s);
	}

	public DBException(Throwable e){
		super(e.getMessage());
	}

}

