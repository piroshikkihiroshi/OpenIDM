package jp.co.webcrew.filters.util.httputil;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;


/**
 * リクエストに対して、パラメータやリクエストボディを操作できるようにしたrequestクラス。
 * 
 * @author kurinami
 */
public class CustomHttpServletRequest extends HttpServletRequestWrapper {

	/** 追加するパラメータ */
	private Map parameterMap = null;

	/** クエリストリング */
	private String queryString = null;

	/** リクエストボディ */
	private byte[] requestBody = null;

	public CustomHttpServletRequest(HttpServletRequest request) {
		super(request);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletRequestWrapper#getParameter(java.lang.String)
	 */
	public String getParameter(String key) {

		if (parameterMap == null) {
			return super.getParameter(key);
		}

		String[] parameterValues = getParameterValues(key);
		if (parameterValues != null && parameterValues.length > 0) {
			return parameterValues[0];
		} else {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletRequestWrapper#getParameterMap()
	 */
	public Map getParameterMap() {

		if (this.parameterMap == null) {
			return super.getParameterMap();
		}

		Map ret = new HashMap();
		ret.putAll(super.getParameterMap());
		ret.putAll(parameterMap);
		return ret;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletRequestWrapper#getParameterNames()
	 */
	public Enumeration getParameterNames() {

		if (parameterMap == null) {
			return super.getParameterNames();
		}

		Map parameterMap = getParameterMap();
		return new Vector(parameterMap.keySet()).elements();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletRequestWrapper#getParameterValues(java.lang.String)
	 */
	public String[] getParameterValues(String key) {

		if (parameterMap == null) {
			return super.getParameterValues(key);
		}

		if (parameterMap.containsKey(key)) {
			Object parameter = parameterMap.get(key);
			if (parameter == null) {
				return null;
			} else if (parameter instanceof String) {
				return new String[] { (String) parameter };
			} else if (parameter instanceof String[]) {
				return (String[]) parameter;
			} else {
				return null;
			}
		} else {
			return super.getParameterValues(key);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServletRequestWrapper#getQueryString()
	 */
	public String getQueryString() {

		if (queryString == null) {
			return super.getQueryString();
		}

		return queryString.length() == 0 ? null : queryString;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletRequestWrapper#getInputStream()
	 */
	public ServletInputStream getInputStream() throws IOException {

		if (requestBody == null) {
			return super.getInputStream();
		}

		return new CustomServletInputStream(new ByteArrayInputStream(requestBody));
	}

	// 以下アクセッサ

	public void setParameterMap(Map parameterMap) {
		this.parameterMap = parameterMap;
	}

	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}

	public void setRequestBody(byte[] requestBody) {
		this.requestBody = requestBody;
	}

}
