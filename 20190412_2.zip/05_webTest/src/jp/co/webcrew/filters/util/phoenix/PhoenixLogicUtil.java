package jp.co.webcrew.filters.util.phoenix;

import java.security.MessageDigest;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.step.CarBangUserInfo;
import jp.co.webcrew.login.common.db.step.HikkoshiUserInfo;
import jp.co.webcrew.login.common.db.step.StepUserInfo;

public class PhoenixLogicUtil
{
	private static final Logger log = Logger.getLogger(PhoenixLogicUtil.class);
	
	/**
     * 
     * @param db
     * @param siteId
     * @param tableId
     * @param clmId
     * @param keyName
     * @param keyValue
     * @param sort
     * @return
     * @throws SQLException
     */
    public static ResultSet querySort(DBAccess db, String siteId, String schema, String tableId, String clmId, 
                                      String keyName, String keyCond, String keyValue, 
                                      String keyName1,String keyCond1, String keyValue1,
                                      String keyName2,String keyCond2, String keyValue2,
                                      String sort, boolean ignorePubFlag) throws SQLException {
        String prodSql = "select clm_data.* from ###schema###.clm_data \n"
                         + " left outer join (select rec_id, to_number(key_data) as sort_key from ###schema###.clm_data where site_id = ###site_id### and tbl_id = '###table_id###' and clm_id = '###clm_id###') sort_tbl on clm_data.rec_id = sort_tbl.rec_id \n"
                         + " inner join (select rec_id from ###schema###.clm_data where site_id = ###site_id### and tbl_id = '###table_id###' and clm_id = '###key_name###' and key_data ###key_cond### '###key_value###') cond_tbl0 on clm_data.rec_id = cond_tbl0.rec_id \n"
                         + " ###condition1###"
                         + " ###condition2###"
                         + " inner join (select rec_id from ###schema###.rec_meta_data where site_id = ###site_id### and tbl_id = '###table_id###' and pub_flag = '1' and to_char(sysdate, 'YYYYMMDDHH24MISS') between bgn_datetime and end_datetime) rec_meta_data on clm_data.rec_id = rec_meta_data.rec_id \n"
                         + " where clm_data.site_id = ###site_id### and clm_data.tbl_id = '###table_id###' \n"
                         + " order by sort_tbl.sort_key ###sort###,  clm_data.rec_id, clm_data.sort_num";
        
        String condition1 = " inner join (select rec_id from loan.clm_data where site_id = ###site_id### and tbl_id = '###table_id###' and clm_id = '###key_name1###' and key_data ###key_cond1### '###key_value1###') cond_tbl1 on clm_data.rec_id = cond_tbl1.rec_id \n";
        String condition2 = " inner join (select rec_id from loan.clm_data where site_id = ###site_id### and tbl_id = '###table_id###' and clm_id = '###key_name2###' and key_data ###key_cond2### '###key_value2###') cond_tbl2 on clm_data.rec_id = cond_tbl2.rec_id \n";
        
        String sql = "";
        sql = prodSql;
        
        sql = sql.replaceAll("###schema###", schema);

        if (keyName1 == null || keyCond1 == null || keyValue1 == null) {
            condition1 = "";
        } else {
            condition1 = condition1.replaceAll("###key_name1###", keyName1);
            condition1 = condition1.replaceAll("###key_cond1###", keyCond1);
            condition1 = condition1.replaceAll("###key_value1###", keyValue1);
        }
        if (keyName2 == null || keyCond2 == null || keyValue2 == null) {
            condition2 = "";
        } else {
            condition2 = condition2.replaceAll("###key_name2###", keyName2);
            condition2 = condition2.replaceAll("###key_cond2###", keyCond2);
            condition2 = condition2.replaceAll("###key_value2###", keyValue2);
        }
        
        sql = sql.replaceAll("###condition1###", condition1);
        sql = sql.replaceAll("###condition2###", condition2);
        sql = sql.replaceAll("###site_id###", siteId);
        sql = sql.replaceAll("###table_id###", tableId);
        sql = sql.replaceAll("###clm_id###", clmId);
        sql = sql.replaceAll("###key_name###", keyName);
        sql = sql.replaceAll("###key_cond###", keyCond);
        sql = sql.replaceAll("###key_value###", keyValue);
        sql = sql.replaceAll("###sort###", sort);
        
        db.prepareStatement(sql);
        return db.executeQuery();
    }
    
    /**
     * 指定された仮想テーブル検索結果を、RowDataのリストに対して登録する。
     * １レコード（recIdで識別）単位でRowDataが作成され、それがレコード数分
     * だけlistに追加されていく。
     * 仮想テーブル検索用にしか利用できないので注意。
     * 
     * @param list RowDataのリスト
     * @param recId レコードＩＤ
     * @param columnName カラム名
     * @param keyData カラムの値（512kまで）
     * @param lobData カラムの値から溢れたlobData
     * @param upDatetime
     */
    public static void setRowData(List list , Long recId , String columnName , String keyData , String lobData , String upDatetime) {
                
        if (list == null) list = new ArrayList();

        // listからrecIdに該当するrowdataを検索して取得する。なければ新規作成して追加
        RowData row = searchRowData(list, recId);
        
        if (row == null) {
            row = new RowData();
            row.setRecId(recId);
            list.add(row);
        }
        
        // rowdata に列の値を追加する
        row.set(columnName , keyData , lobData , upDatetime);
        
        
    }
    
    
    /**
     * 指定されたlistの中から、指定したrecIdに合致するRowDataを検索し返す。
     * @param list RowDataのリスト
     * @param recId レコードＩＤ
     * @return RowData 指定したレコードＩＤに対応するもの
     */
    public static RowData searchRowData(List list , Long recId){
        
        if (list == null) return null;
        
        if (list.size() == 0 ) return null;
        
        for(Iterator it = list.iterator() ; it.hasNext();) {
            
            RowData row = (RowData)it.next();
            
            if (row.getRecId().longValue() == recId.longValue()) {
                return row;
            }
            
        }
        
        return null;
    }
    
    
    
    
    /**
     * 仮想テーブルの検索を指定された条件で実行する。
     * 本番機の場合は、公開データのみを抽出するようにする。
     * @param db PhoenixDBAccess
     * @param siteId サイトＩＤ
     * @param tableName 検索対象のテーブル名
     * @param condition 検索条件
     * @return ResultSet 検索結果
     * @throws SQLException
     */
    public static ResultSet query(DBAccess db, int siteId, String schema, String tableName, String condition) throws SQLException {
        String now = currentDateTime();
        String sql = "";
        sql = " select data.* \n"
            +   " from \n"
            +   "  ###schema###.clm_data data, \n"
            +   "  ###schema###.rec_meta_data meta \n"
            +   " where \n"
            +   "   meta.site_id=data.site_id \n"
            +   " and \n"
            +   "   meta.tbl_id=data.tbl_id \n"
            +   " and \n"
            +   "   meta.rec_id=data.rec_id \n"
            +   " and \n"
            +   "   meta.pub_flag='1' \n"
            +   " and \n"
            +   "  (meta.bgn_datetime <= ? and ? <= meta.end_datetime) \n"
            +   " and \n"
            +   "  data.site_id=? \n"
            +   " and \n"
            +   "  data.tbl_id=? \n"
            +   condition
            +   " order by data.rec_id asc,data.sort_num asc ";
   
        sql = sql.replaceAll("###schema###", schema);
        
        db.prepareStatement(sql);
        db.setString(1, now);
        db.setString(2, now);
        db.setInt   (3, siteId);
        db.setString(4, tableName);
            
        return db.executeQuery();
    }

    /**
     * 現在日付時刻をYYYYMMDDHHMISSの文字列形式で返す
     * @return
     */
	public static String currentDateTime(){
		return now(14);
	}
	
	public static String now(int type) {

		int      Year;       /* 年   */
		int      Mon;        /* 月   */
		int      Day;        /* 日   */
//		int      WDay;       /* 曜日 */
		int      Hour;       /* 時   */
		int      Min;        /* 分   */
		int      Sec;        /* 秒   */

		TimeZone            tzone;
		GregorianCalendar   cal;

		tzone = TimeZone.getTimeZone("JST");
		cal = new GregorianCalendar(tzone);

		Year = cal.get(Calendar.YEAR);
		Mon = cal.get(Calendar.MONTH) + 1;
		Day = cal.get(Calendar.DATE);
//		WDay = cal.get(Calendar.DAY_OF_WEEK) - 1;
		Hour = cal.get(Calendar.HOUR_OF_DAY);
		Min = cal.get(Calendar.MINUTE);
		Sec = cal.get(Calendar.SECOND);

		if (type == 14) {
			// YYYYMMDDHIMMSS
			return toZString(Year,4)+toZString(Mon,2)+toZString(Day,2)+
						toZString(Hour,2)+toZString(Min,2)+toZString(Sec,2);
		}
		else {
			// YYYYMMDD
			return toZString(Year,4)+toZString(Mon,2)+toZString(Day,2);
		}
	}
	
	/**
	 * 数字を桁揃えする（左側に0を詰める）
	 * @param val 数字
	 * @param width 揃える桁数
	 * @return 変換後の文字列
	 */
	public static String toZString(int val, int width) {

		String s = Integer.toString(val);
		return lpadZero(s, width);
	}

	/**
	 * 文字列を指定桁数まで'0'で左詰めします
	 * @param src  変換元の文字列
	 * @param keta 桁数
	 * @return 変換後の文字列
	 * @throws IllegalDataException
	 */
	public static String lpadZero( String src ,int keta ) {
		return lpad(src,keta,"0");
	}
	
	/**
	 * 文字列を指定桁数まで左詰めします
	 * @param src  変換元の文字列
	 * @param keta 桁数
	 * @param str  埋める文字
	 * @return
	 */
	public static String lpad( String src ,int keta,String str ) {
		if(src == null){
			src = "";
		}
		
		int len = src.length();
		if(keta < len){
			log.warn("桁数の合わないデータが渡されました。");
			return "";
		}

		StringBuffer wk = new StringBuffer();
		for ( int i=0 ; i < keta - len ; i++ ){
			wk.append(str);
		}
		wk.append( src );
		
		return wk.toString();
	}
	
    /**
     * ResultSetから、lob_dataもしくはkey_dataを取得する。
     * lob_dataが512バイトを超える場合は、lob_dataに値が入る、というルールになっているため、
     * まずlob_dataを取得して値が入っていたらそれを返却し、入っていなければkey_dataを取得して返却する。
     * @param rs
     * @return
     * @throws SQLException
     */
    public static String getClmData(ResultSet rs) throws SQLException {
        String returnValue = "";
        returnValue = ValueUtil.nullToStr(rs.getString("lob_data"));
        if (returnValue.equals("")) {
            returnValue = rs.getString("key_data");
        }
        return returnValue;
    }
    
    public static String get(StepUserInfo userInfo, String columnName) {
    	String value = "";
    	// 自動車PC,モバイル
        if (userInfo instanceof CarBangUserInfo) {
        	value =  ((CarBangUserInfo)userInfo).get(columnName);
        } else if (userInfo instanceof HikkoshiUserInfo) {
        //引越比較個人PC　・　ズバット引越比較個人PC
        	
        	value =  ((HikkoshiUserInfo)userInfo).get(columnName);
        	//引越しの場合は都道府県は引越し先のものを利用する。
        	if (columnName.equals("pref_id") || columnName.equals("prom_code") || columnName.equals("zip")
        		|| columnName.equals("address_1") || columnName.equals("address_2") || columnName.equals("address_3")
        		|| columnName.equals("address_4") || columnName.equals("address_5")
        		|| columnName.equals("next_address_1") || columnName.equals("next_address_2") || columnName.equals("next_address_3")
        		|| columnName.equals("next_address_4") || columnName.equals("next_address_5") || columnName.equals("order_comment")
        		|| columnName.equals("client_ip_address")) {
        		value = ((HikkoshiUserInfo)userInfo).getFromOrderId(columnName);
        	}
        }
        return ValueUtil.nullToStr(value);
    }
}
