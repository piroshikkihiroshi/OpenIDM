package jp.co.webcrew.login.common.db.step;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;



public class StepUserInfoFactory {

	/** ロガー */
	private static Logger log = Logger.getLogger(StepUserInfoFactory.class);
	
	/**
	 * 
	 * @param siteId
	 * @param db
	 * @return null 該当するサイトIDが見つからなかった時
	 */
	public static StepUserInfo createStepUserInfo(HttpServletRequest request , String siteId){
		log.debug("siteId=" + siteId);

		//TODO takahashi リフレクションを使ったクラス生成を検討する
		if(siteId.equals("5300")) {
			log.debug("create BikeBangUserInfo");
			return new BikeBangUserInfo(request , siteId);
		}
		
		if(siteId.equals("4600")) {
			log.debug("create FxBangUserInfo");
			return new FxBangUserInfo(request , siteId);
		}

		if(siteId.equals("3600")) {
			log.debug("create KKHikakuUserInfo");
			return new KKHikakuUserInfo(request , siteId);
		}

        // ピアノ買取PC
		if(siteId.equals("3910")) {
			log.debug("create PianoKaitoriUserInfo");
			return new PianoKaitoriUserInfo(request , siteId);
		}
        // ピアノ買取MOBILE
        if(siteId.equals("3930")) {
            log.debug("create PianoKaitoriUserInfo");
            return new PianoKaitoriUserInfo(request , siteId);
        }
        
        // ズバットピアノ買取
        if(siteId.equals("3940") || siteId.equals("3960")) {
            log.debug("create PianoKaitoriUserInfo");
            return new PianoKaitoriUserInfo(request , siteId);
        }

		if(siteId.equals("3100")) {
			log.debug("create HCHikakuUserInfo");
			return new HCHikakuUserInfo(request , siteId);
		}

		// 車買取
		if(siteId.equals("4100")) {
			log.debug("create SateiOmakseUserInfo");
			return new SateiOmakaseUserInfo(request , siteId);
		}
		
		// 車買取モバイル
		if(siteId.equals("4130")) {
			log.debug("create SateiOmakseUserInfo");
			return new SateiOmakaseUserInfo(request , siteId);
		}

		// ズバット車買取PC/モバイル
		if(siteId.equals("4160") || siteId.equals("4163")) {
			log.debug("create SateiOmakseUserInfo");
			return new SateiOmakaseUserInfo(request , siteId);
		}

        // ランディングページから車買取モバイル/ズバット車買取PC
        if (siteId.equals("4170") || siteId.equals("4171")) {
            log.debug("create SateiOmakseUserInfo");
            return new SateiOmakaseUserInfo(request, siteId);
        }

        // ランディングページから車買取モバイル/ズバット車買取モバイル
        if (siteId.equals("4172") || siteId.equals("4173")) {
            log.debug("create SateiOmakseUserInfo");
            return new SateiOmakaseUserInfo(request, siteId);
        }

		//引越見積人PC
		if(siteId.equals("4400")) {
			log.debug("create FunMovingUserInfo");
			return new FunMovingUserInfo(request , siteId);
		}
		//引越見積人モバイル
		if(siteId.equals("4402")) {
			log.debug("create FunMovingUserInfo");
			return new FunMovingUserInfo(request , siteId);
		}

		//引越し大手PC	ズバットサイトID:3430
		if(siteId.equals("3400") || siteId.equals("3430")) {
			log.debug("create Hikkoshi_oUserInfo");
			return new Hikkoshi_oUserInfo(request , siteId);
		}
        //引越し大手モバイル		ズバットサイトID:3433
        if(siteId.equals("3403") || siteId.equals("3433")) {
            log.debug("create Hikkoshi_oUserInfo");
            return new Hikkoshi_oUserInfo(request , siteId);
        }

        //引越比較個人PC　・　ズバット引越比較個人PC
		if(siteId.equals("3001") || siteId.equals("3051")) {
			log.debug("create HikkoshiUserInfo");
			return new HikkoshiUserInfo(request , siteId);
		}
        //引越比較法人　・　ズバット引越比較法人
		if(siteId.equals("3002") || siteId.equals("3052")) {
			log.debug("create HikkoshiHoujinUserInfo");
			return new HikkoshiHoujinUserInfo(request , siteId);
		}
        //引越比較海外　・　ズバット引越比較海外
		if(siteId.equals("3003") || siteId.equals("3053")) {
			log.debug("create HikkoshiKaigaiUserInfo");
			return new HikkoshiKaigaiUserInfo(request , siteId);
		}
        //引越比較個人モバイル
		if(siteId.equals("3030") || siteId.equals("3060")) {
			log.debug("create HikkoshiUserInfo");
			return new HikkoshiUserInfo(request , siteId);
		}

		if(siteId.equals("4800")) {
			log.debug("create CxBangUserInfo");
			return new CxBangUserInfo(request , siteId);
		}

		if(siteId.equals("5000")) {
			log.debug("create FireBangUserInfo");
			return new FireBangUserInfo(request , siteId);
		}

		// ペットBANG!
		if(siteId.equals("1003")) {
			log.debug("create PetBangUserInfo");
			return new PetBangUserInfo(request , siteId);
		}		

		if(siteId.equals("1014")) {
			log.debug("create PetBangUserInfo");
			return new PetBangUserInfo(request , siteId);
		}		

        // ズバットペットBANG!
        if (siteId.equals("1017") || siteId.equals("1018")) {
            log.debug("create PetBangUserInfo");
            return new PetBangUserInfo(request, siteId);
        }

		if(siteId.equals("3300")) {
			log.debug("create SkaifukuUserInfo");
			return new SkaifukuUserInfo(request , siteId);
		}		

		if(siteId.equals("5100")) {
			log.debug("create OfficeKaitoriUserInfo");
			return new OfficeKaitoriUserInfo(request , siteId);
		}		

		if(siteId.equals("5200")) {
			log.debug("create HinabeUserInfo");
			return new HinabeUserInfo(request , siteId);
		}

		if(siteId.equals("4602")) {
			log.debug("create FxBangMobileUserInfo");
			return new FxBangMobileUserInfo(request , siteId);
		}		

        if(siteId.equals("3320")) {
            log.debug("create SkaifukuUserInfo (for mobile)");
            return new SkaifukuUserInfo(request , siteId);
        }

        if(siteId.equals("8000")) {
            log.debug("create FXKingOpenUserAccountInfo");
            return new FXKingOpenUserAccountInfo(request , siteId);
        }
        
        if(siteId.equals("8001")) {
            log.debug("create FXKingDemoOpenUserDemoInfo");
            return new FXKingDemoOpenUserDemoInfo(request , siteId);
        }
        
        if(siteId.equals("8002")) {
            log.debug("create FXKingDocKojinUserDocKojinInfo");
            return new FXKingDocKojinUserDocKojinInfo(request , siteId);
        }
        
        if(siteId.equals("8003")) {
            log.debug("create FXKingDocHoujinUserDocHoujinInfo");
            return new FXKingDocHoujinUserDocHoujinInfo(request , siteId);
        }
        // 結婚比較
        if(siteId.equals("3600") || siteId.equals("3603")) {
			log.debug("create KKHikakuUserInfo");
			return new KKHikakuUserInfo(request , siteId);
		}
        // ズバッと結婚比較
        if(siteId.equals("3608") || siteId.equals("3612")) {
			log.debug("create KKHikakuUserInfo");
			return new KKHikakuUserInfo(request , siteId);
		}
        // ハウス
        if(siteId.equals("3100") || siteId.equals("3103")) {
			log.debug("create HChikakuUserInfo");
			return new HCHikakuUserInfo(request , siteId);
		}        
        // ズバットハウス
        if(siteId.equals("3150") || siteId.equals("3153")) {
			log.debug("create HChikakuUserInfo");
			return new HCHikakuUserInfo(request , siteId);
		}        
        
      if(siteId.equals("8012")) {
        log.debug("create FXKingDocKojinUserDocKojinInfo (for mobile)");
        return new FXKingDocKojinUserDocKojinInfo(request , siteId);
      }
        
      // Bang!バイクPC、ズバットPC
      if(siteId.equals("10000") || siteId.equals("10003")) {
        log.debug("create BikeBangUserInfo");
        return new BikeBangUserInfo(request , siteId);
      }
      // Bang!バイク モバイル、ズバットモバイル
      if(siteId.equals("10001") || siteId.equals("10004")) {
        log.debug("create BikeBangUserInfo for mobile");
        return new BikeBangUserInfo(request , siteId);
      }
      
      if(siteId.equals("5500")) {
          log.debug("create FundBangUserInfo");
          return new FundBangUserInfo(request , siteId);
      }
      
      // バイク買取
      if(siteId.equals("7000") || siteId.equals("7005")) {
        log.debug("create BikeSateomaUserInfo");
        return new BikeSateomaUserInfo(request , siteId);
      }

      
      // Bang！生保PC、Bang！生保モバイル　ズバット生保PC、ズバット生保モバイル
      if(siteId.equals("6100") || siteId.equals("6110") || siteId.equals("6120") || siteId.equals("6200")) {
        log.debug("create LifeBangUserInfo");
        return new LifeBangUserInfo(request , siteId);
      }      

      // 自動車PC,モバイル
        if (siteId.equals("11005") || siteId.equals("11000") || siteId.equals("11001") || siteId.equals("11002") || siteId.equals("11010")
                || siteId.equals("11011")) {
            log.debug("create CarBangUserInfo");
            return new CarBangUserInfo(request, siteId);
        }

        //貴金属買取
        if (siteId.equals("11100") || siteId.equals("11101"))
        {
          log.debug("create KaitoriGoldUserInfo");
          return new KaitoriGoldUserInfo(request, siteId);
        }

        // 中古携帯買取
        if(siteId.equals("9300") || siteId.equals("9301")) {
            log.debug("create KaitoriKeitaiUserInfo");
            return new KaitoriKeitaiUserInfo(request , siteId);
        }

        // 住宅ローン
        if(siteId.equals("11600")) {
            log.debug("create HomeLoanUserInfo");
            return new HomeLoanUserInfo(request , siteId);
        }
        
        // 老人ホーム
        if(siteId.equals("11800")) {
            log.debug("create RoujinHomeUserInfo");
            return new RoujinHomeUserInfo(request , siteId);
        }

        // ホームセキュリティ
        if(siteId.equals("11900")) {
            log.debug("create HomeSecurityUserInfo");
            return new HomeSecurityUserInfo(request , siteId);
        }
      
        // 食材宅配
        if(siteId.equals("12400")) {
            log.debug("create FoodDeliveryUserInfo");
            return new FoodDeliveryUserInfo(request , siteId);
        }
        
        // 通信制高校
        if(siteId.equals("10800") || siteId.equals("10801") || siteId.equals("10806") || siteId.equals("10807")) {
            log.debug("create Gogo2UserInfo");
            return new Gogo2UserInfo(request , siteId);
        }
        
        // 車販売
        if(siteId.equals(CarHanbaiUserInfo.PC_SITE_ID)) {
            log.debug("create CarSellUserInfo");
            return new CarHanbaiUserInfo(request , siteId);
        }
        
		return null;

	}

    /**
     * <pre>
     * 
     * </pre>
     * 
     * @param request
     * @param siteId
     */
    public static StepUserInfo createEmptyUserInfo(HttpServletRequest request , String siteId){
        return new EmptyUserInfo(request , siteId);
    }
    
}
