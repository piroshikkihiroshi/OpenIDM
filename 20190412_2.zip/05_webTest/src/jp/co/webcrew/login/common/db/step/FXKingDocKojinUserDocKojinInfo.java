package jp.co.webcrew.login.common.db.step;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;



public class FXKingDocKojinUserDocKojinInfo extends StepUserInfoCommonDb{

	public static final String SCHEMA = "FXKING"; 
	public static final String TABLE = "USER_DOC_KOJIN_INFO"; 
	/** 法人向けサイトであるか否か   */
	public static final boolean CORPORATE_SERVICE_FLG = false;
	
    /** PC用の履歴表示サイト名 */
	public static final String ORDER_TEXT_CAPTION_PC = "FXキング 個人資料請求 PC";
    /** MBL用の履歴表示サイト名 */
    public static final String ORDER_TEXT_CAPTION_MBL = "FXキング 個人資料請求 モバイル";
    
    /** PCサイトＩＤ*/
    public static final String PC_SITE_ID = "8002";
	
	public static final String USER_ID = "USER_ID";
	public static final String STEP_SITE_ID = "STEP_SITE_ID";
	public static final String NAME_KANJI_1 = "NAME_KANJI_1";
	public static final String NAME_KANJI_2 = "NAME_KANJI_2";
	public static final String NAME_KANA_1 = "NAME_KANA_1";
	public static final String NAME_KANA_2 = "NAME_KANA_2";
    public static final String BIRTH_DATE = "BIRTH_DATE";
	public static final String SEX_ID = "SEX_ID";
	public static final String ZIP = "ZIP";
	public static final String PREF_ID = "PREF_ID";
	public static final String ADDRESS_1 = "ADDRESS_1";
	public static final String ADDRESS_2 = "ADDRESS_2";
	public static final String ADDRESS_3 = "ADDRESS_3";
	public static final String ADDRESS_4 = "ADDRESS_4";
	public static final String ADDRESS_5 = "ADDRESS_5";
	public static final String TEL = "TEL";
    public static final String MOBILE = "MOBILE";
	public static final String EMAIL = "EMAIL";

	public static final String PERMIT_WC_FLG = "PERMIT_WC_FLG";
	public static final String FINISH_FLG = "FINISH_FLG";
    public static final String MOBILE_FLG = "MOBILE_FLG";
	public static final String LAST_UPDATE = "LAST_UPDATE";
	public static final String DELETE_DATE = "DELETE_DATE";
	public static final String GUID = "GUID";

	private static String SEQUENCE_SQL = "SELECT fxking.seq_user_account_info.nextval AS userId,fxking.seq_order_account_info.nextval AS requestId FROM   dual";

	/** ロガー */
	private Logger log = Logger.getLogger(this.getClass());

	public void doInit(){
		setSchema(SCHEMA);
		setTable(TABLE);
	}
	
	private FXKingDocKojinUserDocKojinInfo(){
	}

	/**
	 * コンストラクタ
	 * @param request
	 * @param siteId
	 */
	public FXKingDocKojinUserDocKojinInfo(HttpServletRequest request , String siteId ){
		setSiteId(siteId);
		setHttpRequest(request);
	}

	public String getEmail(){
		return get(EMAIL);
	}

	/**
	 * @return true ロードに成功（該当レコードあり）
	 * @return false ロードに失敗（該当レコードなし）
	 */
	public boolean doLoad(DBAccess db , String orderId , String userId) throws SQLException{
		setRequestId(orderId);
		setUserId(userId);
        setCorporateService(CORPORATE_SERVICE_FLG);
		
		return load(db);
	}

	public String getSequenceSQL(){
		return SEQUENCE_SQL;
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doCreateNewStepId(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	public void doCreateNewStepId(DBAccess db) throws SQLException{
	
		String userId = "";
		String requestId = "";
		
		ResultSet rs = null;
		try{
			db.prepareStatement(getSequenceSQL());
			rs = db.executeQuery();
			if (db.next(rs)) {
				userId = ValueUtil.nullToStr(rs.getString("userId"));
				requestId = ValueUtil.nullToStr(rs.getString("requestId"));
			}
			
			setUserId(userId);
			setRequestId(requestId);

		} catch(SQLException e){
			// 例外エラー
			log.error("シーケンス取得中にデータベースエラーが発生しました。",e);
			throw e;
			
		} finally {
			DBAccess.close(rs);
		}
	    
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doPrepareStepDatabase(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	protected void doPrepareStepDatabase(DBAccess db) throws SQLException{

		try{
			
			// USER_INFOに登録
			StringBuffer buf = new StringBuffer();
			buf.append("INSERT INTO fxking.user_doc_kojin_info (");
			buf.append(USER_ID);
			buf.append(",");
			buf.append(STEP_SITE_ID);
			buf.append(",");
			buf.append(NAME_KANJI_1);
			buf.append(",");
			buf.append(NAME_KANJI_2);
			buf.append(",");
			buf.append(NAME_KANA_1);
			buf.append(",");
			buf.append(NAME_KANA_2);
            buf.append(",");
            buf.append(BIRTH_DATE);
			buf.append(",");
			buf.append(SEX_ID);
			buf.append(",");
			buf.append(ZIP);
			buf.append(",");
			buf.append(PREF_ID);
			buf.append(",");
			buf.append(ADDRESS_1);
			buf.append(",");
			buf.append(ADDRESS_2);
			buf.append(",");
			buf.append(ADDRESS_3);
			buf.append(",");
			buf.append(ADDRESS_4);
			buf.append(",");
			buf.append(ADDRESS_5);
			buf.append(",");
			buf.append(TEL);
			buf.append(",");
			buf.append(MOBILE);
			buf.append(",");
			buf.append(EMAIL);
			buf.append(",");
			buf.append(PERMIT_WC_FLG);
			buf.append(",");
			buf.append(FINISH_FLG);
			buf.append(",");
			buf.append(LAST_UPDATE);
			buf.append(",");
			buf.append(DELETE_DATE);
			buf.append(",");
			buf.append(GUID);

			buf.append(") VALUES ( ");
			buf.append("?,?,?,?,?,?,?,?,?,?,");
			buf.append("?,?,?,?,?,?,?,?,?,?,");
			buf.append("?,?,?");
			buf.append(") ");

			String sql = buf.toString();
			db.prepareStatement(sql);
			
            db.setString(1, getUserId());
            db.setString(2, getSiteId());
            db.setString(3, trimGet(NAME_KANJI_1));
            db.setString(4, trimGet(NAME_KANJI_2));
            db.setString(5, trimGet(NAME_KANA_1));
            db.setString(6, trimGet(NAME_KANA_2));
            db.setString(7, trimGet(BIRTH_DATE));
            db.setString(8, trimGet(SEX_ID));
            db.setString(9, trimGet(ZIP));
            db.setString(10, trimGet(PREF_ID));
            db.setString(11, trimGet(ADDRESS_1));
            db.setString(12, trimGet(ADDRESS_2));
            db.setString(13, trimGet(ADDRESS_3));
            db.setString(14, trimGet(ADDRESS_4));
            db.setString(15, trimGet(ADDRESS_5));
            db.setString(16, trimGet(TEL));
            db.setString(17, trimGet(MOBILE));
            db.setString(18, trimGet(EMAIL));
            db.setString(19, trimGet(PERMIT_WC_FLG));
            db.setString(20, "0"); // finish_flgは0で固定
            db.setString(21, DateUtil.currentDbDateStr());
            db.setString(22, "");
            db.setString(23, get(GUID));

			db.executeUpdate();
	
			// ORDER_INFOに登録
			sql = "INSERT INTO fxking.order_doc_kojin_info (order_id, user_id, auth_key, finish_flg, client_ip, mobile_flg, guid) "
				+	"VALUES (?,?,?,?,?,?,?)";
			
			db.prepareStatement(sql);
			db.setString(1, getRequestId());
			db.setString(2, getUserId());
			db.setString(3, " ");
			db.setString(4, "0");
            db.setString(5, getHttpRequest().getRemoteAddr());
            
            // モバイルの場合はMOBILE_FLGを1に設定する。
            if(this.getSiteId().equals(PC_SITE_ID)) {
                db.setString(6, "0");
            } else {
                db.setString(6, "1");
            }
            
			db.setString(7, get(GUID));
			
			db.executeUpdate();
			
		} catch(SQLException e){
			// 例外エラー
			log.error("UserDocKojinInfo,OrderDocKojinInfoの新規レコード作成時にエラーが発生しました。",e);
			throw e;
		
		} finally {
			;
		}	
		
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getSexId()
	 */
	public String getSexId() {
		return get(SEX_ID);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDate()
	 */
	public String getBirthDate() {
		return get(BIRTH_DATE);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthYear()
	 */
	public String getBirthYear() {
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(0,4);
		}
		return ret;
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthMonth()
	 */
	public String getBirthMonth() {
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(5,7);
		}
		return ret;
	}		
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDay()
	 */
	public String getBirthDay(){
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(8,10);
		}
		return ret;		
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getZip()
	 */
	public String getZip(){
		return get(ZIP);
	}


	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setZip(java.lang.String)
	 */
	public void setZip(String val){
		set(ZIP,val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setSexId(java.lang.String)
	 */
	public void setSexId(String val){
		set(SEX_ID,val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setBirthDate(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void setBirthDate(String year,String month,String day){
		set(BIRTH_DATE , year + "-" + month + "-" + day);
	}
	

	public boolean doIsDifferentFromMemberMst(MemberMst member){
		if (! get (NAME_KANJI_1).equals(member.get(MemberMst.NAME1)) ) return true;
		if (! get (NAME_KANJI_2).equals(member.get(MemberMst.NAME2)) ) return true;
		if (! get (NAME_KANA_1).equals(member.get(MemberMst.FURI1)) ) return true;
		if (! get (NAME_KANA_2).equals(member.get(MemberMst.FURI2)) ) return true;
		if (! get (ZIP).equals(member.get(MemberMst.ZIP)) ) return true;
		if (! get (PREF_ID).equals(member.get(MemberMst.PREF_ID)) ) return true;
		if (! get (ADDRESS_1).equals(member.get(MemberMst.ADDR1)) ) return true;
		if (! get (ADDRESS_2).equals(member.get(MemberMst.ADDR2)) ) return true;
		if (! get (ADDRESS_3).equals(member.get(MemberMst.ADDR3)) ) return true;
		if (! get (ADDRESS_4).equals(member.get(MemberMst.ADDR4)) ) return true;
		if (! get (ADDRESS_5).equals(member.get(MemberMst.ADDR5)) ) return true;
		if (! get (BIRTH_DATE).equals(DateUtil.toDbDateStr(member.get(MemberMst.BIRTHDAY))) ) return true;
		if (! get (SEX_ID).equals(member.get(MemberMst.SEX_ID)) ) return true;
		if (! get (TEL).equals(member.get(MemberMst.TEL)) ) return true;
        if (! get (MOBILE).equals(member.get(MemberMst.MOBILE)) ) return true;
		
		return false;
	}
	
	public void doPopulateFromMemberMst(MemberMst member){
		set (GUID , member.get(MemberMst.GUID));
		set (NAME_KANJI_1 , member.get(MemberMst.NAME1));
		set (NAME_KANJI_2 , member.get(MemberMst.NAME2));
		set (NAME_KANA_1 , member.get(MemberMst.FURI1));
		set (NAME_KANA_2 , member.get(MemberMst.FURI2));
		set (ZIP , member.get(MemberMst.ZIP));
		set (PREF_ID , member.get(MemberMst.PREF_ID));
		set (ADDRESS_1 , member.get(MemberMst.ADDR1));
		set (ADDRESS_2 , member.get(MemberMst.ADDR2));
		set (ADDRESS_3 , member.get(MemberMst.ADDR3));
		set (ADDRESS_4 , member.get(MemberMst.ADDR4));
		set (ADDRESS_5 , member.get(MemberMst.ADDR5));
		set (BIRTH_DATE, DateUtil.toDbDateStr(member.get(MemberMst.BIRTHDAY)));
		set (SEX_ID , member.get(MemberMst.SEX_ID));
		set (TEL , member.get(MemberMst.TEL));
        set (MOBILE , member.get(MemberMst.MOBILE));
        set (EMAIL , member.get(MemberMst.EMAIL));
	}

	public void doPopulateToMemberMst(MemberMst member){
		// メンバーオブジェクトを自動生成する時は、データを切り捨ててでも、なるべく生かす。
		// （文字数制限を自動的に行う）
		
		member.setTrimData(MemberMst.NAME1, get(NAME_KANJI_1));
		member.setTrimData(MemberMst.NAME2, get(NAME_KANJI_2));
		member.setTrimData(MemberMst.FURI1, get(NAME_KANA_1));
		member.setTrimData(MemberMst.FURI2, get(NAME_KANA_2));
		member.setTrimData(MemberMst.ZIP, get(ZIP));
		member.setTrimData(MemberMst.PREF_ID, get(PREF_ID));
		member.setTrimData(MemberMst.ADDR1, get(ADDRESS_1));
		member.setTrimData(MemberMst.ADDR2, get(ADDRESS_2));
		member.setTrimData(MemberMst.ADDR3, get(ADDRESS_3));
		member.setTrimData(MemberMst.ADDR4, get(ADDRESS_4));
		member.setTrimData(MemberMst.ADDR5, get(ADDRESS_5));
		member.setTrimData(MemberMst.BIRTHDAY, charBirthDate()); //YYYYMMDDに変換
		member.setTrimData(MemberMst.SEX_ID, get(SEX_ID));
		member.setTrimData(MemberMst.TEL, get(TEL));
        member.setTrimData(MemberMst.MOBILE, get(MOBILE));
	}

	
	private String charBirthDate(){
		return getBirthYear() + getBirthMonth() + getBirthDay();		
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToOrderHist(jp.co.webcrew.login.util.db.OrderHist)
	 */
	public void doPopulateToOrderHist(OrderHist order){
		order.setTrimData(OrderHist.ORDER_DATETIME,DateUtil.currentDateTime()); //発注日
		order.setTrimData(OrderHist.ORDER_TYPE, OrderHist.TYPE_SHIRYO_SEIKYU); //資料請求に固定
		order.setTrimData(OrderHist.SITE_ID, getSiteId());
		order.setTrimData(OrderHist.ORDER_ID, getRequestId());

		//DBAccess db;
		try{
			//db = new DBAccess();

			// ORDER_TEXT
            if (this.getSiteId().equals(PC_SITE_ID)) {
                order.setTrimData(OrderHist.ORDER_TEXT, ORDER_TEXT_CAPTION_PC);                
            } else {
                order.setTrimData(OrderHist.ORDER_TEXT, ORDER_TEXT_CAPTION_MBL);                
            }

            /*
			// SUPPLIER_TEXT
			StringBuffer sqlbuf = new StringBuffer("SELECT MST.NAME FROM ");
			sqlbuf.append("  FXKING.ORDER_COMPANY_INTER INTER, ");
			sqlbuf.append("  FXKING.COMPANY_MST MST ");
			sqlbuf.append("WHERE ");
			sqlbuf.append("  INTER.COMPANY_ID = MST.COMPANY_ID ");
			sqlbuf.append("AND ");
			sqlbuf.append("  INTER.ORDER_ID = ? ");
			
			db.prepareStatement(sqlbuf.toString());
			db.setString(1, getRequestId());
			db.executeQuery();
			List suppliers = Record.getResultListOf(db);
			StringBuffer supplier_text = new StringBuffer("");
			for (int i = 0 ; i < suppliers.size() ; i++) {
				Record supinfo = (Record)suppliers.get(i);
				if (i != 0) {
					supplier_text.append(",");
				}
				supplier_text.append(supinfo.getString("NAME"));
			}*/
			order.setTrimData(OrderHist.SUPPLIER_TEXT, "FXKING DOC REQ KOJIN"); 
			
		} catch (Exception e) {
			log.error("",e);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doDeleteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public void doDeleteGuid(DBAccess db , String guid) throws SQLException{
		DBUpdater updater = new DBUpdater("FXKING.ORDER_DOC_KOJIN_INFO");
		updater.addString("GUID","");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		updater.update(db);

		updater = new DBUpdater("FXKING.USER_DOC_KOJIN_INFO");
		updater.addString(GUID, "");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		updater.update(db);

	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getPrefId()
	 */
	public String getPrefId(){
		return get(PREF_ID);
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setPrefId(java.lang.String)
	 */
	public void setPrefId(String val){
		set (PREF_ID , val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getUserId()
	 */
	public String getUserId(){
		return get(USER_ID);
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setUserId(java.lang.String)
	 */
	public void setUserId(String val) {
		set(USER_ID , val);
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doOverWriteGuid(java.lang.String)
	 */
	public boolean doOverWriteGuid(DBAccess db , String guid)  {
        log.info ("ステップのデータベースに対し、guidの上書き処理を開始します。");
        
        // 入力チェック
            
            // GUIDが不正ならエラー
            if (! SessionFilterAlterUtil.isValidGuid(guid)){
                log.error("GUIDが不正です。");
                return false;
            }

            // ORDER_IDが不正ならエラー
            String orderId = ValueUtil.nullToStr(getRequestId());
            if (orderId.equals("")) {
                log.error("ORDER_IDが不正です。");
                return false;
            }

            // USER_IDが不正ならエラー
            String userId = ValueUtil.nullToStr(getUserId());
            if (userId.equals("")) {
                log.error("USER_IDが不正です。");
                return false;
            }

        // 更新
            
            try {
                // ORDER_INFOのGUIDを更新する
                String sql = "UPDATE " + getSchema() + ".ORDER_DOC_KOJIN_INFO SET GUID = ? ";
                sql += "WHERE ORDER_ID = ? ";
                db.prepareStatement(sql);
                db.setString(1, guid);
                db.setString(2, orderId);
                db.executeUpdate();

                sql = "UPDATE " + getSchema() + ".USER_DOC_KOJIN_INFO SET GUID = ? ";
                sql += "WHERE USER_ID = ? ";
                db.prepareStatement(sql);
                db.setString(1, guid);
                db.setString(2, getUserId());
                db.executeUpdate();
                
                log.info("GUIDの上書き処理が完了しました。");
                return true;
            
            } catch (Exception e) {

                log.error("guid上書き処理中に例外エラーが発生しました。" , e);
                return false;
            }
	    
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getLastUpdateTime()
	 */
	public String getLastUpdate() {
		String ret = get(LAST_UPDATE);
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(0,4) + ret.substring(5,7) + ret.substring(8,10);
		}
		
		return ret;
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getMagFlag()
	 */
	public String getMagFlag() {
		String mag_flag = get(PERMIT_WC_FLG);
		
		if (mag_flag == null) {
			return "" ;
		}
		if (mag_flag.equals("0")) {
			return "0";
		}
		if (mag_flag.equals("1")) {
			return "1";
		}

		return "";
		
	}
    
    /* (non-Javadoc)
     * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#getOrderIDs(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
     */
    public String[] getOrderIDs(DBAccess db, String guid) {
        
        //テーブル名がスーパークラスで実装されているものと異なるので、オーバーライドする。
        String sql = "SELECT ORDER_ID , USER_ID FROM " + getSchema() + ".ORDER_DOC_KOJIN_INFO WHERE GUID=? ORDER BY LAST_UPDATE DESC";
        try {
            db.prepareStatement(sql);
            db.setString(1, guid);
            Record rec = Record.getFirstRowOf(db);
            
            if (rec == null) {
                return null;
            } else {
                String[] ret = { rec.getString("ORDER_ID") , rec.getString("USER_ID") };
                return ret;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            log.info("ORDER_ID取得中に例外エラーが発生しました。");
            
            return null;
        }
    }
}
