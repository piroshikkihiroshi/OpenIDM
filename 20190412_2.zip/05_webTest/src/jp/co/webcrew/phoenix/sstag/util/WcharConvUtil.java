package jp.co.webcrew.phoenix.sstag.util;

import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * 半角/全角を変換するutilクラス。
 * 
 * @author kurinami
 */
public class WcharConvUtil {

    /** 半角から全角への対応マップ */
    private static Map<String, String> toWideMap = new HashMap<String, String>();

    /** 半角2文字から全角への対応マップ */
    private static Map<String, String> toWideMap2Chr = new HashMap<String, String>();

    /** 全角文字から半角文字への対応マップ */
    private static Map<String, String> toNarrowMap = new HashMap<String, String>();

    static {
        String[][] stdPairs = { { " ", "　" }, { "!", "！" }, { "\"", "”" }, { "#", "＃" }, { "$", "＄" }, { "%", "％" },
                { "&", "＆" }, { "'", "’" }, { "(", "（" }, { ")", "）" }, { "*", "＊" }, { "+", "＋" }, { ",", "，" },
                { "-", "－" }, { ".", "．" }, { "/", "／" }, { "0", "０" }, { "1", "１" }, { "2", "２" }, { "3", "３" },
                { "4", "４" }, { "5", "５" }, { "6", "６" }, { "7", "７" }, { "8", "８" }, { "9", "９" }, { ":", "：" },
                { ";", "；" }, { "<", "＜" }, { "=", "＝" }, { ">", "＞" }, { "?", "？" }, { "@", "＠" }, { "A", "Ａ" },
                { "B", "Ｂ" }, { "C", "Ｃ" }, { "D", "Ｄ" }, { "E", "Ｅ" }, { "F", "Ｆ" }, { "G", "Ｇ" }, { "H", "Ｈ" },
                { "I", "Ｉ" }, { "J", "Ｊ" }, { "K", "Ｋ" }, { "L", "Ｌ" }, { "M", "Ｍ" }, { "N", "Ｎ" }, { "O", "Ｏ" },
                { "P", "Ｐ" }, { "Q", "Ｑ" }, { "R", "Ｒ" }, { "S", "Ｓ" }, { "T", "Ｔ" }, { "U", "Ｕ" }, { "V", "Ｖ" },
                { "W", "Ｗ" }, { "X", "Ｘ" }, { "Y", "Ｙ" }, { "Z", "Ｚ" }, { "[", "［" }, { "\\", "￥" }, { "]", "］" },
                { "^", "＾" }, { "_", "＿" }, { "`", "‘" }, { "a", "ａ" }, { "b", "ｂ" }, { "c", "ｃ" }, { "d", "ｄ" },
                { "e", "ｅ" }, { "f", "ｆ" }, { "g", "ｇ" }, { "h", "ｈ" }, { "i", "ｉ" }, { "j", "ｊ" }, { "k", "ｋ" },
                { "l", "ｌ" }, { "m", "ｍ" }, { "n", "ｎ" }, { "o", "ｏ" }, { "p", "ｐ" }, { "q", "ｑ" }, { "r", "ｒ" },
                { "s", "ｓ" }, { "t", "ｔ" }, { "u", "ｕ" }, { "v", "ｖ" }, { "w", "ｗ" }, { "x", "ｘ" }, { "y", "ｙ" },
                { "z", "ｚ" }, { "{", "｛" }, { "|", "｜" }, { "}", "｝" }, { "~", "～" }, { "｡", "。" }, { "｢", "「" },
                { "｣", "」" }, { "､", "、" }, { "･", "・" }, { "ｦ", "ヲ" }, { "ｧ", "ァ" }, { "ｨ", "ィ" }, { "ｩ", "ゥ" },
                { "ｪ", "ェ" }, { "ｫ", "ォ" }, { "ｬ", "ャ" }, { "ｭ", "ュ" }, { "ｮ", "ョ" }, { "ｯ", "ッ" }, { "ｰ", "ー" },
                { "ｱ", "ア" }, { "ｲ", "イ" }, { "ｳ", "ウ" }, { "ｴ", "エ" }, { "ｵ", "オ" }, { "ｶ", "カ" }, { "ｷ", "キ" },
                { "ｸ", "ク" }, { "ｹ", "ケ" }, { "ｺ", "コ" }, { "ｻ", "サ" }, { "ｼ", "シ" }, { "ｽ", "ス" }, { "ｾ", "セ" },
                { "ｿ", "ソ" }, { "ﾀ", "タ" }, { "ﾁ", "チ" }, { "ﾂ", "ツ" }, { "ﾃ", "テ" }, { "ﾄ", "ト" }, { "ﾅ", "ナ" },
                { "ﾆ", "ニ" }, { "ﾇ", "ヌ" }, { "ﾈ", "ネ" }, { "ﾉ", "ノ" }, { "ﾊ", "ハ" }, { "ﾋ", "ヒ" }, { "ﾌ", "フ" },
                { "ﾍ", "ヘ" }, { "ﾎ", "ホ" }, { "ﾏ", "マ" }, { "ﾐ", "ミ" }, { "ﾑ", "ム" }, { "ﾒ", "メ" }, { "ﾓ", "モ" },
                { "ﾔ", "ヤ" }, { "ﾕ", "ユ" }, { "ﾖ", "ヨ" }, { "ﾗ", "ラ" }, { "ﾘ", "リ" }, { "ﾙ", "ル" }, { "ﾚ", "レ" },
                { "ﾛ", "ロ" }, { "ﾜ", "ワ" }, { "ﾝ", "ン" }, { "ﾞ", "゛" }, { "ﾟ", "゜" }, };
        String[][] othPairs = { { "ｶﾞ", "ガ" }, { "ｷﾞ", "ギ" }, { "ｸﾞ", "グ" }, { "ｹﾞ", "ゲ" }, { "ｺﾞ", "ゴ" },
                { "ｻﾞ", "ザ" }, { "ｼﾞ", "ジ" }, { "ｽﾞ", "ズ" }, { "ｾﾞ", "ゼ" }, { "ｿﾞ", "ゾ" }, { "ﾀﾞ", "ダ" },
                { "ﾁﾞ", "ヂ" }, { "ﾂﾞ", "ヅ" }, { "ﾃﾞ", "デ" }, { "ﾄﾞ", "ド" }, { "ﾊﾞ", "バ" }, { "ﾋﾞ", "ビ" },
                { "ﾌﾞ", "ブ" }, { "ﾍﾞ", "ベ" }, { "ﾎﾞ", "ボ" }, { "ﾊﾟ", "パ" }, { "ﾋﾟ", "ピ" }, { "ﾌﾟ", "プ" },
                { "ﾍﾟ", "ペ" }, { "ﾎﾟ", "ポ" }, };

        for (String[] pair : stdPairs) {
            toWideMap.put(pair[0], pair[1]);
            toNarrowMap.put(pair[1], pair[0]);
        }

        for (String[] pair : othPairs) {
            toWideMap2Chr.put(pair[0], pair[1]);
            toNarrowMap.put(pair[1], pair[0]);
        }

    }

    /**
     * 文字列配列の半角文字を全角文字に変換する。
     * 
     * @param source
     * @return
     */
    public static String[] toWide(String[] source) {
        if (PhoenixUtil.isEmpty(source)) {
            return source;
        }
        String[] result = new String[source.length];
        for (int i = 0; i < source.length; i++) {
            result[i] = toWide(source[i]);
        }
        return result;
    }

    /**
     * 文字列の半角文字を全角文字に変換する。
     * 
     * @param source
     * @return
     */
    public static String toWide(String source) {
        if (PhoenixUtil.isEmpty(source)) {
            return "";
        }

        StringBuffer sb = new StringBuffer();

        int index = 0;
        while (index < source.length()) {
            String key = null;
            String res = null;
            if (index < source.length() - 1) {
                key = source.substring(index, index + 2);
                res = toWideMap2Chr.get(key);
            }
            if (res == null) {
                key = source.substring(index, index + 1);
                if (toWideMap.containsKey(key)) {
                    res = toWideMap.get(key);
                } else {
                    res = key;
                }
            }
            sb.append(res);
            index += key.length();
        }

        return sb.toString();
    }

    /**
     * 文字列配列の全角文字を半角文字に変換する。
     * 
     * @param source
     * @return
     */
    public static String[] toNarraw(String[] source) {
        if (PhoenixUtil.isEmpty(source)) {
            return source;
        }
        String[] result = new String[source.length];
        for (int i = 0; i < source.length; i++) {
            result[i] = toNarraw(source[i]);
        }
        return result;
    }

    /**
     * 文字列の全角文字を半角文字に変換する。
     * 
     * @param source
     * @return
     */
    public static String toNarraw(String source) {
        if (PhoenixUtil.isEmpty(source)) {
            return "";
        }

        StringBuffer sb = new StringBuffer();

        int index = 0;
        while (index < source.length()) {
            String key = null;
            String res = null;
            key = source.substring(index, index + 1);
            if (toNarrowMap.containsKey(key)) {
                res = toNarrowMap.get(key);
            } else {
                res = key;
            }
            sb.append(res);
            index += key.length();
        }

        return sb.toString();
    }

    public static void main(String[] args) {
        String[] source = { "ボクハ ｼﾞｬｲｱｰﾝ 1番! １０００番！ ｶﾞﾞ", "あいうえおかきくけこ",
                "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン", "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜｦﾝ",
                "１２３４５６７８９０ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ",
                "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "ガギグゲゴザジズゼゾダヂヅデドバビブベボパピプペポ",
                "ｶﾞｷﾞｸﾞｹﾞｺﾞｻﾞｼﾞｽﾞｾﾞｿﾞﾀﾞﾁﾞﾂﾞﾃﾞﾄﾞﾊﾞﾋﾞﾌﾞﾍﾞﾎﾞﾊﾟﾋﾟﾌﾟﾍﾟﾎﾟ", "！”＃＄％＆’（）－＾￥＝～｜＠［；：］‘｛＋＊｝，．／＜＞？＿",
                "!\"#$%&'()-^\\=~|@[;:]`{+*},./<>?_", };

        String[] wide = toWide(source);
        String[] narraw = toNarraw(source);

        for (int i = 0; i < source.length; i++) {
            System.out.println("orginal   : " + source[i]);
            System.out.println("to_wide   : " + wide[i]);
            System.out.println("to_narraw : " + narraw[i]);
        }
    }
}
