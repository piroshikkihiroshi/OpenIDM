﻿Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim strRet As String = getResponse()

        Me.TextBox1.Text = strRet


    End Sub


    Function getResponse() As String
        'HttpWebRequestを作成
        Dim webreq As System.Net.HttpWebRequest = _
            DirectCast(System.Net.WebRequest.Create("http://www.microsoft.com"),  _
                System.Net.HttpWebRequest)
        'または、
        'Dim webreq As System.Net.WebRequest = _
        '    System.Net.WebRequest.Create("http://www.microsoft.com")

        'サーバーからの応答を受信するためのHttpWebResponseを取得
        Dim webres As System.Net.HttpWebResponse = _
            DirectCast(webreq.GetResponse(), System.Net.HttpWebResponse)
        'または、
        'Dim webres As System.Net.WebResponse = webreq.GetResponse()


        '応答データを受信するためのStreamを取得
        Dim st As System.IO.Stream = webres.GetResponseStream()
        '文字コードを指定して、StreamReaderを作成
        Dim sr As New System.IO.StreamReader(st, System.Text.Encoding.UTF8)
        'データをすべて受信
        Dim htmlSource As String = sr.ReadToEnd()
        '閉じる
        sr.Close()
        st.Close()
        webres.Close()
        '「st.Close()」や「webres.Close()」だけでもよい

        '取得したソースを表示する
        'Console.WriteLine(htmlSource)

        getResponse = htmlSource



    End Function


    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class
