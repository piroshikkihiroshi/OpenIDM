package jp.co.webcrew.phoenix.logic.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * POST情報保持用
 * 
 * @author kurinami
 */
public class PostInfo implements Serializable {

    /** デフォルトシリアルバージョン */
    private static final long serialVersionUID = 1L;

    public Map<String, String[]> postItemMap = new HashMap<String, String[]>();
    public Map<String, PostFile[]> postFileMap = new HashMap<String, PostFile[]>();
}
