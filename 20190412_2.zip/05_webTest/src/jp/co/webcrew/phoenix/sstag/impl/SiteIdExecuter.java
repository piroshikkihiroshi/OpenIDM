package jp.co.webcrew.phoenix.sstag.impl;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * サイトID変更を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class SiteIdExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** ロガー */
    private static final Logger log = Logger.getLogger(SiteIdExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { SITE_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String siteId = ValueUtil.nullToStr(parameters.get(SITE_ID_PARAM_KEY));

            if (siteId.equalsIgnoreCase("default")) {
                // デフォルトに戻す。
                StoreUtil.removeSiteId(request);
            } else {
                // サイトIDを指定された値に置き換える。
                StoreUtil.setSiteId(request, ValueUtil.toint(siteId));
            }

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

}
