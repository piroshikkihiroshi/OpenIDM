package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.loader.util.LoadUtil;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.logic.db.FormDb;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * スクリーニングを行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class ScreeningExecuter extends SSTagExecuter {

    /** パラメータ名：スクリーニング結果(結果リスト)を保持するための一意なID */
    private static final String RESULT_ID_PARAM_KEY = "result_id";

    /** パラメータ名：バリデーション用の追加モジュール名 */
    private static final String LOGIC_PARAM_KEY = "logic";

    /** パラメータ名：バリデーション結果の順序指定 */
    private static final String RESULT_ORDER_PARAM_KEY = "result_order";

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：フォーム定義のID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：form定義カラムの中でスクリーニングやバリデーションを行うグループを指定 */
    private static final String GROUP_ID_PARAM_KEY = "group_id";

    /** パラメータ名：group_id外であってもスクリーニング、バリデーションを行う項目(カラム)を指定 */
    private static final String INCLUDE_PARAM_KEY = "include";

    /** パラメータ名：group_id内であってもスクリーニング、バリデーションを行わない項目名を指定 */
    private static final String EXCLUDE_PARAM_KEY = "exclude";

    /** パラメータ名：group_id/include/exclude を使用せず直接項目IDを指定する際に使用 */
    private static final String ITEM_ID_PARAM_KEY = "item_id";

    /** パラメータ名：結果保持期間 */
    private static final String LIFE_PARAM_KEY = "life";

    /** パラメータ名：スクリーニングの件数が全て０の場合にリダイレクトする場合の遷移先URL */
    private static final String ZERO_URL_PARAM_KEY = "zero_url";

    /** パラメータ名：スクリーニングの件数が１件でもある場合にリダイレクトする場合の遷移先URL */
    private static final String NO_ZERO_URL_PARAM_KEY = "not_zero_url";

    /** ロガー */
    private static final Logger log = Logger.getLogger(ScreeningExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { RESULT_ID_PARAM_KEY, LOGIC_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String resultId = ValueUtil.nullToStr(parameters.get(RESULT_ID_PARAM_KEY));
            String[] logic = PhoenixUtil.split((String) parameters.get(LOGIC_PARAM_KEY), " ");
            String resultOrder = ValueUtil.nullToStr(parameters.get(RESULT_ORDER_PARAM_KEY));
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String[] groupId = PhoenixUtil.split((String) parameters.get(GROUP_ID_PARAM_KEY), ",");
            String[] include = PhoenixUtil.split((String) parameters.get(INCLUDE_PARAM_KEY), ",");
            String[] exclude = PhoenixUtil.split((String) parameters.get(EXCLUDE_PARAM_KEY), ",");
            String[] itemId = PhoenixUtil.split((String) parameters.get(ITEM_ID_PARAM_KEY), ",");
            String life = ValueUtil.nullToStr(parameters.get(LIFE_PARAM_KEY));
            String zeroUrl = ValueUtil.nullToStr(parameters.get(ZERO_URL_PARAM_KEY));
            String notZeroUrl = ValueUtil.nullToStr(parameters.get(NO_ZERO_URL_PARAM_KEY));

            // フォーム項目一覧を取得する。
            FormInfo formInfo = FormDb.getFormInfo(siteId, formId);

            // セッションストアで保持しているフォームデータを取得する。
            PostInfo postInfo = StoreUtil.getPostInfo(request);

            // form内で使用するグループと項目
            FormUseInfo formUseInfo = new FormUseInfo(groupId, include, exclude, itemId);

            // 共通情報を取得する。
            SstagGlobalInfo sgInfo = SstagUtil.getSstagGlobalInfo(request);

            // 順序指定を取得する。
            SortRequest[] sortReq = SstagUtil.getSortRequest(resultOrder);

            // htmlを組み立てる。
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);

            // スクリーニングを行う。
            BindLogicExtStatus status = screen(request, parameters, sgInfo, formInfo, postInfo, formUseInfo, sortReq,
                    logic);
            if (!status.result) {
                status.writeLog(log);
                return onerror(request, response, parameters, status.errStatus, status.errMsg);
            }

            // 結果htmlを出力する。
            pw.println(ValueUtil.nullToStr(status.html));

            // スクリーニング結果をセッションストアに書き込む。
            StoreUtil.setScreeningResult(request, resultId, status.sResult, life);

            // 次回スクリーニング用に結果を保持しておく。
            StoreUtil.setLastSResult(request, status.sResult, life);
            StoreUtil.setLastAuxResult(request, status.auxResult, life);

            // スクリーニング結果を置換変数に登録する。
            SstagUtil.setScreeningResultReplaceParam(request, resultId, status.sResult);

            // スクリーニング結果によって、遷移が必要であれば、遷移する。
            if (PhoenixUtil.isEmpty(status.sResult)) {
                if (!PhoenixUtil.isEmpty(zeroUrl)) {
                    response.sendRedirect(zeroUrl);
                    return "";
                }
            } else {
                if (!PhoenixUtil.isEmpty(notZeroUrl)) {
                    response.sendRedirect(notZeroUrl);
                    return "";
                }
            }

            pw.flush();
            return sw.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * スクリーニングを行う。
     * 
     * @param request
     * @param sstagParam
     * @param sgInfo
     * @param formInfo
     * @param postInfo
     * @param formUseInfo
     * @param sortReq
     * @param logic
     * @return
     * @throws Exception
     */
    private BindLogicExtStatus screen(HttpServletRequest request, Map<String, String> sstagParam,
            SstagGlobalInfo sgInfo, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
            SortRequest[] sortReq, String[] logic) throws Exception {
        SstagDynamicLogic logicClass = (SstagDynamicLogic) LoadUtil.newInstanceFromId(request, logic[0]);

        List<String> userParam = Arrays.asList(logic);

        Map<String, Map<String, Object[]>> sResult = StoreUtil.getLastSResult(request);
        Map<String, Object[]> auxResult = StoreUtil.getLastAuxResult(request);

        return logicClass.validationLogic(sgInfo, sstagParam, userParam, formInfo, postInfo, formUseInfo, sortReq,
                null, sResult, auxResult, false, true);
    }

}
