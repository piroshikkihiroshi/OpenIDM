package jp.co.webcrew.filters.filters.replace.replacer;

import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.filters.replace.htmlparser.SSTagReplaceParser;
import jp.co.webcrew.filters.filters.replace.htmlparser.SSTagReplaceParserCallback;
import jp.co.webcrew.loader.util.LoadUtil;

/**
 * サーバサイドタグを処理するReplacerクラス。
 * 
 * @author kurinami
 */
public class SSTagReplacer extends Replacer {

    /** ロガー */
    private static final Logger log = Logger.getLogger(SSTagReplacer.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.replacer.Replacer#init(javax.servlet
     * .FilterConfig)
     */
    public void init(FilterConfig filterConfig) throws ServletException {

        log.debug("init start.");

        // 動的クラスローダーを初期化する。
        LoadUtil.init(filterConfig.getServletContext());

        log.debug("init end.");
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.Replacer#replace(java.lang.String,
     * javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    public String replace(String source, HttpServletRequest request, HttpServletResponse response) {

        log.debug("replace start.");

        SSTagReplaceParserCallback cb = new SSTagReplaceParserCallback(request, response);
        String result = SSTagReplaceParser.parse(source, cb);

        log.debug("replace end.");
        return result;
    }

}
