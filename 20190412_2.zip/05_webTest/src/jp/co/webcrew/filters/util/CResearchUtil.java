package jp.co.webcrew.filters.util;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class CResearchUtil {
  private Properties config = null;
  
  /** 投票状態 */
  public static final String VOTE_ACCEPT = "0";
  public static final String VOTE_END    = "1";
  public static final String VOTE_BEFORE = "2";
  
  /** カテゴリ */
  public static final String CATEGORY_ALL = "";
  
  /** NEWマーク表示期間中を表すフラグ */
  public static final String IS_NEW = "1";
  
  /** 掲載期間 */
  private static final String RANGE_TYPE_NOW   = "";
  private static final String RANGE_TYPE_START = "start";
  private static final String RANGE_TYPE_END   = "end";
  
  //--------------------------------------------------------------------------------
  // ↓↓↓ コンストラクタ ↓↓↓
  /**
   * コンストラクタ
   * 
   * @param config
   */
  public CResearchUtil(Properties config) {
    this.config = config;
  }
  
  /**
   * コンストラクタ
   *
   */
  public CResearchUtil() {
    //何もしない
  }
  // ↑↑↑ コンストラクタ ↑↑↑
  //--------------------------------------------------------------------------------
  
  //--------------------------------------------------------------------------------
  // ↓↓↓ アンケート情報をリストに保存するためのメソッド ↓↓↓
  /**
   * 
   * @param tempMap アンケート情報をマップ形式で保持している値
   */
  public static List createEnquetesList(Map tempMap) {
    List allEnquetesList = new ArrayList();
    
    Iterator iterator = tempMap.keySet().iterator();
    
    while(iterator.hasNext()) {
      String key = (String)iterator.next();
      allEnquetesList.add((HashMap)tempMap.get(key));
    }
    
    return allEnquetesList;
  }
  //↑↑↑ アンケート情報をリストに保存するためのメソッド ↑↑↑
  //--------------------------------------------------------------------------------
  
  //--------------------------------------------------------------------------------
  // ↓↓↓ 時間関係のメソッド ↓↓↓
  /**
   * 現在時刻をYYYY/MM/DD HH24:MI形式で生成する
   * 
   */
  public static String createNowDate() {
  Calendar cal = Calendar.getInstance();
    
    int year   = cal.get(Calendar.YEAR);
    int month  = cal.get(Calendar.MONTH) + 1;
    int day    = cal.get(Calendar.DAY_OF_MONTH);
    int hour   = cal.get(Calendar.HOUR_OF_DAY);
    int minute = cal.get(Calendar.MINUTE);
      
    NumberFormat nf = new DecimalFormat("00");
      
    return year + "/" + nf.format(month) + "/" + nf.format(day) + " " + nf.format(hour) + ":" + nf.format(minute);
  }
  
  /**
   * NEWマーク表示期間中の判定を行う
   * 
   * @param startDate
   * @param endDate
   * @param nowDate
   * @return
   */
  public static String isNew(String startDate, String endDate, String nowDate) {
    
    if(isAcceptance(startDate, endDate, nowDate).equals(VOTE_ACCEPT) == true) {
      return IS_NEW; //NEWマーク表示期間中
    }
    
    return "";
  }
  
  /**
   * アンケートが受付期間中かどうか確認する
   * 
   * @param startdDate
   * @param endDate
   * @param nowDate
   * @return
   */
  public static String isAcceptance(String startDate, String endDate, String nowDate) {
    
    if(startDate.equals("") == true || endDate.equals("") == true || nowDate.equals("") == true) {
      return VOTE_BEFORE; //投票期間前(or 日付指定がないため表示しない)
    }
    
    //開始年月日と現在の年月日を比較する
    Calendar now   = getCalendar(nowDate, RANGE_TYPE_NOW);
    Calendar start = getCalendar(startDate, RANGE_TYPE_START);
    
    long lNow = now.getTimeInMillis();
    long lStart = start.getTimeInMillis();
    //if(now.compareTo(start) < 0) {
    if(lNow < lStart) {
      return VOTE_BEFORE; //投票期間前(or 日付指定がないため表示しない)
    }
    
    //終了年月日と現在の年月日を比較する
    Calendar end = getCalendar(endDate, RANGE_TYPE_END);
    long lEnd = end.getTimeInMillis();
    //if(end.compareTo(now) < 0) {
    if(lEnd < lNow) {
      return VOTE_END; //投票期間終了
    }
    
    return VOTE_ACCEPT; //投票受付中
  }
  
  /**
   * 引数で指定した日時をCalendarオブジェクトで返す
   * 
   * @param date
   * @return
   */
  private static Calendar getCalendar(String date, String rangeType) {
    Calendar cal = Calendar.getInstance();
    
    int year   = cal.get(Calendar.YEAR);
    int month  = cal.get(Calendar.MONTH) + 1;
    int day    = cal.get(Calendar.DAY_OF_MONTH);
    int hour   = cal.get(Calendar.HOUR_OF_DAY);
    int minute = cal.get(Calendar.MINUTE);
    
    if(date.matches("^[0-9]{4}[/]{1}[0-9]{2}[/]{1}[0-9]{2}[ ]{1}[0-9]{2}[:]{1}[0-9]{2}$") == true) {
      //「YYYY/MM/DD HH24:MI」形式の場合
      year   = Integer.parseInt(date.substring(0, 4));
      month  = Integer.parseInt(date.substring(5, 7));
      day    = Integer.parseInt(date.substring(8, 10));
      hour   = Integer.parseInt(date.substring(11, 13));
      minute = Integer.parseInt(date.substring(14, 16));
    } else if(date.matches("^[0-9]{4}[/]{1}[0-9]{2}[/]{1}[0-9]{2}$") == true) {
      //「YYYY/MM/DD」形式の場合
      year   = Integer.parseInt(date.substring(0, 4));
      month  = Integer.parseInt(date.substring(5, 7));
      day    = Integer.parseInt(date.substring(8, 10));
      if(RANGE_TYPE_START.equals(rangeType) == true) {
        hour   = 0;
        minute = 0;
      } else if(RANGE_TYPE_END.equals(rangeType) == true) {
        hour   = 23;
        minute = 59;
      } else {
        hour   = 0;
        minute = 0;
      }
    } else {
      
    }
    
    cal.set(year, month - 1, day, hour, minute, 0);

    return cal;
  }
  
  /**
   * 引数に指定したvalueが文字列の日付形式かどうかを確認する
   * 引数が「YYYY/MM/DD HH24:MI」 or 「YYYY/MM/DD」形式の場合はtrue、それ以外はfalseを返す
   * 
   * @param value
   * @return
   */
  private boolean isDate(Object value) {
    if(value.getClass().equals(String.class) == true) {
      
      String date = (String)value;
      
      if(date.matches("^[0-9]{4}[/]{1}[0-9]{2}[/]{1}[0-9]{2}[ ]{1}[0-9]{2}[:]{1}[0-9]{2}$") == true) {
        return true;
      } else if(date.matches("^[0-9]{4}[/]{1}[0-9]{2}[/]{1}[0-9]{2}$") == true) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
  // ↑↑↑ 時間関係のメソッド ↑↑↑
  //--------------------------------------------------------------------------------
    
  //--------------------------------------------------------------------------------
  // ↓↓↓ アンケートデータを操作するためのメソッド ↓↓↓
  /**
   * アンケートXMLから指定したenqueteNoのアンケートを取得する
   * 
   * @param allEnquetesList
   * @param enqueteNo
   * @return
   * @throws Exception
   */
  public static Map getEnquete(List allEnquetesList, String enqueteNo) throws Exception {
    
    for(int i = 0; i < allEnquetesList.size(); i++) {
      Map enqueteMap = (HashMap)allEnquetesList.get(i);
      
      int no = ((Integer)enqueteMap.get("id")).intValue();
      if(no == Integer.parseInt(enqueteNo)) {
        return enqueteMap;
      }
    }
    
    return null;
  }
  
  /**
   * 投票件数をアンケートリストに保存する
   * 
   * @param voteMap
   * @param allEnquetesList
   */
  public void setVoteCount(Map voteMap, List allEnquetesList) {
    for(int i = 0; i < allEnquetesList.size(); i++) {
      Map enqueteMap = (HashMap)allEnquetesList.get(i);
      
      //アンケート番号取得
      int id = ((Integer)enqueteMap.get("id")).intValue();
      
      //取得したアンケート番号と一致する投票件数を取得
      String count = (voteMap.get(String.valueOf(id)) == null) ? "0" : (String)voteMap.get(String.valueOf(id));
      
      //マップに詰めなおし
      enqueteMap.put("voteCount", new Integer(count));
      
      //リストに詰め直し
      allEnquetesList.set(i, enqueteMap);
    }
  }
  
  /**
   * voteCountingMapには、投票件数が1件以上ある項目の項目番号と件数しか保持していないため、
   * 投票件数が0の項目番号と件数をvoteCoungingMapに保持させる
   * 
   * @param voteCountingMap
   * @param enqueteMap
   */
  public void setOptionVoteCount(Map enqueteMap, Map voteCountingMap) {
    Map optionMap = (HashMap)enqueteMap.get("options");
    
    Iterator iterator = optionMap.keySet().iterator();
    while(iterator.hasNext()) {
      String optionNo = (String)iterator.next();
      
      if(voteCountingMap.get(optionNo) == null) {
        voteCountingMap.put(optionNo, "0");
      }
    }
  }
  
  /**
   * 投票受付中のデータを取得する
   * 
   * @param allEnquetesList
   * @throws Exception
   */
  public List getOnBallot(List allEnquetesList, String nowDate) throws Exception {
    
    List enquetesList = new ArrayList();
    
    for(int i = 0; i < allEnquetesList.size(); i++) {
      Map enquetesMap = (HashMap)allEnquetesList.get(i);
      
      String start = (enquetesMap.get("startDate") == null) ? "" : (String)enquetesMap.get("startDate");
      String end   = (enquetesMap.get("endDate")   == null) ? "" : (String)enquetesMap.get("endDate");
      
      String status = isAcceptance(start, end, nowDate);
      
      if(status.equals(VOTE_ACCEPT) == true) {
        //受付中データなので表示する
        enquetesList.add(enquetesMap);
      } else {
        //受付中以外のデータなので表示しない
      }
    }
    
    return enquetesList;
  }
  
  /**
   * 指定カテゴリの過去データを取得する
   * 
   * @param allEnquetesList
   * @return
   */
  public List getBackwardData(List allEnquetesList, String categoryId, String nowDate) throws Exception {
   
    List enquetesList = new ArrayList();
    
    for(int i = 0; i < allEnquetesList.size(); i++) {
      Map enquetesMap = (HashMap)allEnquetesList.get(i);
      
      String start = (enquetesMap.get("startDate") == null) ? "" : (String)enquetesMap.get("startDate");
      String end   = (enquetesMap.get("endDate")   == null) ? "" : (String)enquetesMap.get("endDate");
      
      String status = isAcceptance(start, end, nowDate);
      String cid    = String.valueOf(enquetesMap.get("categoryId"));
      
      //過去データ以外を削除する
      if(status.equals(VOTE_END) == true) {
        if(CATEGORY_ALL.equals(categoryId)) {
          //カテゴリの指定がないので表示
          enquetesList.add(enquetesMap);
        } else if(cid.equals(categoryId) == false) {
          //指定したカテゴリと異なるので表示しない
        } else {
          //指定したカテゴリなので表示する
          enquetesList.add(enquetesMap);
        }
      } else {
        //過去データではないので表示しない
      }
    }
    
    return enquetesList;
  }
  
  /**
   * 指定したpageNoに表示するアンケートを、configで設定された件数(show_page_max)だけリスト形式で返す
   * pageNoは1以上の値を設定する
   * 
   * @param allEnquetesList
   * @param pageNo
   * @return
   */
  public List create(List allEnquetesList, int pageNo) throws Exception {
    List enquetesList = new ArrayList();
    
    if(allEnquetesList.size() == 0) {
      return enquetesList;
    }
    
    int pageMax = 0;
    if(config.get("show_page_max") != null) {
      pageMax = Math.min(Integer.parseInt((String)config.get("show_page_max")), allEnquetesList.size());
      
      int max = 0;
      if(config.get("show_max") != null) {
        max = Math.min(Integer.parseInt((String)config.get("show_max")), allEnquetesList.size());
      } else {
        max = allEnquetesList.size();
      }
      
      pageMax = Math.min(pageMax, max);
    }
    
    if(pageNo < 1) {
      return enquetesList;
    }
    
    int startIndex = pageMax * (pageNo - 1);
    int endIndex   = startIndex + (pageMax - 1);
    if(allEnquetesList.size() < (endIndex + 1)) {
      endIndex = allEnquetesList.size() - 1;
    }
    
    for(int i = startIndex; i <= endIndex; i++) {
      enquetesList.add(allEnquetesList.get(i));
    }
    
    return enquetesList;
  }
  
  /**
   * configで設定された件数分のアンケートをリスト形式で返す
   * 
   * @param allEnquetesList
   * @return
   */
  public List create(List allEnquetesList) throws Exception {
    List enquetesList = new ArrayList();
    
    if(config.get("show_max") != null) {
      int max = Math.min(Integer.parseInt((String)config.get("show_max")), allEnquetesList.size());
      
      for(int i = 0; i < max; i++) {
        enquetesList.add(i, allEnquetesList.get(i));
      }
    } else {
      enquetesList.addAll(allEnquetesList);
    }
    
    return enquetesList; 
  }
  // ↑↑↑ アンケートデータを操作するためのメソッド ↑↑↑
  //--------------------------------------------------------------------------------
  
  //--------------------------------------------------------------------------------
  // ↓↓↓ アンケートデータを並び替えるためのメソッド ↓↓↓
  /**
   * アンケート項目を並び替える
   * 
   * @param enquetes
   */
  public void sort(List enquetes) {
    
    Collections.sort(enquetes, new Comparator() {
      public int compare(Object objBeforeMap, Object objAfterMap) {
        
        int sortResult = -1;
        
        String sortKeys = config.getProperty("sort");
        String[] sortKey = sortKeys.split(",");
        
        Map beforeMap = (HashMap)objBeforeMap;
        Map afterMap = (HashMap)objAfterMap;
        if(sortKey.length > 0) {
          //1つ目のソートキーを取得する
          String[] key = sortKey[0].split("#");
          
          //並び替えの対象となる値を取得
          Object beforeValue = (beforeMap.get(key[0]) == null) ? null : beforeMap.get(key[0]);
          Object afterValue  = (afterMap.get(key[0])  == null) ? null : afterMap.get(key[0]);
          
          if(beforeValue == null || afterValue == null) {
            return -1;
          }
          
          //並び順を取得する
          String order = getSortOrder(key);
          
          //１つ目のソートキーで並び替える
          sortResult = compareValue(order, beforeValue, afterValue);
          
          //戻り値が0だったら、１つ目のソートキーの値は前後で同じなので、２つ目以降のソートキーで並び替え
          if(sortResult == 0) {
            for(int i = 1; i < sortKey.length; i++) {
              //２つ目以降のソートキーを取得する
              key = sortKey[i].split("#");
              
              //並び替えの対象となる値を取得
              beforeValue = (beforeMap.get(key[0]) == null) ? null : beforeMap.get(key[0]);
              afterValue  = (afterMap.get(key[0])  == null) ? null : afterMap.get(key[0]);
              if(beforeValue == null || afterValue == null) {
                return -1;
              }
              
              //並び順を取得する
              order = getSortOrder(key);
              
              //２つ目以降のソートキーで並び替える
              sortResult = compareValue(order, beforeValue, afterValue);
              
              if(sortResult != 0) {
                return sortResult;
              }
            }
          }
        }
        
        return sortResult;
      }
    });
  }
  
  /**
   * 並び順（昇順 or 降順）を取得する
   * 
   * @param key
   * @return
   */
  private String getSortOrder(String[] key) {
    String order = "DESC";
    if(key.length == 2) {
      order = key[1];
    }
   
    return order;
  }
 
  /**
   * 比較を行う
   * 
   * @param order
   * @param beforeValue
   * @param afterValue
   * @return
   */
  private int compareValue(String order, Object beforeValue, Object afterValue) {
    int sortResult = 0;
   
    if(order.equals("ASC")) {
      sortResult = compareValueAsc(beforeValue, afterValue);
    } else {
      sortResult = compareValueDesc(beforeValue, afterValue);
    }
   
    return sortResult;
  }
 
  /**
   * 比較（昇順用）を行う
   * 
   * @param before
   * @param after
   * @return
   */
  private int compareValueAsc(Object before, Object after) {
    if(before.getClass().equals(after.getClass()) == false) {
      return 1;
    }
   
    if(isDate(before) == true && isDate(after) == true) {
      Calendar beforeDate = getCalendar((String)before, RANGE_TYPE_NOW);
      Calendar afterDate  = getCalendar((String)after, RANGE_TYPE_NOW);
      
      long lBeforeDate = beforeDate.getTimeInMillis();
      long lAfterDate = afterDate.getTimeInMillis();
      //if(beforeDate.compareTo(afterDate) > 0) {
      if(lBeforeDate > lAfterDate) {
        return 1;
      //} else if(beforeDate.compareTo(afterDate) < 0) {
      } else if(lBeforeDate < lAfterDate) {
        return -1;
      } else {
        return 0;
      }
    } else if(before.getClass().equals(Integer.class) == true) {
      int beforeValue = ((Integer)before).intValue();
      int afterValue  = ((Integer)after).intValue();
     
      if(beforeValue > afterValue) {
        return 1;
      } else if(beforeValue < afterValue){
        return -1;
      } else {
        return 0;
      }
    } else if(before.getClass().equals(String.class) == true) {
      String beforeValue = (String)before;
      String afterValue  = (String)after;
      
      if(beforeValue.compareTo(afterValue) > 0) {
        return 1;
      } else if(beforeValue.compareTo(afterValue) < 0) {
        return -1;
      } else {
        return 0;
      }
    } else {
      return 1;
    }
  }
  
  /**
   * 比較（降順用）を行う
   * 
   * @param before
   * @param after
   * @return
   */
  private int compareValueDesc(Object before, Object after) {
    if(before.getClass().equals(after.getClass()) == false) {
      return 1;
    }
    
    if(before.getClass().equals(Integer.class) == true) {
      int beforeValue = ((Integer)before).intValue();
      int afterValue  = ((Integer)after).intValue();
      
      if(beforeValue > afterValue) {
        return -1;
      } else if(beforeValue < afterValue){
        return 1;
      } else {
        return 0;
      }
    } else if(before.getClass().equals(Long.class) == true) {
      long beforeValue = ((Long)before).longValue();
      long afterValue  = ((Long)after).longValue();
      
      if(beforeValue > afterValue) {
        return -1;
      } else if(beforeValue < afterValue) {
        return 1;
      } else {
        return 0;
      }
    } else if(before.getClass().equals(String.class) == true) {
      String beforeValue = (String)before;
      String afterValue  = (String)after;
      
      if(beforeValue.compareTo(afterValue) > 0) {
        return -1;
      } else if(beforeValue.compareTo(afterValue) < 0) {
        return 1;
      } else {
        return 0;
      }
    } else {
      return 1;
    }
  }
  // ↑↑↑ アンケートデータを並び替えるためのメソッド ↑↑↑
  //--------------------------------------------------------------------------------
}
