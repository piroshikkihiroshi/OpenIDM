package jp.co.webcrew.phoenix.logic.bean;

/**
 * form内で使用するグループと項目
 * 
 * @author kurinami
 */
public class FormUseInfo {
    public String[] groupId; /* 使用するグループIDの配列 */
    public String[] includeItemId; /* 追加使用する項目IDの配列 */
    public String[] excludeItemId; /* グループ内で使用しない項目IDの配列 */
    public String[] itemId; /* 項目ID(item_id)が直接指定された場合の項目IDの配列 */

    /**
     * コンストラクタ
     * 
     * @param groupId
     * @param includeItemId
     * @param excludeItemId
     * @param itemId
     */
    public FormUseInfo(String[] groupId, String[] includeItemId, String[] excludeItemId, String[] itemId) {
        this.groupId = groupId;
        this.includeItemId = includeItemId;
        this.excludeItemId = excludeItemId;
        this.itemId = itemId;
    }
}
