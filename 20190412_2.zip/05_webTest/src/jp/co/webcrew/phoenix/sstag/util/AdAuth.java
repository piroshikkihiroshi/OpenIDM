package jp.co.webcrew.phoenix.sstag.util;

//===========================================================================
//
//         AD 認証 (Kerberos via JAAS認証)
//
// 注意
//   realm は大文字、小文字を別物として扱うので Windows の時は大文字にすること
//   kdc は本プログラムを実行するマシンから使用可能な名前（ホスト名）
//       なので、必ずしもフルではない(要は見つかればOK）
//   jaas.confはパスの通るところに置く。

import java.net.URL;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

/**
 * AD認証用クラス。
 * 
 * @author kurinami
 */
public class AdAuth {

    /**
     * ADサーバでの認証処理を行う。
     * 
     * @param user
     *            ログインユーザ名
     * @param password
     *            パスワード
     * @param domain
     *            ドメイン名 例. AD.USO.JP
     * @param server
     *            認証サーバ (ホスト名 or IP )
     * @return
     * @throws LoginException
     */
    public static boolean auth(String user, String password, String domain, String server) throws LoginException {

        URL url = AdAuth.class.getResource("/jaas.conf");
        if(url == null) {
            throw new LoginException("設定ファイル【jaas.conf】が読み込めません。");
        }
        
        System.setProperty("java.security.auth.login.config", url.getPath());
        System.setProperty("java.security.krb5.kdc", server);
        System.setProperty("java.security.krb5.realm", domain.toUpperCase());

        LoginContext lc = new LoginContext("JaasAuth", new LoginCallbackHandler(user, password));

        // 認証実行
        try {
            lc.login();
        } catch (LoginException e) {
            // ログインNG
            return false;
        }

        // ログインOK
        return true;

    }

    /**
     * ログイン処理の際にコールバックされるクラス。
     */
    public static class LoginCallbackHandler implements CallbackHandler {

        private String loginID = null;
        private String passwd = null;

        LoginCallbackHandler(String loginID, String passwd) {
            this.loginID = loginID;
            this.passwd = passwd;
        }

        public void handle(Callback[] callbacks) throws java.io.IOException, UnsupportedCallbackException {
            for (int i = 0; i < callbacks.length; i++) {
                if (callbacks[i] instanceof NameCallback) {
                    NameCallback cb = (NameCallback) callbacks[i];
                    cb.setName(loginID);
                } else if (callbacks[i] instanceof PasswordCallback) {
                    PasswordCallback cb = (PasswordCallback) callbacks[i];
                    char[] pwChar = new char[passwd.length()];
                    passwd.getChars(0, pwChar.length, pwChar, 0);
                    cb.setPassword(pwChar);

                } else {
                    throw new UnsupportedCallbackException(callbacks[i]);
                }
            }
        }
    }
}
