package jp.co.webcrew.filters.util;

import java.security.MessageDigest;

import jp.co.webcrew.dbaccess.util.Logger;

public class MD5
{
	private static final Logger objLogger = Logger.getLogger(MD5.class);
	
	/**
	 * MD5アルゴリズム
	 * 文字列を暗号化する
	 *
	 * @param str 暗号化される文字列
	 * @return 暗号化結果
	 * @throws NoSuchAlgorithmException
	 */
	public static String crypt(String strValue)
	{
		try
		{
			if (strValue == null || strValue.equals(""))
			{
				objLogger.error("暗号化する文字列が指定されていません。");
				return "";
			}

			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(strValue.getBytes());
			byte[] hash = md.digest();

			return hashByte2MD5(hash);
		}
		catch (Exception e)
		{
			objLogger.error("MD5暗号化処理で例外が発生しました。", e);
			return "";
		}
	}

	/**
	 * MD5 ハッシュ関数
	 * 
	 */
	private static String hashByte2MD5(byte []hash)
	{
		StringBuffer hexString = new StringBuffer();
		for (int i = 0; i < hash.length; i++)
		{
			if ((0xff & hash[i]) < 0x10)
			{
				hexString.append("0" + Integer.toHexString((0xFF & hash[i])));
			}
			else
			{
				hexString.append(Integer.toHexString(0xFF & hash[i]));
			}
		}
		return hexString.toString();
	}
}



