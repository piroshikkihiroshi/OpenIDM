package jp.co.webcrew.login.common.mailmaga;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.util.AppConstants;
import jp.co.webcrew.login.common.util.MelmagaUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;

/**
 * Registering the mail maga flags
 * If user is logged in the mail maga setting screen is displayed
 * If user is not logged in, then a mail with confirmation link is sent to the user
 *
 * @author Amit Parmar
 */
public class MailMagaRegistServlet extends HttpServlet
{
	/** serialVersionUID */
	private static final long serialVersionUID = -3959213999920666981L;

	/** ロガー */
	private static final Logger log 				= Logger.getLogger(MailMagaRegistServlet.class);

	private static final String SHOW_URL 			= "MyAction?page=melmaga.SubscriptionList&command=show";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}
	
	/**
	 * 主処理を行う。
	 *
	 * @param req
	 * @param res
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void execute(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException 
	{

		log.info("メルマガ登録 execute start");

		MailMagaRegistForm objMailMagaRegistForm = new MailMagaRegistForm();
		//入力チェック
		objMailMagaRegistForm.populate(request);
		objMailMagaRegistForm.validate(request);
		
		// 入力値にエラーがある場合、元の画面に戻す
		if (objMailMagaRegistForm.isMessageFlag()) {
			redirect(request, response, objMailMagaRegistForm);
			return;
		}
		
		boolean blnMobileFlg = SessionFilterAlterUtil.fromMobile(request);
		String strLoginFlag = SessionFilterAlterUtil.getLoginFlag(request);
		if ("t".equals(strLoginFlag))
		{
			forward(request, response, SHOW_URL); 
		}	
		else
		{
			// メールIDを取得
			String strEmail = objMailMagaRegistForm.getEmail();
			log.info("ログオフ状態　Email:　" + strEmail);
			
			// strSiteIdを取得する
			String strSiteId = objMailMagaRegistForm.getSiteId();
			//サイトIDが付加されてなかったら、サイト認識不能とする。
			if (strSiteId == null || "".equals(strSiteId) || strSiteId.equals("null")) {
				strSiteId = (String)request.getAttribute(MelmagaUtil.SITE_ID_ATTR_KEY);
				if (strSiteId == null || "".equals(strSiteId)) {
					strSiteId = "-1";
				}
			}
			
			String strGuid = SessionFilterAlterUtil.getGuid(request);
			if (strGuid == null || "".equals(strGuid)) 
			{
				log.info("guidが無効です。");
				throw new ServletException();
				//forwardSystemError(request, response);
			}
			
			int nResult = MelmagaUtil.sendSubscribeMail(strEmail, strSiteId, strGuid);
			
			if (MelmagaUtil.MAIL_SEND_ERROR == nResult)
			{	
				if (blnMobileFlg) {						
					objMailMagaRegistForm.setMessage("ﾒﾙﾏｶﾞ登録ﾒｰﾙの送信に失敗しました。");
				}
				else {
					objMailMagaRegistForm.setMessage("メルマガ登録メールの送信に失敗しました。");
				}
				
				objMailMagaRegistForm.setMessageFlag(true);
				redirect(request, response, objMailMagaRegistForm);
			}
			else if (MelmagaUtil.SYSTEM_ERROR == nResult)
			{
				log.error("ﾙﾏｶﾞ登録ﾒｰﾙの送信にシステムエラーが発生しました。 Email=" + strEmail);
				 throw new ServletException();
				//forwardSystemError(request, response);
			}
			else 
			{
				log.info("メルマガ登録メールの送信完了しました。 Email=" + strEmail);
				if (blnMobileFlg) 
				{						
					objMailMagaRegistForm.setMessage("お客様のE-mailへ確認ﾒｰﾙをお送りさせていただきました。");
				}
				else 
				{
					objMailMagaRegistForm.setMessage("お客様のE-mailへ確認メールをお送りさせていただきました。");
				}
				
				objMailMagaRegistForm.setMessageFlag(true);
				redirect(request, response, objMailMagaRegistForm);
			}	
		}
	}

	/**
	 * Forwarding to the mail maga subscribe page
	 * @param request
	 * @param response
	 * @param strUrl
	 * @throws ServletException
	 * @throws IOException
	 */
    public static void forward(HttpServletRequest request, HttpServletResponse response, String strUrl) throws ServletException,IOException
    { 
        RequestDispatcher objRequestDispatcher = request.getRequestDispatcher(strUrl);
        objRequestDispatcher.forward(request, response);
    }
    
	/**
	 * エラー画面を表示する
	 * 
	 * @param request
	 * @param response
	 * @param form
	 * @throws IOException 
	 * @throws Exception 
	 */
	private void redirect (HttpServletRequest request,
			HttpServletResponse response , MailMagaRegistForm objMailMagaRegistForm) 
			throws ServletException, IOException 
	{		
		String strReferer = request.getHeader("referer");
		if (strReferer != null && strReferer.indexOf("/") != -1) {
			String strRequestPath = request.getServerName() + request.getContextPath();
			strReferer = strReferer.substring(strReferer.indexOf(strRequestPath) + strRequestPath.length() + 1);
		}
		
		HttpSession session = request.getSession(false);
        if (session == null) 
        {
            log.info("メルマガ購読解除処理でセッションタイムアウトエラーが発生しました。");
            throw new ServletException();
            //forwardSystemError(request, response);
        }
        
        session.setAttribute(AppConstants.MAIL_MAGA_REGIST_FORM, objMailMagaRegistForm);
        
        String strUrl = pathConcat(request.getContextPath(), strReferer);
        response.sendRedirect(response.encodeURL(strUrl));
	}
	
    /**
     * 
     * <pre>
     *  内部パスや URLなど最後に / が付く可能性のある文字列を連結。
     *  左側文字列の最後に / が付かない場合、付与してから連結する。
     * </pre>
     * @param strLeftUrl 左側文字列。
     * @param index 右側文字列
     * @return
     */
    public static String pathConcat( String strLeftUrl, String strRightUrl ) 
    {
        strLeftUrl  = ValueUtil.nullToStr(strLeftUrl).trim();
        strRightUrl = ValueUtil.nullToStr(strRightUrl).trim();

        String strUrl = null;
        if( strLeftUrl.endsWith( "/" ) )
        {
            strUrl = strLeftUrl + strRightUrl;
        } 
        else 
        {
            strUrl = strLeftUrl + "/" + strRightUrl;
        }
        
        return strUrl;
    }
}