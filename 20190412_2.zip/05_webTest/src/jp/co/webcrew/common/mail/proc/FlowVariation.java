package jp.co.webcrew.common.mail.proc;

import java.util.Map;

import jp.co.webcrew.common.util.proc.StringUtils;

import org.w3c.dom.Node;

/**
 * This class represents a possible deviation from the standard calculation set flow.
 * If the wildcard value matching "name" has value matching "value", the flow is
 * directed to go to the "goto" attribute. If "error" is true, an error is thrown. If
 * "goto" is null, the flow exits.
 * 
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: FlowVariation.java,v 1.4 2005-06-14 11:45:19 rickk Exp $
 */
public class FlowVariation {
    static final String ATTR_NAME = "name";
    static final String ATTR_VALUE = "value";
    static final String ATTR_GOTO = "goto";
    static final String ATTR_ERROR = "error";
    static final String ATTR_ERRORPARAM = "errorParam";
    static final String ATTR_NEGATE = "negate";

    private String name;
    private String value;
    private Integer gotoOrder;
    private String errorMessage;
    private String errorParam;
    private boolean negate;
    
    public FlowVariation(Node node) {
        this.name = node.getAttributes().getNamedItem(ATTR_NAME).getNodeValue();
        Node value = node.getAttributes().getNamedItem(ATTR_VALUE);
        if (value != null) {
            this.value = value.getNodeValue();
        }

        Node gotoOrder = node.getAttributes().getNamedItem(ATTR_GOTO);
        if (gotoOrder != null) {
            this.gotoOrder = new Integer(gotoOrder.getNodeValue());
        } else {
            this.gotoOrder = null;
        }

        Node errorMessage = node.getAttributes().getNamedItem(ATTR_ERROR);
        if (errorMessage != null) {
            this.errorMessage = errorMessage.getNodeValue();
        }

        Node errorParam = node.getAttributes().getNamedItem(ATTR_ERRORPARAM);
        if (errorParam != null) {
            this.errorParam = errorParam.getNodeValue();
        }

        Node negate = node.getAttributes().getNamedItem(ATTR_NEGATE);
        if (negate != null) {
            this.negate = new Boolean(negate.getNodeValue()).booleanValue();
        } else {
            this.negate = false;
        }
    }
    
    public boolean isMatching(Map wildcards) {
        WildcardValue wc = CalculationSet.findWildcardInMap(this.name, wildcards);
        String wcValueStringForm = null;
        if (wc != null) {
            wcValueStringForm = CalculationSet.convertToStringForm(wc.getValue(), wc.getType());
        }
        boolean isNullMatch = (wcValueStringForm == null) && (this.value == null);
        boolean isNonNullMatch = (wcValueStringForm != null) && (this.value != null) && 
                wcValueStringForm.equals(this.value);
        return ( (isNullMatch || isNonNullMatch) && !this.negate) ||
               (!(isNullMatch || isNonNullMatch) && this.negate);
    }
    
    public Integer getGotoOrder() {
        return this.gotoOrder;
    }
    
    public String getThrownErrorMessage(Map wildcards) {
        
        String errorMessage = this.errorMessage;
        if (errorMessage == null) {
            WildcardValue wc = (WildcardValue) wildcards.get(this.errorParam);
            if ((wc != null) && (wc.getValue() != null)) {
                errorMessage = "" + wc.getValue();
            }
        }
        
        if (errorMessage == null) {
            return null;
        } else {
            String replaceWildcards[][] = Expression.getWildcardArrayForReplacement(wildcards);
            return StringUtils.stringReplace(
                    StringUtils.capitalizeWildcardNames(errorMessage),
                    replaceWildcards);
        }
    }
}
