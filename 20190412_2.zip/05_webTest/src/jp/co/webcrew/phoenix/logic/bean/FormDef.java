package jp.co.webcrew.phoenix.logic.bean;

/**
 * form_def テーブル用
 * 
 * @author kurinami
 */
public class FormDef {
    public String site_id;
    public String form_id;
    public String src_site_id;
    public String src_form_id;
    public char sync_flag;
    public String name;
    public String description;
    public String up_datetime;
    public String up_admin;
}
