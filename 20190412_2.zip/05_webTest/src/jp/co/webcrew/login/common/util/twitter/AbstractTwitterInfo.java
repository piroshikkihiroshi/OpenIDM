/**
 *
 */
package jp.co.webcrew.login.common.util.twitter;

import java.sql.SQLException;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.SystemProperties;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;

/**
 * TwitterAPIを利用するのに必要なプロパティ値の保持クラス
 * サイト毎にこれを継承して、子クラスで細かい実装を行う
 *
 * @author shintaro.kurihara
 *
 */
public abstract class AbstractTwitterInfo {

	private static Logger log = Logger.getLogger(AbstractTwitterInfo.class);


	//ConsumerTwitterオブジェクト
	private static Twitter consumerTwiter = null;
	//アプリケーション登録ユーザのtwitter
	private static Twitter appsUserTwitter = null;

	//取得したtweetを格納 List<TweetBean>
	//private static List tweetList = null;


	//System_Prperty Keys
	protected String autoTweetTextKeyName = "";        //つぶやき時の自動挿入テキスト
	protected String consumerKeyKeyName = "";         //CONSUMER_KEY
	protected String consumerSecretKeyName ="";      //CONSUMER_SECRET
	protected String appUserScreennameKeyName ="";  //アプリケーション登録ユーザのtwitterID
	protected String appUserPasswordKeyName ="";    //アプリケーション登録ユーザのtwitterパスワード
	protected String callBackUrlKeyName ="";        //AOtuh認証時の戻りURL

	//キャンペーン固有値


	//1ページあたりの表示数（もっと見るなどを押されると表示が増える）default 5
	protected int onepageTweetsNumber = 5;

	//表示Tweets最大数 default 50
	protected int maxKeepingTweetNumer = 50;

	//経過時間表示フォーマット default 1
	protected int elapsedTimeFormatID = 1;

	/**
	 * @return displayTweetList　List<TweetBean>
	 */
	/*public List getTweetList() throws Exception{
		if(tweetList == null || tweetList.size() == 0){
			setTweetList();
		}
		return tweetList;
	}*/

	/*public void setTweetList() throws Exception{
		String _searchQuery = null;
		if(searchQuery == null){
			_searchQuery = this.getAutoTweetText();
		}else{
			_searchQuery = searchQuery;
		}
		try{
			tweetList = TwitterUtil.getTweetsList(_searchQuery, new Integer(maxKeepingTweetNumer), elapsedTimeFormatID);
		}catch(TwitterException e){

		}
	}*/


	/**
	 * @return autoTweetText つぶやき時自動挿入文
	 */
	public String getAutoTweetText() throws Exception{
		return getValue(autoTweetTextKeyName);

	}

	/**
	 * @return searchQuary 表示リスト検索用文字列　デフォルトは自動挿入文
	 */
	public String getSearchQuary() throws Exception{
		return getValue(autoTweetTextKeyName);

	}

	/**
	 * @return appUserTwitter ｱﾌﾟﾘｹｰｼｮﾝ登録ユーザのTwitter
	 */
	public Twitter getAppsUserTwitter() throws Exception{
		//t_ueda コメントアウト
//		appsUserTwitter = new TwitterFactory().getInstance(this.getAppUserScreenname(), this.getAppUserPassword());
//		return appsUserTwitter;
		appsUserTwitter = new TwitterFactory().getInstance();
		return appsUserTwitter;
	}

	/**
	 * @return callBackURL OAuth認証後の戻りURL
	 */
	public String getCallBackURL() throws Exception{
		return getValue(callBackUrlKeyName);
	}

	/**
	 * @return consumerTwiter　ConsumerのTwitter
	 */
	public Twitter getConsumerTwiter() throws Exception{
		//t_ueda コメントアウト
//		consumerTwiter = new TwitterFactory().getOAuthAuthorizedInstance(getValue(consumerKeyKeyName), getValue(consumerSecretKeyName));
//		return consumerTwiter;
		consumerTwiter = new TwitterFactory().getInstance();
		return consumerTwiter;
	}

	/**
	 * @return consumerKey
	 */
	public String getConsumerKey() throws Exception{
		return getValue(consumerKeyKeyName);
	}

	/**
	 * @return consumerTwiter　ConsumerのTwitter
	 */
	public String getConsumerSecret() throws Exception{
		return getValue(consumerSecretKeyName);
	}

	/**
	 * @return appUserScreenname　App登録ユーザのTwitterアカウント
	 */
	public String getAppUserScreenname() throws Exception{
		return getValue(appUserScreennameKeyName);
	}

	/**
	 * @return appUserPassword　App登録ユーザのTwitterパスワード
	 */
	public String getAppUserPassword() throws Exception{
		return getValue(appUserPasswordKeyName);
	}


	/**
	 * @return maxKeepingTweetNumer　表示用Listが持つ最大Tweet数
	 */
	public int getMaxKeepingTweetNumer() {
		return maxKeepingTweetNumer;
	}

	/**
	 * @return onepageTweetsNumber　一つのページで表示する最大Tweet数
	 */
	public int getOnepageTweetsNumber() {
		return onepageTweetsNumber;
	}


	/**
	 * @return elapsedTimeFormatID　時間表記のFormatID
	 * 表記方詳細はTwitterUtil参照
	 */
	public int getElapsedTimeFormatID() {
		return elapsedTimeFormatID;
	}


	/**
	 *
	 * @return displayTweetList
	 * @throws Exception
	 * 表示用つぶやきリストの取得メソッド
	 * デフォルトの検索条件は、
	 * 自動入力値で検索、子クラスで指定された最大取得数
	 *
	 * 条件を変更したい場合は、子クラスでオーバーライドする
	 */
	public List getDisplayTweetList() throws Exception{
		String[] searchQuarys ={this.getAutoTweetText()};
		return TwitterUtil.getTweetsList(searchQuarys, new Integer(this.maxKeepingTweetNumer));

	}


	/**
	 * TONASHIBA.SYSTEM_PROPERTIESから、Valueを取得する
	 * エラーは呼び出し側のサーブレットで処理する
	 *
	 * @parame key
	 */
	private static String getValue(String key) throws Exception{
		DBAccess db = null;
		String value = null;
		try {
			db = new DBAccess();

			SystemProperties sysProp = new SystemProperties(db);
			value = ValueUtil.nullToStr(sysProp.get(key));

		} catch (SQLException e) {
			log.error("例外エラーが発生しました。" , e);
			throw new Exception();
		} finally {
			DBAccess.close(db);
		}
		return value;
	}


}