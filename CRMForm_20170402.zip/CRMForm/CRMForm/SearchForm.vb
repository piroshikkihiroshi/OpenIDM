﻿Imports CRMForm.DeclareCs
Imports CRMForm.commonFunc
Imports CRMForm.sqlMng
Imports CRMForm.ExcelCnt

Public Class SearchForm

    Private Sub SearchForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        'サーバに接続
        Dim objSqlFn As New sqlMng
        Dim objCmFn As New commonFunc
        Dim strSeverName As String
        Dim strDbName As String
        Dim strSqlCom As String
        Dim initStatus As Long


        Dim objCnt As Control()
        Dim tmpVal As Object
        Dim tmpVal2 As Object
        Dim dicHeder As New Dictionary(Of String, String)

        Dim strWhere As String = ""
        Dim tgtControl As Object
        Dim strUserId As String
        Dim strPass As String
        'Dim loopIdx As Long

        'Dim ret As Long


        strSeverName = TGT_SERVER_NAME
        strDbName = TGT_DB

        'mainForm自体を格納
        Dim fmMain As Form = CType(Me.Owner, SearchMainForm)


        strUserId = TGT_USER
        strPass = TGT_PASS

        'サーバに接続
        Dim objSqlCon As System.Data.SqlClient.SqlConnection = objSqlFn.sqlCon(strSeverName, strDbName, strUserId, strPass)

        initStatus = 1

        'For Each tmpVal In glHdInfoDic
        '    objCnt = fmMain.Controls.Find(tmpVal.key, True)
        '    If objCnt.Length > 0 Then
        '        tgtControl = objCnt(0)
        '        If TypeOf tgtControl Is TextBox Then 'テキストボックスの処理
        '            If CType(objCnt(0), TextBox).Text <> "" And initStatus = 1 Then
        '                strWhere = tmpVal.key & " LIKE '%" & CType(objCnt(0), TextBox).Text & "%' "
        '                initStatus = 2
        '            ElseIf CType(objCnt(0), TextBox).Text <> "" Then
        '                strWhere = strWhere & " AND " & tmpVal.key & " LIKE '%" & CType(objCnt(0), TextBox).Text & "%' "
        '            End If
        '        Else
        '            If CType(objCnt(0), ComboBox).Text <> "" And initStatus = 1 Then
        '                Dim strComboVal As String = ""
        '                For Each tmpVal2 In glComboDic(tmpVal.key)
        '                    If tmpVal2.Value = CType(objCnt(0), ComboBox).Text Then
        '                        strComboVal = tmpVal2.Key
        '                        Exit For
        '                    End If
        '                Next tmpVal2
        '                strWhere = tmpVal.key & " LIKE '%" & strComboVal & "%' "
        '                initStatus = 2
        '            ElseIf CType(objCnt(0), ComboBox).Text <> "" Then
        '                Dim strComboVal As String = ""
        '                For Each tmpVal2 In glComboDic(tmpVal.key)
        '                    If tmpVal2.Value = CType(objCnt(0), ComboBox).Text Then
        '                        strComboVal = tmpVal2.Key
        '                        Exit For
        '                    End If
        '                Next tmpVal2
        '                strWhere = strWhere & " AND " & tmpVal.key & " LIKE '%" & strComboVal & "%' "
        '            End If
        '        End If

        '    End If
        'Next tmpVal

        'Dim aaa As Integer = 0

        'For Each tmpVal In glHdInfoDic
        '    objCnt = fmMain.Controls.Find(tmpVal.key, True)
        '    If objCnt.Length > 0 Then
        '        tgtControl = objCnt(0)

        '        If TypeOf tgtControl Is TextBox Then 'テキストボックスの処理
        '            'If aaa = 0 Then
        '            '    MessageBox.Show(CType(tgtControl, TextBox).Text)
        '            '    aaa = 1
        '            'End If
        '            If CType(tgtControl, TextBox).Text <> "" And initStatus = 1 Then
        '                strWhere = tmpVal.key & " LIKE '%" & CType(tgtControl, TextBox).Text & "%' "
        '                initStatus = 2
        '            ElseIf CType(tgtControl, TextBox).Text <> "" Then
        '                strWhere = strWhere & " AND " & tmpVal.key & " LIKE '%" & CType(tgtControl, TextBox).Text & "%' "
        '            End If
        '        Else
        '            If CType(tgtControl, ComboBox).Text <> "" And initStatus = 1 Then
        '                Dim strComboVal As String = ""
        '                For Each tmpVal2 In glComboDic(tmpVal.key)
        '                    If tmpVal2.Value = CType(tgtControl, ComboBox).Text Then
        '                        strComboVal = tmpVal2.Key
        '                        Exit For
        '                    End If
        '                Next tmpVal2
        '                strWhere = tmpVal.key & " = '" & strComboVal & "' "
        '                initStatus = 2
        '            ElseIf CType(tgtControl, ComboBox).Text <> "" Then
        '                Dim strComboVal As String = ""
        '                For Each tmpVal2 In glComboDic(tmpVal.key)
        '                    If tmpVal2.Value = CType(tgtControl, ComboBox).Text Then
        '                        strComboVal = tmpVal2.Key
        '                        Exit For
        '                    End If
        '                Next tmpVal2
        '                strWhere = strWhere & " AND " & tmpVal.key & " = '" & strComboVal & "' "
        '            End If
        '        End If

        '    End If
        'Next tmpVal


        '顧客名暫定対応

        objCnt = fmMain.Controls.Find("kokyakuText", True)
        tgtControl = objCnt(0)
        If CType(tgtControl, TextBox).Text <> "" Then
            strWhere = " [dbo].[Kkyak_Kmk01].cMoji40011 LIKE '%" & CType(tgtControl, TextBox).Text & "%' "
            initStatus = 0
        End If

        'strWhere = " [dbo].[Kkyak_Kmk02].cMoji40046 <> '' "


        For Each tmpVal In glHdInfoDic
            objCnt = fmMain.Controls.Find(tmpVal.key, True)
            If objCnt.Length > 0 Then
                tgtControl = objCnt(0)

                If TypeOf tgtControl Is TextBox Then 'テキストボックスの処理

                    If CType(tgtControl, TextBox).Text <> "" And initStatus = 1 Then

                        strWhere = tmpVal.key & " LIKE '%" & CType(tgtControl, TextBox).Text & "%' "
                        initStatus = 2
                    ElseIf CType(tgtControl, TextBox).Text <> "" Then
                        strWhere = strWhere & " AND " & tmpVal.key & " LIKE '%" & CType(tgtControl, TextBox).Text & "%' "
                    End If
                Else
                    If CType(tgtControl, ComboBox).Text <> "" And initStatus = 1 Then
                        Dim strComboVal As String = ""
                        For Each tmpVal2 In glComboDic(tmpVal.key)
                            If tmpVal2.Value = CType(tgtControl, ComboBox).Text Then
                                strComboVal = tmpVal2.Key
                                Exit For
                            End If
                        Next tmpVal2
                        strWhere = tmpVal.key & " = '" & strComboVal & "' "
                        initStatus = 2
                    ElseIf CType(tgtControl, ComboBox).Text <> "" Then
                        Dim strComboVal As String = ""
                        For Each tmpVal2 In glComboDic(tmpVal.key)
                            If tmpVal2.Value = CType(tgtControl, ComboBox).Text Then
                                strComboVal = tmpVal2.Key
                                Exit For
                            End If
                        Next tmpVal2
                        strWhere = strWhere & " AND " & tmpVal.key & " = '" & strComboVal & "' "
                    End If
                End If

            End If
        Next tmpVal





        'sql発行
        strSqlCom = glSqlCom
        If strWhere <> "" Then  '文字が指定されていなければすべて表示
            strSqlCom = strSqlCom & " WHERE " & strWhere
        End If

        strSqlCom = strSqlCom & " ORDER BY 顧客コード; "

        'Dim objDbData As Object = objSqlFn.sqlQuery(objSqlCon, strSqlCom)


        'フォームのレイアウトロジックを中断する
        Me.SuspendLayout()
        Cursor.Current = Cursors.WaitCursor

        Dim SQLDA As SqlClient.SqlDataAdapter
        Dim SQLDS As New DataSet()

        '接続の設定を行います。
        SQLDA = New SqlClient.SqlDataAdapter(strSqlCom, objSqlCon)

        'データセットに格納します。
        SQLDA.Fill(SQLDS, "K_MAIN")

        'データグリッドビューのデータソースを設定
        Me.objGridView.DataSource = SQLDS.Tables("K_MAIN")


        Me.AutoSize = True


        'ロジック変更 SQLで指定し加工しないでビューへ表示
        'initStatus = 1
        'loopIdx = 0

        '' 次のレコードに進める (次のレコードがない場合は False になるため実行されない)
        'While (objDbData.Read())
        '    ReDim Preserve sryColCells(objDbData.FieldCount - 1)    'データ格納用配列
        '    If initStatus = 1 Then '初回はカラムを作成
        '        Me.objGridView.Columns.Add("cKkyakCd", "顧客コード")  '最初は顧客コードを格納
        '        For Each tmpVal In glHdInfoDic

        '            If objDbData(tmpVal.key()).ToString() <> "" Then
        '                Me.objGridView.Columns.Add(tmpVal.key, tmpVal.Value)
        '                dicHeder.Add(tmpVal.key, tmpVal.Value)  '必要な情報のみのdictionary作成
        '                loopIdx = loopIdx + 1
        '            End If


        '        Next tmpVal

        '        initStatus = 2
        '    End If

        '    loopIdx = 1
        '    sryColCells(0) = objDbData("cKkyakCd").ToString()   '最初は顧客コードを格納
        '    For Each tmpVal In dicHeder

        '        If glComboDic.ContainsKey(tmpVal.key) Then
        '            Dim tmpObj As Object = glComboDic(tmpVal.key)
        '            Dim strTmpKey As String = CInt(objDbData(tmpVal.key().ToString()))
        '            If tmpObj.ContainsKey(strTmpKey) Then
        '                sryColCells(loopIdx) = tmpObj(strTmpKey)
        '            Else
        '                sryColCells(loopIdx) = "未設定"
        '            End If

        '        Else
        '            sryColCells(loopIdx) = objDbData(tmpVal.key()).ToString()
        '        End If

        '        loopIdx = loopIdx + 1
        '    Next tmpVal

        '    Me.objGridView.Rows.Add(sryColCells)

        '    Erase sryColCells


        'End While

        'Me.objGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
        'Me.objGridView.AutoSize = True

        Me.objGridView.Size = New Point(glDispWidth - 100, glDispHeight - 100)
        Me.objGridView.Location = New Point(0, 40)
        Me.objGridView.Columns(1).Frozen = True

        Me.objGridView.DefaultCellStyle.Format = "N0"

        ' 2列目の右側の区分線の幅を1にする
        'Me.objGridView.Columns(1).DividerWidth = 1

        Me.Controls.Add(objGridView)

        Me.AutoScroll = True
        Me.Location = New Point(20, 20)

        Me.ExcelOutput.Location = New Point(10, 10)

        'フォームのレイアウトロジックを再開する
        Me.ResumeLayout(False)

        Cursor.Current = Cursors.Default


    End Sub

    Private Sub objGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles objGridView.CellDoubleClick

        Dim lngResult As Long
        Dim objCmFn As New commonFunc
        'Dim ret As Long

        'ret = objCmFn.checkCardAble()

        'If ret = 0 Then
        If e.ColumnIndex < 0 Or Me.objGridView.ColumnCount - 1 < e.ColumnIndex Then 'レコードセレクタをクリック
            'MessageBox.Show("Col　" & e.ColumnIndex)
        ElseIf e.RowIndex < 0 Or Me.objGridView.RowCount - 1 < e.RowIndex Then    ' ヘッダー部をクリック
            'MessageBox.Show("Row　" & e.RowIndex)
        Else
            Dim strTgtCode As String = objGridView.CurrentRow.Cells("顧客コード").Value
            lngResult = objCmFn.searchTgtInfo(strTgtCode)
        End If
        'End If



    End Sub

    'キーイベント
    Private Sub objGridView_PreviewKeyDown(ByVal sender As Object, ByVal e As PreviewKeyDownEventArgs) Handles objGridView.PreviewKeyDown
        'Stop

        'Me.objGridView.HorizontalScrollingOffset = 10

        Select Case e.KeyCode
            'Case Keys.Up, Keys.Left, Keys.Down, Keys.Right
            Case Keys.Left
                'Me.objGridView.FirstDisplayedScrollingColumnIndex = Me.objGridView.FirstDisplayedScrollingColumnIndex - 1
            Case Keys.Right
                Dim a As String
                a = ""
                'Me.objGridView.ReadOnly = False
                'Me.objGridView.ReadOnly = True
                'Me.objGridView.FirstDisplayedScrollingColumnIndex = Me.objGridView.FirstDisplayedScrollingColumnIndex + 1
                'Me.objGridView.CurrentCell = Me.objGridView(Me.objGridView.CurrentCell.RowIndex, Me.objGridView.CurrentCell.ColumnIndex + 1)
            Case Keys.Up
                'Me.objGridView.FirstDisplayedScrollingRowIndex = Me.objGridView.FirstDisplayedScrollingRowIndex - 1
            Case Keys.Down
                'Me.objGridView.FirstDisplayedScrollingRowIndex = Me.objGridView.FirstDisplayedScrollingRowIndex + 1
        End Select


    End Sub


    Private Sub ExcelOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExcelOutput.Click

        Dim objExcelCls As New ExcelCnt

        objExcelCls.ExcelOutPut(Me.objGridView)


    End Sub


End Class