package jp.co.webcrew.filters.filters.replace.sstag;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.QueueThreadUtil;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;
import jp.co.webcrew.login.common.SStagRegistUtil;
import jp.co.webcrew.login.common.SStagUpdateUtil;

/**
 * 本登録処理を行うthreadクラス。
 * 
 * @author kurinami
 */
public class MemberRegistThread extends QueueThreadUtil {

	/** email */
	public static final String MEMBER_REGIST_THREAD_EMAIL_ATTR_KEY = "webcrew_member_regist_thread_email";

	/** password */
	public static final String MEMBER_REGIST_THREAD_PASSWORD_ATTR_KEY = "webcrew_member_regist_thread_password";

	/** site_id */
	public static final String MEMBER_REGIST_THREAD_SITE_ID_ATTR_KEY = "webcrew_member_regist_thread_site_id";

	/** order_id */
	public static final String MEMBER_REGIST_THREAD_ORDER_ID_ATTR_KEY = "webcrew_member_regist_thread_order_id";

	/** user_id */
	public static final String MEMBER_REGIST_THREAD_USER_ID_ATTR_KEY = "webcrew_member_regist_thread_user_id";

	/** nickname */
	public static final String MEMBER_REGIST_THREAD_NICKNAME_ATTR_KEY = "webcrew_member_regist_thread_nickname";

	/** gender */
	public static final String MEMBER_REGIST_THREAD_GENDER_ATTR_KEY = "webcrew_member_regist_thread_gender";

	/** birthday */
	public static final String MEMBER_REGIST_THREAD_BIRTHDAY_ATTR_KEY = "webcrew_member_regist_thread_birthday";

	/** mobile_site_flag */
	public static final String MEMBER_REGIST_THREAD_MOBILE_SITE_FLAG_ATTR_KEY = "webcrew_member_regist_thread_mobile_site_flag";

	/** exec_type */
	public static final String MEMBER_REGIST_THREAD_EXEC_TYPE_ATTR_KEY = "webcrew_member_regist_thread_exec_type";

	/** exec_type: 本登録 */
	public static final String MEMBER_REGIST_THREAD_EXEC_TYPE_REGIST = "1";

	/** exec_type: ユーザ情報更新 */
	public static final String MEMBER_REGIST_THREAD_EXEC_TYPE_UPDATE = "2";

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(MemberRegistThread.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.util.QueueThreadUtil#execute(jp.co.webcrew.filters.util.httputil.HttpServletRequestCache)
	 */
	protected void execute(HttpServletRequestCache request) throws Exception {

		int guid = ValueUtil.toint((String) request
				.getAttribute(UserInfo.GUID_ATTR_KEY));
		String email = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_EMAIL_ATTR_KEY);
		String password = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_PASSWORD_ATTR_KEY);
		String siteId = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_SITE_ID_ATTR_KEY);
		String orderId = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_ORDER_ID_ATTR_KEY);
		String userId = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_USER_ID_ATTR_KEY);
		String nickname = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_NICKNAME_ATTR_KEY);
		String gender = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_GENDER_ATTR_KEY);
		String birthday = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_BIRTHDAY_ATTR_KEY);
		boolean mobileSiteFlag = ((Boolean) request
				.getAttribute(MEMBER_REGIST_THREAD_MOBILE_SITE_FLAG_ATTR_KEY))
				.booleanValue();
		String execType = (String) request
				.getAttribute(MEMBER_REGIST_THREAD_EXEC_TYPE_ATTR_KEY);

		try {

			if (execType.equals(MEMBER_REGIST_THREAD_EXEC_TYPE_REGIST)) {
				// 本登録処理を行う。

				// 性別と誕生日が指定されていない場合は、nullにする。
				gender = gender.length() == 0 ? null : gender;
				birthday = birthday.length() == 0 ? null : birthday;

				log.info("SStagRegistUtil#registUser()呼び出し guid = " + guid
						+ ", email = " + email + ", password = " + password
						+ ", siteId = " + siteId + ", orderId = " + orderId
						+ ", userId = " + userId + ", nickname = " + nickname
						+ ", gender = " + gender + ", birthday = " + birthday
						+ ", mobileSiteFlag = " + mobileSiteFlag);

				if (SStagRegistUtil.registUser(Integer.toString(guid), email,
						password, siteId, orderId, userId, nickname, gender,
						birthday, mobileSiteFlag)) {
					log.info("本登録処理が無事完了しました。");
				} else {
					log.error("本登録処理に失敗しました。");
				}

			} else if (execType.equals(MEMBER_REGIST_THREAD_EXEC_TYPE_UPDATE)) {
				// ユーザ情報更新処理を行う。

				log.info("SStagUpdateUtil#updateUser()呼び出し guid = " + guid
						+ ", email = " + email + ", siteId = " + siteId
						+ ", orderId = " + orderId + ", userId = " + userId
						+ ", mobileSiteFlag = " + mobileSiteFlag);

				if (SStagUpdateUtil.updateUser(Integer.toString(guid), email,
						siteId, orderId, userId, mobileSiteFlag)) {
					log.info("ユーザ情報更新処理が無事完了しました。");
				} else {
					log.error("ユーザ情報更新処理に失敗しました。");
				}

			}
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}
	}

}
