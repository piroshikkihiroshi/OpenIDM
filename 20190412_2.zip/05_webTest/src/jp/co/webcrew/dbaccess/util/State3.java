/**
 * 
 */
package jp.co.webcrew.dbaccess.util;

/**
 * <pre>
 * TRUE , FALSE , NA(N/A) の三値を表すクラス。
 * 
 * 
 * 値の判定には isXXX を使ってください。
 * 
 * (使用例)
 * 
 * State3 result = Util.isXXX(); // State3型の結果を取得
 *  
 * ○ if ( result.isTrue() ) { ...
 * 
 * × if ( result == State3.TRUE ) { ...
 * 
 * 
 * </pre>
 * 
 * @author Takahashi
 *
 */
public class State3 {
    
    /** 値 */
    private Boolean _val;
    
    /** 追加の情報 */
    private String _addition;

    /** コンストラクタ。値は NA になる  */
    public State3() {
        _val = null;
    }
    
    /** TRUE */
    public final static State3 TRUE  = State3.TRUE();

    /** FALSE */
    public final static State3 FALSE = State3.FALSE();

    /** N/A */
    public final static State3 NA    = State3.NA();

    /**
     * コンストラクタ。値は引数で指定する。
     * @param bool
     */
    public State3(boolean bool) {
        _val = new Boolean(bool);
    }
    
    /**
     * @return addtion
     */
    public String getAddition() {
        return _addition;
    }

    /**
     * @param addtion 設定する addtion
     */
    public void setAddition(String addition) {
        _addition = addition;
    }
    
    /** 
     * 値が TRUE であれば true, そうでなければfalseを返す 
     */
    public boolean isTrue() {
        if (_val != null) {
            if (_val.booleanValue() == true) {
                return true;
            }
        }
        
        return false;
    }

    /** 
     * 値が FALSE であれば true, そうでなければfalseを返す 
     */
    public boolean isFalse() {
        if (_val != null) {
            if (_val.booleanValue() == false) {
                return true;
            }
        }
        
        return false;
    }

    /** 
     * 値が NA であれば true, そうでなければfalseを返す 
     */
    public boolean isNA() {
        if (_val == null) {
            return true;
        }
        
        return false;
    }
    
    /**
     * <pre>
     * 値を NA に設定する
     * </pre>
     */
    public void setNA() {
        _val = null;
    }
    
    /**
     * <pre>
     * 値を TRUE に設定する
     * </pre>
     */
    public void setTrue() {
        _val = new Boolean(true);
    }

    /**
     * <pre>
     * 値を FALSE に設定する
     * </pre>
     */
    public void setFalse() {
        _val = new Boolean(false);
    }

    /**
     * <pre>
     * 値が OTHER のState3オブジェクトを生成する
     * </pre>
     */
    public static State3 NA() {
        State3 state = new State3();
        state.setNA();
        return state;
    }

    /**
     * <pre>
     * 値が OTHER のState3オブジェクトを生成する
     * </pre>
     * @param addition
     */
    public static State3 NA(String addition) {
        State3 state = new State3();
        state.setNA();
        state.setAddition(addition);
        return state;
    }

    /**
     * <pre>
     * 値が TRUE のState3オブジェクトを生成する
     * </pre>
     */
    public static State3 TRUE() {
        return new State3 (true);
    }

    /**
     * <pre>
     * 値が TRUE のState3オブジェクトを生成する
     * </pre>
     * @param addition
     */
    public static State3 TRUE(String addition) {
        State3 state = new State3(true);
        state.setAddition(addition);
        return state;
    }

    /**
     * <pre>
     * 値が FALSE のState3オブジェクトを生成する
     * </pre>
     */
    public static State3 FALSE() {
        return new State3 (false);
    }

    /**
     * <pre>
     * 値が FALSE のState3オブジェクトを生成する
     * </pre>
     * @param addition
     */
    public static State3 FALSE(String addition) {
        State3 state = new State3(false);
        state.setAddition(addition);
        return state;
    }

    /** 文字出力　*/
    public String toString() {
         if( _val == null ){
            return "n/a"; // return "n/a";
         } else if( _val.booleanValue() ) {
            return "true";
         } else {
            return "false";
         }
    }
    
}
