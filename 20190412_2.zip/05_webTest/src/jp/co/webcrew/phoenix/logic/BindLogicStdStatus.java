package jp.co.webcrew.phoenix.logic;

import jp.co.webcrew.dbaccess.util.Logger;

/**
 * 汎用ロジックの結果を保持するsttausクラス。
 * 
 * @author kurinami
 */
public class BindLogicStdStatus {

    /** レベル：complete */
    public static final int LEVEL_COMPLETE = 0;

    /** レベル：notice */
    public static final int LEVEL_NOTICE = 1;

    /** レベル：warning */
    public static final int LEVEL_WARNING = 2;

    /** レベル：fatal */
    public static final int LEVEL_FATAL = -1;

    /** 正常終了=true, 異常終了=false */
    public boolean result = true;

    /** 0=complete 1=notice 2=warning -1=fatal */
    public int level = LEVEL_COMPLETE;

    /** 出力HTML文字列 */
    public String html = "";

    /** エラーの場合のステータス値。内容はロジック依存 */
    public String errStatus = "";

    /** notice や warning の際に出力するエラーメッセージ(バリデーションのエラーメッセージではない) */
    public String errMsg = "";

    /**
     * エラーのログを出力する。
     * 
     * @param log
     */
    public void writeLog(Logger log) {
        // TODO kurinami 【確認】 このやり方で問題ないか。
        String message = "[" + errStatus + "] " + errMsg;
        switch (level) {
        case LEVEL_COMPLETE:
            log.debug(message);
            break;
        case LEVEL_NOTICE:
            log.info(message);
            break;
        case LEVEL_WARNING:
            log.warn(message);
            break;
        case LEVEL_FATAL:
            log.error(message);
            break;
        }
    }
}
