package jp.co.webcrew.phoenix.sstag.impl;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * ページインデックス用HTML組み立てを行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class PagingIndexExecuter extends SSTagExecuter {

    /** パラメータ名：ページングのリンク先となるURL */
    private static final String BASE_URL_PARAM_KEY = "base_url";

    /** パラメータ名：URLでページ番号を示すパラメータ */
    private static final String PAGE_PARAM_PARAM_KEY = "page_param";

    /** パラメータ名：現在のページ */
    private static final String CURRENT_PAGE_PARAM_KEY = "current_page";

    /** パラメータ名：カレントページ指定がない場合のデフォルトページ */
    private static final String DEFAULT_PAGE_PARAM_KEY = "default_page";

    /** パラメータ名：先頭ページ */
    private static final String TOP_PAGE_PARAM_KEY = "top_page";

    /** パラメータ名：最終ページ */
    private static final String LAST_PAGE_PARAM_KEY = "last_page";

    /** パラメータ名：一度に表示するページ数 */
    private static final String COUNT_PAGE_PARAM_KEY = "count_page";

    /** パラメータ名：先頭ページを表す文字列 */
    private static final String TOP_MARK_PARAM_KEY = "top_mark";

    /** パラメータ名：先頭ページを表す文字列 */
    private static final String LAST_MARK_PARAM_KEY = "last_mark";

    /** パラメータ名：最終ページを表す文字列 */
    private static final String PREV_MARK_PARAM_KEY = "prev_mark";

    /** パラメータ名：１つ前のページを表す文字列 */
    private static final String NEXT_MARK_PARAM_KEY = "next_mark";

    /** パラメータ名：先頭ページを表す <a> タグに付与する class名 */
    private static final String TOP_CLASS_PARAM_KEY = "top_class";

    /** パラメータ名：最終ページを表す <a> タグに付与する class名 */
    private static final String LAST_CLASS_PARAM_KEY = "last_class";

    /** パラメータ名：１つ前のページを表す <a> タグに付与する class名 */
    private static final String PREV_CLASS_PARAM_KEY = "prev_class";

    /** パラメータ名：１つ次のページを表す <a> タグに付与する class名 */
    private static final String NEXT_CLASS_PARAM_KEY = "next_class";

    /** パラメータ名：ページ番号表示の間のセパレータ文字列 */
    private static final String SEPARATOR_PARAM_KEY = "separator";

    //以下、追加したパラメータ
    /** パラメータ名：現在のページ番号に適用するclass */
    private static final String CURRENT_SPAN_CLASS_PARAM_KEY = "current_class";

    /** パラメータ名：ページ数０の場合に表示するHTML */
    private static final String NOPAGE_HTML_PARAM_KEY = "nopage_html";

    /** パラメータ名：ページ数１の場合に表示するHTML */
    private static final String ONEPAGE_HTML_PARAM_KEY = "onepage_html";

    
    /** ロガー */
    private static final Logger log = Logger.getLogger(PagingIndexExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { BASE_URL_PARAM_KEY, PAGE_PARAM_PARAM_KEY, LAST_PAGE_PARAM_KEY, COUNT_PAGE_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            String baseUrl = ValueUtil.nullToStr(parameters.get(BASE_URL_PARAM_KEY));
            String pageParam = ValueUtil.nullToStr(parameters.get(PAGE_PARAM_PARAM_KEY));
            int currentPage = ValueUtil.toint((String) parameters.get(CURRENT_PAGE_PARAM_KEY));
            int defaultPage = ValueUtil.toint((String) parameters.get(DEFAULT_PAGE_PARAM_KEY));
            int topPage = ValueUtil.toint((String) parameters.get(TOP_PAGE_PARAM_KEY));
            int lastPage = ValueUtil.toint((String) parameters.get(LAST_PAGE_PARAM_KEY));
            int countPage = ValueUtil.toint((String) parameters.get(COUNT_PAGE_PARAM_KEY));
            String topMark = ValueUtil.nullToStr(parameters.get(TOP_MARK_PARAM_KEY));
            String lastMark = ValueUtil.nullToStr(parameters.get(LAST_MARK_PARAM_KEY));
            String prevMark = ValueUtil.nullToStr(parameters.get(PREV_MARK_PARAM_KEY));
            String nextMark = ValueUtil.nullToStr(parameters.get(NEXT_MARK_PARAM_KEY));
            String topClass = ValueUtil.nullToStr(parameters.get(TOP_CLASS_PARAM_KEY));
            String lastClass = ValueUtil.nullToStr(parameters.get(LAST_CLASS_PARAM_KEY));
            String prevClass = ValueUtil.nullToStr(parameters.get(PREV_CLASS_PARAM_KEY));
            String nextClass = ValueUtil.nullToStr(parameters.get(NEXT_CLASS_PARAM_KEY));
            String separator = ValueUtil.nullToStr(parameters.get(SEPARATOR_PARAM_KEY));
            //以下、追加したパラメータ
            String currentSpanClass = ValueUtil.nullToStr(parameters.get(CURRENT_SPAN_CLASS_PARAM_KEY));
            String nopageHtml = ValueUtil.nullToStr(parameters.get(NOPAGE_HTML_PARAM_KEY));
            String onepageHtml = ValueUtil.nullToStr(parameters.get(ONEPAGE_HTML_PARAM_KEY));

            
            if(lastPage==0)
            {
            	return nopageHtml;
            }
            else if(lastPage==1)
            {
            	return onepageHtml;
            }
            
            
            // パラメータをつなげるために、?か&を後ろにつける。
            baseUrl += baseUrl.indexOf('?') < 0 ? "?" : "&";

            // パラメータに等号が指定されていない場合、、付与する。
            pageParam += pageParam.endsWith("=") ? "" : "=";

            // 値が指定されていないパラメータにデフォルト値を設定する。
            if (topPage == 0) {
                topPage = 1;
            }
            if (defaultPage == 0) {
                defaultPage = topPage;
            }
            if (currentPage == 0) {
                currentPage = defaultPage;
            }
            if (PhoenixUtil.isEmpty(separator)) {
                separator = "&nbsp;";
            }

            // 各リンクにクラス名が指定されている場合、class="___" の表記に置き換える。
            if (!PhoenixUtil.isEmpty(topClass)) {
                topClass = " class=\"" + topClass + "\"";
            }
            if (!PhoenixUtil.isEmpty(lastClass)) {
                lastClass = " class=\"" + lastClass + "\"";
            }
            if (!PhoenixUtil.isEmpty(prevClass)) {
                prevClass = " class=\"" + prevClass + "\"";
            }
            if (!PhoenixUtil.isEmpty(nextClass)) {
                nextClass = " class=\"" + nextClass + "\"";
            }

            String pattern = "<a href=\"{0}{1}{2}\"{3}>{4}</a>\n";

            StringBuffer sb = new StringBuffer();

            // 最初のページへのリンク
            if (!PhoenixUtil.isEmpty(topMark)) {
                sb.append(MessageFormat.format(pattern, baseUrl, pageParam, topPage, topClass, topMark));
                sb.append(separator);
            }

            // 前のページへのリンク
            if (!PhoenixUtil.isEmpty(prevMark)) {
            	if(currentPage!=1)
            	{
	                int prevPage = Math.max(currentPage - 1, topPage);
	                sb.append(MessageFormat.format(pattern, baseUrl, pageParam, prevPage, prevClass, prevMark));
	                sb.append(separator);
            	}
            }

            // ページ番号を指定したリンク
            int startPage = Math.max(currentPage - countPage / 2, topPage);
            if (startPage + countPage - 1 > lastPage) {
                startPage = Math.max(lastPage - countPage + 1, topPage);
            }
            int endPage = Math.min(startPage + countPage - 1, lastPage);

            for (int i = startPage; i <= endPage; i++) {
                if (i > startPage) {
                    sb.append(separator);
                }
                if (i == currentPage) {
                	
                	if(currentSpanClass.length()==0)
                	{
                        sb.append(i);
                	}
                	else
                	{
                        sb.append("<span class=\""+currentSpanClass+"\" >"+i+"</span>");
                	}
                	
                    sb.append("\n");
                } else {
                    sb.append(MessageFormat.format(pattern, baseUrl, pageParam, i, "", i));
                }
            }

            // 次のページへのリンク
            if (!PhoenixUtil.isEmpty(nextMark)) {
            	if(currentPage!=lastPage)
            	{
	                int nextPage = Math.min(currentPage + 1, lastPage);
	                sb.append(separator);
	                sb.append(MessageFormat.format(pattern, baseUrl, pageParam, nextPage, nextClass, nextMark));
            	}
            }

            // 最後のページへのリンク
            if (!PhoenixUtil.isEmpty(lastMark)) {
                sb.append(separator);
                sb.append(MessageFormat.format(pattern, baseUrl, pageParam, lastPage, lastClass, lastMark));
            }

            return sb.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

}
