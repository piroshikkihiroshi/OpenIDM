package jp.co.webcrew.filters.util;

import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.filters.replace.ReplaceFilter;
import jp.co.webcrew.filters.filters.replace.htmlparser.SSTagReplaceParserCallback;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.httputil.CustomFilterConfig;
import jp.co.webcrew.filters.util.httputil.DummyHttpServletRequest;
import jp.co.webcrew.filters.util.httputil.DummyHttpServletResponse;

/**
 * フィルタ外でReplaceFilter関連の機能を使うためのutilクラス。
 * 
 * @author kurinami
 */
public class ReplaceFilterUtil {

	/**
	 * ReplaceFileterの置換処理部分だけを呼び出す。
	 * 
	 * @param source
	 * @param guid
	 * @return
	 * @throws SQLException
	 * @throws ServletException
	 */
	public static String replace(String source, int guid) throws SQLException,
			ServletException {
		return replace(source, guid, "");
	}

	/**
	 * ReplaceFileterの置換処理部分だけを呼び出す。
	 * 
	 * @param source
	 * @param guid
	 * @param url
	 * @return
	 * @throws SQLException
	 * @throws ServletException
	 */
	public static String replace(String source, int guid, String url)
			throws SQLException, ServletException {

		CustomFilterConfig filterConfig = new CustomFilterConfig();

		ReplaceFilter filter = new ReplaceFilter();
		filter.init(filterConfig);

		DummyHttpServletRequest request = new DummyHttpServletRequest(url);
		DummyHttpServletResponse response = new DummyHttpServletResponse();

		UserInfo userInfo = new UserInfo();
		userInfo.setGuid(Integer.toString(guid));
		userInfo.setGsid("0");
		userInfo.setGsCode("");
		userInfo.setSsid("0");
		userInfo.setLoginFlag(true);
		userInfo.setUserInfoToRequest(request);

		String result = filter.doReplace(source, request, response);

		return result;
	}

	/**
	 * sstagのtype名とクラス名のマップを登録する。
	 * 
	 * @param type type名
	 * @param className クラス名(パッケージ名付き)
	 */
	public static void registSstag(String type, String className) {
		SSTagReplaceParserCallback.registSstag(type, className);
	}

	/**
	 * リダイレクトする際にrequestURLが
	 * www.zubat.net, www.zubat.net, www.zubat.net/car-kaitori/incldue
	 * になってしまうという問題の対応として、本来のドメインを取得する
	 * ための処理。
	 * @param request
	 * @return
	 */
	public static String getActualServerName(HttpServletRequest request) {
		String serverName = request.getServerName();
    	int cammaIndex = serverName.indexOf(",");
    	if (cammaIndex != -1)
    	{
    		serverName = serverName.substring(0, cammaIndex);
    	}
    	return serverName;
	}
	
	/**
	 * リダイレクトする際にrequestURLが
	 * www.zubat.net, www.zubat.net, www.zubat.net/car-kaitori/incldue
	 * になってしまうという問題の対応として、本来のURLからサイトIDを取得する
	 * ための処理。
	 * @param request
	 * @return
	 */
	public static String getActualSiteId(HttpServletRequest request) {
		String serverName = request.getServerName();
		String requestUri = request.getRequestURI();
    	int cammaIndex = serverName.indexOf(",");
    	String siteId = "";
    	if (cammaIndex != -1)
    	{
    		String url = "http://" + serverName.substring(0, cammaIndex) + requestUri;
        	Map siteInfo = SiteMstDb.getInstance().getSiteInfo(url);
        	if (siteInfo != null)
        	{
        		siteId = ((Integer)siteInfo.get("site_id")).toString();
        	}
    	}
    	return siteId;
	}
	
	
	public static void main(String[] args) {

		try {
			String source = "こんなんで本当にうまくいくかな？$$urlkwd.kuri99$$$$urlkwd.service$$名前$$member_mst.name1$$<sstag type='test'>value1=gegege value2=bababa</sstag>$$guid$$むりじゃね？";
			System.out.println(source);
			System.out.println("----------");
			String result = replace(source, 8224, "http://sbf.uso.jp/ranking/money");
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
