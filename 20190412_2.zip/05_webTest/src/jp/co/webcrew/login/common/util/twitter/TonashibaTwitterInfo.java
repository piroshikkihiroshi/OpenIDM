/**
 * 
 */
package jp.co.webcrew.login.common.util.twitter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jp.co.webcrew.dbaccess.util.Logger;


/**
 * とな芝用TwitterInfoクラス
 * @author shintaro.kurihara
 *
 */
public class TonashibaTwitterInfo extends AbstractTwitterInfo{


	private static Logger log = Logger.getLogger(TonashibaTwitterInfo.class);
	
	
	/**
	 * System_Prperty Keysの設定
	 *
	 */
	{
		autoTweetTextKeyName = "TONASHIBA_TWITTER_AUTO_TWEET_TEXT";
		consumerKeyKeyName = "TONASHIBA_TWITTER_CONSUMER_KEY";
		consumerSecretKeyName ="TONASHIBA_TWITTER_CONSUMER_SECRET";
		appUserScreennameKeyName ="TONASHIBA_TWITTER_APP_USER_SCREENNAME";
		appUserPasswordKeyName ="TONASHIBA_TWITTER_APP_USER_PASSWORD";
		callBackUrlKeyName ="TONASHIBA_TWITTER_CALLBACKURL";
		maxKeepingTweetNumer = 150;
		onepageTweetsNumber = 5;
		elapsedTimeFormatID = 1;
	}
	
	

	/**
	 *　表示ように成型したリストを作成
	 *  @params isDevelopment テスト環境フラグ
	 */
	public List  getDisplayTweetList(boolean isDevelopment) throws Exception{
		List resultList = new ArrayList();
		
		String[] searchQuarys = new String[4];
		if(isDevelopment){
			searchQuarys[0] = "@tonasen";
			searchQuarys[1] = "#tonashiba";
			searchQuarys[2] = "#tonasen";
			searchQuarys[3] = "#tonakuri";
		}else{
			searchQuarys[0] = "@tonasen";
			searchQuarys[1] = "#tonashiba";
			searchQuarys[2] = "#tonasen_dev";
			searchQuarys[3] = "#tonakuri_dev";
		}
		//検索条件よりリストを取得
		List _templist =  TwitterUtil.getTweetsList(searchQuarys, new Integer(this.maxKeepingTweetNumer));
		TweetBean _temp = null;
		//つぶやきから不必要な文章を削除する
		for(Iterator it = _templist.iterator(); it.hasNext();){
			_temp = (TweetBean)it.next();
			
			//ハッシュタグ、ショートURLを削除
			for(int i = 0; i < searchQuarys.length; i++){
				//返信は残す
				if(searchQuarys[i].indexOf("@") == -1){
					_temp.setTweetText(_temp.getTweetText().replaceAll(searchQuarys[i], " ") );
				}
			}
			_temp.setTweetText(_temp.getTweetText().replaceAll("http://bit.ly/bHyCAK"," "));
			_temp.setTweetText(_temp.getTweetText().replaceAll("http://bit.ly/9knmEd"," "));
			resultList.add(_temp);			
		}
		return resultList;
	}
	
	/**
	 * 親クラスからのオーバーライド、間違って呼んじゃったときのために
	 * 引数有りリストを呼ぶ。
	 */
	public List getDisplayTweetList() throws Exception{
		return getDisplayTweetList(true);
	}
	
//	/**
//	 *　表示サイズに合わせたLISTを返す、Stringの数値を引数にする場合
//	 *
//	 */
//	public List getDisplayTweetList(String tweetPageNumberStr,List tweetList) throws Exception{
//		
//		int tweetPageNumber = 0;
//		try{
//			tweetPageNumber = Integer.parseInt(tweetPageNumberStr);
//		}catch(NumberFormatException e){
//			//数値以外が来た場合はdefault値を追加
//			tweetPageNumber = 1;
//		}catch(NullPointerException e){
//			//nullだった場合
//			tweetPageNumber = 1;
//		}
//		return getDisplayTweetList(tweetPageNumber,tweetList);
//	}*/
}
