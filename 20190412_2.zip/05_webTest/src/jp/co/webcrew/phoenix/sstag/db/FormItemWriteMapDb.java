package jp.co.webcrew.phoenix.sstag.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.sstag.bean.FormItemWriteMapBean;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.TblMetaMstBean;
import jp.co.webcrew.phoenix.vtable.db.MetaDb;

/**
 * フォーム項目登録テーブル情報を管理するdbクラス。
 * 
 * @author kurinami
 */
public class FormItemWriteMapDb {

    /** フォーム項目登録テーブル情報を取得するためのsql */
    private static final String SELECT_FORM_ITEM_WRITE_MAP = ""
            + "select * from (schema_name).form_item_write_map where site_id = ? and form_id = ? order by map_site_id, map_tbl_id, num ";

    /**
     * フォーム項目登録テーブル情報を書き込み先テーブルごとにまとめて返す。
     * 
     * @param siteId
     * @param formId
     * @return
     * @throws SQLException
     */
    public static Map<TblMetaMstBean, List<FormItemWriteMapBean>> getFormItemWriteMapList(int siteId, String formId)
            throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            Map<TblMetaMstBean, List<FormItemWriteMapBean>> formItemWriteMapList = new HashMap<TblMetaMstBean, List<FormItemWriteMapBean>>();

            TblMetaMstBean lastTblMetaMst = null;

            // フォーム項目登録テーブル情報を取得する。
            dbAccess.prepareStatement(SELECT_FORM_ITEM_WRITE_MAP);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, formId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                FormItemWriteMapBean formItemWriteMap = new FormItemWriteMapBean();
                formItemWriteMap.setSiteId(rs.getInt("site_id"));
                formItemWriteMap.setFormId(ValueUtil.nullToStr(rs.getString("form_id")));
                formItemWriteMap.setItemId(PhoenixUtil.split(ValueUtil.nullToStr(rs.getString("item_id")), ","));
                formItemWriteMap.setNum(rs.getInt("num"));
                formItemWriteMap.setMapSiteId(rs.getInt("map_site_id"));
                formItemWriteMap.setMapTblId(ValueUtil.nullToStr(rs.getString("map_tbl_id")));
                formItemWriteMap.setMapClmId(ValueUtil.nullToStr(rs.getString("map_clm_id")));
                formItemWriteMap.setKeyFlag(ValueUtil.nullToStr(rs.getString("key_flag")).equals("1"));
                formItemWriteMap.setSep(ValueUtil.nullToStr(rs.getString("sep")));

                if (lastTblMetaMst == null || lastTblMetaMst.getSiteId() != formItemWriteMap.getMapSiteId()
                        || !lastTblMetaMst.getTblId().equals(formItemWriteMap.getMapTblId())) {
                    lastTblMetaMst = MetaDb.getTblMetaMst(formItemWriteMap.getMapSiteId(), formItemWriteMap
                            .getMapTblId());
                    formItemWriteMapList.put(lastTblMetaMst, new ArrayList<FormItemWriteMapBean>());
                }
                formItemWriteMapList.get(lastTblMetaMst).add(formItemWriteMap);
            }

            return formItemWriteMapList;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

}
