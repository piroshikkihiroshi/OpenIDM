package jp.co.webcrew.phoenix.sstag.impl;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.phoenix.sstag.db.OrderInfoDb;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;

/**
 * オーダー情報の取得を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class GetOrderInfoExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：直近（新しい方）からか古い方から取得するかを指定 */
    // TODO kurinami 【確認】 typeというパラメータは使えない。
    private static final String ORDER_TYPE_PARAM_KEY = "order_type";

    /** パラメータ名：先頭から何番目のレコードを取得するかを指定 */
    private static final String OFFSET_PARAM_KEY = "offset";

    /** パラメータ名：テーマID */
    private static final String THEMA_PARAM_KEY = "thema";

    /** パラメータ名：グローバルオーダーID */
    private static final String GOID_PARAM_KEY = "goid";

    /** パラメータ名：読み込んだ情報をどこに保存するか */
    private static final String BIND_PARAM_KEY = "bind";

    /** ロガー */
    private static final Logger log = Logger.getLogger(GetOrderInfoExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String orderType = ValueUtil.nullToStr(parameters.get(ORDER_TYPE_PARAM_KEY)).toLowerCase();
            int offset = ValueUtil.toint((String) parameters.get(OFFSET_PARAM_KEY));
            String thema = ValueUtil.nullToStr(parameters.get(THEMA_PARAM_KEY));
            String goid = ValueUtil.nullToStr(parameters.get(GOID_PARAM_KEY));
            String bind = ValueUtil.nullToStr(parameters.get(BIND_PARAM_KEY)).toLowerCase();

            // オーダー情報の取得方向が指定されていない場合、
            if (PhoenixUtil.isEmpty(orderType)) {
                orderType = "new";
            }

            // 取得するレコード位置が指定されていない場合、
            if (offset == 0) {
                offset = 1;
            }

            // テーマIDが指定されていない場合、
            if (PhoenixUtil.isEmpty(thema)) {
                // TODO kurinami 【未実装】 カレントテーマの指定
            }

            // ログインしていない場合は、何もしない。
            if (!SessionFilterUtil.isLogined(request)) {
                return "";
            }

            // ユーザIDを取得する。
            String guid = SessionFilterUtil.getGuid(request);

            // 該当するオーダー情報を取得する。
            Map<String, ClmDataBean> record;
            if (PhoenixUtil.isEmpty(goid)) {
                record = OrderInfoDb.getOrderInfo(siteId, thema, guid, !orderType.equalsIgnoreCase("old"), offset);
            } else {
                record = OrderInfoDb.getOrderInfo(siteId, thema, guid, goid);
            }

            // オーダー情報をセッションストアに書き込む。
            StoreUtil.setOrderInfo(request, record, bind);

            // 置換パラメータに登録する。
            SstagUtil.setOrderInfoReplaceParam(request, record);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

}
