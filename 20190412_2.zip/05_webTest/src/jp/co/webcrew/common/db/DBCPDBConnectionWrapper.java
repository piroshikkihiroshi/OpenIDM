/*
 * Generator Runtime Servlet Framework
 * Copyright (C) 2004 Rick Knowles
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package jp.co.webcrew.common.db;

import generator.runtime.db.AbstractDBConnectionWrapper;
import generator.runtime.db.DBConnectionWrapperSource;
import generator.runtime.exception.ApplicationException;
import generator.runtime.log.Log;
import generator.runtime.servlet.ErrorNotificationMail;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;


/**
 * Models a connection object within the rk framework. One of these objects
 * is allocated at the beginning of the request, and when it's finished, we
 * refresh it and send it back to the pool. This abstracts the read-only/
 * read-write connection behaviour, and keeps the ugly stuff like sequence
 * emulation out of sight.
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 */
public class DBCPDBConnectionWrapper extends AbstractDBConnectionWrapper {
    private static final Log log = new Log(DBCPDBConnectionWrapper.class);

    private DBCPDBConnectionWrapperSource wrapperSource;
    private DataSource dataSource;
    private Connection readWriteConnection;

    public DBCPDBConnectionWrapper(DBCPDBConnectionWrapperSource wrapperSource, 
            DataSource dataSource, Log readLogStream, Log writeLogStream) {
        super(readLogStream, writeLogStream);
        this.wrapperSource = wrapperSource;
        this.dataSource = dataSource;
    }

    public DBConnectionWrapperSource getSource() {
        return this.wrapperSource;
    }
    
    /**
     * Close this wrapper - ie we're finished with it. If successful commit, then
     * release any connections, and notify the wrapper pool to release us.
     */
    public void closeWrapper(boolean successfully) {
        try {
            forceCommitRollback(successfully);
        } catch (SQLException err) {
            throw new ApplicationException("Couldn't commit!!", err);
        }
    }

    /**
     * Get the current connection. This is intended to be called by the dbpeer
     * class, because only it can decide the type of operation (ie read or write).
     */
    public Connection getConnection(boolean writeable)
                             throws SQLException {
        if (this.readWriteConnection == null) {
            this.readWriteConnection = this.dataSource.getConnection();
            this.readWriteConnection.setAutoCommit(false);
        }
        return this.readWriteConnection;
    }
    
    /**
     * For this simple implementation just return the same connection.
     * Note this is actually incorrect, since it returns the same connection 
     * that is probably auto-commit disabled, but it achieves our purpose for
     * sequence enabled dbs.
     */
    public Connection getNonTransactionConnection() throws SQLException {
        log.warning("WARNING: Returning auto-commit disabled " +
                "connection for getNonTransactionConnection(). Switch to " +
                "another connection pool to stop this behaviour"); 
        return getConnection(true);
    }
    
    /**
     * Does nothing in this implementation
     */
    public void releaseNonTransactionConnection(Connection nonTrans) 
            throws SQLException {
    }

    public void forceCommitRollback(boolean successfully) throws SQLException {
        
        SQLException problem = null;
        if (this.readWriteConnection != null) {
            try {
                if (successfully) {
                    this.readWriteConnection.commit();
                }
            } catch (SQLException err) {
                log.warning("Commit failed on read-write connection", err);
                if ((this.wrapperSource != null) && (this.wrapperSource.getErrorMailProperties() != null)) {
                    new ErrorNotificationMail(err, null, this.wrapperSource.getErrorMailProperties()).send();
                }
                problem = new SQLException("Error committing read-write connection: " + err.toString());
            } finally {
                try {
                    this.readWriteConnection.close();
                } catch (SQLException err) {
                    log.error("Error closing dbcp connection", err);
                    if ((problem == null) && (this.wrapperSource != null) && 
                                (this.wrapperSource.getErrorMailProperties() != null)) {
                        new ErrorNotificationMail(err, null, 
                                this.wrapperSource.getErrorMailProperties()).send();
                    }
                }
                this.readWriteConnection = null;
            }
        }

//        if (this.readWriteConnection != null) {
//            // Commit if we don't have any reason to prevent it, and transaction was successful
//            boolean needsRollback = !successfully;
//            if (!needsRollback) {
//                try {
//                    if ((this.readWriteConnection != null) && 
//                            !this.readWriteConnection.isClosed() &&
//                            !this.readWriteConnection.isReadOnly() && 
//                            !this.readWriteConnection.getAutoCommit()) {
//                        log.frameworkDebug("Committing read-write connection: " + this.readWriteConnection);
//                        this.readWriteConnection.commit();
//                    }
//                } catch (Throwable err) {
//                    log.warning("Commit failed on read-write connection", err);
//                    if ((this.wrapperSource != null) && (this.wrapperSource.getErrorMailProperties() != null)) {
//                        new ErrorNotificationMail(err, null, this.wrapperSource.getErrorMailProperties()).send();
//                    }
//                    problem = new SQLException("Error committing read-write connection: " + err.toString());
//                    needsRollback = true;
//                }
//            }
//            if (needsRollback) {
//                if (!nonExceptionRollback(this.readWriteConnection) && (problem == null)) {
//                    problem = new SQLException("Error rolling back read-write connection");
//                }
//            }
//            this.wrapperSource.releaseConnection(this.readWriteConnection, true);
//            this.readWriteConnection = null;
//        }
        processEntityPeerActionNotifications(successfully && (problem == null)); 
        
        // Throw the error if one was found
        if (problem != null) {
            reset();
            throw problem;
        } else {
            writeExecutedSQLToLog(successfully);
            reset();
        }
    }
}
