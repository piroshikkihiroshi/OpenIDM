package jp.co.webcrew.phoenix.sstag.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.sstag.bean.FormCssInfoBean;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * フォーム項目を管理するdbクラス。
 * 
 * @author kurinami
 */
public class FormItemDb {

    /** フォーム項目一覧を取得するためのsql */
    private static final String SELECT_LIST = ""
            + "select form_item.*, nvl(form_item.html_tmpl, form_item_html_map.html_tmpl) as html \n"
            + "  from (schema_name).form_item left outer join (schema_name).form_item_html_map \n"
            + "                                            on form_item.site_id = form_item_html_map.site_id \n"
            + "                                           and form_item.type = form_item_html_map.item_type \n"
            + "                                           and form_item_html_map.map_id = nvl(?, 'default') \n"
            + " where form_item.site_id = ? and form_item.form_id = ? ";

    /** フォーム出力css定義一覧を取得するためのsql */
    private static final String SELECT_CSS_INFO_LIST = ""
            + "select * from (schema_name).form_css_info where site_id = ? and form_id = ? and item_id = ? order by num ";

    /**
     * フォーム項目一覧を返す。
     * 
     * @param siteId
     * @param formId
     * @param groupId
     * @param include
     * @param exclude
     * @param mapId
     * @return
     * @throws SQLException
     */
    public static List<FormItemBean> getList(int siteId, String formId, String[] groupId, String[] include,
            String[] exclude, String mapId) throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            List<FormItemBean> list = new ArrayList<FormItemBean>();

            // sqlを組み立てる。
            StringBuffer sb = new StringBuffer(SELECT_LIST);
            if (!PhoenixUtil.isEmpty(groupId)) {
                sb.append(" and (form_item.group_id in (" + DBAccess.getInList(groupId) + ")");
                if (!PhoenixUtil.isEmpty(include)) {
                    sb.append(" or form_item.item_id in (" + DBAccess.getInList(include) + ")");
                }
                sb.append(")");
            }
            if (!PhoenixUtil.isEmpty(exclude)) {
                sb.append(" and form_item.item_id not in (" + DBAccess.getInList(exclude) + ")");
            }
            sb.append(" order by form_item.sort_num");

            // フォーム項目一覧を取得する。
            dbAccess.prepareStatement(sb.toString());
            dbAccess.setString(1, mapId);
            dbAccess.setInt(2, siteId);
            dbAccess.setString(3, formId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                FormItemBean formItem = new FormItemBean();
                formItem.setSiteId(rs.getInt("site_id"));
                formItem.setFormId(ValueUtil.nullToStr(rs.getString("form_id")));
                formItem.setItemId(ValueUtil.nullToStr(rs.getString("item_id")));
                formItem.setGroupId(ValueUtil.nullToStr(rs.getString("group_id")));
                formItem.setSortNum(rs.getInt("sort_num"));
                formItem.setType(ValueUtil.nullToStr(rs.getString("type")));
                formItem.setTitle(ValueUtil.nullToStr(rs.getString("title")));
                formItem.setCaution1(ValueUtil.nullToStr(rs.getString("caution1")));
                formItem.setCaution2(ValueUtil.nullToStr(rs.getString("caution2")));
                formItem.setCaution3(ValueUtil.nullToStr(rs.getString("caution3")));
                formItem.setCaution4(ValueUtil.nullToStr(rs.getString("caution4")));
                formItem.setCaution5(ValueUtil.nullToStr(rs.getString("caution5")));
                formItem.setRequire(ValueUtil.nullToStr(rs.getString("require_flag")).equals("1"));
                formItem.setClmSize(ValueUtil.toInteger(rs.getString("clm_size")));
                formItem.setRowSize(ValueUtil.toInteger(rs.getString("row_size")));
                formItem.setLeast(ValueUtil.toInteger(rs.getString("least")));
                formItem.setMost(ValueUtil.toInteger(rs.getString("most")));
                formItem.setMin(ValueUtil.toDouble(rs.getString("min")));
                formItem.setMax(ValueUtil.toDouble(rs.getString("max")));
                formItem.setLimitChar(ValueUtil.nullToStr(rs.getString("limit_char")));
                formItem.setLimitRegex(ValueUtil.nullToStr(rs.getString("limit_regex")));
                formItem.setWcharConv(rs.getInt("wchar_conv"));
                formItem.setDateTimeType(ValueUtil.nullToStr(rs.getString("date_time_type")));
                formItem.setDateTimeSep(ValueUtil.nullToStr(rs.getString("date_time_sep")));
                formItem.setDateTimeInput(ValueUtil.nullToStr(rs.getString("date_time_input")));
                formItem.setSelMstSiteId(rs.getInt("sel_mst_site_id"));
                formItem.setSelMstId(ValueUtil.nullToStr(rs.getString("sel_mst_id")));
                formItem.setInitData1(ValueUtil.nullToStr(rs.getString("init_data1")));
                formItem.setInitData2(ValueUtil.nullToStr(rs.getString("init_data2")));
                formItem.setHtmlTmpl(ValueUtil.nullToStr(rs.getString("html")));
                formItem.setDispStat(ValueUtil.nullToStr(rs.getString("disp_stat")));
                list.add(formItem);
            }

            // 各フォーム出力css定義一覧を取得する。
            for (FormItemBean formItem : list) {
                List<FormCssInfoBean> formCssInfoList = getCssInfoList(dbAccess, siteId, formId, formItem.getItemId());
                formItem.setFormCssInfoList(formCssInfoList);
            }

            return list;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * フォーム出力css定義一覧を返す。
     * 
     * @param dbAccess
     * @param siteId
     * @param formId
     * @param itemId
     * @return
     * @throws SQLException
     */
    private static List<FormCssInfoBean> getCssInfoList(DBAccess dbAccess, int siteId, String formId, String itemId)
            throws SQLException {

        ResultSet rs = null;
        try {

            List<FormCssInfoBean> list = new ArrayList<FormCssInfoBean>();

            // フォーム出力css定義一覧を取得する。
            dbAccess.prepareStatement(SELECT_CSS_INFO_LIST);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, formId);
            dbAccess.setString(3, itemId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                FormCssInfoBean formItem = new FormCssInfoBean();
                formItem.setSiteId(rs.getInt("site_id"));
                formItem.setFormId(ValueUtil.nullToStr(rs.getString("form_id")));
                formItem.setItemId(ValueUtil.nullToStr(rs.getString("item_id")));
                formItem.setVarName(ValueUtil.nullToStr(rs.getString("var_name")));
                formItem.setNum(rs.getInt("num"));
                formItem.setVarValue(ValueUtil.nullToStr(rs.getString("var_value")));
                list.add(formItem);
            }

            return list;

        } finally {
            DBAccess.close(rs);
        }
    }
}
