package jp.co.webcrew.filters.batch;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.SessionUtil;

/**
 * 古くなったサイトセッションをきれいにするbatchクラス。
 * 
 * @author kurinami
 */
public class SiteSessionCleanBatch extends BaseBatch {

	/** システムプロパティ値 ： サイトセッションタイムアウト */
	public static final String SITE_SESSION_TIMEOUT = "SITE_SESSION_TIMEOUT";

	/** システムプロパティ値 ： サイトセッション滞在上限時間 */
	public static final String SITE_SESSION_STAY_LIMIT = "SITE_SESSION_STAY_LIMIT";

	/** システムプロパティ値 ： サイトセッション滞在上限チェック経過時間 */
	public static final String SITE_SESSION_STAY_LIMIT_CHECK_TERM = "SITE_SESSION_STAY_LIMIT_CHECK_TERM";

	/** サイトセッション検索用用SQL */
	private static final String OLD_SITE_SESSION_SELECT = ""
			+ "select * \n"
			+ "  from site_session \n"
			+ " where ((site_session.last_datetime <= to_char(sysdate - numtodsinterval(?, 'second'), 'YYYYMMDDHH24MISS')) \n"
			+ "    or (site_session.mk_datetime <= to_char(sysdate - numtodsinterval(?, 'second'), 'YYYYMMDDHH24MISS') and site_session.last_datetime <= to_char(sysdate - numtodsinterval(?, 'second'), 'YYYYMMDDHH24MISS'))) \n"
			+ " order by ssid";

	/** サイトセッションロック用SQL */
	private static final String SITE_SESSION_SELECT_FOR_UPDATE = "select * from site_session where ssid = ? for update";

	/** システムプロパティ取得用SQL */
	private static final String SYSTEM_PROPERTIES_SELECT = "select * from system_properties where name = ?";

	/**
	 * 指定されたシステムプロパティの値を返す。
	 * 
	 * @param dbAccess
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	private String getSystemPropertiesValue(DBAccess dbAccess, String name)
			throws SQLException {

		ResultSet rs = null;
		try {

			String value = "";

			// ポイント発生ワーク情報を検索する。
			dbAccess.prepareStatement(SYSTEM_PROPERTIES_SELECT);
			dbAccess.setString(1, name);
			rs = dbAccess.executeQuery();

			if (dbAccess.next(rs)) {
				value = ValueUtil.nullToStr(rs.getString("value"));
			} else {
				throw new SQLException("システムプロパティ[" + name + "]取得エラー");
			}

			return value;

		} finally {
			DBAccess.close(rs);
		}

	}

	/**
	 * 指定されたvalue値を<br>
	 * 末尾の時間の単位を見て秒にして返す。<br>
	 * d : 日<br>
	 * h : 時<br>
	 * m : 分<br>
	 * s : 秒<br>
	 * 
	 * @param value
	 * @return
	 */
	private static int toSecondValue(String value) {
		char postfix = ' ';
		int number = 0;
		if (value.length() > 0) {
			postfix = value.charAt(value.length() - 1);
			number = ValueUtil.toint(value.substring(0, value.length() - 1));
		}

		if (number != 0) {
			switch (postfix) {
			case 'd':
				return number * 24 * 60 * 60;
			case 'h':
				return number * 60 * 60;
			case 'm':
				return number * 60;
			case 's':
				return number;
			}
		}

		return 0;
	}

	/**
	 * 古くなったサイトセッションの一覧を返す。
	 * 
	 * @param dbAccess
	 * @return
	 * @throws SQLException
	 */
	private List getSsidList(DBAccess dbAccess) throws SQLException {

		// サイトセッションのタイムアウト時間(秒)
		int siteSessionTimeout = toSecondValue(getSystemPropertiesValue(
				dbAccess, SITE_SESSION_TIMEOUT));

		// サイトセッションの滞在上限時間(秒)
		int siteSessionStayLimit = toSecondValue(getSystemPropertiesValue(
				dbAccess, SITE_SESSION_STAY_LIMIT));

		// サイトセッションの滞在上限の確認対象となるラストアクセスからの経過時間(秒)
		int siteSessionStayLimitCheckTerm = toSecondValue(getSystemPropertiesValue(
				dbAccess, SITE_SESSION_STAY_LIMIT_CHECK_TERM));

		ResultSet rs = null;
		try {

			List ssidList = new ArrayList();

			// 古くなっているサイトセッションを検索する。
			dbAccess.prepareStatement(OLD_SITE_SESSION_SELECT);
			dbAccess.setInt(1, siteSessionTimeout);
			dbAccess.setInt(2, siteSessionStayLimit);
			dbAccess.setInt(3, siteSessionStayLimitCheckTerm);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				ssidList.add(rs.getString("ssid"));
			}
			DBAccess.close(rs);

			return ssidList;

		} finally {
			DBAccess.close(rs);
		}

	}

	/**
	 * 古くなったサイトセッションをきれいにする
	 * 
	 * @param dbAccess
	 * @throws SQLException
	 */
	protected void execute(DBAccess dbAccess) throws SQLException {

		// 古くなったサイトセッションの一覧を取得する。
		List ssidList = getSsidList(dbAccess);

		// 古くなったサイトセッションに関する情報をログに移す。
		for (int i = 0; i < ssidList.size(); i++) {
			String ssid = (String) ssidList.get(i);

			try {

				// トランザクションを開始する。
				dbAccess.setAutoCommit(false);

				String gsid = null;
				dbAccess.prepareStatement(SITE_SESSION_SELECT_FOR_UPDATE);
				dbAccess.setString(1, ssid);
				ResultSet rs = dbAccess.executeQuery();
				if (dbAccess.next(rs)) {
					gsid = rs.getString("gsid");
				}
				DBAccess.close(rs);

				if (gsid != null) {
					SessionUtil.deleteSiteSession(dbAccess, gsid);
				}

				// コミットする。
				dbAccess.commit();

			} catch (SQLException e) {
				// ロールバックする。
				dbAccess.rollback();
				throw e;
			}
		}
	}

	/**
	 * バッチ処理を行う。
	 * 
	 * @param argv
	 */
	public static void main(String[] argv) {
		new SiteSessionCleanBatch().batch(argv);
	}
}
