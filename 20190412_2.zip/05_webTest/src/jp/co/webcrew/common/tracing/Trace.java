package jp.co.webcrew.common.tracing;

import javax.servlet.http.HttpServletRequest;

/**
 * User tracking trace definition interface
 */
public interface Trace {

    /**
     * Override this method to record the start of the trace
     */
    public abstract void traceRequest(HttpServletRequest request, 
            String path, String promoCode);
    
    /**
     * Override this method to record the end of the trace. Note that the 
     * mapping and forward params are deprecated and passed in as null.
     */
    public abstract void traceComplete(HttpServletRequest request);
}
