package jp.co.webcrew.login.common.db.util;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * <pre>
 * データベースユーティティ
 * 
 * </pre>
 * 
 * @author Fu
 * 
 */
public class ZubatDbUtil {

    /** hikkoshiサイトへ接続名 ユーザーはhikkoshiです。 */
    public final static String HIKKOSHI_DB = "hikkoshi";

    /** 車買取サイトへ接続名です。 */
    public final static String SATEIOMAKASE_DB = "sateiomakase";

    /** 接続名 ユーザーはstepengineです。 */
    public final static String STEPENGINE_DB = "stepengine";

    /** SPIアプリサーバ接続名 ユーザーはSPIです。 */
    public final static String SPI_DB = "spi";

    /**
     * @return hikkoshiサイト用の接続
     * @throws SQLException
     */
    public static DBAccess getHikkoshiDb() throws SQLException {
        // hikkoshiサイト用の接続を返す
        return new DBAccess(HIKKOSHI_DB);
    }

    /**
     * @return 車買取サイト用の接続
     * @throws SQLException
     */
    public static DBAccess getSateiomakaseDb() throws SQLException {
        // 車買取サイト用の接続を返す
        return new DBAccess(SATEIOMAKASE_DB);
    }

    /**
     * @return stepengineサイト用の接続
     * @throws SQLException
     */
    public static DBAccess getStepengineDb() throws SQLException {
        // stepengineサイト用の接続を返す
        return new DBAccess(STEPENGINE_DB);
    }

    /**
     * @return SPIアプリサーバ用の接続
     * @throws SQLException
     */
    public static DBAccess getSpiDb() throws SQLException {
        // SPIアプリサーバ用の接続を返す
        return new DBAccess(SPI_DB);
    }
}
