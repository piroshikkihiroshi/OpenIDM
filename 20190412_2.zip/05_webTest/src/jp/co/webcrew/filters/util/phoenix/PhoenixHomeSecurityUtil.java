package jp.co.webcrew.filters.util.phoenix;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.util.phoenix.RowData;
import jp.co.webcrew.login.common.db.MailTemplateUtil;
import jp.co.webcrew.login.common.db.step.StepUserInfo;

public class PhoenixHomeSecurityUtil
{
private static final Logger log = Logger.getLogger(PhoenixLogicUtil.class);
	
	public static List returnCompanyList (DBAccess db, String zip, String prefId) throws Exception {
		
		ResultSet rs = null;
		int rowIndex = 0;
        //スクリーニング該当会社リスト
        List hitCompList = new ArrayList();
		try {
			//都道府県IDの左のゼロがあったらトリム
	    	if (prefId.startsWith("0")) {
	    		prefId = prefId.substring(1);
	    	}
			
			//会社一覧を取得
		    String conditionComp = "";
		    List compList = new ArrayList();
		    
		    rs = PhoenixLogicUtil.querySort(db, "11900", "move_house", "company_mst", "company_id", 
		    		                 "company_id", "!=", "99999", null, null, null, null, null, null, "asc", true);
	        while (rs.next()) {
	        	PhoenixLogicUtil.setRowData(compList, rs.getLong("rec_id") , rs.getString("clm_id"), 
	                                 rs.getString("key_data"), null, rs.getString("up_datetime"));
	        }
		    DBAccess.close(rs);
			
		    Iterator compIter = compList.iterator();
		    
		    while (compIter.hasNext()) {
		    	
			    //都道府県スクリーニング
		        RowData compRow = (RowData)compIter.next();
		        
		        log.info("会社ID：" + compRow.get("company_id"));
		        
		        //会社IDを指定して「scr_pref_mst」テーブルを検索
		        String conditionPref = " AND data.clm_id = 'pref_id' \n"
		            + " AND EXISTS (SELECT 1 FROM move_house.clm_data data1 \n" 
		            + " WHERE data.rec_id = data1.rec_id \n" 
		            + " AND data1.tbl_id = 'scr_pref_mst' \n"
		            + " AND data1.clm_id = 'company_id' \n"
		            + " AND data1.key_data = '" + compRow.get("company_id") + "') \n";
		        
		        rs = PhoenixLogicUtil.query(db, 11900, "move_house", "scr_pref_mst", conditionPref);
		        boolean isHit = false;
		        
		        if (rs.next()) {
		        	String prefList = PhoenixLogicUtil.getClmData(rs);
		            
		            //都道府県リストを改行で分割し、配列にする。
		            prefList = prefList.replaceAll("\r\n", "\n");
		            String [] prefListArray = prefList.split("\n");
		            
		            for (int i = 0; i < prefListArray.length; i++) {
		                if (prefListArray[i].equals(prefId)) {
		                    //該当会社リストに追加する。
		                    hitCompList.add(compRow);
		                    rowIndex++;
		                    isHit = true;
		                    break;
		                }
		            }
		        }
		        DBAccess.close(rs);
		        
		        //都道府県スクリーニングで合致している場合は完了する。
		        if (isHit || zip.equals("")) {
		            continue;
		        }
		        
		      //郵便番号スクリーニング
		        String now = PhoenixLogicUtil.currentDateTime();
		        String zipSql = "SELECT 1 AS result FROM move_house.scr_zip_mst \n"
		                        + " WHERE site_id = ? AND company_id = ? AND zip_code = ?"
		                        + " AND invalid_flg = 0 AND ? BETWEEN bgn_date AND end_date";
		        
		        db.prepareStatement(zipSql);
		        db.setInt(1, 11900);
		        db.setInt(2, ValueUtil.toint(compRow.get("company_id")));
		        db.setString(3, zip);
		        db.setString(4, now);
		        rs = db.executeQuery();
		        
		        if (rs.next()) {
		            if (! rs.getString("result").equals("")) {
		                //該当会社リストに追加する。
		                hitCompList.add(compRow);
		                rowIndex++;
		            }
		        }
		        DBAccess.close(rs);
		    }
		} finally {
			DBAccess.close(rs);
		}
		return hitCompList;
    }
	
	/**
     * テストユーザがどうか判定１
     * @param db
     * @param orderId
     * @return
     * @throws SQLException
     */
    public static boolean isTestUser(DBAccess db, StepUserInfo userInfo) throws SQLException {
    	ResultSet rs = null;
        String sql=
            "SELECT COMMON.IS_TEST_USER(?,?,?,?,?) as test_user_flg FROM dual";
        
        String nameKanji1 = PhoenixLogicUtil.get(userInfo, "name_kanji_1");
        String nameKanji2 = PhoenixLogicUtil.get(userInfo, "name_kanji_2");
        String nameKana1  = PhoenixLogicUtil.get(userInfo, "name_kana_1");
        String nameKana2  = PhoenixLogicUtil.get(userInfo, "name_kana_2");
        String email      = PhoenixLogicUtil.get(userInfo, "email");
       try{
	       db.prepareStatement(sql);
	       db.setString(1, nameKanji1);
	       db.setString(2, nameKanji2);
	       db.setString(3, nameKana1);
	       db.setString(4, nameKana2);
	       db.setString(5, email);
	       
	       rs = db.executeQuery();
	       rs.next();
	       
	       boolean isTestUser;
	       if(rs.getString("test_user_flg").equals("0"))
	       {
	    	   isTestUser=false;
	       }
	       else
	       {
	    	   isTestUser=true;
	       }
	       rs.close();
	       return isTestUser;
       }
       finally{
    	   DBAccess.close(rs);
       }
    }
    
    public static boolean isBadUser (DBAccess db, StepUserInfo userInfo) throws SQLException {
        ResultSet rs = null;
        try
        {
            String sqlCallIsBadUser = 
                    "SELECT "+
                    "move_house.is_bad_user(?,?,?,?,?,?,?,?,?,?,?) AS badUser FROM dual";
            
            String sqlCallIsBadUserCommon = 
            		"SELECT "+
            		"common.is_bad_user_com(?,?,?,?,?,?,?,?,?,?) AS badUser FROM dual";
            
            db.prepareStatement(sqlCallIsBadUserCommon);
            db.setString(1, PhoenixLogicUtil.get(userInfo, "name_kanji_1"));
            db.setString(2, PhoenixLogicUtil.get(userInfo, "name_kanji_2"));
            db.setString(3, PhoenixLogicUtil.get(userInfo, "name_kana_1"));
            db.setString(4, PhoenixLogicUtil.get(userInfo, "name_kana_2"));
            db.setString(5, PhoenixLogicUtil.get(userInfo, "email"));
            db.setString(6, PhoenixLogicUtil.get(userInfo, "tel"));
            db.setString(7, PhoenixLogicUtil.get(userInfo, "zip"));
            db.setString(8, PhoenixLogicUtil.get(userInfo, "address_1") + PhoenixLogicUtil.get(userInfo, "address_2") + PhoenixLogicUtil.get(userInfo, "address_3")
    		        + PhoenixLogicUtil.get(userInfo, "address_4") + PhoenixLogicUtil.get(userInfo, "address_5"));
            db.setString(9, PhoenixLogicUtil.get(userInfo, "client_ip_address"));
            db.setString(10, PhoenixLogicUtil.get(userInfo, "prom_code"));

            rs = db.executeQuery();
            rs.next();
            
            boolean isBadUserCommon = rs.getString("badUser").equals("1");
            rs.close();
            
            db.prepareStatement(sqlCallIsBadUser);
            db.setString(1, PhoenixLogicUtil.get(userInfo, "name_kanji_1"));
            db.setString(2, PhoenixLogicUtil.get(userInfo, "name_kanji_2"));
            db.setString(3, PhoenixLogicUtil.get(userInfo, "name_kana_1"));
            db.setString(4, PhoenixLogicUtil.get(userInfo, "name_kana_2"));
            db.setString(5, PhoenixLogicUtil.get(userInfo, "email"));
            db.setString(6, PhoenixLogicUtil.get(userInfo, "tel"));
            db.setString(7, PhoenixLogicUtil.get(userInfo, "prom_code"));
            db.setString(8, PhoenixLogicUtil.get(userInfo, "zip"));
            db.setString(9, PhoenixLogicUtil.get(userInfo, "address_1") + PhoenixLogicUtil.get(userInfo, "address_2") + PhoenixLogicUtil.get(userInfo, "address_3")
            		        + PhoenixLogicUtil.get(userInfo, "address_4") + PhoenixLogicUtil.get(userInfo, "address_5"));
            db.setString(10, PhoenixLogicUtil.get(userInfo, "next_address_1") + PhoenixLogicUtil.get(userInfo, "next_address_2") + PhoenixLogicUtil.get(userInfo, "next_address_3")
    		                + PhoenixLogicUtil.get(userInfo, "next_address_4") + PhoenixLogicUtil.get(userInfo, "next_address_5"));
            db.setString(11, PhoenixLogicUtil.get(userInfo, "client_ip_address"));
            
            
            rs = db.executeQuery();
            rs.next();
            
            boolean isBadUser;
            if(rs.getString("badUser").equals("1") || isBadUserCommon)
            {
                isBadUser = true;
            }
            else
            {
                isBadUser = false;
            }
            rs.close();
            return isBadUser;
        }
        finally 
        {
        	DBAccess.close(rs);
        }
    }
	
    public static void sendMail(DBAccess db, int siteId, int orderId, boolean isTestUser, boolean isBadUser, List hitCompList) throws SQLException {
        
        DBAccess dbAccess4MailTempl = null;
        ResultSet rs = null;
        try
        {
            //tonashibaスキーマ検索用にDBAccessを初期化
            dbAccess4MailTempl = new DBAccess();

            //会社リストテキスト
            String strCompanyList = "";

            Iterator hitCompIter = hitCompList.iterator();
            
            //RowDataのリストを作成する。
            while (hitCompIter.hasNext()) {
                RowData compRow = (RowData)hitCompIter.next();
                //サンクスメール用の会社名のテキストリストを作成しておく。
                if (!strCompanyList.equals("")) {
                    strCompanyList += "," + compRow.get("company_name");
                } else {
                    strCompanyList = compRow.get("company_name");
                }
            }
            
            //まず、order_infoを検索
            String sql = "select email,name_kanji_1,name_kanji_2,mobile_flg,last_update from move_house.order_info where order_id = ?";
            
            db.prepareStatement(sql);
            db.setInt(1, orderId);
            rs =db.executeQuery();
            rs .next();
            
            String email      = rs .getString("email");
            String nameKanji  = rs .getString("name_kanji_1")+" "+rs .getString("name_kanji_2");
            String lastUpdateFromDB = rs.getString("last_update");
            String lastUpdate = lastUpdateFromDB.substring(0,4) + "年" + lastUpdateFromDB.substring(4,6) + "月" + lastUpdateFromDB.substring(6,8) + "日";
            String lastUpdateTime = lastUpdate + lastUpdateFromDB.substring(8,10) + "時" + lastUpdateFromDB.substring(10,12) + "分";
            String mobileFlg = rs.getString("mobile_flg");
            
            DBAccess.close(rs);
            
            MailTemplateUtil mailTemplateUtil;
            HashMap bodyParams;
            HashMap subjectParams;
            String from;
            String to;
            
            //メールテンプレートを確定
            String thanksMailTemplateName = "";
            if (mobileFlg != null && mobileFlg.equals("1")) {
                thanksMailTemplateName = "HOME_SECURITY_THS_MB";
            } else {
                thanksMailTemplateName = "HOME_SECURITY_THANKS";
            }
            
            //--------------------------
            //ユーザー向けサンクスメール
            //
            if(!isBadUser)
            {
                //メールテンプレートを取得
                mailTemplateUtil = new MailTemplateUtil(thanksMailTemplateName);
                mailTemplateUtil.load(dbAccess4MailTempl);

                subjectParams=new HashMap();
                bodyParams=new HashMap();
                bodyParams.put("###orderNo###", new Integer(orderId).toString());
                bodyParams.put("###name###", nameKanji);
                bodyParams.put("###companyName###", strCompanyList);
                bodyParams.put("###lastUpdate###", lastUpdateTime);
                
                from = mailTemplateUtil.getFrom();
                to   = email;
                mailTemplateUtil.doReplaceAndMail(subjectParams, bodyParams, to, from, new Integer(siteId).toString(), false);
            
            }
            
            //----------------------
            //会社注文確認メール
            //
            if(!isTestUser && !isBadUser)
            {
                hitCompIter = hitCompList.iterator();
                while (hitCompIter.hasNext())
                {
                    RowData compRow = (RowData)hitCompIter.next();
                    mailTemplateUtil = new MailTemplateUtil("HOME_SECURITY_ORDER");
                    mailTemplateUtil.load(dbAccess4MailTempl);
                    
                    
                    subjectParams = new HashMap();
                    subjectParams.put("###SITENAME###", "ズバットホームセキュリティ比較");
                    subjectParams.put("###SEQNO###", new Integer(orderId).toString());
                    
                    bodyParams = new HashMap();
                    bodyParams.put("###SEQNO###", new Integer(orderId).toString());
                    bodyParams.put("###FINISHTIME###", lastUpdateTime);
                    
                    from = mailTemplateUtil.getFrom();
                    to = compRow.get("company_mail");
                    
                    mailTemplateUtil.doReplaceAndMail(subjectParams, bodyParams, to, from, new Integer(siteId).toString(),false);
                }
            }
        }
        finally
        {
            DBAccess.close(dbAccess4MailTempl);
            DBAccess.close(rs);
        }
    }
    
    public static String insertIntoHomeSecurityOrderInfo(DBAccess db, String hostSiteId, String hostOrderId, StepUserInfo userInfo,
    		                                              String buildingType,List companyList, 
    		                                              String testUserFlg, String badUserFlg) throws Exception {
    	
    	String getSeqSql = "select phoenix.seq_goid.nextval AS order_id from dual";
    	
    	String insertSql = "insert into move_house.order_info \n"
                           + " (order_id, auth_id, site_id, name_kanji_1, name_kanji_2, name_kana_1, \n" 
                           + " name_kana_2, zip, pref_id, address_1, address_2, address_3, address_4, \n" 
                           + " address_5, tel, email, order_comment, \n" 
                           + " prom_code, delete_date, last_update, finish_flg, client_ip_address, \n" 
                           + " mobile_flg, guid, last_step, test_user_flg, bad_user_flg) \n"
                           + " values(?, ?, ?, ?, ?, ?, \n" 
                           + " ?, ?, ?, ?, ?, ?, ?, \n" 
                           + " ?, ?, ?, ?, \n" 
                           + " ?, '', to_char(sysdate,'YYYYMMDDHH24MISS'), ?, ?, \n" 
                           + " nvl(?,0), ?, ?, ?, ?)";
    	
    	String insertSecurityInterSql = "insert into move_house.order_security_inter (order_id, building_type) values (?,?)";
    	
    	String insertOrderCompanyInterSql = "insert into move_house.order_company_inter values (?,?, to_char(sysdate,'YYYYMMDDHH24MISS'))";
    	
    	String insertHsCBOXHistSql = "insert into move_house.hs_cbox_history values (?, ?, to_char(sysdate,'YYYYMMDDHH24MISS'))";
    	
    	String orderId = "";
    	
    	ResultSet rs = null;
    	try {
    		db.prepareStatement(getSeqSql);
        	rs = db.executeQuery();
        	if (rs.next()) {
        		orderId = rs.getString("order_id");
        	} else {
        		return "";
        	}
    	} finally {
    		DBAccess.close(rs);
    	}
    	
    	//order_info
    	db.prepareStatement(insertSql);
    	
    	db.setInt(1, ValueUtil.toint(orderId));
    	db.setString(2, "hikkoshi");
    	db.setInt(3, 11900);
    	db.setString(4, PhoenixLogicUtil.get(userInfo, "name_kanji_1"));
    	db.setString(5, PhoenixLogicUtil.get(userInfo, "name_kanji_2"));
    	db.setString(6, PhoenixLogicUtil.get(userInfo, "name_kana_1"));
    	db.setString(7, PhoenixLogicUtil.get(userInfo, "name_kana_2"));
    	db.setString(8, PhoenixLogicUtil.get(userInfo, "zip"));
    	db.setString(9, PhoenixLogicUtil.get(userInfo, "pref_id"));
    	db.setString(10, PhoenixLogicUtil.get(userInfo, "address_1"));
    	db.setString(11, PhoenixLogicUtil.get(userInfo, "address_2"));
    	db.setString(12, PhoenixLogicUtil.get(userInfo, "address_3"));
    	db.setString(13, PhoenixLogicUtil.get(userInfo, "address_4"));
    	db.setString(14, PhoenixLogicUtil.get(userInfo, "address_5"));
    	db.setString(15, PhoenixLogicUtil.get(userInfo, "tel"));
    	db.setString(16, PhoenixLogicUtil.get(userInfo, "email"));
    	db.setString(17, "");
    	db.setString(18, "hikkoshi");
    	db.setString(19, PhoenixLogicUtil.get(userInfo, "finish_flg"));
    	db.setString(20, PhoenixLogicUtil.get(userInfo, "client_ip_address"));
    	db.setString(21, PhoenixLogicUtil.get(userInfo, "mobile_flg"));
    	db.setString(22, PhoenixLogicUtil.get(userInfo, "guid"));
    	db.setString(23, "thanks");
    	db.setString(24, testUserFlg);
    	db.setString(25, badUserFlg);
    	
    	db.executeUpdate();
    	
    	//order_security_interへの登録
    	db.prepareStatement(insertSecurityInterSql);
    	db.setInt(1, ValueUtil.toint(orderId));
    	db.setString(2, buildingType);
    	
    	db.executeUpdate();
    	
    	
    	//order_company_interへの登録
    	Iterator iter = companyList.iterator();
    	while (iter.hasNext()) {
    		RowData companyRow = (RowData)iter.next();
    		
    		db.prepareStatement(insertOrderCompanyInterSql);
    		
    		db.setInt(1, ValueUtil.toint(orderId));
    		db.setString(2, companyRow.get("company_id"));
    		
    		db.executeUpdate();
    	}
    	
    	db.prepareStatement(insertHsCBOXHistSql);
    	db.setString(1, hostSiteId);
    	db.setString(2, hostOrderId);
    	db.executeUpdate();
    	
    	return orderId;
    }

}
