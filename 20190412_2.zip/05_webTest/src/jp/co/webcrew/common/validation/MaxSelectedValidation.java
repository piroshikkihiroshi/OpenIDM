/*
 * Copyright (c) 2004 WebCrew Inc. All rights reserved.
 *
 */
package jp.co.webcrew.common.validation;

import generator.runtime.db.DBConnectionWrapper;
import generator.runtime.utils.ParamUtils;

import java.util.Iterator;
import java.util.Map;


/**
 * {�N���X��}<BR>
 * {�N���X����}<BR>
 * <BR>
 * @version 1.0 2004/12/15
 *           �V�K�쐬
 * @author ������ЃE�F�u�N���[<BR>
 *          ��@����<BR>
 * <B>�X�V����</B><BR>
 *  �X�V��   : <BR>
 *  �쐬��   : <BR>
 *  �X�V���e : <BR>
 */
public class MaxSelectedValidation extends ValidationCheck {
	
	public ValidationFailure validate(Object value, DBConnectionWrapper dbConnection) {
	    if (value == null || value.equals("")) {
            return new ValidationFailure(getFieldName(), getErrorType(), null);
        } else if (value instanceof Map) {
            Map valueMap = (Map) value;
            String size = ParamUtils.nvl(getConfigParameter("length"), valueMap.size() + "");
            int nMin = 1;
            int nMax = Integer.parseInt(size);
            nMax = ( nMin > nMax ) ? nMin : nMax;
            
            int count = 0;
            Iterator it = valueMap.keySet().iterator();
            while (it.hasNext()) {
                String selected = (String) valueMap.get(it.next());
                if (selected.equalsIgnoreCase("true")) {
                    count++;
                }
            }
            if (count <= nMax) {
                return null;
            } else {
                return new ValidationFailure(getFieldName(), getErrorType(), null, String.valueOf(nMax));
            }
            
        } else {
    	    return null;
    	}
	}

}
