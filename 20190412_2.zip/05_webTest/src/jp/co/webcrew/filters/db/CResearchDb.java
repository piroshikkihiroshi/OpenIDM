package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.util.CResearchUtil;
import jp.co.webcrew.filters.util.CResearchXmlParser;

/**
 * クリックリサーチのアンケート項目、投票ユーザ情報を管理するためのdbクラス。
 * 
 * @author 
 */
public class CResearchDb extends RefreshMstDb {
  /** ロガー */
  private static final Logger log = Logger.getLogger(CResearchDb.class);
  
  /** 唯一のインスタンス */
  private static final CResearchDb instance = new CResearchDb();
  
  /** アンケートリスト */
  private List allEnquetesList = new ArrayList();
  
  /** アンケート項目を取得する */
  public static final String SELECT_ENQUETES_XML = ""
    + "SELECT enquetes_xml FROM ranking_enquetes_mst WHERE id = 1";
  
  /**
   * コンストラクタ
   *
   */
  private CResearchDb() {
    try {
      init();
    } catch (SQLException e) {
      log.error("DBエラー", e);
    }
  }
  
  /**
   * インスタンスを取得する
   */
  public static CResearchDb getInstance() {
    return instance;
  }
  
  /**
   * アンケートXMLを文字列で取得する
   */
  public void init_from_xml() throws SQLException {
    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();
      
      rs = dbAccess.executeQuery(SELECT_ENQUETES_XML);
      if (dbAccess.next(rs)) { 
        allEnquetesList = CResearchXmlParser.parser(rs.getString("enquetes_xml"));
        if(allEnquetesList.size() == 0) {
          log.error("アンケートXMLを取得出来ませんでした。XMLを確認して下さい。");
        }
      }
  
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
  
  /**
   * 全アンケート項目をリストで取得する
   * 
   * @return
   */
  public List getAllEnquetesList() {
    return allEnquetesList;
  }
  
  /** アンケート項目を取得するためのSQL(アンケート情報がXMLからDB形式に変わったときに利用する) */
  private static final String SELECT_CRESEARCH_ENQUETES = ""
    + "SELECT "
    + "  cem.enquete_id, cem.style, cem.title, cem.question, cem.category_id, "
    + "  TO_CHAR(TO_DATE(cem.start_date, 'YYYY/MM/DD'), 'YYYY/MM/DD') as start_date, "
    + "  TO_CHAR(TO_DATE(cem.end_date, 'YYYY/MM/DD'), 'YYYY/MM/DD') as end_date, "
    + "  TO_CHAR(TO_DATE(cem.new_start_date, 'YYYY/MM/DD'), 'YYYY/MM/DD') as new_start_date, "
    + "  TO_CHAR(TO_DATE(cem.new_end_date, 'YYYY/MM/DD'), 'YYYY/MM/DD') as new_end_date, "
    + "  com.option_id, com.answer, ccm.category_name "
    + "FROM "
    + "  cresearch_enquetes_mst cem "
    + "INNER JOIN cresearch_options_mst com ON cem.enquete_id = com.enquete_id "
    + "LEFT OUTER JOIN cresearch_category_mst ccm ON cem.category_id = ccm.category_id "
    + "WHERE cem.delete_date IS NULL "
    + "ORDER BY cem.enquete_id, com.option_id";
  //TODO init_from_db()は、アンケート情報をテーブルに保持するバージョンになった時にしようする
  //そのときは、メソッド名をinit()に変更する
  /**
   * アンケートデータを取得する
   * アンケートがXMLデータからDBへ保存形態が変わったときに使用する
   * 
   * @throws SQLException
   */
  public void init() throws SQLException {
    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();
      
      rs = dbAccess.executeQuery(SELECT_CRESEARCH_ENQUETES);
      
      //アンケート情報を一時的に保持するためのマップ
      Map tempMap = new LinkedHashMap();
      
      while(dbAccess.next(rs)) {
        //アンケートIDを取得
        String enqueteId = rs.getString("enquete_id");
        
        Map enqueteMap = null;
        
        if(tempMap.get(enqueteId) == null) {
          enqueteMap = new HashMap();
          
          //(1)アンケート番号を設定
          enqueteMap.put("id", new Integer(enqueteId));
          
          //(2)項目の入力タイプを設定
          enqueteMap.put("style", rs.getString("style"));
          
          //(3)タイトルを設定
          enqueteMap.put("title", rs.getString("title"));
          
          //(4)質問文を設定
          enqueteMap.put("question", rs.getString("question"));
          
          //(5)質問に対する回答番号と回答文を設定する
          Map optionsMap = new LinkedHashMap();
          optionsMap.put(rs.getString("option_id"), rs.getString("answer"));
          enqueteMap.put("options", optionsMap);
          
          //(7)掲載開催年月日を設定する
          enqueteMap.put("startDate", rs.getString("start_date"));
          
          //(8)掲載終了年月日を設定する
          enqueteMap.put("endDate", rs.getString("end_date"));
          
          //(10)カテゴリIDを設定
          enqueteMap.put("categoryId", rs.getString("category_id"));
          
          //(11)カテゴリ名を設定
          enqueteMap.put("categoryName", rs.getString("category_name"));
          
          //(12)NEWマーク表示開始年月日を取得する
          enqueteMap.put("newStartDate", rs.getString("new_start_date"));
          
          //(13)NEWマーク表示終了年月日
          enqueteMap.put("newEndDate", rs.getString("new_end_date"));
          
          //(14)投票数を設定する(初期値０)
          enqueteMap.put("voteCount", new Integer("0"));
          
        } else {
          enqueteMap = (HashMap)tempMap.get(enqueteId);
          Map optionsMap = (LinkedHashMap)enqueteMap.get("options");
          optionsMap.put(rs.getString("option_id"), rs.getString("answer"));
          enqueteMap.put("options", optionsMap);
        }
        
        tempMap.put(enqueteId, enqueteMap);
      }
      
      allEnquetesList = CResearchUtil.createEnquetesList(tempMap);
    } catch(SQLException se) {
      log.error("アンケート情報を取得出来ませんでした", se);
      throw se;
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
}
