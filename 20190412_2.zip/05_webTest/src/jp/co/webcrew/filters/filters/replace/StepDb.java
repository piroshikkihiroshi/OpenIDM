package jp.co.webcrew.filters.filters.replace;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * step関連のテーブルを処理するDBクラス。
 * 
 * @author kurinami
 */
public class StepDb {

	/** 会員新規登録用連携削除用sql */
	public static final String COORDINATE_REGIST_DELETE = "delete from coordinate_regist where guid = ?";

	/** guidを書き換える用のsql */
	public static final String OVER_WRITE_GUID = "update {0} set guid = ? where {1} = ?";

	/** メルマガ購読情報挿入用sql */
	public static final String MAG_SUBSCRIBE_UPDATE = ""
			+ "insert into mag_subscribe(guid, email, mag_id, bgn_datetime) \n"
			+ "select ?, ?, mag_id, to_char(sysdate, 'yyyymmddhh24miss') \n"
			+ "  from mag_map \n"
			+ " where site_id = ? \n"
			+ "   and not exists (select * from mag_subscribe where guid = ? and mag_id = mag_map.mag_id)";

	/** メルマガ購読情報挿入用sql */
	public static final String MAG_SUBSCRIBE_INSERT = ""
			+ "insert into mag_subscribe(guid, email, mag_id, bgn_datetime) \n"
			+ "select ?, ?, ?, to_char(sysdate, 'yyyymmddhh24miss') \n"
			+ "  from dual \n"
			+ " where not exists (select * from mag_subscribe where email = ? and mag_id = ?)";

	/** メルマガ購読情報検索用sql */
	public static final String MAG_SUBSCRIBE_SELECT = "select * from mag_subscribe where email = ? and guid <> 0";

	/**
	 * step連携テーブルの情報を削除する。
	 * 
	 * @param guid
	 * @throws SQLException
	 */
	public static void deleteCoordinateRegist(String guid) throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// step連携テーブルの情報を削除する。
			dbAccess.prepareStatement(COORDINATE_REGIST_DELETE);
			int i = 0;
			dbAccess.setString(++i, guid);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * 新しいguidで書き換える。
	 * 
	 * @param dbNamespace
	 * @param orderTableName
	 * @param orderId
	 * @param userTableName
	 * @param userId
	 * @param newGuid
	 * @throws SQLException
	 * @deprecated
	 */
	public static void doOverWriteGuid(String dbNamespace,
			String orderTableName, String orderId, String userTableName,
			String userId, String newGuid) throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess(dbNamespace);

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// order_infoのguidを書き換える。
			if (orderTableName.length() > 0) {
				doOverWriteGuid(dbAccess, orderTableName, "order_id", orderId,
						newGuid);
			}

			// user_infoのguidを書き換える。
			if (userTableName.length() > 0) {
				doOverWriteGuid(dbAccess, userTableName, "user_id", userId,
						newGuid);
			}

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * 指定されたテーブルのguidを書き換える。
	 * 
	 * @param dbAccess
	 * @param tableName
	 * @param keyCulumn
	 * @param keyValue
	 * @param newGuid
	 * @throws SQLException
	 * @deprecated
	 */
	private static void doOverWriteGuid(DBAccess dbAccess, String tableName,
			String keyCulumn, String keyValue, String newGuid)
			throws SQLException {

		String sql = new MessageFormat(OVER_WRITE_GUID).format(new String[] {
				tableName, keyCulumn });

		// guidを書き換える。
		dbAccess.prepareStatement(sql);
		int i = 0;
		dbAccess.setString(++i, newGuid);
		dbAccess.setString(++i, keyValue);
		dbAccess.executeUpdate();

	}

	/**
	 * サイトIDを元にメルマガフラグ購読情報を作成する。
	 * 
	 * @param newGuid
	 * @param email
	 * @param siteId
	 * @throws SQLException
	 */
	public static void updateMelmagaFlg(String newGuid, String email,
			String siteId) throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// メルマガフラグ購読情報を作成する。
			dbAccess.prepareStatement(MAG_SUBSCRIBE_UPDATE);
			int i = 0;
			dbAccess.setString(++i, newGuid);
			dbAccess.setString(++i, email);
			dbAccess.setString(++i, siteId);
			dbAccess.setString(++i, newGuid);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * メルマガIDを元にメルマガフラグ購読情報を作成する。
	 * 
	 * @param guid
	 * @param email
	 * @param magIds
	 * @throws SQLException
	 */
	public static void insertMelmagaFlg(String guid, String email,
			String[] magIds) throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// メルマガフラグ購読情報を作成する。
			dbAccess.prepareStatement(MAG_SUBSCRIBE_INSERT);

			for (int i = 0; i < magIds.length; i++) {
				if (magIds[i].trim().length() > 0) {
					dbAccess.setString(1, guid);
					dbAccess.setString(2, email);
					dbAccess.setString(3, magIds[i].trim());
					dbAccess.setString(4, email);
					dbAccess.setString(5, magIds[i].trim());
					dbAccess.executeUpdate();
				}
			}

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * 指定されたemailで登録されているメルマガ購読情報のguidを返す。
	 * 
	 * @param email
	 * @return
	 * @throws SQLException
	 */
	public static String getGuid(String email) throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// メルマガ購読情報を検索する。
			dbAccess.prepareStatement(MAG_SUBSCRIBE_SELECT);
			dbAccess.setString(1, email);
			rs = dbAccess.executeQuery();
			if (dbAccess.next(rs)) {
				return rs.getString("guid");
			} else {
				return "";
			}

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}
}
