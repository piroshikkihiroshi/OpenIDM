package jp.co.webcrew.phoenix.htmlservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;

/**
 * <pre>
 * HtmlServlet固有のユーティリティクラス
 * </pre>
 * @author Takahashi
 *
 */
public class HtmlServletUtil {

    private static int ouput_buffer = 256;
    
    /** プロパティファイル記載のの本番環境フラグ */
    private static String prop_productionEnv;

    /** プロパティファイル記載のデータベース接続先 */
    private static String prop_dbsection;


    static{

        try {
            HtmlPropertiesUtil prop = new HtmlPropertiesUtil("html_servlet.properties");
            prop_dbsection = prop.getProperty("dbaccess.section.name");
            prop_productionEnv = prop.getProperty("env.production");

        } catch (Throwable e) {
            e.printStackTrace();
        }

    }
    
    public static String getSiteId(HttpServletRequest request) {
        
        String siteId = ValueUtil.nullToStr(request.getAttribute("faon.site_id"));
        // サイトIDがリセットされる可能性があるため、URLからもう一回取得するよ
        if(siteId.length() == 0){
          siteId = ValueUtil.nullToStr(SiteMstDb.getInstance().getSiteId(request.getRequestURL().toString())); 
        }
        return siteId;
    }
    
    /**
     * <pre>
     * 本番環境ならtrue、そうでないならfalseを返す
     * </pre>
     */
    public static boolean isProductionEnv() {
/*
         if (prop_productionEnv != null && prop_productionEnv.equals("1")) {
            return true;
        }
        
        return false;
*/
        String mode = System.getProperty("testMode");
        if( mode != null && mode.equals("1")) {
            // テスト機
            return false;
        } else {
            // 本番機
            return true;
        }
    
    
    
    }
    
    /**
     * <pre>
     * ロジック登録用のデータベースアクセサを返す
     * </pre>
     * @throws SQLException
     */
    public static DBAccess getDB() throws SQLException{
        
        if (prop_dbsection == null) {
            throw new SQLException("データベース設定を読み込むことができませんでした。");
        }
        
        return new jp.co.webcrew.dbaccess.db.DBAccess(prop_dbsection);
    }

    
    
    /**
     * <pre>
     * HTML_STOREテーブル からhtmlファイルを読み込む。
     * typeを指定しない場合。html_store.type=1 or 3 (html or css/js)のみを対象とする。
     * </pre>
     * @param db
     * @param siteId
     * @param path
     * @return
     */
    public static  HttpEntry getEntry(DBAccess db , String theme , String siteId , String path) {

        if (db == null) return null;
        
        if (theme == null) return null;
        
        if (path == null) return null;

        if (siteId == null) return null;

        int queryIdx = path.indexOf("?");
        if (queryIdx >= 0 ) {
            path = path.substring(0 , queryIdx);
        }
        
        String currentDateTime = DateUtil.currentDateTime();
        
        String sql = null;
        
        
        if (isProductionEnv()) {
            sql = "SELECT * FROM " + theme + ".HTML_STORE "
                +   " WHERE "
                +   "  SITE_ID=? "
                +   " AND "
                +   "  (\"TYPE\"='1' OR \"TYPE\"='2' OR \"TYPE\"='3') " // html or css。includeは無視　⇒　コンテンツ再構築対応後includeも受け入れる。
                +   " AND "
                +   "  PATH_NAME=? "
                +   " AND "
                +   "  PUB_FLAG='1' "
                +   " AND "
                +   "  (BGN_DATETIME <= ? AND ? <= END_DATETIME)  "
                +   " ORDER BY BGN_DATETIME DESC ";
        
        } else {
            sql = "SELECT * FROM " + theme + ".HTML_STORE "
                +   " WHERE "
                +   "  SITE_ID=? "
                +   " AND "
                +   "  (\"TYPE\"='1' OR \"TYPE\"='2' OR \"TYPE\"='3') " // html or css。includeは無視　⇒　コンテンツ再構築対応後includeも受け入れる。
                +   " AND "
                +   "  PATH_NAME=? "
//                +   " AND "
//                +   "  PUB_FLAG='1' "
//                +   " AND "
//                +   "  (BGN_DATETIME <= ? AND ? <= END_DATETIME)  "
                +   " ORDER BY BGN_DATETIME DESC ";
            
        }
        
        ResultSet rs = null;
        try {
            db.prepareStatement(sql);
            
            db.setString(1 , siteId);
            db.setString(2 , path);
            
            if (isProductionEnv()) {
                db.setString(3 , currentDateTime);
                db.setString(4 , currentDateTime);
            }
            
            rs = db.executeQuery();
            
            if (rs.next()) {
                
                HttpEntry entry = new HttpEntry();
                entry.path     = rs.getString("PATH_NAME");
                entry.contents = rs.getBytes("BODY");
                entry.charset  = rs.getString("CHARSET");
                entry.type     = rs.getString("TYPE");
                entry.content_type = rs.getString("CONTENT_TYPE");
                
                return entry;
                
            } else {
                
                return null;
                
            }
            
        
        } catch (Exception e) {
            e.printStackTrace();
            return null;
            
        } finally {
            DBAccess.close(rs);
        }
        
        
    }

    /**
     * <pre>
     * HTML_STOREテーブル からファイルを読み込む。
     * </pre>
     * @param db
     * @param siteId
     * @param path
     * @param type
     * @return
     */
    public static  HttpEntry getEntry(DBAccess db , String theme , String siteId , String path , String type) {
        
        if (path == null) return null;
        
        if (siteId == null) return null;
        
        if (type == null) return getEntry(db , theme , siteId , path);
        
        int queryIdx = path.indexOf("?");
        if (queryIdx >= 0 ) {
            path = path.substring(0 , queryIdx);
        }
        
        String currentDateTime = DateUtil.currentDateTime();
        
        String sql = null;
        
        if (isProductionEnv()) {
            sql = "SELECT * FROM "  + theme + ".HTML_STORE "
                +   " WHERE "
                +   "  SITE_ID=? "
                +   " AND "
                +   "  \"TYPE\"=? "
                +   " AND "
                +   "  PATH_NAME=? "
                +   " AND "
                +   "  PUB_FLAG='1' "
                +   " AND "
                +   "  (BGN_DATETIME <= ? AND ? <= END_DATETIME)  "
                +   " ORDER BY BGN_DATETIME DESC ";
            
        } else {

            
            // テスト環境の場合、公開フラグは見ず、最新の公開日のものだけを見る。
            sql = "SELECT * FROM " + theme + ".HTML_STORE "
                +   " WHERE "
                +   "  SITE_ID=? "
                +   " AND "
                +   "  \"TYPE\"=? "
                +   " AND "
                +   "  PATH_NAME=? "
//                +   " AND "
//                +   "  PUB_FLAG='1' "
//                +   " AND "
//                +   "  (BGN_DATETIME <= ? AND ? <= END_DATETIME)  "
                +   " ORDER BY BGN_DATETIME DESC ";
            
        }
        
        ResultSet rs = null;
        try {
            db.prepareStatement(sql);
            
            db.setString(1 , siteId);
            db.setString(2 , type);
            db.setString(3 , path);
            
            if (isProductionEnv()) {
                db.setString(4 , currentDateTime);
                db.setString(5 , currentDateTime);
            }
            
            rs = db.executeQuery();
            
            if (rs.next()) {
                
                HttpEntry entry = new HttpEntry();
                entry.path     = rs.getString("PATH_NAME");
                entry.contents = rs.getBytes("BODY");
                entry.charset  = rs.getString("CHARSET");
                entry.type     = rs.getString("TYPE");
                entry.content_type = rs.getString("CONTENT_TYPE");
                
                return entry;
                
            } else {
                
                return null;
                
            }
            
        
        } catch (Exception e) {
            e.printStackTrace();
            return null;
            
        } finally {
            DBAccess.close(rs);
        }
        
        
    }

    public static  void copy (HttpEntry entry , HttpServletResponse response) throws IOException , ServletException{
        if (entry != null && ! entry.isEmpty()) {
            
            ServletOutputStream ostream = null;
            
            ostream = response.getOutputStream();
            
            try {
                response.setBufferSize(ouput_buffer);
            } catch (IllegalStateException e) {
                // Silent catch
            }
          
            if (ostream != null) {
                
                copy (entry.getContents() , ostream);
    
            }
            
//            PrintWriter writer = null;
//            
//            if (entry.isBinary()) {
//                
//                ostream = response.getOutputStream();
//
//                try {
//                    response.setBufferSize(ouput_buffer);
//                } catch (IllegalStateException e) {
//                    // Silent catch
//                }
//              
//                if (ostream != null) {
//                    
//                    copy (entry.getContents() , ostream);
//
//                }
//                
//            } else {
//                writer = response.getWriter();
//                copy (entry.getContentsStr() , writer);
//            }
        }
        
    }

    
    public static void copy(byte[] buffer , ServletOutputStream ostream)
        throws IOException {

        if (ostream != null) {
            if (buffer != null) {
                ostream.write(buffer, 0, buffer.length);
            }
        }

    }

    public static void copy(String contents , PrintWriter writer)
        throws IOException {

        if (contents != null && writer != null) {
            writer.append(contents);
        }
    
    }
    
    public static HttpEntry getDefaultIndexEntry(DBAccess db , String theme , String siteId , String path ) {

        return getDefaultIndexEntry(db, theme , siteId , path , null);
    }   
    
    public static HttpEntry getDefaultIndexEntry(DBAccess db , String theme , String siteId , String path , String type) {
        if (path == null) return null;
        
        if (! path.endsWith("/")) return null;
        
        String targetPath = path + "index.html";
        
        HttpEntry entry = getEntry(db , theme , siteId , targetPath , type);
        
        if (entry == null || entry.isEmpty()) {
            
            targetPath = path = "index.htm";
            entry = getEntry(db , siteId , targetPath , type);
            
        }
        
        return entry;
        
    }  

    public static String getLastPathOf (String path) {
        
        if (path == null) return null;
        
        if (path.endsWith("/")) return "/";
        
        if (path.indexOf("/") >= 0) {
            
            int lastIdx = path.lastIndexOf("/");
            
            path = path.substring(lastIdx);
            
        }
        
        return path;
        
        
    }
    
    public static String getTheme (String siteId) {
        if (siteId == null || siteId.length() == 0) return null;
        
        DBAccess db = null;
        ResultSet rs = null;
        
        try {
            db = new DBAccess();
            
            String sql = "SELECT \"SCHEMA\" FROM SITE_MST WHERE INVALID_FLAG='0' AND SITE_ID=? ";
            
            db.prepareStatement(sql);
            db.setString(1, siteId);
            
            rs = db.executeQuery();
            
            if (rs.next()) {
                return rs.getString("SCHEMA");
            } else {
                return null;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            
            return null;
        
        } finally {
            DBAccess.close(rs);
            DBAccess.close(db);
        }
        
    }
}
