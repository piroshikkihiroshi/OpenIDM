package jp.co.webcrew.phoenix.sstag.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.loader.util.LoadUtil;
import jp.co.webcrew.phoenix.logic.ItemConvLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import jp.co.webcrew.phoenix.logic.db.FormDb;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * フォーム項目の変換処理を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class FormItemConvExecuter extends SSTagExecuter {

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：対象とする group_id(任意） */
    private static final String GROUP_ID_PARAM_KEY = "group_id";

    /** パラメータ名：group_id外であっても対象とする項目(カラム)を指定 */
    private static final String INCLUDE_PARAM_KEY = "include";

    /** パラメータ名：group_id内であっても対象としない項目名を指定 */
    private static final String EXCLUDE_PARAM_KEY = "exclude";

    /** パラメータ名：フォーム定義内の項目ID */
    private static final String ITEM_ID_PARAM_KEY = "item_id";

    /** パラメータ名：処理方法 */
    private static final String OP_PARAM_KEY = "op";

    /** パラメータ名：処理方法 のサブパラメータ1 */
    private static final String SUB1_PARAM_KEY = "sub1";

    /** パラメータ名：処理方法 のサブパラメータ2 */
    private static final String SUB2_PARAM_KEY = "sub2";

    /** パラメータ名：任意処理用のロジック */
    private static final String LOGIC_PARAM_KEY = "logic";

    /** パラメータ名：変換結果を格納する項目ID */
    private static final String RESULT_PARAM_KEY = "result";

    /** ロガー */
    private static final Logger log = Logger.getLogger(FormItemConvExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { FORM_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String[] groupId = PhoenixUtil.split((String) parameters.get(GROUP_ID_PARAM_KEY), ",");
            String[] include = PhoenixUtil.split((String) parameters.get(INCLUDE_PARAM_KEY), ",");
            String[] exclude = PhoenixUtil.split((String) parameters.get(EXCLUDE_PARAM_KEY), ",");
            String[] itemId = PhoenixUtil.split((String) parameters.get(ITEM_ID_PARAM_KEY), ",");
            String op = ValueUtil.nullToStr(parameters.get(OP_PARAM_KEY));
            String sub1 = ValueUtil.nullToStr(parameters.get(SUB1_PARAM_KEY));
            String sub2 = ValueUtil.nullToStr(parameters.get(SUB2_PARAM_KEY));
            String[] logic = PhoenixUtil.split((String) parameters.get(LOGIC_PARAM_KEY), " ");
            String result = ValueUtil.nullToStr(parameters.get(RESULT_PARAM_KEY));

            // セッションストアで保持しているフォームデータを取得する。
            PostInfo postInfo = StoreUtil.getPostInfo(request);

            // htmlを組み立てる。
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);

            if (PhoenixUtil.isEmpty(logic)) {
                defaultConvert(postInfo, itemId, op, sub1, sub2, result);
            } else {

                // サイトIDを取得
                int siteId = SstagUtil.getSiteId(null, request);

                // フォーム項目一覧を取得する。
                FormInfo formInfo = FormDb.getFormInfo(siteId, formId);

                // form内で使用するグループと項目
                FormUseInfo formUseInfo = new FormUseInfo(groupId, include, exclude, itemId);

                // 共通情報を取得する。
                SstagGlobalInfo sgInfo = SstagUtil.getSstagGlobalInfo(request);

                ItemConvLogicStatus status = logicConvert(request, parameters, sgInfo, formInfo, postInfo, formUseInfo,
                        logic, sub1, sub2, result);
                if (!status.result) {
                    status.writeLog(log);
                    return onerror(request, response, parameters, status.errStatus, status.errMsg);
                }

                // 結果htmlを出力する。
                pw.println(ValueUtil.nullToStr(status.html));

                if (!PhoenixUtil.isEmpty(status.itemData)) {
                    for (Map.Entry<String, String[]> entry : status.itemData.entrySet()) {
                        postInfo.postItemMap.put(entry.getKey(), entry.getValue());
                    }
                }
            }

            // セッションストアにフォームデータを格納し直す。
            StoreUtil.setPostInfo(request, postInfo);

            // TODO kurinami 【未実装】 置換パラメータ設定しなおし。
            // // フォームデータの値を置換パラメータに登録する。
            // setReplaceParam(request, postInfo);

            // TODO kurinami 【確認】 ★ 動作未確認
            pw.flush();
            return sw.toString();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * 標準の変換処理を行う。
     * 
     * @param postInfo
     * @param itemId
     * @param op
     * @param sub1
     * @param sub2
     * @param result
     */
    private void defaultConvert(PostInfo postInfo, String[] itemId, String op, String sub1, String sub2, String result) {

        if (op.equals("cat")) {

            String[] values = new String[itemId.length];
            for (int i = 0; i < itemId.length; i++) {
                values[i] = PhoenixUtil.concat(postInfo.postItemMap.get(itemId[i]), sub1);
            }
            String resultValue = PhoenixUtil.concat(values, sub1);

            String resultItemId = (PhoenixUtil.isEmpty(result) ? itemId[0] : result);
            postInfo.postItemMap.put(resultItemId, new String[] { resultValue });

        } else if (op.equals("sub")) {

            int beginIndex = ValueUtil.toint(sub1);
            int endIndex = beginIndex + ValueUtil.toint(sub2);

            List<String> resultList = new ArrayList<String>();

            for (int i = 0; i < itemId.length; i++) {
                String[] values = postInfo.postItemMap.get(itemId[i]);
                for (int j = 0; j < values.length; j++) {
                    String resultValue = (PhoenixUtil.isEmpty(sub2) ? PhoenixUtil.substring(values[j], beginIndex)
                            : PhoenixUtil.substring(values[j], beginIndex, endIndex));
                    if (!PhoenixUtil.isEmpty(result)) {
                        resultList.add(resultValue);
                    } else {
                        values[j] = resultValue;
                    }
                }
            }

            if (!PhoenixUtil.isEmpty(result)) {
                postInfo.postItemMap.put(result, resultList.toArray(new String[0]));
            }

        } else if (op.equals("map")) {

            // 置き換えようの一覧を作成する。
            Map<String, String> replaceMap = new HashMap<String, String>();
            if (sub1.equals("select_mst")) {
                // TODO kurinami 【未実装】 マスタでの置き換え
            } else {
                String[] keys = PhoenixUtil.split(sub1.substring(1), sub1.substring(0, 1));
                String[] values = PhoenixUtil.split(sub2.substring(1), sub2.substring(0, 1));

                for (int i = 0; i < keys.length && i < values.length; i++) {
                    replaceMap.put(keys[i], values[i]);
                }
            }

            List<String> resultList = new ArrayList<String>();

            for (int i = 0; i < itemId.length; i++) {
                String[] values = postInfo.postItemMap.get(itemId[i]);
                for (int j = 0; j < values.length; j++) {
                    String resultValue = replaceMap.get(values[j]);
                    if (!PhoenixUtil.isEmpty(result)) {
                        resultList.add(resultValue);
                    } else {
                        values[j] = resultValue;
                    }
                }
            }

            if (!PhoenixUtil.isEmpty(result)) {
                postInfo.postItemMap.put(result, resultList.toArray(new String[0]));
            }

        } else {
            // TODO kurinami 【未実装】 パラメータエラー
        }

    }

    /**
     * ロジックでの変換処理を行う。
     * 
     * @param request
     * @param sstagParam
     * @param sgInfo
     * @param formInfo
     * @param postInfo
     * @param formUseInfo
     * @param logic
     * @param sub1
     * @param sub2
     * @param result
     * @throws Exception
     */
    private ItemConvLogicStatus logicConvert(HttpServletRequest request, Map<String, String> sstagParam,
            SstagGlobalInfo sgInfo, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String[] logic,
            String sub1, String sub2, String result) throws Exception {
        // TODO kurinami 【確認】 ★ 動作未確認
        SstagDynamicLogic logicClass = (SstagDynamicLogic) LoadUtil.newInstanceFromId(request, logic[0]);

        List<String> userParam = Arrays.asList(logic);
        return logicClass.itemConvLogic(sgInfo, sstagParam, userParam, formInfo, postInfo, formUseInfo, sub1, sub2,
                result);

    }
}
