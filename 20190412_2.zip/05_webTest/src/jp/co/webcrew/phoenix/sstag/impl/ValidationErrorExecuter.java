package jp.co.webcrew.phoenix.sstag.impl;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * バリデーションエラー時のメッセージを出力するsstagクラス。
 * 
 * @author kurinami
 */
public class ValidationErrorExecuter extends SSTagExecuter {

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：項目名称 */
    private static final String NAME_PARAM_KEY = "name";

    /** パラメータ名：エラー時文言 */
    private static final String ERROR_PARAM_KEY = "error";

    /** パラメータ名：非エラー時文言 */
    private static final String NOERROR_PARAM_KEY = "noerror";

    /** ロガー */
    private static final Logger log = Logger.getLogger(ValidationErrorExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    @SuppressWarnings("unchecked")
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String name = ValueUtil.nullToStr(parameters.get(NAME_PARAM_KEY));
            String error = ValueUtil.nullToStr(parameters.get(ERROR_PARAM_KEY));
            String noerror = ValueUtil.nullToStr(parameters.get(NOERROR_PARAM_KEY));

            // セッションストアで保持している入力チェックの結果を取得する。
            Map<String, String[]> vResult = StoreUtil.getValidationResult(request, formId);

            // エラーの発生状況に応じて、メッセージを切り分ける。
            if (isError(vResult, name)) {
                return error;
            } else {
                return noerror;
            }

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * エラーが発生しているかを返す。
     * 
     * @param status
     * @param name
     * @return
     */
    private boolean isError(Map<String, String[]> vResult, String name) {

        if (name.length() == 0) {
            return !PhoenixUtil.isEmpty(vResult);
        } else {
            return !PhoenixUtil.isEmpty(vResult) && !PhoenixUtil.isEmpty(vResult.get(name));
        }

    }
}
