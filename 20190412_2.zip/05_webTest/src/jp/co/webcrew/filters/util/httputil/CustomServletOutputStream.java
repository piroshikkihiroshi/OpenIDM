package jp.co.webcrew.filters.util.httputil;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletOutputStream;

/**
 * クライアントへのレスポンスをバッファリングするstreamクラス。
 * 
 * @author kurinami
 */
public class CustomServletOutputStream extends ServletOutputStream {

	/** バッファリングする出力先 */
	private OutputStream outputStream;

	public CustomServletOutputStream(OutputStream outputStream) {
		this.outputStream = outputStream;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.OutputStream#close()
	 */
	public void close() throws IOException {
		outputStream.close();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.OutputStream#flush()
	 */
	public void flush() throws IOException {
		outputStream.flush();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.io.OutputStream#write(int)
	 */
	public void write(int b) throws IOException {
		outputStream.write(b);
	}

}
