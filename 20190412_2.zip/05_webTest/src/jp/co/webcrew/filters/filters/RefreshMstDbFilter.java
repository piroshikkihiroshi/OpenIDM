package jp.co.webcrew.filters.filters;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * キャッシュしているマスタ情報を強制的に更新できるようにするためのfilterクラス。
 * 
 * @author kurinami
 */
public class RefreshMstDbFilter implements Filter {

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(RefreshMstDbFilter.class);

	/** リフレッシュを指定するためのパラメータ名 */
	private String parameterName = "";

	/** 実行が許可されたサブネットのアドレスをビット値で表したもの */
	int subnetAddressBit = 0;

	/** マスクする桁数 */
	int maskBitDigit = 0;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

		log.info("init start.");

		try {
			parameterName = ValueUtil.nullToStr(filterConfig
					.getInitParameter("parameterName"));
			if (parameterName.length() == 0) {
				throw new Exception("init parameter 'parameterName' is not set");
			}

			try {

				String permitAddress = filterConfig
						.getInitParameter("permitAddress");
				String[] values = permitAddress.split("/", 2);

				maskBitDigit = Integer.parseInt(values[1]);
				subnetAddressBit = getMaskedAddressBit(values[0], maskBitDigit);

			} catch (Exception e) {
				throw new Exception("init parameter 'permitAddress' is invalid");
			}

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			throw new ServletException(e);
		}

		log.info("init end.");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		try {
			String address = request.getRemoteAddr();
			int addressBit = getMaskedAddressBit(address, maskBitDigit);

			// 許可されたネットワークからのアクセスでdbリフレッシュを指定するパラメータが渡された場合、
			if (subnetAddressBit == addressBit
					&& request.getParameter(parameterName) != null) {
				try {
					// 取得しているマスタ情報をリフレッシュする。
					RefreshMstDb.refreshForce();
				} catch (SQLException e) {
					// 更新でエラーが発生した場合はエラーの500を返す。
					log.error("DBエラー", e);
					((HttpServletResponse) response)
							.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					return;
				}
			}

		} catch (Throwable t) {
			log.error("予期せぬエラー", t);
		}

		chain.doFilter(request, response);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// 処理なし
	}

	/**
	 * IPアドレスにマスクをかけたビット値を返す。
	 * 
	 * @param address
	 * @param maskBitDigit
	 * @return
	 */
	private static int getMaskedAddressBit(String address, int maskBitDigit) {

		final int byteDigit = 4;
		final int bitDigit = 8;
		
		int addressBit = 0;

		String[] nums = ValueUtil.nullToStr(address).split("\\.", byteDigit);

		for (int i = 0; i < byteDigit; i++) {
			addressBit <<= bitDigit;
			if (nums.length > i && nums[i].length() > 0) {
				addressBit += Integer.parseInt(nums[i]);
			}
		}

		int shiftBitDigit = byteDigit * bitDigit - maskBitDigit;
		return (shiftBitDigit < byteDigit * bitDigit) ? (addressBit >>> shiftBitDigit << shiftBitDigit) : 0;
	}

	public static void main(String[] argv) {
		try {
//			System.out.println(Integer.toHexString(getMaskedAddressBit("255.255.255.0.0", 14)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("255.255.255", 14)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("255.255.255.", 14)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("255.255.255.0", 14)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("255.255.255.0", 15)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("255.255.255.0", 16)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("255.255.255.0", 17)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("192.168.1.4", 32)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("192.168.1.4", 31)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("192.168.1.4", 1)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("192.168.1.4", 0)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("0.0.0.0", 0)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("192.168.1.0", 24)));
			System.out.println(Integer.toHexString(getMaskedAddressBit("192.168.1.4", 24)));
		} catch(Throwable t) {
			t.printStackTrace();
		}
	}
}
