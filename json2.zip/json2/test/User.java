package test;
import java.util.List;
import java.util.Map;

public class User {
    private int id;
    private String name;
    private List<String> hobby;
    private String[] interests;
    private Map<String, Object> skill;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<String> getHobby() { return hobby; }
    public void setHobby(List<String> hobby) { this.hobby = hobby; }

    public String[] getInterests() { return interests; }
    public void setInterests(String[] interests) { this.interests = interests; }

    public Map<String, Object> getSkill() { return skill; }
    public void setSkill(Map<String, Object> skill) { this.skill = skill; }
}
