package jp.co.webcrew.test;

import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.BindLogicStdStatus;
import jp.co.webcrew.phoenix.logic.ItemConvLogicStatus;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
public class AAAAA extends SstagDynamicLogic {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ

//		LogOut aaa  = new LogOut();
		Logger logger = Logger.getLogger(AAAAA.class);
		System.out.println(logger.toString());

	}

	@Override
	public ItemConvLogicStatus itemConvLogic(SstagGlobalInfo arg0, Map<String, String> arg1, List<String> arg2,
			FormInfo arg3, PostInfo arg4, FormUseInfo arg5, String arg6, String arg7, String arg8) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public JudgementLogicStatus judgementLogic(SstagGlobalInfo arg0, Map<String, String> arg1, List<String> arg2,
			FormInfo arg3, PostInfo arg4, FormUseInfo arg5, SortRequest[] arg6, Map<String, String[]> arg7,
			Map<String, Map<String, Object[]>> arg8, Map<String, Object[]> arg9, boolean arg10, boolean arg11) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public BindLogicStdStatus stdLogic(SstagGlobalInfo arg0, Map<String, String> arg1, List<String> arg2, FormInfo arg3,
			PostInfo arg4, FormUseInfo arg5) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public BindLogicExtStatus validationLogic(SstagGlobalInfo arg0, Map<String, String> arg1, List<String> arg2,
			FormInfo arg3, PostInfo arg4, FormUseInfo arg5, SortRequest[] arg6, Map<String, String[]> arg7,
			Map<String, Map<String, Object[]>> arg8, Map<String, Object[]> arg9, boolean arg10, boolean arg11) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
