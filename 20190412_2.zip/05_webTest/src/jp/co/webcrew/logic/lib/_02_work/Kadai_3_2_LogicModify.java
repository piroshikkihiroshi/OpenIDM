package jp.co.webcrew.logic.lib._02_work;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.BindLogicStdStatus;
import jp.co.webcrew.phoenix.logic.ItemConvLogicStatus;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;

public class Kadai_3_2_LogicModify extends SstagDynamicLogic {

	Logger logger = Logger.getLogger(Kadai_3_2_LogicModify.class);

	@Override
	public BindLogicStdStatus stdLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam, List<String> userParam,
			FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo) {

		//member変数
		int intSiteId = 91076;
		PhoenixDBAccess objDbAccess = null;
//		ResultSet objRs = null;
		int intMax = 0;

		String[] arrOrderId = postInfo.postItemMap.get("ORDER_ID");
		String[] arrKanzi1 = postInfo.postItemMap.get("NAME_KANJI_1");
		String[] arrKanzi2 = postInfo.postItemMap.get("NAME_KANJI_2");
		String[] arrkana1 = postInfo.postItemMap.get("NAME_KANA_1");
		String[] arrkana2 = postInfo.postItemMap.get("NAME_KANA_2");
		String[] arrEmail = postInfo.postItemMap.get("EMAIL");
		String[] arrTel = postInfo.postItemMap.get("TEL");
//		String[] arrInquiryInfo = postInfo.postItemMap.get("inquiry_info");

		logger.info("取得テストTel：" + arrTel[0]);


		//sql作成
		String strSql = "";
		strSql +=" UPDATE \"TATSUYA.UEDA\".ORDER_INFO  ";
		strSql +=" SET ";
		strSql +="   NAME_KANJI_1 = ?  ";
		strSql +="   , NAME_KANJI_2 = ?  ";
		strSql +="   , NAME_KANA_1 = ?  ";
		strSql +="   , NAME_KANA_2 = ?  ";
		strSql +="   , EMAIL = ?  ";
		strSql +="   , TEL = ?  ";
		strSql +="   , CONTACT = ?  ";
		strSql +="   , DELETE_FLG = ?  ";
		strSql +=" WHERE ";
		strSql +="   ORDER_ID = ? ";

		try {

			objDbAccess = new PhoenixDBAccess(intSiteId);
			objDbAccess.setAutoCommit(false); //一応明示的にオートコミット切る
			objDbAccess.prepareStatement(strSql);
			objDbAccess.setString(1, arrKanzi1[0]);
			objDbAccess.setString(2, arrKanzi2[0]);
			objDbAccess.setString(3, arrkana1[0]);
			objDbAccess.setString(4, arrkana2[0]);
			objDbAccess.setString(5, arrEmail[0]);
			objDbAccess.setString(6, arrTel[0]);
			objDbAccess.setInt(7, 1); //contact取り込まないと
			objDbAccess.setInt(8, 0); //delflg
			objDbAccess.setInt(9, Integer.parseInt(arrOrderId[0])); //where

			int intCnt = objDbAccess.executeUpdate();

			logger.info("update件数：" + intCnt);

			objDbAccess.commit();
			logger.info("commit success");

		} catch (SQLException e) {
			logger.error("SQL Error", e);
			e.printStackTrace();
		} catch (Exception e) {
			objDbAccess.rollback();
			logger.error("Unexpect Error", e);
			e.printStackTrace();
		} finally {
			//DBAccess.close(rs);
			DBAccess.close(objDbAccess);

		} //try

		//statusは必須
		BindLogicExtStatus objStatus = new BindLogicExtStatus();

		return objStatus;

	} // stdLogic

	@Override
	public BindLogicExtStatus validationLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public JudgementLogicStatus judgementLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public ItemConvLogicStatus itemConvLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String sub1,
			String sub2, String result) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
