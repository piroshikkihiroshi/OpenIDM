﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InitForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SearchInitBtn = New System.Windows.Forms.Button()
        Me.PasteInitBtn = New System.Windows.Forms.Button()
        Me.ProcKillInitBtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'SearchInitBtn
        '
        Me.SearchInitBtn.Location = New System.Drawing.Point(54, 37)
        Me.SearchInitBtn.Name = "SearchInitBtn"
        Me.SearchInitBtn.Size = New System.Drawing.Size(173, 25)
        Me.SearchInitBtn.TabIndex = 0
        Me.SearchInitBtn.Text = "顧客王検索"
        Me.SearchInitBtn.UseVisualStyleBackColor = True
        '
        'PasteInitBtn
        '
        Me.PasteInitBtn.Location = New System.Drawing.Point(54, 77)
        Me.PasteInitBtn.Name = "PasteInitBtn"
        Me.PasteInitBtn.Size = New System.Drawing.Size(173, 26)
        Me.PasteInitBtn.TabIndex = 1
        Me.PasteInitBtn.Text = "略歴・備考貼り付け"
        Me.PasteInitBtn.UseVisualStyleBackColor = True
        '
        'ProcKillInitBtn
        '
        Me.ProcKillInitBtn.Location = New System.Drawing.Point(54, 125)
        Me.ProcKillInitBtn.Name = "ProcKillInitBtn"
        Me.ProcKillInitBtn.Size = New System.Drawing.Size(173, 25)
        Me.ProcKillInitBtn.TabIndex = 2
        Me.ProcKillInitBtn.Text = "顧客王が起動しなくなった時"
        Me.ProcKillInitBtn.UseVisualStyleBackColor = True
        '
        'InitForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.ProcKillInitBtn)
        Me.Controls.Add(Me.PasteInitBtn)
        Me.Controls.Add(Me.SearchInitBtn)
        Me.Name = "InitForm"
        Me.Text = "InitForm"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SearchInitBtn As System.Windows.Forms.Button
    Friend WithEvents PasteInitBtn As System.Windows.Forms.Button
    Friend WithEvents ProcKillInitBtn As System.Windows.Forms.Button
End Class
