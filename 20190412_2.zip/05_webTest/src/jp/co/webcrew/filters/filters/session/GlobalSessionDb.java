package jp.co.webcrew.filters.filters.session;

import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * 端末IDにひもづくグローバルセッションを管理するためのdbクラス
 * 
 * @author kurinami
 */
public class GlobalSessionDb {

	/** 取得用sql */
	private final static String GLOBAL_SESSION_SELECT = "select * from global_session ";

	/** 更新用sql */
	private final static String GLOBAL_SESSION_UPDATE = "update global_session set ca_uniq_id1 = ?, ca_uniq_id2 = ? where gsid = ? ";

	/** 削除用sql */
	private final static String GLOBAL_SESSION_DELETE = "delete from global_session where (ca_uniq_id1 = ? or ca_uniq_id2 = ?) and gsid <> ? ";

	/** gsid */
	private int gsid = 0;

	/** gs_code */
	private String gsCode = "";

	/** 端末識別ID1 */
	private String caUniqId1 = "";

	/** 端末識別ID2 */
	private String caUniqId2 = "";

	/** 更新フラグ */
	private boolean updateFlag = false;

	/**
	 * 条件に一致するグローバルセッションを返す。
	 * 
	 * @param condition 検索条件
	 * @param params 検索条件中の置換パラメータ
	 * @return
	 * @throws SQLException
	 */
	public static GlobalSessionDb getInstance(String condition, String[] params)
			throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// グローバルセッションを検索する。
			dbAccess.prepareStatement(GLOBAL_SESSION_SELECT + condition);
			if (params != null) {
				for(int i = 0; i < params.length; i++) {
					dbAccess.setString(i + 1, params[i]);
				}
			}
			rs = dbAccess.executeQuery();
			
			if (dbAccess.next(rs)) {
				GlobalSessionDb globalSession = new GlobalSessionDb();
				globalSession.gsid = rs.getInt("gsid");
				globalSession.gsCode = rs.getString("gs_code");
				globalSession.caUniqId1 = rs.getString("ca_uniq_id1");
				globalSession.caUniqId2 = rs.getString("ca_uniq_id2");
				return globalSession;
			} else {
				return null;
			}

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * グローバルセッションの更新をdbに反映する。
	 * 
	 * @throws SQLException
	 */
	public void save() throws SQLException {

		// 内容が更新されていない場合は、何もしない。
		if (!updateFlag) {
			return;
		}

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// 各ドコモ用IDを更新する。
			dbAccess.prepareStatement(GLOBAL_SESSION_UPDATE);
			dbAccess.setString(1, caUniqId1);
			dbAccess.setString(2, caUniqId2);
			dbAccess.setInt(3, gsid);
			dbAccess.executeUpdate();

			// IDの重複は排除しておく。
			dbAccess.prepareStatement(GLOBAL_SESSION_DELETE);
			dbAccess.setString(1, caUniqId1);
			dbAccess.setString(2, caUniqId2);
			dbAccess.setInt(3, gsid);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;
		} finally {
			DBAccess.close(dbAccess);
		}
	}

	public String getCaUniqId1() {
		return caUniqId1;
	}

	public void setCaUniqId1(String caUniqId1) {
		caUniqId1 = ValueUtil.nullToStr(caUniqId1);
		if (caUniqId1.length() > 0
				&& !caUniqId1.equals(ValueUtil.nullToStr(this.caUniqId1))) {
			this.caUniqId1 = caUniqId1;
			updateFlag = true;
		}
	}

	public String getCaUniqId2() {
		return caUniqId2;
	}

	public void setCaUniqId2(String caUniqId2) {
		caUniqId2 = ValueUtil.nullToStr(caUniqId2);
		if (caUniqId2.length() > 0
				&& !caUniqId2.equals(ValueUtil.nullToStr(this.caUniqId2))) {
			this.caUniqId2 = caUniqId2;
			updateFlag = true;
		}
	}

	public String getGsCode() {
		return gsCode;
	}

	public void setGsCode(String gsCode) {
		this.gsCode = gsCode;
	}

	public int getGsid() {
		return gsid;
	}

	public void setGsid(int gsid) {
		this.gsid = gsid;
	}

}
