package jp.co.webcrew.phoenix.vtable.bean;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

import jp.co.webcrew.phoenix.sstag.db.SelectMstDb;

/**
 * カラムメタ情報マスタを保持するbeanクラス。
 * 
 * @author kurinami
 */
public class ClmMetaMstBean implements Serializable {

    /** デフォルトシリアルバージョン */
    private static final long serialVersionUID = 1L;

    /** 半角・全角変換:変換しない */
    public static final int WCHAR_CONV_NONE = 0;

    /** 半角・全角変換:全角を半角に変換 */
    public static final int WCHAR_CONV_NARROW = 1;

    /** 半角・全角変換:半角を全角に変換 */
    public static final int WCHAR_CONV_WIDE = 2;

    /** 時刻オプション：24時間 */
    public static final String TIME_OPTION_24 = "0";

    /** 時刻オプション：12時間 */
    public static final String TIME_OPTION_12 = "1";

    /** 出力時カンマ付け：変換しない */
    public static final String OUT_STYLE_COMMA_NO = "0";

    /** 出力時カンマ付け：3桁カンマ付けする */
    public static final String OUT_STYLE_COMMA_YES = "1";

    /** サイトID */
    private int siteId = 0;

    /** テーブルID */
    private String tblId = "";

    /** カラムID */
    private String clmId = "";

    /** テーブル内番号 */
    private int sortNum = 0;

    /** 表示用カラム名 */
    private String dispName = "";

    /** 項目タイプ */
    private String type = "";

    /** 半角・全角変換 */
    private int wcharConv = WCHAR_CONV_NONE;

    /** 時刻オプション */
    private String timeOption = "";

    /** 出力時カンマ付け */
    private String outStyleComma = "";

    /** 出力時日付書式変換 */
    private String outStyleDate = "";

    /** 出力時時刻書式変換 */
    private String outStyleTime = "";

    /** 固定prefix */
    private String prefix = "";

    /** 固定suffix */
    private String suffix = "";

    /** 選択肢マスタのサイトID */
    private int selMstSiteId = 0;

    /** 選択肢マスタID */
    private String selMstId = "";

    /**
     * 数値系のデータかどうかを返す。
     * 
     * @return
     * @throws SQLException
     */
    public boolean isNumber() throws SQLException {
        if (type.equals("1") || type.equals("16")) {
            // 型が数値型の場合、
            return true;
        } else if ((type.equals("51") || type.equals("52") || type.equals("55") || type.equals("56"))
                && SelectMstDb.isNumberValue(siteId, selMstId)) {
            // 単一選択肢型で、選択肢が全て数値の場合、
            return true;
        }
        return false;
    }

    /**
     * カラム情報の一覧から該当のカラム情報を探し出し、それが数値系のデータかどうかを返す。
     * 
     * @param clmMetaMstList
     * @param clmId
     * @return
     * @throws SQLException
     */
    public static boolean isNumber(List<ClmMetaMstBean> clmMetaMstList, String clmId) throws SQLException {
        for (ClmMetaMstBean clmMetaMst : clmMetaMstList) {
            if (clmMetaMst.getClmId().equals(clmId)) {
                return clmMetaMst.isNumber();
            }
        }
        return false;
    }

    // 以下、アクセッサ。

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public String getTblId() {
        return tblId;
    }

    public void setTblId(String tblId) {
        this.tblId = tblId;
    }

    public String getClmId() {
        return clmId;
    }

    public void setClmId(String clmId) {
        this.clmId = clmId;
    }

    public int getSortNum() {
        return sortNum;
    }

    public void setSortNum(int sortNum) {
        this.sortNum = sortNum;
    }

    public String getDispName() {
        return dispName;
    }

    public void setDispName(String dispName) {
        this.dispName = dispName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getWcharConv() {
        return wcharConv;
    }

    public void setWcharConv(int wcharConv) {
        this.wcharConv = wcharConv;
    }

    public String getTimeOption() {
        return timeOption;
    }

    public void setTimeOption(String timeOption) {
        this.timeOption = timeOption;
    }

    public String getOutStyleComma() {
        return outStyleComma;
    }

    public void setOutStyleComma(String outStyleComma) {
        this.outStyleComma = outStyleComma;
    }

    public String getOutStyleDate() {
        return outStyleDate;
    }

    public void setOutStyleDate(String outStyleDate) {
        this.outStyleDate = outStyleDate;
    }

    public String getOutStyleTime() {
        return outStyleTime;
    }

    public void setOutStyleTime(String outStyleTime) {
        this.outStyleTime = outStyleTime;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public int getSelMstSiteId() {
        return selMstSiteId;
    }

    public void setSelMstSiteId(int selMstSiteId) {
        this.selMstSiteId = selMstSiteId;
    }

    public String getSelMstId() {
        return selMstId;
    }

    public void setSelMstId(String selMstId) {
        this.selMstId = selMstId;
    }

}
