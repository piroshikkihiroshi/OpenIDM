package jp.co.webcrew.filters.util;

import java.util.List;

import jp.co.webcrew.filters.bean.voice.HikkoshiVoiceBean;
import jp.co.webcrew.filters.bean.voice.SateiomakaseVoiceBean;
import jp.co.webcrew.filters.bean.voice.VoiceBean;

public class VoiceNewHtmlUtil 
{
	/**
	 * Get 口コミ Html for Hikkoshi
	 * @param strCompanyId
	 * @param nDispCount
	 * @param lstDispList
	 * @return
	 */
	public static String getHikkoshiHtml(String strCompanyId, int nDispCount, List<VoiceBean> lstDispList) 
	{
		StringBuffer sbufDispHtml = new StringBuffer();
		sbufDispHtml.append("<h2>利用者の口コミ</h2>")
			.append("<div class=\"indentBox02\">");
	  		//.append("<script type=\"text/javascript\" src=\"/hikkoshi/js/jquery.js\"></script>");
    
		if (lstDispList.isEmpty()) {
			sbufDispHtml.append("口コミの投稿がありません。");
		}	
		else
		{
			for (int nCnt=0; nCnt<lstDispList.size(); nCnt++)
			{
				if (nCnt == nDispCount) {
					break;
    			}
    		
	    		HikkoshiVoiceBean objVoiceBean = (HikkoshiVoiceBean)lstDispList.get(nCnt);
	    		sbufDispHtml
	    			.append("<div class=\"voiceBox\">")
			    	.append("<div class=\"title\">")
			    	.append("<div class=\"").append(objVoiceBean.getSexName().equals("女性") ? "woman" : "man").append("\">")
			    	.append(objVoiceBean.getNickName() ).append("さん ").append(objVoiceBean.getAddress1()).append(objVoiceBean.getAddress2()).append(" ").append(objVoiceBean.getAgeRange()).append(" ").append(objVoiceBean.getSexName())
			    	.append("</div><div class=\"date\">投稿日：").append(objVoiceBean.getLastUpadte().replaceAll("/", ".").replace("投稿", "")).append("</div>")
			    	.append("</div>")
			    	
				    .append("<div class=\"voiceBlock\">")
				    .append("<div class=\"com\">引越し業者：<span class=\"faceBold\">").append(objVoiceBean.getCompanyName()).append("</span></div>")
				    .append("<div class=\"case\"><span class=\"faceBold\">引越し日：</span>").append(objVoiceBean.getHDateDisp())
				    .append(" | <span class=\"faceBold\">人数：</span>");
	    		
			    if (objVoiceBean.getNumAdult() != null && !"0".equals(objVoiceBean.getNumAdult())) { 
			    	sbufDispHtml.append("大人").append(objVoiceBean.getNumAdult()).append("人");
			    }
			    
			    if (objVoiceBean.getNumChild() != null && !"0".equals(objVoiceBean.getNumChild())) { 
			    	sbufDispHtml.append("子供").append(objVoiceBean.getNumChild()).append("人");
			    }
			    
			    sbufDispHtml
				    .append(" | <span class=\"faceBold\">距離：</span>").append(objVoiceBean.getAddressRange())
				    .append(" | <span class=\"faceBold\">引越し経験：</span>").append(objVoiceBean.getMoveNumName())
				    .append("</div>")
				    
				    .append("<div class=\"decideBlock\">")
				    .append("料金：<span class=\"rate\">").append(objVoiceBean.getPrice()).append("</span>")
				    .append("</div>")
				    .append("<!-- .voiceBlock --></div>")
				    
				    .append("<div class=\"adviceBlock\"><span class=\"good\">良かった点</span>")
				    .append("<p>").append(objVoiceBean.getCmpnySvcCommentGood()).append("</p>")
				    .append("</div>")
				    .append("<!-- .voiceBox --></div>")
				    
				    .append("<div class=\"detailBlock\" id=\"vote_num_%{set.enquete_id.value}\">参考になった件数:").append(objVoiceBean.getUsefulVoteNum() )
				    .append("件")
				    .append("<a href=\"/hikkoshi/voice/com/c").append(objVoiceBean.getCompanyIdMtm())
				    .append("/v").append(objVoiceBean.getEnqueteId()).append("/\">この口コミの詳細を見る</a></div>");

			}
    	
		    if (lstDispList.size() > nDispCount) {
		    	sbufDispHtml.append("<div class=\"linkButton\">").append("<a href=\"/hikkoshi/voice/com/c").append(strCompanyId).append("/\">すべての口コミを見る</a></div>");
		    }	
		}
    
	    sbufDispHtml
	    	.append("<div class=\"bottomLinkBox\"><a href=\"/hikkoshi/com/\">引越し業者一覧に戻る</a></div>")
	    	.append("<!-- .indentBox02 --></div>");
	    
	    return sbufDispHtml.toString();
	}
	
	/**
	 * Get 口コミ Html for Sateiomakase
	 * @param strCompanyId
	 * @param nDispCount
	 * @param lstDispList
	 * @return
	 */
	public static String getSateiomakaseHtml(String strCompanyId, int nDispCount, List<VoiceBean> lstDispList) 
	{
		StringBuffer sbufDispHtml = new StringBuffer();
		sbufDispHtml.append("<!-- /indentBox01 -->")
	  		.append("<div class=\"indentBox01\" style=\"padding:0px;\">")
	  		.append("<h2>利用者の口コミ</h2>")
	  		.append("<script type=\"text/javascript\" src=\"/car-kaitori/js/jquery.js\"></script>");
    
		if (lstDispList.isEmpty()) {
			sbufDispHtml.append("口コミの投稿がありません。");
		}	
		else
		{
			for (int nCnt=0; nCnt<lstDispList.size(); nCnt++)
			{
				if (nCnt == nDispCount) {
					break;
    			}
				
				SateiomakaseVoiceBean objVoiceBean = (SateiomakaseVoiceBean)lstDispList.get(nCnt);
				
				sbufDispHtml.append("<div class=\"voiceBox\">")
					.append("<table>")
					.append("<tr class=\"header\">")
					.append("<th colspan=\"3\">").append(objVoiceBean.getNickName()).append("さん ").append(objVoiceBean.getAddress1()).append(objVoiceBean.getAddress2()).append(" ").append(objVoiceBean.getAgeRange()).append(" ").append(objVoiceBean.getSexName()).append("</th>")
					.append("<th class=\"date\">").append(objVoiceBean.getLastUpadte()).append("</th>")
					.append("</tr>")
					.append("<tr>")
					.append("<th>サイト利用日</th>")
					.append("<td>").append(objVoiceBean.getStepLastUpadteDisp()).append("</td>")
					.append("<th>売却業者</th>")
					.append("<td><strong>").append(objVoiceBean.getCompanyName()).append("</strong></td>")
					.append("</tr>")
					.append("<tr>")
					.append("<th>メーカー</th>")
					.append("<td>").append(objVoiceBean.getMakeName()).append("</td>")
					.append("<th>車種</th>")
					.append("<td>").append(objVoiceBean.getShashuName()).append("</td>")
					.append("</tr>")
					.append("<tr>")
					.append("<th>年式</th>")
					.append("<td>").append(objVoiceBean.getModelYearDisp()).append("</td>")
					.append("<th>カラー</th>")
					.append("<td>").append(objVoiceBean.getBcBase()).append("</td>")
					.append("</tr>")
					.append("<tr>")
					.append("<th class=\"reason\">売却の決め手</th>")
					.append("<td colspan=\"3\">").append(objVoiceBean.getReasonName()).append("</td>")
					.append("</tr>")
					.append("</table>")
					.append("<div class=\"detailBlock\">参考になった件数").append(objVoiceBean.getUsefulVoteNum())
					.append("件　<a href=\"/car-kaitori/voice/company/c").append(objVoiceBean.getCompanyIdMtm())
					.append("/v").append(objVoiceBean.getEnqueteId()).append("/\">この買取口コミの詳細を見る</a></div>")
					.append("</div>");
			}
    	
			if (lstDispList.size() > nDispCount) {
				sbufDispHtml.append("<div class=\"detailBlock\">").append("<a href='/car-kaitori/voice/company/c").append(strCompanyId).append("'/>すべての口コミを見る</a></div>");
			}	
		}
    
	    sbufDispHtml.append("</div>")
			.append("<!--  indentBox01/ -->");
	    
	    return sbufDispHtml.toString();
	}	
}
