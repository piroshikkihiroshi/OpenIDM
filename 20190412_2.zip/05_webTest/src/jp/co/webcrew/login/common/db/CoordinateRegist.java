package jp.co.webcrew.login.common.db;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.Record;


public class CoordinateRegist {
    
    /** ロガー */
    private static final Logger log = Logger.getLogger(CoordinateRegist.class);


	/** siteId */
	private String _siteId;
	/** guid */
	private String _guid;
	/** stepUserId */
	private String _stepUserId;
	/** stepOrderId */
	private String _stepOrderId;
	
	/** 不可視 */
	private CoordinateRegist(){}
		
	/**
	 * コンストラクタ
	 * @param guid
	 * @param siteId
	 */
	public CoordinateRegist(String guid , String siteId ){
		set_guid(guid);
		set_siteId(siteId);
	}
	
	/**
	 * データベースからデータを読み込む
	 * @param db
	 * @throws SQLException
	 */
	public void load(DBAccess db) throws SQLException {
		String sql = "select * from " + db.getSchema(".") + "coordinate_regist where guid=? and site_id=?";
		db.prepareStatement(sql);
		db.setString(1, get_guid());
		db.setString(2, get_siteId());
		Record rec = Record.getFirstRowOf(db);
		if(rec == null) {
			//何もしない
		} else {
			set_stepUserId(rec.getString("STEP_USER_ID"));
			set_stepOrderId(rec.getString("STEP_ORDER_ID"));
		}
	}

	/**
	 * PK定義に基づき、guidとsiteidをキーにDBデータを削除する
	 * @param db
	 * @throws SQLException
	 */
	public void delete(DBAccess db) throws SQLException {
		String sql = "delete from " + db.getSchema(".") + "coordinate_regist where guid=? and site_id=?";
		db.prepareStatement(sql);
		db.setString(1, get_guid());
		db.setString(2, get_siteId());
		db.executeUpdate();		
	}
	
	/**
	 * 該当GUIDのデータを全て消去する
	 * @param db
	 * @throws SQLException
	 */
	public void deleteByGuid(DBAccess db) throws SQLException {
        String guid = ValueUtil.nullToStr(get_guid());
        if (guid.equals("")){
            return;
        }
        
		String sql = "delete from " + db.getSchema(".") + "coordinate_regist where guid=? ";
		db.prepareStatement(sql);
		db.setString(1, get_guid());
		db.executeUpdate();		
        log.info("COORDINATE_REGISTの情報を削除しました。guid=" + guid);
	}
	
	
	/**
	 * GUIDを取得する
	 * @return
	 */
	public String get_guid() {
		return _guid;
	}

	/**
	 * GUIDをセットする
	 * @return
	 */
	public void set_guid(String _guid) {
		this._guid = _guid;
	}

	/**
	 * siteIdを取得する
	 * @return
	 */
	public String get_siteId() {
		return _siteId;
	}

	/**
	 * siteIdをセットする
	 * @param String id サイトID
	 */
	public void set_siteId(String id) {
		_siteId = id;
	}

	/**
	 * stepOrderIdを取得する
	 * @return
	 */
	public String get_stepOrderId() {
		return _stepOrderId;
	}

	/**
	 * stepOrderIdをセットする
	 * @param orderId
	 */
	public void set_stepOrderId(String orderId) {
		_stepOrderId = orderId;
	}

	/**
	 * stepUserIdを取得する
	 * @return
	 */
	public String get_stepUserId() {
		return _stepUserId;
	}

	/**
	 * stepUserIdをセットする
	 * @param userId
	 */
	public void set_stepUserId(String userId) {
		_stepUserId = userId;
	}
}
