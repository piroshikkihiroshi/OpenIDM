﻿'宣言クラス

Imports System.Runtime.InteropServices
Imports System.Diagnostics
Imports System.Text 'stringbuilder用
Public Class DeclareCs
    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function FindWindow(ByVal lpClassName As String, _
        ByVal lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll")> _
    Public Shared Function IsIconic(ByVal hWnd As IntPtr) As _
    <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("user32.dll")> _
    Public Shared Function ShowWindowAsync(ByVal hWnd As IntPtr, ByVal nCmdShow As Integer) As _
    <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("user32.dll")> _
    Public Shared Function SetForegroundWindow(ByVal hWnd As IntPtr) As _
    <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    Public Delegate Function EnumWindowsProc(ByVal hWnd As IntPtr, ByVal lParam As IntPtr) As Boolean

    <DllImport("user32.dll", CharSet:=CharSet.Auto)> _
    Public Shared Function EnumChildWindows(ByVal hWndParent As System.IntPtr, ByVal lpEnumFunc As EnumWindowsProc, ByVal lParam As Integer) As Boolean
    End Function


    'functionの宣言
    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function GetClassName(ByVal hWnd As IntPtr, _
        ByVal lpClassName As StringBuilder, ByVal nMaxCount As Integer) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function GetWindowText(ByVal hWnd As IntPtr, _
        ByVal lpString As StringBuilder, ByVal nMaxCount As Integer) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function GetWindowTextLength(ByVal hWnd As IntPtr) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Public Shared Function SendMessage( _
     ByVal hwnd As IntPtr, _
     ByVal wMsg As Integer, _
     ByVal wParam As Integer, _
     ByVal lParam As String _
   ) As Integer
    End Function

    Public Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" ( _
              ByVal lpApplicationName As String, _
              ByVal lpKeyName As String, _
              ByVal lpDefault As String, _
              ByVal lpReturnedString As String, _
              ByVal nSize As Integer, _
              ByVal lpFileName As String) As Integer

    ' 20170429 追加
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Public Shared Function PostMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As Boolean
    End Function


    'Public Declare Function SendMessageTimeout Lib "user32" Alias "SendMessageTimeoutA" _
    '(ByVal hwnd As Long, ByVal msg As Long, ByVal wParam As Long, ByVal lParam As _
    'Long, ByVal fuFlags As Long, ByVal uTimeout As Long, ByVal lpdwResult As Long) As Long

    '<DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    'Public Shared Function SendMessageTimeout( _
    'ByVal hwnd As Long, ByVal msg As Long, ByVal wParam As Long, ByVal lParam As _
    'Long, ByVal fuFlags As Long, ByVal uTimeout As Long, ByVal lpdwResult As Long) As Long
    'End Function

    <Flags()> _
    Public Enum SendMessageTimeoutFlags
        SMTO_NORMAL = 0
        SMTO_BLOCK = 1
        SMTO_ABORTIFHUNG = 2
        SMTO_NOTIMEOUTIFNOTHUNG = 8
        SMTO_ERRORONEXIT = 32
    End Enum

    <DllImport("user32.dll", SetLastError:=True)> _
    Public Shared Function SendMessageTimeout( _
    ByVal hwnd As IntPtr, ByVal Msg As Integer, ByVal wParam As IntPtr, ByVal lParam As String, ByVal flags As SendMessageTimeoutFlags, ByVal timeout As Integer, ByRef result As IntPtr) As IntPtr
    End Function


    <DllImport("USER32.DLL")> _
    Public Shared Sub mouse_event(ByVal dwFlags As Integer, ByVal dx As Integer, _
    ByVal dy As Integer, ByVal cButtons As Integer, ByVal dwExtraInfo As Integer)
    End Sub




    'グローバル変数
    Public Shared glTgtClassTitle As String
    Public Shared glTgtHndl As IntPtr

    Public Shared glTLEDITCol As Collection

    Public Shared glHdInfoDic As Dictionary(Of String, String)
    Public Shared glComboDic As New Dictionary(Of String, Object)
    '通常数値かコンボボックスなどを見分ける
    Public Shared gliCtrlTypeDic As New Dictionary(Of String, String)

    Public Shared glSqlCom As String

    'ディスプレイの高さ
    Public Shared glDispHeight As Integer = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height
    'ディスプレイの幅
    Public Shared glDispWidth As Integer = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width


    '定数

    Public Const MAX_ROW = 50
    Public Const HISTORY_ST_ROW = 100


    'Public Const WM_ACTIVATE = &H6
    'Public Const WM_SETTEXT = &HC
    'Public Const WM_KEYDOWN = &H100
    'Public Const VK_RETURN = &HD   '   Enter

    'Public Const SW_HIDE = 0                                       '' ウィンドウを非表示にし、他のウィンドウをアクティブにします。
    'Public Const SW_MAXIMIZE = 3                                   '' ウィンドウを最大化します。
    'Public Const SW_MINIMIZE = 6                                   '' ウィンドウを最小化し、Z 順位が次のトップレベルウィンドウをアクティブにします。
    'Public Const SW_RESTORE = 9                                    '' ウィンドウをアクティブにし、表示します。ウィンドウが最小化されていたり最大化されていたりすると、元の位置とサイズに戻ります。
    'Public Const SW_SHOW = 5                                       '' ウィンドウをアクティブにして、現在の位置とサイズで表示します。
    'Public Const SW_SHOWDEFAULT = 10                               '' アプリケーションを起動させたプログラムが CreateProcess 関数に渡すSTARTUPINFO 構造体の wShowWindow メンバで指定された SW_ フラグを基にして、表示状態を設定します。
    'Public Const SW_SHOWMAXIMIZED = 3                              '' ウィンドウをアクティブにして、最大化します。
    'Public Const SW_SHOWMINIMIZED = 2                              '' ウィンドウをアクティブにして、最小化します。
    'Public Const SW_SHOWMINNOACTIVE = 7                            '' ウィンドウを最小化します。アクティブなウィンドウは、アクティブな状態を維持します。非アクティブなウィンドウは、非アクティブなままです。
    'Public Const SW_SHOWNA = 8                                     '' ウィンドウを現在の状態で表示します。アクティブなウィンドウはアクティブな状態を維持します。
    'Public Const SW_SHOWNOACTIVATE = 4                             '' ウィンドウを直前の位置とサイズで表示します。アクティブなウィンドウはアクティブな状態を維持します。
    'Public Const SW_SHOWNORMAL = 1                                 '' ウィンドウをアクティブにして、表示します。ウィンドウが最小化または最大化されているときは、位置とサイズを元に戻します。


    Public Const INI_FILE = "Setting.ini"

    '設定ファイルから取得するように変更
    'Public Shared TGT_SERVER_NAME As String = ""
    'Public Shared TGT_DB As String = ""
    'Public Shared TGT_USER As String = ""
    'Public Shared TGT_PASS As String = ""
    Public Shared TGT_BOOK_NAME As String = ""
    Public Shared TGT_SHEET_NAME As String = ""




    ' 20170429 追加

    '---------mouse_event
    Public Const MOUSE_MOVED = &H1              'マウスを移動する(相対座標)
    Public Const MOUSEEVENTF_ABSOLUTE = &H8000& 'MOUSE_MOVED or で絶対座標を指定
    Public Const MOUSEEVENTF_LEFTUP = &H4       '左ボタンUP
    Public Const MOUSEEVENTF_LEFTDOWN = &H2     '左ボタンDown
    Public Const MOUSEEVENTF_MIDDLEDOWN = &H20  '中央ボタンDown
    Public Const MOUSEEVENTF_MIDDLEUP = &H40    '中央ボタンUP
    Public Const MOUSEEVENTF_RIGHTDOWN = &H8    '右ボタンDown
    Public Const MOUSEEVENTF_RIGHTUP = &H10     '右ボタンUP
    '---------mouse_event


    'グローバル変数
    'Public glInputAry As Object
    'Public glLoopIdx As Long
    'Public glTgtStr As String
    'Public glTgtHwnd As Long
    'Public glHwndCol As Collection
    'Public glRet As Integer
    Public Shared glInputAry As Object
    Public Shared glLoopIdx As Long
    Public Shared glTgtStr As String
    Public Shared glTgtHwnd As Long
    Public Shared glHwndCol As Collection
    Public Shared glRet As Integer

    '定数
    Public Const WM_ACTIVATE = &H6
    Public Const WM_SETTEXT = &HC
    Public Const WM_GETTEXT = &HD  'テキスト取得
    Public Const WM_KEYDOWN = &H100
    Public Const WM_KEYUP As Long = &H101
    Public Const VK_RETURN = &HD   '   Enter
    Public Const WM_GETTEXTLENGTH = &HE '

    Public Const SW_HIDE = 0                                       '' ウィンドウを非表示にし、他のウィンドウをアクティブにします。
    Public Const SW_MAXIMIZE = 3                                   '' ウィンドウを最大化します。
    Public Const SW_MINIMIZE = 6                                   '' ウィンドウを最小化し、Z 順位が次のトップレベルウィンドウをアクティブにします。
    Public Const SW_RESTORE = 9                                    '' ウィンドウをアクティブにし、表示します。ウィンドウが最小化されていたり最大化されていたりすると、元の位置とサイズに戻ります。
    Public Const SW_SHOW = 5                                       '' ウィンドウをアクティブにして、現在の位置とサイズで表示します。
    Public Const SW_SHOWDEFAULT = 10                               '' アプリケーションを起動させたプログラムが CreateProcess 関数に渡すSTARTUPINFO 構造体の wShowWindow メンバで指定された SW_ フラグを基にして、表示状態を設定します。
    Public Const SW_SHOWMAXIMIZED = 3                              '' ウィンドウをアクティブにして、最大化します。
    Public Const SW_SHOWMINIMIZED = 2                              '' ウィンドウをアクティブにして、最小化します。
    Public Const SW_SHOWMINNOACTIVE = 7                            '' ウィンドウを最小化します。アクティブなウィンドウは、アクティブな状態を維持します。非アクティブなウィンドウは、非アクティブなままです。
    Public Const SW_SHOWNA = 8                                     '' ウィンドウを現在の状態で表示します。アクティブなウィンドウはアクティブな状態を維持します。
    Public Const SW_SHOWNOACTIVATE = 4                             '' ウィンドウを直前の位置とサイズで表示します。アクティブなウィンドウはアクティブな状態を維持します。
    Public Const SW_SHOWNORMAL = 1                                 '' ウィンドウをアクティブにして、表示します。ウィンドウが最小化または最大化されているときは、位置とサイズを元に戻します。

    Public Const BM_CLICK = &HF5                                        'Click
    Public Const WM_LBUTTONDOWN = &H201                     '左クリック

    Public Const SMTO_ABORTIFHUNG = &H2

    Public Const CONFIG_SH = "configSheet"
    Public Const LOG_SHEET = "ログ"
    Public Const MAIN_SH = "main"
    Public Const ST_ROW = 6
    Public Const ST_CLM = 9
    Public Const WAIT_TIME As Integer = 750 '待ち時間(ms)

    Public Const WAIT_MIN_TIME As Integer = 10 '短い待ち時間(ms)







End Class
