package jp.co.webcrew.login.common;

import jp.co.webcrew.login.common.db.MemberMst;

/**
 * リマインダ処理結果を格納するクラス
 * 
 * @author Takahashi
 *
 */
public class ReminderResult {
	/*
	 * 定数定義
	 */
	
	/** メールタイプ：PC */
	public static final int TYPE_PC_MAIL = MemberMst.TYPE_PC_MAIL;

	/** メールタイプ：携帯 */
	public static final int TYPE_MB_MAIL = MemberMst.TYPE_MB_MAIL;
	
	/** メールタイプ：法人 */
	public static final int TYPE_CP_MAIL = MemberMst.TYPE_CP_MAIL;

	/** 登録状態：仮登録 */
	public static final int STAT_TEMP_REG = 1;

	/** 登録状態：本登録 */
	public static final int STAT_REAL_REG = 2;

	/** 入力メールアドレスが不正 */
	public static final int REMIND_INPUT_EMAIL_ERROR      = 1;

	/** 入力誕生日が不正 */
	public static final int REMIND_INPUT_BIRTHDAY_ERROR   = 2;

	/** 該当EMAILがテーブルに存在しない */
	public static final int REMIND_EMAIL_NOT_EXIST_ERROR  = 3;

	/** 本登録ユーザにおいて、誕生日が合致しない */
	public static final int REMIND_BIRTHDAT_AUTH_ERROR    = 4;

	/** データベースエラー */
	public static final int REMIND_DB_ERROR               = 5;

	/** その他のエラー */
	public static final int REMIND_OTHER_ERROR            = 6;

	
	/*
	 * プロパティ
	 */
	
	/** 処理結果ステータス 成功ならtrue 失敗ならfalse */
	public boolean status = false;

	/** エラーの原因 */
	public int reason = 0;

	/** メールアドレスのタイプ */
	public int emailType = TYPE_PC_MAIL;

	/** 再設定されたパスワード */
	public String newPasswd = "";

	/** 会員マスタに初期登録されていたSITE_ID */
	public String siteId = "";

	/** メールアドレスの会員登録状態 （仮登録/本登録）*/
	public int registStat = STAT_TEMP_REG;
	
	/** 処理開始時点でのguid */
	public String guid = "";

	/** 処理開始時点でDBに格納されているパスワードハッシュ */
	public String passwd = "";
	
	/** 処理開始時点でのリマインダフラグ */
	public String reminder_flag = "";
	
	/** 処理開始時点でのリマインダ送信日付 */
	public String rm_datetime = "";

	/** 処理開始時点での仮登録有効期限 */
	public String limit_datetime = "";

}
