package jp.co.webcrew.filters.filters.session;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.login.common.SessionUtil;
import jp.co.webcrew.phoenix.fwsetting.FrameworkSettingRefreshMstDb;

/**
 * 会員マスタを管理するdbクラス。
 * 
 * @author kurinami
 */
public class MemberMstDb {

    /** ロガー */
    private static final Logger log = Logger.getLogger(MemberMstDb.class);

	/** 会員マスタ取得用SQL */
	private static final String MEMBER_MST_SELECT = "select * from member_mst where guid = ?";

	/** LS_CODE用seqno取得SQL(GS_CODE用のシーケンスを流用) */
	private static final String LS_CODE_SEQNO = "select seq_gs_code.nextval from dual";

	/** ローカルセッションコードでの会員マスタ取得用sql */
	private static final String MEMBER_MST_SELECT_BY_LS_CODE = ""
			+ "select member_mst.*, \n"
			+ "       global_session.*, \n"
			+ "       site_session.*, \n"
			+ "       local_session.*, \n "
			+ "       term_mst.*, \n"
			+ "       site_session.mk_datetime as site_session_mk_datetime, \n"
			+ "       site_session.promo_code as site_session_promo_code, \n"
			+ "       site_session.af_code as site_session_af_code, \n"
			+ "       sysdate as now \n"
			+ "  from member_mst inner join global_session on member_mst.guid = global_session.guid \n"
			+ "                  inner join site_session on global_session.gsid = site_session.gsid \n"
			+ "                  inner join local_session on global_session.gsid = local_session.gsid \n"
			+ "                  left outer join term_mst on site_session.term_id = term_mst.term_id \n"
			+ " where local_session.ls_code = ? \n";

	/** グローバルセッションIDでの会員マスタ取得用sql */
	private static final String MEMBER_MST_SELECT_BY_GS_CODE = ""
			+ "select member_mst.*, \n"
			+ "       global_session.*, \n"
			+ "       site_session.*, \n"
			+ "       local_session.*, \n "
			+ "       term_mst.*, \n"
			+ "       site_session.mk_datetime as site_session_mk_datetime, \n"
			+ "       site_session.promo_code as site_session_promo_code, \n"
			+ "       site_session.af_code as site_session_af_code, \n"
			+ "       sysdate as now \n"
			+ "  from member_mst inner join global_session on member_mst.guid = global_session.guid \n"
			+ "                  inner join site_session on global_session.gsid = site_session.gsid \n"
			+ "                  inner join local_session on global_session.gsid = local_session.gsid \n"
			+ "                  left outer join term_mst on site_session.term_id = term_mst.term_id \n"
			+ " where global_session.gs_code = ? \n";

	/** 永続セッション情報取得用SQL */
	private static final String GLOBAL_SESSION_SELECT = "select * from global_session inner join member_mst on global_session.guid = member_mst.guid where gs_code = ?";

	/** サイトセッションプロパティ取得用SQL */
	private static final String SITE_SESSION_PROPS_SELECT_ALL = "select * from site_session_props where ssid = ?";

	/** サイトセッションプロパティ挿入用SQL */
	private static final String SITE_SESSION_PROPS_INSERT = "insert into site_session_props(ssid, gsid, name, value, site_id) values(?, ?, ?, ?, ?)";

	/** サイトセッションプロパティ削除用sql */
	private static final String SITE_SESSION_PROPS_DELETE = "delete from site_session_props where ssid = ? and name = ?";

	/**
	 * 現在、有効なサイトセッションが存在するかを確認する。
	 * 
	 * @param dba
	 * @param rs
	 * @param siteId
	 * @param referer
	 * @return
	 * @throws SQLException
	 */
	private static String checkSiteSession(DBAccess dbAccess, ResultSet rs,
			int siteId, String referer) throws SQLException {

		// サイトセッションのタイムアウト時間(秒)
		int siteSessionTimeout = SystemPropertiesDb.getInstance()
				.getSecondValue(SystemPropertiesDb.SITE_SESSION_TIMEOUT);

		// サイトセッションの滞在上限時間(秒)
		int siteSessionStayLimit = SystemPropertiesDb.getInstance()
				.getSecondValue(SystemPropertiesDb.SITE_SESSION_STAY_LIMIT);

		// サイトセッションの滞在上限の確認対象となるラストアクセスからの経過時間(秒)
		int siteSessionStayLimitCheckTerm = SystemPropertiesDb.getInstance()
				.getSecondValue(
						SystemPropertiesDb.SITE_SESSION_STAY_LIMIT_CHECK_TERM);

		// 外部サイトからの戻りチェックの確認対象となるラストアクセスからの経過時間(秒)
		int siteSessionOuterSiteCheckTerm = SystemPropertiesDb.getInstance()
				.getSecondValue(
						SystemPropertiesDb.SITE_SESSION_OUTER_SITE_CHECK_TERM);

		if (!dbAccess.next(rs)) {
			// サイトセッションそのものが存在しない場合
			return "サイトセッション情報が存在しません。";
		} else {

			Date now = rs.getTimestamp("now");
			Date mkDatetime = ValueUtil.toDate(rs
					.getString("site_session_mk_datetime"));
			Date lastDatetime = ValueUtil.toDate(rs.getString("last_datetime"));
			int lastSiteId = rs.getInt("last_site_id");

			// 最終サクセス時刻から一定時間たっている場合
			if (ValueUtil.dateDiff(now, lastDatetime) > siteSessionTimeout) {
				return "サイトセッションがタイムアウトしました。";
			}

			// サイトセッション開始から一定時間たっていて、かつ最終アクセス時刻からも一定時間たってる場合
			if (ValueUtil.dateDiff(now, mkDatetime) > siteSessionStayLimit
					&& ValueUtil.dateDiff(now, lastDatetime) > siteSessionStayLimitCheckTerm) {
				return "サイトセッションの滞在上限を超過しました。";
			}

			// 外部サイトから進入してきて、前回アクセスしたサイトIDと、今回アクセスしたサイトIDが違い、
			// かつ最終サクセス時刻から一定時間たっている場合
			if (referer.length() > 0
					&& SiteMstDb.getInstance().getSiteId(referer) == SiteMstDb.OUTSIDE_SITE_ID
					&& lastSiteId != siteId
					&& ValueUtil.dateDiff(now, lastDatetime) > siteSessionOuterSiteCheckTerm) {
				return "リクエストが外部サイトからやってきました。";
			}

			// 上記のどれにも当てはまらない場合、そのサイトセッションを有効なものとみなす。
			return "";
		}
	}

	/**
	 * ログインフラグと最終アクセス日時を見て現在のログイン状態を返す。
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private static boolean getLoginStatus(ResultSet rs) throws SQLException {

		// ログインのタイムアウト時間(秒)
		int loginTimeout = SystemPropertiesDb.getInstance().getSecondValue(
				SystemPropertiesDb.LOGIN_TIMEOUT);

		Date now = rs.getTimestamp("now");
		Date lastDatetime = ValueUtil.toDate(rs.getString("last_datetime"));

		if (rs.getBoolean("login_flag")
				&& ValueUtil.dateDiff(now, lastDatetime) < loginTimeout) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * サイトセッション情報を更新する。
	 * 
	 * @param ssid
	 * @param loginFlag
	 * @param siteId
	 * @param url
	 * @throws SQLException
	 */
	private static void updateSiteSession(int ssid, boolean loginFlag,
			int siteId, String url, ResultSet rs) throws SQLException {

		DBAccess dbAccess = null;
		try {

            // チェック有効の場合更新期間制限を行う
		    String siteSessionUpdateEnabled = FrameworkSettingRefreshMstDb.getInstance().getPropValue(
                    "site_session_update_enabled");
            log.debug("siteSessionUpdateEnabled:" + siteSessionUpdateEnabled + " reqUrl:" + url);
            if (FrameworkSettingRefreshMstDb.YES.equals(siteSessionUpdateEnabled)) {
                // 対象のURLの場合更新期間制限を行う
                String siteSessionUpdateEnabledPrefixes = FrameworkSettingRefreshMstDb.getInstance().getPropValue(
                        "site_session_update_enabled_prefixes");
                if (isTargetUrl(siteSessionUpdateEnabledPrefixes, url)) {
                    int siteSessionUpdateFrequency = FrameworkSettingRefreshMstDb.getInstance().getPropIntValue(
                            "site_session_update_frequency", 0);

                    Date now = rs.getTimestamp("now");
                    Date lastDatetime = ValueUtil.toDate(rs.getString("last_datetime"));
                    log.debug("now:" + now + " lastDatetime:" + lastDatetime + " siteSessionUpdateFrequency:"
                            + siteSessionUpdateFrequency);
                    // 最終サクセス時刻から一定時間たっている場合更新行う
                    if (ValueUtil.dateDiff(now, lastDatetime) < siteSessionUpdateFrequency) {
                        log.debug("サイトセッション更新しない！");
                        return;
                    }
                }
            }
            log.debug("サイトセッション更新する！");

            dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// 最終アクセス日時を更新する。
			SessionUtil.updateSiteSession(dbAccess, ssid, loginFlag, siteId,
					url);

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;
		} finally {
			DBAccess.close(dbAccess);
		}
	}

    /**
     * 制限対応URLかどうか
     * 
     * @param enablePrefixes
     * @param requestUrl
     * @return
     */
    private static boolean isTargetUrl(String enabledPrefixes, String requestUrl) {
        // 空行除外処理
        String[] array = enabledPrefixes.split("\r\n|\r|\n");
        for (String item : array) {
            if (ValueUtil.nullToStr(item).length() != 0 && requestUrl.startsWith(item)) {
                return true;
            }
        }
        return false;
    }

	/**
	 * 会員マスタを取得する。
	 * 
	 * @param guid
	 * @return
	 * @throws SQLException
	 */
	public static Map getMemberMst(String guid) throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			Map memberMstMap = new HashMap();

			// 会員マスタを検索する。
			dbAccess.prepareStatement(MEMBER_MST_SELECT);
			dbAccess.setString(1, guid);
			rs = dbAccess.executeQuery();

			ResultSetMetaData resultSetMetaData = rs.getMetaData();

			String[] columnNames = new String[resultSetMetaData
					.getColumnCount()];
			for (int i = 0; i < columnNames.length; i++) {
				columnNames[i] = resultSetMetaData.getColumnName(i + 1);
			}

			if (dbAccess.next(rs)) {
				for (int i = 0; i < columnNames.length; i++) {
					memberMstMap.put(columnNames[i].toLowerCase(), ValueUtil
							.nullToStr(rs.getString(i + 1)));
				}
			} else {
				for (int i = 0; i < columnNames.length; i++) {
					memberMstMap.put(columnNames[i].toLowerCase(), "");
				}
			}

			return memberMstMap;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * lsCodeを元にDBから会員マスタを取得する。 見つからない場合は、nullが返る。
	 * 
	 * @param lsCode
	 * @param siteId
	 * @param url
	 * @param referer
	 * @param log
	 * @return
	 * @throws SQLException
	 */
	public static UserInfo getUserInfoByLsCode(String lsCode, int siteId,
			String url, String referer, Logger log) throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// 会員マスタを検索する。
			dbAccess.prepareStatement(MEMBER_MST_SELECT_BY_LS_CODE);
			dbAccess.setString(1, lsCode);

			// 有効なサイトセッションが存在するかを確認する。
			rs = dbAccess.executeQuery();
			String message = checkSiteSession(dbAccess, rs, siteId, referer);
			if (message.length() > 0) {
				log.info("[ls_code:" + lsCode + "] " + message);
				return null;
			}

			// beanに情報を格納する。
			UserInfo userInfo = new UserInfo();
			userInfo.setUserInfoFromDb(rs);
			userInfo.setLoginFlag(getLoginStatus(rs));

			// DB上のサイトセッション情報を更新する。
			updateSiteSession(ValueUtil.toint(userInfo.getSsid()), userInfo
					.isLoginFlag(), siteId, url, rs);

			return userInfo;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * gsCodeを元にDBから会員マスタを取得する。 見つからない場合は、nullが返る。
	 * 
	 * @param gsCode
	 * @param siteId
	 * @param url
	 * @param referer
	 * @param log
	 * @return
	 * @throws SQLException
	 */
	public static UserInfo getUserInfoByGsCode(String gsCode, int siteId,
			String url, String referer, Logger log) throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// 会員マスタを検索する。
			dbAccess.prepareStatement(MEMBER_MST_SELECT_BY_GS_CODE);
			dbAccess.setString(1, gsCode);

			// 有効なサイトセッションが存在するかを確認する。
			rs = dbAccess.executeQuery();
			String message = checkSiteSession(dbAccess, rs, siteId, referer);
			if (message.length() > 0) {
				log.info("[gs_code:" + gsCode + "] " + message);
				return null;
			}

			// beanに情報を格納する。
			UserInfo userInfo = new UserInfo();
			userInfo.setUserInfoFromDb(rs);
			userInfo.setLoginFlag(getLoginStatus(rs));

			// DB上のサイトセッション情報を更新する。
			updateSiteSession(ValueUtil.toint(userInfo.getSsid()), userInfo
					.isLoginFlag(), siteId, url, rs);

			return userInfo;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * サイトセッションプロパティを返す。
	 * 
	 * @param ssid
	 * @return
	 * @throws SQLException
	 */
	public static Map getSiteSessionProps(String ssid) throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			Map siteSessionProps = new HashMap();

			// サイトセッションプロパティを検索する。
			dbAccess.prepareStatement(SITE_SESSION_PROPS_SELECT_ALL);
			dbAccess.setString(1, ssid);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				siteSessionProps.put(rs.getString("name"), rs
						.getString("value"));
			}

			return siteSessionProps;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * サイトセッションプロパティを挿入する。
	 * 
	 * @param ssid
	 * @param gsid
	 * @param name
	 * @param value
	 * @param siteId
	 * @throws SQLException
	 */
	public static void writeSiteSessionProps(int ssid, int gsid, String name,
			String value, int siteId) throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// サイトセッション情報を作成する。
			dbAccess.prepareStatement(SITE_SESSION_PROPS_DELETE);
			dbAccess.setInt(1, ssid);
			dbAccess.setString(2, name);
			dbAccess.executeUpdate();

			// サイトセッション情報を作成する。
			dbAccess.prepareStatement(SITE_SESSION_PROPS_INSERT);
			dbAccess.setInt(1, ssid);
			dbAccess.setInt(2, gsid);
			dbAccess.setString(3, name);
			// TODO kurinami 【確認】256って短くない？
			dbAccess.setString(4, value.substring(0, Math.min(value.length(),
					256)));
			dbAccess.setInt(5, siteId);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * サイトセッションプロパティを削除する。
	 * 
	 * @param ssid
	 * @param name
	 * @throws SQLException
	 */
	public static void removeSiteSessionProps(int ssid, String name)
			throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// サイトセッション情報を作成する。
			dbAccess.prepareStatement(SITE_SESSION_PROPS_DELETE);
			dbAccess.setInt(1, ssid);
			dbAccess.setString(2, name);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * 会員マスタを作成する。
	 * 
	 * @param lsCode
	 * @param type
	 * @param siteId
	 * @param url
	 * @param referer
	 * @param remoteIp
	 * @param promoCode
	 * @param afCode
	 * @param termId
	 * @param ua
	 * @return
	 * @throws SQLException
	 */
	public static UserInfo makeUserInfoByLsCode(String lsCode, String type,
			int siteId, String url, String referer, String remoteIp,
			String promoCode, String afCode, int termId, String ua,
			String carrier) throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// 会員マスタを作成する。
			String guid = SessionUtil
					.makeMemberMst(dbAccess, promoCode, afCode);

			// グローバルセッション情報を作成する。
			String gsCode = carrier + "-" + getLsCode();
			String gsid = SessionUtil.makeGlobalSession(dbAccess, gsCode, guid);

			// サイトセッション情報を作成する。
			SessionUtil.makeSiteSession(dbAccess, gsid, siteId, url, referer,
					remoteIp, promoCode, afCode, termId, ua);

			// ローカルセッション情報を作成する。
			SessionUtil.makeLocalSession(dbAccess, gsid, siteId, lsCode, type);

			// コミットする。
			dbAccess.commit();

			// 会員マスタを検索する。
			UserInfo userInfo = null;
			dbAccess.prepareStatement(MEMBER_MST_SELECT_BY_LS_CODE);
			dbAccess.setString(1, lsCode);
			rs = dbAccess.executeQuery();
			if (dbAccess.next(rs)) {
				userInfo = new UserInfo();
				userInfo.setUserInfoFromDb(rs);
			}

			return userInfo;

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * 会員マスタを作成する。
	 * 
	 * @param gsCode
	 * @param type
	 * @param siteId
	 * @param url
	 * @param referer
	 * @param remoteIp
	 * @param promoCode
	 * @param afCode
	 * @param termId
	 * @param ua
	 * @return
	 * @throws SQLException
	 */
	public static UserInfo makeUserInfoByGsCode(String gsCode, String type,
			int siteId, String url, String referer, String remoteIp,
			String promoCode, String afCode, int termId, String ua)
			throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			String gsid;

			dbAccess.prepareStatement(GLOBAL_SESSION_SELECT);
			dbAccess.setString(1, gsCode);
			rs = dbAccess.executeQuery();
			if (dbAccess.next(rs)) {
				// すでに登録済みのグローバルセッションコードの場合、

				// グローバルセッションIDを取得する。
				gsid = rs.getString("gsid");

				// 古いサイトセッション情報を削除する。
				SessionUtil.deleteSiteSession(dbAccess, gsid);

			} else {
				// 未登録のグローバルセッションコードの場合、

				// 会員マスタを作成する。
				String guid = SessionUtil.makeMemberMst(dbAccess, promoCode,
						afCode);

				// グローバルセッション情報を作成する。
				gsid = SessionUtil.makeGlobalSession(dbAccess, gsCode, guid);

			}
			DBAccess.close(rs);

			// サイトセッション情報を作成する。
			SessionUtil.makeSiteSession(dbAccess, gsid, siteId, url, referer,
					remoteIp, promoCode, afCode, termId, ua);

			// ローカルセッション情報を作成する。
			String lsCode = getLsCode(dbAccess);
			SessionUtil.makeLocalSession(dbAccess, gsid, siteId, lsCode, type);

			// コミットする。
			dbAccess.commit();

			// 会員マスタを検索する。
			UserInfo userInfo = null;
			dbAccess.prepareStatement(MEMBER_MST_SELECT_BY_GS_CODE);
			dbAccess.setString(1, gsCode);
			rs = dbAccess.executeQuery();
			if (dbAccess.next(rs)) {
				userInfo = new UserInfo();
				userInfo.setUserInfoFromDb(rs);
			}

			return userInfo;

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * サーバのIPとセッションIDにmd5をかけて 当システムで使用するローカルセッションコードを作成する。
	 * 
	 * @param request
	 * @return
	 */
	public static String getLsCode(HttpServletRequest request) {
		String serverIp = request.getLocalAddr();
		String sessionId = request.getSession().getId();

		return ValueUtil.getMd5Digest(serverIp + sessionId);
	}

	/**
	 * ローカルセッションコードを時間から作成する。
	 * 
	 * @param dbAccess
	 * @return
	 * @throws SQLException
	 */
	public static String getLsCode(DBAccess dbAccess) throws SQLException {
		return ValueUtil.getMd5Digest(Long.toString(System.currentTimeMillis())
				+ Long.toString(dbAccess.getSequenceNo(LS_CODE_SEQNO)));
	}

	/**
	 * ローカルセッションコードを時間から作成する。
	 * 
	 * @return
	 * @throws SQLException
	 */
	public static String getLsCode() throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = new DBAccess();
			return getLsCode(dbAccess);

		} finally {
			DBAccess.close(dbAccess);
		}

	}

}
