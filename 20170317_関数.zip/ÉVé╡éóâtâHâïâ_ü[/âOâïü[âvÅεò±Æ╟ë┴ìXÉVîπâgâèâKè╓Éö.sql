
declare

	-- RMI�p
	rmi_host       text;
	rmi_port       text;

	md_oid         text;
	ad_oid         text;
	names_oid      text;
	cnapnames_oid  text;
	sso_oid        text;

	ldap_oid       text[];
	notes_oid      text[];

	-- ���^�f�B���N�g���p
	md_organization_base_dn  text;

	-- AD�p
	ad_group_base_dn  text;

	rec_grp  �O���[�v�K�w���%rowtype;
	rec_buf  record;

	idx  integer;

	force$  boolean := false;

	l_section  text;
	l_formula  text;

	l_cn  text := null;
	l_dn  text := null;

	l_dn_old  text := null;
	l_dn_new  text := null;

	l_child_cn  text := null;

	l_caller  text := null;

	l_returnValue   integer;
	l_epdcSnJP      text;

	arr_attributes      text[];
	arr_member_new      text[];
	arr_member_old      text[];
	arr_mainMember_new  text[];
	arr_mainMember_old  text[];
	arr_epdcChildren    text[];

	flag_update_meta   boolean;
	flag_update_ad     boolean;
	flag_update_notes  boolean;
	flag_update_sso    boolean;
	flag_update_user   boolean;
	

begin

INSERT INTO "�O���[�v���_tmp"(
 cn,
 epdcjrkocode,
 epdcojp,
 epdcsnjp,
 epdcsnkana,
 epdcjrksnjp, 
 epdcfullname,
 epdcfullnamekana,
 epdcparent,
 epdcparentname,
 epdcparentdn,
 businesscategory,
 uniquemember,
 uniquemember_bk,
 epdcchildren,
 epdcchildren_bk,
 epdcmainmember,
 epdcmainmember_bk,
 epdcsubmember,
 epdcsubmember_bk,
 membersad,
 membersad_bk,
 membersnotes,
 membersnotes_bk,
 epdcgroupglmember,
 workflowflag,
 epdcgroupmail,
 epdcrepresentgroup,
 epdcshinseiocode,
 epdcshinseiemployeeno,
 epdcshoninocode,
 epdcshoninemployeeno,
 epdcoperator,
 epdccreatedate,
 epdcmodifydate,
 epdcyoyakucn,
 epdcchangetype,
 beforetriggerflag,
 aftertriggerflag,
 processorflag
 )
    VALUES (
 NEW.cn,
 NEW.epdcjrkocode,
 NEW.epdcojp,
 NEW.epdcsnjp,
 NEW.epdcsnkana,
 NEW.epdcjrksnjp, 
 NEW.epdcfullname,
 NEW.epdcfullnamekana,
 NEW.epdcparent,
 NEW.epdcparentname,
 NEW.epdcparentdn,
 NEW.businesscategory,
 NEW.uniquemember,
 NEW.uniquemember_bk,
 NEW.epdcchildren,
 NEW.epdcchildren_bk,
 NEW.epdcmainmember,
 NEW.epdcmainmember_bk,
 NEW.epdcsubmember,
 NEW.epdcsubmember_bk,
 NEW.membersad,
 NEW.membersad_bk,
 NEW.membersnotes,
 NEW.membersnotes_bk,
 NEW.epdcgroupglmember,
 NEW.workflowflag,
 NEW.epdcgroupmail,
 NEW.epdcrepresentgroup,
 NEW.epdcshinseiocode,
 NEW.epdcshinseiemployeeno,
 NEW.epdcshoninocode,
 NEW.epdcshoninemployeeno,
 NEW.epdcoperator,
 NEW.epdccreatedate,
 NEW.epdcmodifydate,
 NEW.epdcyoyakucn,
 NEW.epdcchangetype,
 NEW.beforetriggerflag,
 NEW.aftertriggerflag,
 NEW.processorflag
 )
 ;

--raise EXCEPTION 'NO ERROR (dummy)';
RETURN NEW; 
END ;

