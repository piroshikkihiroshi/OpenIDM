/**
 * 
 */
package jp.co.webcrew.phoenix.htmlservlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * <pre>
 * </pre>
 * @author Takahashi
 *
 */
public final class SStagUtil {

   
    /** ロガー */
    private static final Logger log = Logger.getLogger(SStagUtil.class);
   
    private static final String MSG_SYSTEM_ERROR = "システムエラーが発生しました。";
    
    private static final String PARENT_DEFAULT_TAG = "span";
    
    private static final boolean READY_HTTPS_IMG_SERVER = true;

    /** 改行文字 */
    private static final String NL = "\r\n";
    
//    /**
//     * <pre>
//     * sstag用のデータベース接続クラスを返す
//     * </pre>
//     * @return
//     * @throws Exception
//     */
//    public static DBAccess getDB() throws SQLException{
//        return WcHtmlServletUtil.getDB();
//    }

    /**
     * <pre>
     * 会員情報にアクセスするためのデータベース接続クラスを返す
     * </pre>
     * @return
     * @throws Exception
     */
    public static DBAccess getMemberDB() throws SQLException{
        return new DBAccess();
    }

    /**
     * <pre>
     * リクエストされたurlを取得する
     * </pre>
     * @param request
     * @return
     */
    public static String getCurrentRequestUrl(HttpServletRequest request) {
        try {
            String url = request.getRequestURL().toString();
            String queryString = request.getQueryString();
            if (queryString != null && queryString.trim().length() != 0) {
                url += "?" + queryString;
            }
            return url;
        } catch (RuntimeException e) {
            log.error("実行時例外エラーが発生しました。" , e);
            return null;
        }
    }
    
    /**
     * 文字列を数値に変換
     * 変換に失敗した場合は0を返します
     * @param str 文字列
     * @return int 数値
     */
    public static int forceInt(String str) {
        int ret = 0;
        try{
            ret = Integer.parseInt(str);            
        }catch(Exception e){
            log.debug("数値変換に失敗しました。: " + str);
        }
        return ret;
    }

    /**
     * <pre>
     * mapから値を取得する。nullは返さない。
     * </pre>
     * @param map
     * @param key
     * @return
     */
    public static String getVal(Map map , String key) {
        if (map == null) {
            return "";
        }
        return ValueUtil.nullToStr(map.get(key));
    }

    /**
     * <pre>
     * request parameter の値を取得する。nullは返さない。
     * </pre>
     * @param request
     * @param key
     * @return
     */
    public static String getVal(HttpServletRequest request , String key) {
        if (request == null) {
            return "";
        }
        return ValueUtil.nullToStr((String)request.getParameter(key));
    }
    
    /**
     * <pre>
     * sstagでparent_tagの指定があればtrue、そうでなければfalseを返す
     * 
     * 現在、デフォルトで span をつけることになっているので、通常は必ずtrueを返すはず
     * 
     * </pre>
     * @param sstagParams
     */
    public static boolean useParentTag(Map sstagParams ) {
        if (sstagParams == null) {
            return false;
        }
        
        String parentTag = getParentTag(sstagParams);
        
        if (parentTag == null) {
            return false; // エラー
        } else if (parentTag.trim().equals("")){
            return false; // 「親タグを使用しない」と明示指定
        } else {
            return true;
        }
    }
    
    /**
     * <pre>
     * parent_tag(最外部に配置するタグ）が指定されていたらその名前を返す。
     * 
     * 指定されていなかったり無効なタグが指定されていた場合はnullを返す。
     * 
     * </pre>
     * @param sstagParams
     */
    public static String  getParentTag(Map sstagParams ) {
        
        if (sstagParams == null) {
            return null;
        }
        
        String parentTag = (String)sstagParams.get("parent_tag");
        
        if (parentTag == null) {
            return PARENT_DEFAULT_TAG;
        }

        if (parentTag.trim().equals("")) {
            return PARENT_DEFAULT_TAG;
        }

        if (parentTag.toLowerCase().startsWith("script")) {

            return  null; // scriptタグは許可しない

        } else {
            return parentTag;
        }
        
//        特定のタグ以外許可しない場合は以下のようなコードに変更する
//        
//        String parent_tag = getVal(sstagParams , "parent_tag");
//        
//        if ( parent_tag.equals("p")  || 
//             parent_tag.equals("h1") ||
//             parent_tag.equals("h2") ||
//             parent_tag.equals("h3") ||
//             parent_tag.equals("h4") ||
//             parent_tag.equals("h5") ||
//             parent_tag.equals("h6") ||
//             parent_tag.equals("div") ) {
//            
//        } else {
//
//            parent_tag = "span";
//            
//        }
    }
    
    /**
     * <pre>
     * 
     * StringBufferに以下の文字列を追加する
     * （tagが div の時は、最後に改行をつける）
     * 
     * 
     * &lt;{tag} class="xxx" style="xxx" &gt;
     * 
     * </pre>
     * @param sb
     * @param sstagParams
     */
    public static void addParentStartTag(StringBuffer sb , Map sstagParams) {
        
        String id = (String)sstagParams.get("id");
        if (id == null) {
            addParentStartTag(sb , sstagParams , null);
        } else {
            addParentStartTag(sb , sstagParams , id);
        }
    }
    
    /**
     * <pre>
     * 
     * StringBufferに以下の文字列を追加する
     * （tagが div の時は、最後に改行をつける）
     * 
     * 
     * &lt;{tag} class="xxx" style="xxx" &gt;
     * 
     * </pre>
     * @param sb
     * @param sstagParams
     * @param html_id 指定された場合、parent_tagに id="xxx" を追加
     */
    public static void addParentStartTag(StringBuffer sb , Map sstagParams , String html_id) {

        if (sb == null) {
            return;
        }
        
        if (sstagParams == null) {
            return;
        }
        
        String parentTag = getParentTag(sstagParams);
        
        if (useParentTag(sstagParams)) {
            
            sb.append("<");
            sb.append(parentTag);
            sb.append(" ");
            
            if (html_id != null && ! html_id.equals("")) {
                sb.append("id=\"");
                sb.append(html_id);
                sb.append("\" ");
            }
            
            if (sstagParams.containsKey("css_class")) {
                sb.append("class=\"");
                sb.append(SStagUtil.getVal(sstagParams , "css_class"));
                sb.append("\" ");
            }
            if (sstagParams.containsKey("css_style")) {
                sb.append("style=\"");
                sb.append(SStagUtil.getVal(sstagParams , "css_style"));
                sb.append("\" ");
            }
            sb.append(">");
            
            if (parentTag.toLowerCase().equals("div")) {
                sb.append(NL);
            }
        }        
    }

    /**
     * <pre>
     * StringBufferに以下の文字列を追加する
     * 
     * （tagが div の時は、冒頭に改行をつける）
     * 
     * &lt;/{tag}&gt;
     * </pre>
     * @param sb
     * @param sstagParams
     */
    public static void addParentEndTag(StringBuffer sb , Map sstagParams) {

        if (sb == null) {
            return;
        }
        
        if (sstagParams == null) {
            return;
        }

        String parentTag = getParentTag(sstagParams);
        
        if (useParentTag(sstagParams)) {
            if (parentTag.toLowerCase().equals("div")) {
                sb.append(NL);
            }
            sb.append("</");
            sb.append(parentTag);
            sb.append(">");
            sb.append(NL);
        }

    }
    
    /**
     * <pre>
     * できうる限り、文字列をカンマ区切りにする。
     * 文字列が数値ならカンマ区切りにし、そうでない場合はそのまま返す。
     * </pre>
     * @param num
     * @return
     */
    public static String groupNumber(String num) {
        
        if (num == null) {
            return null;
        }
        
        if (num.trim().equals("")) {
            return num;
        }
        
        try {
            DecimalFormat decimalFormat1 = new DecimalFormat("###,###");
            return decimalFormat1.format(new BigDecimal(num));
        } catch (Exception e) {
            return num;
        }
        
    }
    
    public static void addTitle (StringBuffer sb , Map sstagParams  ) {
        addTitle(sb , sstagParams , null);
    }
    
    public static void addTitle (StringBuffer sb , Map sstagParams , String defaultTitle ) {
        
        String id = (String)sstagParams.get("id");
        
        if (id == null) {
            addTitle(sb , sstagParams , defaultTitle , null);
        } else {
            addTitle(sb , sstagParams , defaultTitle , id + "_title");
        }
        
    }

    public static void addTitle (StringBuffer sb , Map sstagParams , String defaultTitle , String id) {
        
        if (sb == null) {
            return;
        }

        if (sstagParams == null) {
            return;
        }
        
        String title = (String)sstagParams.get("title");
        
        if (title == null) {
            // タイトルパラメータが無い場合は、デフォルト出力を行う
            if (defaultTitle == null || defaultTitle.equals("")) {
                // ただし、デフォルト値の指定も無い場合は、何も出力をしない
                return;
            }
            title = defaultTitle;
        }

        if (title.equals("")) {
            // title="" と、空文字をわざわざ指定した場合は、title非使用と判断し、何も出力しない
            return;
        }
        
        sb.append("<span");
        if (sstagParams.containsKey("title_style") ||  sstagParams.containsKey("title_class")) {
            if (sstagParams.containsKey("title_style")) {
                sb.append(" style=\"");
                sb.append(getVal(sstagParams , "title_style"));
                sb.append("\" ");
            }
            if (sstagParams.containsKey("title_class")) {
                sb.append(" class=\"");
                sb.append(getVal(sstagParams , "title_class"));
                sb.append("\" ");
            }
        }
        if (id != null) {
            sb.append(" id=\"");
            sb.append(id);
            sb.append("\" ");
        }
        sb.append(">");
        sb.append(title);
        sb.append("</span>");

    }

    public static boolean isDebugMode (Map sstagParams) {
        
        if (sstagParams == null) {
            return false;
        }
        
        String debug = getVal(sstagParams , "debug");
        
        if (debug.equals("1") || debug.equals("true")) {
            return true;
        }
        
        return false;
        
    }

    
    /**
     * <pre>
     * urlのhttp/https をrequestプロトコルに応じて自動的に切り替える
     * </pre>
     * @param request
     * @param url
     * @return
     */
    public static String adjustProtocol (HttpServletRequest request , String url) {

        if (READY_HTTPS_IMG_SERVER) {
            // 画像サーバのhttps化が準備できていない間は、urlの変換は行わない
            return url;
        }
        
        if (request == null) {
            return url;
        }

        if (url == null) {
            return null;
        }
        
        if (url.trim().length() == 0) {
            return url;
        }
    
        try {
            if (url.startsWith("http")) {

                String requestScheme = ValueUtil.nullToStr(request.getScheme()).trim();
                
                if (requestScheme.toLowerCase().equals("http")) {
                    
                    if (url.startsWith("https:")) {
                        return url.replaceAll("^https:", "http:");
                    }
                    
                }

                if (requestScheme.toLowerCase().equals("https")) {
                    
                    if (url.startsWith("http:")) {
                        return url.replaceAll("^http:", "https:");
                    }
                    
                }
            }

            return url;

        } catch (RuntimeException e) {
            e.printStackTrace();
            return url;  // 何もしない
        }
        
        
    }

    /**
     * 
     * <pre>
     *  内部パスや URLなど最後に / が付く可能性のある文字列を連結。
     *  左側文字列の最後に / が付かない場合、付与してから連結する。
     * </pre>
     * @param left 左側文字列。
     * @param index 右側文字列
     * @return
     */
    public static String pathCat( String left, String right ) {
        
        left  = ValueUtil.nullToStr(left).trim();
        right = ValueUtil.nullToStr(right).trim();

        String url = null;
        if( left.endsWith( "/" ) ){
            url = left + removeFirstSlash(right);
        } else {
            url = left + "/" + removeFirstSlash(right);
        }
        
        return url;
    }
    
    private static String removeFirstSlash(String src) {
        if (src == null) {
            return null;
        }

        if (src.startsWith("/")) {
            return src.substring(1);
        }
        
        return src;
    }

    /**
     * <pre>
     * ec_sstag用の共通javascriptをインクルードするコードを追加する
     * </pre>
     * @param sb
     * @param request
     */
    public static void addJsIncludeCode(StringBuffer sb , HttpServletRequest request){
        
        if (sb == null || request == null) {
            return;
        }
        
        // ---- jsインクルード用のコードを生成

        String jsFileName = ValueUtil.nullToStr(
            SStagUtil.pathCat(
                SStagUtil.adjustProtocol(request , SystemPropertiesDb.getInstance().get("EC_SSTAG_JS_PATH")),
                "ec_sstag.js"
            )
        );

        if (jsFileName != null) {
            String js_include_code = MessageFormat.format(
                "<script type=\"text/javascript\" src=\"{0}\"></script>" ,
                new String[]{jsFileName}
            );
            sb.append(js_include_code);
            sb.append(NL);
        }    
    }

    /**
     * <pre>
     * 必須チェックを行う場合はtrue、そうでない場合はfalse
     * </pre>
     * @param sstagParams
     * @return
     */
    public static boolean needsRequiredCheck (Map sstagParams) {
        
        if (sstagParams == null) {
            return false;
        }
        
        String required_check = SStagUtil.getVal(sstagParams , "required_check");
        if (required_check.trim().equals("")) {
            required_check = "1";
        }
        
        if (required_check.equals("1")) {
            return true;
        } else {
            return false;
        }
    }

    
    /**
     * <pre>
     * 通常ありえない例外を補足した場合のエラー処理
     * </pre>
     * @param sstagParams
     * @param request
     * @param response
     * @param e
     * @return
     */
    public static String onExceptionError(
            Map sstagParams,
            HttpServletRequest request , 
            HttpServletResponse response , 
            Exception e) {

        log.error("例外エラーが発生しました。" , e);
        return onError (sstagParams , request , response , "例外エラーが発生しました。" , e.getMessage());
    }
    
    public static String onSystemError(
            Map sstagParams,
            HttpServletRequest request , 
            HttpServletResponse response , 
            String error_detail) {
        
        return onError (sstagParams , request , response , MSG_SYSTEM_ERROR , error_detail);
    }

    public static String onSystemError(
            Map sstagParams,
            HttpServletRequest request , 
            HttpServletResponse response ) {        
        return onSystemError (sstagParams , request , response , null);
    }

    public static String onError(
            Map sstagParams,
            HttpServletRequest request , 
            HttpServletResponse response ,
            String msg) {        
        return onError (sstagParams , request , response , msg , null);
    }

    public static String onError(
            Map sstagParams, 
            HttpServletRequest request , 
            HttpServletResponse response , 
            String msg ,
            String errorDetail) {

        log.info(msg);
        log.info(errorDetail);

        String onerror = getVal (sstagParams , "onerror").trim().toLowerCase();
        if (onerror.length() == 0 ) {
            onerror = "here";
        } else if (! onerror.equals("redirect") && ! onerror.equals("alert") ){
            onerror = "here";
        }
        
        if (onerror.equals("redirect")) {
            String errorUrl = ValueUtil.nullToStr(SystemPropertiesDb.getInstance().get("EC_SSTAG_ERROR_URL"));
            if (errorUrl.equals("")) {
                onerror = "here";
                msg += NL + "Sysprop EC_SSTAG_ERROR_URL が設定されていません。";
            } else {
                errorUrl = adjustProtocol(request, errorUrl);
                try {
                    response.sendRedirect(errorUrl);
                    return "";
                } catch (IOException e) {
                    e.printStackTrace();
                }

                onerror = "here";
                
            }
        }
        
        StringBuffer sb = new StringBuffer();
        
        if (msg == null || msg.equals("")) {
            msg = MSG_SYSTEM_ERROR;
        }

        if (onerror.equals("here")) {
            sb.append(MSG_SYSTEM_ERROR);
            sb.append(NL);
            sb.append("<!-- ");
            sb.append(msg);
            sb.append(" -->");
            sb.append(NL);
            
            if (errorDetail != null && ! errorDetail.equals("")) {
                sb.append("<!-- ");
                sb.append(errorDetail);
                sb.append(" -->");
                sb.append(NL);
            }
            
        } else {
            // alert
            //TODO 携帯のときは出力を変える
            sb.append(NL);
            sb.append("<script><!--");
            sb.append(NL);
            sb.append("alert(\"");
            sb.append(msg);
            sb.append("\");");
            sb.append(NL);
            sb.append("--></script>");
            sb.append(NL);

            if (errorDetail != null && ! errorDetail.equals("")) {
                sb.append("<!-- ");
                sb.append(errorDetail);
                sb.append(" -->");
                sb.append(NL);
            }
        }

        return sb.toString();
    }

    public static int getMinNum(String paramVal , int defaultVal) {

        if (paramVal == null) return defaultVal;
        
        if (paramVal.trim().equals("")) return defaultVal;
        
        int min;
        try {
            min = Integer.parseInt(paramVal);
        } catch (Exception e) {
            e.printStackTrace();
            min = defaultVal;
        }
        
        if (min < defaultVal) {
            return defaultVal;
        } else {
            return min;
        }
    }
    
    public static int getMaxNum(String paramVal) {

        int defaultVal = 0;
        
        if (paramVal == null) return defaultVal;
        
        if (paramVal.trim().equals("")) return defaultVal;
        
        int max;
        try {
            max = Integer.parseInt(paramVal);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultVal;
        }
        
        if (max <= 0) {
            return defaultVal;
        } else {
            return max;
        }
    }
    
    /**
     * 文字列が数値であるか否かを返す
     * nullの時はfalse
     * 
     * @param str
     * @return
     */
    public static boolean isNumber (String str) {
        if (str == null) {
            return false;
        }
        
        try{
            Long.parseLong(str);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    public static void addJavaScript (StringBuffer sb , List scriptLines) {
        if (sb == null) return;
        if (scriptLines == null) return;
        if (scriptLines.size() <= 0) return;
        
        sb.append("<script><!--");
        sb.append(NL);
                
        for (Iterator it = scriptLines.iterator(); it.hasNext();) {
            String line = (String)it.next();
            sb.append(" ");
            sb.append(line);
            sb.append(NL);
        }

        sb.append("--></script>");
        sb.append(NL);        
    }
    
    public static String convertImgPath (HttpServletRequest request , String img_file) {
        
        if (img_file == null) {
            return null;
        }
        
        if (img_file.toLowerCase().startsWith("http") || img_file.startsWith("/") ) {
            
            // img_file の値をそのまま使う
            
        } else {

            // EC_ITEM_PICT_PATH_PREFIX を付加する。
            
            img_file = SStagUtil.pathCat( SystemPropertiesDb.getInstance().get("EC_ITEM_PICT_PATH_PREFIX") , img_file);
            
        }
        
        // http/https の自動変換処理を入れる
        return adjustProtocol(request , img_file);        
    }
    
    public static boolean isMobile (HttpServletRequest request , Map sstagParams) {
        if (sstagParams == null) {
            return false;
        }
        
        String termType = (String)sstagParams.get("term_type");
        
        if (termType == null) {
            //TODO 端末自動判定
            return false;
        } else {
            if (termType.equals("mb")) {
                return true;
            } else {
                return false;
            }
        }
        
        
    }

    public static void debugRequestParameter(Map sstagParams , HttpServletRequest request) {
        if (sstagParams == null ) return;
        
        if (request == null) return;
        
        if (! isDebugMode(sstagParams)) return ;

        Map reqMap = request.getParameterMap();
        for (Iterator it = reqMap.keySet().iterator(); it.hasNext();) {
            Object key = it.next();
            String[] val = (String[])reqMap.get(key);
            if (val != null) {
                for (int i = 0 ; i < val.length ; i++) {
                    System.out.println(key + ": " + val[i]);
                }
            }
        }
        
    }
    
    /**
     * <pre>
     * 日付文字列をTimestamp形式に変換して返す。
     * 
     * 変換に失敗した場合はnullを返す。
     * </pre>
     * @param datetime
     * @return
     */
    public static Timestamp toTimestamp(String datetime) {
       
        if (datetime == null ) {
            return null;
        }
        
        int length = datetime.length();
        
        if (length < 8) {
            return null;
        }
        
        try {
            if (length == 8) {
                Date d = ValueUtil.toDate(datetime);
                if (d == null) {
                    return null;
                } else {
                    return new Timestamp(d.getTime());
                }
            }
            
            if (8 < length && length < 13) {
                // 9～13のときは、yyyy-mm-dd など、セパレータが入っている可能性がある
                if (datetime.indexOf("/") >= 0) {
                    datetime = datetime.replaceAll("/", "-"); // '/' を '-' に変換
                }
                
                if (datetime.indexOf("-") >= 0) {
                    
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    sdf.setLenient(false);
                    
                    return new Timestamp(sdf.parse(datetime).getTime());                
                    
                } else {
                    
                    //セパレータがない場合は解析できない
                    log.warn("日付解析できません。datetime=" + datetime);
                    return null;
                    
                }
                
            }
            
            if (length >= 20) {
                return Timestamp.valueOf(datetime);
            }
            
            // 14～19
            
            datetime = datetime.substring(0 , 14);
            Date d = ValueUtil.toDate(datetime);
            if (d == null) {
                return null;
            } else {
                return new Timestamp(d.getTime());
            }
        
        } catch (Exception e) {
            
            log.error("日付解析に失敗しました。datetime=" + datetime , e);
            
            return null;
        }
        
    }

    /**
     * <pre>
     * 現在時刻をTimestamp形式で取得する
     * </pre>
     * @return
     */
    public static Timestamp getCurrentTimestamp() {
        return toTimestamp(getCurrentDatetimeStr());
    }
    
    public static String getCurrentDatetimeStr() {
        return ValueUtil.toDateTimeString(new Date());
    }

    public static String toDateTimeString(Timestamp dt) {
        
        if (dt == null) return null;
        
        return ValueUtil.toDateTimeString(dt);
    }

    public static String zenEisuuToHanEisuu(String value) {
        if (value == null) return null;
        StringBuffer sb = new StringBuffer(value);
        for (int i = 0; i < sb.length(); i++) {
            int c = (int) sb.charAt(i);
            if ((c >= 0xFF10 && c <= 0xFF19) || (c >= 0xFF21 && c <= 0xFF3A) || (c >= 0xFF41 && c <= 0xFF5A)) {
                sb.setCharAt(i, (char) (c - 0xFEE0));
            }
        }
        value = sb.toString();
        return value;
    }
    
    public static String replaceSysPropsIn (String src) {
        
        if (src == null) return null;
        
        if (src.trim().length() == 0) return src;
        
        SystemPropertiesDb sysProps = SystemPropertiesDb.getInstance();
        
        return replaceSysProps(sysProps , src);
        
    }
    
    /**
     * 文字列中に埋め込まれたシステムプロパティ変数をシステムプロパティ値で置き換える
     * 
     * システムプロパティのキーと値のペア (key , val) があったとすると、
     * 文字列中に埋め込まれた文字列"$$key$$"を、全てvalに置き換える
     * 
     * keyはどんな値を使ってもよいし、変数は何回使ってもよい。
     * ただし、システムプロパティに登録されていないキーが指定されるなどして、
     * 置換に失敗した変数が一つでもあれば、nullが返される
     * 
     * @param props システムプロパティオブジェクト
     * @param src   システムプロパティ変数置換前の文字列
     * @return      システムプロパティ変数置換後の文字列
     */
    private static String replaceSysProps (SystemPropertiesDb props , String src) {

        if (props == null) {
            log.info("SystemPropertiesオブジェクトがnullです");
            return null;
        }
        if (src == null) {
            log.info("srcにnullが渡されました。");
            return null;
        }
        
        Pattern pattern = Pattern.compile("\\$\\$sysprop\\.(.*?)\\$\\$");
        Matcher matcher = pattern.matcher(src);
        if (matcher.find()) {
            String key = matcher.group(1);
            if (key.equals("")) {
                log.info("不正な変数が検知されました。$$sysprop.$$");
                log.info("src = " + src);
                return null;
            }
            src = replaceSysProps(props, src, key); // システムプロパティ変数を置き換える
            if (src == null) {
                return null;
            }
            return replaceSysProps(props , src); // 再帰
            
        } else {
            return src;
        }
        
    }

    /**
     * 文字列中に埋め込まれたシステムプロパティ変数をシステムプロパティ値で置き換える
     * 
     * システムプロパティのキーと値のペア (key , val) があったとすると、
     * 文字列中に埋め込まれた文字列"$$key$$"を、全てvalに置き換える
     * 
     * 変換に失敗した場合や、置換対象のシステムプロパティが見つからない場合はnullを返す
     * 
     * @param props システムプロパティオブジェクト
     * @param src   変換元文字列
     * @param key   置換対象となるシステムプロパティのキー
     * @return
     */
    private static String replaceSysProps (SystemPropertiesDb props , String src , String key) {
        if (src == null) return null;
        
        if (key == null) return null;

        if (key.equals("")) return null; // $$$$は置き換えない

        try {
            String val = ValueUtil.nullToStr(props.get(key.toUpperCase()));
            if (val.equals("")) {
                log.warn("変数" + key + "はシステムプロパティに見つかりませんでした。");
                return null;
            }
            String replaceTarget = "\\$\\$sysprop\\." + key + "\\$\\$";
            
            return src.replaceAll(replaceTarget, val);

        } catch (Exception e) {
            log.error("文字列の置き換え時に例外エラーが発生しました。" , e);
            return null;
        }       
    }
}
