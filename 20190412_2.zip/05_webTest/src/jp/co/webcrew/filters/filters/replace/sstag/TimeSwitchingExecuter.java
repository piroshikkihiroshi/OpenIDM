package jp.co.webcrew.filters.filters.replace.sstag;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.TimeSwitchingContentsMstDb;

/**
 * <pre>
 *  指定日時により表示する内容を切り替えるExecuterクラス。
 *  パラメータは以下の4つで、それぞれ省略可能。
 *  　start = contents1Id表示開始日時。省略時には既に開始日時を過ぎているものとして解釈する。
 *    switch = contents1からcontents2への表示切替日時。省略時には切り替え判断がスキップされる。（contents1のみがずっと表示される）
 *    end = 表示対象コンテンツの表示終了日時。省略時には指定なしと解釈し、対象コンテンツを永久に表示する。
 *    contents1Id = switchパラメタで指定される日時以前に表示されるHTMLコンテンツのID。省略時には空文字扱いとする。（何も表示されない）
 *    contents2Id = switchパラメタで指定される日時以後に表示されるHTMLコンテンツのID。switchが省略されると表示されることはない。省略時には空文字扱いとする。（何も表示されない）
 *  
 *  コンテンツIDとそれに紐付くコンテンツデータはDBで管理する。
 *  &quot;TimeSwitchingContentsMst&quot;
 * </pre>
 * 
 * @author amit, katsuno
 */
public class TimeSwitchingExecuter extends SSTagExecuter {
	
	/** ロガー */
	private static final Logger log = Logger.getLogger(AdExecuter.class);
	
	/**
	 * Returns the HTML contents based on the value of Start/Switch/End time read from the parameter
	 * 
	 */
	public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {
		
		//Get the Start/Switch/End time and Content-1 Id/Content-2 Id from the parameter
		String strStart = ValueUtil.nullToStr(parameters.get("start"));
		String strSwitch = ValueUtil.nullToStr(parameters.get("switch"));
		String strEnd = ValueUtil.nullToStr(parameters.get("end"));
		String strContents1Id = ValueUtil.nullToStr(parameters.get("contents1id"));
		String strContents2Id = ValueUtil.nullToStr(parameters.get("contents2id"));
		
		try {
			//Get the HTML contents from the database
			TimeSwitchingContentsMstDb objTimeSwitchingContentsMstDb = TimeSwitchingContentsMstDb.getInstance();
			Map mapContents = objTimeSwitchingContentsMstDb.getContents();
	
			SimpleDateFormat objSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
			Date objDateTimeCurrent = objSimpleDateFormat.parse(objSimpleDateFormat.format(new Date()));

			Date objDateTimeStart = null;
			Date objDateTimeSwitch = null;
			Date objDateTimeEnd = null;
			if (strStart != null && !"".equals(strStart)) {
				objDateTimeStart = objSimpleDateFormat.parse(strStart);
			}
			if (strSwitch != null && !"".equals(strSwitch)) {
				objDateTimeSwitch = objSimpleDateFormat.parse(strSwitch);
			}
			if (strEnd != null && !"".equals(strEnd)) {
				objDateTimeEnd = objSimpleDateFormat.parse(strEnd);
			}			

			if (objDateTimeEnd != null && !objDateTimeEnd.after(objDateTimeCurrent)) {
				return "";
			}	
			else if (objDateTimeSwitch != null && !objDateTimeSwitch.after(objDateTimeCurrent)) {
				if (mapContents != null && mapContents.containsKey(strContents2Id))
					return (String)mapContents.get(strContents2Id);
			}
			else if (objDateTimeStart == null || !objDateTimeStart.after(objDateTimeCurrent)) {
				if (mapContents != null && mapContents.containsKey(strContents1Id))
					return (String)mapContents.get(strContents1Id);
			}
		}
		catch (java.text.ParseException objParseWExp) {
			log.error("Date parsing error", objParseWExp);
		}
		catch(Exception objExp) {
			log.error("予期せぬエラー", objExp);
		}
		return "";
	}

}
