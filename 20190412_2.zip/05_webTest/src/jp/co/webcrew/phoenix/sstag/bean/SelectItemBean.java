package jp.co.webcrew.phoenix.sstag.bean;

import java.io.Serializable;

/**
 * 選択肢候補データを保持するbeanクラス。
 * 
 * @author kurinami
 */
public class SelectItemBean implements Serializable {

    /** デフォルトシリアルバージョン */
    private static final long serialVersionUID = 1L;

    /** サイトID */
    private int siteId = 0;

    /** 選択肢マスタID */
    private String selMstId = "";

    /** 表示順番号 */
    private int sortNum = 0;

    /** 選択肢名 */
    private String name = "";

    /** 選択肢の値 */
    private String value = "";

    /** 画像 */
    private String image = "";

    // 以下、アクセッサ。

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public String getSelMstId() {
        return selMstId;
    }

    public void setSelMstId(String selMstId) {
        this.selMstId = selMstId;
    }

    public int getSortNum() {
        return sortNum;
    }

    public void setSortNum(int sortNum) {
        this.sortNum = sortNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

}
