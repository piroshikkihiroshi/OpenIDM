package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.util.LogicUtil;
import jp.co.webcrew.filters.util.RowData;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.sstag.bean.PromoDisplayBean;

public class PromDisplayRefreshMst extends RefreshMstDb
{

	private static final Logger	log	= Logger.getLogger(PromDisplayRefreshMst.class);

	private static final int	nSiteId					= 800;
	
	private static List<PromoDisplayBean> lstPromoDisplayBean = null;

	
	
	/** 唯一のインスタンス */
	private static PromDisplayRefreshMst objPromDisplayRefreshMst = new PromDisplayRefreshMst();

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static PromDisplayRefreshMst getInstance() {
		return objPromDisplayRefreshMst;
	}
	
	@Override
	public void init()
	{
		try	{
			// promo_display_mstを全取得
			getHTMLContents();
		}
		catch (Exception objException){
			log.error("エラーが発生しました。", objException);
		}
	}

	/**
	 * promo_display_mstを全取得する
	 * 
	 * @return
	 * @throws Exception 
	 */
	public static List<PromoDisplayBean> getHTMLAllList() throws Exception
	{
		if(lstPromoDisplayBean != null){
			log.info("BEANサイズ："+lstPromoDisplayBean.size());
		}
		
		return lstPromoDisplayBean;
	}

	/**
	 * HTMLを取得する
	 * 
	 * @param context
	 * @return HTML
	 * @throws Exception
	 */
	public static void getHTMLContents() throws Exception
	{

		PhoenixDBAccess db = null;
		ResultSet rs = null;

		List<RowData> lstListingData = new ArrayList<RowData>();
		List<PromoDisplayBean> lstPromoDisplay = new ArrayList<PromoDisplayBean>();
		try
		{
			db = new PhoenixDBAccess(nSiteId);

			// SQL作成用のbuffer
			StringBuffer sbufCondition = new StringBuffer();
			sbufCondition.append(" AND EXISTS (SELECT 1 FROM common_phoenix.CLM_DATA data1 WHERE data1.tbl_id = '")
					.append("promo_display_mst").append("')");

			rs = LogicUtil.query(db, nSiteId, "promo_display_mst", sbufCondition.toString());

			// ここで審査条件のリストを作成する。
			while (rs.next())
			{
				LogicUtil.setRowData(lstListingData, rs.getLong("rec_id"), rs.getString("clm_id"),
						rs.getString("key_data"), rs.getString("lob_data"), rs.getString("up_datetime"));
			}

			if (!lstListingData.isEmpty())
			{
				PromoDisplayBean objPromoDisplayBean = null;
				for (RowData objCurrRow : lstListingData)
				{
					objPromoDisplayBean = new PromoDisplayBean();
					objPromoDisplayBean.setStrPromoCode(objCurrRow.get("prom_code"));
					objPromoDisplayBean.setnSiteID(Integer.parseInt(objCurrRow.get("site_id")));
					objPromoDisplayBean.setStrDescription(objCurrRow.get("description"));
					objPromoDisplayBean.setStrHTML1(objCurrRow.get("html1"));
					objPromoDisplayBean.setStrHTML2(objCurrRow.get("html2"));
					objPromoDisplayBean.setStrHTML3(objCurrRow.get("html3"));
					objPromoDisplayBean.setStrHTML4(objCurrRow.get("html4"));
					objPromoDisplayBean.setStrHTML5(objCurrRow.get("html5"));
					objPromoDisplayBean.setStrHTML6(objCurrRow.get("html6"));
					objPromoDisplayBean.setStrHTML7(objCurrRow.get("html7"));
					objPromoDisplayBean.setStrHTML8(objCurrRow.get("html8"));
					objPromoDisplayBean.setStrHTML9(objCurrRow.get("html9"));
					objPromoDisplayBean.setStrHTML10(objCurrRow.get("html10"));
					objPromoDisplayBean.setStrHTML11(objCurrRow.get("html11"));
					objPromoDisplayBean.setStrHTML12(objCurrRow.get("html12"));
					objPromoDisplayBean.setStrHTML13(objCurrRow.get("html13"));
					objPromoDisplayBean.setStrHTML14(objCurrRow.get("html14"));
					objPromoDisplayBean.setStrHTML15(objCurrRow.get("html15"));
					objPromoDisplayBean.setStrHTML16(objCurrRow.get("html16"));
					objPromoDisplayBean.setStrHTML17(objCurrRow.get("html17"));
					objPromoDisplayBean.setStrHTML18(objCurrRow.get("html18"));
					objPromoDisplayBean.setStrHTML19(objCurrRow.get("html19"));
					objPromoDisplayBean.setStrHTML20(objCurrRow.get("html20"));
					objPromoDisplayBean.setStrLastUpdate(objCurrRow.get("last_update"));
					objPromoDisplayBean.setStrUpdateAdmin(objCurrRow.get("update_admin"));
					lstPromoDisplay.add(objPromoDisplayBean);
				}
			}
			lstPromoDisplayBean = lstPromoDisplay;
			log.info("リストサイズ全 : " + lstPromoDisplayBean.size());
		}
		finally
		{
			PhoenixDBAccess.close(rs);
			PhoenixDBAccess.close(db);
		}
	}
}
