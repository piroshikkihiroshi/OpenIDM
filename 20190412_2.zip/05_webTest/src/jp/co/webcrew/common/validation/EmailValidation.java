/*
 * Generator Runtime Servlet Framework
 * Copyright (C) 2004 Rick Knowles
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * Version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package jp.co.webcrew.common.validation;

import generator.runtime.db.DBConnectionWrapper;


/**
 * Implements an alphanumeric only check - ensures the field is either null or 
 * a numeric value
 * 
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: EmailValidation.java,v 1.4 2005-04-19 05:13:35 rickk Exp $
 */
public class EmailValidation extends ValidationCheck {
	
	public ValidationFailure validate(Object valueObj, DBConnectionWrapper dbConnection) {
        if (valueObj == null) {
            return null; // check elsewhere
        }

        String value = (String) valueObj;
        int atPos = value.indexOf('@');
        int dotPos = value.lastIndexOf('.');
        int nextAtPos = -1;

        if (atPos != -1) {
            nextAtPos = value.substring(atPos+1).indexOf('@');
        }
        
        if ((atPos == -1) || (dotPos == -1) || (nextAtPos != -1) || (atPos > dotPos) || 
                (value.length() < 5) || value.endsWith(".")) {
            return new ValidationFailure(getFieldName(), getErrorType(), value);
        } else {
            return null;
        }
	}
}
