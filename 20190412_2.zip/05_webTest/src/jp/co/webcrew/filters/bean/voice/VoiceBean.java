package jp.co.webcrew.filters.bean.voice;

import java.io.Serializable;

public class VoiceBean implements Serializable {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    private int index 						= 0;
    private String nameKana1 				= null;
    private String nameKana2 				= null;
    private String nickName 				= null;
    private String address1 				= null;
    private String address2 				= null;
    private String sexName 					= null;
    private String ageRange 				= null;
    private String companyIdMtm 			= null; // 引越し業者ID
    private String companyName 				= null; // 引越し業者漢字
    private String companyNameKana 			= null; // 引越し業者カナ
    private String orderId 					= null;
    private String userId 					= null;
    private String enqueteId 				= null;
    private String advice 					= null;
    private StringBuffer adviceIdSb 		= new StringBuffer(); // 複数の場合「：」で区切
    private StringBuffer adviceNameSb 		= new StringBuffer(); // 複数の場合"\n"で区切
    private int usefulVoteNum 				= 0;
    private String mtmShowFlg 				= null;
    private String lastUpdate 				= null; // 投稿日時

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getNameKana1() {
        return nameKana1;
    }

    public void setNameKana1(String nameKana1) {
        this.nameKana1 = nameKana1;
    }

    public String getNameKana2() {
        return nameKana2;
    }

    public void setNameKana2(String nameKana2) {
        this.nameKana2 = nameKana2;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getSexName() {
        return sexName;
    }

    public void setSexName(String sexName) {
        this.sexName = sexName;
    }

    public String getAgeRange() {
        return ageRange;
    }

    public void setAgeRange(String ageRange) {
        this.ageRange = ageRange;
    }

    public String getCompanyIdMtm() {
        return companyIdMtm;
    }

    public void setCompanyIdMtm(String companyIdMtm) {
        this.companyIdMtm = companyIdMtm;
    }

    public String getCompanyName() {
        return nullToHyphen(companyName);
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyNameKana() {
        return companyNameKana;
    }

    public void setCompanyNameKana(String companyNameKana) {
        this.companyNameKana = companyNameKana;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEnqueteId() {
        return enqueteId;
    }

    public void setEnqueteId(String enqueteId) {
        this.enqueteId = enqueteId;
    }

    public String getAdvice() {
        return toHtml(nullToHyphen(advice));
    }

    public void setAdvice(String advice) {
        this.advice = advice;
    }

    public StringBuffer getAdviceIdSb() {
        return adviceIdSb;
    }

    public void setAdviceIdSb(StringBuffer adviceCtgIdSb) {
        this.adviceIdSb = adviceCtgIdSb;
    }

    public int getUsefulVoteNum() {
        return usefulVoteNum;
    }

    public void setUsefulVoteNum(int usefulVoteNum) {
        this.usefulVoteNum = usefulVoteNum;
    }

    public String getMtmShowFlg() {
        return mtmShowFlg;
    }

    public void setMtmShowFlg(String mtmShowFlg) {
        this.mtmShowFlg = mtmShowFlg;
    }

    public StringBuffer getAdviceNameSb() {
        return adviceNameSb;
    }

    public void setAdviceNameSb(StringBuffer adviceCtgNameSb) {
        this.adviceNameSb = adviceCtgNameSb;
    }

    public String getAdviceCtgName() {
        return toHtml(new String(adviceNameSb));
    }

    public String getLastUpadte() {
        if (lastUpdate == null || lastUpdate.length() == 0) {
            return "";
        }
        return lastUpdate + "投稿";
    }

    public void setLastUpadte(String lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public static String toHtml(String src) 
    {
        src = sanitize(src);
        src = src.replaceAll("\r\n", "\n");
        src = src.replaceAll("\r", "\n");
        return src.replaceAll("\n", "<BR>\r\n");
    }

    /**
     * サニタイジング処理
     */
    public static String sanitize(String src) {
        if (src == null) {
            return "";
        }
        src = src.replaceAll("&", "&amp;");
        src = src.replaceAll("<", "&lt;");
        src = src.replaceAll(">", "&gt;");
        src = src.replaceAll("\"", "&quot;");
        src = src.replaceAll("'", "&#39;");
        src = src.replaceAll(" ", "&nbsp;");
        return src;
    }

    /**
     * NULLの場合「－」を返す
     * 
     * @param src
     * @return
     */
    public static String nullToHyphen(String src) {

        if (src == null || src.length() == 0) {
            return "-";
        }
        return src;
    }

}
