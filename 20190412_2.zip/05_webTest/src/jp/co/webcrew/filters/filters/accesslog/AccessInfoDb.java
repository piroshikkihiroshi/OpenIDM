package jp.co.webcrew.filters.filters.accesslog;

import java.sql.SQLException;
import java.util.Date;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.util.DBAccessUtil;

/**
 * アクセスログを管理するdbクラス。
 * 
 * @author kurinami
 */
public class AccessInfoDb {

	/** アクセスログ挿入用SQL */
	private static final String ACCESS_INFO_INSERT = "insert into access_log(acc_datetime, method, req_url, remote_ip, user_agent, referer, status, guid, gsid, ssid, site_id, sub_num) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	/**
	 * アクセスログを作成してdbに格納する。
	 * 
	 * @param accDatetime
	 * @param method
	 * @param reqUrl
	 * @param remoteIp
	 * @param userAgent
	 * @param referer
	 * @param status
	 * @param guid
	 * @param gsid
	 * @param ssid
	 * @param siteId
	 * @param subNum
	 * @throws SQLException
	 */
	public static void insert(Date accDatetime, String method, String reqUrl,
			String remoteIp, String userAgent, String referer, int status,
			int guid, int gsid, int ssid, int siteId, int subNum)
			throws SQLException {

		DBAccess dbAccess = null;
		try {
			dbAccess = DBAccessUtil.getLogDB();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// アクセスログを作成する。
			dbAccess.prepareStatement(ACCESS_INFO_INSERT);
			int i = 0;
			dbAccess.setString(++i, ValueUtil.toDateTimeMillString(accDatetime));
			dbAccess.setString(++i, method);
			dbAccess.setString(++i, reqUrl.substring(0, Math.min(reqUrl
					.length(), 400)));
			dbAccess.setString(++i, remoteIp);
			dbAccess.setString(++i, userAgent.substring(0, Math.min(userAgent
					.length(), 400)));
			dbAccess.setString(++i, referer.substring(0, Math.min(referer
					.length(), 4000)));
			dbAccess.setInt(++i, status);
			dbAccess.setInt(++i, guid);
			dbAccess.setInt(++i, gsid);
			dbAccess.setInt(++i, ssid);
			dbAccess.setInt(++i, siteId);
			dbAccess.setInt(++i, subNum);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

}
