package jp.co.webcrew.phoenix.logic.bean;

import java.io.Serializable;

/**
 * type="FILE" post データ用
 * 
 * @author kurinami
 */
public class PostFile implements Serializable {

    /** デフォルトシリアルバージョン */
    private static final long serialVersionUID = 1L;

    public String filename;
    public int size;
    public String contentType;
    public byte[] body;
}
