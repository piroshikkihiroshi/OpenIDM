package jp.co.webcrew.phoenix.sstag.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.bean.FormItemWriteMapBean;
import jp.co.webcrew.phoenix.sstag.db.FormItemDb;
import jp.co.webcrew.phoenix.sstag.db.FormItemWriteMapDb;
import jp.co.webcrew.phoenix.sstag.util.FormItemUtil;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.TblMetaMstBean;
import jp.co.webcrew.phoenix.vtable.db.VDb;

/**
 * フォームデータ書き込み（項目単位）を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class FormWriteItemExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：キーにする項目名の並び */
    private static final String KEY_NAME_PARAM_KEY = "key_name";

    /** パラメータ名：上書きするかのフラグ */
    private static final String DUPLICATE_PARAM_KEY = "duplicate";

    /** パラメータ名：レコードID */
    private static final String REC_ID_PARAM_KEY = "rec_id";

    /** パラメータ名：追加を許可するかのフラグ */
    private static final String APPEND_PARAM_KEY = "append";

    /** ロガー */
    private static final Logger log = Logger.getLogger(FormWriteItemExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { FORM_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String[] keyName = PhoenixUtil.split((String) parameters.get(KEY_NAME_PARAM_KEY), ",");
            String duplicate = ValueUtil.nullToStr(parameters.get(DUPLICATE_PARAM_KEY));
            long recId = ValueUtil.tolong((String) parameters.get(REC_ID_PARAM_KEY));
            String append = ValueUtil.nullToStr(parameters.get(APPEND_PARAM_KEY));

            boolean duplicateFlag;
            if (PhoenixUtil.isEmpty(duplicate) || duplicate.equals("0") || duplicate.equalsIgnoreCase("OK")) {
                duplicateFlag = false;
            } else if (duplicate.equals("1") || duplicate.equalsIgnoreCase("NG")) {
                duplicateFlag = true;
            } else {
                return onerror(request, response, parameters, "パラメータの値が不正です。[" + DUPLICATE_PARAM_KEY + ":" + duplicate
                        + "]");
            }

            boolean appendFlag;
            if (PhoenixUtil.isEmpty(append) || append.equals("0") || append.equalsIgnoreCase("OK")) {
                appendFlag = true;
            } else if (append.equals("1") || append.equalsIgnoreCase("NG")) {
                appendFlag = false;
            } else {
                return onerror(request, response, parameters, "パラメータの値が不正です。[" + APPEND_PARAM_KEY + ":" + append + "]");
            }

            // フォーム項目一覧を取得する。
            List<FormItemBean> formItemList = FormItemDb.getList(siteId, formId, null, null, null, null);

            // フォーム項目登録テーブル情報を取得する。
            Map<TblMetaMstBean, List<FormItemWriteMapBean>> formItemWriteMapList = FormItemWriteMapDb
                    .getFormItemWriteMapList(siteId, formId);
            if (PhoenixUtil.isEmpty(formItemWriteMapList)) {
                return onerror(request, response, parameters, "フォーム項目登録テーブル情報が登録されていません。[site_id:" + siteId
                        + "][form_id:" + formId + "]");
            }

            // データをdbに書き込む。
            write(siteId, formItemWriteMapList, formItemList, request, keyName, duplicateFlag, recId, appendFlag);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * dbにpostデータを書き込む。
     * 
     * @param siteId
     * @param formItemWriteMapList
     * @param keyName
     * @param formItemList
     * @param request
     * @param duplicate
     * @throws SQLException
     * @throws InstantiationException
     */
    private void write(int siteId, Map<TblMetaMstBean, List<FormItemWriteMapBean>> formItemWriteMapList,
            List<FormItemBean> formItemList, HttpServletRequest request, String[] keyName, boolean duplicateFlag,
            long recId, boolean appendFlag) throws SQLException, InstantiationException {

        List<TblMetaMstBean> tblMetaMstList = new ArrayList<TblMetaMstBean>();
        List<String[]> keyNameList = new ArrayList<String[]>();
        List<Map<String, String>> clmDataList = new ArrayList<Map<String, String>>();

        for (Map.Entry<TblMetaMstBean, List<FormItemWriteMapBean>> entry : formItemWriteMapList.entrySet()) {
            tblMetaMstList.add(entry.getKey());

            // キー項目が指定されていない場合、
            if (PhoenixUtil.isEmpty(keyName)) {
                // デフォルトを取得する。
                keyNameList.add(toKeyNames(entry.getValue()));
            } else {
                keyNameList.add(keyName);
            }

            Map<String, String> clmData = new HashMap<String, String>();

            for (FormItemWriteMapBean formItemWriteMap : entry.getValue()) {
                String key = formItemWriteMap.getMapClmId();
                String value = PhoenixUtil.concat(toValues(formItemWriteMap.getItemId(), formItemList, request), "\n");
                clmData.put(key, value);
            }

            clmDataList.add(clmData);
        }

        VDb.writeRecords(siteId, tblMetaMstList, clmDataList, keyNameList, !duplicateFlag, recId, appendFlag);

    }

    /**
     * キーとなるカラムのカラム名だけ抜き出す。
     * 
     * @param list
     * @return
     */
    private String[] toKeyNames(List<FormItemWriteMapBean> list) {
        List<String> resultList = new ArrayList<String>();

        for (FormItemWriteMapBean formItemWriteMap : list) {
            if (formItemWriteMap.isKeyFlag()) {
                resultList.add(formItemWriteMap.getMapClmId());
            }
        }

        return resultList.toArray(new String[0]);
    }

    /**
     * 項目名の一覧に対する、値の一覧を返す。
     * 
     * @param itemIds
     * @param formItemList
     * @param request
     * @return
     * @throws SQLException
     * @throws InstantiationException
     */
    private String[] toValues(String[] itemIds, List<FormItemBean> formItemList, HttpServletRequest request)
            throws SQLException, InstantiationException {
        List<String> valueList = new ArrayList<String>();
        for (String itemId : itemIds) {
            for (FormItemBean formItem : formItemList) {
                if (formItem.getItemId().equals(itemId)) {
                    String value = FormItemUtil.getInstance(formItem, request).getDbValue();
                    valueList.add(value);
                    break;
                }
            }
        }
        return valueList.toArray(new String[0]);
    }

}
