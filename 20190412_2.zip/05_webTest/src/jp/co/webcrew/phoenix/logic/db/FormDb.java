package jp.co.webcrew.phoenix.logic.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.logic.bean.FormDef;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormItem;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * フォーム情報を管理するdbクラス。
 * 
 * @author kurinami
 */
public class FormDb {

    /** フォーム定義を取得するためのsql */
    private static final String SELECT_FORM_DEF = ""
            + "select * from (schema_name).form_def where site_id = ? and form_id = ? ";

    /** フォーム項目一覧を取得するためのsql */
    private static final String SELECT_FORM_ITEM_LIST = ""
            + "select * from (schema_name).form_item where site_id = ? and form_id = ? order by form_item.sort_num ";

    /**
     * フォーム情報を返す。
     * 
     * @param siteId
     * @param formId
     * @return
     * @throws SQLException
     */
    public static FormInfo getFormInfo(int siteId, String formId) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = new PhoenixDBAccess(siteId);

            FormDef formDef = getFormDef(dbAccess, siteId, formId);
            if (formDef == null) {
                return null;
            }

            List<FormItem> formItemList = getFormItemList(dbAccess, siteId, formId);

            FormInfo formInfo = new FormInfo();
            formInfo.formDef = formDef;
            formInfo.formItemList = formItemList;

            return formInfo;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * フォーム定義を返す。
     * 
     * @param dbAccess
     * @param siteId
     * @param formId
     * @return
     * @throws SQLException
     */
    private static FormDef getFormDef(DBAccess dbAccess, int siteId, String formId) throws SQLException {

        ResultSet rs = null;
        try {
            FormDef formDef = null;

            // フォーム定義を取得する。
            dbAccess.prepareStatement(SELECT_FORM_DEF);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, formId);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                formDef = new FormDef();
                formDef.site_id = ValueUtil.nullToStr(rs.getString("site_id"));
                formDef.form_id = ValueUtil.nullToStr(rs.getString("form_id"));
                formDef.src_site_id = ValueUtil.nullToStr(rs.getString("src_site_id"));
                formDef.src_form_id = ValueUtil.nullToStr(rs.getString("src_form_id"));
                formDef.sync_flag = PhoenixUtil.tochar(rs.getString("sync_flag"));
                formDef.name = ValueUtil.nullToStr(rs.getString("name"));
                formDef.description = ValueUtil.nullToStr(rs.getString("description"));
            }

            return formDef;

        } finally {
            DBAccess.close(rs);
        }

    }

    /**
     * フォーム項目一覧を返す。
     * 
     * @param dbAccess
     * @param siteId
     * @param formId
     * @return
     * @throws SQLException
     */
    private static List<FormItem> getFormItemList(DBAccess dbAccess, int siteId, String formId) throws SQLException {

        ResultSet rs = null;
        try {
            List<FormItem> formItemList = new ArrayList<FormItem>();

            // フォーム項目一覧を取得する。
            dbAccess.prepareStatement(SELECT_FORM_ITEM_LIST);
            dbAccess.setInt(1, siteId);
            dbAccess.setString(2, formId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                FormItem formItem = new FormItem();

                formItem.site_id = ValueUtil.nullToStr(rs.getString("site_id"));
                formItem.form_id = ValueUtil.nullToStr(rs.getString("form_id"));
                formItem.item_id = ValueUtil.nullToStr(rs.getString("item_id"));
                formItem.group_id = ValueUtil.nullToStr(rs.getString("group_id"));
                formItem.sort_num = ValueUtil.nullToStr(rs.getString("sort_num"));
                formItem.fixed_flag = PhoenixUtil.tochar(rs.getString("fixed_flag"));
                formItem.type = ValueUtil.nullToStr(rs.getString("type"));
                formItem.title = ValueUtil.nullToStr(rs.getString("title"));
                formItem.caution1 = ValueUtil.nullToStr(rs.getString("caution1"));
                formItem.caution2 = ValueUtil.nullToStr(rs.getString("caution2"));
                formItem.caution3 = ValueUtil.nullToStr(rs.getString("caution3"));
                formItem.caution4 = ValueUtil.nullToStr(rs.getString("caution4"));
                formItem.caution5 = ValueUtil.nullToStr(rs.getString("caution5"));
                formItem.require_flag = PhoenixUtil.tochar(rs.getString("require_flag"));
                formItem.clm_size = rs.getInt("clm_size");
                formItem.row_size = rs.getInt("row_size");
                formItem.least = rs.getInt("least");
                formItem.most = rs.getInt("most");
                formItem.min = rs.getDouble("min");
                formItem.max = rs.getDouble("max");
                formItem.limit_char = ValueUtil.nullToStr(rs.getString("limit_char"));
                formItem.limit_regex = ValueUtil.nullToStr(rs.getString("limit_regex"));
                formItem.wchar_conv = PhoenixUtil.tochar(rs.getString("wchar_conv"));
                formItem.date_time_type = ValueUtil.nullToStr(rs.getString("date_time_type"));
                formItem.date_time_sep = ValueUtil.nullToStr(rs.getString("date_time_sep"));
                formItem.time_option = ValueUtil.nullToStr(rs.getString("time_option"));
                formItem.sel_mst_id = ValueUtil.nullToStr(rs.getString("sel_mst_id"));
                formItem.max_select = rs.getInt("max_select");
                formItem.edit_kbn = PhoenixUtil.tochar(rs.getString("edit_kbn"));
                formItem.del_kbn = PhoenixUtil.tochar(rs.getString("del_kbn"));
                formItem.up_datetime = ValueUtil.nullToStr(rs.getString("up_datetime"));
                formItem.up_admin = ValueUtil.nullToStr(rs.getString("up_admin"));

                formItemList.add(formItem);
            }

            return formItemList;

        } finally {
            DBAccess.close(rs);
        }

    }

}
