package jp.co.webcrew.login.common.db.util;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;

/**
 * SQLの更新系（INSERT・UPDATE）を生成・実行するクラス
 * 
 * @author Takahashi
 *
 */
public class DBUpdater {

	/** ロガー */
	private static final Logger log = Logger.getLogger(DBUpdater.class);

	/** CURRENT_TIMESTAMPを表す定数 */
	public static final String CURRENT_TIMESTAMP = "CURRENT_TIMESTAMP";
	
	/** テーブル名 */
	private String _tableName = "";
	
	/** 列リスト */
	private List _columns = new ArrayList();

	/** ステートメント */
	private List _statements = new ArrayList();

	/** 更新条件（WHERE句） */
	private String _cond = null;

	/** 更新条件句内のパラメータ */
	private List _condParams = new ArrayList();

	/** 更新条件無しの全件更新を許可 */
	private boolean  _permitNullCond = false; // 全件更新は許可しない

	/** 条件（WHERE句）をセットする */
	public void setCond(String val) {
		_cond = val;
	}
	
	/** 条件句内のパラメータ値をセットする */
	public void addCondString(String param) {
		_condParams.add(new Value(param));
	}

	/** 列リストを取得 */
	public List getColumns(){
		return _columns;
	}

	/** 条件を取得 */
	public String getCond(){
		return _cond;
	}

//	public void addObject (String columnName , Object obj) {
//	getColumns().add(new Column(columnName , obj));
//}

	/**
	 * 時刻をセットする
	 * 
	 * @param columnName
	 * @param t
	 */
	public void addTimestamp (String columnName , Timestamp t) {
		getColumns().add(new Column(columnName , t));
	}

	/**
	 * 文字列値をセットする
	 * 
	 * @param columnName
	 * @param val
	 */
	public void addString (String columnName , String val) {
		getColumns().add(new Column(columnName,val));
	}

	/**
	 * 列にSQLステートメントを設定する
	 * 
	 * @param columnName
	 * @param val
	 */
	public void addStatement (String columnName , String val) {
		Column column = new Column(columnName , val);
		column.setValueType(Column.TYPE_SQL_STATEMENT);
		getColumns().add(column);
		getStatements().add(column);
//		getStatements().add(column);
	}

//	public void addDatePair (String columnName , String yyyymmdd) {
//
//		// for Oracle
//		addStatement(columnName ,"TO_DATE(" + yyyymmdd + ",'YYYYMMDD')");
//		
//		/*
//		 * Timestamp用コード
//		 * 
//		 * TIMEZONE考慮せず
//		 */
//		/*
//		try {
//			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//			Timestamp t = new Timestamp(sdf.parse(yyyymmdd).getTime());
//			getColumns().add(new Column(columnName , t));
//		} catch (ParseException e) {
//			log.error("日付解析中に例外発生" , e);
//		}
//		*/
//	}
//
//	public void addDateTimePair (String columnName , String dateTime) {
//		// for Oracle
//		addStatement(columnName ,"TO_DATE(" + dateTime + ",'YYYYMMDDHH24MISS')");
//		
//		/*
//		 * Timestamp用コード
//		 * 
//		 * TIMEZONE考慮せず
//		 */
//		/*
//		try {
//			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
//			Timestamp t = new Timestamp(sdf.parse(dateTime).getTime());
//			getColumns().add(new Column(columnName , t));
//		} catch (ParseException e) {
//			log.error("日付解析中に例外発生" , e);
//		}
//		*/
//	}

	
	/**
	 * 列に現在時刻を設定する
	 * @param columnName
	 */
	public void addCurrentTimestamp (String columnName) {
		addStatement(columnName , CURRENT_TIMESTAMP);
	}

	/** コンストラクタ */
	public DBUpdater(String tableName){
		_tableName = tableName;
	}
	
	/** テーブル名を取得 */
	public String getTableName() {
		return _tableName;
	}
	
	/**
	 * テーブル更新用のSQLを生成する
	 * @return
	 * @throws DBException
	 */
	public String makeUpdateSql() throws DBException{
		StringBuffer buf = new StringBuffer();
		buf.append("UPDATE ");
		buf.append(getTableName());
		buf.append(" SET ");
		List columns = getColumns();
		for (int i = 0 ; i < columns.size(); i++){
			Column column = (Column)columns.get(i);
			String columnName = column.getColumnName();
			if (i != 0) {
				buf.append(",");
			}
			buf.append(" ");
			buf.append(columnName);
			if(column.isSqlStatement()) {
				buf.append("=");
				buf.append(column.getValue());
				buf.append(" ");
			} else {
				buf.append("=? ");
			}

		}
		buf.append("\n");
		
		if (getCond() == null ) {
			if (!_permitNullCond) {
				log.info("データベース更新の際に条件設定が無いため処理を中断します。");
				log.info("テーブルの全件更新を行う場合は呼び出し時にパラメータを設定してください。");
				throw new DBException("不正なデータベース処理が呼び出されました。");
			}
		}

		//条件文を追加
		buf.append(getCond());
//		log.info("sql=" + buf.toString());
		return buf.toString();
	}

//	public String makeUpdateSql_org() throws DBException{
//		StringBuffer buf = new StringBuffer();
//		buf.append("UPDATE ");
//		buf.append(getTableName());
//		buf.append(" SET ");
//		List columns = getColumns();
//		for (int i = 0 ; i < columns.size(); i++){
//			Column column = (Column)columns.get(i);
//			String columnName = column.getColumnName();
//			if (i != 0) {
//				buf.append(",");
//			}
//			buf.append(" ");
//			buf.append(columnName);
//			buf.append("=? ");
//		}
//		buf.append("\n");
//		
//		if (getCond() == null ) {
//			if (!_permitNullCond) {
//				log.info("データベース更新の際に条件設定が無いため処理を中断します。");
//				log.info("テーブルの全件更新を行う場合は呼び出し時にパラメータを設定してください。");
//				throw new DBException("不正なデータベース処理が呼び出されました。");
//			}
//		}
//
//		//条件文を追加
//		buf.append(getCond());
//		
//		return buf.toString();
//	}

	private void setColumnValues(DBAccess db) throws SQLException{
		List columns = getColumns();
		int paramIdx = 0;
		for (int i = 0 ; i < columns.size(); i++){
			Column column = (Column)columns.get(i);
//			String columnName = column.getColumnName();
			Object val = column.getValue();
			if (! column.isSqlStatement()) {
				paramIdx++;
				//			int type =  column.getType();
				//TODO takahashi 必要に応じて、typeに応じた処理を書く
				db.setObject(paramIdx , val);
			}
		}		
	}
	
	public List getCondParams(){
		return _condParams;
	}
	
	private void setCondValues(DBAccess db) throws SQLException{
		int targetColumnNum = getColumns().size();
		int statementNum = getStatements().size();
		int valueParamNum = targetColumnNum - statementNum;
		
		List condParams = getCondParams();
		for (int i = 0 ; i < condParams.size(); i++) {
			Value value = (Value)condParams.get(i);
			//TODO takahashi 必要に応じて、typeに応じた処理を書く
			db.setObject((valueParamNum + i + 1), value.getValue());
		}
	}
	
	public void setValues(DBAccess db) throws SQLException{
		setColumnValues(db);
		setCondValues(db);
	}

	/**
	 * テーブルを更新する
	 * 
	 * @param db
	 * @return
	 * @throws SQLException
	 */
	public int update(DBAccess db) throws SQLException{
		// TODO条件設定値が無い場合はエラーとする
		db.prepareStatement(makeUpdateSql());
		setColumnValues(db);
		setCondValues(db);
		return db.executeUpdate();
	}

	/**
	 * テーブルに一行挿入する
	 * 
	 * @param db
	 * @return
	 * @throws SQLException
	 */
	public int insert(DBAccess db) throws SQLException{
		String sql = makeInsertSql();
		db.prepareStatement(sql);
		setColumnValues(db);
		return db.executeUpdate();
	}

	/**
	 * INSERT文を生成する
	 * @return String INSERT-SQL文
	 */
// 	private String makeInsertSql(){
//		StringBuffer buf = new StringBuffer();
//		buf.append("INSERT INTO ");
//		buf.append(getTableName());
//		buf.append(" (");
//
//		List columns = getColumns();
//		int columnNum = 0;
//		for (int columnIdx = 0 ; columnIdx < columns.size(); columnIdx++){
//			columnNum++;
//			Column column = (Column)columns.get(columnIdx);
//			String columnName = column.getColumnName();
//			if (columnIdx != 0) {
//				buf.append(",");
//			}
//			buf.append(" ");
//			buf.append(columnName);
//		}
//
//		List statements = getStatements();
//		int targetIdx = 0;
//		for (int stateIdx = 0 ; stateIdx < statements.size(); stateIdx++){
//			targetIdx = stateIdx + columnNum;
//			Column column = (Column)statements.get(stateIdx);
//			String columnName = column.getColumnName();
//			if (targetIdx != 0) {
//				buf.append(",");
//			}
//			buf.append(" ");
//			buf.append(columnName);
//		}
//
//		buf.append(") VALUES (");
//		for (int columnIdx = 0 ; columnIdx < _columns.size(); columnIdx++){
//			Column column = (Column)columns.get(columnIdx);
//			if (columnIdx != 0) {
//				buf.append(",");
//			}
//			if(column.isSqlStatement()) {
//				buf.append(column.getValue());
//			} else {
//				buf.append("?");
//			}
//		}
//		buf.append(") ");
//		
//		return buf.toString();
//	}
	public String makeInsertSql(){
		StringBuffer buf = new StringBuffer();
		buf.append("INSERT INTO ");
		buf.append(getTableName());
		buf.append(" (");

		List columns = getColumns();
		for (int i = 0 ; i < columns.size(); i++){
			Column column = (Column)columns.get(i);
			String columnName = column.getColumnName();
			if (i != 0) {
				buf.append(",");
			}
			buf.append(" ");
			buf.append(columnName);
		}
		buf.append(") VALUES (");
		for (int i = 0 ; i < _columns.size(); i++){
			Column column = (Column)columns.get(i);
			if (i != 0) {
				buf.append(",");
			}
			if(column.isSqlStatement()) {
				buf.append(column.getValue());
			} else {
				buf.append("?");
			}
		}
		buf.append(") ");
		
		return buf.toString();
	}
	
	public void clear() {
		getColumns().clear();
		getCondParams().clear();
		
	}
	
	/**
	 * 列クラス
	 * 
	 * @author Takahashi
	 *
	 */
	class Column{

		public static final int TYPE_PREPARE_PARAM = 0;
		public static final int TYPE_SQL_STATEMENT = 1;
		
		private String _columnName;
		private Object _value;
		private int _columnType = java.sql.Types.OTHER;
		private int _valueType = TYPE_PREPARE_PARAM;
		public Column(String columnName,Object val){
			_columnName = columnName;
			_value = val;
			_valueType = TYPE_PREPARE_PARAM;
		}
		
		public String getColumnName(){
			return _columnName;
		}
		public Object getValue() {
			return _value;
		}
		public int getColumnType(){
			return _columnType;
		}
		
		public  void setValueType(int type) {
			_valueType = type;
		}
		
		public int getValueType() {
			return _valueType;
		}
		
		public boolean isSqlStatement(){
			if (getValueType() == TYPE_SQL_STATEMENT) {
				return true;
			} else {
				return false;
			}
		}
	}

	/**
	 * 値クラス
	 * 
	 * @author Takahashi
	 *
	 */
	class Value{
		private int _columnType = java.sql.Types.OTHER;
		private String _value;
		public Value(String val){
			_value = val;
		}
		public String getValue() {
			return _value;
		}
		public int getType(){
			return _columnType;
		}
	}

	public List getStatements() {
		return _statements;
	}

	public void setStatements(List statements) {
		_statements = statements;
	}

}
