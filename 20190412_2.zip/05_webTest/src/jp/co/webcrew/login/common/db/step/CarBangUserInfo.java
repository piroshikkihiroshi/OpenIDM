package jp.co.webcrew.login.common.db.step;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;

public class CarBangUserInfo extends StepUserInfoCommonDb {

    /** スキーマ名 */
    public static final String SCHEMA = "XML";
    /** テーブル名 */
    public static final String TABLE = "USER_INFO";
    /** ORDER_HIST.ORDER_TEXTに転送する文字列 */
    public static final String ORDER_TEXT_CAPTION_PC = "bang!自動車保険";
    public static final String ORDER_TEXT_CAPTION_MB = "bang!自動車保険モバイル";
    public static final String ORDER_TEXT_CAPTION_PC_ZUBAT = "ズバット自動車保険";
    public static final String ORDER_TEXT_CAPTION_MB_ZUBAT = "ズバット自動車保険モバイル";

    /** 法人向けサイトであるか否か */
    public static final boolean CORPORATE_SERVICE_FLG = false;

    /** PCサイトＩＤ */
    public static final String PC_SITE_ID = "11000";
    /** ズバットPCサイトＩＤ */
    public static final String PC_SITE_ID_ZUBAT = "11010";

    /** 一般モバイルサイトＩＤ */
    public static final String MB_SITE_ID_GENERAL = "11001";
    /** 公式化モバイルサイトＩＤ */
    public static final String MB_SITE_ID_OFFICIAL = "11002";
    /** ズバットモバイルサイトＩＤ */
    public static final String MB_SITE_ID_ZUBAT = "11011";

    public static final String HYPHEN = "-";

    /*
     * USER_INFOの一部列名定義
     */
    public static final String KEIYAKUSHA_ID = "KEIYAKUSHA_ID";
    public static final String ZIP_CODE_1 = "ZIP_CODE_1";
    public static final String ZIP_CODE_2 = "ZIP_CODE_2";
    public static final String HOME_PHONE_NO_1 = "HOME_PHONE_NO_1";
    public static final String HOME_PHONE_NO_2 = "HOME_PHONE_NO_2";
    public static final String HOME_PHONE_NO_3 = "HOME_PHONE_NO_3";
    public static final String HOME_MAIL_ADDRESS = "HOME_MAIL_ADDRESS";
    public static final String ADDRESS_KANJI_1 = "ADDRESS_KANJI_1";
    public static final String ADDRESS_KANJI_2 = "ADDRESS_KANJI_2";
    public static final String ADDRESS_KANJI_3 = "ADDRESS_KANJI_3";
    public static final String ADDRESS_KANJI_4 = "ADDRESS_KANJI_4";
    public static final String ADDRESS_KANJI_5 = "ADDRESS_KANJI_5";
    public static final String ADDRESS_KANJI_6 = "ADDRESS_KANJI_6";
    public static final String NAME_KANA_1 = "NAME_KANA_1";
    public static final String NAME_KANA_2 = "NAME_KANA_2";
    public static final String NAME_KANJI_1 = "NAME_KANJI_1";
    public static final String NAME_KANJI_2 = "NAME_KANJI_2";
    public static final String BIRTHDAY = "BIRTHDAY";
    public static final String SEX_CODE = "SEX_CODE";
    public static final String MERUMAGA1_FLG = "MERUMAGA1_FLG"; // TODO PERMIT_WC_FLGと同じ？

    // 既存テーブルにはないカラム
    public static final String PREF_ID = "PREF_ID";

    /** ロガー */
    private Logger log = Logger.getLogger(this.getClass());

    private UserControl _userControl = new UserControl();
    
    private CarInfo _carInfo = new CarInfo();

    // private OperationInfo _operationInfo = new OperationInfo();

    public UserControl getUserControl() {
        return _userControl;
    }

    public void setUserControl(UserControl userControl) {
        _userControl = userControl;
    }

    public CarInfo getCarInfo() {
        return _carInfo;
    }

    public void setCarInfo(CarInfo carInfo) {
        _carInfo = carInfo;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.db.DBEntity#doInit()
     */
    public void doInit() {
        setSchema(SCHEMA);
        setTable(TABLE);
        setCorporateService(CORPORATE_SERVICE_FLG);
    }

    private CarBangUserInfo() {
    }

    /**
     * 主キー設定 自動車用のテーブルはPKがないため UNIQUE INDEXを主キーとして設定
     */
    public void setPkColumns() {
        getPkColumns().clear();
        getPkColumns().add(KEIYAKUSHA_ID);
    }

    /**
     * コンストラクタ
     * 
     * @param request
     * @param siteId
     */
    /**
     * @param request
     * @param siteId
     */
    public CarBangUserInfo(HttpServletRequest request, String siteId) {
        setSiteId(siteId);
        setHttpRequest(request);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doCreateNewStepId(jp.co.webcrew.dbaccess.db.DBAccess)
     */
    public void doCreateNewStepId(DBAccess db) throws SQLException {
        // Mypageの見積もり一覧からPCも利用できます

        String userId = "";
        // String requestId = "";
        ResultSet rs = null;
        try {
            String sql = "SELECT XML.KSEQ.NEXTVAL AS USERID FROM DUAL";

            db.prepareStatement(sql);
            rs = db.executeQuery();
            if (db.next(rs)) {
                userId = ValueUtil.nullToStr(rs.getString("USERID"));
            }

            setUserId(userId);
            // setRequestId(requestId); // SEQ_NOは自動車側作成

        } catch (SQLException e) {
            // 例外エラー
            log.error("シーケンス取得中にデータベースエラーが発生しました。", e);
            throw e;

        } finally {
            DBAccess.close(rs);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateFromMemberMst(jp.co.webcrew.login.util.db.MemberMst)
     */
    public void doPopulateFromMemberMst(MemberMst member) {

        set(UserControl.GUID, member.get(MemberMst.GUID));
        set(NAME_KANJI_1, member.get(MemberMst.NAME1));
        set(NAME_KANJI_2, member.get(MemberMst.NAME2));
        set(NAME_KANA_1, member.get(MemberMst.FURI1));
        set(NAME_KANA_2, member.get(MemberMst.FURI2));

        String zip = ValueUtil.nullToStr(member.get(MemberMst.ZIP));
        String[] zip_arr = zip.split(HYPHEN);
        if (zip_arr.length == 2) {
            set("ZIP_CODE_1", zip_arr[0]);
            set("ZIP_CODE_2", zip_arr[1]);
        } else {
            set("ZIP_CODE_1", null);
            set("ZIP_CODE_2", null);
        }
        // set(PREF_ID, member.get(MemberMst.PREF_ID));
        set(ADDRESS_KANJI_1, member.get(MemberMst.ADDR1));
        set(ADDRESS_KANJI_2, member.get(MemberMst.ADDR2));
        set(ADDRESS_KANJI_3, member.get(MemberMst.ADDR3));
        set(ADDRESS_KANJI_4, member.get(MemberMst.ADDR4));
        set(ADDRESS_KANJI_5, member.get(MemberMst.ADDR5));
        set(BIRTHDAY, DateUtil.toDbDateStr(member.get(MemberMst.BIRTHDAY)));
        set(SEX_CODE, member.get(MemberMst.SEX_ID));

        // 電話番号
        String tel = "";
        if (isFromPc()) {
            // PCアクセスの場合PCを優先します
            tel = ValueUtil.nullToStr(member.get(MemberMst.TEL));
            if (tel.length() == 0)
                tel = ValueUtil.nullToStr(member.get(MemberMst.MOBILE));
        } else {
            // Mobileアクセスの場合Mobileを優先します
            tel = ValueUtil.nullToStr(member.get(MemberMst.MOBILE));
            if (tel.length() == 0)
                tel = ValueUtil.nullToStr(member.get(MemberMst.TEL));
        }
        String[] tel_arr = tel.split(HYPHEN);
        if (tel_arr.length == 3) {
            set(HOME_PHONE_NO_1, tel_arr[0]);
            set(HOME_PHONE_NO_2, tel_arr[1]);
            set(HOME_PHONE_NO_3, tel_arr[2]);
        } else {
            set(HOME_PHONE_NO_1, null);
            set(HOME_PHONE_NO_2, null);
            set(HOME_PHONE_NO_3, null);
        }

        // メールアドレスは三種類を場合に応じて表示する TODO isMobileAccessでいい？
        if (isMobileAccess()) {
            set(HOME_MAIL_ADDRESS, member.get(MemberMst.MB_MAIL));
        } else {
            if (isCorporateService()) {
                set(HOME_MAIL_ADDRESS, member.get(MemberMst.CP_MAIL));
            } else {
                set(HOME_MAIL_ADDRESS, member.get(MemberMst.EMAIL));
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doPrepareStepDatabase(jp.co.webcrew.dbaccess.db.DBAccess)
     */
    protected void doPrepareStepDatabase(DBAccess db) throws SQLException {

        // Mypageの見積もり一覧からPCも利用できます

        // stepのinitialCalculationsにおけるinsert処理と同じことをする
        // ただしログイン機能無しの時と異なり、コピーした会員情報もDB登録する
        try {

            // USER_INFOに一行作成
            DBUpdater inserter = new DBUpdater(SCHEMA + "." + TABLE);
            inserter.addString(KEIYAKUSHA_ID, getUserId());
            inserter.addString(NAME_KANJI_1, trimGet(NAME_KANJI_1));
            inserter.addString(NAME_KANJI_2, trimGet(NAME_KANJI_2));
            inserter.addString(NAME_KANA_1, trimGet(NAME_KANA_1));
            inserter.addString(NAME_KANA_2, trimGet(NAME_KANA_2));
            inserter.addString(SEX_CODE, trimGet(SEX_CODE));
            inserter.addString(ZIP_CODE_1, trimGet(ZIP_CODE_1));
            inserter.addString(ZIP_CODE_2, trimGet(ZIP_CODE_2));
            // inserter.addString(PREF_ID, getPrefId()); 自動車のテーブルに該当カラムがないため、登録しないよう
            inserter.addString(ADDRESS_KANJI_1, trimGet(ADDRESS_KANJI_1));
            inserter.addString(ADDRESS_KANJI_2, trimGet(ADDRESS_KANJI_2));
            inserter.addString(ADDRESS_KANJI_3, trimGet(ADDRESS_KANJI_3));
            inserter.addString(ADDRESS_KANJI_4, trimGet(ADDRESS_KANJI_4));
            inserter.addString(ADDRESS_KANJI_5, trimGet(ADDRESS_KANJI_5));
            inserter.addString(HOME_PHONE_NO_1, trimGet(HOME_PHONE_NO_1));
            inserter.addString(HOME_PHONE_NO_2, trimGet(HOME_PHONE_NO_2));
            inserter.addString(HOME_PHONE_NO_3, trimGet(HOME_PHONE_NO_3));

            inserter.addString(HOME_MAIL_ADDRESS, trimGet(HOME_MAIL_ADDRESS));
            inserter.addString(BIRTHDAY, trimGet(BIRTHDAY));
            inserter.addString(MERUMAGA1_FLG, "2"); // 初期化値は「2」：購読
            inserter.insert(db);

            // USER_CONTROLに一行作成
            inserter = new DBUpdater(SCHEMA + "." + UserControl.TABLE);
            inserter.addString(UserControl.KEIYAKUSHA_CODE, getUserId());
            inserter.addString(UserControl.USER_ID, makeId(getUserId()));
            inserter.addString(UserControl.PASSWORD, makePassword(7));
            inserter.addString(UserControl.GUID, get(UserControl.GUID));
            inserter.addCurrentTimestamp(UserControl.LAST_UPDATE);
            inserter.addString(UserControl.SITE_ID, getSiteId());

            inserter.insert(db);

        } catch (SQLException e) {
            // 例外エラー
            log.error("UserInfo,UserControlの新規レコード作成時にエラーが発生しました。", e);
            throw e;

        } finally {
            ;
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.common.db.step.StepUserInfoCommonDb#doLoad(jp.co.webcrew.dbaccess.db.DBAccess,
     *      java.lang.String, java.lang.String)
     */
    public boolean doLoad(DBAccess db, String seqNo, String keiyakushaId) throws SQLException {
        // 検索前は主キー設定が必要です。
        setPkColumns();
        if (super.doLoad(db, seqNo, keiyakushaId)) {
            UserControl userControl = getUserControl();
            userControl.setPkColumns(); // 主キー設定
            userControl.setKeiyakushaCode(keiyakushaId);
            if (userControl.load(db)) {
                if (get(ZIP_CODE_1) != null && get(ZIP_CODE_2) != null) {
                    setPrefIdByZip(db, get(ZIP_CODE_1) + get(ZIP_CODE_2));
                }
                // 車情報も取得するよ
                CarInfo carInfo = getCarInfo();
                carInfo.setPkColumns(); // 主キー設定
                carInfo.setSeqNo(seqNo);
                if (carInfo.load(db)) {
                    return true;
                }
            }
        }
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doIsDifferentFromMemberMst(jp.co.webcrew.login.util.db.MemberMst)
     */
    public boolean doIsDifferentFromMemberMst(MemberMst member) {
        if (!get(NAME_KANJI_1).equals(member.get(MemberMst.NAME1)))
            return true;
        if (!get(NAME_KANJI_2).equals(member.get(MemberMst.NAME2)))
            return true;
        if (!get(NAME_KANA_1).equals(member.get(MemberMst.FURI1)))
            return true;
        if (!get(NAME_KANA_2).equals(member.get(MemberMst.FURI2)))
            return true;
        if (!getZip().equals(member.get(MemberMst.ZIP)))
            return true;
        if (!getPrefId().equals(member.get(MemberMst.PREF_ID)))
            return true;
        if (!get(ADDRESS_KANJI_1).equals(member.get(MemberMst.ADDR1)))
            return true;
        if (!get(ADDRESS_KANJI_2).equals(member.get(MemberMst.ADDR2)))
            return true;
        if (!get(ADDRESS_KANJI_3).equals(member.get(MemberMst.ADDR3)))
            return true;
        if (!get(ADDRESS_KANJI_4).equals(member.get(MemberMst.ADDR4)))
            return true;
        if (!get(ADDRESS_KANJI_5).equals(member.get(MemberMst.ADDR5)))
            return true;
        if (getBirthDate().length() < 10
                || !getBirthDate().substring(0, 10).equals(DateUtil.toDbDateStr(member.get(MemberMst.BIRTHDAY))))
            return true;
        if (!get(SEX_CODE).equals(member.get(MemberMst.SEX_ID)))
            return true;
        // 電話番号チェック
        String tel = isFromPc() ? member.get(MemberMst.TEL) : member.get(MemberMst.MOBILE);
        if (!getTel().equals(tel))
            return true;
        
        // 車情報
        // 車のメーカー名
        if (!getCarInfo().get(CarInfo.CAR_MAKER_NAME_DISP).equals(member.get(MemberMst.CAR_MAKER_NAME_DISP)))
            return true;
        // 車種名
        if (!getCarInfo().get(CarInfo.CAR_SHASHU_NAME_DISP).equals(member.get(MemberMst.CAR_SHASHU_NAME_DISP)))
            return true;
        // 型式
        if (!getCarInfo().get(CarInfo.CAR_KATASHIKI_NAME).equals(member.get(MemberMst.CAR_KATASHIKI_NAME)))
            return true;
        // 車の初年度登録
        String shoDoTorokuMonth = getCarInfo().getDateStr(CarInfo.SHODO_TOROKU_NENGETSU);
        if (shoDoTorokuMonth.length() == 8) {
            if (!shoDoTorokuMonth.equals(member.get(MemberMst.SHODO_TOROKU_NENGETSU))) {
                return true;
            }
        }

        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToMemberMst(jp.co.webcrew.login.util.db.MemberMst)
     */
    public void doPopulateToMemberMst(MemberMst member) {
        // メンバーオブジェクトを自動生成する時は、データを切り捨ててでも、なるべく生かす。
        // （文字数制限を自動的に行う）

        member.setTrimData(MemberMst.NAME1, get(NAME_KANJI_1));
        member.setTrimData(MemberMst.NAME2, get(NAME_KANJI_2));
        member.setTrimData(MemberMst.FURI1, get(NAME_KANA_1));
        member.setTrimData(MemberMst.FURI2, get(NAME_KANA_2));

        member.setTrimData(MemberMst.ZIP, getZip());
        member.setTrimData(MemberMst.PREF_ID, getPrefId());
        member.setTrimData(MemberMst.ADDR1, get(ADDRESS_KANJI_1));
        member.setTrimData(MemberMst.ADDR2, get(ADDRESS_KANJI_2));
        member.setTrimData(MemberMst.ADDR3, get(ADDRESS_KANJI_3));
        member.setTrimData(MemberMst.ADDR4, get(ADDRESS_KANJI_4));
        member.setTrimData(MemberMst.ADDR5, get(ADDRESS_KANJI_5));

        member.setTrimData(MemberMst.BIRTHDAY, charBirthDate()); // YYYYMMDDに変換
        member.setTrimData(MemberMst.SEX_ID, get(SEX_CODE));
        if (isFromPc()) {
            member.setTrimData(MemberMst.TEL, getTel());
        } else {
            member.setTrimData(MemberMst.MOBILE, getTel());
        }
        // member.trimCopy(MemberMst.EMAIL, get(HOME_MAIL_ADDRESS)); // TODO EMAIL情報は自動的には更新しない
        
        member.setTrimData(MemberMst.CAR_MAKER_NAME_DISP, getCarInfo().get(CarInfo.CAR_MAKER_NAME_DISP));
        member.setTrimData(MemberMst.CAR_SHASHU_NAME_DISP, getCarInfo().get(CarInfo.CAR_SHASHU_NAME_DISP));
        member.setTrimData(MemberMst.CAR_KATASHIKI_NAME, getCarInfo().get(CarInfo.CAR_KATASHIKI_NAME));
        member.setTrimData(MemberMst.SHODO_TOROKU_NENGETSU, getCarInfo().get(CarInfo.SHODO_TOROKU_NENGETSU));
        String shoDoTorokuMonth = getCarInfo().getDateStr(CarInfo.SHODO_TOROKU_NENGETSU);
        if (shoDoTorokuMonth.length() == 8) {
            member.setTrimData(MemberMst.SHODO_TOROKU_NENGETSU, shoDoTorokuMonth);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToOrderHist(jp.co.webcrew.login.util.db.OrderHist)
     */
    public void doPopulateToOrderHist(OrderHist order) {

        DBAccess db = null;
        try {
            db = new DBAccess();

            // 自動車PCは完了画面してもまだブラウザバックから再完了できるため重複登録チェックおこないます。
            String sql = "SELECT GUID FROM TONASHIBA.ORDER_HIST WHERE SITE_ID='" + getSiteId() + "' AND ORDER_ID ='"
                    + getRequestId() + "'";
            // 重複があると削除して再登録するよう。
            ResultSet rs = db.executeQuery(sql);
            while (db.next(rs)) {
                String delSql = "DELETE FROM TONASHIBA.ORDER_HIST WHERE SITE_ID='" + getSiteId() + "' AND ORDER_ID ='"
                        + getRequestId() + "'";
                // トランザクションを開始する。
                db.setAutoCommit(false);
                // データを削除する。
                db.executeUpdate(delSql);
                // コミットする。
                db.commit();
            }

            // 存在し手ない場合登録更新行います
            order.setTrimData(OrderHist.ORDER_DATETIME, DateUtil.currentDateTime()); // 発注日
            order.setTrimData(OrderHist.ORDER_TYPE, OrderHist.TYPE_MITSUMORI_IRAI); // 見積り依頼に固定
            order.setTrimData(OrderHist.SITE_ID, getSiteId());
            order.setTrimData(OrderHist.ORDER_ID, getRequestId());

            // ORDER_TEXT列にStepサイトの説明文をコピー
            order.setTrimData(OrderHist.ORDER_TEXT, getOrderText());

            // SUPPLIER_TEXT列に複数のサプライヤ情報をカンマ区切りでコピー
            StringBuffer sqlbuf = new StringBuffer("SELECT ICI.CORP_NAME AS NAME FROM ");
            sqlbuf.append("XML.OPERATION_INFO OI, ");
            sqlbuf.append("XML.INSURANCE_COMPANY_INFO ICI ");
            sqlbuf.append("WHERE ");
            sqlbuf.append("OI.SEQ_NO = ? ");
            sqlbuf.append("AND ");
            sqlbuf.append("OI.HOPE_INSURANCE LIKE '%'|| ICI.CORP_CODE || '%' ");
            db.prepareStatement(sqlbuf.toString());
            db.setString(1, getRequestId());
            db.executeQuery();
            List suppliers = Record.getResultListOf(db);
            StringBuffer supplier_text = new StringBuffer("");
            for (int i = 0; i < suppliers.size(); i++) {
                Record supinfo = (Record) suppliers.get(i);
                if (i != 0) {
                    supplier_text.append(",");
                }
                supplier_text.append(supinfo.getString("NAME"));
            }
            order.setTrimData(OrderHist.SUPPLIER_TEXT, supplier_text.toString());

        } catch (Exception e) {
            log.error("Stepデータを会員情報の履歴データに転送する際にデータベースエラーが発生しました。", e);
        } finally {
            DBAccess.close(db);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doDeleteGuid(jp.co.webcrew.dbaccess.db.DBAccess,
     *      java.lang.String)
     */
    public void doDeleteGuid(DBAccess db, String guid) throws SQLException {
        DBUpdater updater = new DBUpdater(getSchema() + "." + UserControl.TABLE);
        updater.addString(UserControl.GUID, "");
        updater.setCond("WHERE GUID=?");
        updater.addCondString(guid);
        updater.update(db);

    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doOverWriteGuid(jp.co.webcrew.dbaccess.db.DBAccess,
     *      java.lang.String)
     */
    public boolean doOverWriteGuid(DBAccess db, String guid) {
        log.info("ステップのデータベースに対し、guidの上書き処理を開始します。");

        // 入力チェック

        // GUIDが不正ならエラー
        if (!SessionFilterAlterUtil.isValidGuid(guid)) {
            log.error("GUIDが不正です。");
            return false;
        }

        // SEQ_NOが不正ならエラー
        String seqNo = ValueUtil.nullToStr(getRequestId());
        if (seqNo.equals("")) {
            log.error("SEQ_NOが不正です。");
            return false;
        }

        // KEIYAKUSHA_CODEが不正ならエラー
        String keiyakushaId = ValueUtil.nullToStr(getUserId());
        if (keiyakushaId.equals("")) {
            log.error("KEIYAKUSHA_CODEが不正です。");
            return false;
        }

        // 更新

        try {
            // USER_CONTROLのGUIDを更新する
            String sql = "UPDATE " + getSchema() + ".USER_CONTROL SET GUID = ? ";
            sql += "WHERE KEIYAKUSHA_CODE = ? ";
            db.prepareStatement(sql);
            db.setString(1, guid);
            db.setString(2, keiyakushaId);
            db.executeUpdate();

            log.info("GUIDの上書き処理が完了しました。");
            return true;

        } catch (Exception e) {

            log.error("guid上書き処理中に例外エラーが発生しました。", e);
            return false;
        }
    }

    // 自動車でPREF_IDカラムがないため。郵便番号からCOMMON.ADDRESS_MSTのPREF_IDを取得する
    private boolean setPrefIdByZip(DBAccess db, String zip) {

        // 郵便番号からCOMMON.ADDRESS_MSTのPREF_IDを取得する
        String sql = "SELECT PREF_ID FROM COMMON.ADDRESS_MST WHERE ZIP='" + zip + "'";
        ResultSet rs = null;
        try {
            // サイト情報一覧を検索する。
            rs = db.executeQuery(sql);
            while (db.next(rs)) {
                setPrefId(ValueUtil.nullToStr(rs.getString("PREF_ID")));
            }
            return true;
        } catch (Exception e) {
            log.error("PREF_IDの取得処理中に例外エラーが発生しました。", e);
            return false;
        } finally {
            // 開放する
            DBAccess.close(rs);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.common.db.step.StepUserInfoCommonDb#getGuid()
     */
    public String getGuid() {
        // GUIDはUserControlテーブルにあるため
        return getUserControl().get(UserControl.GUID);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getPrefId()
     */
    public String getPrefId() {
        return get(PREF_ID);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setPrefId(java.lang.String)
     */
    public void setPrefId(String val) {
        set(PREF_ID, val);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getUserId()
     */
    public String getUserId() {
        return get(KEIYAKUSHA_ID);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setUserId(java.lang.String)
     */
    public void setUserId(String val) {
        set(KEIYAKUSHA_ID, val);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getEmail()
     */
    public String getEmail() {
        return get(HOME_MAIL_ADDRESS);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getSexId()
     */
    public String getSexId() {
        return get(SEX_CODE);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDate()
     */
    public String getBirthDate() {
        return get(BIRTHDAY);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthYear()
     */
    public String getBirthYear() {
        String ret = getBirthDate();
        if (ret == null || ret.equals("")) {
            ret = "";
        } else if (ret.length() < 10) {
            ret = "";
        } else {
            ret = ret.substring(0, 4);
        }
        return ret;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthMonth()
     */
    public String getBirthMonth() {
        String ret = getBirthDate();
        if (ret == null || ret.equals("")) {
            ret = "";
        } else if (ret.length() < 10) {
            ret = "";
        } else {
            ret = ret.substring(5, 7);
        }
        return ret;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDay()
     */
    public String getBirthDay() {
        String ret = getBirthDate();
        if (ret == null || ret.equals("")) {
            ret = "";
        } else if (ret.length() < 10) {
            ret = "";
        } else {
            ret = ret.substring(8, 10);
        }
        return ret;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getZip()
     */
    public String getZip() {
        if (get(ZIP_CODE_1) == null || get(ZIP_CODE_2) == null)
            return "";
        return get(ZIP_CODE_1) + HYPHEN + get(ZIP_CODE_2);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setZip(java.lang.String)
     */
    public void setZip(String val) {
        String zip = ValueUtil.nullToStr(val);
        if (zip.length() == 7) {
            set(ZIP_CODE_1, val.substring(0, 3));
            set(ZIP_CODE_2, val.substring(4, 7));
        } else {
            set(ZIP_CODE_1, null);
            set(ZIP_CODE_2, null);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getTel()
     */
    public String getTel() {
        if (get(HOME_PHONE_NO_1) == null || get(HOME_PHONE_NO_2) == null || get(HOME_PHONE_NO_3) == null)
            return "";
        return get(HOME_PHONE_NO_1) + HYPHEN + get(HOME_PHONE_NO_2) + HYPHEN + get(HOME_PHONE_NO_3);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setTel(java.lang.String)
     */
    public void setTel(String val) {
        String tel = ValueUtil.nullToStr(val);
        String[] tel_arr = tel.split(HYPHEN);
        if (tel_arr.length == 3) {
            set(HOME_PHONE_NO_1, tel_arr[0]);
            set(HOME_PHONE_NO_2, tel_arr[1]);
            set(HOME_PHONE_NO_3, tel_arr[2]);
        } else {
            set(HOME_PHONE_NO_1, null); // TODO リセットが必要？
            set(HOME_PHONE_NO_2, null);
            set(HOME_PHONE_NO_3, null);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setSexId(java.lang.String)
     */
    public void setSexId(String val) {
        set(SEX_CODE, val);
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setBirthDate(java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    public void setBirthDate(String year, String month, String day) {
        set(BIRTHDAY, year + HYPHEN + month + HYPHEN + day);
    }

    /*
     * private method
     */

    /**
     * クライアントのIPアドレスを取得する
     * 
     * @return String IPアドレス
     */
    private String getRemoteAddr() {
        return getHttpRequest().getRemoteAddr();
    }

    /**
     * 誕生日をYYYYMMDD形式の文字列で取得する
     * 
     * @return String 誕生日 YYYYMMDD
     */
    private String charBirthDate() {
        return getBirthYear() + getBirthMonth() + getBirthDay();
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getLastUpdateTime()
     */
    public String getLastUpdate() {
        // 完了前は値が登録してないため
        // String ret = getOperationInfo().get(OperationInfo.FINISH_TIME); 
        // if (ret == null || ret.equals("")) {
        // ret = "";
        // } else if (ret.length() < 10) {
        // ret = "";
        // } else {
        // ret = ret.substring(0, 4) + ret.substring(5, 7) + ret.substring(8, 10);
        // }

        return "";
    }

    // PCアクセスの場合
    private boolean isFromPc() {
        return PC_SITE_ID.equals(getSiteId()) || PC_SITE_ID_ZUBAT.equals(getSiteId());
    }

    // Stepサイトの説明文を取得
    private String getOrderText() {
        String order_text = "";
        if (PC_SITE_ID.equals(getSiteId())) {
            order_text = ORDER_TEXT_CAPTION_PC;
        } else if (PC_SITE_ID_ZUBAT.equals(getSiteId())) {
            order_text = ORDER_TEXT_CAPTION_PC_ZUBAT;
        } else if (MB_SITE_ID_ZUBAT.equals(getSiteId())) {
            order_text = ORDER_TEXT_CAPTION_MB_ZUBAT;
        } else {
            order_text = ORDER_TEXT_CAPTION_MB;
        }
        return order_text;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getMagFlag()
     */
    public String getMagFlag() {
        String mag_flag = get(MERUMAGA1_FLG);

        if (mag_flag == null) {
            return "";
        }
        // NGの場合
        if (mag_flag.equals("1")) {
            return "0";
        }
        // OKの場合
        if (mag_flag.equals("0")) {
            return "1";
        }

        return "";

    }

    private class UserControl extends DBEntity {

        /** テーブル名 */
        public static final String TABLE = "USER_CONTROL";

        /*
         * 列名
         */
        public static final String KEIYAKUSHA_CODE = "KEIYAKUSHA_CODE";
        public static final String USER_ID = "USER_ID";
        public static final String PASSWORD = "PASSWORD";
        public static final String GUID = "GUID";
        public static final String LAST_UPDATE = "LAST_UPDATE";
        public static final String SITE_ID = "SITE_ID";

        /**
         * オブジェクト初期化
         */
        public void init() {
            setSchema(SCHEMA);
            setTable(TABLE);
        }

        /**
         * オブジェクト初期化
         */
        public void setKeiyakushaCode(String val) {
            set(KEIYAKUSHA_CODE, val);
        }

        /**
         * 主キー設定 自動車用のテーブルはPKがないため UNIQUE INDEXを主キーとして設定
         * 
         */
        public void setPkColumns() {
            getPkColumns().clear();
            getPkColumns().add(KEIYAKUSHA_CODE);
        }

    }
    

    private class CarInfo extends DBEntity {

        /** テーブル名 */
        public static final String TABLE = "CAR_INFO";

        /*
         * 列名
         */
        public static final String SEQ_NO = "SEQ_NO";
        public static final String CAR_MAKER_NAME_DISP = "CAR_MAKER_NAME_DISP";
        public static final String CAR_SHASHU_NAME_DISP = "CAR_SHASHU_NAME_DISP";
        public static final String CAR_KATASHIKI_NAME = "CAR_KATASHIKI_NAME";
        public static final String SHODO_TOROKU_NENGETSU = "SHODO_TOROKU_NENGETSU";
        // 他の項目取得したい場合以下に追加してください。
        
        /**
         * オブジェクト初期化
         */
        public void init() {
            setSchema(SCHEMA);
            setTable(CarInfo.TABLE);
        }

        /**
         * オブジェクト初期化
         */
        public void setSeqNo(String val) {
            set(CarInfo.SEQ_NO, val);
        }

        /**
         * 主キー設定 自動車用のテーブルはPKがないため UNIQUE INDEXを主キーとして設定
         * 
         */
        public void setPkColumns() {
            getPkColumns().clear();
            getPkColumns().add(SEQ_NO);
        }

    }

    /**
     * @param String
     *            id
     */
    public static String makeId(String id) {
        String[] arr1 = { "A", "B", "C", "D", "E", "F", "G", "H", "J", "K" };
        String[] arr2 = { "L", "M", "N", "P", "R", "S", "T", "W", "X", "Y" };
        // idの長さを10に編集
        if (id.length() < 10) {
            for (int i = id.length(); i < 10; i++) {
                id = "0".concat(id);
            }
        } else {
            id = id.substring(0, 10);
        }
        int[] arr3 = new int[id.length()];
        for (int i = 0; i < id.length(); i++) {
            arr3[i] = Integer.parseInt(id.substring(i, i + 1));
        }
        StringBuffer tempId = new StringBuffer();
        tempId.append(arr1[arr3[1]]);
        tempId.append(arr2[arr3[0]]);
        tempId.append(arr1[arr3[8]]);
        tempId.append(arr2[arr3[7]]);
        tempId.append(arr3[2]);
        tempId.append(arr3[3]);
        tempId.append(arr3[4]);
        tempId.append(arr3[5]);
        tempId.append(arr3[6]);
        tempId.append(arr3[9]);

        return tempId.toString();
    }

    /**
     * @param String
     *            pwLength
     * @return String pw
     */
    public static String makePassword(int pwLength) {
        StringBuffer pw = new StringBuffer();
        String[] pwArr = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H",
                "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b",
                "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",
                "w", "x", "y", "z" };
        for (int i = 0; i < pwLength; i++) {
            Random rd = new Random();
            pw.append(pwArr[rd.nextInt(pwArr.length)]);
        }

        return pw.toString();
    }

}
