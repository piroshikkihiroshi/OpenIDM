package jp.co.webcrew.phoenix.sstag.bean;

import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.phoenix.vtable.bean.ClmMetaMstBean;

/**
 * フォーム項目情報を保持するbeanクラス。
 * 
 * @author kurinami
 */
public class FormItemBean {

    /** 日付・時刻入力タイプ:選択肢からの入力 */
    public static final String DATE_TIME_INPUT_SELECT = "0";

    /** 日付・時刻入力タイプ:直接入力 */
    public static final String DATE_TIME_INPUT_DIRECT = "1";

    /** サイトID */
    private int siteId = 0;

    /** フォームID */
    private String formId = "";

    /** 項目ID */
    private String itemId = "";

    /** グループID */
    private String groupId = "";

    /** テンプレート内番号 */
    private int sortNum = 0;

    /** 項目タイプ */
    private String type = "";

    /** 項目タイトル */
    private String title = "";

    /** 注意書き1 */
    private String caution1 = "";

    /** 注意書き2 */
    private String caution2 = "";

    /** 注意書き3 */
    private String caution3 = "";

    /** 注意書き4 */
    private String caution4 = "";

    /** 注意書き5 */
    private String caution5 = "";

    /** 必須フラグ */
    private boolean require = false;

    /** 入力画面での表示文字数 */
    private Integer clmSize = null;

    /** 入力画面での表示行数 */
    private Integer rowSize = null;

    /** 最少文字数 */
    private Integer least = null;

    /** 最大文字数 */
    private Integer most = null;

    /** 最小値 */
    private Double min = null;

    /** 最大値 */
    private Double max = null;

    /** 入力制限文字種 */
    private String limitChar = "";

    /** 入力文字種別 */
    private String limitRegex = "";

    /** 半角・全角変換 */
    private int wcharConv = ClmMetaMstBean.WCHAR_CONV_NONE;

    /** 日付、時刻タイプ */
    private String dateTimeType = "";

    /** 日付、時刻区切り */
    private String dateTimeSep = "";

    /** 日付・時刻入力タイプ */
    private String dateTimeInput = "";

    /** 選択肢マスタのサイトID */
    private int selMstSiteId = 0;

    /** 選択肢マスタID */
    private String selMstId = "";

    /** 初期データ1 */
    private String initData1 = "";

    /** 初期データ2 */
    private String initData2 = "";

    /** 表示用テンプレート */
    private String htmlTmpl = "";

    /** 表示区分 */
    private String dispStat = "";

    /** フォーム出力css定義一覧 */
    private List<FormCssInfoBean> formCssInfoList = new ArrayList<FormCssInfoBean>();

    // 以下、アクセッサ。

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public int getSortNum() {
        return sortNum;
    }

    public void setSortNum(int sortNum) {
        this.sortNum = sortNum;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCaution1() {
        return caution1;
    }

    public void setCaution1(String caution1) {
        this.caution1 = caution1;
    }

    public String getCaution2() {
        return caution2;
    }

    public void setCaution2(String caution2) {
        this.caution2 = caution2;
    }

    public String getCaution3() {
        return caution3;
    }

    public void setCaution3(String caution3) {
        this.caution3 = caution3;
    }

    public String getCaution4() {
        return caution4;
    }

    public void setCaution4(String caution4) {
        this.caution4 = caution4;
    }

    public String getCaution5() {
        return caution5;
    }

    public void setCaution5(String caution5) {
        this.caution5 = caution5;
    }

    public boolean isRequire() {
        return require;
    }

    public void setRequire(boolean require) {
        this.require = require;
    }

    public Integer getClmSize() {
        return clmSize;
    }

    public void setClmSize(Integer clmSize) {
        this.clmSize = clmSize;
    }

    public Integer getRowSize() {
        return rowSize;
    }

    public void setRowSize(Integer rowSize) {
        this.rowSize = rowSize;
    }

    public Integer getLeast() {
        return least;
    }

    public void setLeast(Integer least) {
        this.least = least;
    }

    public Integer getMost() {
        return most;
    }

    public void setMost(Integer most) {
        this.most = most;
    }

    public Double getMin() {
        return min;
    }

    public void setMin(Double min) {
        this.min = min;
    }

    public Double getMax() {
        return max;
    }

    public void setMax(Double max) {
        this.max = max;
    }

    public String getLimitChar() {
        return limitChar;
    }

    public void setLimitChar(String limitChar) {
        this.limitChar = limitChar;
    }

    public String getLimitRegex() {
        return limitRegex;
    }

    public void setLimitRegex(String limitRegex) {
        this.limitRegex = limitRegex;
    }

    public int getWcharConv() {
        return wcharConv;
    }

    public void setWcharConv(int wcharConv) {
        this.wcharConv = wcharConv;
    }

    public String getDateTimeType() {
        return dateTimeType;
    }

    public void setDateTimeType(String dateTimeType) {
        this.dateTimeType = dateTimeType;
    }

    public String getDateTimeSep() {
        return dateTimeSep;
    }

    public void setDateTimeSep(String dateTimeSep) {
        this.dateTimeSep = dateTimeSep;
    }

    public String getDateTimeInput() {
        return dateTimeInput;
    }

    public void setDateTimeInput(String dateTimeInput) {
        this.dateTimeInput = dateTimeInput;
    }

    public int getSelMstSiteId() {
        return selMstSiteId;
    }

    public void setSelMstSiteId(int selMstSiteId) {
        this.selMstSiteId = selMstSiteId;
    }

    public String getSelMstId() {
        return selMstId;
    }

    public void setSelMstId(String selMstId) {
        this.selMstId = selMstId;
    }

    public String getInitData1() {
        return initData1;
    }

    public void setInitData1(String initData1) {
        this.initData1 = initData1;
    }

    public String getInitData2() {
        return initData2;
    }

    public void setInitData2(String initData2) {
        this.initData2 = initData2;
    }

    public String getHtmlTmpl() {
        return htmlTmpl;
    }

    public void setHtmlTmpl(String htmlTmpl) {
        this.htmlTmpl = htmlTmpl;
    }

    public String getDispStat() {
        return dispStat;
    }

    public void setDispStat(String dispStat) {
        this.dispStat = dispStat;
    }

    public List<FormCssInfoBean> getFormCssInfoList() {
        return formCssInfoList;
    }

    public void setFormCssInfoList(List<FormCssInfoBean> formCssInfoList) {
        this.formCssInfoList = formCssInfoList;
    }

}
