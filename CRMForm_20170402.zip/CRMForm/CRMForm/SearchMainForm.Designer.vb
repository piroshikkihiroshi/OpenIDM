﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SearchMainForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.optionPaste = New System.Windows.Forms.Button()
        Me.historyPaste = New System.Windows.Forms.Button()
        Me.SerachBtn = New System.Windows.Forms.Button()
        Me.kokyakuText = New System.Windows.Forms.TextBox()
        Me.kokyakuLabel = New System.Windows.Forms.Label()
        Me.clearBtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'optionPaste
        '
        Me.optionPaste.Location = New System.Drawing.Point(1158, 156)
        Me.optionPaste.Name = "optionPaste"
        Me.optionPaste.Size = New System.Drawing.Size(65, 38)
        Me.optionPaste.TabIndex = 1
        Me.optionPaste.Text = "備考貼付"
        Me.optionPaste.UseVisualStyleBackColor = True
        Me.optionPaste.Visible = False
        '
        'historyPaste
        '
        Me.historyPaste.Location = New System.Drawing.Point(1158, 103)
        Me.historyPaste.Name = "historyPaste"
        Me.historyPaste.Size = New System.Drawing.Size(65, 38)
        Me.historyPaste.TabIndex = 2
        Me.historyPaste.Text = "略歴等貼付"
        Me.historyPaste.UseVisualStyleBackColor = True
        Me.historyPaste.Visible = False
        '
        'SerachBtn
        '
        Me.SerachBtn.Location = New System.Drawing.Point(900, 609)
        Me.SerachBtn.Name = "SerachBtn"
        Me.SerachBtn.Size = New System.Drawing.Size(156, 25)
        Me.SerachBtn.TabIndex = 3
        Me.SerachBtn.Text = "検索"
        Me.SerachBtn.UseVisualStyleBackColor = True
        '
        'kokyakuText
        '
        Me.kokyakuText.Location = New System.Drawing.Point(180, 6)
        Me.kokyakuText.Name = "kokyakuText"
        Me.kokyakuText.Size = New System.Drawing.Size(100, 19)
        Me.kokyakuText.TabIndex = 5
        '
        'kokyakuLabel
        '
        Me.kokyakuLabel.AutoSize = True
        Me.kokyakuLabel.Location = New System.Drawing.Point(11, 9)
        Me.kokyakuLabel.Name = "kokyakuLabel"
        Me.kokyakuLabel.Size = New System.Drawing.Size(41, 12)
        Me.kokyakuLabel.TabIndex = 6
        Me.kokyakuLabel.Text = "顧客名"
        '
        'clearBtn
        '
        Me.clearBtn.Location = New System.Drawing.Point(900, 640)
        Me.clearBtn.Name = "clearBtn"
        Me.clearBtn.Size = New System.Drawing.Size(156, 25)
        Me.clearBtn.TabIndex = 7
        Me.clearBtn.Text = "クリア"
        Me.clearBtn.UseVisualStyleBackColor = True
        '
        'SearchMainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1235, 679)
        Me.Controls.Add(Me.clearBtn)
        Me.Controls.Add(Me.kokyakuLabel)
        Me.Controls.Add(Me.kokyakuText)
        Me.Controls.Add(Me.SerachBtn)
        Me.Controls.Add(Me.historyPaste)
        Me.Controls.Add(Me.optionPaste)
        Me.Name = "SearchMainForm"
        Me.Text = "mainForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public Sub New()

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後で初期化を追加します。

    End Sub
    Friend WithEvents optionPaste As System.Windows.Forms.Button
    Friend WithEvents historyPaste As System.Windows.Forms.Button
    Friend WithEvents SerachBtn As System.Windows.Forms.Button
    Friend WithEvents kokyakuText As System.Windows.Forms.TextBox
    Friend WithEvents kokyakuLabel As System.Windows.Forms.Label
    Friend WithEvents clearBtn As System.Windows.Forms.Button
End Class
