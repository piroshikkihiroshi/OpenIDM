package jp.co.webcrew.filters.filters.replace;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.sun.xml.internal.ws.client.RequestContext;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.CmsKwdMstDb;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.db.UrlKwdMstDb;
import jp.co.webcrew.filters.filters.replace.replacer.HttpProtocolReplacer;
import jp.co.webcrew.filters.filters.replace.replacer.ImageUrlReplacer;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;
import jp.co.webcrew.filters.filters.replace.replacer.LsCodeReplacer;
import jp.co.webcrew.filters.filters.replace.replacer.SSTagReplacer;
import jp.co.webcrew.filters.filters.replace.sstag.PromDisplayRefreshMst;
import jp.co.webcrew.filters.filters.replace.sstag.SystemErrorMsgExecuter;
import jp.co.webcrew.filters.util.httputil.CustomHttpServletResponse;
import jp.co.webcrew.htmlservlet.HtmlServletLogger;
import jp.co.webcrew.koromogae.KoromogaeChecker;
import jp.co.webcrew.perflog.PerfLogger;
import jp.co.webcrew.phoenix.htmlservlet.db.UriAliasMstDB;
import jp.co.webcrew.phoenix.util.PhoenixBackgroundRefreshMstDB;
import jp.co.webcrew.phoenix.util.PhoenixRequestContext;

/**
 * 結果htmlに置換を行うためのfilterクラス。
 * 
 * @author kurinami
 */
public class ReplaceFilter implements Filter {

    /** replacer適用時のループの無限ループ回避用リミット数 */
    public static final int LOOP_LIMIT = 100;

    /** ロガー */
    private static final Logger log = Logger.getLogger(ReplaceFilter.class);

    /** デフォルトの文字コード */
    private String defalutCharacterEncoding = "Shift_JIS";

    /** キーワード置換用replacer */
    private KeywordReplacer keywordReplacer = new KeywordReplacer();

    /** サーバサイドタグ用replacer */
    private SSTagReplacer ssTagReplacer = new SSTagReplacer();

    /** URLへのローカルセッションコード追加用replacer */
    private LsCodeReplacer lsCodeReplacer = new LsCodeReplacer();

    /** 画像urlを本番環境用に変換するreplacer */
    private ImageUrlReplacer imageUrlReplacer = null;

    /** リクエストのプロトコルを変換するreplacer */
    private HttpProtocolReplacer httpProtocolReplacer = new HttpProtocolReplacer();

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
     */
    public void init(FilterConfig filterConfig) throws ServletException {

        log.debug("init start.");
        
        try {
        	
        	
            // デフォルトの文字エンコーディングを設定する。
            String defalutCharacterEncoding = filterConfig.getInitParameter("defalutCharacterEncoding");
            if (defalutCharacterEncoding != null) {
                this.defalutCharacterEncoding = defalutCharacterEncoding;
            }

            // 画像サーバを使用するかを設定する。
            String useImgServer = ValueUtil.nullToStr(filterConfig.getInitParameter("useImgServer"));
            if (useImgServer.equalsIgnoreCase("true") || useImgServer.equalsIgnoreCase("yes")
                    || useImgServer.equals("1")) {
                imageUrlReplacer = new ImageUrlReplacer();
                imageUrlReplacer.init(filterConfig);
            }

            // 各replacerを初期化する。
            keywordReplacer.init(filterConfig);
            ssTagReplacer.init(filterConfig);
            lsCodeReplacer.init(filterConfig);
            httpProtocolReplacer.init(filterConfig);

            // 必要なDBを初期化しておく
            SiteMstDb.getInstance().init();
            CmsKwdMstDb.getInstance().init();
            UrlKwdMstDb.getInstance().init();
            SystemPropertiesDb.getInstance().init();
        	//PhoenixRequestContext.bindServletContext(filterConfig.getServletContext());
            
            PhoenixBackgroundRefreshMstDB.getInstance(filterConfig.getServletContext());
            
            PromDisplayRefreshMst.getInstance().init();
            
            UriAliasMstDB.getInstance().init();
            
            
        } catch (ServletException e) {
            log.error("予期せぬエラー", e);
            throw e;
        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            throw new ServletException(e);
        }

        log.debug("init end.");

    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     * javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {

        log.debug("doFilter start.");
        PerfLogger.filter_Start(this.getClass());
        PhoenixRequestContext.bindServletObject(request, response);

        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        HtmlServletLogger.accesslog_start(httpServletRequest);

        CustomHttpServletResponse customHttpServletResponse = new CustomHttpServletResponse(httpServletResponse,
                defalutCharacterEncoding);
        chain.doFilter(request, customHttpServletResponse);

        try {

            String contentType = ValueUtil.nullToStr(customHttpServletResponse.getContentType());
            log.debug("uri         : " + httpServletRequest.getRequestURI());
            log.debug("content-type: " + contentType);

            byte[] buf;
            if (contentType.length() == 0 || contentType.toLowerCase().startsWith("text/")) {
                // レスポンスがテキストデータの場合、
                log.debug("レスポンスをテキスト形式と判定し置換処理開始");

                // キャッシュしていたhtmlに置換処理をしてクライアントに出力する。
                String sourceHtml = customHttpServletResponse.getHtml();

                String resultHtml = sourceHtml;
                
                // 必要であれば、プロトコルの変換を行う。
                resultHtml = httpProtocolReplacer.replace(resultHtml, httpServletRequest, customHttpServletResponse);

                // 各replacerの適用
                resultHtml = doReplace(resultHtml, httpServletRequest, customHttpServletResponse);

                // URLパラメータへのローカルセッションコード付与を行なうreplacerの適用
                resultHtml = lsCodeReplacer.replace(resultHtml, httpServletRequest, customHttpServletResponse);

                // 画像urlを本番環境用に置き換える。
                if (imageUrlReplacer != null) {
                    resultHtml = imageUrlReplacer.replace(resultHtml, httpServletRequest, customHttpServletResponse);
                }

                Boolean applyNoCache=PhoenixRequestContext.isReserved_ResponseNoCache();
                //NULL
                if(applyNoCache==null)
                {
                    // 変換が行われた場合、クライアントにキャッシュさせないようにする。
                	// todo_kurinamiを除外
	                if (!sourceHtml.equals(resultHtml)) 
	                {
	                    httpServletResponse.setHeader("Cache-Control", "no-cache");
	                    httpServletResponse.setHeader("Pragma", "no-cache");
	                }
                }
                else if(applyNoCache)
                {
                	//無条件にキャッシュ拒否
                    httpServletResponse.setHeader("Cache-Control", "no-cache");
                    httpServletResponse.setHeader("Pragma", "no-cache");
                }
                
                // 内容をバイトデータにする。
                buf = resultHtml.getBytes(customHttpServletResponse.getCharacterEncoding());
            } else {
                // レスポンスがテキストデータ以外の場合、
                log.debug("レスポンスをテキスト以外の形式と判定し置換処理をスキップ");

                // 置換は行なわない。
                buf = customHttpServletResponse.getByte();
            }

            // リダイレクトをチェックする。
            String location = customHttpServletResponse.getLocation();
            if (location != null) 
			{
				switch(customHttpServletResponse.getStatus())
				{
				case HttpServletResponse.SC_MOVED_PERMANENTLY:
					httpServletResponse.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
					httpServletResponse.setHeader("Location",location);
					break;
				case HttpServletResponse.SC_MOVED_TEMPORARILY:
					httpServletResponse.sendRedirect(location);
					break;
				default:
					throw new RuntimeException("statusCodeが不正です。:"+customHttpServletResponse.getStatus());
				}
				
				
			}
            

            
            KoromogaeChecker.doCheck(httpServletRequest, httpServletResponse, buf);
            
            // ContentLengthを設定する。
            httpServletResponse.setContentLength(buf.length);

            // 置換した結果を本来のstreamに出力する。
            ServletOutputStream sos = httpServletResponse.getOutputStream();
            sos.write(buf);
            sos.close();

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            httpServletResponse.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
        finally
        {
        	PhoenixRequestContext.releaseServletObject();
        	HtmlServletLogger.accesslog_end(httpServletRequest);
            PerfLogger.filter_End(this.getClass());
        }

        log.debug("doFilter end.");
    }
    
    

    /**
     * キーワード置換とサーバサイドタグの適用を行う。
     * 
     * @param source
     * @param request
     * @param response
     * @return
     */
    public String doReplace(String source, HttpServletRequest request, HttpServletResponse response) {

        // 事前定義済みキーワードを登録する。
        keywordReplacer.setDefinedKeyword(request);

        for (int i = 0; i < LOOP_LIMIT; i++) {

            String tempHtml1 = source;

            // サーバサイドタグの実行を行なう。
            source = ssTagReplacer.replace(source, request, response);

            // サーバサイドタグで変更があれば、リプレースを最初から適用する。
            if (tempHtml1.equals(source)) {
                break;
            }
        }

        // 置換キーワードが置換仕切れなかった場合に、置換キーワードを削除する。
        String alternativeWord = SystemErrorMsgExecuter.isDisplayOn(request) ? KeywordReplacer.ALTERNATIVE_WORD : "";
        source = keywordReplacer.eraseReplaceKeyword(source, alternativeWord);

        return source;
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy() {
    	//PhoenixRequestContext.releaseServletContext();
        // 処理なし
    }

}
