package jp.co.webcrew.htmlservlet;

/***
 * log出力先を他のファイルと切り分けるために用意したクラス
 * Htmlservletで利用されることを想定している
 * 
 * @author kazuto.yano
 *
 */
public final class Empty 
{
	private Empty()
	{}
}
