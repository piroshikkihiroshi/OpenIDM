package jp.co.webcrew.filters.bean.voice;

import java.io.Serializable;

public class SateiomakaseVoiceBean extends VoiceBean implements Serializable {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    private String makeName = null;
    private String shashuName = null;
    private String modelYear = null;
    private String bcBase = null;

    private String reason = null;
    private StringBuffer reasonIdSb = new StringBuffer(); // 複数の場合「：」で区切
    private StringBuffer reasonNameSb = new StringBuffer(); // 複数の場合"\n"で区切
    private String sellExpName = null; // 売却経験数
    private String responseComment = null;
    
    public final static String OTHER_COM_ID = "9999"; // その他車買取業者ID
    private int comVoiceCnt = 0; // 車買取業者口コミ件数

    private String kutikomiFlg = null;
    private String stepLastUpadte = null; // サイト利用日時

    public String getMakeName() {
        return makeName;
    }

    public void setMakeName(String makeName) {
        this.makeName = makeName;
    }

    public String getShashuName() {
        return shashuName;
    }

    public void setShashuName(String shashuName) {
        this.shashuName = shashuName;
    }

    public String getModelYear() {
        return modelYear;
    }

    public String getModelYearDisp() {
        return nullToHyphen(modelYear);
    }

    public void setModelYear(String modelYear) {
        this.modelYear = modelYear;
    }

    public String getBcBase() {
        return bcBase;
    }

    public void setBcBase(String bcBase) {
        this.bcBase = bcBase;
    }

    public String getReason() {
        return toHtml(nullToHyphen(reason));
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public StringBuffer getReasonIdSb() {
        return reasonIdSb;
    }

    public void setReasonIdSb(StringBuffer reasonIdSb) {
        this.reasonIdSb = reasonIdSb;
    }

    public StringBuffer getReasonNameSb() {
        return reasonNameSb;
    }

    public String getReasonName() {
        return toHtml(new String(reasonNameSb));
    }

    public void setReasonNameSb(StringBuffer reasonNameSb) {
        this.reasonNameSb = reasonNameSb;
    }

    public String getSellExpName() {
        return sellExpName;
    }

    public void setSellExpName(String sellExpName) {
        this.sellExpName = sellExpName;
    }

    public String getResponseComment() {
        return toHtml(nullToHyphen(responseComment));
    }

    public void setResponseComment(String responseComment) {
        this.responseComment = responseComment;
    }

    public int getComVoiceCnt() {
        return comVoiceCnt;
    }

    public void setComVoiceCnt(int comVoiceCnt) {
        this.comVoiceCnt = comVoiceCnt;
    }

    public String getKutikomiFlg() {
        return kutikomiFlg;
    }

    public void setKutikomiFlg(String kutikomiFlg) {
        this.kutikomiFlg = kutikomiFlg;
    }

    public String getStepLastUpadte() {
        return stepLastUpadte;
    }

    public void setStepLastUpadte(String stepLastUpadte) {
        this.stepLastUpadte = stepLastUpadte;
    }

    public String getStepLastUpadteDisp() {
        if (getStepLastUpadte() == null || getStepLastUpadte().length() < 8) {
            return "-";
        }
        String year = getStepLastUpadte().substring(0, 4);
        String month = getStepLastUpadte().substring(4, 6);
        String day = getStepLastUpadte().substring(6, 8);
        return year + "年" + month + "月" + day + "日";
    }
}
