package jp.co.webcrew.filters.filters.session;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.db.ProxyMstDb;
import jp.co.webcrew.filters.util.QueueThreadUtil;
import jp.co.webcrew.filters.util.httputil.HttpServletRequestCache;

/**
 * プロキシリクエストを処理するthreadクラス。
 * 
 * @author kurinami
 */
public class ProxyRequesterThread extends QueueThreadUtil {

	/** プロキシリクエストを表すパス */
	public static final String PROXY_REQUEST_PATH = "/proxy";

	/** プロキシコードのパラメータ名 */
	public static final String PROXY_CODE_PARAM_KEY = "proxy";

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(ProxyRequesterThread.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.util.QueueThreadUtil#execute(jp.co.webcrew.filters.util.httputil.HttpServletRequestCache)
	 */
	protected void execute(HttpServletRequestCache request) throws Exception {

		String originalQueryString = request.getQueryString();
		if (!originalQueryString.startsWith(PROXY_CODE_PARAM_KEY + "=")) {
			log.error("プロキシリクエスト用のパラメータ不正 [query_string: "
					+ originalQueryString + "]");
			return;
		}

		// 元のgetパラメータをプロキシするプロキシコードとプロキシ先へのgetパラメータに分ける。
		String proxyCode = "";
		String queryString = "";
		int index = originalQueryString.indexOf('&');
		if (index < 0) {
			proxyCode = originalQueryString
					.substring((PROXY_CODE_PARAM_KEY + "=").length());
			queryString = "";
		} else {
			proxyCode = originalQueryString.substring(
					(PROXY_CODE_PARAM_KEY + "=").length(), index);
			queryString = originalQueryString.substring(index + 1);
		}

		// プロキシするリクエスト先を求める。
		String url = ProxyMstDb.getInstance().getUrl(proxyCode, queryString);
		if (url == null) {
			log.error("リクエスト先が不正 [query_string: " + originalQueryString + "]");
			return;
		}

		String ua = request.getHeader("User-Agent");

		Map headers = new HashMap();
		headers.put(SessionFilter.GUID_HEADER_KEY, request
				.getAttribute(UserInfo.GUID_ATTR_KEY));
		headers.put(SessionFilter.GSID_HEADER_KEY, request
				.getAttribute(UserInfo.GSID_ATTR_KEY));
		headers.put(SessionFilter.SSID_HEADER_KEY, request
				.getAttribute(UserInfo.SSID_ATTR_KEY));
		headers.put(SessionFilter.GS_CODE_HEADER_KEY, request
				.getAttribute(UserInfo.GS_CODE_ATTR_KEY));

		try {
			sendRequest(url, ua, headers);
		} catch(IOException e) {
			log.error("プロキシリクエスト送信時にエラーが発生しました。", e);
		}
	}

	/**
	 * httpのリクエストを送信する。
	 * 
	 * @param strUrl
	 * @param userAgent
	 * @param headers
	 * @return
	 * @throws IOException
	 */
	private void sendRequest(String strUrl, String userAgent, Map headers)
			throws IOException {

		// URL の作成
		log.info("プロキシリクエスト送信 [url: " + strUrl + "]");
		URL url = new URL(strUrl);

		// コネクトして、HttpURLConnection の作成
		HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
		urlConn.setRequestMethod("GET");
		urlConn.setDoOutput(false);
		if (userAgent != null) {
			urlConn.setRequestProperty("User-Agent", userAgent);
		}
		Iterator i = headers.keySet().iterator();
		while (i.hasNext()) {
			String key = (String) i.next();
			String value = (String) headers.get(key);
			urlConn.addRequestProperty(key, value);
		}

		// レスポンスコードの確認
		int responseCode = urlConn.getResponseCode();
		if (responseCode != HttpURLConnection.HTTP_OK) {
			log.info("proxy request url[" + strUrl + "]  response code["
					+ responseCode + "]");
		}

		// 内容の取得(実際には取得しても何もしていない)
		InputStream is = urlConn.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		while (true) {
			String buf = br.readLine();
			if (buf == null) {
				break;
			}
		}
		is.close();

		urlConn.disconnect();
	}

}
