package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;

/**
 * sqlを実行して結果を動的パラメータに登録するExecuterクラス。
 * 
 * @author kurinami
 */
public class DbRecordGetExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(DbRecordGetExecuter.class);

	/** 登録キーワードの接頭辞 */
	public static final String PREFIX = "db.";

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameterMap, HttpServletRequest request,
			HttpServletResponse response) {

		try {

			String sql = ValueUtil.nullToStr(parameterMap.get("sql"));
			if (sql.length() == 0) {
				log.error("パラメータ[sql]が指定されていません。");
				return "";
			}
			String varName = ValueUtil.nullToStr(parameterMap.get("var_name"));
			if (varName.length() == 0) {
				log.error("パラメータ[var_name]が指定されていません。");
				return "";
			}
			String dbNamespace = ValueUtil.nullToStr(parameterMap.get("db_namespace"));
			
			DBAccess dbAccess = null;
			ResultSet rs = null;
			try {
				dbAccess = new DBAccess(dbNamespace);

				// sqlを実行する。
				rs = dbAccess.executeQuery(sql);

				ResultSetMetaData resultSetMetaData = rs.getMetaData();

				String[] columnNames = new String[resultSetMetaData
						.getColumnCount()];
				for (int i = 0; i < columnNames.length; i++) {
					columnNames[i] = resultSetMetaData.getColumnName(i + 1);
				}

				if (dbAccess.next(rs)) {
					for (int i = 0; i < columnNames.length; i++) {
						String value = ValueUtil.nullToStr(rs.getString(i + 1));
						KeywordReplacer.addDynamicKeyword(request, PREFIX
								+ varName + "." + columnNames[i], value);
					}
				} else {
					for (int i = 0; i < columnNames.length; i++) {
						KeywordReplacer.addDynamicKeyword(request, PREFIX
								+ varName + "." + columnNames[i], "");
					}
				}

			} finally {
				DBAccess.close(rs);
				DBAccess.close(dbAccess);
			}

		} catch (SQLException e) {
			log.error("DBエラー", e);
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		return "";

	}

}
