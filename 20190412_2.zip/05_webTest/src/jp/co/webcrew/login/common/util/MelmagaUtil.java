/**
 * 
 */
package jp.co.webcrew.login.common.util;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.DBUtil;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.MailBody;
import jp.co.webcrew.login.common.MailInfo;
import jp.co.webcrew.login.common.MailSubject;
import jp.co.webcrew.login.common.db.MagSubscribe;
import jp.co.webcrew.login.common.db.MailTemplateUtil;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.db.util.Record;

/**
 * メールマガジン関連のユーティリティクラス。
 * 
 * step との連携でメルマガフラグを更新する場合は、メールアドレスの更新などで
 * 少しロジックが異なってくるため、StepMelmagaUtil クラスを使用すること。
 * 
 * @author Takahashi
 *
 */
public class MelmagaUtil {
	
	/** ロガー */
	private static final Logger log = Logger.getLogger(MelmagaUtil.class);
	
	private static final int 	MOBILE_EMAIL_FLAG		= 1;
	private static final String MEMBER_SITE_TOP			= "MEMBER_SITE_TOP_URI_PC";
	private static final String MAIL_SENDER				= "MAIL_SENDER_OF_TNS_TMP_REG";
	private static final String SUBSCRIBE_URL 			= "MyAction?page=melmaga.SubscriptionList&command=subcribe";
	private static final String SITEWISE_SUBSCRIBE_URL = "MyAction?page=magtool.MailRegistPopupInfo&command=subscribe";
	private static final int 	PASSWORD_LENGTH			= 4;
	public static final String 	SITE_ID_ATTR_KEY 		= "faon.site_id";
	public static final int 	SUCCESS 				= 1;
	public static final int 	SYSTEM_ERROR			= -1;
	public static final int 	MAIL_SEND_ERROR			= 0;

	private static final String SELECT_MAIL_MST = "SELECT MM.DESCRIPTION " +
		"FROM COMMON.MAIL_MST MM WHERE MM.MAIL_ID=?";
	
	private static final String SELECT_MAIL_SUBSCRIBE = "SELECT INVALID_FLAG " +
		"FROM COMMON.MAIL_SUBSCRIBE WHERE MAIL_ID=? AND EMAIL=?";
	
	/**
	 * <pre>
	 * 該当サイトIDに関連づけられた複数のメールマガジンに対し、購読状況を
	 * 「購読」に更新する
	 * </pre>
	 * 
	 * @param db
	 * @param guid           guid null不可
	 * @param siteId         サイトID null不可
	 * @param email          配信先のemail nullは原則不可
	 * @param overWriteEmail メルマガ管理テーブルに既にemailが存在する場合、新しい値で上書きするか否か
	 * @deprecated DB変更に従いこのメソッドは使えなくなりました。
	 */
	/**
	public static boolean checkMelmagaFlgs (DBAccess db , String guid , String siteId , String email , boolean overWriteEmail) {
		if (db == null) {
			log.error("引数エラー：データベースコネクションが渡されませんでした。");
			return false;
		}
		
		if (! AppUtil.isValidGuid(guid) ) {
			log.error("引数エラー：guidが無効です。");
			return false;
		}

		if (siteId == null || siteId.equals("") ) {
			log.error("引数エラー：siteIdが無効です。");
			return false;
		}
		
		// 全てのメルマガを購読とする
		List targetMagList = getMelmagaList (db , siteId);

		if (targetMagList == null) {
			log.info("メルマガのリスト取得に失敗しました。");
			return false;
		}
		
		for ( Iterator it = targetMagList.iterator(); it.hasNext();) { 

			String targetMagId = (String)it.next();

			if (! checkMelmagaFlg (db , email, targetMagId) ) {
				return false;
			}
			
		}

		return true;
	}
	*/

	/**
	 * <pre>
	 * 該当サイトIDに関連づけられた複数のメールマガジンに対し、購読状況を
	 * 「未読」に更新する
	 * </pre>
	 * 
	 * @param db
	 * @param guid        guid null不可
	 * @param siteId      サイトID null不可
	 * @param magFlg      となしばのメルマガ購読状況 (0:未購読 1:購読 ） null可
	 * @param email       配信先のemail null可
	 
	public static boolean clearMelmagaFlgs (DBAccess db , String guid , String siteId) {
		if (db == null) {
			log.error("引数エラー：データベースコネクションが渡されませんでした。");
			return false;
		}
		
		if (! AppUtil.isValidGuid(guid) ) {
			log.error("引数エラー：guidが無効です。");
			return false;
		}

		if (siteId == null || siteId.equals("") ) {
			log.error("引数エラー：siteIdが無効です。");
			return false;
		}
		
		// 全てのメルマガを未読とする
		List targetMagList = getMelmagaList (db , siteId);
		
		if (targetMagList == null) {
			log.info("メルマガのリスト取得に失敗しました。");
			return false;
		}
		
		for ( Iterator it = targetMagList.iterator(); it.hasNext();) { 

			String targetMagId = (String)it.next();

			if (! clearMelmagaFlg (db , guid , targetMagId) ) {
				return false;
			}
			
		}
		
		return true;
	}
	*/
	
	/**
	 * <pre>
	 * 該当サイトIDに関連づけられた複数のメールマガジンに対し、購読状況を
	 * 「未読」「購読」のどちらかに更新する
	 * </pre>
	 * 
	 * @param db
	 * @param guid           guid null不可
	 * @param siteId         サイトID null不可
	 * @param magFlg         となしばのメルマガ購読状況 (0:未購読 1:購読 ） null可
	 * @param email          配信先のemail null可
	 * @param overWriteEmail メルマガ管理テーブルに既にemailが存在する場合、新しい値で上書きするか否か
	 */
	/**
	public static boolean updateMelmagaFlgs (DBAccess db , String guid , String siteId , String magFlg , String email , boolean overWriteEmail) {
		if (db == null) {
			log.error("引数エラー：データベースコネクションが渡されませんでした。");
			return false;
		}
		
		if (! AppUtil.isValidGuid(guid) ) {
			log.error("引数エラー：guidが無効です。");
			return false;
		}

		if (siteId == null || siteId.equals("") ) {
			log.error("引数エラー：siteIdが無効です。");
			return false;
		}
		
		if (magFlg == null ) {
			// 何もしない。
			return true;
		}
		
		if (magFlg.equals("0")) {
			// 全てのメルマガを未読とする
			return clearMelmagaFlgs(db, guid, siteId);
			
		} else if (magFlg.equals("1")) {
			
			// 全てのメルマガを購読とする
			return checkMelmagaFlgs(db, guid, siteId, email, overWriteEmail);

		} else {
			log.warn("想定しない値が渡されました。");
			log.info("magFlg=" + magFlg);
			// 何もしない。
			return true;
		}
		
	}
	*/
	
	/**
	 * <pre>
	 * 会員情報をデータベースから読み込む
	 * 
	 * 失敗した時はnullを返す
	 * 
	 * </pre>
	 * @param strPasswd
	 * @return
	 */
	public static Record getUserEmail(String strPasswd) {
		DBAccess db = null;
		ResultSet rs = null;
		try 
		{
			db = new DBAccess();
			db.prepareStatement("SELECT EMAIL, CASE WHEN LIMIT_DATETIME >= TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') THEN " + AppConstants.SUCCESS
					+ " ELSE " + AppConstants.ERROR + " END AS RETURN, INVALID_FLAG FROM COMMON.MAIL_KEY_MAP WHERE PASSWD=?");
			db.setString(1, strPasswd);
			
			return Record.getFirstRowOf(db);
		} 
		catch (Exception objExp) 
		{
			log.error ("EMAILを取得する際に例外エラーが発生しました。" , objExp);
			return null;
		}
		finally 
		{
			DBAccess.close(rs);
			DBAccess.close(db);
		}		
	}
	
	/**
	 * 受信メール管理用
	 * Sending mail maga registration mail to the user with logoff status
	 * @param strEmail
	 * @param strSiteId
	 * @param strGuid
	 * @return
	 */
	public static int sendSubscribeMail(String strEmail, String strSiteId, String strGuid)
	{
		return sendSubscribeMail(strEmail, strSiteId, strGuid, null, false);
	}
	
	/**
	 * メールパーミッション登録専用画面用
	 * Sending mail maga registration mail to the user with logoff status
	 * @param strEmail
	 * @param strSiteId
	 * @param strGuid
	 * @return
	 */
	public static int sendSubscribeMail(String strEmail, String strSiteId, String strGuid, Map mapMailId, boolean blnSitewiseFlg)
	{
		DBAccess db = null;
		try
		{
			db = new DBAccess();
			 
			// メールテンプレートを準備する
			MailTemplateUtil objMailTemplate = null;
			if (blnSitewiseFlg) {
				objMailTemplate = new MailTemplateUtil(MailTemplateUtil.MAIL_MAGA_SITEWISE_TEMPLATE_ID);
			}
			else {	
				objMailTemplate = new MailTemplateUtil(MailTemplateUtil.MAIL_MAGA_REGIST_TEMPLATE_ID);
			}	
			if (!objMailTemplate.load(db) ) {
				log.error("メールテンプレートの読み込みに失敗しました。");
				return SYSTEM_ERROR;
			}
			
			// システムプロパティを取得
			SystemProperties objSystemProperties = new SystemProperties(db);
			
			// メール送信者を指定する
			String strMailFrom    = ValueUtil.nullToStr(objMailTemplate.getFrom());
			if (strMailFrom.equals("")) {
				log.warn("MAIL_TEMPLテーブルにfromが指定されていません。システムプロパティを検索します。");
				strMailFrom =  objSystemProperties.get(MAIL_SENDER);
			}

			if (strMailFrom.equals("")) {
				log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
				return SYSTEM_ERROR;
			}
			
			// Using sequence to get next value
			long nReturn = MelmagaUtil.getOneTimePasswd(db);
			if (AppConstants.ERROR == nReturn)
			{
				log.error("シーケンスの取得に失敗しました。 Email = " + strEmail);
				db.rollback();
				return SYSTEM_ERROR;
			}
			
			String strFinalPasswd = "";  
			String strSequence = ValueUtil.nullToStr(String.valueOf(nReturn));
			String strTempPasswd = ValueUtil.nullToStr(DBUtil.makeRandomPassword(PASSWORD_LENGTH));
			if ("".equals(strSequence) || "".equals(strTempPasswd))
			{
				log.error("ワンタイムパスワードの作成出来ませんでした。");
				return SYSTEM_ERROR;
			}
			
			if (strSequence.length() < 4)
			{
				strFinalPasswd = DBUtil.makeRandomPassword(PASSWORD_LENGTH + 4);
			}
			else
			{
				strFinalPasswd = strTempPasswd.substring(0, 2) + strSequence.substring(0, 2)
					+ strTempPasswd.substring(2) + strSequence.substring(2);				
			}	
			
			// URLを生成する
			String strRegistUrl = objSystemProperties.get(MEMBER_SITE_TOP);
			if (strRegistUrl == null) {
				log.error("本登録URLの解釈に失敗しました。メール送信を中断します。");
				return SYSTEM_ERROR;
			}
			
			if (blnSitewiseFlg) {
				strRegistUrl += SITEWISE_SUBSCRIBE_URL + "&ukey=" + strFinalPasswd + "&sid=" + strSiteId;
			}
			else {	
				strRegistUrl += SUBSCRIBE_URL + "&passwd=" + strFinalPasswd;
			}
			
			// メール送信情報を設定する
			MailInfo objMailInfo = new MailInfo();
			objMailInfo.setMailTo(strEmail);
			objMailInfo.setMailFrom(strMailFrom);
			objMailInfo.setMobileFlag(MailTemplateUtil.isMobileEmail(db, strEmail));
			objMailInfo.setSiteId(strSiteId);
		
			// 件名情報を生成(件名の変数を置き換えるための変数を設定する)
			MailSubject objMailSubject = new MailSubject();
		
			Calendar objCalendar = Calendar.getInstance();
	    	objCalendar.set(objCalendar.get(Calendar.YEAR), objCalendar.get(Calendar.MONTH), objCalendar.get(Calendar.DATE), 
	    			objCalendar.get(Calendar.HOUR_OF_DAY), objCalendar.get(Calendar.MINUTE), objCalendar.get(Calendar.SECOND));
	    	objCalendar.add(Calendar.DATE, 1);
	    	StringBuffer sbufTime = new StringBuffer(); 
	    	sbufTime.append(objCalendar.get(Calendar.YEAR)).append("/").append(StringUtil.convertTo2Digits(String.valueOf(objCalendar.get(Calendar.MONTH)+1)))
	    			.append("/").append(StringUtil.convertTo2Digits(String.valueOf(objCalendar.get(Calendar.DATE)))).append(" ")
	    			.append(StringUtil.convertTo2Digits(String.valueOf(objCalendar.get(Calendar.HOUR_OF_DAY)))).append(":")
	    			.append(StringUtil.convertTo2Digits(String.valueOf(objCalendar.get(Calendar.MINUTE))));
	    	
			// 本文情報を生成(本文の変数を置き換えるための変数を設定する)
			MailBody objMailBody = new MailBody();
			objMailBody.setEmail(strEmail);
			objMailBody.setAuthUrl(strRegistUrl);
			objMailBody.setOrderDate(sbufTime.toString());
			
			if (blnSitewiseFlg)
			{
				if (mapMailId != null)
				{
					String strTitle = "";
					Set setKeys = mapMailId.keySet();
					Iterator objIterator = setKeys.iterator();
					while (objIterator.hasNext())
					{
						String strMailId = (String)objIterator.next();
						strTitle = strTitle + "  ・『 " + (String)mapMailId.get(strMailId) + " 』" + "\n";
					}
					
					if (strTitle.indexOf("\n") != -1) {
						strTitle = strTitle.substring(0, strTitle.lastIndexOf("\n"));
					}	
					
					objMailBody.setFreeText1(strTitle);
				}
			}	
			
			// 仮登録のメール送信
			boolean blnSent = objMailTemplate.doReplaceAndMail(objMailSubject, objMailBody, objMailInfo);
			if (!blnSent) 
			{
				log.error("メルマガ登録メールの送信に失敗しました。 Email = " + strEmail);
				return MAIL_SEND_ERROR;
			}
			
			if (blnSitewiseFlg)
			{
				// Insert into MAIL_SITEWISE_KEY_MAP
				nReturn = MelmagaUtil.deleteMailSitewiseKeyMap(db, strSiteId, strEmail);
				if (AppConstants.ERROR == nReturn)
				{
					log.error("メールキーマップの削除出来ませんでした。 Email = " + strEmail);
					db.rollback();
					return SYSTEM_ERROR;
				}
				
				if (mapMailId != null)
				{
					Set setKeys = mapMailId.keySet();
					Iterator objIterator = setKeys.iterator();
					while (objIterator.hasNext())
					{
						String strMailId = (String)objIterator.next();
						nReturn = MelmagaUtil.insertMailSitewiseKeyMap(db, strMailId, strSiteId, strFinalPasswd, strEmail);
						if (AppConstants.ERROR == nReturn)
						{
							log.error("メールキーマップへの登録出来ませんでした。 Email = " + strEmail);
							db.rollback();
							return SYSTEM_ERROR;
						}
					}	
				}	
			}
			else
			{	
				// Insert into MAIL_KEY_MAP
				nReturn = MelmagaUtil.deleteMailKeyMap(db, strEmail);
				if (AppConstants.ERROR == nReturn)
				{
					log.error("メールキーマップの削除出来ませんでした。 Email = " + strEmail);
					db.rollback();
					return SYSTEM_ERROR;
				}
				
				nReturn = MelmagaUtil.insertMailKeyMap(db, strEmail, strFinalPasswd);
				if (AppConstants.ERROR == nReturn)
				{
					log.error("メールキーマップへの登録出来ませんでした。 Email = " + strEmail);
					db.rollback();
					return SYSTEM_ERROR;
				}
			}
			
			db.commit();
			
		}
		catch (Exception objExp)
		{
	          log.error("例外エラーが発生しました。", objExp);
	          return SYSTEM_ERROR;
		}
		finally 
		{
			DBAccess.close(db);
		}
		
		return SUCCESS;
	}
	
	/**
	 * <pre>
	 * 会員情報をデータベースから読み込む
	 * 
	 * 失敗した時はAppConstants.ERRORを返す
	 * 
	 * </pre>
	 * @param strEmail
	 * @return
	 */
	public static int deleteMailKeyMap(DBAccess db, String strEmail) {
		ResultSet rs = null;
		try {
			db.prepareStatement("DELETE FROM COMMON.MAIL_KEY_MAP WHERE EMAIL=?");
			db.setString(1, strEmail);
			
			return  db.executeUpdate();
		} 
		catch (Exception objExp) 
		{
			log.error ("メールキーマップをする際に例外エラーが発生しました。　strEmail =" + strEmail , objExp);
			return AppConstants.ERROR;
		}
		finally 
		{
			DBAccess.close(rs);
		}		
	}
	
	/**
	 * <pre>
	 * 会員情報をデータベースから読み込む
	 * 
	 * 失敗した時はAppConstants.ERRORを返す
	 * 
	 * </pre>
	 * @param strEmail
	 * @param strPasswd
	 * @return
	 */
	public static int insertMailKeyMap(DBAccess db, String strEmail, String strPasswd) {
		ResultSet rs = null;
		try {
			db.prepareStatement("INSERT INTO COMMON.MAIL_KEY_MAP (EMAIL, PASSWD, MK_DATETIME, LIMIT_DATETIME) " +
					"VALUES (?, ?, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'), TO_CHAR(SYSDATE+1, 'YYYYMMDDHH24MISS'))");
			
			db.setString(1, strEmail);
			db.setString(2, strPasswd);
			
			return db.executeUpdate();
		} 
		catch (Exception objExp) 
		{
			log.error ("メールキーマップをを登録する際に例外エラーが発生しました。　strEmail =" + strEmail , objExp);
			return AppConstants.ERROR;
		}
		finally 
		{
			DBAccess.close(rs);
		}		
	}
	
	/**
	 * <pre>
	 * ワンタイムパスワードは1度認証したら無効にする
	 * 
	 * 失敗した時はAppConstants.ERRORを返す
	 * 
	 * </pre>
	 * @param strPasswd
	 * @return
	 */
	public static int uplateInvalidFlag(String strPasswd) {
		DBAccess db = null;
		ResultSet rs = null;
		try {
			db = new DBAccess();
			db.prepareStatement("UPDATE COMMON.MAIL_KEY_MAP SET INVALID_FLAG='1' WHERE PASSWD=?");
			db.setString(1, strPasswd);
			
			return  db.executeUpdate();
		} 
		catch (Exception objExp) 
		{
			log.error ("メールキーマップをする際に例外エラーが発生しました。　strPasswd =" + strPasswd , objExp);
			return AppConstants.ERROR;
		}
		finally 
		{
			DBAccess.close(db);
			DBAccess.close(rs);
		}		
	}
	
	/**************************************************************************************/
	/**  メールパーミッション登録専用画面用　 - Start */
	/**************************************************************************************/
	/**
	 * <pre>
	 * 会員情報をデータベースから読み込む
	 * 
	 * 失敗した時はnullを返す
	 * 
	 * </pre>
	 * @param strPasswd
	 * @return
	 */
	public static List getSitewisePermissionInfo(String strPasswd) {
		DBAccess db = null;
		ResultSet rs = null;
		try 
		{
			db = new DBAccess();
			db.prepareStatement("SELECT MAIL_ID, SITE_ID, EMAIL, CASE WHEN LIMIT_DATETIME >= TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') THEN " + AppConstants.SUCCESS
					+ " ELSE " + AppConstants.ERROR + " END AS RETURN FROM COMMON.MAIL_SITEWISE_KEY_MAP WHERE PASSWD=?");
			db.setString(1, strPasswd);
			
			return Record.getResultListOf(db);
		} 
		catch (Exception objExp) 
		{
			log.error ("EMAILを取得する際に例外エラーが発生しました。" , objExp);
			return null;
		}
		finally 
		{
			DBAccess.close(rs);
			DBAccess.close(db);
		}		
	}
	
	/**
	 * <pre>
	 * 会員情報をデータベースから読み込む
	 * 
	 * 失敗した時はAppConstants.ERRORを返す
	 * 
	 * </pre>
	 * @param strEmail
	 * @return
	 */
	public static int deleteMailSitewiseKeyMap(DBAccess db, String strSiteId, String strEmail) {
		ResultSet rs = null;
		try {
			db.prepareStatement("DELETE FROM COMMON.MAIL_SITEWISE_KEY_MAP WHERE SITE_ID=? AND EMAIL=?");
			db.setString(1, strSiteId);
			db.setString(2, strEmail);
			
			return  db.executeUpdate();
		} 
		catch (Exception objExp) 
		{
			log.error ("メールキーマップをする際に例外エラーが発生しました。　strEmail =" + strEmail , objExp);
			return AppConstants.ERROR;
		}
		finally 
		{
			DBAccess.close(rs);
		}		
	}
	
	/**
	 * <pre>
	 * 会員情報をデータベースから読み込む
	 * 
	 * 失敗した時はAppConstants.ERRORを返す
	 * 
	 * </pre>
	 * @param strEmail
	 * @param strPasswd
	 * @return
	 */
	public static int insertMailSitewiseKeyMap(DBAccess db, String strMailId, String strSiteId, String strPasswd, String strEmail) 
	{
		try 
		{
			db.prepareStatement("INSERT INTO COMMON.MAIL_SITEWISE_KEY_MAP (MAIL_ID, SITE_ID, PASSWD, EMAIL, MK_DATETIME, LIMIT_DATETIME) " +
					"VALUES (?, ?, ?, ?, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'), TO_CHAR(SYSDATE+1, 'YYYYMMDDHH24MISS'))");
			
			db.setString(1, strMailId);
			db.setString(2, strSiteId);
			db.setString(3, strPasswd);
			db.setString(4, strEmail);
			
			return db.executeUpdate();
		} 
		catch (Exception objExp) 
		{
			log.error ("メールキーマップをを登録する際に例外エラーが発生しました。　strEmail =" + strEmail , objExp);
			return AppConstants.ERROR;
		}
	}
	
	/**
	 * <pre>
	 * ワンタイムパスワードは1度認証したら無効にする
	 * 
	 * 失敗した時はAppConstants.ERRORを返す
	 * 
	 * </pre>
	 * @param strPasswd
	 * @return
	 */
	public static int uplateSitewiseInvalidFlag(String strPasswd) {
		DBAccess db = null;
		ResultSet rs = null;
		try {
			db = new DBAccess();
			db.prepareStatement("UPDATE COMMON.MAIL_SITEWISE_KEY_MAP SET INVALID_FLAG='1' WHERE PASSWD=?");
			db.setString(1, strPasswd);
			
			return  db.executeUpdate();
		} 
		catch (Exception objExp) 
		{
			log.error ("メールキーマップをする際に例外エラーが発生しました。　strPasswd =" + strPasswd , objExp);
			return AppConstants.ERROR;
		}
		finally 
		{
			DBAccess.close(db);
			DBAccess.close(rs);
		}		
	}
	

    /**
     * <pre>
     * 会員情報をデータベースから読み込む
     * 
     * 失敗した時はAppConstants.ERRORを返す
     * 
     * </pre>
     * @param strEmail
     * @return
     */
    public static boolean isMobileEmail(String strEmail) throws Exception
    {
        DBAccess db = null;
        try 
        {
           db = new DBAccess();
           return isMobileEmail(db, strEmail);
        } 
        finally 
        {
            DBAccess.close(db);
        }
    }
	
	/**
	 * <pre>
	 * 会員情報をデータベースから読み込む
	 * 
	 * 失敗した時はAppConstants.ERRORを返す
	 * 
	 * </pre>
	 * @param strEmail
	 * @return
	 */
	public static boolean isMobileEmail(DBAccess db, String strEmail) throws Exception
	{
		ResultSet rs = null;
		try 
		{
			db.prepareStatement("SELECT COMMON.IS_MOBILE_EMAIL(?) AS COUNT FROM DUAL");
			db.setString(1, strEmail);
			rs = db.executeQuery();
			if (rs.next()) 
			{
				if (rs.getInt("COUNT") == MOBILE_EMAIL_FLAG) {
					return true;
				}
			}
			
			return false;
		} 
		finally 
		{
			DBAccess.close(rs);
		}
	}
	/**************************************************************************************/
	/**  メールパーミッション登録専用画面用　 - End */
	/**************************************************************************************/
	
	/**
	 * getting the sequence value
	 * @param db
	 * @return
	 */
	private static long getOneTimePasswd(DBAccess db)
	{
		ResultSet rs = null;
		try {
			db.prepareStatement("SELECT COMMON.SEQ_ONE_TIME_PASSWD.NEXTVAL AS PASSWD FROM DUAL");
			
			rs = db.executeQuery();
			if (rs.next())
			{
				return rs.getLong("PASSWD");
			}
			
			return AppConstants.ERROR;
		} 
		catch (Exception objExp) 
		{
			log.error ("メールキーマップをを登録する際に例外エラーが発生しました。" , objExp);
			return AppConstants.ERROR;
		}
		finally 
		{
			DBAccess.close(rs);
		}
	}
	
	/**
	 * <pre>
	 * 各サイトに関連づけられたメールマガジンのIDをリストで返す
	 * </pre>
	 * 
	 * null：エラー発生時
	 * 
	 * @param db
	 * @param siteId
	 * @return
	 * @deprecated 
	 
	public static List getMelmagaList (DBAccess db , String siteId) {
		
		if (siteId == null || siteId.equals("")) {
			log.error ("引数エラー：siteIdが不正です。");
			return null;
		}
		
		// MAG_MAPからsiteIdとmag_idの対応を調べる
		List magIdList = new ArrayList();
		
		try {
			db.prepareStatement("SELECT MAG_ID FROM MAG_MAP WHERE SITE_ID=?");
			db.setString(1, siteId);
			List list = Record.getResultListOf(db);
			
			for ( Iterator it = list.iterator(); it.hasNext();){ 
				Record rec = (Record)it.next();
				String mag_id = rec.getString("MAG_ID");
				magIdList.add(mag_id);
			}
			
			return magIdList;
			
		} catch (Exception e) {
			log.error ("サイトIDからメルマガIDを取得する際に例外エラーが発生しました。" , e);
			return null;
		}		
		
	}
	*/

	/**
	 * <pre>
	 * 該当emailに関連づけられたアクセスしたサイトの未購読メールマガジンのIDをリストで返す
	 * このメソッドは自動車など側使う。※DBAccessパラメータは渡されない
	 * </pre>
	 * 
	 * new ArrayList()：エラー発生時
	 * 
	 * @param email
	 * @return List<String>
	 */
	public static List getMelmagaListByEmail(String email, String siteId) {
		DBAccess db = null;
		try {
			db = new DBAccess();
			return getMelmagaListByEmail(db, email, siteId);
		} catch (Exception e) {
			log.error("emailからメルマガIDを取得する際に例外エラーが発生しました。", e);
			return new ArrayList();
		} finally {
			DBAccess.close(db);
		}
	}
	
	/**
	 * <pre>
	 * 該当emailに関連づけられたアクセスしたサイトの未購読メールマガジンのレコードをリストで返す
	 * このメソッドは自動車など側使う。※DBAccessパラメータは渡されない
	 * </pre>
	 * 
	 * new ArrayList()：エラー発生時
	 * 
	 * @param email
	 * @return List<String>
	 */
	public static List getMelmagaRecordListByEmail(String email, String siteId) {
		DBAccess db = null;
		try {
			db = new DBAccess();
			return getMailRecordList(db, email, siteId);
		} catch (Exception e) {
			log.error("emailからメルマガレコードを取得する際に例外エラーが発生しました。", e);
			return new ArrayList();
		} finally {
			DBAccess.close(db);
		}
	}
	
	/**
	 * <pre>
	 * 該当emailに関連づけられたアクセスしたサイトの未購読メールマガジンのIDをリストで返す
	 * </pre>
	 * 
	 * new ArrayList()：エラー発生時
	 * 
	 * @param db
	 * @param email
	 * @param siteId
	 * @return List<String>
	 */
	public static List getMelmagaListByEmail (DBAccess db , String email, String siteId) {
		
		if (email == null || email.equals("")) {
			log.error ("引数エラー：emailが不正です。");
			return new ArrayList();
		}
		
		// MAG_MAPからsiteIdとmag_idの対応を調べる
		List magIdList = new ArrayList();
		
		try {
			List list = getMailRecordList(db, email, siteId);
			for ( Iterator it = list.iterator(); it.hasNext();){ 
				Record rec = (Record)it.next();
				magIdList.add(rec.getString("MAIL_ID"));
			}
			
			return magIdList;
			
		} catch (Exception e) {
			log.error ("emailからメルマガIDを取得する際に例外エラーが発生しました。" , e);
			return magIdList;
		}		
		
	}
	
	/**
	 * <pre>
	 * 該当emailに関連づけられたアクセスしたサイトの未購読メール情報をリストで返す
	 * </pre>
	 * 
	 * new ArrayList()：エラー発生時
	 * 
	 * @param db
	 * @param email
	 * @param siteId
	 * @return List<Record>
	 */
	public static List getMailRecordList (DBAccess db , String email, String siteId) {
		
		// MAG_MAPからsiteIdとmag_idの対応を調べる
		List recordList = new ArrayList();
		
		if (email == null || email.equals("")) {
			log.error ("引数エラー：emailが不正です。");
			return recordList;
		}

		try {
			db.prepareStatement("SELECT MM.MAIL_ID, MM.MAIL_TYPE, MM.TITLE, MM.DESCRIPTION, MM.SORT, MM.TITLE_STEP, MM.DESCRIPTION_STEP " +
					" FROM COMMON.MAIL_MST MM, COMMON.MAIL_SITE_MAP SM" +
					" WHERE MM.MAIL_ID = SM.MAIL_ID AND MM.INVALID_FLAG = '0' AND SM.INVALID_FLAG = '0'" +
					" AND SM.SITE_ID = ? AND NOT EXISTS (SELECT MS.MAIL_ID" +
					" FROM COMMON.MAIL_SUBSCRIBE MS" +
					" WHERE MS.EMAIL = ? AND MS.MAIL_ID = MM.MAIL_ID AND MS.INVALID_FLAG = '0')" +
					" ORDER BY MM.SORT");
			db.setString(1, siteId);
			db.setString(2, email);
			recordList = Record.getResultListOf(db);
			
			return recordList;
			
		} catch (Exception e) {
			log.error ("emailからメルマガIDを取得する際に例外エラーが発生しました。" , e);
			return recordList;
		}		
		
	}
	

	/**
	 * <pre>
	 * 該当siteIdに関連づけられた全てメール情報をリストで返す
	 * </pre>
	 * 
	 * new ArrayList()：エラー発生時
	 * 
	 * @param db
	 * @param siteId
	 * @return List<Record>
	 */
	public static List getSiteMailList (DBAccess db , String siteId) {
		
		// MAG_MAPからsiteIdとmag_idの対応を調べる
		List recordList = new ArrayList();
		
		if (siteId == null || siteId.equals("")) {
			log.error ("引数エラー：siteIdが不正です。");
			return recordList;
		}

		try {
			db.prepareStatement("SELECT" +
					" MM.MAIL_ID," +
					" MM.MAIL_TYPE," +
					" MM.TITLE, " +
					" MM.DESCRIPTION " +
					" FROM" +
					" COMMON.MAIL_MST MM," +
					" COMMON.MAIL_SITE_MAP SM" +
					" WHERE" +
					" MM.MAIL_ID = SM.MAIL_ID" +
					" AND MM.INVALID_FLAG = '0'" +
					" AND SM.INVALID_FLAG = '0'" +
					" AND SM.SITE_ID = ? " +
					" ORDER BY MM.SORT");
			db.setString(1, siteId);
			recordList = Record.getResultListOf(db);
			
			return recordList;
			
		} catch (Exception e) {
			log.error ("siteIdからメルマガIDを取得する際に例外エラーが発生しました。" , e);
			return recordList;
		}		
		
	}
	
	/**
	 * <pre>
	 * 特定の個人のメールマガジン購読状況を「購読しない」に変更する
	 * 
	 * 処理が成功したらtrue
	 * 失敗したらfalseを返す
	 * 
	 * </pre>
	 * 
	 * @param db
	 * @param strEmail   guid
	 * @param strMailId メールマガジンID
	 * @param strUpdateFrom TODO
	 */
	public static boolean clearMelmagaFlg (DBAccess db, String strEmail, String strMailId, String strUpdateFrom) 
	{
		if (db == null) {
			log.error("引数エラー：データベースコネクションが渡されませんでした。");
			return false;
		}
		
		if (strMailId == null || strMailId.equals("")) 
		{
			log.error("引数エラー：mail_idが無効です。");
			return false;
		}
		
		if (strEmail == null || "".equals(strEmail)) 
		{
			log.error("引数エラー：emailが無効です。");
			return false;
		}
	
		try 
		{
			// レコードが存在する場合は、既に購読中なので、削除する
			// mag_subscribeからデータを検索
			Record objRecord = MagSubscribe.selectMailSubscribe(db, strEmail, strMailId);
			if (objRecord == null) 
			{
				// レコードが存在しない場合はinsert
				MagSubscribe.insertMailSubscribe(db, strEmail, strMailId, MagSubscribe.MAG_INVALID_FLAG_ON, strUpdateFrom);
			}
			else
			{
				if (MagSubscribe.MAG_INVALID_FLAG_OFF.equals(objRecord.get(MagSubscribe.INVALID_FLAG)))
				{
					// レコードが存在している場合はupdate
					MagSubscribe.updateMailSubscribe(db, strEmail, strMailId, MagSubscribe.MAG_INVALID_FLAG_ON, strUpdateFrom);
				}		
			}	
			
			return true;
		} 
		catch (Exception objExp) 
		{
			log.error ("メールマガジン購読状況の変更中に、例外エラーが発生しました。" , objExp);
			return false;
		}		
	}	

	/**
	 * <pre>
	 * 特定の個人のメールマガジン購読状況を「購読する」に変更する
	 * 
	 * overWriteEmailがfalseの場合、既に購読テーブルにデータが入っている時、
	 * 既存のメールアドレスを上書きしない
	 * 
	 * メールアドレスが空の場合はエラーログを出力する
	 * 
	 * 処理が成功したらtrue
	 * 処理が失敗したらfalseを返す
	 * 
	 * </pre>
	 * 
	 * @param db
	 * @param strGuid   guid
	 * @param strMailId メールマガジンID
	 * @param strEmail  配送先email nullは原則不可。
	 * 
	 */
	public static boolean checkMelmagaFlg (DBAccess db, String strEmail, String strMailId, String strUpdateFrom) 
	{
		if (db == null) 
		{
			log.error("引数エラー：データベースコネクションが渡されませんでした。");
			return false;
		}
		
		if (strMailId == null || strMailId.equals("")) 
		{
			log.error("引数エラー：mail_idが無効です。");
			return false;
		}
		
		if (strEmail == null || "".equals(strEmail)) 
		{
			log.error("引数エラー：emailが無効です。");
			return false;
		}

		try 
		{
			// mag_subscribeからデータを検索
			Record objRecord = MagSubscribe.selectMailSubscribe(db, strEmail, strMailId);
			if (objRecord == null) 
			{
				// レコードが存在しない場合はinsert
				MagSubscribe.insertMailSubscribe(db, strEmail, strMailId, MagSubscribe.MAG_INVALID_FLAG_OFF, strUpdateFrom);
			}
			else
			{
				if (MagSubscribe.MAG_INVALID_FLAG_ON.equals(objRecord.get(MagSubscribe.INVALID_FLAG)))
				{
					// レコードが存在している場合はupdate
					if (strUpdateFrom == null) {
						strUpdateFrom = (String) objRecord.get(MagSubscribe.REGISTERED_FROM);
					}	
					MagSubscribe.updateMailSubscribe(db, strEmail, strMailId, MagSubscribe.MAG_INVALID_FLAG_OFF, strUpdateFrom);
				}		
			}	
			
			return true;
		} 
		catch (Exception objExp) 
		{
			log.error ("メールマガジン購読状況の変更中に、例外エラーが発生しました。" , objExp);
			return false;
		}		
	}
	

	/**
	 * <pre>
	 * 特定の個人のメールマガジン購読状況を「購読する」に変更する
	 * 
	 * overWriteEmailがfalseの場合、既に購読テーブルにデータが入っている時、
	 * 既存のメールアドレスを上書きしない
	 * 
	 * メールアドレスが空の場合はエラーログを出力する
	 * 
	 * 処理が成功したらtrue
	 * 処理が失敗したらfalseを返す
	 * 
	 * </pre>
	 * 
	 * @param db
	 * @param strGuid   guid
	 * @param strMailId メールマガジンID
	 * @param strEmail  配送先email nullは不可。
	 * @param strInvalidFlag  無効フラグ　「0」：有効　「1」：無効
	 *  
	 */
	public static boolean executeMailSubscribe(DBAccess db, String strEmail, String strMailId, String strInvalidFlag, String strUpdateFrom) {
		if (db == null) {
			log.error("引数エラー：データベースコネクションが渡されませんでした。");
			return false;
		}

		if (strMailId == null || strMailId.equals("")) {
			log.error("引数エラー：mail_idが無効です。");
			return false;
		}

		if (strEmail == null || "".equals(strEmail)) {
			log.error("引数エラー：emailが無効です。");
			return false;
		}

		try {

			// mag_subscribeからデータを検索
			Record objRecord = MagSubscribe.selectMailSubscribe(db, strEmail, strMailId);
			if (objRecord == null) {
				// レコードが存在しない場合はinsert
				MagSubscribe.insertMailSubscribe(db, strEmail, strMailId, strInvalidFlag, strUpdateFrom);
			} else {
				// 変更の場合だけ更新します。
				if (!strInvalidFlag.equals(objRecord.get(MagSubscribe.INVALID_FLAG))) {
					// レコードが存在している場合はupdate
					MagSubscribe.updateMailSubscribe(db, strEmail, strMailId, strInvalidFlag, strUpdateFrom);
				}
			}

			return true;
		} catch (Exception objExp) {
			log.error("メールマガジン購読状況の変更中に、例外エラーが発生しました。", objExp);
			return false;
		}
	}
	
	/**
	 * Get TITLE and DESCRIPTION based on MAIL_ID
	 * @param strMailId
	 * @return
	 * @throws AppException
	 */
	public static Record getMelmagaDetails(DBAccess db, String strMailId) throws AppException 
	{
		try
		{
			db.prepareStatement(SELECT_MAIL_MST);
			db.setString(1, strMailId);
			
			return Record.getFirstRowOf(db);
		}
		catch (Exception objExp) 
		{
			log.error("例外エラーが発生しました。" , objExp);
			throw new AppException(objExp);
		} 
	}
	
	public static boolean getInvalidFlag(DBAccess db, String strMailId, String strEmail) throws AppException 
	{
		ResultSet rs = null;
		try
		{
			db.prepareStatement(SELECT_MAIL_SUBSCRIBE);
			db.setString(1, strMailId);
			db.setString(2, strEmail);
			
			rs = db.executeQuery();
			if (rs.next())
			{
				if ("1".equals(rs.getString("INVALID_FLAG"))) {
					return true;
				}
				
				return false;
			}
			
			return true;
		}
		catch (Exception objExp) 
		{
			log.error("例外エラーが発生しました。" , objExp);
			throw new AppException(objExp);
		} 
		finally 
		{
			DBAccess.close(rs);
		}
	}
}
