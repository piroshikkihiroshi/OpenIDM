package jp.co.webcrew.phoenix.sstag.replace;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.replacer.Replacer;
import jp.co.webcrew.phoenix.sstag.bean.FormCssInfoBean;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.db.FormItemDb;
import jp.co.webcrew.phoenix.sstag.impl.FormDispExecuter;
import jp.co.webcrew.phoenix.sstag.util.FormItemUtil;
import jp.co.webcrew.phoenix.sstag.util.ReplaceUtil;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

public class PhoenixReplacer extends Replacer {

    /** FORMキーワード用の接頭辞 */
    public static final String FORM_PREFIX = "form.";

    /** ロガー */
    private static final Logger log = Logger.getLogger(FormDispExecuter.class);

    @Override
    public String replace(String source, HttpServletRequest request, HttpServletResponse response) {
        try {

            String result = null;

            if (source.startsWith(FORM_PREFIX)) {
                result = replaceForm(source.substring(FORM_PREFIX.length()), request, response);
            }

            return result;

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return null;
        }
    }

    /** 置換変数名：フォーム項目に入力された生の値 */
    private static final String FORM_ITEM_RAW_VAL_KEY = "raw";

    /** 置換変数名：フォーム項目に入力された値 */
    private static final String FORM_ITEM_VALUE_VAL_KEY = "value";

    /** 置換変数名：フォーム項目に入力された値 */
    private static final String FORM_ITEM_VALUE_NOENC_VAL_KEY = "value_noenc";

    /** 置換変数名：選択肢の場合、選択されたvalue値に対する表示用の値 */
    private static final String FORM_ITEM_DISP_VAL_KEY = "disp";

    /** 置換変数名：選択肢の場合、選択されたvalue値に対する表示用の値 */
    private static final String FORM_ITEM_DISP_NOENC_VAL_KEY = "disp_noenc";

    /** 置換変数名：項目が選択項目の場合に値がチェックされているは "checked"という文字、チェックされていない場合には値なし */
    private static final String FORM_ITEM_CHECKED_VAL_KEY = "{0}.checked";

    /** 置換変数名：項目が選択項目の場合に値がチェックされているは "selected"という文字、チェックされていない場合には値なし */
    private static final String FORM_ITEM_SELECTED_VAL_KEY = "{0}.selected";

    /** 置換変数名：バリデーションエラーの文字列 */
    private static final String FORM_ITEM_ERROR_VAL_KEY = "error";

    /** 置換変数名：バリデーションエラーの番号 */
    private static final String FORM_ITEM_ERRNO_VAL_KEY = "errno";

    /** 置換変数名：フォーム項目CSS */
    private static final String FORM_ITEM_CSS_VAL_KEY = "css.{0}";

    /** 置換変数名：注意書き文言 */
    private static final String FORM_ITEM_CAUTION_VAL_KEY = "caution";

    /** 置換変数名：項目のタイプ */
    private static final String FORM_ITEM_TYPE_VAL_KEY = "type";

    /** 置換変数名：入力画面での表示文字数 */
    private static final String FORM_ITEM_CLM_SIZE_VAL_KEY = "clm_size";

    /** 置換変数名：入力画面での表示行数 */
    private static final String FORM_ITEM_ROW_SIZE_VAL_KEY = "row_size";

    /** 置換変数名：最大文字数 */
    private static final String FORM_ITEM_LEAST_VAL_KEY = "least";

    /** 置換変数名：最大文字数 */
    private static final String FORM_ITEM_MOST_VAL_KEY = "most";

    /** 置換変数名：最大文字数 */
    private static final String FORM_ITEM_MIN_VAL_KEY = "min";

    /** 置換変数名：最大文字数 */
    private static final String FORM_ITEM_MAX_VAL_KEY = "max";

    /** 置換変数名：日付・時刻入力タイプ */
    private static final String FORM_ITEM_DATE_TIME_INPUT_VAL_KEY = "date_time_input";

    public String replaceForm(String target, HttpServletRequest request, HttpServletResponse response)
            throws SQLException, InstantiationException {

        String[] param = target.split("\\.", 3);
        if (PhoenixUtil.isEmpty(param) || param.length < 3 || PhoenixUtil.isEmpty(param[0])
                || PhoenixUtil.isEmpty(param[1]) || PhoenixUtil.isEmpty(param[2])) {
            return null;
        }

        int siteId = SstagUtil.getSiteId(null, request);
        String formId = param[0];
        String itemId = param[1];
        String suffix = param[2];

        // バリデーションエラーメッセージを全てまとめたものの場合
        if (itemId.equalsIgnoreCase("validation_error")) {

            Map<String, String> replaceMap = new HashMap<String, String>();
            
            List<String> names = new ArrayList<String>();
            List<String> titles = new ArrayList<String>();
            List<String> msgs = new ArrayList<String>();
            
            // セッションストアで保持している入力チェックの結果を取得する。
            Map<String, String[]> vResult = StoreUtil.getValidationResult(request, formId);
            if (!PhoenixUtil.isEmpty(vResult)) {
                    
                // フォーム項目一覧を取得する。
                List<FormItemBean> formItemList = FormItemDb.getList(siteId, formId, null, null, null, null);
                for (FormItemBean formItem : formItemList) {

                    // この項目に対するエラー情報を取りだす。
                    String[] errors = vResult.get(formItem.getItemId());
                    if (errors != null) {
                        names.add(formItem.getItemId());
                        titles.add(formItem.getTitle());
                        msgs.add((errors.length >= 2 && !PhoenixUtil.isEmpty(errors[1]) ? errors[1] : "Error"));
                    }
                }
            }
            
            replaceMap.put("name", ValueUtil.concat(names, " "));
            replaceMap.put("name.br", ValueUtil.concat(names, "<br />\n"));
            replaceMap.put("title", ValueUtil.concat(titles, " "));
            replaceMap.put("title.br", ValueUtil.concat(titles, "<br />\n"));
            replaceMap.put("msg", ValueUtil.concat(msgs, " "));
            replaceMap.put("msg.br", ValueUtil.concat(msgs, "<br />\n"));

            return replaceMap.get(suffix);
        }
        
        // フォーム項目一覧を取得する。
        List<FormItemBean> formItemList = FormItemDb.getList(siteId, formId, null, null, null, null);
        for (FormItemBean formItem : formItemList) {
            if (formItem.getItemId().equals(itemId)) {

                // セッションストアで保持している入力チェックの結果を取得する。
                Map<String, String[]> vResult = StoreUtil.getValidationResult(request, formId);
                if (vResult == null) {
                    vResult = new HashMap<String, String[]>();
                }

                // この項目に対するエラー情報を取りだす。
                String[] errors = vResult.get(formItem.getItemId());

                Map<String, String> replaceMap = new HashMap<String, String>();

                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".1", formItem.getCaution1());
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".2", formItem.getCaution2());
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".3", formItem.getCaution3());
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".4", formItem.getCaution4());
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".5", formItem.getCaution5());
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".1.br", PhoenixUtil.isEmpty(formItem.getCaution1()) ? ""
                        : "<br />");
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".2.br", PhoenixUtil.isEmpty(formItem.getCaution2()) ? ""
                        : "<br />");
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".3.br", PhoenixUtil.isEmpty(formItem.getCaution3()) ? ""
                        : "<br />");
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".4.br", PhoenixUtil.isEmpty(formItem.getCaution4()) ? ""
                        : "<br />");
                replaceMap.put(FORM_ITEM_CAUTION_VAL_KEY + ".5.br", PhoenixUtil.isEmpty(formItem.getCaution5()) ? ""
                        : "<br />");
                replaceMap.put(FORM_ITEM_TYPE_VAL_KEY, formItem.getType());
                replaceMap.put(FORM_ITEM_CLM_SIZE_VAL_KEY, ValueUtil.nullToStr(formItem.getClmSize()));
                replaceMap.put(FORM_ITEM_ROW_SIZE_VAL_KEY, ValueUtil.nullToStr(formItem.getRowSize()));
                replaceMap.put(FORM_ITEM_LEAST_VAL_KEY, ValueUtil.nullToStr(formItem.getLeast()));
                replaceMap.put(FORM_ITEM_MOST_VAL_KEY, ValueUtil.nullToStr(formItem.getMost()));
                replaceMap.put(FORM_ITEM_MIN_VAL_KEY, ValueUtil.nullToStr(formItem.getMin()));
                replaceMap.put(FORM_ITEM_MAX_VAL_KEY, ValueUtil.nullToStr(formItem.getMax()));
                replaceMap.put(FORM_ITEM_DATE_TIME_INPUT_VAL_KEY, ValueUtil.nullToStr(formItem.getDateTimeInput()));

                for (FormCssInfoBean formCssInfo : formItem.getFormCssInfoList()) {
                    replaceMap.put(MessageFormat.format(FORM_ITEM_CSS_VAL_KEY, formCssInfo.getVarName()) + "."
                            + Integer.toString(formCssInfo.getNum()), formCssInfo.getVarValue());

                    if (formCssInfo.getNum() == 1) {
                        replaceMap.put(MessageFormat.format(FORM_ITEM_CSS_VAL_KEY, formCssInfo.getVarName()),
                                formCssInfo.getVarValue());
                    }
                }

                FormItemUtil formItemUtil = FormItemUtil.getInstance(formItem, request);

                SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getRaw(), FORM_ITEM_RAW_VAL_KEY);
                SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getValueNoenc(), FORM_ITEM_VALUE_NOENC_VAL_KEY);
                SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getValue(), FORM_ITEM_VALUE_VAL_KEY);
                SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getDispNoenc(), FORM_ITEM_DISP_NOENC_VAL_KEY);
                SstagUtil.setValueToReplaceMap(replaceMap, formItemUtil.getDisp(), FORM_ITEM_DISP_VAL_KEY);

                SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getRaws(), FORM_ITEM_RAW_VAL_KEY);
                SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getValuesNoenc(),
                        FORM_ITEM_VALUE_NOENC_VAL_KEY);
                SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getValues(), FORM_ITEM_VALUE_VAL_KEY);
                SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getDispsNoenc(), FORM_ITEM_DISP_NOENC_VAL_KEY);
                SstagUtil.setValuesToReplaceMap(replaceMap, formItemUtil.getDisps(), FORM_ITEM_DISP_VAL_KEY);


                // 性別のときだけ、rawsではなくvaluesでchecked/selectedの値を確認する。
                String[] values = (formItem.getType().equals("17") ? formItemUtil.getValues() : formItemUtil.getRaws());
                for (String value : values) {
                    SstagUtil.setValueToReplaceMap(replaceMap, "checked", FORM_ITEM_CHECKED_VAL_KEY, value);
                    SstagUtil.setValueToReplaceMap(replaceMap, "selected", FORM_ITEM_SELECTED_VAL_KEY, value);
                }

                // エラーが存在する場合、
                if (!PhoenixUtil.isEmpty(errors)) {
                    // エラーメッセージ自体にも置換変数が含まれる。
                    String error = (errors.length >= 2 && !PhoenixUtil.isEmpty(errors[1]) ? errors[1] : "Error");
                    replaceMap.put(FORM_ITEM_ERROR_VAL_KEY, ReplaceUtil.getReplacedHtml(error, replaceMap));
                    replaceMap.put(FORM_ITEM_ERROR_VAL_KEY + ".br", "<br />");
                    String errno = (errors.length >= 1 && !PhoenixUtil.isEmpty(errors[0]) ? errors[0] : "");
                    replaceMap.put(FORM_ITEM_ERRNO_VAL_KEY, errno);
                } else {
                    replaceMap.put(FORM_ITEM_ERROR_VAL_KEY, "");
                    replaceMap.put(FORM_ITEM_ERROR_VAL_KEY + ".br", "");
                    replaceMap.put(FORM_ITEM_ERRNO_VAL_KEY, "");
                }

                return replaceMap.get(suffix);
            }
        }

        return null;

    }
}
