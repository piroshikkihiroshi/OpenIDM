package jp.co.webcrew.dbaccess.db;

import java.sql.SQLException;

/**
 * DB接続エラー用のExceptionクラス。
 * 
 * @author kurinami
 */
public class DBConnectionException extends SQLException {

    /** シリアルバージョン */
    private static final long serialVersionUID = 1L;

    public DBConnectionException() {
    }
    
    public DBConnectionException(Throwable t) {
        initCause(t);
    }
}
