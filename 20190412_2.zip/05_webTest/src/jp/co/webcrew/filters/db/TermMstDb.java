package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;
import jp.co.webcrew.phoenix.vtable.db.VDb;

/**
 * 端末識別マスタを管理するdbクラス。
 * 
 * @author kurinami
 */
public class TermMstDb extends RefreshMstDb {

    /** ロガー */
    private static final Logger log = Logger.getLogger(TermMstDb.class);

	/** 端末情報取得用SQL */
	private static final String TERM_MST_SELECT = "select * from term_mst order by case when ident_string is null then ' ' else ident_string end desc";

	/** 不明の端末を表す端末ID */
	public static final int UNKNOWN_TERM_ID = -1;

	/** クライアントタイプ：pc */
	public static final String TYPE_PC_BROWSER = "pc";

	/** クライアントタイプ：docomo */
	public static final String TYPE_DOCOMO = "docomo";

	/** クライアントタイプ：au */
	public static final String TYPE_AU = "au";

	/** クライアントタイプ：softbank */
	public static final String TYPE_SOFTBANK = "softbank";

	/** クライアントタイプ：willcom */
	public static final String TYPE_WILLCOM = "willcom";

	/** クライアントタイプ：その他 */
	public static final String TYPE_CRAWLER = "crawler";

	/** 唯一のインスタンス */
	private static TermMstDb termMstDb = new TermMstDb();

	/** 端末識別情報の一覧 */
	private List termList = null;

	/** 端末識別情報の一覧　部分一致、仮想テーブルに登録しています、スキーマcommonの仮想テーブルterm_info_partialです。 */
    private List<Map<String, Object>> termMapList = new ArrayList<Map<String, Object>>();

	/**
	 * 生成不能コンストラクタ
	 */
	private TermMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static TermMstDb getInstance() {
		return termMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			List termList = new ArrayList();

			// サイト情報一覧を検索する。
			rs = dbAccess.executeQuery(TERM_MST_SELECT);
			while (dbAccess.next(rs)) {
				Map element = new HashMap();
				element.put("term_id", new Integer(rs.getInt("term_id")));
				element.put("carrier", ValueUtil.nullToStr(rs
						.getString("carrier")));
				element.put("term_type", ValueUtil.nullToStr(rs
						.getString("term_type")));
				element.put("ident_string", ValueUtil.nullToStr(rs
						.getString("ident_string")));
				element.put("memo", ValueUtil.nullToStr(rs.getString("memo")));

				termList.add(element);
			}

			this.termList = termList;

			// 部分一致の端末情報を検索する。
			initTermPartial();
		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

    /**
     * 部分一致の端末情報を検索する。
     * 
     * @throws SQLException
     */
    private void initTermPartial() throws SQLException {
        List<Map<String, Object>> _termMapList = new ArrayList<Map<String, Object>>();
        // 部分一致の端末情報を取得する。
        List<Map<String, ClmDataBean>> termMapBeanList = VDb.getList(800, "term_mst_partial_match", null, null, null,
                "ident_string", "desc");
        for (Map<String, ClmDataBean> termMapBean : termMapBeanList) {
            Map element = new HashMap();
            element.put("term_id", new Integer(termMapBean.get("term_id").getData()));
            element.put("carrier", ValueUtil.nullToStr(termMapBean.get("carrier").getData()));
            element.put("term_type", ValueUtil.nullToStr(termMapBean.get("term_type").getData()));
            element.put("ident_string", ValueUtil.nullToStr(termMapBean.get("ident_string").getData()));
            element.put("memo", ValueUtil.nullToStr(termMapBean.get("memo").getData()));
            log.debug("initTermPartial() element:"+element);
            _termMapList.add(element);
        }
        this.termMapList = _termMapList;
        log.debug("term_mst_partial_matchのデータ件数：" + termMapList.size());
    }

	/**
	 * uaを元に端末情報を返す。<br>
	 * 不明な端末のUAの場合は、nullが返る。
	 * 
	 * @param ua
	 * @return
	 */
	public Map getTermInfo(String ua) {
	    Map termMap = null; 
		// NullPointerExceptionを回避
		ua = ValueUtil.nullToStr(ua);
		
		// UA前方一致のデータ取得
		List termList = this.termList;

		for (int i = 0; i < termList.size(); i++) {
			Map element = (Map) termList.get(i);

			if (ua.startsWith((String) element.get("ident_string"))) {
			    termMap = element;
			    break;
			}
		}

        // termMapは必ずデータは返しています。PCがデフォルトにしているため
        // PCの場合Term_mst_v2へもう一回検索します、データがあれば新Mapデータ返します、なければデフォルトtermMapを返します
        String carrier = ValueUtil.nullToStr(termMap.get("carrier"));
        if (carrier.equals(TermMstDb.TYPE_PC_BROWSER)) {
            Map element = getTermInfoPartial(ua);
            if (element != null) {
                termMap = element;
            }
        }
        log.debug("termMap:"+termMap);
        return termMap;
	}

    /**
     * @param ua
     * @return
     */
    private Map getTermInfoPartial(String ua) {
        // UA部分一致のデータ取得
        List<Map<String, Object>> termMapList = this.termMapList;

        for (int i = 0; i < termMapList.size(); i++) {
            Map element = termMapList.get(i);

            if (ua.indexOf(ValueUtil.nullToStr(element.get("ident_string"))) != -1) {
                return element;
            }
        }
        return null;
    }

	/**
	 * uaを元に端末IDを返す。<br>
	 * 不明な端末のUAの場合は、TermMstDb.UNKNOWN_TERM_IDが返る。
	 * 
	 * @param ua
	 * @return
	 */
	public int getTermId(String ua) {
		Map termInfo = getTermInfo(ua);
		return termInfo == null ? UNKNOWN_TERM_ID : ((Integer) termInfo
				.get("term_id")).intValue();
	}

	/**
	 * キャリアを返す。
	 * 
	 * @param ua
	 * @return
	 */
	public static String getCarrier(String ua) {
		Map termInfo = TermMstDb.getInstance().getTermInfo(ua);
		return (String) termInfo.get("carrier");
	}

	/**
	 * 端末種別を返す。
	 * 
	 * @param ua
	 * @return
	 */
	public static String getTermType(String ua) {
		Map termInfo = TermMstDb.getInstance().getTermInfo(ua);
		return (String) termInfo.get("term_type");
	}

	/**
	 * モバイルかどうかを判定する。
	 * 
	 * @param ua
	 * @return
	 */
	public static boolean isMobileUa(String ua) {
		String carrier = getCarrier(ua);
		return isMobileCarrier(carrier);
	}

	/**
	 * モバイルかどうかを判定する。
	 * 
	 * @param carrier
	 * @return
	 */
	public static boolean isMobileCarrier(String carrier) {

		boolean isMobile;
		if (carrier.equals(TermMstDb.TYPE_DOCOMO)
				|| carrier.equals(TermMstDb.TYPE_AU)
				|| carrier.equals(TermMstDb.TYPE_SOFTBANK)) {
			isMobile = true;
		} else {
			isMobile = false;
		}

		return isMobile;

	}

}
