/**
 * 
 */
package jp.co.webcrew.login.common.db.step;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;

/**
 * <pre>
 * 空っぽのユーザ情報を意味するクラス。
 * 
 * stepサイトでの登録ユーザ情報が無い（もしくは取得できない）場合に使用する。 
 * 
 * </pre>
 * @author Takahashi
 *
 */
public class EmptyUserInfo implements StepUserInfo {

    /** HttpRequest */
    private HttpServletRequest _request;
    
    /** 会員情報（MEMBER_MST テーブル） */
    private MemberMst _member;
    
    /** サイトID */
    private String _siteId;
    
    /** stepの user_id */
    private String _userId;
    
    /** stepの order_id (request_id) */
    private String _requestId;
    
    /** 都道府県コード */
    private String _prefId;
    
    /** 性別 */
    private String _sexId;
    
    /** 誕生日 YYYY-MM-DD */
    private String _birthDate; 

    /** 郵便番号 */
    private String _zip;

    /**
     * コンストラクタ
     * @param request
     * @param siteId
     */
    public EmptyUserInfo(HttpServletRequest request , String siteId) {
        _request = request;
        _siteId  = siteId;
    }
    
    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#getGuid()
     */
    public String getGuid() {
        // stepに何の情報も無いのでnull
        return null;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.util.db.step.StepUserInfo#isMobileAccess()
     */
    public final boolean isMobileAccess(){
        return SessionFilterAlterUtil.fromMobile(getHttpRequest());
    }
    
    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#getEmail()
     */
    public String getEmail() {
        return getMember().getPrimaryEmail();
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#isCorporateService()
     */
    public boolean isCorporateService() {
        return false;
    }

    /**
     * @return member
     */
    public MemberMst getMember() {
        if (_member == null) {
            _member = new MemberMst();
        }
        return _member;
    }

    /**
     * @param member 設定する member
     */
    public void setMember(MemberMst member) {
        _member = member;
    }
    
    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#doLoad(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String, java.lang.String)
     */
    public boolean doLoad(DBAccess db , String orderId , String userId) throws SQLException {
        return true;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#getOrderIDs(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
     */
    public String[]  getOrderIDs(DBAccess db , String guid) {
        return null;
    }

    /**
     * @return requestId
     */
    public String getRequestId() {
        return _requestId;
    }

    /**
     * @param requestId 設定する requestId
     */
    public void setRequestId(String requestId) {
        _requestId = requestId;
    }

    /**
     * @return siteId
     */
    public String getSiteId() {
        return _siteId;
    }

    /**
     * @param siteId 設定する siteId
     */
    public void setSiteId(String siteId) {
        _siteId = siteId;
    }

    /**
     * @return userId
     */
    public String getUserId() {
        return _userId;
    }

    /**
     * @param userId 設定する userId
     */
    public void setUserId(String userId) {
        _userId = userId;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#getLastUpdate()
     */
    public String getLastUpdate(){
        //TODO
        return null;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#getMagEmail()
     */
    public String getMagEmail(){
        return getMember().getPrimaryEmail();
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#getMagFlag()
     */
    public String getMagFlag(){
        return MemberMst.FLG_MAG_FLAG_OFF;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#doPopulateFromMemberMst(jp.co.webcrew.login.common.db.MemberMst)
     */
    public void doPopulateFromMemberMst(MemberMst member) {
        /** step_loginのログインは行わないはずなので、ここの実装は不要のはず */
        setMember(member);
        return;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#doPrepareStepDatabase(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String, java.lang.String)
     */
    public void doPrepareStepDatabase(DBAccess db , String guid , String gsid) throws SQLException {
        // 何もしない
        return;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#doDeleteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
     */
    public void doDeleteGuid(DBAccess db , String guid) throws SQLException {
        // 何もしない
        return ;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#doIsDifferentFromMemberMst(jp.co.webcrew.login.common.db.MemberMst)
     */
    public boolean doIsDifferentFromMemberMst(MemberMst member){
        // 前のデータが無いので、何も変わらない
        return false;
    }
    
    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#doOverWriteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
     */
    public boolean doOverWriteGuid(DBAccess db , String guid){
        // 何もしない
        return true;
    }


    /**
     * @return prefId
     */
    public String getPrefId() {
        return _prefId;
    }

    /**
     * @param prefId 設定する prefId
     */
    public void setPrefId(String prefId) {
        _prefId = prefId;
    }

    /**
     * @return sexId
     */
    public String getSexId() {
        return _sexId;
    }

    /**
     * @param sexId 設定する sexId
     */
    public void setSexId(String sexId) {
        _sexId = sexId;
    }

    /**
     * @return zip
     */
    public String getZip() {
        return _zip;
    }

    /**
     * @param zip 設定する zip
     */
    public void setZip(String zip) {
        _zip = zip;
    }


    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#doPopulateToMemberMst(jp.co.webcrew.login.common.db.MemberMst)
     */
    public void doPopulateToMemberMst(MemberMst member){
        // step情報を会員情報に書き込む。
        // step情報は何も無いので、何もしない。
        
        // 現状のjspが、stepUserInfo の方にリクエストデータを書き込んでいるため、一部のデータをコピーする
        //TODO jspのパラメータ名などを変更
        
        member.setTrimData(MemberMst.ZIP      , getZip());
        member.setTrimData(MemberMst.PREF_ID  , getPrefId());
        member.setTrimData(MemberMst.BIRTHDAY , charBirthDate()); //YYYYMMDDに変換
        member.setTrimData(MemberMst.SEX_ID   , getSexId());
        
    }

    /**
     * 誕生日をYYYYMMDD形式の文字列で取得する
     * @return String 誕生日 YYYYMMDD
     */
    private String charBirthDate(){
        return getBirthYear() + getBirthMonth() + getBirthDay();        
    }
    
    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#doPopulateToOrderHist(jp.co.webcrew.login.common.db.OrderHist)
     */
    public void doPopulateToOrderHist(OrderHist order) {
        // 履歴が無いことを明示する
        order = null;
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#setBirthDate(java.lang.String, java.lang.String, java.lang.String)
     */
    public void setBirthDate(String year , String month , String day){
        _birthDate = DateUtil.toDbDateStr(year , month , day);
    }

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.step.StepUserInfo#getBirthDate()
     */
    public String getBirthDate() {
        return _birthDate;
    }

    /**
     * 生年を返す
     */
    public String getBirthYear() {
        String ret = getBirthDate();
        if (ret == null || ret.equals("")){
            ret = "";
        } else if (ret.length() < 10){
            ret = "";
        } else {
            ret = ret.substring(0,4);
        }
        return ret;
    }
    
    
    /**
     * 生月を返す
     */
    public String getBirthMonth() {
        String ret = getBirthDate();
        if (ret == null || ret.equals("")){
            ret = "";
        } else if (ret.length() < 10){
            ret = "";
        } else {
            ret = ret.substring(5,7);
        }
        return ret;
    }       
    
    /**
     * 生日を返す
     */
    public String getBirthDay(){
        String ret = getBirthDate();
        if (ret == null || ret.equals("")){
            ret = "";
        } else if (ret.length() < 10){
            ret = "";
        } else {
            ret = ret.substring(8,10);
        }
        return ret;     
    }

    /**
     * <pre>
     * HttpRequestを返す
     * </pre>
     * @return
     */
    public HttpServletRequest getHttpRequest() {
        return _request;
    }
    

}
