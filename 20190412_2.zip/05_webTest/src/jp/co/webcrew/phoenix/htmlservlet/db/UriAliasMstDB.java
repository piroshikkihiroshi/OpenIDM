package jp.co.webcrew.phoenix.htmlservlet.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.htmlservlet.UriAliasMstBean;
import jp.co.webcrew.phoenix.htmlservlet.UriAliasPathNameNotAvailableException;

public class UriAliasMstDB extends RefreshMstDb
{
	private static final Logger logger=Logger.getLogger(UriAliasMstDB.class);
	private static UriAliasMstDB thisClassObject=new UriAliasMstDB();
	
	public static UriAliasMstDB getInstance()
	{
		return thisClassObject;
	}
	
	private RootEntry rootEntry=null;
	
	
	@Override
	public void init() throws SQLException 
	{
		/***
		 * データ取得sql
		 * 無効フラグがオフのデータのみ取得
		 * alias_uriの逆順（large to small）でソート
		 */
		String sql="select site_id,alias_uri,path_name,getvar_name,getvar_default_value,suffix,split_word from phoenix.uri_alias_mst " +
				" where invalid_flag=0 order by alias_uri desc";
		ResultSet rset=null;
		
		DBAccess db=null;
		
		logger.info("UriAliasMstDB.init()");
		
		try
		{
			Map<Integer,List<UriAliasMstBean>> localMapCacheBean=new HashMap<Integer, List<UriAliasMstBean>>();
			Map<Integer,List<String>> localMapCacheMirrorPath=new HashMap<Integer, List<String>>();
			
			//TODO とりあえずphoenixで接続
			db=new DBAccess("phoenix");
			
			
			db.prepareStatement(sql);
			rset=db.executeQuery();
			
			final String INDEX_HTML="/index.html";
			final String INDEX_HTM="/index.htm";
			final int LEN_INDEX_HTML=INDEX_HTML.length()-1;
			final int LEN_INDEX_HTM=INDEX_HTM.length()-1;
			
			
			while(rset.next())
			{
				UriAliasMstBean bean=new UriAliasMstBean();
				bean.siteId=rset.getInt("site_id");
				bean.aliasUri=rset.getString("alias_uri");
				bean.pathName=rset.getString("path_name");
				bean.getVarName=ValueUtil.nullToStr(rset.getString("getvar_name"));
				bean.getVarDefaultValue=ValueUtil.nullToStr(rset.getString("getvar_default_value"));
				bean.suffix=ValueUtil.nullToStr(rset.getString("suffix"));
				bean.splitWord=ValueUtil.nullToStr(rset.getString("split_word"));
				
				List<UriAliasMstBean> listBean=localMapCacheBean.get(bean.siteId);
				List<String> listMirrorPath=localMapCacheMirrorPath.get(bean.siteId);
				
				if(listBean==null)
				{
					listBean=new ArrayList<UriAliasMstBean>();
					localMapCacheBean.put(bean.siteId, listBean);
					listMirrorPath=new ArrayList<String>();
					localMapCacheMirrorPath.put(bean.siteId, listMirrorPath);
				}
				
				listBean.add(bean);
				listMirrorPath.add(bean.pathName);
				//末尾が「/index.html」の場合、この部分を除外したパス(但し、末尾のスラッシュは有効)をミラーコンテンツページとして登録
				if(bean.pathName.endsWith(INDEX_HTML))
				{
					listMirrorPath.add(bean.pathName.substring(0,bean.pathName.length()-LEN_INDEX_HTML));
				}
				//末尾が「/index.htm」の場合、この部分を除外したパス(但し、末尾のスラッシュは有効)をミラーコンテンツページとして登録
				else if(bean.pathName.endsWith(INDEX_HTM))
				{
					listMirrorPath.add(bean.pathName.substring(0,bean.pathName.length()-LEN_INDEX_HTM));
				}
				
				
			}
			
			RootEntry localRootEntry=new RootEntry();
			localRootEntry.mapCacheBean=localMapCacheBean;
			localRootEntry.mapCacheMirrorPath=localMapCacheMirrorPath;
			
			//すべての処理が完了してからインスタンス変数の内容を置き換える
			this.rootEntry=localRootEntry;
			
		}
		catch(Exception exc)
		{
			logger.error("UriAliasMstの取得処理に関連したエラーです。",exc);
		}
		finally
		{
			DBAccess.close(rset);
			DBAccess.close(db);
		}
		
	}
	
	/****
	 * URL擬似静的化対応のロジック
	 * バージョン管理が煩雑なので、一旦マージ
	 * 
	 * @param db
	 * @param request
	 * @param siteId
	 * @param requestUri
	 * @return
	 */
	public UriAliasMstBean getUriAliasMstBean(HttpServletRequest request,int siteId,String requestUri)
	throws UriAliasPathNameNotAvailableException
	{
		RootEntry localRootEntry=this.rootEntry;
		
		List<UriAliasMstBean> list=localRootEntry.mapCacheBean.get(siteId);
		
		//サイト(ID)にひもづくalias定義が一件もない場合はNULL
		if(list==null || list.size()==0)
		{
			return null;
		}
		
		
		//TODO サイトレベルで有効無効の判別をする？となるとキャッシュすべきおよび管理テーブルも増やす必要あり
		
		
		//サイト内の全別名定義をループ
		for(UriAliasMstBean aBean:list)
		{
			if(requestUri.startsWith(aBean.aliasUri))
			{
				//TODO スラッシュ終わりはこれで対応できるのか？？
				if(aBean.suffix.length()==0)
				{
					return aBean;
				}
				else if(requestUri.endsWith(aBean.suffix))
				{
					return aBean;
				}
			}
		}
		
		List<String> listMirrorPath=localRootEntry.mapCacheMirrorPath.get(siteId);
		
		for(String pathName:listMirrorPath)
		{
			if(requestUri.equals(pathName))
			{
				logger.warn("このpathNameは別名として既に登録済みです。[siteid]"+siteId+"[path]"+pathName);
				throw new UriAliasPathNameNotAvailableException();
			}
		}
		
		
		//見つからない場合はNULLを返す
		return null;
	}
	
	
	
	/*
	public UriAliasMstBean getUriAliasMstBean(HttpServletRequest request,int siteId,String requestUri)
	{
		//TODO キャッシュ最適化は必要か？
		String sql="select alias_uri,path_name,getvar_name from phoenix.uri_alias_mst where site_id=? and ? like alias_uri || '%' order by alias_uri desc";
		ResultSet rset=null;
		
		final String EXT_HTML=".html";
		final int EXT_HTML_LENGTH=EXT_HTML.length();
		
		DBAccess db=null;
		
		try
		{
			db=new DBAccess();
			
			
			//System.out.println("[replace]"+sql+"\r\n[siteid]"+siteId+"[uri]"+requestUri);
			HtmlServletLogger.info("[replace]"+sql+"\r\n[siteid]"+siteId+"[uri]"+requestUri);
			db.prepareStatement(sql);
			db.setInt(1, siteId);
			//db.setString(2, requestUri+"%");
			db.setString(2, requestUri);
			rset=db.executeQuery();
			
			if(!rset.next())return null;
			
			String aliasUri=rset.getString("alias_uri");
			
			String unmatchedWord=requestUri.substring(aliasUri.length());
			
			
			
			
			if(unmatchedWord.endsWith(EXT_HTML))
			{
				int length=unmatchedWord.length()-EXT_HTML_LENGTH;
				if(length<=0)
				{
					unmatchedWord="";
				}
				else
				{
					unmatchedWord=unmatchedWord.substring(0,length);
				}
			}
			
			
			String[] unmatchedArray=unmatchedWord.split("/");
			
			String pathName=rset.getString("path_name");
			String varName=rset.getString("getvar_name");
			if(varName!=null && unmatchedArray.length!=0)
			{
				request.setAttribute("replace_getvar", new String[]{varName,unmatchedArray[0]});
			}
			else
			{
				request.removeAttribute("replace_getvar");
			}
			request.setAttribute("replace_path_array", unmatchedArray);
			request.setAttribute("replace_path_all", unmatchedWord);
			
			
			return pathName;
			
		}
		catch(Exception exc)
		{
			HtmlServletLogger.error("uri_aliasの処理でエラーを検知しました。/"+exc.getMessage(),exc);
			throw new RuntimeException(exc);
		}
		finally
		{
			DBAccess.close(rset);
			DBAccess.close(db);
		}
		
	}
	*/
	
	
	private static class RootEntry
	{
		/***
		 * 
		 * キー：サイトID
		 * 値：Beanオブジェクトの一覧（AliasUriのLarge To Small）
		 */
		Map<Integer,List<UriAliasMstBean>> mapCacheBean=null;
		Map<Integer,List<String>> mapCacheMirrorPath=null;
	}
	
	public static void main(String[] args) 
	{
		StringTokenizer st = new StringTokenizer("this///@/is/a//test","/@",true);
		//st.
	     while (st.hasMoreTokens()) {
	         System.out.println("["+st.nextToken()+"]");
	     }		
		
		
	}
	
}
