package jp.co.webcrew.filters.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;

/**
 * HTTPヘッダのcontentTypeを指定したタイプで再設定するフィルター。
 * 
 * param : contentType - 設定するコンテンツタイプ
 * 
 * @author katsuno
 */
public class SetContentTypeFilter implements Filter {
	
	/** モバイル用のコンテンツタイプ */
	private String contentType 	= "text/html";
	private String uriPattern	= null;

	/** ロガー */
	private static final Logger log = Logger.getLogger(SetContentTypeFilter.class);
	
	public void init(FilterConfig filterConfig) throws ServletException {
		log.info("init SetContentTypeFilter start.");

		try {
			// 携帯用のContentTypeを設定する。
			String contentType = filterConfig.getInitParameter("contentType");
			if (contentType != null) {
				this.contentType = contentType;
			}
			
			String uriPattern = filterConfig.getInitParameter("uriPattern");
			if (uriPattern != null) {
				this.uriPattern = uriPattern;
			}
			
			log.info("setting contentType : " + this.contentType);

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			throw new ServletException(e);
		}

		log.info("init SetContentTypeFilter end.");
	}
	
	public void destroy() {
		// 処理なし

	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		log.info("doFilter SetContentTypeFilter start.");
		
		chain.doFilter(request, response);
		
		if (uriPattern == null || "".equals(uriPattern)) {
			response.setContentType(contentType);
		} 
		else 
		{
			HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			if (httpServletRequest.getRequestURI() != null &&
					httpServletRequest.getRequestURI().indexOf(uriPattern) != -1)
			{
				response.setContentType(contentType);
			}	
		}
		log.info("doFilter SetContentTypeFilter end.");
	}
}
