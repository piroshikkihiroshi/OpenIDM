package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.sstag.bean.PromoDisplayBean;

public class PromoDisplayExecuter extends SSTagExecuter
{

	/** ロガー */
	private static final Logger	log	= Logger.getLogger(PromoDisplayExecuter.class);

	/**
	 * 取得したHTMLコンテンツをリターン
	 * 
	 * @param mapParameters
	 *            SSTAGパラメータ
	 * @param request
	 * @param response
	 * @return strHTML HTMLコンテンツ
	 */
	public String execute(Map mapParameters, HttpServletRequest request, HttpServletResponse response)
	{
		log.info("はいりました。");
		// サイトID
		String strSiteId = ValueUtil.nullToStr(mapParameters.get("siteid"));
		if ("".equals(strSiteId))
		{
			return "";
		}
		log.info("サイトID = " + strSiteId);

		// プロモID
		String strPromoId = ValueUtil.nullToStr(mapParameters.get("promoid"));
		if ("".equals(strPromoId))
		{
			return "";
		}
		log.info("プロモID = " + strPromoId);

		// コンテンツ番号
		String strContentsID = ValueUtil.nullToStr(mapParameters.get("contentsid"));
		if ("".equals(strContentsID))
		{
			return "";
		}
		log.info("表示コンテンツ番号 = " + strContentsID);

		// コンテンツ番号
		String strVariables = ValueUtil.nullToStr(mapParameters.get("variables"));
		
		log.info("変数（カンマ区切り） = " + strVariables);

		String[] arrVariables = strVariables.split(",");

		int nContentsID = ValueUtil.toint((String) strContentsID);

		// HTMLコンテンツ
		String strHTML = "";

		try
		{
			// HTML表示コンテンツを取得する
			List<PromoDisplayBean> lstPromoDisplayBean = PromDisplayRefreshMst.getHTMLAllList();
			for (PromoDisplayBean objPromoDisplayBean : lstPromoDisplayBean)
			{

				int nSiteIDBean = objPromoDisplayBean.getnSiteID();
				String strPromoIdBean = objPromoDisplayBean.getStrPromoCode();

				if (nSiteIDBean == Integer.parseInt(strSiteId) && strPromoIdBean.equals(strPromoId))
				{
					switch (nContentsID)
					{
						case 1:
							strHTML = objPromoDisplayBean.getStrHTML1();
							break;
						case 2:
							strHTML = objPromoDisplayBean.getStrHTML2();
							break;
						case 3:
							strHTML = objPromoDisplayBean.getStrHTML3();
							break;
						case 4:
							strHTML = objPromoDisplayBean.getStrHTML4();
							break;
						case 5:
							strHTML = objPromoDisplayBean.getStrHTML5();
							break;
						case 6:
							strHTML = objPromoDisplayBean.getStrHTML6();
							break;
						case 7:
							strHTML = objPromoDisplayBean.getStrHTML7();
							break;
						case 8:
							strHTML = objPromoDisplayBean.getStrHTML8();
							break;
						case 9:
							strHTML = objPromoDisplayBean.getStrHTML9();
							break;
						case 10:
							strHTML = objPromoDisplayBean.getStrHTML10();
							break;
						case 11:
							strHTML = objPromoDisplayBean.getStrHTML11();
							break;
						case 12:
							strHTML = objPromoDisplayBean.getStrHTML12();
							break;
						case 13:
							strHTML = objPromoDisplayBean.getStrHTML13();
							break;
						case 14:
							strHTML = objPromoDisplayBean.getStrHTML14();
							break;
						case 15:
							strHTML = objPromoDisplayBean.getStrHTML15();
							break;
						case 16:
							strHTML = objPromoDisplayBean.getStrHTML16();
							break;
						case 17:
							strHTML = objPromoDisplayBean.getStrHTML17();
							break;
						case 18:
							strHTML = objPromoDisplayBean.getStrHTML18();
							break;
						case 19:
							strHTML = objPromoDisplayBean.getStrHTML19();
							break;
						case 20:
							strHTML = objPromoDisplayBean.getStrHTML20();
							break;	
					}
					// 見つから場合ＨＴＭＬを返しする。
					if (strHTML != null && strHTML.length() != 0)
					{
						return replaceConstants(strHTML, arrVariables);
					}
				}
			}

			// 見つからない場合はデフォルトＨＴＭＬを返しする。
			for (PromoDisplayBean objPromoDisplayBean : lstPromoDisplayBean)
			{
				int nSiteIDBean = objPromoDisplayBean.getnSiteID();
				String strPromoIdBean = objPromoDisplayBean.getStrPromoCode();

				if (nSiteIDBean == Integer.parseInt(strSiteId) && strPromoIdBean.equals("default"))
				{
					switch (nContentsID)
					{
						case 1:
							strHTML = objPromoDisplayBean.getStrHTML1();
							break;
						case 2:
							strHTML = objPromoDisplayBean.getStrHTML2();
							break;
						case 3:
							strHTML = objPromoDisplayBean.getStrHTML3();
							break;
						case 4:
							strHTML = objPromoDisplayBean.getStrHTML4();
							break;
						case 5:
							strHTML = objPromoDisplayBean.getStrHTML5();
							break;
						case 6:
							strHTML = objPromoDisplayBean.getStrHTML6();
							break;
						case 7:
							strHTML = objPromoDisplayBean.getStrHTML7();
							break;
						case 8:
							strHTML = objPromoDisplayBean.getStrHTML8();
							break;
						case 9:
							strHTML = objPromoDisplayBean.getStrHTML9();
							break;
						case 10:
							strHTML = objPromoDisplayBean.getStrHTML10();
							break;
						case 11:
							strHTML = objPromoDisplayBean.getStrHTML11();
							break;
						case 12:
							strHTML = objPromoDisplayBean.getStrHTML12();
							break;
						case 13:
							strHTML = objPromoDisplayBean.getStrHTML13();
							break;
						case 14:
							strHTML = objPromoDisplayBean.getStrHTML14();
							break;
						case 15:
							strHTML = objPromoDisplayBean.getStrHTML15();
							break;
						case 16:
							strHTML = objPromoDisplayBean.getStrHTML16();
							break;
						case 17:
							strHTML = objPromoDisplayBean.getStrHTML17();
							break;
						case 18:
							strHTML = objPromoDisplayBean.getStrHTML18();
							break;
						case 19:
							strHTML = objPromoDisplayBean.getStrHTML19();
							break;
						case 20:
							strHTML = objPromoDisplayBean.getStrHTML20();
							break;
					}
					if(strHTML != null && strHTML.length() != 0){
						return replaceConstants(strHTML, arrVariables);
					}
				}
			}

			return "";
		}
		catch (Exception objExp)
		{
			log.error("予期せぬエラー", objExp);
		}
		return "";
	}

	/**
	 * HTML内の###n###（Nは数字）を置換する。
	 * 
	 * @param content
	 *            HTML本文
	 * @param arrVariables
	 *            変数（カンマ区切り）
	 * @return HTML内
	 */
	public String replaceConstants(String strContents, String[] arrVariables) throws Exception
	{
		if (arrVariables.length > 0)
		{
			log.info("arrVariablesサイズ＝" + arrVariables.length);
			for (int i = 0; i < arrVariables.length; i++)
			{
				if (arrVariables[i].length() > 0)
				{
					String key = "###" + (i + 1) + "###";
					Pattern pattern = Pattern.compile(key);
					Matcher matcher = pattern.matcher(strContents);
					strContents = matcher.replaceAll(arrVariables[i]);
				}
			}
		}
		log.info("HTMLコンテンツ = " + strContents);
		return strContents;
	}
}
