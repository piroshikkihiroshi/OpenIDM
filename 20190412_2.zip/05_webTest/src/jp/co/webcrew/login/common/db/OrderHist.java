package jp.co.webcrew.login.common.db;

import java.io.Serializable;
import java.sql.SQLException;
import java.sql.Timestamp;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.step.SateiOmakaseUserInfo;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.point.ContractPointUtil;
import jp.co.webcrew.login.common.util.DateUtil;

/**
 * ORDER_HIST テーブルを扱うクラス
 * 
 * @author Takahashi
 * 
 */
public class OrderHist extends DBEntity implements Serializable {

    /** ロガー */
    private static final Logger log = Logger.getLogger(OrderHist.class);

    public static final String TABLE = "ORDER_HIST";

    // 事後登録：1
    public static final String POST_REGIST_FLAG_YES = "1";

    public static final String TYPE_SHIRYO_SEIKYU = "1";
    public static final String TYPE_MITSUMORI_IRAI = "2";

    public static final String TYPE_SHIRYO_SEIKYU_STR = "資料請求";
    public static final String TYPE_MITSUMORI_IRAI_STR = "見積り依頼";

    /** 悪質ユーザー */
    public static final String FLG_BAD_USER_ON = "1";
    /** 悪質ユーザーではない */
    public static final String FLG_BAD_USER_OFF = "0";

    /** 成約フラグ 成約 */
    public static final String FLG_CONTRACT_FLAG_ON = "1";
    /** 成約フラグ 未成約 */
    public static final String FLG_CONTRACT_FLAG_OFF = "0";

    /***
     * 成約ステータス・対象外
     */
    public static final int STATUS_0_OUT = 0;
    public static final String STATUS_0_OUT_NAME;
    /***
     * 成約ステータス・回答待
     */
    public static final int STATUS_1_ANSWER_WAIT = 1;
    public static final String STATUS_1_ANSWER_WAIT_NAME;
    /***
     * 成約ステータス・申請待
     */
    public static final int STATUS_2_APPLICATION_WAIT = 2;
    public static final String STATUS_2_APPLICATION_WAIT_NAME;
    /***
     * 成約ステータス・確認中
     */
    public static final int STATUS_3_CONFIRM = 3;
    public static final String STATUS_3_CONFIRM_NAME;
    /***
     * 成約ステータス・ポイント付与済
     */
    public static final int STATUS_4_COMPLETE = 4;
    public static final String STATUS_4_COMPLETE_NAME;
    /***
     * 成約ステータス・ポイント付与拒否
     */
    public static final int STATUS_5_REJECT = 5;
    public static final String STATUS_5_REJECT_NAME;
    /***
     * 成約ステータス・取消
     */
    public static final int STATUS_6_CANCEL = 6;
    public static final String STATUS_6_CANCEL_NAME;
    
    /***
     * 成約ステータス・成約せず
     */
    public static final int STATUS_90_NO_CONTRACT = 90;
    public static final String STATUS_90_NO_CONTRACT_NAME;
    /***
     * 成約ステータス・有効期限切れ
     */
    public static final int STATUS_91_EXPIRED = 91;
    public static final String STATUS_91_EXPIRED_NAME;
    static
    {
        /***
         * 成約ステータス・対象外
         */
        STATUS_0_OUT_NAME = "対象外";
        /***
         * 成約ステータス・回答待
         */
        STATUS_1_ANSWER_WAIT_NAME = "回答待";
        /***
         * 成約ステータス・申請待
         */
        STATUS_2_APPLICATION_WAIT_NAME = "未申請";
        /***
         * 成約ステータス・確認中
         */
        STATUS_3_CONFIRM_NAME = "確認中";
        /***
         * 成約ステータス・ポイント付与済
         */
        STATUS_4_COMPLETE_NAME = "付与";
        /***
         * 成約ステータス・ポイント付与拒否
         */
        STATUS_5_REJECT_NAME = "無効";
        /***
         * 成約ステータス・取消
         */
        STATUS_6_CANCEL_NAME = "無効";

        /***
         * 成約ステータス・成約せず
         */
        STATUS_90_NO_CONTRACT_NAME = "未契約";
        /***
         * 成約ステータス・有効期限切れ
         */
        STATUS_91_EXPIRED_NAME = "期限切れ";
    }
    
    /*
     * 列名定義
     */
    public static final String GUID = "GUID";
    public static final String ORDER_DATETIME = "ORDER_DATETIME";
    public static final String ORDER_ID = "ORDER_ID";
    public static final String ORDER_TYPE = "ORDER_TYPE";
    public static final String SITE_ID = "SITE_ID";
    public static final String ORDER_TEXT = "ORDER_TEXT";
    public static final String SUPPLIER_TEXT = "SUPPLIER_TEXT";
    // マイページのメニュー画面で最近利用した履歴を展開するかどうかフラグ、デフォルト（展開する）：null　ユーザーが展開されない：1　ユーザーが展開再する：2
    public static final String RECENT_DISP_FLAG = "RECENT_DISP_FLAG";
    // 利用履歴事後登録フラグ、デフォルト：null　事後登録：1
    public static final String POST_REGIST_FLAG = "POST_REGIST_FLAG";
    public static final String ORDER_MEMO = "ORDER_MEMO";
    /** 成約サイトID */
    public static final String CONTRACT_SITE_ID = "CONTRACT_SITE_ID";
    /** 成約ポイント番号 */
    public static final String CONTRACT_POINT_NO = "CONTRACT_POINT_NO";
    /** 成約ポイント数 */
    public static final String CONTRACT_POINT = "CONTRACT_POINT";
    /** 成約ポイント申請期限 */
    public static final String CONTRACT_LIMIT_DATE = "CONTRACT_LIMIT_DATE";
    /** 成約ステータス */
    public static final String CONTRACT_STATUS = "CONTRACT_STATUS";
    /** 成約フラグ(1:成約、0:未成約) */
    public static final String CONTRACT_FLAG = "CONTRACT_FLAG";
    /** 成約会社ID(カンマ区切り) */
    public static final String CONTRACT_COMPANY_ID = "CONTRACT_COMPANY_ID";
    /** 成約会社名(カンマ区切) */
    public static final String CONTRACT_COMPANY_NAME = "CONTRACT_COMPANY_NAME";
    /** 成約ステータス更新日時 */
    public static final String STATUS_UP_DATETIME = "STATUS_UP_DATETIME";
    /** 非承認理由 */
    public static final String REJECT_REASON = "REJECT_REASON";
    /** 悪質ユーザーフラグ(0:非悪質、1:悪質) */
    public static final String BAD_USER_FLAG = "BAD_USER_FLAG";
    /** ポイント付与履歴ID */
    public static final String POINT_CHARGE_ID = "POINT_CHARGE_ID";

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
     */
    public void init() {
        setTable(TABLE);
    }

    /**
     * コンストラクタ
     */
    public OrderHist() {
        super();
    }

    /**
     * コンストラクタ
     * 
     * @param guid
     */
    public OrderHist(String guid) {
        super();
        setGuid(guid);
    }

    public void setGuid(String val) {
        set(GUID, val);
    }

    public final String getGUID() {
        return get(GUID);
    }

    public String getOrderTypeStr() {
        String type = get(ORDER_TYPE);
        if (type == null || type.equals("")) {
            return "";
        }

        if (type.equals(TYPE_SHIRYO_SEIKYU)) {
            return TYPE_SHIRYO_SEIKYU_STR;
        }

        if (type.equals(TYPE_MITSUMORI_IRAI)) {
            return TYPE_MITSUMORI_IRAI_STR;
        }

        return "";
    }

    /**
     * 成約ステータス
     * 
     * @return
     */
    public int getContractStatus() {
        return ValueUtil.toint(get(CONTRACT_STATUS));
    }

    /**
     * ステータス名を返す
     * 
     * @return
     */
    public String getContractStatusName() {
        return getContractStatusName(getContractStatus());
    }

    /**
     * <pre>
     * 有効期限切れかどうか 
     * 期限切れたらDBのステータスも更新します
     * </pre>
     * 
     * @return
     */
    public boolean isExpired() {
        DBAccess db = null;
        try {
            db = new DBAccess();
            return ContractPointUtil.isExpired(db, this);

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            DBAccess.close(db);
        }
    }

    /**
     * ステータス名を返す
     * 
     * @return
     */
    public static String getContractStatusName(int status) {
        if (status == STATUS_0_OUT) {
            return STATUS_0_OUT_NAME;
        } else if (status == STATUS_1_ANSWER_WAIT) {
            return STATUS_1_ANSWER_WAIT_NAME;
        } else if (status == STATUS_2_APPLICATION_WAIT) {
            return STATUS_2_APPLICATION_WAIT_NAME;
        } else if (status == STATUS_3_CONFIRM) {
            return STATUS_3_CONFIRM_NAME;
        } else if (status == STATUS_4_COMPLETE) {
            return STATUS_4_COMPLETE_NAME;
        } else if (status == STATUS_5_REJECT) {
            return STATUS_5_REJECT_NAME;
        } else if (status == STATUS_6_CANCEL) {
            return STATUS_6_CANCEL_NAME;
        } else if (status == STATUS_90_NO_CONTRACT) {
            return STATUS_90_NO_CONTRACT_NAME;
        } else if (status == STATUS_91_EXPIRED) {
            return STATUS_91_EXPIRED_NAME;
        }
        return STATUS_0_OUT_NAME;
    }

    /**
     * 成約ポイント数
     * 
     * @return
     */
    public long getContractPoint() {
        return ValueUtil.tolong(get(CONTRACT_POINT));
    }

    /**
     * <pre>
     * 
     * ORDER_HISTテーブルの一行データを取得する。
     * 
     * ORDER_HISTを返す。
     * 
     * null : エラー
     * null : 処理中止（引数がNULLの場合など）
     * OrderHist : 成功
     * 
     * </pre>
     * 
     * @param siteId
     * @param orderId
     * @return boo
     */
    public boolean load(String siteId, String orderId) {

        DBAccess db = null;

        try {

            db = new DBAccess();
            return load(db, siteId, orderId);

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function OrderHist#load", e);
            return false;
        } finally {
            DBAccess.close(db);
        }
    }

    /**
     * <pre>
     * 
     * ORDER_HISTテーブルの一行データを取得する。
     * 
     * ORDER_HISTを返す。
     * 
     * null : エラー
     * null : 処理中止（引数がNULLの場合など）
     * OrderHist : 成功
     * 
     * </pre>
     * 
     * @param db
     * @param siteId
     * @param orderId
     * @return boo
     */
    public boolean load(DBAccess db, String siteId, String orderId) {

        // パラメータチェック
        if (db == null || siteId == null || orderId == null) {
            return false;
        }
        if (siteId.length() == 0 || orderId.length() == 0) {
            return false;
        }

        try {

            // 検索SQL文を作成する
            StringBuffer sqlBuf = new StringBuffer();
            sqlBuf.append("SELECT ").append(TABLE).append(".* FROM ").append(TABLE);
            sqlBuf.append(" WHERE ").append(SITE_ID).append(" = '").append(siteId).append("'");
            sqlBuf.append(" AND ").append(ORDER_ID).append(" = '").append(orderId).append("'");

            // PreparedStatementを作成する
            db.prepareStatement(sqlBuf.toString());

            // 最初のレコードを取得する
            Record rec = Record.getFirstRowOf(db);
            if (rec == null) {
                log.warn(TABLE + "の情報を読み込めませんでした。siteId:" + siteId + " orderId:" + orderId);
                return false;
            } else {
                super.setRecord(rec);
                return true;
            }

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function OrderHist#load", e);
            return false;
        }

    }

    /**
     * <pre>
     * 
     * ORDER_HISTテーブルに一行作成する。
     * 
     * 作成した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param order
     * @return
     */
    public static int insertToDB(DBAccess db, OrderHist order) {

        if (db == null) {
            return -1;
        }

        if (order == null) {
            return -1;
        }

        try {

            // 成約ステータスと悪質ユーザーフラグを登録追加する
            boolean isValidSite = false;
            boolean isBadUser = false;
            boolean isTargetOrder = false; // 成約ポイント対象か
            String siteId = order.get(OrderHist.SITE_ID);
            String orderId = order.get(OrderHist.ORDER_ID);
            ContractSiteMst site = new ContractSiteMst();
            String expireDateTime = "";
            // 成約ポイント対応してないサイトは設定しない
            if (site.load(db, siteId)) {
                isValidSite = true;
                if (site.isBadUser(db, orderId)) {
                    isBadUser = true;
                }
                Timestamp order_timestamp = DateUtil.toTimestamp(order.get(OrderHist.ORDER_DATETIME));
                Timestamp bgn_timestamp = DateUtil.toTimestamp(site.get(ContractSiteMst.BGN_DATETIME));
                if (order_timestamp.after(bgn_timestamp)) {
                    isTargetOrder = true; // 事後登録時
                }
                // ポイント申請制限期間(単位：日)を取得する
                int expireDay = site.getLimitDays(db, orderId);

                // ポイント申請期限を計算
                expireDateTime = ValueUtil.nullToStr(DateUtil.getDateTime(order.get(OrderHist.ORDER_DATETIME),
                        expireDay + "d"));
            }

            // 成約ステータス(サイト有効かつ悪質ユーザーではない場合「1:回答待」、その他「0:対象外」)
            int contractStatus = (isValidSite && !isBadUser && isTargetOrder) ? STATUS_1_ANSWER_WAIT : STATUS_0_OUT;
            // 車買取成約ポイント停止より対応
            if (contractStatus == STATUS_1_ANSWER_WAIT
                    && site.getContractSiteId().equals(SateiOmakaseUserInfo.PC_SITE_ID)) {
                // 利用停止日時を取得する
                String pointEndTime = ValueUtil.nullToStr(SystemPropertiesDb.getInstance().get("CONTRACT_POINT_END_TIME"));
                if (pointEndTime.length() != 0) {
                    // Timestampへ変換
                    Timestamp end_timestamp = DateUtil.toTimestamp(pointEndTime);

                    // 利用日取得(YYYYMMDDHHMISS形式)
                    Timestamp order_timestamp = DateUtil.toTimestamp(order.get(OrderHist.ORDER_DATETIME));

                    // 利用終了の場合
                    if (order_timestamp.after(end_timestamp)) {
                        contractStatus = STATUS_0_OUT;
                    }
                }
            }
            order.set(CONTRACT_LIMIT_DATE, contractStatus==STATUS_0_OUT? "": expireDateTime);
            order.set(CONTRACT_STATUS, String.valueOf(contractStatus));
            order.set(BAD_USER_FLAG, isBadUser ? FLG_BAD_USER_ON : FLG_BAD_USER_OFF);

            StringBuffer sqlbuf = new StringBuffer("INSERT INTO ORDER_HIST ");
            sqlbuf.append("(GUID,ORDER_DATETIME,ORDER_TYPE,SITE_ID,ORDER_ID,ORDER_TEXT,SUPPLIER_TEXT,");
            sqlbuf
                    .append("RECENT_DISP_FLAG,POST_REGIST_FLAG, CONTRACT_STATUS, CONTRACT_LIMIT_DATE, STATUS_UP_DATETIME, BAD_USER_FLAG) ");
            sqlbuf.append(" SELECT ?,?,?,?,?,?,?,?,?,?,?,?,? ");
            sqlbuf.append(" FROM DUAL ");

            // サイトIDとオーダーID一致のデータがあれば重複登録しないよう
            sqlbuf.append(" WHERE NOT EXISTS (SELECT 1 FROM ORDER_HIST");
            sqlbuf.append(" WHERE GUID = ? AND SITE_ID = ? AND ORDER_ID = ? )");

            int idx = 1;
            db.prepareStatement(sqlbuf.toString());
            db.setString(idx++, order.get(OrderHist.GUID));
            db.setString(idx++, order.get(OrderHist.ORDER_DATETIME));
            db.setString(idx++, order.get(OrderHist.ORDER_TYPE));
            db.setString(idx++, siteId);
            db.setString(idx++, orderId);
            db.setString(idx++, order.get(OrderHist.ORDER_TEXT));
            db.setString(idx++, order.get(OrderHist.SUPPLIER_TEXT));
            db.setString(idx++, order.get(OrderHist.RECENT_DISP_FLAG));
            db.setString(idx++, order.get(OrderHist.POST_REGIST_FLAG));
            db.setString(idx++, order.get(OrderHist.CONTRACT_STATUS));
            db.setString(idx++, order.get(OrderHist.CONTRACT_LIMIT_DATE));
            db.setString(idx++, order.get(OrderHist.ORDER_DATETIME));
            db.setString(idx++, order.get(OrderHist.BAD_USER_FLAG));

            // where
            db.setString(idx++, order.get(OrderHist.GUID));
            db.setString(idx++, siteId);
            db.setString(idx++, orderId);
            return db.executeUpdate();

        } catch (Exception e) {

            log.error("ORDER_HISTORY テーブルに書き込み中に例外エラーが発生しました。", e);
            return -1;

        }

    }

    /**
     * <pre>
     * 
     * ORDER_HISTテーブルに一行作成する。
     * 
     * 作成した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param order
     * @return
     */
    public static int insertToDB(OrderHist order) {

        if (order == null) {
            return -1;
        }

        DBAccess db = null;
        try {

            db = new DBAccess();

            return OrderHist.insertToDB(db, order);

        } catch (Exception e) {
            log.error("例外エラーが発生しました。", e);
            return -1;

        } finally {
            DBAccess.close(db);
        }

    }

    /**
     * <pre>
     * 
     * ORDER_HISTテーブルに一行更新する。
     * 
     * 更新した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param campaign
     * @return 更新したレコード数
     */
    public static int updateToDB(OrderHist order) {

        if (order == null) {
            return -1;
        }

        DBAccess db = null;
        try {

            db = new DBAccess();

            return OrderHist.updateToDB(db, order);

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function OrderHist#updateToDB", e);
            return -1;

        } finally {
            DBAccess.close(db);
        }

    }

    /**
     * <pre>
     * 
     * ORDER_HISTテーブルに一行更新する。
     * 
     * 更新した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param db
     * @param campaign
     * @return 更新したレコード数
     */
    public static int updateToDB(DBAccess db, OrderHist order) {

        if (db == null) {
            return -1;
        }

        if (order == null) {
            return -1;
        }

        try {
            DBUpdater updater = new DBUpdater(TABLE);

            // 更新対象
            updater.addString(CONTRACT_SITE_ID, order.get(CONTRACT_SITE_ID));
            updater.addString(CONTRACT_POINT_NO, order.get(CONTRACT_POINT_NO));
            updater.addString(CONTRACT_POINT, order.get(CONTRACT_POINT));
            updater.addString(CONTRACT_LIMIT_DATE, order.get(CONTRACT_LIMIT_DATE));
            updater.addString(CONTRACT_STATUS, order.get(CONTRACT_STATUS));
            updater.addString(CONTRACT_FLAG, order.get(CONTRACT_FLAG));
            updater.addString(CONTRACT_COMPANY_ID, order.get(CONTRACT_COMPANY_ID));
            updater.addString(CONTRACT_COMPANY_NAME, order.get(CONTRACT_COMPANY_NAME));
            updater.addString(STATUS_UP_DATETIME, order.get(STATUS_UP_DATETIME));
            updater.addString(REJECT_REASON, order.get(REJECT_REASON));
            updater.addString(POINT_CHARGE_ID, order.get(POINT_CHARGE_ID));
            updater.addString(BAD_USER_FLAG, order.get(BAD_USER_FLAG));

            // 主キー
            updater.setCond(" WHERE SITE_ID = ? AND ORDER_ID = ? ");
            updater.addCondString(order.get(SITE_ID));
            updater.addCondString(order.get(ORDER_ID));
            return updater.update(db);

        } catch (Exception e) {
            log.error(TABLE + " テーブルに書き込み中に例外エラーが発生しました。Error in function OrderHist#updateToDB", e);
            return -1;
        }

    }
}
