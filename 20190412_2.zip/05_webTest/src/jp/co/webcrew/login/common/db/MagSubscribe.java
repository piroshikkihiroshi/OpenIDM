/**
 * 
 */
package jp.co.webcrew.login.common.db;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;

/**
 * メールマガジン購読管理テーブル MAG_SUBSCRIBE に対応したクラス
 * 
 * @author Takahashi
 *
 */
public class MagSubscribe extends DBEntity {
    /** ロガー */
    private static final Logger log = Logger.getLogger(MagSubscribe.class);

    /** テーブル名 */
    public static final String TABLE 					= "MAIL_SUBSCRIBE";

    /** スキーマ名 */
    public static final String SCHEMA 					= "COMMON";

    /** 端末タイプ：共用 */
    public static final String TERM_TYPE_COMMON  		= "0";

    /** 端末タイプ：PC向け */
    public static final String TERM_TYPE_PC      		= "1";

    /** 端末タイプ：モバイル向け */
    public static final String TERM_TYPE_MOBILE  		= "2";

    /** 端末タイプ：ゲーム機、情報端末、TV向け */
    public static final String TERM_TYPE_OTHER   		= "3";

    /** 健康メルマガＩＤ  ズバット通信ＩＤになります。*/
    public static final String MAG_KENKO_ID             = "1";

    /** 西原漫画購読メルマガＩＤ */
    public static final String MAG_SAIBARA_ID           = "3";

    /** となしば通信メルマガＩＤ */
    public static final String MAG_TONASHIBA_ID         = "11";
    
    /** アンケートおしらせメールＩＤ */
    public static final String MAG_ENQUETE_NOTICE_ID    = "12";
    
    /** 無効フラグ　0：有効 */
    public static final String MAG_INVALID_FLAG_OFF 	= "0";

    /** 無効フラグ 1:無効 */
    public static final String MAG_INVALID_FLAG_ON 		= "1";

    /** お知らせメール */
    public static final String ANNOUNCE_MAIL = "1";
	
	/** カテゴリメルマガ */
    public static final String CATEGORY_MAIL = "2";
	
	/** 統合メルマガ */
    public static final String ZUBAT_MAIL = "3";

	/** 満期日お知らせメルマガ */
    public static final String MATURITY_MAIL = "4";
    
    /** 受信メール管理画面からの登録 */
    public static final String REGIST_MYPAGE_MAIL_KANRI_PAGE 	= "1";
    /** 各商材サイト利用時の登録 */
    public static final String REGIST_SITE_USE 					= "2";
    /** マイページ初回ログイン画面からの登録 */
    public static final String REGIST_MYPAGE_LOGIN_PAGE			= "3";
    /** 専用登録画面から */
    public static final String REGIST_SITEWISE_PAGE				= "4";
    /** 個人情報管理ツールからの登録 */
    public static final String REGIST_KOJIN_JOHO_KANRI_TOOL 	= "5";
    
    /** 受信メール管理画面からの解除 */
    public static final String DELETE_MYPAGE_MAIL_KANRI_PAGE 	= "1";
    /** 各商材サイト利用時の解除 */
    public static final String DELETE_SITE_USE 					= "2";
    /** 個人情報管理ツールからの解除 */
    public static final String DELETE_KOJIN_JOHO_KANRI_TOOL 	= "3";
    /** ブラックリストからのクリーニングによる解除 */
    public static final String DELETE_BLACK_LIST		 		= "4";
    /** メルマガによる解除 */
    public static final String DELETE_MAIL_MAGA		 			= "5";

    /*
     * 列名定義 （定数定義）
     */
    public static final String GUID          			= "GUID"; 
    public static final String EMAIL         			= "EMAIL"; 
    public static final String MAG_ID        			= "MAG_ID"; 
    public static final String BGN_DATETIME  			= "BGN_DATETIME";
    
    /** メールID */
    public static final String MAIL_ID 					= "MAIL_ID";
    
    /** 無効フラグ　0：有効　1：無効 */
    public static final String INVALID_FLAG 			= "INVALID_FLAG";
    
    /** 購読開始日時 */
    public static final String REGISTRATION_DATE 		= "REGISTRATION_DATE";
    
    /** 購読更新日 */
    public static final String DELETE_DATE 				= "DELETE_DATE";
    
    /** 登録元 */
    public static final String REGISTERED_FROM			= "REGISTERED_FROM";
    
    /** 削除元 */
    public static final String DELETED_FROM 			= "DELETED_FROM";

    /** メルマガ購読情報検索用sql */
    public static final String MAIL_SUBSCRIBE_SELECT = "SELECT INVALID_FLAG, REGISTERED_FROM "
    		+ "FROM COMMON.MAIL_SUBSCRIBE "
    		+ "WHERE EMAIL = ? AND MAIL_ID = ?";
    
    /** メルマガ購読情報挿入用sql */
    public static final String MAIL_SUBSCRIBE_INSERT1 = "INSERT INTO COMMON.MAIL_SUBSCRIBE "
    		+ "(MAIL_ID, EMAIL, INVALID_FLAG, REGISTRATION_DATE, REGISTERED_FROM) "
            + "SELECT ?, ?, ?, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'), ? "
            + "FROM DUAL "
            + "WHERE NOT EXISTS (SELECT 1 FROM COMMON.MAIL_SUBSCRIBE WHERE MAIL_ID = ? AND EMAIL = ? )";
    
    /** メルマガ購読情報挿入用sql  当該データのREGISTRATION_DATE と DELETE_DATE には NULL が登録されるように修正する。 */
    public static final String MAIL_SUBSCRIBE_INSERT2 = "INSERT INTO COMMON.MAIL_SUBSCRIBE "
    		+ "(MAIL_ID, EMAIL, INVALID_FLAG) "
            + "SELECT ?, ?, ? "
            + "FROM DUAL "
            + "WHERE NOT EXISTS (SELECT 1 FROM COMMON.MAIL_SUBSCRIBE WHERE MAIL_ID = ? AND EMAIL = ? ) "
            + "AND NOT EXISTS(SELECT 1 FROM COMMON.MAIL_MST WHERE MAIL_ID = ? AND MAIL_TYPE IN (2,3))";

    /** メルマガ購読情報更新用sql */
    public static final String MAIL_SUBSCRIBE_UPDATE1 = "UPDATE COMMON.MAIL_SUBSCRIBE SET DELETE_DATE=?, "
    		+ "DELETED_FROM =?, INVALID_FLAG =? WHERE MAIL_ID = ? AND EMAIL = ?";

    /** メルマガ購読情報更新用sql */
    public static final String MAIL_SUBSCRIBE_UPDATE2 = "UPDATE COMMON.MAIL_SUBSCRIBE SET "
    		+ "REGISTRATION_DATE = TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'), REGISTERED_FROM=?, "
    		+ "INVALID_FLAG =? WHERE MAIL_ID = ? AND EMAIL = ?";
    
    /** メルマガ購読情報挿入用sql */
    public static final String MAIL_SUBSCRIBE_DETAIL_INSERT = "INSERT INTO COMMON.MAIL_SUBSCRIBE_DETAIL " 
    		+ "(EMAIL, SITE_ID, ORDER_ID, USER_ID, GUID, MK_DATETIME) "
            + "SELECT ?, ?, ?, ?, ?, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')"
            + "FROM DUAL "
            + "WHERE NOT EXISTS "
            + "(SELECT 1 FROM COMMON.MAIL_SUBSCRIBE_DETAIL WHERE EMAIL = ? AND SITE_ID = ? AND ORDER_ID = ?)";

    /** テーブル変更したため、今後使わない
     * メルマガ購読情報挿入用sql */
//    public static final String MAG_SUBSCRIBE_INSERT = "INSERT INTO MAG_SUBSCRIBE(GUID, EMAIL, MAG_ID, BGN_DATETIME) "
//            + "SELECT ?, ?, ?, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') "
//            + "FROM DUAL "
//            + "WHERE NOT EXISTS (SELECT * FROM MAG_SUBSCRIBE WHERE EMAIL = ? AND MAG_ID = ?)";
    
    public void init() {
        setSchema(SCHEMA);
        setTable(TABLE);
    }

    /**
     * メルマガIDを元にメルマガフラグ購読情報を作成する。
     * 
     * @param db
     * @param strEmail
     * @param strMailId
     * @param strInvalidFlag
     * @throws SQLException
     */
    public static Record selectMailSubscribe(DBAccess db, String strEmail, String strMailId)
            throws SQLException 
    {
        // メルマガフラグ購読情報を検索する。
        db.prepareStatement(MAIL_SUBSCRIBE_SELECT);

    	db.setString(1, strEmail);
		db.setString(2, strMailId);
		return Record.getFirstRowOf(db);
    }
    
    /**
     * メルマガIDを元にメルマガフラグ購読情報を作成する。
     * 
     * @param db
     * @param strEmail
     * @param strMailId
     * @param strInvalidFlag
     * @throws SQLException
     */
    public static void insertMailSubscribe(DBAccess db, String strEmail, String strMailId, String strInvalidFlag, String strUpdateFrom)
            throws SQLException 
    {
        if (ValueUtil.nullToStr(strEmail).equals("")) 
        {
            log.info("E-mailが空のため、メルマガ購読処理を中止します。");
            return;
        }

        // メルマガフラグ購読情報を作成する。
        if (MAG_INVALID_FLAG_ON.equals(strInvalidFlag)) {
        	 // チェックオフ状態から初めて登録する場合お知らせメール [mail_id="101"以降]当該データのREGISTRATION_DATE と DELETE_DATE には NULL が登録されるように修正する。
	        db.prepareStatement(MAIL_SUBSCRIBE_INSERT2);
	        db.setString(1, strMailId);
	        db.setString(2, strEmail);
	        db.setString(3, strInvalidFlag);
	        db.setString(4, strMailId);
	        db.setString(5, strEmail);
	        db.setString(6, strMailId);
	        db.executeUpdate();
		}
		else {
	        db.prepareStatement(MAIL_SUBSCRIBE_INSERT1);
	        db.setString(1, strMailId);
	        db.setString(2, strEmail);
	        db.setString(3, strInvalidFlag);
			db.setString(4, strUpdateFrom);
	        db.setString(5, strMailId);
	        db.setString(6, strEmail);
	        db.executeUpdate();
		}  


    }

    /**
     * サイトIDを元にメルマガフラグ購読情報を更新する。
     * @param db
     * @param strEmail
     * @param strMailId
     * @param strInvalidFlag
     * @throws SQLException
     */
	public static void updateMailSubscribe(DBAccess db, String strEmail, String strMailId, 
		String strInvalidFlag, String strUpdateFrom) throws SQLException 
	{
		if (ValueUtil.nullToStr(strEmail).equals("")) 
		{
			log.info("E-mailが空のため、メルマガ購読処理を中止します。");
			return;
		}

		// メルマガフラグ購読情報を作成する。
		if (MAG_INVALID_FLAG_ON.equals(strInvalidFlag))	{
			db.prepareStatement(MAIL_SUBSCRIBE_UPDATE1);
			db.setString(1, DateUtil.currentDateTime());
			db.setString(2, strUpdateFrom);
			db.setString(3, strInvalidFlag);
			db.setString(4, strMailId);
			db.setString(5, strEmail);
		}
		else {
			db.prepareStatement(MAIL_SUBSCRIBE_UPDATE2);
			db.setString(1, strUpdateFrom);
			db.setString(2, strInvalidFlag);
			db.setString(3, strMailId);
			db.setString(4, strEmail);
		}
		
		db.executeUpdate();
	}
	
    /**
     * メルマガIDを元にメルマガフラグ購読情報詳細を作成する。
     * @param db
     * @param strEmail
     * @param strSiteId
     * @param strOrderId
     * @param strUserId
     * @param strGuid
     * @throws SQLException
     */
    public static void insertMailSubscribeDetail(DBAccess db, String strEmail, String strSiteId, String strOrderId,
            String strUserId, String strGuid) throws SQLException 
    {

        if (ValueUtil.nullToStr(strEmail).equals("")) 
        {
            log.info("E-mailが空のため、メルマガ購読処理を中止します。");
            return;
        }

        // メルマガフラグ購読情報を作成する。
        db.prepareStatement(MAIL_SUBSCRIBE_DETAIL_INSERT);

        db.setString(1, strEmail);
        db.setString(2, strSiteId);
        db.setString(3, strOrderId);
        db.setString(4, strUserId);
        db.setString(5, strGuid);
        db.setString(6, strEmail);
        db.setString(7, strSiteId);
        db.setString(8, strOrderId);
        db.executeUpdate();
    }

    /**
     * テーブル変更のためこのメソッドは使わない
     * メルマガIDを元にメルマガフラグ購読情報を作成する。
     * @param db
     * @param strGuid
     * @param strEmail
     * @param strMailId
     * @throws SQLException
     
    public static void insertMelmagaFlg(DBAccess db, String strGuid, String strEmail, String strMailId) 
    		throws SQLException 
    {

        if (ValueUtil.nullToStr(strEmail).equals("")) 
        {
            log.info("E-mailが空のため、メルマガ購読処理を中止します。");
            return;
        }
        if (ValueUtil.nullToStr(strGuid).equals("")) 
        {
            log.info("guidが空のため、メルマガ購読処理を中止します。");
            return;
        }
        
        // メルマガフラグ購読情報を作成する。
        db.prepareStatement(MAG_SUBSCRIBE_INSERT);

        db.setString(1, strGuid);
        db.setString(2, strEmail);
        db.setString(3, strMailId.trim());
        db.setString(4, strEmail);
        db.setString(5, strMailId.trim());
        db.executeUpdate();
    }
    */
}
