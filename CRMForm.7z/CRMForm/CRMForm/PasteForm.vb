﻿Imports System.Text 'stringbuilder用
Imports CRMForm.DeclareCs
Imports CRMForm.commonFunc
Imports CRMForm.sqlMng

Public Class PasteForm

    Private Sub PasteForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub tgtTextArea_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tgtTextArea.TextChanged

    End Sub
End Class