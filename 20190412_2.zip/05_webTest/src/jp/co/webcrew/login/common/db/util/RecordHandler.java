/**
 * 
 */
package jp.co.webcrew.login.common.db.util;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * レコードオブジェクトを扱うインタフェース
 * @author Takahashi
 *
 */
public interface RecordHandler {
	/**
	 * ResultSetを元にオブジェクトの各属性をセットする
	 * @param ResultSet rs
	 * @throws SQLException
	 */
	public void populate(ResultSet rs) throws SQLException;
}
