package jp.co.webcrew.filters.util.httputil;

import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * リクエスト情報をリクエスト終了後でも参照できるようにするために保持しておくクラス。
 * 
 * @author kurinami
 * 
 */
public class HttpServletRequestCache {

	/** クラス作成日時 */
	Date mkDatetime = new Date();

	/** ヘッダ情報 */
	Map headers = new HashMap();

	/** リクエスト属性 */
	Map attributes = new HashMap();

	/** クエリストリング */
	String queryString = null;

	/** リクエストURL */
	StringBuffer requestURL = null;

	/** リクエストメソッド */
	String method = null;

	/** リモートアドレス */
	String remoteAddr = null;

	/** 状態コード(これだけレスポンスの内容なので注意) */
	int status = 0;

	/**
	 * リクエスト情報の中から必要な項目をコピーする。
	 * 
	 * @param request
	 */
	public HttpServletRequestCache(HttpServletRequest request,
			HttpServletResponse httpServletResponse) {

		Enumeration headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = ((String) headerNames.nextElement()).toLowerCase();
			headers.put(key, request.getHeader(key));
		}

		Enumeration attributeNames = request.getAttributeNames();
		while (attributeNames.hasMoreElements()) {
			String key = (String) attributeNames.nextElement();
			attributes.put(key, request.getAttribute(key));
		}

		queryString = request.getQueryString();

		requestURL = request.getRequestURL();

		method = request.getMethod();

		remoteAddr = request.getRemoteAddr();

		if (httpServletResponse instanceof CustomHttpServletResponse) {
			status = ((CustomHttpServletResponse) httpServletResponse)
					.getStatus();
		}
	}

	/**
	 * 作成日時を返す。
	 * 
	 * @return
	 */
	public Date getMkDatetime() {
		return mkDatetime;
	}

	/**
	 * ヘッダ情報を返す。
	 * 
	 * @param key
	 * @return
	 */
	public String getHeader(String key) {
		return (String) headers.get(key.toLowerCase());
	}

	/**
	 * リクエスト属性を返す。
	 * 
	 * @param key
	 * @return
	 */
	public Object getAttribute(String key) {
		return attributes.get(key);
	}

	/**
	 * クエリストリングを返す。
	 * 
	 * @return
	 */
	public String getQueryString() {
		return queryString;
	}

	/**
	 * リクエストURLを返す。
	 * 
	 * @return
	 */
	public StringBuffer getRequestURL() {
		return requestURL;
	}

	/**
	 * メソッドを返す。
	 * 
	 * @return
	 */
	public String getMethod() {
		return method;
	}

	/**
	 * リモートアドレスを返す。
	 * 
	 * @return
	 */
	public String getRemoteAddr() {
		return remoteAddr;
	}

	/**
	 * 状態コードを返す。
	 * 
	 * @return
	 */
	public int getStatus() {
		return status;
	}
}
