package jp.co.webcrew.filters.db;

import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * CMSキーワードを管理するdbクラス。
 * 
 * @author kurinami
 */
public class CmsKwdMstDb extends RefreshMstDb {

	/** CMSキーワードマスタ情報取得用SQL */
	private static final String CMS_KWD_MST_SELECT = "select * from cms_kwd_mst where to_char(sysdate, 'YYYYMMDDHH24MISS') between bgn_datetime and end_datetime";

	/** 唯一のインスタンス */
	private static CmsKwdMstDb cmsKwdMstDb = new CmsKwdMstDb();

	/** 変換キーワードの一覧 */
	private Map keywordMap;

	/**
	 * 生成不能コンストラクタ
	 */
	private CmsKwdMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static CmsKwdMstDb getInstance() {
		return cmsKwdMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			Map keywordMap = new HashMap();

			// サイト情報一覧を検索する。
			dbAccess.prepareStatement(CMS_KWD_MST_SELECT);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				String name = ValueUtil.nullToStr(rs.getString("kwd_name"))
						.toLowerCase();
				Clob valueClob = rs.getClob("content");
				String value = valueClob.getSubString(1, (int) valueClob
						.length());

				keywordMap.put(name, value);
			}

			this.keywordMap = keywordMap;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * CMSキーワードの一覧を返す。
	 * 
	 * @return
	 */
	public Map getKeywordMap() {
		Map keywordMap = this.keywordMap;
		if (keywordMap != null) {
			return new HashMap(keywordMap);
		} else {
			return new HashMap();
		}
	}
}
