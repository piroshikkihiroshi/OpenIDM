package jp.co.webcrew.login.common.db.util;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.util.DateUtil;

public class Record extends DBMap implements RecordHandler {


	/**
	 * 
	 */
	private static final long serialVersionUID = 4122349509230616419L;
	/** ロガー */
	private static Logger log = Logger.getLogger(Record.class);

	/**
	 * 
	 * @param rs 結果セット
	 * @return Record 取得結果の最初の一行を表すオブジェクト
	 * @return null 結果セットの行が空（SQL結果0行）の時
	 * @throws SQLException
	 */
	public static Record getFirstRow(ResultSet rs) throws SQLException{
		if (rs.next()){
			return new Record(rs);
		} else {
			return null;
		}
	}

	/**
	 * 最初のレコードを取得する。
	 * prepareStatementで検索系のSQLを準備し、
	 * setXXXでパラメータ設定が終わった後に呼び出すこと
	 * @param db
	 * @return Record 取得した行データオブジェクト 
	 * @return null 該当データが存在しない
	 * @throws SQLException
	 */
    public static Record getFirstRowOf(DBAccess db) throws SQLException{
		ResultSet rs = null;
		try{
			rs = db.executeQuery();
			return Record.getFirstRow(rs);
		
		} finally {
			DBAccess.close(rs);
		}
    }

	/**
	 * SQLの検索結果をRecord（行データ）のListで返却する
	 * prepareStatementで検索系のSQLを準備し、
	 * setXXXでパラメータ設定が終わった後に呼び出すこと
	 * @param db
	 * @return List 取得した行データオブジェクト。
	 *               該当データが存在しない場合、nullではなく空のListオブジェクトを返却する 
	 * @throws SQLException
	 */
    public static List getResultListOf(DBAccess db) throws SQLException{
    	List list = new ArrayList();
    	ResultSet rs = null;
		try{
			rs = db.executeQuery();
			while(rs.next()) {
				list.add(new Record(rs));
			}
		} finally {
			DBAccess.close(rs);
		}
		return list;
    }

	/**
	 * SQLの検索結果をRecord（行データ）のListで返却する
	 * prepareStatementで検索系のSQLを準備し、
	 * setXXXでパラメータ設定が終わった後に呼び出すこと
	 * @param db
	 * @return List 取得した行データオブジェクト。
	 *               該当データが存在しない場合、nullではなく空のListオブジェクトを返却する 
	 * @throws SQLException
	 */
    public static List getResultListOf(DBAccess db , RecordHandler handler) throws SQLException{
    	List list = new ArrayList();
    	ResultSet rs = null;
//    	Record record = new Record();
    	
		try{
			rs = db.executeQuery();
			while(rs.next()) {
		    	RecordHandler record = (RecordHandler)handler.getClass().newInstance(); // TODO オブジェクトのクローンを検討する
		    	record.populate(rs);
				list.add(record);
			}
		} catch (Exception e) {
			log.error("結果リスト取得中に例外エラーが発生しました。" , e);
			throw new DBException(e);
		} finally {
			DBAccess.close(rs);
		}
		return list;
    }
    
	/**
     * コンストラクタ
     * @param ResultSet rs 結果セット
   　* @return なし
     * @throws SQLException DBエラー発生時
     */
	public Record(ResultSet rs) throws SQLException{
		init(rs);
	}

    public Record() {
	  ;
    }

	public void init(ResultSet rs) throws SQLException{
		read(rs);  
	}

    /**
     * ResultSetからカラム名、内容を読み込む
     *
     * @param ResultSet rs JDBCの結果集合
     * @return なし
     * @throws SQLException DBエラーが発生したとき
     */
	protected final void read(ResultSet rs) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		for (int columnIdx = 1; columnIdx <= rsmd.getColumnCount(); columnIdx++) {

			String colName = rsmd.getColumnName(columnIdx);
			int colType = rsmd.getColumnType(columnIdx);
			if (colType == java.sql.Types.DATE ||
				colType == java.sql.Types.TIMESTAMP ) {
				
				super.put(colName,rs.getTimestamp(columnIdx));
			
			} else if(colType == java.sql.Types.CLOB) {

				super.put(colName , rs.getString(columnIdx)); // 「CLOB データの挿入および取出しのショートカット」

			} else {
			
				super.put(colName,rs.getObject(columnIdx));

			}
			
		}
	}
	
	public void populate(ResultSet rs) throws SQLException {
		read(rs);
	}

  /**
   * オブジェクト型の値を設定する
   * @param String 値をセットするSQL文内のカラム名
   * @param Object セットする値
   * @throws なし
   * @deprecate {@link Record#setObject(String, Object)}
   * 
   */
  public void setValue(String name, Object value) {
    super.put(name,value);
  }

  /**
   * オブジェクト型の値を設定する
   * @param String 値をセットするSQL文内のカラム名
   * @param Object セットする値
   * @return なし
   * @throws なし
   */
  public void setObject(String name, Object value) {
    super.put(name,value);
  }
  
  //------------------------------
  /**
   * オブジェクト型の値を取得する
   * @param String SQL文の代替文字列
   * @return 引数名カラムから取得した値
   * @throws なし
   */
  public Object getObject(String name) {
	   return super.get(name);
  }
  
  /**
   * DBに格納されている値そのままを文字列型で取得する
   * ObjectがNULLの場合、そのままNULLを返します
   * NULLと空文字の区別のあるデータベースの場合はこのメソッドを使ってください
   * @param String 列名
   * @return 引数名カラムから取得した値
   * @throws DBException
   */
  public String getDBString(Object name) {
    	String ret = null;
    	if(name == null){
    		log.warn("呼び出し元が引数にnullを指定しました。");
    		return null;
    	}
    	
		try {
			Object obj = super.get(name);
			if (obj == null) {
				return null;
			} else {

				if (obj instanceof java.sql.Timestamp) {
					ret = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"))
							.format(obj);
				} else if (obj instanceof java.sql.Date) { // 読み込み時に全てTimastampになっているはずだが、念のため
					ret = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"))
							.format(obj);
				} else {
					ret = obj.toString();
				}
			}
		} catch (Exception e) {
			log.error("例外エラーが発生しました。" , e);
		}		
		return changeDBString(ret);
  }

	/**
	 * 列がNULLかどうかを返す
	 * @param columnName
	 * @return true NULLである
	 * @return false NULLでない
	 * @throws DBException
	 */
	public boolean isNull(String columnName){
		if(getDBString(columnName) == null){
			return true ; 	
		} else {
			return false;
		}
	}

	/**
	 * 列がNULLでないかどうかを返す
	 * @param columnName
	 * @return true NULLでない
	 * @return false NULLである
	 * @throws DBException
	 */
	public boolean isNotNull(String columnName){
		return ! isNull(columnName);
	}

    /**
     * <pre>
     * 日付型の値を取得する。
     * 
     * Timestampへの型変換に失敗した場合は null を返す。
     * 
     * </pre>
     * @param String SQL文の代替文字列
     * @return 引数名カラムから取得した値
     * @throws なし
     */
    public Timestamp getTimestamp(String name) {
        
        try {
           
            return (Timestamp)super.get(name);
        
        } catch (RuntimeException e) {
            log.warn("Timestampへの変換に失敗しました。列=" + name + ", 値=" + super.get(name));
            e.printStackTrace();
            
            return null;
        }
        
    }

    /**
     * 日付型の列の値を、YYYYMMDD形式の文字列で取得する
     * nullの時は空文字を返す
     * 
     * @param name 列名
     * @return
     */
    public String getDateStr(String name) {
        
        Object val = super.get(name);
        
        if (val instanceof Timestamp) {
            return ValueUtil.nullToStr(DateUtil.getDate((Timestamp)val));
        }
        
        String date_str = getDBString(name);
        
        if (date_str.length() == 0) {
            return "";
        }
        
        if (date_str.length() < 8) {
            log.info("日付のデータフォーマットが不正です。" + date_str);
            return "";
        }

        if (date_str.length() == 8) {
            return date_str;
        }
        
        return ValueUtil.nullToStr(DateUtil.getDate(DateUtil.toTimestamp(date_str)));

    }

    /**
     * 日付型の列を、YYYYMMDDHH24MISS形式の文字列で取得する
     * nullの時は空文字を返す
     * @param name  列名
     * @return
     */
    public String getDateTimeStr(String name) {
        Timestamp t = getTimestamp(name);

        if (t == null) {
            return "";
        } else {
            return DateUtil.getDateTime(getTimestamp(name));
        }
    }

    /**
     * 数値型の値を取得する。NULLの場合は0を戻す
     * @param String 列名
     * @return 引数名カラムから取得した値
     * @throws なし
     */
    public int getInt(String name) {
        int ret = 0;
        try{
            String s = getDBString(name);
            if(s == null){
                return 0;
            }

            BigDecimal d = new BigDecimal(s); 
            ret = d.intValue();
        } catch (NullPointerException npe) {
            log.error("NullPointerException",npe);
        } catch (ClassCastException cce) {
            log.error("ClassCastException",cce);
        } catch (Exception ex){
            log.error("例外エラー発生",ex);
        } finally {
        }
        return ret;
    }

    /**
     * 数値型の値を取得する。NULLの場合は0を戻す
     * @param String 列名
     * @return 引数名カラムから取得した値
     * @throws なし
     */
    public long getLong(String name) {
        long ret = 0;
        try{
            String s = getDBString(name);
            if(s == null){
                return 0;
            }
            BigDecimal d = new BigDecimal(s); 
            ret = d.longValue();
        } catch (Exception ex){
            log.error("例外エラー発生",ex);
        } finally {
        }

        return ret;
    }


	/**
	 * keyに該当する列のデータをStringで得る。nullが渡されたら""を戻す
	 * @param String key
	 * @returns String 
	 * @throws なし
	 * 結果がnullだった場合は空文字列""として返すメソッドです
	 * 引数がnullでも""を戻します
	 */
	public String getString(Object key) {
		if(key == null){
			return "";
		}
		String ret = getDBString(key);
		if (ret == null || ret.equals("")){
			return "";
		}
		
		// 文字化け対策
		ret = changeDBString(ret);

		return ret;
	}


	public String changeDBString(String str) {
		// 文字化け対策
		return Cp932.toCp932(str);
	}

	public BigDecimal getBigDecimal(String name){
		return (BigDecimal)super.get(name);
	}
	
	public static String readDBStr(String str) {
		if (str == null || str.equals("")) {
			return "";
		}
		return Cp932.toCp932(str);
	}
	
}
