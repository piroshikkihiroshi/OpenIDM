package jp.co.webcrew.filters.filters.accesslog;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.UrlCategoryMapDb;

/**
 * アクセスログを出力するためのfilterクラス。
 * 
 * @author kurinami
 */
public class AccesslogFilter implements Filter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(AccesslogFilter.class);

	/** アクセスログスレッド */
	private AccesslogThread accesslogThread;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

		log.debug("init start.");

		try {
            // 必要なDBを初期化しておく
            UrlCategoryMapDb.getInstance().init();
			// ログ収集用スレッドを開始する。
			accesslogThread = new AccesslogThread();
			accesslogThread.start();
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			throw new ServletException(e);
		}

		log.debug("init end.");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		log.debug("doFilter start.");

		try {
			chain.doFilter(request, response);
		} finally {
			try {

			  // 対象URLだけアクセスログ登録スレット実行
        if (isTargetedUrl((HttpServletRequest) request)) {
          accesslogThread.push((HttpServletRequest) request, (HttpServletResponse) response);
        }

			} catch (Exception e) {
				log.error("予期せぬエラー", e);
			}
		}

		log.debug("doFilter end.");

	}

  /**
   * 登録対象URLチェック
   * 
   * @param request
   * @return
   */
  private boolean isTargetedUrl(HttpServletRequest request) {

    // SYSTEM_PROPERTIESで設定したログ登録対象外拡張子一覧取得
    String excludeExtensions = ValueUtil.nullToStr(SystemPropertiesDb.getInstance()
        .get("ACCESS_LOG_EXCLUDE_EXTENSIONS"));
    if (excludeExtensions.length() == 0) {
      return true; // 制御なし
    }

    String reqUrl = ValueUtil.nullToStr(request.getRequestURL());
    // 登録必要ないURL拡張子
    String[] excludeExts = excludeExtensions.split(",");
    for (String ext : excludeExts) {
      if (reqUrl.endsWith(ext.trim())) {
        return false;
      }
    }

    return true;
  }

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// 処理なし
	}

}
