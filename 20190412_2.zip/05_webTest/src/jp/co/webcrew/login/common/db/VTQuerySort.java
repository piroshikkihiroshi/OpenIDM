package jp.co.webcrew.login.common.db;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.ValueUtil;

public class VTQuerySort implements Comparator<Map<String, String>>
{
	private String sortKey;
	private VTQuerySortType sortType;
	private boolean asc;
	
	private SimpleDateFormat dateFormat=null;
	
	public VTQuerySort(VTQuerySortType sortType,String sortKey,boolean asc)
	{
		this.sortKey=sortKey;
		this.sortType=sortType;
		this.asc=asc;
		switch(this.sortType)
		{
		case Date:
			this.dateFormat=new SimpleDateFormat("yyyyMMdd");
			break;
		case DateTime:
			this.dateFormat=new SimpleDateFormat("yyyyMMddHHmmss");
			break;
		default:
			this.dateFormat=null;
			break;
		}
		
	}
	
	
	
	//@Override
	public int compare(Map<String, String> rowData1, Map<String, String> rowData2) 
	{
		String str1=ValueUtil.nullToStr(rowData1.get(this.sortKey));
		String str2=ValueUtil.nullToStr(rowData2.get(this.sortKey));
		
		int retval=0;
		//両方NULL
		if(str1.length()==0 && str2.length()==0)
		{
			retval=0;
		}
		//前者（のみ）空
		else if(str1.length()==0)
		{
			retval=-1;
		}
		//後者（のみ）空
		else if(str2.length()==0)
		{
			retval=1;
		}
		else
		{
			switch(this.sortType)
			{
			case Date:
			case DateTime:
				Date date1=null;
				try {
					date1 = this.dateFormat.parse(str1);
				} catch (ParseException e) {
					retval=0;
				}
				Date date2=null;
				try {
					date2 = this.dateFormat.parse(str2);
				} catch (ParseException e) {
					retval=0;
				}
				if(date1!=null && date2!=null)
				{
					retval=date1.compareTo(date2);
				}
				break;
			case Integer:
				long long1=Long.parseLong(str1);
				long long2=Long.parseLong(str2);
				if(long1-long2 <0)
				{
					retval=-1;
				}
				else if(long1==long2)
				{
					retval=0;
				}
				else
				{
					retval=1;
				}
				break;
			case Decimal:
				BigDecimal dec1=new BigDecimal(str1);
				BigDecimal dec2=new BigDecimal(str2);
				retval=dec1.compareTo(dec2);
				break;
			default:
				retval=str1.compareTo(str2);
				break;
			}
		}
		if(asc)
		{
			return retval;
		}
		else
		{
			return -retval;
		}
		
	}
	
}
