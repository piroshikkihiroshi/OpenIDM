package jp.co.webcrew.filters.db;

import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * URLキーワードを管理するdbクラス。
 * 
 * @author kurinami
 */
public class UrlKwdMstDb extends RefreshMstDb {

	/** URLキーワードマスタ情報取得用SQL */
	private static final String URL_KWD_MST_SELECT = "select * from url_kwd_mst where to_char(sysdate, 'YYYYMMDDHH24MISS') between bgn_datetime and end_datetime";

	/** 唯一のインスタンス */
	private static UrlKwdMstDb urlKwdMstDb = new UrlKwdMstDb();

	/** 完全一致用のURLキーワードの一覧 */
	private Map layerMapForComplete;

	/** 前方一致用のURLキーワードの一覧 */
	private Map layerMapForPartial;

	/**
	 * 生成不能コンストラクタ
	 */
	private UrlKwdMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static UrlKwdMstDb getInstance() {
		return urlKwdMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			Map layerMapForComplete = new HashMap();
			Map layerMapForPartial = new HashMap();

			// URLキーワードの一覧を検索する。
			dbAccess.prepareStatement(URL_KWD_MST_SELECT);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {

				// 完全一致用のmapに登録する。
				putToLayerMap(layerMapForComplete, rs);

				// サブディレクトリも含むと設定されている場合、
				if (ValueUtil.nullToStr(rs.getString("subdir_flag"))
						.equals("1")) {
					// 前方一致用のmapにも登録する。
					putToLayerMap(layerMapForPartial, rs);
				}

			}

			this.layerMapForComplete = layerMapForComplete;
			this.layerMapForPartial = layerMapForPartial;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * 階層ごとのmapにURLキーワードを登録する。
	 * 
	 * @param layerMap
	 * @param rs
	 * @throws SQLException
	 */
	private static void putToLayerMap(Map layerMap, ResultSet rs)
			throws SQLException {

		// 階層のごとのURLのmapを取得する。
		Integer layer = new Integer(rs.getInt("layer"));
		Map urlMap = (Map) layerMap.get(layer);
		if (urlMap == null) {
			urlMap = new HashMap();
			layerMap.put(layer, urlMap);
		}

		// URLごとのキーワードのmapを取得する。
		String url = ValueUtil.nullToStr(rs.getString("url"));
		Map keywordMap = (Map) urlMap.get(url);
		if (keywordMap == null) {
			keywordMap = new HashMap();
			urlMap.put(url, keywordMap);
		}

		// キーワードのmapに登録する。
		String name = (rs.getString("kwd_name")).toLowerCase();  // ここで小文字にしておかないと大文字で登録されているとマッチングしない 2008.02.08 miyake
		Clob valueClob = rs.getClob("content");
		String value = valueClob.getSubString(1, (int) valueClob.length());

		keywordMap.put(name, value);

	}

	/**
	 * urlとキーワードに対応した置換文字列を返す。
	 * 
	 * @param requestURI
	 * @param serverName
	 * @param kwd
	 * @return
	 */
	public String getContent(String requestURI, String serverName, String kwd) {

		Map layerMapForComplete = this.layerMapForComplete;
		Map layerMapForPartial = this.layerMapForPartial;

		String content;

		// まずホスト名付きで検索する。
		content = getContent(serverName + requestURI, kwd, layerMapForComplete,
				layerMapForPartial);
		if (content != null) {
			return content;
		}

		// 見つからなければ、次にホスト名なしで検索する。
		content = getContent(requestURI, kwd, layerMapForComplete,
				layerMapForPartial);
		if (content != null) {
			return content;
		}

		// 最終的に見つからなかった場合、nullを返す。
		return null;
	}

	/**
	 * urlとキーワードに対応した置換文字列を返す。
	 * 
	 * @param url
	 * @param kwd
	 * @param layerMapForComplete
	 * @param layerMapForPartial
	 * @return
	 */
	private static String getContent(String url, String kwd,
			Map layerMapForComplete, Map layerMapForPartial) {

		String content;

		List dirList = new ArrayList(Arrays.asList((url).split("/")));

		if (url.equals("/")) {
			// urlが「/」だけの場合、

			// 空のファイル名の部分を追加する。
			dirList.add("");
			dirList.add("");
			// 完全一致のものを検索する。
			content = searchFromLayerMap(layerMapForComplete, dirList, kwd);
			if (content != null) {
				return content;
			}
		} else if (url.endsWith("/")) {
			// ファイル名の部分が存在しない場合、

			// 空のファイル名の部分を追加する。
			dirList.add("");
			// 完全一致のものを検索する。
			content = searchFromLayerMap(layerMapForComplete, dirList, kwd);
			if (content != null) {
				return content;
			}
		} else {
			// ファイル名の部分が存在する場合、

			// 完全一致のものを検索する。
			content = searchFromLayerMap(layerMapForComplete, dirList, kwd);
			if (content != null) {
				return content;
			}

			// 最後のファイル名を取った表記のものを検索する。
			dirList.set(dirList.size() - 1, "");
			content = searchFromLayerMap(layerMapForPartial, dirList, kwd);
			if (content != null) {
				return content;
			}
		}

		// 前方一致のものを検索する。
		dirList.remove(dirList.size() - 1);
		while (dirList.size() > 0) {

			// 登録urlの最後がフォルダ名になっているもものを検索する。
			content = searchFromLayerMap(layerMapForPartial, dirList, kwd);
			if (content != null) {
				return content;
			}

			// 登録urlの最後に/ありの表記のものを検索する。
			dirList.set(dirList.size() - 1, "");
			content = searchFromLayerMap(layerMapForPartial, dirList, kwd);
			if (content != null) {
				return content;
			}

			dirList.remove(dirList.size() - 1);
		}

		return null;

	}

	/**
	 * 階層ごとのmapからURLキーワードを検索する。
	 * 
	 * @param layerMap
	 * @param dirList
	 * @param kwd
	 * @return
	 */
	private static String searchFromLayerMap(Map layerMap, List dirList,
			String kwd) {
		Map urlMap = (Map) layerMap.get(new Integer(dirList.size() - 1));
		if (urlMap != null) {
			String url = ValueUtil.concat(dirList, "/");
			Map keywordMap;
			keywordMap = (Map) urlMap.get(url);
			if (keywordMap != null) {
				String content = (String) keywordMap.get(kwd);
				if (content != null) {
					return content;
				}
			}
		}
		return null;
	}
}
