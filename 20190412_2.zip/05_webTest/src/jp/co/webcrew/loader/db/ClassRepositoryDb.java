package jp.co.webcrew.loader.db;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * クラス情報を管理するdbクラス。
 * 
 * @author kurinami
 */
public class ClassRepositoryDb {

    /** クラス情報一覧取得用SQL */
    private static final String SELECT_LIST = ""
            + "select distinct class_name from logic_store where class_name like ? || ''.%'' {0} ";

    /** クラス情報取得用SQL */
    private static final String SELECT_CLASS_REPOSITORY = ""
            + "select * from logic_store where class_name = ? {0} order by {1} up_datetime desc ";

    /** クラス情報取得用SQL */
    private static final String SELECT_CLASS_NAME = ""
            + "select * from logic_store where logic_id = ? {0} order by {1} up_datetime desc ";

    /** クラス情報取得用SQL */
    private static final String SELECT_CLASS_NAME_FROM_PURPOSE = ""
            + "select * from logic_store where purpose = ? and logic_name = ? {0} order by {1} up_datetime desc";

    /** 更新クラス情報一覧取得用SQL */
    private static final String SELECT_MODIFIED_LIST = ""
            + "select distinct class_name from logic_store where 1 = 1 {0} {1} ";

    /** 本番環境用追加検索条件 */
    private static final String RELEASE_CONDITION = ""
            + "and bgn_datetime <= to_char(sysdate, ''YYYYMMDDHH24MISS'') and (include_server is null or include_server like ''%{0}%'') and (exclude_server is null or not exclude_server like ''%{0}%'') ";

    /** 本番環境用追加ソート条件 */
    private static final String RELEASE_ORDER = "bgn_datetime desc,";

    /** 本番環境用追加更新条件 */
    private static final String RELEASE_MODIFIED_CONDITION = ""
            + "and ( bgn_datetime between ? and to_char(sysdate, 'YYYYMMDDHH24MISS') or up_datetime between ? and to_char(sysdate, 'YYYYMMDDHH24MISS') ) ";

    /** 本番環境用追加更新条件 */
    private static final String STAGING_MODIFIED_CONDITION = ""
            + "and up_datetime between ? and to_char(sysdate, 'YYYYMMDDHH24MISS') ";

    /** 用途区分：バリデーション用 */
    public static final int PURPOSE_VALIDATION = 1;

    /** 用途区分：スクリーニング用 */
    public static final int PURPOSE_SCREENING = 2;

    /** 用途区分：汎用ロジック */
    public static final int PURPOSE_LOGIC = 11;

    /** 用途区分：filter */
    public static final int PURPOSE_FILTER = 12;

    /** 用途区分：sstag */
    public static final int PURPOSE_SSTAG = 21;

    /** 用途区分：管理画面用モジュール */
    public static final int PURPOSE_ADMIN_MODULE = 51;

    /** 用途区分：その他 */
    public static final int PURPOSE_OTHER = 99;

    /** ロガー */
    private static final Logger log = Logger.getLogger(ClassRepositoryDb.class);

    /** ホスト名 */
    private static String hostName = "";

    static {
        try {
            hostName = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            log.error("ホスト名取得エラー", e);
        }
    }

    /**
     * 種別を返す。
     * 
     * @param className
     * @return
     * @throws SQLException
     */
    public static int getType(String className) throws SQLException {

        log.info("start getType( " + className + " ).");

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess("phoenix");

            int type = 0;

            // クラス情報を検索する。
            String sql = MessageFormat.format(SELECT_CLASS_REPOSITORY, getAddCondition(), getAddOrder());
            dbAccess.prepareStatement(sql);
            dbAccess.setString(1, className);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                type = rs.getInt("prog_type");
            }

            return type;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * クラスのソース文字列を返す。
     * 
     * @param className
     * @return
     * @throws SQLException
     */
    public static String getSource(String className) throws SQLException {

        log.info("start getSource( " + className + " ).");

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess("phoenix");

            String source = "";

            // クラス情報を検索する。
            String sql = MessageFormat.format(SELECT_CLASS_REPOSITORY, getAddCondition(), getAddOrder());
            dbAccess.prepareStatement(sql);
            dbAccess.setString(1, className);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                source = new String(rs.getBytes("body"), "utf-8");
            }

            return source;

        } catch (UnsupportedEncodingException e) {
            throw new SQLException("予期せぬエラー", e);
        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * クラスのコンパイルしたバイト配列を返す。
     * 
     * @param className
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static byte[] getClass(String className) throws SQLException, IOException {

        log.info("start getClass( " + className + " ).");

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess("phoenix");

            byte[] buf = new byte[0];

            // クラス情報を検索する。
            String sql = MessageFormat.format(SELECT_CLASS_REPOSITORY, getAddCondition(), getAddOrder());
            dbAccess.prepareStatement(sql);
            dbAccess.setString(1, className);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                buf = rs.getBytes("body");
            }

            return buf;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * パッケージ内のクラス名の一覧を返す。
     * 
     * @param packageName
     * @return
     * @throws SQLException
     */
    public static List<String> getClassNameList(String packageName) throws SQLException {

        log.info("start getClassNameList( " + packageName + " ).");

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess("phoenix");

            List<String> classNameList = new ArrayList<String>();

            // クラス情報一覧を検索する。
            String sql = MessageFormat.format(SELECT_LIST, getAddCondition());
            dbAccess.prepareStatement(sql);
            dbAccess.setString(1, packageName);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                String className = ValueUtil.nullToStr(rs.getString("class_name"));

                // そのクラスがパッケージ直下のクラスの場合のみ一覧に追加する。
                if (className.substring(packageName.length() + 1).indexOf('.') < 0) {
                    classNameList.add(className);
                }
            }

            return classNameList;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * クラス名を返す。
     * 
     * @param logicId
     * @return
     * @throws SQLException
     */
    public static String getClassName(String logicId) throws SQLException {

        log.info("start getClassName( " + logicId + " ).");

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess("phoenix");

            String className = "";

            // クラス名を検索する。
            String sql = MessageFormat.format(SELECT_CLASS_NAME, getAddCondition(), getAddOrder());
            dbAccess.prepareStatement(sql);
            dbAccess.setString(1, logicId);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                className = ValueUtil.nullToStr(rs.getString("class_name"));
            }

            return className;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * 用途区分とロジック名からクラス名を返す。
     * 
     * @param purpose
     * @param logicName
     * @return
     * @throws SQLException
     */
    public static String getClassName(int purpose, String logicName) throws SQLException {

        log.info("start getClassName( purpose:" + purpose + " logicName:" + logicName + " ).");

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess("phoenix");

            String className = "";

            // クラス名を検索する。
            String sql = MessageFormat.format(SELECT_CLASS_NAME_FROM_PURPOSE, getAddCondition(), getAddOrder());
            dbAccess.prepareStatement(sql);
            dbAccess.setInt(1, purpose);
            dbAccess.setString(2, logicName);
            rs = dbAccess.executeQuery();
            if (dbAccess.next(rs)) {
                className = ValueUtil.nullToStr(rs.getString("class_name"));
            }

            return className;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * 更新されたクラスのクラス名の一覧を返す。
     * 
     * @param lastDatetime
     * @return
     * @throws SQLException
     */
    public static List<String> getModifiedClassNameList(long lastDatetime) throws SQLException {

        String lastDatetimeStr = ValueUtil.toDateTimeString(new Date(lastDatetime));

        log.info("start getModifiedClassNameList( " + lastDatetimeStr + " ).");

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = new DBAccess("phoenix");

            List<String> classNameList = new ArrayList<String>();

            // 前回更新チェック以降に更新されたクラス情報一覧を検索する。
            String sql = MessageFormat.format(SELECT_MODIFIED_LIST, getAddModifiedCondition(), getAddCondition());
            dbAccess.prepareStatement(sql);
            if (PhoenixUtil.isTestMode()) {
                dbAccess.setString(1, lastDatetimeStr);
            } else {
                dbAccess.setString(1, lastDatetimeStr);
                dbAccess.setString(2, lastDatetimeStr);
            }
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                String className = ValueUtil.nullToStr(rs.getString("class_name"));
                classNameList.add(className);
            }

            return classNameList;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * 本番環境用の追加検索条件を返す。
     * 
     * @return
     */
    private static String getAddCondition() {
        return PhoenixUtil.isTestMode() ? "" : MessageFormat.format(RELEASE_CONDITION, hostName);
    }

    /**
     * 本番環境用の追加更新条件を返す。
     * 
     * @return
     */
    private static String getAddModifiedCondition() {
        return PhoenixUtil.isTestMode() ? STAGING_MODIFIED_CONDITION : RELEASE_MODIFIED_CONDITION;
    }

    /**
     * 本番環境用の追加ソート条件を返す。
     * 
     * @return
     */
    private static String getAddOrder() {
        return PhoenixUtil.isTestMode() ? "" : RELEASE_ORDER;
    }

}
