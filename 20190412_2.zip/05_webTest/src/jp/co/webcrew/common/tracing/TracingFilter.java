package jp.co.webcrew.common.tracing;

import generator.runtime.exception.ApplicationException;
import generator.runtime.servlet.ContextInitializer;
import generator.runtime.utils.ApplicationProperties;
import generator.runtime.utils.ResourceApplicationProperties;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Filter implementation of the tracer logic. The allows us to trace 
 * objects outside of struts
 */
public abstract class TracingFilter implements Filter, Trace {

    /** �v�����[�V�����R�[�h�̎w�肪�����ꍇ�̕����� */
    public static final String DEFAULT_PROM_CODE = "aa000";
    
    protected ServletContext context;
    
    /**
     * Set up the filter parameters - basically just the resource bundle name
     */
    public void init(FilterConfig config) throws ServletException {
        this.context = config.getServletContext();
        
    }

    /**
     * Remove any setup data, so we can reuse
     */
    public void destroy() {
        this.context = null;
    }
    
    protected ServletContext getServletContext() {
        return this.context;
    }
    
    /**
     * Filter execution method. Call processTraceRequest first, then the 
     * requested resource, followed by processTraceComplete. The effect
     * is to wrap the tracing around a request.
     */
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
        try {
            processTraceRequest((HttpServletRequest) request, 
                    (HttpServletResponse) response);
        } catch (Exception err) {
            throw new ApplicationException("Error in processTraceRequest", err);
        }
        
        chain.doFilter(request, response);
        
        try {
            processTraceComplete((HttpServletRequest) request);
        } catch (Exception err) {
            throw new ApplicationException("Error in processTraceRequest", err);
        }
    }

    /**
     * The start of the trace. Sets a cookie for tracking purposes.
     */
    protected void processTraceRequest(
            HttpServletRequest request,
            HttpServletResponse response
            ) throws Exception {
                
        String promoid = null;
        boolean notCookie = true;

        ApplicationProperties resources = (ApplicationProperties) 
                this.context.getAttribute(ContextInitializer.ATTR_PROPS);
        if (resources == null) {
            resources = new ResourceApplicationProperties("tracingFilter", null);
        }
        
        String promoKey      = resources.get("trace.promoKey");
        String expiryTimeKey = resources.get("trace.expiryTimeKey");
        String promoExpDays  = resources.get("trace.promoExpDays.default");
        String cookieName    = resources.get("trace.promoCookie.name");
        
        // url�X�g�����O��promoKey���܂܂�Ă���ꍇ
        // cookie�Ɋւ�炸�㏑��
        if ((promoKey != null) && !promoKey.equals("")) {
            promoid = getParameterIgnoreCase(request, promoKey);
            
            // cookie�����ݒ�B ����ꍇ�̂�
            String expiryTime = getParameterIgnoreCase(request, expiryTimeKey);
            if ((expiryTime != null) && !expiryTime.equals("")) {
                promoExpDays = expiryTime; 
            }
        } 
        
        if ((promoid == null) || promoid.equals("")) {
            // url�X�g�����O��promoKey���܂܂�Ă��Ȃ��ꍇ
            // cookie������΂Ȃɂ������B
            Cookie[] cookies = request.getCookies();
            if (cookies != null) {
                for (int i = 0; i < cookies.length; i++) {
                    String cname = cookies[i].getName();
                    if (cname.equalsIgnoreCase(cookieName)) {
                        notCookie = false;
                        promoid = cookies[i].getValue();
                        break;
                    }
                }
            }
            
            // url�ɂ�cookie�ɂ��Ȃ���΃f�t�H���g�̒l���Z�b�g
            if (notCookie) {
                promoid = DEFAULT_PROM_CODE;
            }
            
        }
        
        if (notCookie){
            // Set cookie only at the first referral
            float expdays = Float.parseFloat(promoExpDays);
            Cookie c = new Cookie(cookieName, promoid);
            c.setPath("/");
            c.setMaxAge(Math.round(expdays * 24 * 60 * 60));
        
            response.addCookie(c);
        
        }
        
        String pathInfo = request.getPathInfo();
        String path = request.getServletPath() + (pathInfo != null ? pathInfo : "");
        
        traceRequest(request, path, promoid);
    }

    /**
     * Record the end of the trace
     */
    protected void processTraceComplete(
            HttpServletRequest request)
            throws Exception {
        traceComplete(request);
    }

    /**
     * Override this method to record the start of the trace
     */
    public abstract void traceRequest(HttpServletRequest request, String path, 
            String promoCode);
    
    /**
     * Override this method to record the end of the trace. Note that the 
     * mapping and forward params are deprecated and passed in as null.
     */
    public abstract void traceComplete(HttpServletRequest request);

    /**
     * �w�肳�ꂽ�L�[��IgnoreCase�ŒT���A���̒l�����N�G�X�g�p�����[�^������o��
     * @param request
     * @param promoKey
     * @return
     */
    public static String getParameterIgnoreCase( HttpServletRequest request, String promoKey ) {
        
        String ret = null;
        Enumeration enum1 = request.getParameterNames() ;
        
        if ( promoKey != null ) {
            while ( enum1.hasMoreElements() )  {
                String key = (String)enum1.nextElement();
                if ( promoKey.equalsIgnoreCase( key )) {
                    String value = request.getParameter( key );
                    ret = value;
                }
            }
        }
        return ret;
    }
    
}
