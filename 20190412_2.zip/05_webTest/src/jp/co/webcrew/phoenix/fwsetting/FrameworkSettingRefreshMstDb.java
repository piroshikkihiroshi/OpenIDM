package jp.co.webcrew.phoenix.fwsetting;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.DBAccessCloseChecker;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.perflog.PerfLogger;
import jp.co.webcrew.phoenix.htmlservlet.HtmlPropertiesUtil;
//import jp.co.webcrew.phoenix.store.db.SessionStoreDb2;

public class FrameworkSettingRefreshMstDb extends RefreshMstDb
{
	
	private static Logger logger=Logger.getLogger(FrameworkSettingRefreshMstDb.class);
	
	private static FrameworkSettingRefreshMstDb thisObject=new FrameworkSettingRefreshMstDb();
	
	
	public static FrameworkSettingRefreshMstDb getInstance()
	{
		return thisObject;
	}
	
	
	private boolean enablePerfLog=false;
	private Map<String, String> dataMap=null;
	
	public static final String YES="yes";
	
	
	@Override
	public void init() throws SQLException 
	{
		
		DBAccess dbAccess=null;
		ResultSet rset=null;
		
		final String SQL_GET_RECID="SELECT REC_ID FROM COMMON_PHOENIX.CLM_DATA " +
				"WHERE SITE_ID=? AND TBL_ID=? AND CLM_ID=? AND KEY_DATA=?";
		
		final String SQL_GET_DATA="SELECT REC_ID,CLM_ID,KEY_DATA FROM COMMON_PHOENIX.CLM_DATA " +
				"WHERE SITE_ID=? AND TBL_ID=? AND REC_ID IN(" +
				"SELECT REC_ID FROM COMMON_PHOENIX.REC_META_DATA " +
				"WHERE SITE_ID=? AND TBL_ID=? AND REC_ID=? " +
				"AND PUB_FLAG=1 " +
				"AND BGN_DATETIME <= TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') " +
				"AND END_DATETIME >= TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS')  " +
				")ORDER BY REC_ID";
		
		int siteId=800;
		String tableId="framework_setting_info";
		String searchClmId="key";
		
		
		try
		{
			HtmlPropertiesUtil prop = new HtmlPropertiesUtil("html_servlet.properties");
			String searchClmValue=ValueUtil.nullToStr(prop.getProperty("framework_setting_info.key"));
			if(searchClmValue.length()==0)
			{
				searchClmValue="default";
			}
			
			dbAccess=new DBAccess("phoenix");
			dbAccess.prepareStatement(SQL_GET_RECID);
			dbAccess.setInt(1, siteId);
			dbAccess.setString(2, tableId);
			dbAccess.setString(3, searchClmId);
			dbAccess.setString(4, searchClmValue);

			rset=dbAccess.executeQuery();
			
			long recId=0;
			if(rset.next())
			{
				recId=rset.getLong("REC_ID");
			}
			else
			{
				recId=-1;
			}
			DBAccess.close(rset);
			
			dbAccess.prepareStatement(SQL_GET_DATA);
			dbAccess.setInt(1, siteId);
			dbAccess.setString(2, tableId);
			dbAccess.setInt(3, siteId);
			dbAccess.setString(4, tableId);
			dbAccess.setLong(5, recId);
			
			rset=dbAccess.executeQuery();
			Map<String,String> map=new HashMap<String, String>();
			
			while(rset.next())
			{
				map.put(rset.getString("CLM_ID"), ValueUtil.nullToStr(rset.getString("KEY_DATA")));
			}
			DBAccess.close(rset);
			
			//logger.info("[mapdata]"+map.toString());
			
			this.dataMap=map;
			String perflog_enabled=this.getPropValue("perflog_enabled");
			String perflog_forceoneline=this.getPropValue("perflog_forceoneline");
			String db_closecheck_enabled=this.getPropValue("db_closecheck_enabled");
			int db_closecheck_waitmsec=this.getPropIntValue("db_closecheck_waitmsec",10000);
			String session_store_use_blob=this.getPropValue("session_store_use_blob");
			int session_store_rawlimit=this.getPropIntValue("session_store_rawlimit",1024);
			int perflog_frequency=this.getPropIntValue("perflog_frequency",0);
			
			String enableSuffixes=this.getPropValue("perflog_enable_suffixes");
			String enableUrlPrefixes=this.getPropValue("perflog_enable_url_prefixes");
			/*
			//空行除外処理
			String[] array=enableSuffixes.split("\r\n|\r|\n");
			List<String> list=new ArrayList<String>();
			for(String item:array)
			{
				if(ValueUtil.nullToStr(item).length()!=0)
				{
					list.add(item);
				}
			}
			String[] array2=new String[list.size()];
			list.toArray(array2);
			*/
			String[] array_enableSuffixes=getStringArray(enableSuffixes);
			String[] array_enableUrlPrefixes=getStringArray(enableUrlPrefixes);
			
			
			if(perflog_enabled.equals(YES))
			{
				logger.info("perflogは有効にします。[改行変換]"+perflog_forceoneline+"[頻度]"+perflog_frequency+"\n[suffix]"+Arrays.asList(array_enableSuffixes)+"\n[prefix]"+Arrays.asList(array_enableUrlPrefixes));
				if(perflog_forceoneline.equals(YES))
				{
					PerfLogger.doEnable(true,perflog_frequency,array_enableSuffixes,array_enableUrlPrefixes);
				}
				else
				{
					PerfLogger.doEnable(false,perflog_frequency,array_enableSuffixes,array_enableUrlPrefixes);
				}
				enablePerfLog=true;
			}
			else
			{
				logger.info("perflogは無効にします。");
				PerfLogger.doDisable();
				enablePerfLog=false;
			}
			if(db_closecheck_enabled.equals(YES))
			{
				logger.info("db閉じ忘れチェックは有効にします。[待ミリ秒]"+db_closecheck_waitmsec);
				DBAccessCloseChecker.doEnable(db_closecheck_waitmsec);
				enablePerfLog=true;
			}
			else
			{
				logger.info("db閉じ忘れチェックは無効にします。");
				DBAccessCloseChecker.doDisable();
				enablePerfLog=false;
			}
			/*
			今回は実装しないのでコメント化
			if(session_store_use_blob.equals(YES))
			{
				logger.info("sessionstoreはBlob(カラム:store_blob)に書き込みます。rawの上限"+session_store_rawlimit);
				SessionStoreDb2.setUseBlob(session_store_rawlimit);
			}
			else
			{
				logger.info("sessionstoreはClob(カラム:store)を書き込みます。");
				SessionStoreDb2.setUseClob();
			}
			*/
			
			
		}
		catch(Exception exc)
		{
			logger.error("DebugInfoRefreshMstDbでエラー検知",exc);
		}
		finally
		{
			DBAccess.close(rset);
			DBAccess.close(dbAccess);
		}
	}
	
	public String getPropValue(String key)
	{
		if(this.dataMap==null)return "";
		return ValueUtil.nullToStr(this.dataMap.get(key));
	}
	
	
	public int getPropIntValue(String key,int defaultValue)
	{
		if(this.dataMap==null)return defaultValue;
		String val=ValueUtil.nullToStr(this.dataMap.get(key));
		if(val.length()==0)
		{
			return defaultValue;
		}
		try
		{
			return Integer.parseInt(val);
		}
		catch(Exception exc)
		{
			return defaultValue;
		}
	}
	
	
	private static String[] getStringArray(String source)
	{
		//空行除外処理
		String[] array=source.split("\r\n|\r|\n");
		List<String> list=new ArrayList<String>();
		for(String item:array)
		{
			if(ValueUtil.nullToStr(item).length()!=0)
			{
				list.add(item);
			}
		}
		String[] array2=new String[list.size()];
		list.toArray(array2);
		return array2;
	}
	
	
}
