package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;

/**
 * クリックリサーチのカテゴリ情報を管理するためのdbクラス。
 * 
 * @author 
 */
public class CResearchCategoryDb extends RefreshMstDb {
  /** ロガー */
  private static final Logger log = Logger.getLogger(CResearchCategoryDb.class);
  
  /** 唯一のインスタンス */
  private static final CResearchCategoryDb instance = new CResearchCategoryDb();
  
  /** カテゴリIDと名前を保持するマップ */
  private Map categoryMap = new LinkedHashMap(); 
  
  /** カテゴリ情報を取得する */
  public static final String SELECT_CATEGORY_MST = ""
	+ "SELECT category_id, category_name FROM cresearch_category_mst ORDER BY sort";
    //+ "SELECT category_id, category_name FROM cresearch_category_mst ORDER BY category_id";
  
  /**
   * コンストラクタ
   *
   */
  private CResearchCategoryDb() {
    try {
      init();
    } catch (SQLException e) {
      log.error("DBエラー", e);
    }
  }
  
  /**
   * インスタンスを取得する
   */
  public static CResearchCategoryDb getInstance() {
    return instance;
  }
  
  /**
   * カテゴリ情報を取得する
   */
  public void init() throws SQLException {
    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();
      
      rs = dbAccess.executeQuery(SELECT_CATEGORY_MST);
      
      Map tempCategoryMap = new LinkedHashMap();
      while(dbAccess.next(rs)) {
        tempCategoryMap.put(rs.getString("category_id"), rs.getString("category_name"));
      }
      
      categoryMap.putAll(tempCategoryMap);
      
    } catch(SQLException se) {
      log.error("カテゴリ情報を取得出来ませんでした", se);
      throw se;
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }

  /**
   * カテゴリ情報を保持したマップを取得する
   * 
   * @return
   */
  public Map getCategoryMap() {
    return categoryMap;
  }
}
