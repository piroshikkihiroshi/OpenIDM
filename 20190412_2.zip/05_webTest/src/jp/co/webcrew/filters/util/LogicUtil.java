package jp.co.webcrew.filters.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.htmlservlet.DateUtil;

public class LogicUtil {
    
    public static final int YYYYMMDDHH24MSS_WITH_SLUSH = 1;
    private static final Logger log = Logger.getLogger(LogicUtil.class);
    
    /**
     * -Dシステムプロパティから「testMode」プロパティを取得し、
     * テスト機か本番機かを判定する。
     * @return
     */
    public static boolean isProductionEnv() 
    {
        String strMode = System.getProperty("testMode");
        if( strMode != null && strMode.equals("1")) 
        {
            // テスト機
            return false;
        } else {
            // 本番機
            return true;
        }
    }
    
    /**
     * 仮想テーブルの検索を指定された条件で実行する。
     * 本番機の場合は、公開データのみを抽出するようにする。
     * @param db PhoenixDBAccess
     * @param nSiteId サイトＩＤ
     * @param strTableName 検索対象のテーブル名
     * @param strCondition 検索条件
     * @return ResultSet 検索結果
     * @throws SQLException
     */
    public static ResultSet query(PhoenixDBAccess db, int nSiteId, String strTableName, String strCondition) throws SQLException {
        String strNow = DateUtil.currentDateTime();
        String strSql = "";
        if (isProductionEnv()) 
        {
            strSql = " select data.* \n"
                +   " from \n"
                +   "  (schema_name).clm_data data, \n"
                +   "  (schema_name).rec_meta_data meta \n"
                +   " where \n"
                +   "   meta.site_id=data.site_id \n"
                +   " and \n"
                +   "   meta.tbl_id=data.tbl_id \n"
                +   " and \n"
                +   "   meta.rec_id=data.rec_id \n"
                +   " and \n"
                +   "   meta.pub_flag='1' \n"
                +   " and \n"
                +   "  (meta.bgn_datetime <= ? and ? <= meta.end_datetime) \n"
                +   " and \n"
                +   "  data.site_id=? \n"
                +   " and \n"
                +   "  data.tbl_id=? \n"
                +   strCondition
                +   " order by data.rec_id asc,data.sort_num asc ";
   
            db.prepareStatement(strSql);
            db.setString(1, strNow);
            db.setString(2, strNow);
            db.setInt   (3, nSiteId);
            db.setString(4, strTableName);
            
        } else {
            strSql = "select data.* \n "
                + "from (schema_name).clm_data data \n"
                +   " where \n"
                +   "  site_id=? \n"
                +   " and \n" 
                +   "  tbl_id=? \n"
                +   strCondition
                +   " order by rec_id asc,sort_num asc";
   
            db.prepareStatement(strSql);
            db.setInt(1, nSiteId);
            db.setString(2, strTableName);
            
            log.info("QUERY2 = "+strSql);
            log.info("nSiteId = "+nSiteId);
            log.info("strTableName = "+strTableName);
        }
        return db.executeQuery();
    }
   
    /**
     * 指定されたlistの中から、指定したrecIdに合致するRowDataを検索し返す。
     * @param lstData RowDataのリスト
     * @param sreRecId レコードＩＤ
     * @return RowData 指定したレコードＩＤに対応するもの
     */
    public static RowData searchRowData(List lstData , Long sreRecId){
        
        if (lstData == null) return null;
        
        if (lstData.size() == 0 ) return null;
        
        for(Iterator iterator = lstData.iterator() ; iterator.hasNext();) 
        {
            RowData objRowData = (RowData)iterator.next();
            if (objRowData.getRecId().longValue() == sreRecId.longValue()) {
                return objRowData;
            }
        }
        
        return null;
    }
    
    /**
     * 指定された仮想テーブル検索結果を、RowDataのリストに対して登録する。
     * １レコード（recIdで識別）単位でRowDataが作成され、それがレコード数分
     * だけlistに追加されていく。
     * 仮想テーブル検索用にしか利用できないので注意。
     * 
     * @param lstData RowDataのリスト
     * @param lngRecId レコードＩＤ
     * @param strColumnName カラム名
     * @param strKeyData カラムの値（512kまで）
     * @param strLobData カラムの値から溢れたlobData
     * @param strUpDatetime
     */
    public static void setRowData(List lstData , Long lngRecId , String strColumnName , String strKeyData , String strLobData , String strUpDatetime) {
                
        if (lstData == null) lstData = new ArrayList();

        // listからrecIdに該当するrowdataを検索して取得する。なければ新規作成して追加
        RowData objRowData = searchRowData(lstData, lngRecId);
        
        if (objRowData == null) 
        {
            objRowData = new RowData();
            objRowData.setRecId(lngRecId);
            lstData.add(objRowData);
        }
        
        // rowdata に列の値を追加する
        objRowData.set(strColumnName , strKeyData , strLobData , strUpDatetime);
    }
}
