PostgreSQL OLE DB Provider
==========================

This is open source OLE DB provider for PostgreSQL database. It can be used to connect
a PostgreSQL database from an application via ADO or ADO.NET. The modules are compiled
with MinGW64 as both 32bit and 64bit version. They can both coexist on the same machine,
however each module must be copied and registered separately.

Installation
------------
Copy PMDAPGS.dll somewhere and run regsvr32 on it (note, regsvr32 must be run "as adminitrator"
on Windows Vista and newer if the UAC is set on). It can be placed in arbitrary location,
the only restriction is that a process using this library must have read access to that
folder. However, the preferred location for OLE DB modules is

"<Program_Files_Folder>\Common Files\System\Ole DB" for 32bit driver on 32bit system
and 64bit driver on 64bit system, and

"<Program_Files_Folder (x86)>\Common Files\System\Ole DB" for 32bit driver on 64bit system


Usage
-----
The connection string for your ADO Connection is:

"Provider=PMDAPGS;Server=<server_name>;Database=<db_name>;User=<user>;Password=<password>;Port=<port>"

Port can be ommitted. Server should be either a name listed in hosts file, or the IP address.

The driver only supports the user/password client athentication method fro PostgreSQL.


The debug file
--------------
There is also a "debug" version of the OLE DB provider dll named PMDAPGS.dll.debug. This version
creates a log file where most of the automation calls to the library are recorded. The logging
has a big performance impact, so use it with cation.

To use the debug version, rename PMDAPGS.dll to something else, e.g. PMDAPGS.dll.release, and
rename the .debug file to PMDAPGS.dll. No regsvr32 re-registration is needed. Then run your
application and the log should be created in the same directory where PMDAPGS.dll resides.
Please note that the process using PMDAPGS.dll must have read/WRITE access to that directory
in this case.
