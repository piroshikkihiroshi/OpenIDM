package jp.co.webcrew.filters.filters.replace.replacer;

import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 置換処理を行うクラスのためのreplacerインターフェース
 * 
 * @author kurinami
 */
abstract public class Replacer {

	/**
	 * 初期化処理を行う。
	 * 
	 * @param filterConfig
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	/**
	 * <pre>
	 *     sourceで渡されるhtmlのコンテンツを
	 *     requetとresponseを元に必要の箇所を置換し、
	 *     置換した結果を返す。
	 * </pre>
	 * 
	 * @param source
	 * @param request
	 * @param response
	 * @return
	 */
	abstract public String replace(String source, HttpServletRequest request,
			HttpServletResponse response);

}
