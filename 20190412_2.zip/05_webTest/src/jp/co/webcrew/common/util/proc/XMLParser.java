package jp.co.webcrew.common.util.proc;

import org.w3c.dom.Document;

import org.xml.sax.InputSource;

import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


public class XMLParser {
    public static Document parseXML(String inputXML) {
        try {
            // Use JAXP to create a document builder
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setExpandEntityReferences(false);
            builderFactory.setValidating(false);
            builderFactory.setNamespaceAware(false);
            builderFactory.setIgnoringComments(true);
            builderFactory.setCoalescing(true);
            builderFactory.setIgnoringElementContentWhitespace(true);

            DocumentBuilder builder = builderFactory.newDocumentBuilder();

            // Get the XML as an input stream
            Reader input = new StringReader(inputXML);

            return builder.parse(new InputSource(input));
        } catch (Throwable err) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            err.printStackTrace(pw);
            throw new RuntimeException("Error - could not parseXML." +
                "\nStacktrace: " + sw.toString());
        }
    }
}
