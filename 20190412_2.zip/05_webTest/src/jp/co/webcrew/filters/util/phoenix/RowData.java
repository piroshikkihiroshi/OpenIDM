package jp.co.webcrew.filters.util.phoenix;

import java.util.HashMap;
import java.util.Map;

public class RowData  {
    private Long   recId;
    Map colData;
    String upDatetime;
    
    public void set (String colName , String keyData , String lobData , String up_datetime) {
        if (lobData == null || lobData.length() == 0) {
            getColData().put(colName, keyData);
        } else {
            getColData().put(colName, lobData);
        }
        if (up_datetime != null) {
            if (upDatetime == null) {
                upDatetime = up_datetime;
            }
        }
    }

    public void set (String colName , String keyData , String lobData) {
        set (colName , keyData , lobData , null);
    }

    
    public String get(String key) {
        return (String)getColData().get(key);
    }
    
    public Map getColData() {
        if (colData == null) {
            colData = new HashMap();
        }
        return colData;
    }
    
    public String getUpdatetime() {
        return upDatetime;
    }
    
    public Long getRecId() {
        return this.recId;
    }
    
    public void setRecId(Long recId) {
        this.recId = recId;
    }
}