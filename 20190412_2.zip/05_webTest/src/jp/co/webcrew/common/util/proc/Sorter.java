package jp.co.webcrew.common.util.proc;


/**
 * Replacement for the Arrays.sort method.
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: Sorter.java,v 1.1 2004-09-15 08:37:11 rickk Exp $
 */
public class Sorter {
    /**
     * This is meant to be a replacement for the JDK1.2 Arrays.sort()
     * method, since we don't have that in 1.1.
     *
     * Modified from James Gosling's implementation:
     * http://www.cs.ubc.ca/spider/harrison/Java/QSortAlgorithm.java.html
     */
    public static void arraySort(Object[] array, Comparator comparator,
        int startIndex, int endIndex) {
        int lo = startIndex;
        int hi = endIndex;

        if (lo >= hi) {
            return;
        } else if (lo == (hi - 1)) {
            /*
                 *  sort a two element list by swapping if necessary
                 */
            if (comparator.compare(array[lo], array[hi]) > 0) {
                Object T = array[lo];
                array[lo] = array[hi];
                array[hi] = T;
            }

            return;
        }

        /*
             *  Pick a pivot and move it out of the way
             */
        Object pivot = array[(lo + hi) / 2];
        array[(lo + hi) / 2] = array[hi];
        array[hi] = pivot;

        while (lo < hi) {
            /*
                 *  Search forward from a[lo] until an element is found that
                 *  is greater than the pivot or lo >= hi
                 */
            while ((comparator.compare(array[lo], pivot) <= 0) && (lo < hi)) {
                lo++;
            }

            /*
                 *  Search backward from a[hi] until element is found that
                 *  is less than the pivot, or lo >= hi
                 */
            while ((comparator.compare(pivot, array[hi]) <= 0) && (lo < hi)) {
                hi--;
            }

            /*
                 *  Swap elements a[lo] and a[hi]
                 */
            if (lo < hi) {
                Object T = array[lo];
                array[lo] = array[hi];
                array[hi] = T;
            }
        }

        /*
             *  Put the median in the "center" of the list
             */
        array[endIndex] = array[hi];
        array[hi] = pivot;

        /*
             *  Recursive calls, elements a[lo0] to a[lo-1] are less than or
             *  equal to pivot, elements a[hi+1] to a[hi0] are greater than
             *  pivot.
             */
        arraySort(array, comparator, startIndex, lo - 1);
        arraySort(array, comparator, hi + 1, endIndex);
    }
}
