package jp.co.webcrew.filters.filters.replace.htmlparser;

import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.filters.session.SessionFilter;

/**
 * <pre>
 *          クッキーが使えない環境のために
 *          html内の各リンクのリクエストパラメータに
 *          ローカルセッションコードを付与するcallbackクラス。
 * </pre>
 * 
 * @author kurinami
 */
public class LsCodeReplaceParserCallback extends HtmlReplaceParserCallback {

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(LsCodeReplaceParserCallback.class);

	/** 置換対象となるタグ名とそのタグの中の属性のマップ */
	private static final Map targetMap = new HashMap();

	/** 付加するローカルセッションコード */
	private String lsCode = "";

	static {
		targetMap.put("a", "href");
		targetMap.put("area", "href");
		targetMap.put("frame", "src");
		targetMap.put("iframe", "src");
		targetMap.put("form", "action");
		// TODO kurinami 【確認】 targetMap.put("fieldset", "action");
	}

	public LsCodeReplaceParserCallback(String lsCode) {
		this.lsCode = lsCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.HtmlReplaceParserCallback#handleStartTag(java.lang.String)
	 */
	public String handleStartTag(String data) {

		int fromIndex = 0;
		int toIndex;

		// タグ名の開始位置を求める。
		fromIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
				HtmlReplaceParser.TOKEN_SEP_CHARS);

		// タグ名が存在しない場合、
		if (fromIndex >= data.length() || data.charAt(fromIndex) == '>') {
			return data;
		}

		// タグ名を求める。
		toIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
				HtmlReplaceParser.TOKEN_SEP_CHARS);
		String tagName = data.substring(fromIndex, toIndex).trim()
				.toLowerCase();

		// タグが処理対象のものか確認する。
		if (!targetMap.containsKey(tagName)) {
			return data;
		}

		StringBuffer sb = new StringBuffer();
		String temp;

		// 現在の位置までを処理結果に格納する。
		sb.append(data.substring(0, toIndex));
		fromIndex = toIndex;

		// 置換対象の属性名を求める。
		String targetAttributeName = (String) targetMap.get(tagName);

		// 属性を順に処理していく。
		while (!(fromIndex >= data.length() || data.charAt(fromIndex) == '>')) {

			// 属性名を処理結果に格納する。
			toIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
					HtmlReplaceParser.TOKEN_SEP_CHARS);
			temp = data.substring(fromIndex, toIndex);
			sb.append(temp);
			fromIndex = toIndex;

			// 属性名を求める。
			String attributeName = temp.trim().toLowerCase();

			// 属性値が存在する場合、
			if (fromIndex < data.length() && data.charAt(fromIndex) == '=') {

				// 「=」部分を処理結果に格納する。
				toIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
						HtmlReplaceParser.TOKEN_SEP_CHARS);
				temp = data.substring(fromIndex, toIndex);
				sb.append(temp);
				fromIndex = toIndex;

				if (!(fromIndex >= data.length() || data.charAt(fromIndex) == '>')) {

					// 属性地を処理結果に格納する。
					toIndex = HtmlReplaceParser.nextTokenPos(data, fromIndex,
							HtmlReplaceParser.TOKEN_SEP_CHARS);
					temp = data.substring(fromIndex, toIndex);
					if (targetAttributeName.equals(attributeName)) {
						// 置換対象属性の場合、属性値を置換する。
						temp = replaceValue(temp);
					}
					sb.append(temp);

					fromIndex = toIndex;

				}
			}
		}

		// 最後の「>」の部分を処理結果に格納する。
		if (fromIndex < data.length()) {
			sb.append(data.substring(fromIndex));
		}

		return sb.toString();
	}

	/**
	 * urlにセッションIDをパラメータとして追加する。
	 * 
	 * @param data
	 * @return
	 */
	private String replaceValue(String data) {

		// 属性値の部分を抜き出す。
		String value = data.trim();

		// 属性値の後の空白部分を抜き出す。
		String blank = data.substring(value.length());

		// 属性値が引用符でくくられている場合、引用符とその中身を分ける。
		String quoteCh = "";
		if (HtmlReplaceParser.contains(value.charAt(0),
				HtmlReplaceParser.QUOTE_CHARS)) {

			// 引用符が1つしかなかったり、開始と終了の引用符が違う場合、
			if (value.length() == 1
					|| value.charAt(0) != value.charAt(value.length() - 1)) {
				// 置換不可能として、そのまま返す。
				return data;
			}

			quoteCh = Character.toString(value.charAt(0));
			value = value.substring(1, value.length() - 1).trim();
		}

//		// 属性値が無かったり、ページ内リンクだったり、javascriptの場合、
//		if (value.length() == 0 
//			|| value.charAt(0) == '#'
//			|| value.toLowerCase().startsWith("javascript")) {
//			// 置換不要として、そのまま返す。
//			return data;
//		}
		
		// 属性値をみて置換の必要性をチェックする
		if(!isNeedReplace(value)) {
			return data;
		}

		// URLを組み立てる。
		StringBuffer sb = new StringBuffer();
		sb.append(quoteCh);
		sb.append(addParameter(value, lsCode));
		sb.append(quoteCh);
		sb.append(blank);

		// 結果を返す。
		return sb.toString();
	}
	
	/**
	 * 置換の必要性を判定する。
	 * 判定条件は下記の通り。
	 * 
	 * 1. 文字列[data] が長さ 0 まはた # で始まっていたら置換対象外。
	 * 2. 文字列[data] が http: または https: で始まってなく、
	 *    かつ、文字列中に ? や / よりも前側に : が存在しない場合は置換対象外。
	 * 3. 1,2以外の場合は置換対象。
	 * 
	 * @param data 判定対象文字列
	 * @return true:必要あり, false:必要なし
	 */
	private boolean isNeedReplace(String data) {
		
		boolean replaceFlg = true;
		
		// 長さ 0 まはた # で始まっていたら置換対象外
		if(data.length() == 0 || data.startsWith("#")) {
			replaceFlg = false;
			
			return replaceFlg;
		}
		
		// http: or https: で始まって
		if(!data.startsWith("http:") && !data.startsWith("https:")) {
			// いなかったら
			boolean charFlg = false;
			for(int index=0; index<data.length(); index++ ){
				if(data.charAt(index) == '?' || data.charAt(index) == '/') {
					charFlg = true;
				} else if (data.charAt(index) == ':') {
					// ':' の前に '?' または '/' が無い場合は
					if(!charFlg) {
						// 置換しない
						replaceFlg = false;
					}
					break;
				}
			}
		}
		
		return replaceFlg;
	}

	/**
	 * URLにパラメータをつけて返す。
	 * 
	 * @param url
	 * @param lsCode
	 * @return
	 */
	public static String addParameter(String url, String lsCode) {

		log.info("start addParameter [url: " + url + "]  [ls_code: " + lsCode
				+ "]");

		// 外部サイトの場合は、パラメータをつけない。
		if ((url.startsWith("http://") || url.startsWith("https://"))
				&& SiteMstDb.getInstance().getSiteId(url) == SiteMstDb.OUTSIDE_SITE_ID) {
			log.info("外部サイト向けのためパラメータを付加せず。");
			return url;
		}

		// 追加するパラメータをURLにつなげるときの文字を求める。
		String connectCh = "";
		if (!HtmlReplaceParser.contains(url.charAt(url.length() - 1),
				new char[] { '?', '&' })) {
			connectCh = url.indexOf('?') < 0 ? "?" : "&";
		}

		// URLにパラメータをつける。
		log.info("内部サイト向けのためパラメータを付加した。");
		StringBuffer sb = new StringBuffer();
		sb.append(url);
		sb.append(connectCh);
		sb.append(SessionFilter.LS_CODE_PARAM_KEY);
		sb.append("=");
		sb.append(lsCode);

		return sb.toString();
	}

}
