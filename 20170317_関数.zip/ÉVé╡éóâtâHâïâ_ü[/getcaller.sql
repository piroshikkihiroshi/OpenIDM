
declare
	cur  refcursor;
	ret  integer;
	l_returnValue  text;
	--ret	text;
begin
	
	-- callertmptable ���݊m�F
	SELECT "relname" into l_returnValue FROM "pg_class" WHERE "relkind" = 'r' AND "relname" = 'callertmptable' ;
	
	if (l_returnValue is null) then
 	   return null;
	end if;
	
	SELECT "l_caller" into l_returnValue FROM "callertmptable"  ;
	
	if (l_returnValue = 'null') then
		l_returnValue = null;
	end if;
	
	return l_returnValue;
    
end;    
