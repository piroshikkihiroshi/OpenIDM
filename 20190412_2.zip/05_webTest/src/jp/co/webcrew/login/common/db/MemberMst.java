package jp.co.webcrew.login.common.db;

import java.io.Serializable;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.State3;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.point.ContractPointUtil;
import jp.co.webcrew.login.common.point.PointUtilRenewal;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;
import jp.co.webcrew.login.common.util.StringUtil;

public class MemberMst extends DBEntity implements Serializable {
	/** ロガー */
	private static final Logger log = Logger.getLogger(MemberMst.class);

	/** テーブル名 */
	public static final String TABLE = "MEMBER_MST"; 

	/** メールタイプ：PC */
	public static final int TYPE_PC_MAIL = 0;

	/** メールタイプ：携帯 */
	public static final int TYPE_MB_MAIL = 1;
	
	/** メールタイプ：法人 */
	public static final int TYPE_CP_MAIL = 2;
	
	/** フラグ有効 */
	public static final String FLG_INVALID_ON    = "1";
	/** フラグ無効 */
	public static final String FLG_INVALID_OFF   = "0";
	/** 本登録フラグオン（本登録） */
	public static final String FLG_FORMAL_ON     = "1";
	/** 本登録フラグオフ（仮登録） */
	public static final String FLG_FORMAL_OFF    = "0";
	/** 法人フラグオン（法人） */
	public static final String FLG_COP_FLAG_ON   = "1";
	/** 法人フラグオフ（非法人） */
	public static final String FLG_COP_FLAG_OFF  = "0";
	/** 法人フラグオフ（非法人） */
	public static final String FLG_AFFILIATE_FLAG_OFF = "0";
	/** メルマガ登録フラグON */
	public static final String FLG_MAG_FLAG_ON   = "1";
	/** メルマガ登録フラグOFF */
	public static final String FLG_MAG_FLAG_OFF  = "0";

	/** メインのメールアドレス：ＰＣ */
	public static final String FLG_PRIMARY_EMAIL_PC = "0";

	/** メインのメールアドレス：携帯 */
	public static final String FLG_PRIMARY_EMAIL_MB = "1";

	/** メインのメールアドレス：会社 */
	public static final String FLG_PRIMARY_EMAIL_CP = "2";

	/** リマインダフラグON(リマインダメール送信済) */
	public static final String FLG_REMINDER_SENT = "1";
	/** リマインダOFF(未送信もしくは再登録済） */
	public static final String FLG_REMINDER_NOT_SENT_OR_REGISTERD = "0";
    /** お住まいの形態：所有 */
    public static final String FLG_SUMAI_KEITAI_OWNERSHIP = "1";
    /** お住まいの形態：賃貸 */
    public static final String FLG_SUMAI_KEITAI_RENT = "2";
    /** バック持っているか 1：あり */
    public static final String FLG_HAVE_BIKE_YES = "1";
    /** バック持っているか 2：なし */
    public static final String FLG_HAVE_BIKE_NO = "2";
    
	/*
	 * 列定義
	 */
	public final static String GUID     = "GUID"; 
	public final static String PASSWD   = "PASSWD"; 
	public final static String NICKNAME = "NICKNAME"; 
	public final static String NAME1    = "NAME1"; 
	public final static String NAME2    = "NAME2"; 
	public final static String FURI1    = "FURI1"; 
	public final static String FURI2    = "FURI2"; 
	public final static String ZIP      = "ZIP"; 
	public final static String PREF_ID  = "PREF_ID"; 
	public final static String ADDR1    = "ADDR1"; 
	public final static String ADDR2    = "ADDR2"; 
	public final static String ADDR3    = "ADDR3"; 
	public final static String ADDR4    = "ADDR4"; 
	public final static String ADDR5    = "ADDR5"; 
	public final static String BIRTHDAY = "BIRTHDAY"; 
	public final static String SEX_ID   = "SEX_ID"; 
	public final static String TEL      = "TEL"; 
	public final static String MOBILE   = "MOBILE"; 
//	public final static String FAX = "FAX"; 
	public final static String EMAIL    = "EMAIL"; 
	public final static String MB_MAIL  = "MB_MAIL"; 
	public final static String CP_MAIL  = "CP_MAIL"; 
	public final static String COMPANY  = "COMPANY"; 
	public final static String PRIMARY_EMAIL  = "PRIMARY_EMAIL"; 
	public final static String CP_TEL   = "CP_TEL"; 
	public final static String CP_ZIP   = "CP_ZIP"; 
	public final static String CP_PREF_ID  = "CP_PREF_ID"; 
	public final static String CP_ADDR1 = "CP_ADDR1"; 
	public final static String CP_ADDR2 = "CP_ADDR2"; 
	public final static String CP_ADDR3 = "CP_ADDR3"; 
	public final static String CP_ADDR4 = "CP_ADDR4"; 
	public final static String CP_ADDR5 = "CP_ADDR5"; 
	public final static String COP_FLAG = "COP_FLAG"; 
	public final static String CONSORT  = "CONSORT"; 
	public final static String CHILDREN = "CHILDREN"; 
	public final static String PARENT   = "PARENT"; 
	public final static String INCOME_KBN     = "INCOME_KBN"; 
	public final static String FORMAL_FLAG    = "FORMAL_FLAG"; 
	public final static String LIMIT_DATETIME = "LIMIT_DATETIME"; 
	public final static String REMINDER_FLAG  = "REMINDER_FLAG"; 
	public final static String RM_DATETIME    = "RM_DATETIME"; 
	public final static String AF_CODE        = "AF_CODE";
	public final static String INVALID_FLAG   = "INVALID_FLAG"; 
	public final static String PROMO_CODE     = "PROMO_CODE"; 
	public final static String SITE_ID        = "SITE_ID"; 
	public final static String MK_DATETIME    = "MK_DATETIME"; 
	public final static String LAST_LOGIN_DATETIME = "LAST_LOGIN_DATETIME"; 
	public final static String UP_DATETIME    = "UP_DATETIME"; 
	public final static String UP_ADMIN       = "UP_ADMIN"; 
	public final static String DEL_DATETIME   = "DEL_DATETIME"; 
	public final static String DEL_ADMIN      = "DEL_ADMIN";
	public final static String MAG_FLAG       = "MAG_FLAG";
	public final static String FIRST_POINT_DATETIME       = "FIRST_POINT_DATETIME";
	public final static String DAILY_POINT_DATETIME       = "DAILY_POINT_DATETIME";
	// 生活情報関連
    public final static String HOUSE_TYPE_ID = "HOUSE_TYPE_ID"; // 引越し比較個人より（ズバット、モバイル含む）より
    public final static String SUMAI_KEITAI_CODE = "SUMAI_KEITAI_CODE"; // 火災保険より
    public final static String CAR_MAKER_NAME_DISP = "CAR_MAKER_NAME_DISP";// 車のメーカー名
    public final static String CAR_SHASHU_NAME_DISP = "CAR_SHASHU_NAME_DISP"; // 車種名
    public final static String CAR_KATASHIKI_NAME = "CAR_KATASHIKI_NAME";// 型式
    public final static String SHODO_TOROKU_NENGETSU = "SHODO_TOROKU_NENGETSU";// 車の初年度登録
    public final static String HAVE_BIKE = "HAVE_BIKE";// バック持っているか

//    public final static String ONETIME_ID     = "ONETIME_ID";
//    public final static String ONETIME_DATETIME  = "ONETIME_DATETIME";
    // ポイント関連追加
    public final static String POINT_BALANCE = "POINT_BALANCE";
    public final static String POINT_BALANCE_INIT = "POINT_BALANCE_INIT";
    public final static String POINT_UP_DATETIME = "POINT_UP_DATETIME";
    public final static String TEST_USER_FLAG = "TEST_USER_FLAG";
    public final static String POINT_UPDATE_COUNT = "POINT_UPDATE_COUNT";
	
	/**
	 * コンストラクタ
	 * @param guid GUID
	 */
	public MemberMst(String guid){
		super();
		setGuid(guid);
		set (INVALID_FLAG , FLG_INVALID_OFF); // レコードはデフォルトで有効。無効にする場合はアプリケーションで制御する
	}

	public MemberMst() {
		super();
		set (INVALID_FLAG , FLG_INVALID_OFF); // レコードはデフォルトで有効。無効にする場合はアプリケーションで制御する
	}

	public void init(){
		setTable(TABLE);
	}

	/**
	 * ラストログイン時間を更新する
	 * @param db
	 * @param guid
	 * @return
	 * @throws SQLException
	 */
	public static int updateLastLoginDatetime(DBAccess db , String guid) throws SQLException{
		DBUpdater updater = new DBUpdater(TABLE);
		updater.addString(MemberMst.LAST_LOGIN_DATETIME, DateUtil.currentDateTime());
		updater.addString(MemberMst.UP_ADMIN, "LOGIN");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		return updater.update(db);	
	}

	/**
	 * 退会処理を行う
	 * 
	 * 
	 * @param db
	 * @param guid
	 * @return DB変更行数
	 * 
	 * @throws SQLException
	 */
	public static void resign(DBAccess db , String guid) throws SQLException{
		resign(db, guid, true); 
	}

	/**
	 * メルマガ統合対応
	 * 
	 * 退会処理を行う
	 * 
	 * @param db
	 * @param guid
	 * @param mailDelFlg メールマガジンの配信を停止する
	 * @return DB変更行数
	 * 
	 * @throws SQLException
	 */
	public static void resign(DBAccess db , String guid, boolean mailDelFlg) throws SQLException{
		
		log.info("resign:exec:"+db.getAutoCommit());
		// メルマガ統合対応
		// メルマガ管理テーブルのデータを一括削除する
		if (mailDelFlg) {
			MemberMst member = new MemberMst(guid);
			member.load(db);
			
			String email = member.get(MemberMst.EMAIL);
			String mb_mail = member.get(MemberMst.MB_MAIL);
			String cp_mail = member.get(MemberMst.CP_MAIL);
			
			String sql = "DELETE FROM COMMON.MAIL_SUBSCRIBE WHERE EMAIL IN (?, ?, ?) ";
			log.debug("COMMON.MAIL_SUBSCRIBEテーブルから以下のデータを削除します。" + sql);
			db.prepareStatement(sql);
			db.setString(1, email);
			db.setString(2, mb_mail);
			db.setString(3, cp_mail);
			db.executeUpdate();

			sql = "DELETE FROM COMMON.MAIL_SUBSCRIBE_DETAIL WHERE EMAIL IN (?, ?, ?) ";
			log.debug("COMMON.MAIL_SUBSCRIBE_DETAILテーブルから以下のデータを削除します。" + sql);
			db.prepareStatement(sql);
			db.setString(1, email);
			db.setString(2, mb_mail);
			db.setString(3, cp_mail);
			db.executeUpdate();

			sql = "DELETE FROM COMMON.MAIL_KEY_MAP WHERE EMAIL IN (?, ?, ?) ";
			log.debug("COMMON.MAIL_KEY_MAPテーブルから以下のデータを削除します。" + sql);
			db.prepareStatement(sql);
			db.setString(1, email);
			db.setString(2, mb_mail);
			db.setString(3, cp_mail);
			db.executeUpdate();
		}
		else
		{
			MemberMst member = new MemberMst(guid);
			member.load(db);
			
			String email = member.get(MemberMst.EMAIL);
			String mb_mail = member.get(MemberMst.MB_MAIL);
			String cp_mail = member.get(MemberMst.CP_MAIL);
			
			String sql = "DELETE FROM COMMON.MAIL_SUBSCRIBE WHERE EMAIL IN (?, ?, ?) "
				+ "AND MAIL_ID IN (SELECT MAIL_ID FROM COMMON.MAIL_MST WHERE MEMBER_ONLY_FLAG='1')";
			log.debug("COMMON.MAIL_SUBSCRIBEテーブルから以下のデータを削除します。" + sql);
			db.prepareStatement(sql);
			db.setString(1, email);
			db.setString(2, mb_mail);
			db.setString(3, cp_mail);
			db.executeUpdate();
		}	
		log.info("before:PointUtilRenew:"+db.getAutoCommit());
		
		// ポイントを無効にします。
		PointUtilRenewal.withdraw(db, guid);

		DBUpdater updater = new DBUpdater(TABLE);

		updater.addString(MemberMst.PASSWD, "");
 		updater.addString(MemberMst.NICKNAME, "");
		updater.addString(MemberMst.NAME1, "");
		updater.addString(MemberMst.NAME2, "");
		updater.addString(MemberMst.FURI1, "");
		updater.addString(MemberMst.FURI2, "");
		updater.addString(MemberMst.ADDR1, "");
		updater.addString(MemberMst.ADDR2, "");
		updater.addString(MemberMst.ADDR3, "");
		updater.addString(MemberMst.ADDR4, "");
		updater.addString(MemberMst.ADDR5, "");
		updater.addString(MemberMst.BIRTHDAY, "");
		updater.addString(MemberMst.TEL, "");
		updater.addString(MemberMst.MOBILE, "");
		updater.addString(MemberMst.EMAIL, "");
		updater.addString(MemberMst.MB_MAIL, "");
		updater.addString(MemberMst.CP_MAIL, "");
		updater.addString(MemberMst.CP_TEL, "");
// del 080415 メルマガ管理方法変更 --
//		updater.addString(MemberMst.MAG_FLAG, MemberMst.FLG_MAG_FLAG_OFF);
// --
// add 080425 MemberMstとの二重管理に変更 --
		updater.addString(MemberMst.MAG_FLAG, MemberMst.FLG_MAG_FLAG_OFF); 
// --
		updater.addString(MemberMst.INVALID_FLAG, MemberMst.FLG_INVALID_ON);
		updater.addString(MemberMst.DEL_DATETIME, DateUtil.currentDateTime());

		updater.addString(MemberMst.POINT_BALANCE, "0");
		updater.addString(MemberMst.POINT_BALANCE_INIT, "0");
		updater.addString(MemberMst.POINT_UP_DATETIME, DateUtil.currentDateTime());
		
		
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);

		
		// MemberMstを更新
		updater.update(db); 
		
		// メルマガ管理テーブルのデータを一括削除する
//		String sql = "DELETE FROM MAG_SUBSCRIBE WHERE GUID=?";
//		db.prepareStatement(sql);
//		db.setString(1, guid);
//		db.executeUpdate();


	}

	/**
	 * MemberMstの冗長データを削除する
	 * @param db
	 * @param guid
	 * @return
	 * @throws SQLException
	 */
	public static int deleteRedundantData(DBAccess db , String guid) throws SQLException{
		// MemberMstの不要データを削除。
		String deletesql = "DELETE FROM MEMBER_MST ";
		deletesql += "WHERE ";
		deletesql += "  GUID = ? ";
		deletesql += "AND ";
		deletesql += "  EMAIL IS NULL ";
		deletesql += "AND ";
		deletesql += "  MB_MAIL IS NULL ";
		deletesql += "AND ";
		deletesql += "  CP_MAIL IS NULL ";
		deletesql += "AND ";
		deletesql += "  FORMAL_FLAG = ? ";
		//TODO takahashi  ★FORMAL_FLG 要確認
		
		db.prepareStatement(deletesql);
		db.setString(1, guid);
		db.setString(2, MemberMst.FLG_FORMAL_OFF);
		return db.executeUpdate();	

	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.common.db.util.DBEntity#insertDB(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	public int insertDB(DBAccess db) throws SQLException{
		set (MK_DATETIME , DateUtil.currentDateTime());
		set (UP_DATETIME , DateUtil.currentDateTime());
		set (REMINDER_FLAG , FLG_REMINDER_NOT_SENT_OR_REGISTERD);
//		set (AF_CODE , FLG_AFFILIATE_FLAG_OFF);                   // NOT NULL でなくなったので削除
		
		return super.insertDB(db);
	}
	
	

	/**
	 * Emailが存在するか否かを調べる
	 * @param db
	 * @return true 存在する
	 * @return false 存在しない
	 * @throws SQLException
	 */
	public boolean isSetEmail() throws SQLException{
		String email = get(EMAIL);
		if (email.equals("")){
			return false;
		} else {
			return true;
		}
	}

	/** mb_mailが存在するか否かを調べる
	 * @param db
	 * @return true 存在する
	 * @return false 存在しない
	 * @throws SQLException
	 */
	public boolean isSetMbMail() throws SQLException{
		String email = get(MB_MAIL);
		if (email.equals("")){
			return false;
		} else {
			return true;
		}
	}

	/** cp_mailが存在するか否かを調べる
	 * @param db
	 * @return true 存在する
	 * @return false 存在しない
	 * @throws SQLException
	 */
	public boolean isSetCpMail() throws SQLException{
		String email = get(CP_MAIL);
		if (email.equals("")){
			return false;
		} else {
			return true;
		}
	}

	/**
	 * member_mstに該当メールアドレスと合致するレコードが存在するか否かを調べる
	 * email,mb_mail,cp_mailのいずれか一つでも該当したら存在すると見なす,
	 * @param db
	 * @param email
	 * @return true 存在する
	 * @return true 存在しない
	 * @throws SQLException
	 */
	public static boolean existsMailAddress(DBAccess db , String email) throws SQLException{

		String sql = "SELECT GUID FROM MEMBER_MST WHERE (EMAIL=? OR MB_MAIL=? OR CP_MAIL=?) ";
		db.prepareStatement(sql);
		db.setString(1, email);
		db.setString(2, email);
		db.setString(3, email);
		Record rec = Record.getFirstRowOf(db);
		if (rec == null) {
			return false;
		} else {
			return true;
		}
		
	}

	/**
	 * <pre>
	 * member_mstに該当メールアドレスが自分のレコード以外で既に使用されているか否かを調べる
	 * email,mb_mail,cp_mailのいずれか一つでも該当したら存在すると見なす
	 * 
	 * ただし、自分のguidは無視する
	 * </pre>
	 * @param db
	 * @param email
	 * @param guid
	 * @return true 存在する
	 * @return true 存在しない
	 * @throws SQLException
	 */
	public static boolean usedMailAddress(DBAccess db , String email , String guid) throws SQLException{
		String sql = "SELECT GUID FROM MEMBER_MST WHERE (EMAIL=? OR MB_MAIL=? OR CP_MAIL=?)  AND ( GUID <> ? ) ";
		db.prepareStatement(sql);
		db.setString(1, email);
		db.setString(2, email);
		db.setString(3, email);
		db.setString(4, guid);
		Record rec = Record.getFirstRowOf(db);
		if (rec == null) {
			return false;
		} else {
			return true;
		}
		
	}

	/**
	 * 本登録有効期限を設定する
	 * @param value 期限（日付） YYYYMMDDHHMISS
	 */
	public void setLimitDateTime(String value){
		set(LIMIT_DATETIME , value);
	}
	
	/**
	 * 本登録有効期限を無期限とする
	 */
	public void unLimitDateTime(){
		setLimitDateTime("99999999999999");
	}

	/**
	 * 本登録フラグをセットする
	 * @param val 値
	 */
	public void setFormalFlag(String val){
		set (FORMAL_FLAG , val);
	}
	
	/**
	 * 仮登録状態とする
	 */
	public void setKaritourokuFlg(){
		setFormalFlag(FLG_FORMAL_OFF);
	}

	/**
	 * 本登録状態とする
	 */
	public void setHontourokuFlg(){
		setFormalFlag(FLG_FORMAL_ON);
	}

	public boolean isValid() {

		// 仮登録状態がNULLの場合はエラー
		if ( get(FORMAL_FLAG).equals("")) {
			return false;
		}
		
		// 削除されているデータの場合はエラー
		if (! get(DEL_DATETIME).equals("")) {
			return false;
		}
		
		return true;
	}
	
	public boolean isMitouroku() {
		if ( get(FORMAL_FLAG).equals("")) {
			return true;
		} else {
			return false;
		}
		
	}
	
	public boolean isHontouroku() {
		if ( get(FORMAL_FLAG).equals(FLG_FORMAL_ON)) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isKaritouroku() {
		if ( get(FORMAL_FLAG).equals(FLG_FORMAL_OFF)) {
			return true;
		} else {
			return false;
		}
	}	

	/*
	 * セッター・ゲッター
	 */
	public void setNameKanji1(String val) {
		set (NAME1 , val);
	}

	public void setNameKanji2(String val) {
		set (NAME2 , val);
	}
	public final String getGuid(){
		return get (GUID);
	}
	
	public void setGuid(String val){
		set(GUID , val);
	}
	
	public void setPassword(String value){
		set(PASSWD , value);
	}

	public void setEmail(String value){
		value = rtrim(value, EMAIL);
		set(EMAIL , value);
	}

	/**
	 * 該当ログインIDのユーザが既に登録済みか否かを調べる
	 * @param db
	 * @param loginId
	 * @return
	 * @throws SQLException
	 */
	public static boolean isRegisterdUser (DBAccess db , String loginId) throws SQLException{
		log.info("ユーザ登録済みチェック 開始");
		log.info("loginId=" + loginId);
		String sql = "select GUID from member_mst where (email=? or mb_mail=? or cp_mail=?) and formal_flag='1' "; //パスワードの正誤は問わない
		db.prepareStatement(sql);
		db.setString(1, loginId);
		db.setString(2, loginId);
		db.setString(3, loginId);
		Record rec = Record.getFirstRowOf(db);
		if (rec == null) {
			return false;
		} else {
			return true; 
		}
	}

	/**
	 * MemberMstから、emailをキーにして一行読み込む
	 * 該当データが複数ある場合は、先頭データを読み込む
	 * 
	 * @param db
	 * @param email
	 * @return
	 * @throws SQLException
	 */
	public boolean load(DBAccess db , String email) throws SQLException{
		
		clear(); // 内部保持しているデータを全削除
		
		// SQLを生成
		String sql = "SELECT * FROM MEMBER_MST ";
		sql += "WHERE";
		sql += " (EMAIL=? OR MB_MAIL=? OR CP_MAIL=?) ";
		
		try{
			db.prepareStatement(sql);
			db.setString(1, email);
			db.setString(2, email);
			db.setString(3, email);
			
			Record rec = Record.getFirstRowOf(db);
			if (rec == null) {
				log.info(getFullTableName() + "の情報を読み込めませんでした。");
				return false;
			} else {
				setRecord(rec);
			}
			
		} catch(SQLException e){
			// 例外エラー
			log.error("DBエラーが発生しました。",e);
			throw e;
			
		} 
		
		return true;
	}
	
	/**
	 * <pre>
	 * 会員のメールアドレスの種別を返す
	 * 
	 * 0:PC
	 * 1:携帯
	 * 2:法人
	 * 
	 * 携帯メールが登録済みならば、無条件で携帯メールと判定
	 * 次に、法人メールが登録済みならば法人メールと判定する
	 * 
	 * </pre>
	 * 
	 */
	public int getEmailType () {

// change 080520 Takahashi Primary_Emailを使うロジックに変更 --
//		String mb_mail = get (MB_MAIL);
//		String cp_mail = get (CP_MAIL);
//
//		if (! mb_mail.equals("")) {
//			return TYPE_MB_MAIL;
//		}
//		
//		if (! cp_mail.equals("")) {
//			return TYPE_CP_MAIL;
//		}
//		
//		return TYPE_PC_MAIL;
//		
		
		String emailTypeStr = ValueUtil.nullToStr(get (PRIMARY_EMAIL) );
		
		if (emailTypeStr.equals("")) {
			log.warn("優先メールフラグがnullです。type=");
			return MemberMst.TYPE_PC_MAIL;
		}
		
		int type = 	StringUtil.forceInt(emailTypeStr);
		
		if (type < MemberMst.TYPE_PC_MAIL && type > MemberMst.TYPE_CP_MAIL) {
			log.warn("優先メールフラグが無効です。type=" + type);
			return MemberMst.TYPE_PC_MAIL;
		}

		return type;
		
// -- change 080520		
		
		
	}
	
	/**
	 * <pre>
	 * 優先的に使用するメールアドレスを取得する。
	 * 
	 * 退会メール送信など、ユーザ連絡用のメールアドレスを取得する場合は
	 * このメソッドを使用する。
	 * 
	 * primary_emailフラグではなく、フラグに応じたe-mailアドレスを返すことに注意。
	 * 
	 * </pre>
	 * @return
	 */
	public String getPrimaryEmail() {
/*
 * 旧仕様
 * 
 * 携帯対応以前は、一律でMB > CP > PC の優先度で取得していた
 * 
 		String email = get (MB_MAIL);
		if (email.equals("")) {
			email = get (CP_MAIL);
			
			if (email.equals("")) {
				email = get (EMAIL);
			}
		}
		
		return email;
*/		
		return getMainEmail(); // Primary_emailフラグに応じて優先メールアドレスを取得する

	}

	/**
	 * リマインダ処理された会員レコードを通常の状態に戻す
	 * 
	 * @param db
	 * @param guid
	 * @return
	 */
	public static int rollbackRemind(DBAccess db , String guid) throws SQLException{
		
		log.info("リマインダ処理されたユーザを通常状態に復帰します。");
		// MemberMst.REMINDER_FLAG		オフ
		// MemberMst.RM_DATETIME		null
		
		DBUpdater updater = new DBUpdater(TABLE);
		updater.addString(MemberMst.REMINDER_FLAG , MemberMst.FLG_REMINDER_NOT_SENT_OR_REGISTERD); // リマインダフラグをオフ
		updater.addString(MemberMst.RM_DATETIME ,   "");                                           // リマインダ処理時刻をクリア
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		
		return updater.update(db);
			
			
	}
	
	public String getMagEmail(String magTermType) {

		// 引数チェック
		if (magTermType == null) {
			log.error("引数 magTermType がnullです。");
			return null;
		}

		if (!  (magTermType.equals(MagSubscribe.TERM_TYPE_COMMON)  ||
				magTermType.equals(MagSubscribe.TERM_TYPE_PC)     ||
				magTermType.equals(MagSubscribe.TERM_TYPE_MOBILE) ||
				magTermType.equals(MagSubscribe.TERM_TYPE_OTHER))  ) {

			log.error("引数 magTermType が不正です。magTermType=" + magTermType);
			return null;
		}

		String email = null;
		
		if (magTermType.equals(MagSubscribe.TERM_TYPE_OTHER) ||
			magTermType.equals(MagSubscribe.TERM_TYPE_COMMON) ||
			magTermType.equals(MagSubscribe.TERM_TYPE_MOBILE)) {

			// 全端末向けのメルマガの場合、メインのメールアドレスを返す。
			// 携帯向端末向けのメルマガの場合、メインのメールアドレスを返す。
			// ゲーム機やTV等の端末機向けのメルマガの場合、メインのメールアドレスを返す。
			
			email = ValueUtil.nullToStr(getPrimaryEmail());
		
		}

		if (magTermType.equals(MagSubscribe.TERM_TYPE_PC)) {
			
			// PC向けのメルマガの場合、携帯には送らない。
			 
			email = ValueUtil.nullToStr(get(EMAIL));

			if (email.equals("")) {
				email = ValueUtil.nullToStr(get(CP_MAIL));
			}
	
		}
		if (email.equals("")) {
		
			return null;

		} else {
			
			return email;
		
		}
		
	}

	/**
	 * PRIMARY_EMAILフラグに応じて決定される優先メールアドレスを取得する
	 * 
	 * 取得に失敗した場合はnull
	 * 
	 * @return
	 */
	private String getMainEmail() {

		// PRIMARY_EMAIL に応じてメールアドレスを返す
		String pm_flg = ValueUtil.nullToStr(get(PRIMARY_EMAIL));
		
		String email = null;

		if (pm_flg.equals("")) {
			// MB > CP > PC
			email = get(MB_MAIL);
			
			if (email.equals("")) {
				email = get(CP_MAIL);
				
				if (email.equals("")) {
					email = get(EMAIL);
				}

			}
		}
		
		
		if (pm_flg.equals(FLG_PRIMARY_EMAIL_MB)) {

			// MB > CP > PC
			email = get(MB_MAIL);
			
			if (email.equals("")) {
				email = get(CP_MAIL);
				
				if (email.equals("")) {
					email = get(EMAIL);
				}

			}
		}

		if (pm_flg.equals(FLG_PRIMARY_EMAIL_CP)) {

			// CP > PC > MB
			email = get(CP_MAIL);
			
			if (email.equals("")) {
				email = get(EMAIL);
				
				if (email.equals("")) {
					email = get(MB_MAIL);
				}

			}
			
		}

		if (pm_flg.equals(FLG_PRIMARY_EMAIL_PC)) {

			// PC > MB > CP
			email = get(EMAIL);
			
			if (email.equals("")) {
				email = get(MB_MAIL);
				
				if (email.equals("")) {
					email = get(CP_MAIL);
				}

			}
			
		}

		email = ValueUtil.nullToStr(email);
		
		if (email.equals("")) {
			
			return null;
			
		} else {
			
			return email;
		}

	}

	public static void checkMelmagaFlg(DBAccess db , String guid) throws SQLException {
		guid = ValueUtil.nullToStr(guid);
		if (guid.equals("")) {
			log.info("guidが不正です。メルマガフラグの更新を中止します。");
			return;
		}
		
		String sql = "UPDATE MEMBER_MST SET MAG_FLAG='1' WHERE GUID=? ";
		db.prepareStatement(sql);
		db.setString(1, guid);
		db.executeUpdate();
		
	}

	public static void clearMelmagaFlg(DBAccess db , String guid) throws SQLException {
		guid = ValueUtil.nullToStr(guid);
		if (guid.equals("")) {
			log.info("guidが不正です。メルマガフラグの更新を中止します。");
			return;
		}
		
		String sql = "UPDATE MEMBER_MST SET MAG_FLAG='0' WHERE GUID=? ";
		db.prepareStatement(sql);
		db.setString(1, guid);
		db.executeUpdate();
		
	}
    
    /**
     * <pre>
     * パスワードが暗号化されているかどうかを判別して返す。
     * 
     * 暗号化されていれば true ，そうでなければ false を返す。
     * 
     * 渡された文字列が null の場合は false を返す。
     * 
     * </pre>
     * @param passwd
     */
    public static boolean isHashedPasswd(String passwd) {
        
        if (passwd == null) {
            return false;
        }
        
        if (passwd.length() >= 40 ) {
            return true;
        }
        
        return false;
        
    }

    /**
     * <pre>
     * MEMBER_MST テーブルの PASSWORD列 が暗号化されているかどうかを返す。
     * 
     * 暗号化されていれば true ，そうでなければ false を返す。
     * 
     * PASSWORD が null の場合は false を返す。
     * 
     * </pre>
     */
    public boolean isHavingHashedPasswd() {
        return isHashedPasswd(ValueUtil.nullToStr(this.get(PASSWD)));
    }
    
 
    /**
     * <pre>
     * 必須項目が満たされていればtrue
     * </pre>
     * @return
     */
    public boolean isFilledRequiredInfo() {

       /*
        * 必須項目は以下の6つ
        * 
        * guid
        * email
        * password
        * nickname
        * gender
        * birthday
        * 
        */
    
        String email = ValueUtil.nullToStr(getMainEmail()).trim();
        
        if (email.equals("")) {
            return false;
        }

        String password = ValueUtil.nullToStr(get(PASSWD)).trim();
        
        if (password.equals("")) {
            return false;
        }
        
        String nickname = ValueUtil.nullToStr(get(NICKNAME)).trim();

        if (nickname.equals("")) {
            return false;
        }
        
        String gender = ValueUtil.nullToStr(get(SEX_ID)).trim();

        if (gender.equals("")) {
            return false;
        }

        String birthday = ValueUtil.nullToStr(get(BIRTHDAY)).trim();

        if (birthday.equals("")) {
            return false;
        }
        
        
        return true;

    }
    
    /**
     * <pre>
     * 本登録ユーザが必須入力項目を全て入力済みであるか否かを返す。
     * 
     * パスワードが仮登録状態であれば FALSE
     * 
     * ユーザが本登録ユーザで、かつ必須入力項目全てが入力済みなら TRUE
     *
     * ユーザが本登録ユーザで、かつ必須入力が未入力のものがあれば FALSE
     *
     * ユーザが本登録ユーザでは無い場合は N/A
     * 
     * 処理途中でエラーが発生した場合は N/A
     * 
     * なお、パスワードが仮登録状態にある場合は、必須項目が入力されて
     * いないものとして扱い、FALSEを返す。
     * 
     * </pre>
     * @param guid
     * @return
     */
    public static State3 isFilledRequiredInfo(String guid) {

        if (! SessionFilterAlterUtil.isValidGuid(guid)){
            log.info("guidが不正です。guid=" + guid);
            return State3.NA();
        }
        
        MemberMst member = new MemberMst(guid);
        
        DBAccess db = null;
        try {
            db = new DBAccess();
            if (! member.load(db)) {
                log.info("MEMBER_MST の読み込みに失敗しました。guid=" + guid);
                return State3.NA();
            }
            
            if (! member.isHontouroku()) {
                return State3.NA();
            }
            
            if (! member.isHavingHashedPasswd() ) {
                return State3.FALSE();
            }
            
            if (member.isFilledRequiredInfo()) {
                return State3.TRUE();
            } else { 
                return State3.FALSE();
            }
            
        } catch (SQLException e) {
            log.error("データベース処理で例外エラーが発生しました。" , e);
            return State3.NA();
        
        } finally {
            DBAccess.close(db);
        }
    }
    
    /**
     * <pre>
     * e-mailが一つでもあればtrue
     * 
     * そうでなければfalse
     * 
     * </pre>
     * @return
     */
    public boolean isHavingEmail() {
        String email = ValueUtil.nullToStr(getMainEmail());
        
        if (email.equals("")) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * <pre>
     * guidを元にワンタイムＩＤを生成して返す。
     * 
     * 生成に失敗した場合はnullを返す。
     * 
     * </pre>
     * @param guid
     * @return
     */
    public static String createOneTimeId (String guid) {
        if (! SessionFilterAlterUtil.isValidGuid(guid)) {
            return null;
        }
        
        try {
        
            return ValueUtil.createHash(Long.parseLong(guid));
        
        } catch (Exception e) {
            
            log.error("guidの変換に失敗しました。guid=" + guid , e);
            return null;
        }
        
    }

    /**
     * <pre>
     * ユーザが無効になっていたらtrue, そうでなければfalse
     * </pre>
     * @return
     */
    public boolean isInvalid() {
        
        if (ValueUtil.nullToStr(get(INVALID_FLAG)).equals(FLG_INVALID_ON)) {
            return true;
        }
        
        if (! ValueUtil.nullToStr(get(DEL_DATETIME)).equals("")) {
            return true;
        }
        
        return false;
    }
}

