package jp.co.webcrew.phoenix.sstag.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.login.common.db.MailTemplate;
import jp.co.webcrew.login.common.util.Mail;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.db.FormActStaffDb;
import jp.co.webcrew.phoenix.sstag.db.FormItemDb;
import jp.co.webcrew.phoenix.sstag.util.FormItemUtil;
import jp.co.webcrew.phoenix.sstag.util.ReplaceUtil;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * メール送信を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class FormMailExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：メールテンプレートID */
    private static final String MAIL_TEMPL_ID_PARAM_KEY = "mail_templ_id";

    /** パラメータ名：メールfrom */
    private static final String FROM_PARAM_KEY = "from";

    /** パラメータ名：メールfrom名 */
    private static final String FROM_NAME_PARAM_KEY = "from_name";

    /** パラメータ名：メールto */
    private static final String TO_PARAM_KEY = "to";

    /** パラメータ名：メールcc */
    private static final String CC_PARAM_KEY = "cc";

    /** パラメータ名：メールbcc */
    private static final String BCC_PARAM_KEY = "bcc";

    /** パラメータ名：メールsubject */
    private static final String SUBJECT_PARAM_KEY = "subject";

    /** パラメータ名：メール本文 */
    private static final String BODY_PARAM_KEY = "body";

    /** パラメータ名：メール添付名 */
    private static final String ATTACH_PARAM_KEY = "attach";

    /** パラメータ名：メール添付ファイル名 */
    private static final String FILE_PARAM_KEY = "file";

    /** パラメータ名：メール送信先(to:ヘッダ) にこのフォームの管理者を(追加)指定 */
    private static final String TO_ADMIN_PARAM_KEY = "to_admin";

    /** パラメータ名：メールコピー送信者にこのフォームの管理者を(追加)指定 */
    private static final String CC_ADMIN_PARAM_KEY = "cc_admin";

    /** パラメータ名：メール秘匿コピー送信者にこのフォームの管理者を(追加)指定 */
    private static final String BCC_ADMIN_PARAM_KEY = "bcc_admin";

    /** 置換変数名：フォーム項目名称 */
    private static final String FORM_ITEM_NAME_VAL_KEY = "form.item.{0}.name";

    /** 置換変数名：フォーム項目タイトル */
    private static final String FORM_ITEM_TITLE_VAL_KEY = "form.item.{0}.title";

    /** 置換変数名：フォーム項目に入力された生の値 */
    private static final String FORM_ITEM_RAW_VAL_KEY = "form.item.{0}.raw";

    /** 置換変数名：フォーム項目に入力された値 */
    private static final String FORM_ITEM_VALUE_VAL_KEY = "form.item.{0}.value";

    /** 置換変数名：フォーム項目に入力された値 */
    private static final String FORM_ITEM_VALUE_NOENC_VAL_KEY = "form.item.{0}.value_noenc";

    /** 置換変数名：選択肢の場合、選択されたvalue値に対する表示用の値 */
    private static final String FORM_ITEM_DISP_VAL_KEY = "form.item.{0}.disp";

    /** 置換変数名：選択肢の場合、選択されたvalue値に対する表示用の値 */
    private static final String FORM_ITEM_DISP_NOENC_VAL_KEY = "form.item.{0}.disp_noenc";

    /** 置換変数名：バリデーションエラーの文字列 */
    private static final String FORM_ITEM_ERROR_VAL_KEY = "form.item.{0}.error";

    /** 置換変数名：注意書き文言 */
    private static final String FORM_ITEM_CAUTION_VAL_KEY = "form.item.{0}.caution";

    /** 置換変数名：項目のタイプ */
    private static final String FORM_ITEM_TYPE_VAL_KEY = "form.item.{0}.type";

    /** ロガー */
    private static final Logger log = Logger.getLogger(FormMailExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String mailTemplId = ValueUtil.nullToStr(parameters.get(MAIL_TEMPL_ID_PARAM_KEY));
            String from = ValueUtil.nullToStr(parameters.get(FROM_PARAM_KEY));
            String fromName = ValueUtil.nullToStr(parameters.get(FROM_NAME_PARAM_KEY));
            String to = ValueUtil.nullToStr(parameters.get(TO_PARAM_KEY));
            String cc = ValueUtil.nullToStr(parameters.get(CC_PARAM_KEY));
            String bcc = ValueUtil.nullToStr(parameters.get(BCC_PARAM_KEY));
            String subject = ValueUtil.nullToStr(parameters.get(SUBJECT_PARAM_KEY));
            String body = ValueUtil.nullToStr(parameters.get(BODY_PARAM_KEY));
            // TODO kurinami 【未実装】 パラメータ
            String[] attach = PhoenixUtil.split((String) parameters.get(ATTACH_PARAM_KEY), ",");
            String[] file = PhoenixUtil.split((String) parameters.get(FILE_PARAM_KEY), ",");
            boolean toAdmin = isAdmin((String) parameters.get(TO_ADMIN_PARAM_KEY));
            boolean ccAdmin = isAdmin((String) parameters.get(CC_ADMIN_PARAM_KEY));
            boolean bccAdmin = isAdmin((String) parameters.get(BCC_ADMIN_PARAM_KEY));

            // フォーム管理者のメールアドレスを設定する。
            if (PhoenixUtil.isEmpty(to) || toAdmin || ccAdmin || bccAdmin) {
                String staffEmails = PhoenixUtil.concat(FormActStaffDb.getStaffEmails(siteId, formId), ",");

                if (!PhoenixUtil.isEmpty(staffEmails)) {
                    if (PhoenixUtil.isEmpty(to) || toAdmin) {
                        to = PhoenixUtil.isEmpty(to) ? staffEmails : to + "," + staffEmails;
                    }

                    if (ccAdmin) {
                        cc = PhoenixUtil.isEmpty(cc) ? staffEmails : cc + "," + staffEmails;
                    }

                    if (bccAdmin) {
                        bcc = PhoenixUtil.isEmpty(bcc) ? staffEmails : bcc + "," + staffEmails;
                    }
                }
            }

            if (!PhoenixUtil.isEmpty(mailTemplId)) {
                // それぞれ指定されていない値をテンプレートの値で上書きする。
                MailTemplate mailTemplate = new MailTemplate(mailTemplId);

                from = PhoenixUtil.isEmpty(from) ? mailTemplate.get(MailTemplate.MAIL_FROM) : from;
                to = PhoenixUtil.isEmpty(to) ? mailTemplate.get(MailTemplate.MAIL_TO) : to;
                cc = PhoenixUtil.isEmpty(cc) ? mailTemplate.get(MailTemplate.MAIL_CC) : cc;
                bcc = PhoenixUtil.isEmpty(bcc) ? mailTemplate.get(MailTemplate.MAIL_BCC) : bcc;
                subject = PhoenixUtil.isEmpty(subject) ? mailTemplate.get(MailTemplate.SUBJECT) : subject;
                body = PhoenixUtil.isEmpty(body) ? mailTemplate.get(MailTemplate.BODY) : body;
            }

            // フォーム項目一覧を取得する。
            List<FormItemBean> formItemList = FormItemDb.getList(siteId, formId, null, null, null, null);

            // セッションストアで保持しているフォームデータを取得する。
            PostInfo postInfo = StoreUtil.getPostInfo(request);

            // セッションストアで保持している入力チェックの結果を取得する。
            Map<String, String[]> vResult = StoreUtil.getValidationResult(request, formId);
            if (vResult == null) {
                vResult = new HashMap<String, String[]>();
            }

            // 置換変数の一覧を作成する。
            Map<String, String> replaceMap = new HashMap<String, String>();
            for (FormItemBean formItem : formItemList) {

                // この項目に対する入力情報とエラー情報を取りだす。
                String[] values = postInfo.postItemMap.get(formItem.getItemId());
                String[] errors = vResult.get(formItem.getItemId());

                // 入力項目に関する置換変数の設定。
                setItemReplaceVal(request, replaceMap, formItem, values, errors);

            }

            fromName = ReplaceUtil.getReplacedMail(fromName, replaceMap);
            subject = ReplaceUtil.getReplacedMail(subject, replaceMap);
            body = ReplaceUtil.getReplacedMail(body, replaceMap);

            // メールを送信する。
            sendMail(to, cc, bcc, from, fromName, subject, body);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * フォーム担当者にメールを送信するかを判定する。
     * 
     * @param param
     * @return
     */
    private boolean isAdmin(String param) {
        if (!PhoenixUtil.isEmpty(param) && (param.equals("1") || param.equalsIgnoreCase("true"))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * フォーム項目ごとの置換変数を組み立てる。
     * 
     * @param request
     * @param replaceMap
     * @param formItem
     * @param values
     * @param errors
     * @throws SQLException
     * @throws InstantiationException
     */
    private void setItemReplaceVal(HttpServletRequest request, Map<String, String> replaceMap, FormItemBean formItem,
            String[] values, String[] errors) throws SQLException, InstantiationException {

        String itemId = formItem.getItemId();

        SstagUtil.setValueToReplaceMap(replaceMap, formItem.getItemId(), FORM_ITEM_NAME_VAL_KEY, itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, formItem.getTitle(), FORM_ITEM_TITLE_VAL_KEY, itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, formItem.getCaution1(), FORM_ITEM_CAUTION_VAL_KEY + ".1", itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, formItem.getCaution2(), FORM_ITEM_CAUTION_VAL_KEY + ".2", itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, formItem.getCaution3(), FORM_ITEM_CAUTION_VAL_KEY + ".3", itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, formItem.getCaution4(), FORM_ITEM_CAUTION_VAL_KEY + ".4", itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, formItem.getCaution5(), FORM_ITEM_CAUTION_VAL_KEY + ".5", itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, formItem.getType(), FORM_ITEM_TYPE_VAL_KEY, itemId);

        FormItemUtil itemUtil = FormItemUtil.getInstance(formItem, request);

        SstagUtil.setValueToReplaceMap(replaceMap, itemUtil.getRaw(), FORM_ITEM_RAW_VAL_KEY, itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, itemUtil.getValue(), FORM_ITEM_VALUE_VAL_KEY, itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, itemUtil.getValueNoenc(), FORM_ITEM_VALUE_NOENC_VAL_KEY, itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, itemUtil.getDisp(), FORM_ITEM_DISP_VAL_KEY, itemId);
        SstagUtil.setValueToReplaceMap(replaceMap, itemUtil.getDispNoenc(), FORM_ITEM_DISP_NOENC_VAL_KEY, itemId);

        SstagUtil.setValuesToReplaceMap(replaceMap, itemUtil.getRaws(), FORM_ITEM_RAW_VAL_KEY, itemId);
        SstagUtil.setValuesToReplaceMap(replaceMap, itemUtil.getValues(), FORM_ITEM_VALUE_VAL_KEY, itemId);
        SstagUtil.setValuesToReplaceMap(replaceMap, itemUtil.getValuesNoenc(), FORM_ITEM_VALUE_NOENC_VAL_KEY, itemId);
        SstagUtil.setValuesToReplaceMap(replaceMap, itemUtil.getDisps(), FORM_ITEM_DISP_VAL_KEY, itemId);
        SstagUtil.setValuesToReplaceMap(replaceMap, itemUtil.getDispsNoenc(), FORM_ITEM_DISP_NOENC_VAL_KEY, itemId);

        if (!PhoenixUtil.isEmpty(errors)) {
            // エラーが存在する場合、
            String error = (errors.length >= 2 && !PhoenixUtil.isEmpty(errors[1]) ? errors[1] : "Error");
            replaceMap.put(FORM_ITEM_ERROR_VAL_KEY, error);
        } else {
            replaceMap.put(FORM_ITEM_ERROR_VAL_KEY, "");
        }

    }

    /**
     * メールを送信する。
     * 
     * @param to
     * @param cc
     * @param bcc
     * @param from
     * @param fromLabel
     * @param subject
     * @param msg
     * @throws Exception
     */
    private void sendMail(String to, String cc, String bcc, String from, String fromLabel, String subject, String msg)
            throws Exception {

        String smtp = SystemPropertiesDb.getInstance().get("MAIL_SMTP_HOST");
        String port = SystemPropertiesDb.getInstance().get("MAIL_SMTP_PORT");

        Mail.sendMailWithCharCheck(smtp, port, to, cc, bcc, from, fromLabel, subject, msg);

    }
}
