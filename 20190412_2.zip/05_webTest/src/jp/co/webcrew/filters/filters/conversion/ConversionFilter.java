package jp.co.webcrew.filters.filters.conversion;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.filters.db.ConversionMstDb;

/**
 * ポイントを収集するためのfilterクラス。
 * 
 * @author kurinami
 */
public class ConversionFilter implements Filter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(ConversionFilter.class);

	/** ポイントチェックスレッド */
	private ConversionThread conversionThread;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

		log.info("init start.");

		try {
			conversionThread = new ConversionThread();
			conversionThread.start();

			// 必要なDBを初期化しておく
			ConversionMstDb.getInstance().init();

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			throw new ServletException(e);
		}

		log.info("init end.");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		log.info("doFilter start.");

		try {
			conversionThread.push((HttpServletRequest) request,
					(HttpServletResponse) response);
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		chain.doFilter(request, response);

		log.info("doFilter end.");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// 処理なし
	}

}
