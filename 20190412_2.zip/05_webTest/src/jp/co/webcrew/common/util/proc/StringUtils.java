package jp.co.webcrew.common.util.proc;


/**
 * Simple local string utility class
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: StringUtils.java,v 1.5 2005-03-09 14:31:04 rickk Exp $
 */
public class StringUtils {
    /**
     * Utility method that replaces wildcards in a string
     */
    public static String stringReplace(String input, String[][] wildcards) {
        String out = input;

        for (int n = 0; n < wildcards.length; n++) {
            out = stringReplace(out, wildcards[n][0], wildcards[n][1]);
        }

        return out;
    }

    public static String stringReplace(String input, String from, String to) {
        if (input == null) {
            return null;
        } else if (from == null) {
            return input;
        }
        int pos = input.indexOf(from);

        if (pos == -1) {
            return input;
        } else {
            return input.substring(0, pos) + to +
            stringReplace(input.substring(pos + from.length()), from, to);
        }
    }

    public static String capitalizeWildcardNames(String input) {
        if (input == null) {
            return null;
        }
        int startPos = input.indexOf("###");

        if (startPos == -1) {
            return input;
        } else {
            int endPos = input.substring(startPos + 3).indexOf("###");

            if (endPos == -1) {
                return input;
            } else {
                return input.substring(0, startPos + 3) +
                input.substring(startPos + 3, startPos + 3 + endPos)
                     .toUpperCase() + "###" +
                capitalizeWildcardNames(input.substring(startPos + 3 + endPos +
                        3));
            }
        }
    }
    
//    public static String convertSJIS(String s) {
//        if (s != null) {
//            char[] chr;
//
//            chr = s.toCharArray();
//
//            for (int i = 0; i < chr.length; ++i) {
//                switch ((int) chr[i]) {
//                // �u�|�v
//                case 0x2212:
//                    chr[i] = 0xFF0D;
//
//                    break;
//
//                // �u�`�v
//                case 0x301C:
//                    chr[i] = 0xFF5E;
//
//                    break;
//
//                // �u�a�v
//                case 0x2016:
//                    chr[i] = 0x2225;
//
//                    break;
//
//                // �u���v
//                case 0x00A2:
//                    chr[i] = 0xFFE0;
//
//                    break;
//
//                // �u���v
//                case 0x00A3:
//                    chr[i] = 0xFFE1;
//
//                    break;
//
//                // �u�ʁv
//                case 0x00AC:
//                    chr[i] = 0xFFE2;
//
//                    break;
//
//                // �u���v
//                case 0x005C:
//                    chr[i] = 0xFF3C;
//
//                    break;
//
//                // �u�\�v
//                case 0x2014:
//                    chr[i] = 0x2015;
//
//                    break;
//
//                default:
//                    break;
//                }
//            }
//
//            return new String(chr);
//        } else {
//            return null;
//        }
//    }
}
