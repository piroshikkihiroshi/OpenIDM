package jp.co.webcrew.phoenix.htmlservlet;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.phoenix.htmlservlet.db.UriAliasMstDB;

public class UriAliasMstUtil 
{
	private static final Logger logger=Logger.getLogger(UriAliasMstUtil.class);
	
	//private static final String EXT_HTML=".html";
	//private static final int EXT_HTML_LENGTH=EXT_HTML.length();

	private static final String REQ_ATTR_NAME_GETVAR="UriAliasMst.GetVar";
	private static final String REQ_ATTR_UNMATCHED_PATH_ARRAY="UriAliasMst.UnmatchedPathArray";
	private static final String REQ_ATTR_UNMATCHED_PATH_ALL="UriAliasMst.UnmatchedPathALL";

	private static final String[] extensions;
	
	static
	{
		extensions=new String[]{".html",".htm",".js",".txt",".css"};
	}
	
	/***
	 * UriAliasMstを適用する
	 * 
	 * @param siteId
	 * @param request
	 * @param requestUri
	 * @return 適用結果を返すオブジェクト
	 */
	public static applyUriAlias_ReturnObject applyUriAlias(int siteId,HttpServletRequest request,String requestUri)
	{
		UriAliasMstBean bean=null;
		
		try
		{
			bean=UriAliasMstDB.getInstance().getUriAliasMstBean(request, siteId, requestUri);
		}
		catch(UriAliasPathNameNotAvailableException exc)
		{
			return new applyUriAlias_ReturnObject(null,UrlReplaceStatus.Apply404);
		}
		
		UrlReplaceStatus status=UrlReplaceStatus.NoChanged;
		
		//String aliasUri=bean.aliasUri;
		if(bean==null)
		{
			//TODO ログレベルを変更
			logger.debug("alias_mst適用なし[siteid]"+siteId+"[uri]"+requestUri);
			
			return new applyUriAlias_ReturnObject(requestUri, status);
		}
		
		
		String unmatchedWord=requestUri.substring(bean.aliasUri.length());
		
		/*
		if(unmatchedWord.endsWith(EXT_HTML))
		{
			int length=unmatchedWord.length()-EXT_HTML_LENGTH;
			if(length<=0)
			{
				unmatchedWord="";
			}
			else
			{
				unmatchedWord=unmatchedWord.substring(0,length);
			}
		}
		*/
		unmatchedWord=removeExtension(unmatchedWord);
		
		String[] unmatchedArray;
		if(bean.splitWord.length()!=0)
		{
			unmatchedArray=unmatchedWord.split(bean.splitWord);
		}
		else
		{
			unmatchedArray=new String[]{unmatchedWord};
		}
		
		if(bean.getVarName!=null)
		{
			if(unmatchedArray.length!=0 && unmatchedArray[0].length()!=0)
			{
				logger.info("GET置換"+bean.getVarName+"="+unmatchedArray[0]);
				setGetVarDataToRequest(request, bean.getVarName, unmatchedArray[0]);
				//request.setAttribute(REQ_ATTR_NAME_GETVAR, new String[]{bean.getVarName,unmatchedArray[0]});
			}
			else
			{
				logger.info("GET置換"+bean.getVarName+"="+bean.getVarDefaultValue);
				setGetVarDataToRequest(request, bean.getVarName, bean.getVarDefaultValue);
				//request.setAttribute(REQ_ATTR_NAME_GETVAR,new String[]{bean.getVarName,bean.getVarDefaultValue});
			}
		}
		else
		{
			logger.info("GET置換:remove_attr");
			request.removeAttribute(REQ_ATTR_NAME_GETVAR);
		}
		setAliasArrayToRequest(request, unmatchedArray);
		setAliasAllToRequest(request, unmatchedWord);
		
		//request.setAttribute(REQ_ATTR_UNMATCHED_PATH_ARRAY, unmatchedArray);
		//request.setAttribute(REQ_ATTR_UNMATCHED_PATH_ALL, unmatchedWord);
		
		//TODO ログのレベル
		logger.info("alias_mst適用あり[siteid]"+siteId+"[uri]"+requestUri+"[path]"+bean.pathName+"[unmatched_word]"+unmatchedWord);
		return new applyUriAlias_ReturnObject(bean.pathName,status);
		
	}
	
	/***
	 * 拡張子の部分を削除する。
	 * 
	 * @param unmatchedWord
	 * @return
	 */
	private static final String removeExtension(String unmatchedWord)
	{
		
		for(String anExt:extensions)
		{
			if(unmatchedWord.endsWith(anExt))
			{
				int length=unmatchedWord.length()-anExt.length();
				if(length<=0)
				{
					unmatchedWord="";
				}
				else
				{
					unmatchedWord=unmatchedWord.substring(0,length);
				}
				return unmatchedWord;
			}
		}
		return unmatchedWord;
	}
	
	/***
	 * メソッドapplyUriAliasの戻り値用オブジェクト
	 * 
	 * @author kazuto.yano
	 *
	 */
	public static class applyUriAlias_ReturnObject
	{
		//public final String requestUri;
		/***
		 * パス名
		 * 「urlReplaceStatus」の値が「NoChanged」以外の場合、
		 * ここの内容が、変換済みの値になっている。
		 */
		public final String pathName;
		/***
		 * 変換状況
		 */
		public final UrlReplaceStatus urlReplaceStatus;
		
		
		public applyUriAlias_ReturnObject(String pathName,UrlReplaceStatus urlReplaceStatus)
		{
//			this.requestUri=requestUri;
			this.pathName=pathName;
			this.urlReplaceStatus=urlReplaceStatus;
		}
	}
	
	
	public static final void setGetVarDataToRequest(HttpServletRequest request,String varName,String varData)
	{
		request.setAttribute(REQ_ATTR_NAME_GETVAR, new String[]{varName,varData});
	}
	
	public static final void setAliasArrayToRequest(HttpServletRequest request,String[] array)
	{
		request.setAttribute(REQ_ATTR_UNMATCHED_PATH_ARRAY, array);
	}
	
	public static final void setAliasAllToRequest(HttpServletRequest request,String allText)
	{
		request.setAttribute(REQ_ATTR_UNMATCHED_PATH_ALL, allText);
	}
	
	/***
	 * $$get変数として適用するデータを取得する。
	 * 
	 * 
	 * @param request
	 * @return サイズ２の配列かＮＵＬＬを返す（索引１：GET変数名、索引２：GET値）
	 */
	public static final String[] getGetVarDataFromRequest(HttpServletRequest request)
	{
		return (String[])request.getAttribute(REQ_ATTR_NAME_GETVAR);
	}
	
	public static final String[] getAliasArrayFromRequest(HttpServletRequest request)
	{
		return (String[])request.getAttribute(REQ_ATTR_UNMATCHED_PATH_ARRAY);
	}
	
	public static final String getAliasAllFromRequest(HttpServletRequest request)
	{
		return (String)request.getAttribute(REQ_ATTR_UNMATCHED_PATH_ALL);
	}
	
	
	
	public static enum UrlReplaceStatus
	{
		/***
		 * alias適用
		 */
		ApplyAlias
		/***
		 * 404適用
		 * alias_mstに登録されているのにpath_nameでアクセスがきた場合、
		 * このステータスになる
		 */
		,Apply404
		/***
		 * 変更なし
		 */
		,NoChanged
		
	}

	
}
