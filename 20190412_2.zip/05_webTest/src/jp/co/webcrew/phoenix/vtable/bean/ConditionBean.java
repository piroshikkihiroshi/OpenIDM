package jp.co.webcrew.phoenix.vtable.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * 条件を保持するbeanクラス。
 * 
 * @author kurinami
 */
public class ConditionBean {

    /** 項目ID（カラム名） */
    private String itemId = "";

    /** 演算子 */
    private String operator = "=";

    /** 値 */
    private String value = "";

    /** 検索条件解析用パターン */
    private static final Pattern PARSE_PATTERN = Pattern
            .compile("\\s*([\\w\\$#]+)\\s*(=|<>|<=|<|>=|>)\\s*('[^']*'|\"[^\"]*\"|[^,]*)?\\s*,?");

    /**
     * コンストラクタ
     */
    public ConditionBean() {
    }

    /**
     * コンストラクタ
     * 
     * @param itemId
     * @param operator
     * @param value
     */
    public ConditionBean(String itemId, String operator, String value) {
        this.itemId = itemId;
        this.operator = operator;
        this.value = value;
    }

    /**
     * 条件用sqlを返す。
     * 
     * @return
     */
    public String getCondition() {

        if (PhoenixUtil.isEmpty(value)) {
            if (operator.equals("=")) {
                return " is null";
            } else if (operator.equals("<>")) {
                return " is not null";
            }
        } else if (value.indexOf("*") >= 0) {
            if (operator.equals("=")) {
                return " like ?";
            }
        }

        return operator + " ?";
    }

    /**
     * 置換パラメータの設定が必要かを返す。
     * 
     * @return
     */
    public boolean isNeedSetParam() {
        if (PhoenixUtil.isEmpty(value)) {
            if (operator.equals("=") || operator.equals("<>")) {
                return false;
            }
        }
        return true;
    }

    /**
     * 比較する値にtrimをかける必要があるかを返す。
     * 
     * @return
     */
    public boolean isNeedTrim() {
        if (PhoenixUtil.isEmpty(value)) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * 置換パラメータに設定する値を返す。
     * 
     * @return
     */
    public String getParamValue() {
        if (value.indexOf("*") >= 0) {
            if (operator.equals("=")) {
                return ValueUtil.replace(value, "*", "%");
            }
        }
        return value;
    }

    /**
     * 検索条件を解析して、条件一覧の返す。
     * 
     * @param conditionStr
     * @return
     */
    public static List<ConditionBean> parse(String conditionStr) {

        List<ConditionBean> list = new ArrayList<ConditionBean>();

        Matcher m = PARSE_PATTERN.matcher(conditionStr);

        while (m.find()) {
            ConditionBean condition = new ConditionBean();
            condition.itemId = m.group(1);
            condition.operator = m.group(2);
            condition.value = quoteTrim(m.group(3));
            list.add(condition);
        }

        return list;
    }

    /**
     * 値に付与された引用符を取り外す。
     * 
     * @param source
     * @return
     */
    private static String quoteTrim(String source) {
        if (PhoenixUtil.isEmpty(source) || source.length() < 2) {
            return ValueUtil.nullToStr(source).trim();
        } else if (source.charAt(0) == '\'' && source.charAt(source.length() - 1) == '\'' || source.charAt(0) == '\"'
                && source.charAt(source.length() - 1) == '\"') {
            return source.substring(1, source.length() - 1);
        } else {
            return source.trim();
        }
    }

    public static void main(String[] args) {

        String[] conditionStrs = { "supplier_id = , \n supplier_id  =  30  , type = 'book',supplier_id = 40",
                "name='三宅,　太郎'", "pet_type <> 'DOG', gegege =", };

        for (String conditionStr : conditionStrs) {
            System.out.println(conditionStr);
            List<ConditionBean> list = parse(conditionStr);
            for (ConditionBean condition : list) {
                System.out.println("[" + condition.itemId + "][" + condition.operator + "][" + condition.value + "]");
            }
        }

    }

    // 以下、アクセッサ

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
