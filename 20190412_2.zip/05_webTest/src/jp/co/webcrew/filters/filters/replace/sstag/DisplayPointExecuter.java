package jp.co.webcrew.filters.filters.replace.sstag;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.DisplayPointDb;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.login.common.util.ChargeLoginPointUtil;
import jp.co.webcrew.login.common.util.PointUtil;

/**
 * 現在の所持ポイント数、今月のポイント数、順位、人数を表示するためのsstag
 *
 */
public class DisplayPointExecuter extends SSTagExecuter
{
	/** ロガー */
	private static final Logger log = Logger.getLogger(DisplayPointExecuter.class);

	private static final String PARAM_CURRENT_MONTH_POINT = "\\$\\$current_month_point\\$\\$";
	private static final String PARAM_RANKING             = "\\$\\$ranking\\$\\$";
	private static final String PARAM_TOTAL_COUNT         = "\\$\\$total_count\\$\\$";
	private static final String PARAM_TOTAL_POINT         = "\\$\\$total_point\\$\\$";

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map mapParameters, HttpServletRequest objRequest, HttpServletResponse objResponse)
	{
		try
		{
		    // ログイン状態判断
            boolean login_flg = SessionFilterUtil.isLogined(objRequest);
            if (!login_flg) {
                return ""; // ログインしてない場合｢空｣を返して以下の処理行わない
            }
		    
			//パラメータを確認
			if (ValueUtil.nullToStr(mapParameters.get("html")).equals(""))
			{
				throw new Exception("SSTAG(DisplayPoint)にパラメータ(html)を設定してください。");
			}

			NumberFormat objNumberFormat = new DecimalFormat("###,###,###,###");

			//パラメータを取得
			String strHTML = (String)mapParameters.get("html");

			//GUIDを取得
			String strGuid = SessionFilterUtil.getGuid(objRequest);
			if(!SessionFilterUtil.isValidGuid(strGuid))
			{
				throw new Exception("GUIDが無効です。GUID=" + strGuid);
			}

			DisplayPointDb objDisplayPointDb = DisplayPointDb.getInstance();
			
			if(objDisplayPointDb.getNextRefreshTime().equals(""))
			{
				//次回再読み込み時間を設定する
				objDisplayPointDb.setNextRefreshTime(getNextDate());
			}
			else
			{
				//次回再読み込み時間を取得
				String strNextRefreshDate = objDisplayPointDb.getNextRefreshTime();
				
				//再読み込みチェック
				if (checkRefresh(strNextRefreshDate))
				{
					//次回再読み込み時間を設定する
					objDisplayPointDb.setNextRefreshTime(getNextDate());
					
					//再読み込みを行う
					objDisplayPointDb.refresh();
				}
			}

			// 新規登録終わったら、ログインしないとポイント表示されないため
			if(SessionFilterUtil.getMemberMst(objRequest, "first_point_datetime").length() == 0){
				ChargeLoginPointUtil.checkFirstLoginPoint(strGuid);
			}

			//人数を取得(1日1回更新)
			String strTotalCount = objNumberFormat.format(objDisplayPointDb.getTotalCount());

			//所持しているポイント数($$total_point$$)を表示する場合はDBから取得する
			String strTotalPoint = "";
			if (isParameter(strHTML, PARAM_TOTAL_POINT))
			{
                /* 仮ポイント対応
                //取得した全ポイント数を取得
				long lngChargeTotal = DisplayPointDb.getChargeTotal(strGuid);

				//利用したポイント数を取得
				long lngSpendTotal = DisplayPointDb.getSpendTotal(strGuid);

				//現在所持しているポイント数を算出
				strTotalPoint = objNumberFormat.format(lngChargeTotal - lngSpendTotal);*/
			    strTotalPoint = objNumberFormat.format(PointUtil.getCurPoint(Long.parseLong(strGuid)));
			}

			//今月の取得ポイント数($$current_month_point$$)か順位($$ranking$$)を表示する場合はDBから取得する
			String strCurrentMonthPoint = "";
			String strRanking = "";
			if (isParameter(strHTML, PARAM_CURRENT_MONTH_POINT) || isParameter(strHTML, PARAM_RANKING))
			{
				//今月の取得ポイント数(key=POINT)/順位(key=RANKING)を取得
				Map mapCurrentMonthPoint = DisplayPointDb.getCurrentMonthPoint(strGuid);

				//今月の取得ポイント数を取り出す
				strCurrentMonthPoint = ValueUtil.nullToStr(mapCurrentMonthPoint.get(DisplayPointDb.KEY_POINT));
				if (strCurrentMonthPoint.equals(""))
				{
					strCurrentMonthPoint = "0";
				}
				else
				{
					strCurrentMonthPoint = objNumberFormat.format(Long.parseLong(strCurrentMonthPoint));
				}

				//順位を取り出す
				strRanking = ValueUtil.nullToStr(mapCurrentMonthPoint.get(DisplayPointDb.KEY_RANKING));
				if (strRanking.equals(""))
				{
					strRanking = strTotalCount;
				}
				else
				{
					strRanking = objNumberFormat.format(Long.parseLong(strRanking));
				}
			}

			//変数を置換する
			strHTML = strHTML.replaceAll(PARAM_CURRENT_MONTH_POINT, strCurrentMonthPoint);
			strHTML = strHTML.replaceAll(PARAM_RANKING,             strRanking);
			strHTML = strHTML.replaceAll(PARAM_TOTAL_COUNT,         strTotalCount);
			strHTML = strHTML.replaceAll(PARAM_TOTAL_POINT,         strTotalPoint);

			return strHTML;
 		}
		catch (Exception e)
		{
			log.error("予期せぬエラー", e);
			return "";
		}
	}

	/**
	 * 再読み込みを行うかどうか確認
	 * 日付が異なっていたら再読み込みを行う
	 * 
	 * @param strNextRefreshDate
	 * @return
	 */
	private boolean checkRefresh(String strNextRefreshDate) throws Exception
	{
		//現在年月日を取得
		String strNowDate = getNowDate();
		
		int nNextRefreshDate = Integer.parseInt(strNextRefreshDate);
		int nNowDate         = Integer.parseInt(strNowDate);
		
		if (nNowDate >= nNextRefreshDate)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 次回再読み込み年月日を作成する
	 * 
	 * @return YYYYMMDD形式の文字列
	 */
	private String getNextDate() throws Exception
	{
		Calendar objCal = Calendar.getInstance();
		
		//次の日を設定
		objCal.add(Calendar.DAY_OF_MONTH, 1);
		
		//年
		String strYear = String.valueOf(objCal.get(Calendar.YEAR));
		//月
		String strMonth = String.valueOf(objCal.get(Calendar.MONTH) + 1);
		if(strMonth.length() == 1)
		{
			strMonth = "0" + strMonth;
		}
		//日
		String strDay = String.valueOf(objCal.get(Calendar.DAY_OF_MONTH));
		if(strDay.length() == 1)
		{
			strDay = "0" + strDay;
		}

		return strYear + strMonth + strDay;
	}
	
	/**
	 * 現在の年月日を取得する
	 * 
	 * @return
	 * @throws Exception
	 */
	private String getNowDate() throws Exception
	{
		Calendar objCal = Calendar.getInstance();
		
		//年
		String strYear = String.valueOf(objCal.get(Calendar.YEAR));
		//月
		String strMonth = String.valueOf(objCal.get(Calendar.MONTH) + 1);
		if(strMonth.length() == 1)
		{
			strMonth = "0" + strMonth;
		}
		//日
		String strDay = String.valueOf(objCal.get(Calendar.DAY_OF_MONTH));
		if(strDay.length() == 1)
		{
			strDay = "0" + strDay;
		}

		return strYear + strMonth + strDay;
	}
	
	/**
	 * HTMLに変数が埋め込まれているか確認
	 *
	 * @param strHTML
	 * @param strParam
	 * @return
	 */
	private boolean isParameter(String strHTML, String strParam)
	{
		String strSearch = strParam.replaceAll("\\\\", "");

		if (strHTML.indexOf(strSearch) != -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
