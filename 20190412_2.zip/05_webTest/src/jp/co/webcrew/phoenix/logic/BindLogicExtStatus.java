package jp.co.webcrew.phoenix.logic;

import java.io.Serializable;
import java.util.Map;

/**
 * バリデーション、スクリーニングロジックの結果を保持するstatusクラス。
 * 
 * @author kurinami
 */
public class BindLogicExtStatus extends BindLogicStdStatus implements Serializable {

    /** デフォルトシリアルバージョン */
    private static final long serialVersionUID = 1L;

    /** バリデーション結果 */
    public Map<String, String[]> vResult;

    /** スクリーニング結果 */
    public Map<String, Map<String, Object[]>> sResult;

    /** 補助的な結果 */
    public Map<String, Object[]> auxResult;
}
