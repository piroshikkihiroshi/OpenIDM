/**
 * 
 */
package jp.co.webcrew.login.common.db;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * @author kazuto.yano
 *
 */
public class VTableRowObject 
{
	public long recId=-1;
	
	public Map<String,String> rowData;
	
	public int accLevel;
	public boolean pubFlag;
	public Date bgnDatetime;
	public Date endDatetime;
	public Date updateTime;
	public String upAdmin;
	public String linkFlag="0";
	
	
	boolean deleteFlag=false;
	
	private static final SimpleDateFormat fmt=new SimpleDateFormat("yyyyMMddHHmmss");
	
	public void delete()
	{
		this.deleteFlag=true;
	}
	
	public boolean isInsert()
	{
		if(this.recId==-1)return true;
		return false;
	}
	
	
	
	public static Date convert_YYYYMMDDHH24MISS_TO_DateObject(String source)
	throws ParseException
	{
		return fmt.parse(source);
	}
	
	public static String convert_Date_TO_YYYYMMDDHH24MISS(Date source)
	{
		return fmt.format(source);
	}
	
	
	/***
	 * オブジェクトの中で管理しているものの一覧を取得する。
	 * デバッグ目的
	 * 
	 * @return
	 */
	public String toString4Debug()
	{
		StringBuilder sb=new StringBuilder();
		
		sb.append("[recId]"+this.recId+"\r\n");
		sb.append("[accLevel]"+this.accLevel+"\r\n");
		sb.append("[pubFlag]"+this.pubFlag+"\r\n");
		sb.append("[bgnDatetime]"+this.bgnDatetime+"\r\n");
		sb.append("[endDatetime]"+this.endDatetime+"\r\n");
		sb.append("[upAdmin]"+this.upAdmin+"\r\n");
		sb.append("[updateTime]"+this.updateTime+"\r\n");
		
		if(this.rowData!=null)
		{
			for(String clmId:this.rowData.keySet())
			{
				sb.append("------------"+"\r\n");
				sb.append("[key]"+clmId+"\r\n");
				sb.append("[val]"+this.rowData.get(clmId)+"\r\n");
			}
		}
		return sb.toString();
		
	}
	
	
	

}
