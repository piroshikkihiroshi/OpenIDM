package jp.co.webcrew.login.common.db.step;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;


public class MortgageEtasteUserInfo extends StepUserInfoCommonDb{

	/** スキーマ名　*/
	public static final String SCHEMA = "MORTGAGE"; 
	/** テーブル名　*/
	public static final String TABLE  = "USER_INFO"; 
	/** ORDER_HIST.ORDER_TEXTに転送する文字列　*/
	public static final String ORDER_TEXT_CAPTION = "不動産担保ローン";
	/** 法人向けサイトであるか否か   */
	public static final boolean CORPORATE_SERVICE_FLG = false;
	
	private String _mortgageTypeId;
	
	/*
	 * 列名定義
	 */
	public static final String USER_ID = "USER_ID";
	public static final String STEP_SITE_ID = "STEP_SITE_ID";
	public static final String CUSTOMER_TYPE_ID = "CUSTOMER_TYPE_ID";
	public static final String NAME_KANJI_1 = "NAME_KANJI_1";
	public static final String NAME_KANJI_2 = "NAME_KANJI_2";
	public static final String NAME_KANA_1 = "NAME_KANA_1";
	public static final String NAME_KANA_2 = "NAME_KANA_2";
	public static final String TEL = "TEL";
	public static final String TEL_MOBILE = "TEL_MOBILE";
	public static final String SECTION = "SECTION";
	public static final String TITLE = "TITLE";
	public static final String EMAIL = "EMAIL";
	public static final String REP_NAME_KANJI_1 = "REP_NAME_KANJI_1";
	public static final String REP_NAME_KANJI_2 = "REP_NAME_KANJI_2";
	public static final String REP_NAME_KANA_1 = "REP_NAME_KANA_1";
	public static final String REP_NAME_KANA_2 = "REP_NAME_KANA_2";
	public static final String REP_SEX_ID = "REP_SEX_ID";
	public static final String REP_BIRTH_DATE = "REP_BIRTH_DATE";
	public static final String REP_ZIP = "REP_ZIP";
	public static final String REP_PREF_ID = "REP_PREF_ID";
	public static final String REP_ADDRESS_1 = "REP_ADDRESS_1";
	public static final String REP_ADDRESS_2 = "REP_ADDRESS_2";
	public static final String REP_ADDRESS_3 = "REP_ADDRESS_3";
	public static final String REP_ADDRESS_4 = "REP_ADDRESS_4";
	public static final String REP_TEL = "REP_TEL";
	public static final String REP_HOME_TYPE_ID = "REP_HOME_TYPE_ID";
	public static final String REP_LOAN_MONEY = "REP_LOAN_MONEY";
	public static final String REP_HONSEKI_ZIP = "REP_HONSEKI_ZIP";
	public static final String REP_HONSEKI_PREF_ID = "REP_HONSEKI_PREF_ID";
	public static final String REP_HONSEKI_ADDRESS_1 = "REP_HONSEKI_ADDRESS_1";
	public static final String REP_HONSEKI_ADDRESS_2 = "REP_HONSEKI_ADDRESS_2";
	public static final String REP_HONSEKI_ADDRESS_3 = "REP_HONSEKI_ADDRESS_3";
	public static final String REP_HONSEKI_ADDRESS_4 = "REP_HONSEKI_ADDRESS_4";
	public static final String REP_ANNUAL_INCOME = "REP_ANNUAL_INCOME";
	public static final String MONTHLY_INCOME = "MONTHLY_INCOME";
	public static final String OCCUPATION_ID = "OCCUPATION_ID";
	public static final String COMPANY_NAME = "COMPANY_NAME";
	public static final String COMPANY_ZIP = "COMPANY_ZIP";
	public static final String COMPANY_PREF_ID = "COMPANY_PREF_ID";
	public static final String COMPANY_ADDRESS_1 = "COMPANY_ADDRESS_1";
	public static final String COMPANY_ADDRESS_2 = "COMPANY_ADDRESS_2";
	public static final String COMPANY_ADDRESS_3 = "COMPANY_ADDRESS_3";
	public static final String COMPANY_ADDRESS_4 = "COMPANY_ADDRESS_4";
	public static final String COMPANY_TEL = "COMPANY_TEL";
	public static final String COMPANY_CONTACT_TEL = "COMPANY_CONTACT_TEL";
	public static final String COMPANY_FAX = "COMPANY_FAX";
	public static final String CONTINUOUS_SERVICE = "CONTINUOUS_SERVICE";
	public static final String BUSINESS_HISTORY = "BUSINESS_HISTORY";
	public static final String STAFF_CNT_ID = "STAFF_CNT_ID";
	public static final String PAY_DAY_ID = "PAY_DAY_ID";
	public static final String INDUSTRY_ID = "INDUSTRY_ID";
	public static final String YEARLY_TURNOVER = "YEARLY_TURNOVER";
	public static final String CAPITAL = "CAPITAL";
	public static final String BANK = "BANK";
	public static final String BANK_BRANCH = "BANK_BRANCH";
	public static final String ACCOUNT_TYPE_ID = "ACCOUNT_TYPE_ID";
	public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
	public static final String PERMIT_WC_FLG = "PERMIT_WC_FLG";
	public static final String FINISH_FLG = "FINISH_FLG";
	public static final String LAST_UPDATE = "LAST_UPDATE";
	public static final String DELETE_DATE = "DELETE_DATE";
	public static final String GUID = "GUID";

	/** ロガー */
	private Logger log = Logger.getLogger(this.getClass());

	private OrderInfo _orderInfo = new OrderInfo();
	
	public OrderInfo getOrderInfo() {
		return _orderInfo;
	}

	public void setOrderInfo(OrderInfo orderInfo) {
		_orderInfo = orderInfo;
	} 

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.db.DBEntity#doInit()
	 */
	public void doInit(){
		setSchema(SCHEMA);
		setTable(TABLE);
		setCorporateService(CORPORATE_SERVICE_FLG);
	}
	
	private MortgageEtasteUserInfo(){}

	/**
	 * コンストラクタ
	 * @param request
	 * @param siteId
	 */
	public MortgageEtasteUserInfo(HttpServletRequest request , String siteId ){
		setSiteId(siteId);
		setHttpRequest(request);
	}
	
 	public boolean doLoad(DBAccess db , String orderId , String userId) throws SQLException{
		if (super.doLoad(db, orderId, userId)) { // USER_INFO読み込み
			OrderInfo orderInfo = getOrderInfo(); 
			orderInfo.setOrderId(orderId);
			return orderInfo.load(db); // ORDER_INFO読み込み
		
		} else {
			return false;
		}
	}
 	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doCreateNewStepId(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	public void doCreateNewStepId(DBAccess db) throws SQLException{
		
		String userId = "";
		String requestId = "";
		ResultSet rs = null;
		try{
			String sql = "SELECT MORTGAGE.SEQ_USER_ID.NEXTVAL  AS USERID,MORTGAGE.SEQ_ORDER_ID.NEXTVAL AS REQUESTID FROM DUAL";
			
			db.prepareStatement(sql);
			rs = db.executeQuery();
			if (db.next(rs)) {
				userId = ValueUtil.nullToStr(rs.getString("USERID"));
				requestId = ValueUtil.nullToStr(rs.getString("REQUESTID"));
			}
			
			setUserId(userId);
			setRequestId(requestId);

		} catch(SQLException e){
			// 例外エラー
			log.error("シーケンス取得中にデータベースエラーが発生しました。",e);
			throw e;
			
		} finally {
			DBAccess.close(rs);
		}
	    
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doPrepareStepDatabase(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	protected void doPrepareStepDatabase(DBAccess db) throws SQLException{

		// MORTGAGEでは、UserInfoとOrderInfoのレコードを一行ずつ作成する
		try{
		      
			// USER_INFOに一行作成
			DBUpdater inserter = new DBUpdater(SCHEMA + ".USER_INFO");
			inserter.addString(USER_ID          , getUserId());
			inserter.addString(STEP_SITE_ID     , getSiteId());
			inserter.addString(CUSTOMER_TYPE_ID , "1");
			inserter.addString(PERMIT_WC_FLG    , trimGet(PERMIT_WC_FLG));
			inserter.addString(FINISH_FLG       , "0");
			inserter.addString(LAST_UPDATE      , DateUtil.currentDbDateStr());
			inserter.addString(GUID             , get(GUID));
			
			inserter.addString(NAME_KANJI_1, trimGet(NAME_KANJI_1));
			inserter.addString(NAME_KANJI_2, trimGet(NAME_KANJI_2));
			inserter.addString(NAME_KANA_1, trimGet(NAME_KANA_1));
			inserter.addString(NAME_KANA_2, trimGet(NAME_KANA_2));
			inserter.addString(TEL, trimGet(TEL));
			inserter.addString(TEL_MOBILE, trimGet(TEL_MOBILE));
			inserter.addString(SECTION, trimGet(SECTION));
			inserter.addString(TITLE, trimGet(TITLE));
			inserter.addString(EMAIL, trimGet(EMAIL));
			inserter.addString(REP_NAME_KANJI_1, trimGet(REP_NAME_KANJI_1));
			inserter.addString(REP_NAME_KANJI_2, trimGet(REP_NAME_KANJI_2));
			inserter.addString(REP_NAME_KANA_1, trimGet(REP_NAME_KANA_1));
			inserter.addString(REP_NAME_KANA_2, trimGet(REP_NAME_KANA_2));
			inserter.addString(REP_SEX_ID, trimGet(REP_SEX_ID));
			inserter.addString(REP_BIRTH_DATE, trimGet(REP_BIRTH_DATE));
			inserter.addString(REP_ZIP, trimGet(REP_ZIP));
			inserter.addString(REP_PREF_ID, trimGet(REP_PREF_ID));
			inserter.addString(REP_ADDRESS_1, trimGet(REP_ADDRESS_1));
			inserter.addString(REP_ADDRESS_2, trimGet(REP_ADDRESS_2));
			inserter.addString(REP_ADDRESS_3, trimGet(REP_ADDRESS_3));
			inserter.addString(REP_ADDRESS_4, trimGet(REP_ADDRESS_4));
			inserter.addString(REP_TEL, trimGet(REP_TEL));
			inserter.addString(REP_HOME_TYPE_ID, trimGet(REP_HOME_TYPE_ID));
			inserter.addString(REP_LOAN_MONEY, trimGet(REP_LOAN_MONEY));
			inserter.addString(REP_HONSEKI_ZIP, trimGet(REP_HONSEKI_ZIP));
			inserter.addString(REP_HONSEKI_PREF_ID, trimGet(REP_HONSEKI_PREF_ID));
			inserter.addString(REP_HONSEKI_ADDRESS_1, trimGet(REP_HONSEKI_ADDRESS_1));
			inserter.addString(REP_HONSEKI_ADDRESS_2, trimGet(REP_HONSEKI_ADDRESS_2));
			inserter.addString(REP_HONSEKI_ADDRESS_3, trimGet(REP_HONSEKI_ADDRESS_3));
			inserter.addString(REP_HONSEKI_ADDRESS_4, trimGet(REP_HONSEKI_ADDRESS_4));
			inserter.addString(REP_ANNUAL_INCOME, trimGet(REP_ANNUAL_INCOME));

			inserter.addString(MONTHLY_INCOME, trimGet(MONTHLY_INCOME));
			inserter.addString(OCCUPATION_ID, trimGet(OCCUPATION_ID));

			inserter.addString(COMPANY_NAME, trimGet(COMPANY_NAME));
			inserter.addString(COMPANY_ZIP, trimGet(COMPANY_ZIP));
			inserter.addString(COMPANY_PREF_ID, trimGet(COMPANY_PREF_ID));
			inserter.addString(COMPANY_ADDRESS_1, trimGet(COMPANY_ADDRESS_1));
			inserter.addString(COMPANY_ADDRESS_2, trimGet(COMPANY_ADDRESS_2));
			inserter.addString(COMPANY_ADDRESS_3, trimGet(COMPANY_ADDRESS_3));
			inserter.addString(COMPANY_ADDRESS_4, trimGet(COMPANY_ADDRESS_4));
			inserter.addString(COMPANY_TEL, trimGet(COMPANY_TEL));
			inserter.addString(COMPANY_CONTACT_TEL, trimGet(COMPANY_CONTACT_TEL));
			inserter.addString(COMPANY_FAX, trimGet(COMPANY_FAX));
			inserter.addString(CONTINUOUS_SERVICE , trimGet(CONTINUOUS_SERVICE));
			
			inserter.insert(db);

			// ORDER_INFOに一行作成
			inserter = new DBUpdater(SCHEMA + ".ORDER_INFO");
			inserter.addString("ORDER_ID"          , getRequestId());
			inserter.addString("USER_ID"           , getUserId());
			inserter.addString("MORTGAGE_TYPE_ID"  , getMortgageTypeId());
			inserter.addString("STATUS_ID"         , "0");
			inserter.addString("CLIENT_IP_ADDRESS" , getRemoteAddr());
			inserter.addString("GUID"              , get(GUID));

			inserter.insert(db);
			
		} catch(SQLException e){
			// 例外エラー
			log.error("UserInfo,OrderInfoの新規レコード作成時にエラーが発生しました。",e);
			throw e;
		
		} finally {
			;
		}	
		
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doIsDifferentFromMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public boolean doIsDifferentFromMemberMst(MemberMst member){
		if (! get (NAME_KANJI_1).equals(member.get(MemberMst.NAME1)) ) return true;
		if (! get (NAME_KANJI_2).equals(member.get(MemberMst.NAME2)) ) return true;
		if (! get (NAME_KANA_1).equals(member.get(MemberMst.FURI1)) ) return true;
		if (! get (NAME_KANA_2).equals(member.get(MemberMst.FURI2)) ) return true;
		if (! get (TEL).equals(member.get(MemberMst.TEL)) ) return true;
		
		return false;
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateFromMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public void doPopulateFromMemberMst(MemberMst member){
		set (GUID , member.get(MemberMst.GUID));
		set (NAME_KANJI_1 , member.get(MemberMst.NAME1));
		set (NAME_KANJI_2 , member.get(MemberMst.NAME2));
		set (NAME_KANA_1 , member.get(MemberMst.FURI1));
		set (NAME_KANA_2 , member.get(MemberMst.FURI2));
		set (TEL , member.get(MemberMst.TEL));

		// メールアドレスは三種類を場合に応じて表示する
		if ( isMobileAccess() ) {
			set (EMAIL , member.get(MemberMst.MB_MAIL));
		} else {
			if ( isCorporateService() ) {
				set (EMAIL , member.get(MemberMst.CP_MAIL));
			} else {
				set (EMAIL , member.get(MemberMst.EMAIL));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public void doPopulateToMemberMst(MemberMst member){
		// メンバーオブジェクトを自動生成する時は、データを切り捨ててでも、なるべく生かす。
		// （文字数制限を自動的に行う）
		
		member.setTrimData(MemberMst.NAME1 , get(NAME_KANJI_1));
		member.setTrimData(MemberMst.NAME2 , get(NAME_KANJI_2));
		member.setTrimData(MemberMst.FURI1 , get(NAME_KANA_1));
		member.setTrimData(MemberMst.FURI2 , get(NAME_KANA_2));
		member.setTrimData(MemberMst.TEL   , get(TEL));
	}

	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToOrderHist(jp.co.webcrew.login.util.db.OrderHist)
	 */
	public void doPopulateToOrderHist(OrderHist order){
		
		order.setTrimData(OrderHist.ORDER_DATETIME , DateUtil.currentDateTime());        // 発注日
		order.setTrimData(OrderHist.ORDER_TYPE     , OrderHist.TYPE_MITSUMORI_IRAI); // 見積もり依頼に固定
		order.setTrimData(OrderHist.SITE_ID        , getSiteId());
		order.setTrimData(OrderHist.ORDER_ID       , getRequestId());

		DBAccess db = null;
		try{
			db = new DBAccess();

			// ORDER_TEXT列にStepサイトの説明文をコピー
			order.setTrimData(OrderHist.ORDER_TEXT, ORDER_TEXT_CAPTION);

			// SUPPLIER_TEXT列に複数のサプライヤ情報をカンマ区切りでコピー

			StringBuffer sqlbuf = new StringBuffer("SELECT MST.NAME FROM ");
			sqlbuf.append("  MORTGAGE.ORDER_COMPANY_INTER INTER, ");
			sqlbuf.append("  MORTGAGE.COMPANY_MST MST ");
			sqlbuf.append("WHERE ");
			sqlbuf.append("  INTER.COMPANY_ID = MST.COMPANY_ID ");
			sqlbuf.append("AND ");
			sqlbuf.append("  INTER.ORDER_ID = ? ");
			
			db.prepareStatement(sqlbuf.toString());
			db.setString(1, getRequestId());
			db.executeQuery();
			List suppliers = Record.getResultListOf(db);
			StringBuffer supplier_text = new StringBuffer("");
			for (int i = 0 ; i < suppliers.size() ; i++) {
				Record supinfo = (Record)suppliers.get(i);
				if (i != 0) {
					supplier_text.append(",");
				}
				supplier_text.append(supinfo.getString("NAME"));
			}
			order.setTrimData(OrderHist.SUPPLIER_TEXT, supplier_text.toString()); 
					
		
		} catch (Exception e) {
			log.error("Stepデータを会員情報の履歴データに転送する際にデータベースエラーが発生しました。",e);
		} finally {
			DBAccess.close(db);
		}
		
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doDeleteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public void doDeleteGuid(DBAccess db , String guid) throws SQLException{
		DBUpdater updater = new DBUpdater(getSchema() + ".ORDER_INFO");
		updater.addString("GUID","");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		updater.update(db);

		updater = new DBUpdater(getSchema() + ".USER_INFO");
		updater.addString(GUID, "");
		updater.setCond("WHERE GUID=?");
		updater.addCondString(guid);
		updater.update(db);

	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doOverWriteGuid(java.lang.String)
	 */
	public boolean doOverWriteGuid(DBAccess db , String guid)  {

		log.info ("ステップのデータベースに対し、guidの上書き処理を開始します。");
		
		return updateGuidCommon(db , guid);
    
	}	
	
	/*
	 * Getter/Setter
	 */
	public String getPrefId(){
		return "";
	}
	
	public void setPrefId(String val){
//		set (PREF_ID , val);
	}

	public String getUserId(){
		return get(USER_ID);
	}
	
	public void setUserId(String val) {
		set(USER_ID , val);
	}

	public String getEmail(){
		return get(EMAIL);
	}

	public String getSexId() {
		return "";
	}

	public String getBirthDate() {
		// 担当者の誕生日は無いので、何も返さない
//		return get (REP_BIRTH_DATE);
		return "";
	}

	public String getBirthYear() {
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(0,4);
		}
		return ret;
	}
	
	
	public String getBirthMonth() {
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(5,7);
		}
		return ret;
	}		
	
	public String getBirthDay(){
		String ret = getBirthDate();
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(8,10);
		}
		return ret;		
	}
	
	public String getZip(){
		// 担当者の郵便番号入力は無いので、何も返さない
//		return get(REP_ZIP);
		return "";
	}


	public void setZip(String val){
//		set(ZIP,val);
	}

	public void setSexId(String val){
	}

	
	public void setBirthDate(String year,String month,String day){
//		set(BIRTH_DATE , year + "-" + month + "-" + day);
	}
	

	/*
	 * private method
	 */
	
	/**
	 * クライアントのIPアドレスを取得する
	 * @return String IPアドレス
	 */
	private String getRemoteAddr() {
		return getHttpRequest().getRemoteAddr();
	}

	/**
	 * 誕生日をYYYYMMDD形式の文字列で取得する
	 * @return String 誕生日 YYYYMMDD
	 */
	private String charBirthDate(){
		return getBirthYear() + getBirthMonth() + getBirthDay();		
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getLastUpdateTime()
	 */
	public String getLastUpdate() {
		String ret = get(LAST_UPDATE);
		if (ret == null || ret.equals("")){
			ret = "";
		} else if (ret.length() < 10){
			ret = "";
		} else {
			ret = ret.substring(0,4) + ret.substring(5,7) + ret.substring(8,10);
		}
		
		return ret;
	}
	
	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getMagFlag()
	 */
	public String getMagFlag() {
		String mag_flag = get(PERMIT_WC_FLG);
		
		if (mag_flag == null) {
			return "" ;
		}
		if (mag_flag.equals("0")) {
			return "0";
		}
		if (mag_flag.equals("1")) {
			return "1";
		}

		return "";
		
	}

	public String getMortgageTypeId() {
		return _mortgageTypeId;
	}

	public void setMortgageTypeId(String mortgageTypeId) {
		_mortgageTypeId = mortgageTypeId;
	}
	
	
	private class OrderInfo extends DBEntity{
//		 MORTGAGE.USER_INFO
		/** スキーマ名　*/
		public static final String SCHEMA = "MORTGAGE"; 
		/** テーブル名　*/
		public static final String TABLE = "ORDER_INFO"; 
		
		public static final String ORDER_ID = "ORDER_ID";
		public static final String USER_ID = "USER_ID";
		public static final String AUTH_KEY = "AUTH_KEY";
		public static final String PASSWORD = "PASSWORD";
		public static final String MORTGAGE_TYPE_ID = "MORTGAGE_TYPE_ID";
		public static final String AMOUNT_APPLIED = "AMOUNT_APPLIED";
		public static final String PERIOD = "PERIOD";
		public static final String USAGE_ID = "USAGE_ID";
		public static final String REPAY_METHOD_ID = "REPAY_METHOD_ID";
		public static final String MORTGAGE_ZIP = "MORTGAGE_ZIP";
		public static final String MORTGAGE_PREF_ID = "MORTGAGE_PREF_ID";
		public static final String MORTGAGE_ADDRESS_1 = "MORTGAGE_ADDRESS_1";
		public static final String MORTGAGE_ADDRESS_2 = "MORTGAGE_ADDRESS_2";
		public static final String MORTGAGE_ADDRESS_3 = "MORTGAGE_ADDRESS_3";
		public static final String MORTGAGE_ADDRESS_4 = "MORTGAGE_ADDRESS_4";
		public static final String MORTGAGE_RANK_ID = "MORTGAGE_RANK_ID";
		public static final String RELATION_OWNER_ID = "RELATION_OWNER_ID";
		public static final String LAND_AREA = "LAND_AREA";
		public static final String LAND_UNIT_ID = "LAND_UNIT_ID";
		public static final String BUILDING_AREA = "BUILDING_AREA";
		public static final String BUILDING_UNIT_ID = "BUILDING_UNIT_ID";
		public static final String MORTGAGE_TO_1 = "MORTGAGE_TO_1";
		public static final String MORTGAGE_FLG_1 = "MORTGAGE_FLG_1";
		public static final String MORTGAGE_MONEY_1 = "MORTGAGE_MONEY_1";
		public static final String MORTGAGE_TO_2 = "MORTGAGE_TO_2";
		public static final String MORTGAGE_FLG_2 = "MORTGAGE_FLG_2";
		public static final String MORTGAGE_MONEY_2 = "MORTGAGE_MONEY_2";
		public static final String MORTGAGE_TO_3 = "MORTGAGE_TO_3";
		public static final String MORTGAGE_FLG_3 = "MORTGAGE_FLG_3";
		public static final String MORTGAGE_MONEY_3 = "MORTGAGE_MONEY_3";
		public static final String URIKAKE_MONEY = "URIKAKE_MONEY";
		public static final String URIKAKE_TERM = "URIKAKE_TERM";
		public static final String TRADE_NUMBER = "TRADE_NUMBER";
		public static final String STOCK_CORP_NAME = "STOCK_CORP_NAME";
		public static final String STOCK_EXCHANGE = "STOCK_EXCHANGE";
		public static final String STOCK_SYMBOL = "STOCK_SYMBOL";
		public static final String STOCK_NUM_HELD = "STOCK_NUM_HELD";
		public static final String BAIKAI_FLG = "BAIKAI_FLG";
		public static final String ORDER_COMMENT_1 = "ORDER_COMMENT_1";
		public static final String ORDER_COMMENT_2 = "ORDER_COMMENT_2";
		public static final String PROM_CODE = "PROM_CODE";
		public static final String DELETE_DATE = "DELETE_DATE";
		public static final String STATUS_ID = "STATUS_ID";
		public static final String APPLY_DATE_1 = "APPLY_DATE_1";
		public static final String REPLY_DATE_1 = "REPLY_DATE_1";
		public static final String APPLY_DATE_2 = "APPLY_DATE_2";
		public static final String APPROVE_DATE = "APPROVE_DATE";
		public static final String REJECT_DATE = "REJECT_DATE";
		public static final String ACCESS_DATE_11 = "ACCESS_DATE_11";
		public static final String ACCESS_DATE_12 = "ACCESS_DATE_12";
		public static final String ACCESS_DATE_13 = "ACCESS_DATE_13";
		public static final String ACCESS_DATE_21 = "ACCESS_DATE_21";
		public static final String ACCESS_DATE_22 = "ACCESS_DATE_22";
		public static final String ACCESS_DATE_23 = "ACCESS_DATE_23";
		public static final String USAGE_HOMELOAN_ID = "USAGE_HOMELOAN_ID";
		public static final String CLIENT_IP_ADDRESS = "CLIENT_IP_ADDRESS";
		public static final String GUID = "GUID";
		
		/**
		 * 
		 * オブジェクト初期化
		 */
		public void init(){
			setSchema(OrderInfo.SCHEMA);
			setTable(OrderInfo.TABLE);
		}
	
		public void setOrderId(String val){
			set (OrderInfo.ORDER_ID , val);
		}
	}	
}
