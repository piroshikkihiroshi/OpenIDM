package jp.co.webcrew.phoenix.store.db;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.phoenix.store.bean.SessionStoreBean;

/**
 * セッションストア情報を管理するdbクラス。
 * 検証不十分なので、リリースしていない
 * 
 * 間違って利用されないように、@Deprecatedマークの付与とクラスからpublicを外している。
 * 
 * @author kazuto.yano
 */
@Deprecated
class SessionStoreDb2 {

    /** セッションストア情報の一覧を取得するためのsql */
    private static final String SELECT_STORE = "select * from session_store where ssid = ? and short_id = ? ";
    
    /** セッションストア情報を挿入するためのsql 
     * 
     * p1:ssid
     * p2:short_id
     * p3:gsid
     * p4:guid
     * p5:key_name
     * p6:store
     * p7:site_id
     * p8:scope
     * p9:store_blob
     * p10:type
     * 
     * */
    private static final String INSERT_STORE = 
    		"insert into session_store" +
    		"(ssid, short_id, gsid, guid, key_name, store, site_id, scope, last_datetime,store_blob,store_type)" +
    		" values(?, ?, ?, ?, ?, ?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'),?,?) ";

    /** セッションストア情報を更新するためのsql 
     * 
     * p1:store
     * p2:store_blob
     * p3:type
     * p4:ssid
     * p5:short_id
     * p6:key_name
     * 
     * */
    private static final String UPDATE_STORE = "update session_store set " +
    		"store = ?, last_datetime = to_char(sysdate, 'YYYYMMDDHH24MISS') ,store_blob=?,store_type=? " +
    		"where ssid = ? and short_id = ? and key_name = ? ";

    /** セッションストア情報を削除するためのsql */
    private static final String DELETE_STORE = "delete from session_store where ssid = ? and short_id = ? and key_name = ?";

    /** セッションストア情報をすべて削除するためのsql */
    private static final String DELETE_ALL_STORE = "delete from session_store where ssid = ? ";

    /** ロガー */
    private static final Logger log = Logger.getLogger(SessionStoreDb2.class);

    private static boolean _useBlob=true;
    private static int _rawLimitSize=1024;
    
    /**
     * DBAccessを作成する。
     * 
     * @return
     * @throws SQLException
     */
    private static DBAccess newDBAccess() throws SQLException {
        return new DBAccess("session_store");
    }

    
    public static void setUseBlob(int rawLimitSize)
    {
    	_useBlob=true;
    	_rawLimitSize=rawLimitSize;
    }

    public static void setUseClob()
    {
    	_useBlob=false;
    }

    
    /**
     * セッションストア情報を返す。
     * 
     * @param ssid
     * @param shortId
     * @return
     * @throws SQLException
     */
    public static SessionStoreBean getSessionStore(long ssid, String shortId) throws SQLException {

        DBAccess dbAccess = null;
        ResultSet rs = null;
        try {
            dbAccess = newDBAccess();

            SessionStoreBean sessionStore = new SessionStoreBean();

            // セッションストア情報を取得する。
            dbAccess.prepareStatement(SELECT_STORE);
            dbAccess.setLong(1, ssid);
            dbAccess.setString(2, shortId);
            rs = dbAccess.executeQuery();
            while (dbAccess.next(rs)) {
                String keyName = ValueUtil.nullToStr(rs.getString("key_name"));
                //Object store = deserialize(rs.getString("store"));
                Object store=deserialize2(rs);
                String scope = Integer.toString(rs.getInt("scope"));
                sessionStore.set(keyName, store, scope);
            }

            return sessionStore;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報を挿入する。
     * 
     * @param ssid
     * @param shortId
     * @param gsid
     * @param guid
     * @param keyName
     * @param store
     * @param siteId
     * @param scope
     * @throws SQLException
     */
    public static void insert(long ssid, String shortId, long gsid, long guid, String keyName, Object store,
            int siteId, String scope) throws SQLException {

        DBAccess dbAccess = null;
        
        //ssid、gsid、guidがいずれも0の場合、insert処理を適用しない。
        if(ssid==0 && gsid==0 && guid==0)
        {
        	log.warn(
        			"ssid,gsid,guidいずれも0のため、" +
        			"ph_session.session_storeへのinsert処理は適用していません。" +
        			"[short_id:key_name]#["+shortId+":"+keyName+"]");
        	return;
        }
        
        try {
            dbAccess = newDBAccess();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // セッションストア情報を挿入する。
            dbAccess.prepareStatement(INSERT_STORE);

            int i = 0;
            dbAccess.setLong(++i, ssid);
            dbAccess.setString(++i, shortId);
            dbAccess.setLong(++i, gsid);
            dbAccess.setLong(++i, guid);
            dbAccess.setString(++i, keyName);
            
            dbAccess.setNull(++i);
            //dbAccess.setString(++i, serialize(store));
            dbAccess.setInt(++i, siteId);
            dbAccess.setInt(++i, ValueUtil.toint(scope));
            
            serialize2(dbAccess, 6, 9, 10, store);
            
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
        	
        	log.error("ph_session.session_storeへの" +
        			"insert処理にて例外検知" +
        			"[err]"+e.getMessage()+
        			"[ssid:gsid:guid:short_id:key_name]#" +
        			"["+ssid+":"+gsid+":"+guid+":"+shortId+":"+keyName+"]",e);
        	
            // ロールバックする。
            dbAccess.rollback();
            throw e;
        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報を更新する。
     * 
     * @param ssid
     * @param shortId
     * @param keyName
     * @param store
     * @throws SQLException
     */
    public static void update(long ssid, String shortId, String keyName, Object store) throws SQLException {
        DBAccess dbAccess = null;
        try {
            dbAccess = newDBAccess();
            /*
            p1:store
            p2:store_blob
            p3:type
            p4:ssid
            p5:short_id
            p6:key_name
            */
            
            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // セッションストア情報を更新する。
            dbAccess.prepareStatement(UPDATE_STORE);

            int i = 0;
            i=3;
            //dbAccess.setString(++i, serialize(store));
            dbAccess.setLong(++i, ssid);
            dbAccess.setString(++i, shortId);
            dbAccess.setString(++i, keyName);
            serialize2(dbAccess, 1, 2, 3, store);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;
        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報を削除する。
     * 
     * @param ssid
     * @param shortId
     * @param keyName
     * @throws SQLException
     */
    public static void delete(long ssid, String shortId, String keyName) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = newDBAccess();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // セッションストア情報を削除する。
            dbAccess.prepareStatement(DELETE_STORE);
            int i = 0;
            dbAccess.setLong(++i, ssid);
            dbAccess.setString(++i, shortId);
            dbAccess.setString(++i, keyName);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * セッションストア情報をすべて削除する。
     * 
     * @param ssid
     * @param shortId
     * @throws SQLException
     */
    public static void deleteAll(long ssid, String shortId) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = newDBAccess();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // sqlを組み立てる。
            StringBuffer sb = new StringBuffer(DELETE_ALL_STORE);
            if (shortId.length() > 0) {
                sb.append(" and short_id = '" + shortId + "'");
            }

            // セッションストア情報を削除する。
            dbAccess.prepareStatement(sb.toString());
            int i = 0;
            dbAccess.setLong(++i, ssid);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    private static final String STORETYPE_RAW="RAW";
    private static final String STORETYPE_GZ="GZ";
    private static final String STORETYPE_ORIGIN="ORIGIN";
    private static final String STORETYPE_DEFAULT="";
    
    
    /**
     * セッションストア情報を文字列に変換する。
     * 
     * @param storeMap
     * @return
     * @throws SQLException
     */
    private static void serialize2(DBAccess dbAccess,int indexStore,int indexBlob,int indexType,Object store) throws SQLException {
        
    	OutputStream streamForClose=null;
        try {
            
        	boolean useBlob=_useBlob;
        	int rawLimitSize=_rawLimitSize;
        	
            //「blobを使用しない」になっている場合
            if(!useBlob)
            {
            	String data=serialize(store);
            	dbAccess.setString(indexStore, data);
            	dbAccess.setNull(indexBlob);
            	dbAccess.setString(indexType, STORETYPE_ORIGIN);
            	//return array; 
            	
            }
            else
            {
            	ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ObjectOutputStream oos = new ObjectOutputStream(baos);
                streamForClose=oos;
                oos.writeObject(store);
                oos.flush();
                byte[] array=baos.toByteArray();
                //if(array.length>1)
	            if(array.length<=rawLimitSize)
	            //if(array.length<=9999999999999999L)
	            {
	            	dbAccess.setNull(indexStore);
	            	dbAccess.setBytes(indexBlob, array);
	            	dbAccess.setString(indexType, STORETYPE_RAW);
	            	//return array; 
	            }
	            else
	            {
	            	streamForClose.close();
	            	baos = new ByteArrayOutputStream();
	            	GZIPOutputStream gzos=new GZIPOutputStream(baos);
	                streamForClose=gzos;
	            	gzos.write(array);
	            	gzos.close();
	            	dbAccess.setNull(indexStore);
	            	//dbAccess.setBytes(i, bytes)
	            	dbAccess.setBytes(indexBlob, baos.toByteArray());
	            	dbAccess.setString(indexType, STORETYPE_GZ);
	            	//return baos.toByteArray();
	            }
            }
        }
        catch (Exception e) 
        {
            throw new SQLException("シリアライズに失敗しました。", e);
        }
        finally
        {
        	try
        	{
        		streamForClose.close();
        	}catch(Exception exc){}
        }
    }

    
    /**
     * セッションストア情報を文字列に変換する。
     * 
     * @param storeMap
     * @return
     * @throws SQLException
     */
    private static String serialize(Object store) throws SQLException {
        // TODO kurinami 【確認】 このやり方で問題ないか。
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(store);
            oos.flush();
            return new String(baos.toByteArray(), "ISO-8859-1");
        } catch (Exception e) {
            throw new SQLException("シリアライズに失敗しました。", e);
        }
    }

    /**
     * ＤＢデータをＪａｖａオブジェクトに復元する
     * 
     * @param store
     * @return
     * @throws SqlException
     */
    private static Object deserialize2(ResultSet rset) 
    {
    	
    	InputStream streamForClose=null;
    	try {
    		
    		String type=ValueUtil.nullToStr(rset.getString("STORE_TYPE"));
    		if(type.equals(STORETYPE_DEFAULT) || type.equals(STORETYPE_ORIGIN))
    		{
                ByteArrayInputStream bais = new ByteArrayInputStream(ValueUtil.nullToStr(rset.getString("STORE")).getBytes("ISO-8859-1"));
                ObjectInputStream ois = new ObjectInputStream(bais);
                streamForClose=ois;
                return (Object) ois.readObject();
    		}
    		else if(type.equals(STORETYPE_RAW))
    		{
    			InputStream is=rset.getBinaryStream("STORE_BLOB");
                ObjectInputStream ois = new ObjectInputStream(is);
                streamForClose=ois;
                return (Object) ois.readObject();
    		}
    		else if(type.equals(STORETYPE_GZ))
    		{
    			InputStream is=rset.getBinaryStream("STORE_BLOB");
                GZIPInputStream gzis=new GZIPInputStream(is);
    			ObjectInputStream ois = new ObjectInputStream(gzis);
                streamForClose=ois;
                return (Object) ois.readObject();
    		}
    		else
    		{
    			throw new Exception("オブジェクトが保存されていません。");
    		}
    		
        } catch (Exception e) {
            log.error("オブジェクトの復元に失敗しました。", e);
            return null;
        }
        finally
        {
        	try
        	{
        		streamForClose.close();
        	}
        	catch(Exception exc){}
        }
    }

    
    /**
     * 文字列をセッションストア情報に戻す。
     * 
     * @param store
     * @return
     * @throws SqlException
     */
    public static Object deserialize(String store) {
        // TODO kurinami 【確認】 このやり方で問題ないか。
        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(store.getBytes("ISO-8859-1"));
            ObjectInputStream ois = new ObjectInputStream(bais);
            return (Object) ois.readObject();
        } catch (ClassNotFoundException e) {
            // TODO kurinami 【確認】 ★ ちゃんとここでエラーが発生するか。
            log.error("オブジェクトの復元に失敗しました。", e);
            return null;
        } catch (IOException e) {
            log.error("デコードに失敗しました。", e);
            return null;
        }
    }
    
    /*
    public static void main(String[] args) 
    throws Exception
    {
    	//DBAccess db=new DBAccess("phoenix");
    	long ssid=8404942;
    	String shortId="kanri_internal";
    	String keyName="phoenix.post_info";//"phoenix.screening_result.file_prepare";
    	long start=new Date().getTime();
    	Object object=SessionStoreDb.getSessionStore(ssid,shortId);
       	long end=new Date().getTime();
    	System.out.println("get:所要時間:"+(end-start));
    	
    	
    	Object store=null;
    	SessionStoreBean ssb=null;
    	if(object instanceof SessionStoreBean)
    	{
    		ssb=(SessionStoreBean)object;
    		Map<String,Object> map=ssb.getAll("phoenix");
    		for(String key:map.keySet())
    		{
    			Object obj=map.get(key);
    	    	System.out.println("[key]"+key+"[val]"+obj);
    			
    			
    		}
    		store=ssb.get(keyName);
    	}
    	
    	if(store==null)
    	{
        	System.out.println("null");
    		return;
    	}
    	
    	start=new Date().getTime();
    	SessionStoreDb.update(ssid, shortId, keyName, store);
    	end=new Date().getTime();
    	System.out.println("fin:所要時間:"+(end-start));

    	start=new Date().getTime();
    	//SessionStoreDb.insert(ssid, shortId, gsid, guid, keyName, store, siteId, scope)
    	SessionStoreDb.insert(2, shortId, 1,1,keyName, store,4160,"0");
    	end=new Date().getTime();
    	System.out.println("fin:所要時間:"+(end-start));

    	
	}
	*/

}
