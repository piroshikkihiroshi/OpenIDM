package jp.co.webcrew.phoenix.util;

import javax.servlet.ServletContext;

public abstract class PhoenixRefreshMstDB 
{
	public abstract void init(ServletContext context);
}
