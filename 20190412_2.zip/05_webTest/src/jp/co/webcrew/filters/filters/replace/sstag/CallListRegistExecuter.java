package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.util.SessionFilterUtil;

/**
 * <pre>
 * コールリスト登録を行うSSTAG
 * 
 * このSSTAGは必ずMemberRegistExecuterを実行終わってから実行するよう、GUIDは変わる可能性があるため
 * </pre>
 * 
 * @author fu
 */
public class CallListRegistExecuter extends SSTagExecuter {

  /** ロガー */
  private static final Logger log = Logger.getLogger(CallListRegistExecuter.class);

  /**
   * CSVカラム最大数
   */
  private static final int CSV_COLUMN_MAX_COUNT = 1000;

  /**
   * 置換前改行コード
   */
  private static final String REPLACE_NEW_LINE_BEFORE = "(\r\n|\n|\r)";

  /**
   * 置換後改行コード
   */
  private static final String REPLACE_NEW_LINE_AFTER = " ";

  /**
   * 区切り文字.
   */
  private static final String SEPARATOR = ",";

  /** コールリスト登録用スレッド */
  private static CallListRegistThread callListRegistThread;

  static {
    // スレッドを開始する。
    callListRegistThread = new CallListRegistThread();
    callListRegistThread.start();
  }

  /*
   * (non-Javadoc)
   * 
   * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
   * javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
   */
  public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {
    String guid = "";
    try {

      String task_id = ValueUtil.nullToStr(parameters.get("task_id")); // 業務ID
      String cl_disp_id = ValueUtil.nullToStr(parameters.get("cl_disp_id"));
      if (task_id.length() == 0) {
        log.error("パラメータエラー パラメータ[task_id]が指定されていません。");
        return "";
      }
      if (cl_disp_id.length() == 0) {
        log.error("パラメータエラー パラメータ[cl_disp_id]が指定されていません。");
        return "";
      }

      // ステップ向けデフォルトはタイトルなし
      String top_title = ValueUtil.nullToStr(parameters.get("top_title")); // 先頭行がタイトル行か否か
      String sep = ValueUtil.nullToStr(parameters.get("sep")); // セパレータ文字
      String charset = ValueUtil.nullToStr(parameters.get("charset")); // 文字コード
      String dup_ok = ValueUtil.nullToStr(parameters.get("dup_ok")); // 電話番号重複
      String auth_code = ValueUtil.nullToStr(parameters.get("auth_code"));// cl_id のMD5値

      String guidNotApply = ValueUtil.nullToStr(parameters.get("guid_not_apply"));// GUID固定空に設定
      if (guidNotApply.equals("1")) {
        guid = "";
      } else {
        // MemberRegistExecuterで実行終わったのGUIDです、このGUIDはユーザーStep利用時の電話番号と紐付けてます
        guid =
            ValueUtil.nullToStr((String) request
                .getAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_GUID_ATTR_KEY));
        guid = SessionFilterUtil.isValidGuid(guid) ? guid : "";
      }
      // CSVデータ作成
      String csv_data_prefix = "csv_data_";
      StringBuilder csvBuilder = new StringBuilder();
      // indexは1から、最大1000個項目
      // 1列目(必須)：電話番号（ハイフンあり、なしどちらも可。数字以外の文字はサプレスされる。） 
      String tel = "";
      for (int idx = 1; idx < CSV_COLUMN_MAX_COUNT; idx++) {
        if (parameters.containsKey(csv_data_prefix + idx)) {
          String paramValue = ValueUtil.nullToStr(parameters.get(csv_data_prefix + idx));
          if(idx == 1){
            tel = paramValue;
            if (tel.length() == 0) {
              log.error("CSVパラメータエラー パラメータ[電話番号]が指定されていません。");
              return "";
            }
          }
          // 3列名のGUIDは再設定
          if (idx == 3) {
            paramValue = guid;
          }
          String itemValue = addQuote(paramValue);
          if (csvBuilder.length() == 0) {
            csvBuilder.append(itemValue);
          } else {
            csvBuilder.append(SEPARATOR).append(itemValue);
          }
        } else {
          break;
        }
      }
      String csv_data = csvBuilder.toString();

      request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_TASK_ID_ATTR_KEY, task_id);
      request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_CL_DISP_ID_ATTR_KEY,
          cl_disp_id);
      request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_TOP_TITLE_ATTR_KEY,
          top_title);
      request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_SEP_ATTR_KEY, sep);
      request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_CHARSET_ATTR_KEY, charset);
      request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_DUP_OK_ATTR_KEY, dup_ok);
      request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_AUTH_CODE_ATTR_KEY,
          auth_code);
      request.setAttribute(CallListRegistThread.CALLLIST_REGIST_THREAD_CSV_DATA_ATTR_KEY, csv_data);

      // データを設定して渡す
      callListRegistThread.push(request, response);

    } catch (Exception e) {
      log.error("予期せぬエラー", e);
    }

    return "";
  }

  /**
   * CSV取込用に値の置換を行います.
   * 
   * @param value 1セルの値
   */
  private String addQuote(String item) {
    if (item == null || item.length() == 0) {
      return "\"\"";
    }
    // 改行コードを半角スペース「 」へ置換
    item = item.replaceAll(REPLACE_NEW_LINE_BEFORE, REPLACE_NEW_LINE_AFTER);
    StringBuffer sb = new StringBuffer();
    sb.append('"');
    for (int idx = 0; idx < item.length(); idx++) {
      char ch = item.charAt(idx);
      if ('"' == ch) {
        sb.append("\"\"");
      } else {
        sb.append(ch);
      }
    }
    sb.append('"');
    return sb.toString();
  }
}
