package jp.co.webcrew.common.mail.proc;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.common.util.WcString;

import oracle.jdbc.OracleConnection;

/**
 * Contains utility functions for type based querying
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: QueryFunctions.java,v 1.18 2007-06-11 18:07:21 kurinami Exp $
 */
public class QueryFunctions {
    
    public static final String NUMBER = "Number";
    public static final String FLOAT = "Float";
    public static final String DATE = "Date:";
    public static final String STRING = "String";
    public static final String LONGSTRING = "LongString";
    public static final String BLOB = "Blob";
    
    
    public static String convertToJavaType(int dbType) {
        switch (dbType) {
        	case Types.INTEGER: return NUMBER; 
        	case Types.NUMERIC: return NUMBER; 
        	case Types.BIGINT: return NUMBER; 
        	case Types.DOUBLE: return FLOAT; 
        	case Types.FLOAT: return FLOAT; 
        	case Types.REAL: return FLOAT; 
        	case Types.DECIMAL: return FLOAT; 
        	case Types.DATE: return DATE + "yyyy/MM/dd"; 
        	case Types.TIME: return DATE + "HH:mm:ss"; 
        	case Types.TIMESTAMP: return DATE + "yyyy/MM/dd HH:mm:ss"; 
            case Types.CLOB: return LONGSTRING; 
        	case Types.LONGVARCHAR: return LONGSTRING; 
            case Types.BLOB: return BLOB; 
            case Types.LONGVARBINARY: return BLOB; 
            case Types.VARBINARY: return BLOB;
            case Types.BINARY: return BLOB;
        	default: return STRING; 
        }
    }

    /**
     * Gets the value from the resultset, using the type parameter to 
     * work out which resultset accessor to use
     */
    public static Object getResultByType(ResultSet rst, String column, 
            String type) throws SQLException {
        if (type == null) {
            return getAsString(rst, column);
        } else if (type.equalsIgnoreCase(NUMBER)) {
            long value = rst.getLong(column);
            return rst.wasNull() ? null : new Long(value);
        } else if (type.equalsIgnoreCase(FLOAT)) {
            float value = rst.getFloat(column);
            return rst.wasNull() ? null : new Float(value);
        } else if (type.equalsIgnoreCase(BLOB)) {
            InputStream content = rst.getBinaryStream(column);
            if (content == null) {
                return null;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte buffer[] = new byte[1024];
            int read = 0;
            try {
                while ((read = content.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
                content.close();
            } catch (IOException err) {
                err.printStackTrace(System.out);
                throw new SQLException("Error reading blob contents");
            }
            return out.toByteArray();
        } else if (type.toUpperCase().startsWith(DATE.toUpperCase())) {
            return rst.getTimestamp(column);
        } else {
            return getAsString(rst, column);
        }
    }
    
    public static String getAsString(ResultSet rst, String column) throws SQLException {
        return getAsString(rst.getCharacterStream(column));
    }
    
    public static String getAsString(Reader content) throws SQLException {
        if (content == null) {
            return null;
        }
        
        StringWriter out = new StringWriter();
        char[] buffer = new char[512];
        int readChars = 0;

        try {
            while ((readChars = content.read(buffer)) != -1)
                out.write(buffer, 0, readChars);
            content.close();
            
            return WcString.convertMS932(out.toString());
            //return out.toString();
            
            // commented out for stepengine - 2005/2/2 - see cheon-san 
            //return StringUtils.convertSJIS(out.toString());
        } catch (IOException err) {
            err.printStackTrace(System.out);
            throw new SQLException("Error reading string contents");
        }            
    }

    /**
     * Sets the value on the query, using the type parameter to 
     * work out which accessor to use
     */
    public static void setParameterByType(Connection connection, PreparedStatement qry, int index,
            Object value, String type) throws SQLException {
        if (type == null) {
            System.out.println("Setting param " + index + " as string : " + value);
            if (value == null) {
                qry.setNull(index, Types.VARCHAR);
            } else {
                String valueStr = "" + value;
                qry.setCharacterStream(index, new StringReader(valueStr), valueStr.length());
            }
        } else if (type.equalsIgnoreCase(NUMBER)) {
            System.out.println("Setting param " + index + " as number : " + value);
            if (value == null) {
                qry.setNull(index, Types.BIGINT);
            } else {
                qry.setLong(index, new Long("" + value).longValue());
            }
        } else if (type.equalsIgnoreCase(FLOAT)) {
            System.out.println("Setting param " + index + " as float : " + value);
            if (value == null) {
                qry.setNull(index, Types.FLOAT);
            } else {
                qry.setFloat(index, new Float("" + value).floatValue());
            }
        } else if (type.toUpperCase().startsWith(DATE.toUpperCase())) {
            System.out.println("Setting param " + index + " as date : " + value);
            if (value == null) {
                qry.setNull(index, Types.TIMESTAMP);
            } else {
                qry.setTimestamp(index, new java.sql.Timestamp(((Date) value).getTime()));
            }
        } else if (type.equalsIgnoreCase(BLOB)) {
            System.out.println("Setting param " + index + " as blob : " + value);
            if (value == null) {
                qry.setNull(index, Types.BLOB);
            } else if (value instanceof byte[]) {
                if (connection instanceof OracleConnection) {
                    oracle.sql.BLOB blob = oracle.sql.BLOB.createTemporary(connection, 
                            false, oracle.sql.BLOB.DURATION_SESSION);
                    blob.setBytes(1, (byte []) value);
                    qry.setBlob(index, blob);
                } else {
                    byte blob[] = (byte []) value;
                    qry.setBytes(index, blob);
                    //qry.setBinaryStream(index, new ByteArrayInputStream(blob), blob.length);
                }
            } else {
                throw new SQLException("Error setting blob parameter: value class=" + 
                        value.getClass().getName());
            }
        } else if (type.equalsIgnoreCase(LONGSTRING)) {
            System.out.println("Setting param " + index + " as clob : " + value);
            if (value == null) {
                qry.setNull(index, Types.CLOB);
            } else if (connection instanceof OracleConnection) {
                oracle.sql.CLOB clob = oracle.sql.CLOB.createTemporary(connection, 
                        false, oracle.sql.CLOB.DURATION_SESSION);
                clob.setString(1, value + "");
                qry.setClob(index, clob);
            } else {
                String valueStr = "" + value;
                qry.setCharacterStream(index, new StringReader(valueStr), valueStr.length());
            }
        } else {
            System.out.println("Setting param " + index + " as string : " + value);
            if (value == null) {
                qry.setNull(index, Types.VARCHAR);
            } else {
                String valueStr = "" + value;
                qry.setCharacterStream(index, new StringReader(valueStr), valueStr.length());
            }
        }
    }
    
    /**
     * Builds a query ready to execute, with all parameters replaced and set
     */
    public static PreparedStatement buildQuery(Connection connection, 
            String sql, Map wildcards, int orderIndex, PreparedStatement reuseQuery) 
            throws SQLException {
                
        // Make a temporary parameter array
        List replaceWildcards = new ArrayList();
        
        // Get the sql
        String finalSQL = buildSQLString(sql, replaceWildcards, wildcards);
        System.out.println("SQL evaluated (order " + orderIndex + ") :" +
                finalSQL);
        
        // Log array length
        System.out.println("Found " + replaceWildcards.size() + " parameters");
        
        // Build the query and set it's parameters
        Connection oracleConnection = getDelegatedConnection(connection);
        PreparedStatement qry = null;
        if (reuseQuery == null) {
            qry = connection.prepareStatement(finalSQL);
        } else {
            qry = reuseQuery;
        }
        int n = 0;
        try {
            for (Iterator i = replaceWildcards.iterator(); i.hasNext(); n++) {
                WildcardValue wc = (WildcardValue) i.next();
                setParameterByType(oracleConnection, qry, n + 1, 
                        wc == null ? null : wc.getValue(), 
                        wc == null ? null : wc.getType());
            }
            return qry;
        } catch (SQLException err) {
            try {qry.close();} catch (SQLException err2) {}
            throw err;
        }
    }

    /**
     * Builds a query ready to execute, with all parameters replaced and set
     */
    public static CallableStatement buildCallableQuery(Connection connection, 
            String sql, Map wildcards, int orderIndex, CallableStatement reuseQuery) 
            throws SQLException {
                
        // Make a temporary parameter array
        List replaceWildcards = new ArrayList();
        
        // Get the sql
        String finalSQL = buildSQLString(sql, replaceWildcards, wildcards);
        System.out.println("SQL evaluated (order " + orderIndex + ") :" +
                finalSQL);
        
        // Log array length
        System.out.println("Found " + replaceWildcards.size() + " parameters");
        
        // Build the query and set it's parameters
        Connection oracleConnection = getDelegatedConnection(connection);
        CallableStatement qry = null;
        if (reuseQuery == null) {
            qry = connection.prepareCall("{call " + finalSQL + "}");
        } else {
            qry = reuseQuery;
        }
        int n = 0;
        try {
            for (Iterator i = replaceWildcards.iterator(); i.hasNext(); n++) {
                WildcardValue wc = (WildcardValue) i.next();
                setParameterByType(oracleConnection, qry, n + 1, 
                        wc == null ? null : wc.getValue(), 
                        wc == null ? null : wc.getType());
            }
            return qry;
        } catch (SQLException err) {
            try {qry.close();} catch (SQLException err2) {}
            throw err;
        }
    }

    /**
     * Replaces the sql (plus wildcards) string with a prepared statement style
     * sql string (ie question marks). Also populates the replace array.
     * 
     * Recurses through the whole string
     */
    public static String buildSQLString(String input, 
            List replaceWildcards, Map wildcards) {
        if (input == null) {
            return null;
        }
        int startPos = input.indexOf("###");

        if (startPos == -1) {
            return input;
        } else {
            int endPos = input.substring(startPos + 3).indexOf("###");

            if (endPos == -1) {
                return input;
            } else {
                // find out wildcard key
                String paramName = input.substring(startPos + 3, 
                        startPos + 3 + endPos);
                
                // add value to replace values
                replaceWildcards.add(CalculationSet.findWildcardInMap(paramName, wildcards));
                
                // return a ? and keep going
                return input.substring(0, startPos) + "?" + 
                	buildSQLString(input.substring(startPos + 3 + endPos +
                        3), replaceWildcards, wildcards);
            }
        }
    }

    public static Connection getDelegatedConnection(Connection pooledConn) throws SQLException {
        if (pooledConn instanceof OracleConnection) {
            return pooledConn;
        } else if (pooledConn.getClass().getName().startsWith("org.apache.commons.dbcp.")) {
            try {
                Class clsDelConn = Class.forName("org.apache.commons.dbcp.DelegatingConnection");
                Method methInnermost = clsDelConn.getMethod("getInnermostDelegate", new Class[0]);
                Connection outConn = (OracleConnection) methInnermost.invoke(
                        pooledConn, new Object[0]);
                if (outConn != null) {
                    return outConn;
                }
                else {
                    // apparently under dbcp 1.1, this is sometimes null, and the following 
                    // seems to work
                    return pooledConn.getMetaData().getConnection();
                }
            } catch (SQLException err) {
                throw err;
            } catch (Throwable err) {
                throw new RuntimeException("Could not extract physical connection", err);
            }
        } else {
            return pooledConn.getMetaData().getConnection();
        }
    }
}
