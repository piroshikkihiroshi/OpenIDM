package jp.co.webcrew.phoenix.vtable;

/**
 * 固定値をまとめたインターフェース
 * 
 * @author kurinami
 */
public interface Constants {

    /** メッセージ：列索引無効 */
    public static final String MES_INVALID_COLUMN_INDEX = "列索引[{0}]が無効です。";

    /** メッセージ：列名無効 */
    public static final String MES_INVALID_COLUMN_NAME = "列名[{0}]が無効です。";

    /** メッセージ：nextメソッド、未呼び出し */
    public static final String MES_NOT_CALLED_NEXT = "ResultSet.nextはコールされませんでした。";

    /** メッセージ：読み取りデータなし */
    public static final String MES_HAS_NO_RECORD = "空の結果セットです。";

    /** メッセージ：メソッド未実装 */
    public static final String MES_NOT_IMPLEMENTED = "未実装のためこのメソッドは使用できません。";

}
