package jp.co.webcrew.login.common.db;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.DBConnectionFactory;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.util.DateUtil;

/**
 * メールテンプレートを扱うクラス
 * 
 * @author Takahashi
 *
 */
public class MailTemplate extends DBEntity{

    /** ロガー */
    private static final Logger log = Logger.getLogger(MailTemplate.class);
    
    /** スキーマ */
	public static final String SCHEMA = DBConnectionFactory.getSchemaFromPropeties();

	/** テーブル名 */
	public static final String TABLE  = "MAIL_TEMPL";

	
	/** デフォルトの仮登録完了通知 */
	public static final String ID_STEP_TEMP_REGIST      = "STEP_TEMP_REGIST";

	/** デフォルトの本登録完了通知 */
	public static final String ID_STEP_REAL_REGIST      = "STEP_REAL_REGIST";

	/** デフォルトのユーザ更新通知 */
	public static final String ID_STEP_REAL_UPDATE      = "STEP_REAL_UPDATE";

	/** デフォルトのリマインダ通知(仮登録者用)  */
	public static final String ID_STEP_TEMP_REMINDER    = "STEP_TEMP_REMINDER";

	/** デフォルトのリマインダ通知(本登録者用)  */
	public static final String ID_STEP_REAL_REMINDER    = "STEP_REAL_REMINDER";

	/** TNS_LOGINの仮登録完了通知 */
	public static final String ID_TNS_TEMP_REGIST       = "TNS_TEMP_REGIST";

	/** TNS_LOGINの本登録完了通知 */
	public static final String ID_TNS_REAL_REGIST       = "TNS_REAL_REGIST";

	/** TNS_LOGINのリマインダ通知(仮登録者用)  */
	public static final String ID_TNS_TEMP_REMINDER     = "TNS_TEMP_REMINDER";

	/** TNS_LOGINのリマインダ通知(本登録者用)  */
	public static final String ID_TNS_REAL_REMINDER     = "TNS_REAL_REMINDER";

	/** MYPAGEのリマインダ通知(仮登録者用)  */
	public static final String ID_MYPAGE_TEMP_REMINDER  = "MYPAGE_TEMP_REMINDER";

	/** MYPAGEのリマインダ通知(本登録者用)  */
	public static final String ID_MYPAGE_REAL_REMINDER  = "MYPAGE_REAL_REMINDER";

	/** MYPAGEの退会処理  */
	public static final String ID_MYPAGE_RESIGN         = "MYPAGE_RESIGN";

	/** TNS_LOGINの仮登録完了通知 */
	public static final String ID_DANDORI_TEMP_REGIST       = "DANDORI_TEMP_REGIST";

	/** TNS_LOGINの本登録完了通知 */
	public static final String ID_DANDORI_REAL_REGIST       = "DANDORI_REAL_REGIST";

	/** TNS_LOGINのリマインダ通知(仮登録者用)  */
	public static final String ID_DANDORI_TEMP_REMINDER     = "DANDORI_TEMP_REMIND";

	/** TNS_LOGINのリマインダ通知(本登録者用)  */
	public static final String ID_DANDORI_REAL_REMINDER     = "DANDORI_REAL_REMIND";
	
	/*
	 * 列名定義 （定数定義）
	 */
	public static final String TEMPL_ID    = "TEMPL_ID"; 
	public static final String PURPOSE     = "PURPOSE"; 
	public static final String MAIL_FROM   = "MAIL_FROM"; 
	public static final String MAIL_TO     = "MAIL_TO"; 
	public static final String MAIL_CC     = "MAIL_CC"; 
	public static final String MAIL_BCC    = "MAIL_BCC"; 
	public static final String SUBJECT     = "SUBJECT"; 
	public static final String BODY        = "BODY"; 
	public static final String MEMO        = "MEMO"; 
	public static final String UP_DATETIME = "UP_DATETIME"; 
	public static final String UP_ADMIN    = "UP_ADMIN"; 

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
	 */
	public void init(){
 		setSchema(SCHEMA);
		setTable(TABLE);
	}

	/**
 	 * コンストラクタ
 	 * 
 	 * @param templ_id メールテンプレートID
 	 */
 	public MailTemplate(String templ_id){
 		set(TEMPL_ID , templ_id);
 	}

	/**
	 * メールテンプレートのsubjectを取得する
	 * 
	 * @return
	 */
	public String getSubject(){
		
		return get(SUBJECT);
	}

	/**
	 * メールテンプレートの本文を取得する
	 * 
	 * @return
	 */
	public String getBody(){
		return get(BODY);
	}

	/**
	 * メールテンプレートのfromを取得する
	 * 
	 * @return
	 */
	public String getFrom(){
		return get(MAIL_FROM);
	}
	
	/**
	 * 非公開コンストラクタ
	 */
 	private MailTemplate(){}

    /**
     * <pre>
     * メールテンプレートに埋め込まれたシステムプロパティの置換変数を、
     * システムプロパティ値に変換する。
     * 
     * 置換変数は、$$SYSPROP_システムプロパティのキー名$$とする。
     * 
     * 例）
     *   
     * キーがXXX, 値がAAA のシステムプロパティが設定されているとき
     * 
     * 置換前
     *   $$SYSPROP_XXX$$
     * 
     * 置換後
     *   AAA
     * 
     * </pre>
     * @param body メールテンプレート本文
     * @return
     */
    public static String replaceSysProp (String body) {
        if (body == null) {
            return null;
        }
        
        if (body.equals("")) {
            return "";
        }

        DBAccess db = null;
        try {
            db = new DBAccess();
  
            // システムプロパティを取得
            SystemProperties props = new SystemProperties(db);

            Pattern pattern;
            Matcher matcher;

            // 全ての$$Sysprop.xxx$$ に対して、$$SYSPROP_xxx$$ をシステムプロパティ(xxx)の値で置換する
            pattern = Pattern.compile("\\$\\$SYSPROP_(.+?)\\$\\$");
            matcher = pattern.matcher(body);
            StringBuffer sb = new StringBuffer();
            while (matcher.find()) {
                String key = matcher.group(1); // (.+?)の中身 を取得
                String val = ValueUtil.nullToStr(props.get(key)); // システムプロパティの値を取得
                if (val.equals("")) {
                    log.error("システムプロパティ " + key + "が見つかりませんでした。");
                    // return null; //TODO 要確認。メール送信を中止する場合はnullを返す。
                    val = "!";
                }
                matcher.appendReplacement(sb, val);
            }
            matcher.appendTail(sb);

            return sb.toString();

        } catch (Exception e) {
        
            return null;

        } finally {
            DBAccess.close(db);
        }        
     
    }

    /**
     * <pre>
     * メールテンプレートの日時変数を現在時刻で置換する
     * 
     * 現在時刻がyyyymmddhhmissの14桁として、次のように置換。
     * 
     * $$year$$   → 年 yyyy
     * $$month$$  → 月 mm
     * $$day$$    → 日 dd
     * $$hour$$   → 時 hh
     * $$minute$$ → 分 mi
     * $$second$$ → 秒 ss
     * 
     * 本文bodyがnullの時はnull
     * 空文字の時は空文字で返す
     * 
     * </pre>
     * 
     * @param body メール本文
     */
    public static String replaceDateTime (String body) {

        if (body == null) {
            return null;
        }
        
        if (body.equals("")) {
            return "";
        }
        
        String dt   = DateUtil.currentDateTime();
        String yyyy = dt.substring( 0 ,  4);
        String mm   = dt.substring( 4 ,  6);
        String dd   = dt.substring( 6 ,  8);
        String hh   = dt.substring( 8 , 10);
        String mi   = dt.substring(10 , 12);
        String ss   = dt.substring(12 , 14);
        
        body = body.replaceAll("\\$\\$year\\$\\$"       , yyyy);
        body = body.replaceAll("\\$\\$month\\$\\$"      , mm);
        body = body.replaceAll("\\$\\$day\\$\\$"        , dd);
        body = body.replaceAll("\\$\\$hour\\$\\$"       , hh);
        body = body.replaceAll("\\$\\$minute\\$\\$"     , mi);
        body = body.replaceAll("\\$\\$second\\$\\$"     , ss);  
        
        return body;
    }
}
