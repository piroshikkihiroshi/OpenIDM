SELECT
        (
            CASE
                WHEN khn.法人コード = '100' THEN 'den' || SUBSTRING(
                    khn.社員コード
                    ,1
                    ,5
                )
                ELSE (
                    SELECT
                            hhm."ユーザID用会社名" || '0' || SUBSTRING(
                                khn.社員コード
                                ,2
                                ,4
                            )
                        FROM
                            法人法人名情報 AS hhm
                        WHERE
                            (hhm.法人コード = khn.法人コード)
                )
            END
        ) AS ユーザID
        ,khn.社員コード
        ,khn.社員名称漢字
        ,khn.任意項目４
        ,kso.発令年月日
        ,kso.組織コード AS 主務部署コード
        ,hso.組織名１
        ,hso.組織名２
        ,hso.組織名３
        ,hso.組織名４
        ,hso.組織名５
        ,hso.組織コード１
        ,hso.組織コード２
        ,hso.組織コード３
        ,hso.組織コード４
        ,hso.組織コード５
        ,han.発令年月日
        ,han.参照項目コード AS 主務役職コード
        ,han.参照項目名称 AS 主務役職名称
        ,hat.発令年月日
        ,hat.事由コード
        ,hat.事由内容
        ,hat.休退職区分
    FROM
        公開基本情報 AS khn INNER JOIN (
            SELECT
                    *
                FROM
                    公開発令情報
                WHERE
                    (
                        法人コード
                        ,社員コード
                        ,発令年月日 || 更新年月日
                    ) IN (
                        SELECT
                                法人コード
                                ,社員コード
                                ,MAX(発令年月日 || 更新年月日)
                            FROM
                                公開発令情報
                            WHERE
                                ((発令年月日 <= '20151101'))
                            GROUP BY
                                法人コード
                                ,社員コード
                    )
        ) AS hat
            ON (khn.法人コード || khn.社員コード = hat.法人コード || hat.社員コード) INNER JOIN (
                SELECT
                        *
            FROM
                公開組織情報
            WHERE
                (
                    法人コード
                    ,社員コード
                    ,発令年月日 || 更新年月日
                ) IN (
                    SELECT
                            法人コード
                            ,社員コード
                            ,MAX(発令年月日 || 更新年月日)
                        FROM
                            公開組織情報
                        WHERE
                            (発令年月日 <= '20151101')
                        GROUP BY
                            法人コード
                            ,社員コード
                )
            ) AS kso
                ON (khn.法人コード || khn.社員コード = kso.法人コード || kso.社員コード) INNER JOIN (
                    SELECT
                            *
                FROM
                    法人組織情報
                WHERE
                    (
                        法人コード
                        ,組織コード
                        ,改定年月日
                    ) IN (
                        SELECT
                                法人コード
                                ,組織コード
                                ,MAX(改定年月日)
                            FROM
                                法人組織情報
                            GROUP BY
                                法人コード
                                ,組織コード
                    )
                ) AS hso
                    ON (hso.組織コード = kso.組織コード)
                LEFT JOIN (
                    SELECT
                            *
                        FROM
                            公開汎用発令情報
                        WHERE
                            (
                                法人コード
                                ,社員コード
                                ,発令種別コード || 発令年月日 || 更新年月日
                            ) IN (
                                SELECT
                                        法人コード
                                        ,社員コード
                                        ,MAX('0001' || 発令年月日 || 更新年月日)
                                    FROM
                                        公開汎用発令情報 AS han
                                    WHERE
                                        発令種別コード = '0001'
                                        AND (発令年月日 <= '20151101')
                                    GROUP BY
                                        法人コード
                                        ,社員コード
                            )
                ) AS han
                    ON (khn.法人コード || khn.社員コード = han.法人コード || han.社員コード)
        WHERE
            (
                (hat.発令年月日 <= '20151101')
                AND (hat.発令年月日 >= '20151101')
            )
            AND (khn.法人コード != 'JPU')
        ORDER BY
            khn.法人コード
            ,khn.社員コード;
