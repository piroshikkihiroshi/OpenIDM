﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SearchForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.objGridView = New System.Windows.Forms.DataGridView()
        Me.ExcelOutput = New System.Windows.Forms.Button()
        CType(Me.objGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'objGridView
        '
        Me.objGridView.AllowUserToAddRows = False
        Me.objGridView.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.objGridView.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.objGridView.BackgroundColor = System.Drawing.SystemColors.Control
        Me.objGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.objGridView.DefaultCellStyle = DataGridViewCellStyle2
        Me.objGridView.Location = New System.Drawing.Point(2, 5)
        Me.objGridView.Name = "objGridView"
        Me.objGridView.RowTemplate.Height = 21
        Me.objGridView.Size = New System.Drawing.Size(158, 107)
        Me.objGridView.TabIndex = 0
        '
        'ExcelOutput
        '
        Me.ExcelOutput.Location = New System.Drawing.Point(459, 281)
        Me.ExcelOutput.Name = "ExcelOutput"
        Me.ExcelOutput.Size = New System.Drawing.Size(79, 22)
        Me.ExcelOutput.TabIndex = 1
        Me.ExcelOutput.Text = "Excel出力"
        Me.ExcelOutput.UseVisualStyleBackColor = True
        '
        'SearchForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(557, 314)
        Me.Controls.Add(Me.ExcelOutput)
        Me.Controls.Add(Me.objGridView)
        Me.Name = "SearchForm"
        Me.Text = "SearchForm"
        CType(Me.objGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents objGridView As System.Windows.Forms.DataGridView
    Friend WithEvents ExcelOutput As System.Windows.Forms.Button
End Class
