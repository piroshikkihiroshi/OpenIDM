package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.TermMstDb;
import jp.co.webcrew.filters.filters.session.UserInfo;

/**
 * <pre>
 *  DoCoMoからのアクセスであると判断された場合のみ、DoCoMoマイメニュー登録/解除リンクを表示するためのSSTAG
 *  ・DoCoMoからのアクセスである場合のみ、マイメニュー登録/削除リンクを表示する。
 *  ・セッション(site_session)にプロモコードが登録されている場合は、
　*  マイメニュー登録リンクの"nl"パラメータの値となるURLに"ID"パラメータとしてプロモコードを設定する。
 * </pre>
 * 
 * @author amit
 */
public class DocomoMymenuRegLinkExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(DocomoMymenuRegLinkExecuter.class);

	public String execute(Map parameters, HttpServletRequest request,
			HttpServletResponse response) 
	{

		try 
		{
			// user-agentの取得
			String strUserAgent = (String) request.getHeader("user-agent");

			// carrierIdの取得
			String strCarrierId = TermMstDb.getCarrier(strUserAgent);
			StringBuffer sbufReturnHTML = new StringBuffer("");
			if (TermMstDb.TYPE_DOCOMO.equals(strCarrierId)) {
				// Get Return URL from the parameter
				String strReturnURL = ValueUtil.nullToStr(parameters.get("return_url"));
				String strCI = ValueUtil.nullToStr(parameters.get("ci"));
				String strPromoCode = getPromoCode(request);

				sbufReturnHTML.append("<span style=\"color:#FF0000;\">&#xE6D9;</span>")
					.append("<a href=\"http://w1m.docomo.ne.jp/cp/regst?ci=").append(strCI).append("&uid=NULLGWDOCOMO&nl=")
					.append(strReturnURL);
				
				if (strPromoCode != null) {
					sbufReturnHTML.append("%3FID%3D").append(strPromoCode);
				}
				
				sbufReturnHTML.append("&rl=&act=reg\">ﾏｲﾒﾆｭｰ登録</a>/")
					.append("<a href=\"http://w1m.docomo.ne.jp/cp/regst?ci=").append(strCI)
					.append("&uid=NULLGWDOCOMO&nl=&rl=&act=rel\">削除</a><br />");
			}

			return sbufReturnHTML.toString();
			
		}
		catch (Exception objExp) 
		{
			log.error("予期せぬエラー", objExp);
		}
		return "";
	}
	
	/**
	 * Getting the promotion code from site_session table
	 * 
	 */
	public String getPromoCode(HttpServletRequest request) throws SQLException 
	{
		/** Site Session情報取得用SQL */
		String SITE_SESSION_SELECT = "select promo_code from tonashiba.site_session where ssid=?";
		
		DBAccess dbAccess = null;
		ResultSet rs = null;
		try 
		{
			dbAccess = new DBAccess();

			// サイト情報を検索する。
			dbAccess.prepareStatement(SITE_SESSION_SELECT);
			dbAccess.setString(1, (String)request.getAttribute(UserInfo.SSID_ATTR_KEY));
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {
				return rs.getString("promo_code");
			}
			return null;	

		} 
		finally 
		{
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}
	}	
}
