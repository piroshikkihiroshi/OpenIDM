package jp.co.webcrew.common.mail.proc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * Models a single calculation within the XML for mail calculations
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: CalculationExpression.java,v 1.12 2006-12-08 13:34:37 rickk Exp $
 */
public class CalculationExpression extends Expression {
    static final String ELEM_SQL = "sql";
    
    private String sql;

    public CalculationExpression(Node node) {
        super(node);
        
        // Read the body in, then override with child node values, so we can 
        // use both body and <sql> sub nodes to populate the sql
        this.sql = node.getFirstChild().getNodeValue();
        NodeList nodeList = node.getChildNodes();
        for (int n = 0; n < nodeList.getLength(); n++) {
            Node childNode = nodeList.item(n);

            if (childNode.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            } else if (childNode.getNodeName().equals(ELEM_SQL)) {
                this.sql = childNode.getFirstChild().getNodeValue();
            }
        }
    }

    /**
     * Executes the SQL select statement, and adds the results to the source array
     */
    public void evaluateExpression(Connection connection,
            List wildcardRows) throws SQLException {
        
        PreparedStatement qry = null;
        try {
            for (Iterator k = wildcardRows.iterator(); k.hasNext(); ) {
                Map wildcards = (Map) k.next();
                doReplace(wildcards);
                qry = QueryFunctions.buildQuery(connection, 
                        this.sql, wildcards, getOrderIndex(), qry);
                ResultSet rst = null;
                try {
                    rst = qry.executeQuery();
                    ResultSetMetaData rstMD = rst.getMetaData();
                    int outWildcardCount = rstMD.getColumnCount();
                    Map outWildcards = new HashMap();
                    System.out.println("Found " + outWildcardCount + " columns");

                    // Initialise out wildcards from the labels, set to null
                    for (int n = 0; n < outWildcardCount; n++) {
                        String label = rstMD.getColumnLabel(n + 1);
                        String type = QueryFunctions.convertToJavaType(
                                rstMD.getColumnType(n + 1));
                        WildcardValue wc = CalculationSet.makeWildcardValue(label, null, type);
                        outWildcards.put(wc.getName(), wc);
                    }

                    // Populate from the resultset
                    if (rst.next()) {
                        for (Iterator i = outWildcards.values().iterator(); i.hasNext(); ) {
                            WildcardValue wc = (WildcardValue) i.next();
                            Object value = QueryFunctions.getResultByType(rst, wc.getName(), 
                                    wc.getType());
                            wc.setValue(value);
                        }
                    }
                    wildcards.putAll(outWildcards);
                } finally {
                    if (rst != null) {
                        rst.close();
                    }
                }
            }
        } finally {
            if (qry != null) {
                qry.close();
            }        
        }
    }
}
