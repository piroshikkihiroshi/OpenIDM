package jp.co.webcrew.filters.filters;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.MobileSiteRedirectMstDb;
import jp.co.webcrew.filters.db.MobileUserAgentMstDb;

/**
 * mobileからのアクセスに対して反応するフィルター。(※mobileアクセスはUserAgentで判定される。)
 * リクエストURLと機種タイプ(上位、下位、非対応)から指定のURLへリダイレクトさせる。
 * リダイレクト先のURLは、DBのcommon.MOBILE_SITE_REDIRECT_MST テーブルへリクエストURL、機種タイプと共に指定する。
 * 機種タイプの設定値は MobileUserAgentMstDbクラスの定義を参照すること。
 * 
 * param : defaultType - UserAgentから機種タイプが特定できなかった場合のデフォルトタイプを指定する。
 *                       このパラメータも指定されていなかった場合は上位機種(3)をデフォルトとする。
 * param : disableTypes - フィルタリングの対象から外す機種タイプを指定する。
 * 
 * @author katsuno
 */
public class MobileTypeBasedSortingFilter implements Filter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(MobileTypeBasedSortingFilter.class);
	
	private String defaultType = null;
	private List disableTypes = null;
	
	
	public void init(FilterConfig filterConfig) throws ServletException {
		log.info("init MobileTypeBasedSortingFilter start.");
		
		try{
			// 必要なDBを初期化しておく
			MobileSiteRedirectMstDb.getInstance().init();
			
			// initParameterを一つずつ確認する。
			Enumeration initParamNames = filterConfig.getInitParameterNames();
			while (initParamNames.hasMoreElements()) {
				String name = (String) initParamNames.nextElement();
				String value = ValueUtil.nullToStr(filterConfig.getInitParameter(name));
				
				// デフォルトの機種タイプを設定する。
				if(name.equalsIgnoreCase("defaultType")) {
					defaultType = value;
					continue;
				}
				
				// フィルタ無効の機種タイプリストを設定する。
				if(name.equalsIgnoreCase("disableTypes")) {
					StringTokenizer stValue = new StringTokenizer(value, ",");
					while(stValue.hasMoreTokens()) {
						if(disableTypes == null) {
							disableTypes = new ArrayList();
						}
						disableTypes.add(stValue.nextToken().trim()); 
					}
					continue;
				}
			}
		} catch(Exception e) {
			log.error("予期せぬエラー", e);
			throw new ServletException(e);
		}
		
		log.info("init MobileTypeBasedSortingFilter end.");
	}
	
	public void destroy() {
		// 処理なし

	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		log.info("doFilter MobileTypeBasedSortingFilter start.");
		
		HttpServletRequest httpServletRequest = (HttpServletRequest)request;
		HttpServletResponse httpServletResponse = (HttpServletResponse)response;
		
		// リダイレクトマップの取得		
		MobileSiteRedirectMstDb mobileSiteRedirectMstDb = MobileSiteRedirectMstDb.getInstance();
		
		log.info("httpServletRequest.getRequestURL() --> " + httpServletRequest.getRequestURL().toString());
		
		// リクエストURLをキーにリダイレクト情報を取得する
		String strRequestURL = httpServletRequest.getRequestURL().toString();
		if (strRequestURL != null && strRequestURL.endsWith("/"))
			strRequestURL += "index.html";
		
		Map redirectUrlMap = mobileSiteRedirectMstDb.getRedirectUrlMap(strRequestURL);
		
		log.info("redirectUrlMap --> " + redirectUrlMap);
		
		if(redirectUrlMap != null) {
			// user-agentマスタの取得
			MobileUserAgentMstDb mobileUserAgentMstDb = MobileUserAgentMstDb.getInstance();
			Map userAgentMap = mobileUserAgentMstDb.getUserAgentMap();
			
			// user-agentの取得
			String userAgent = ValueUtil.nullToStr(httpServletRequest.getHeader("user-agent"));
			
			// user-agentのタイプを取得する
			String type = null;
			Iterator iterUserAgents = userAgentMap.keySet().iterator();
			while(iterUserAgents.hasNext()){
				String ua = (String)iterUserAgents.next();
				
				if(userAgent.indexOf(ua) != -1) {
					type = (String)userAgentMap.get(ua);
					break;
				}
			}
			
			// user-agentタイプが取得できなかった場合、defaultType設定を指定する。この指定が無い場合は上位機種とする。
			if(type == null) {
				if(defaultType != null) {
					type = defaultType;
				} else {
					type = MobileUserAgentMstDb.TYPE_UPPER;
				}
			}
			
			// フィルタ無効設定を確認する
			if(disableTypes == null || !disableTypes.contains(type))  {
				// 指定のURLへリダイレクトする
				try {
					String redirectUrl = (String)redirectUrlMap.get(type);
					
					if(redirectUrl != null) {
						log.info("mobile_type : " + type);
						log.info("redirect_url : " + redirectUrl);
						
						httpServletResponse.sendRedirect(redirectUrl);
						return;
					} else {
						log.error("リダイレクトURLが取得できませんでした。リダイレクトマスタ情報を確認してください。");
						throw new Exception("InternalError!!");
					}
				} catch(IOException e) {
					log.error("予期せぬエラー", e);
				} catch(Exception e) {
					log.error("予期せぬエラー", e);
				}
			}
			
		}

		// フィルタチェーン
		chain.doFilter(request, response);
		
		log.info("doFilter MobileTypeBasedSortingFilter end.");
	}
}
