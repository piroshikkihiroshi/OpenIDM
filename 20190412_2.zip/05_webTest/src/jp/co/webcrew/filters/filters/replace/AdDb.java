package jp.co.webcrew.filters.filters.replace;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.SystemPropertiesDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.util.DBAccessUtil;

/**
 * 広告を管理するためのdbクラス。
 * 
 * @author kurinami
 */
public class AdDb {

	/** system_propertiesテーブル用のスキーマ名格納キー値 */
	private static final String SCHEMA_NAME_PROP_KEY = "WCADVMAN_SCHEMA_NAME";

	private static String SELECT_PAGE_SPACE_MST = ""
			+ "select space_id from {0}.page_space_mst where site_id = ? and page_level_id = ? and page_id = ? and page_space_num = ?";

	/** 広告枠を取得するためのsql */
	private static String SELECT_AD_WINDOW_INFO = ""
			+ "select * \n"
			+ "  from {0}.space_mst left outer join {0}.site_mst on space_mst.site_id = site_mst.site_id \n"
			+ "          left outer join {0}.ad_window_info on space_mst.space_id = ad_window_info.space_id \n"
			+ "                                        and sysdate between ad_window_info.start_date and ad_window_info.end_date \n"
			+ " where space_mst.space_id = ?";

	/** インプレッション情報を取得するためのsql */
	private static String SELECT_IMPRESSION_INFO = ""
			+ "select * \n"
			+ "  from {0}.impression_info \n"
			+ " where (to_char(sysdate, ''D'') = 1 and sun_impression_flg = 1 \n"
			+ "    or to_char(sysdate, ''D'') = 2 and mon_impression_flg = 1 \n"
			+ "    or to_char(sysdate, ''D'') = 3 and tue_impression_flg = 1 \n"
			+ "    or to_char(sysdate, ''D'') = 4 and wed_impression_flg = 1 \n"
			+ "    or to_char(sysdate, ''D'') = 5 and thu_impression_flg = 1 \n"
			+ "    or to_char(sysdate, ''D'') = 6 and fri_impression_flg = 1 \n"
			+ "    or to_char(sysdate, ''D'') = 7 and sat_impression_flg = 1) \n"
			+ "   and to_char(sysdate, ''HH24MI'') between start_time and end_time \n"
			+ "   and final_impression_ratio <> 0 \n"
			+ "   and ad_window_id = ? \n"
			+ " order by abs(dbms_random.random()) / final_impression_ratio ";

	/** デフォルト広告情報を取得するためのsql */
	private static String SELECT_DEFAULT_AD_INFO = ""
			+ "select * \n"
			+ "  from {0}.default_ad_info inner join {0}.space_mst on default_ad_info.space_id = space_mst.space_id \n"
			+ " where sysdate >= default_ad_info.effective_date \n"
			+ "   and default_ad_info.space_id = ? \n"
			+ " order by default_ad_info.effective_date desc";

	/** 広告IDから広告の内容を取得するためのsql */
	private static final String SELECT_AD = ""
			+ "select * from {0}.ad_source_mst where ad_id = ? and ad_source_no = ? ";

	/** インプレッション履歴を挿入するためのsql */
	private static final String INSERT_IMPRESSION_LOG = ""
			+ "insert into {0}.impression_log(seq_no, session_id, site_id, ad_id, ad_window_id, space_id, impression_date) values({0}.impression_no_seq.nextval, ?, ?, ?, ?, ?, sysdate)";

	/** クリック履歴を挿入するためのsql */
	private static final String INSERT_CLICK_LOG = ""
			+ "insert into {0}.click_log(seq_no, session_id, site_id, ad_id, ad_window_id, space_id, click_date, user_agent, ip, referer) values({0}.click_no_seq.nextval, ?, ?, ?, ?, ?, sysdate, ?, ?, ?)";

	/**
	 * 場所IDを返す。
	 * 
	 * @param siteId
	 * @param groupCodes
	 * @param gegege
	 * @return
	 * @throws SQLException
	 */
	public static String getSpaceId(int siteId, String[] pageIds,
			int pageSpaceNum) throws SQLException {

		// スキーマ名の取得
		String schmaName = SystemPropertiesDb.getInstance().get(
				SCHEMA_NAME_PROP_KEY);

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			// 広告枠を検索する。
			String sql = new MessageFormat(SELECT_PAGE_SPACE_MST)
					.format(new String[] { schmaName });

			for (int i = pageIds.length - 1; i >= 0; i--) {
				try {
					dbAccess.prepareStatement(sql);
					dbAccess.setInt(1, siteId);
					dbAccess.setInt(2, i + 1);
					dbAccess.setString(3, pageIds[i]);
					dbAccess.setInt(4, pageSpaceNum);

					rs = dbAccess.executeQuery();
					if (dbAccess.next(rs)) {
						return rs.getString("space_id");
					}

				} finally {
					DBAccess.close(rs);
				}
			}

			return null;

		} finally {
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * 場所IDから今回表示する広告の内容を返す。
	 * 
	 * @param spaceId
	 * @return
	 * @throws SQLException
	 */
	public static Map getAdDetail(String spaceId) throws SQLException {

		// スキーマ名の取得
		String schmaName = SystemPropertiesDb.getInstance().get(
				SCHEMA_NAME_PROP_KEY);

		DBAccess dbAccess = null;
		ResultSet rs = null;
		String sql = "";
		try {
			dbAccess = new DBAccess();

			// 広告枠を検索する。
			String searchSpaceId = spaceId;
			int adWindowId = 0;
			Set spaceIdSet = new HashSet();
			String imgPathPrefix = "";
			int spaceWidth = 0;
			int spaceHeight = 0;
			sql = new MessageFormat(SELECT_AD_WINDOW_INFO)
					.format(new String[] { schmaName });
			while (true) {
				try {
					dbAccess.prepareStatement(sql);
					dbAccess.setString(1, searchSpaceId);
					rs = dbAccess.executeQuery();
					if (dbAccess.next(rs)) {

						// 画像パスプレフィックスと場所サイズを取得しておく。
						imgPathPrefix = ValueUtil.nullToStr(rs
								.getString("img_path_prefix"));

						if (rs.getInt("ad_window_id") != 0) {
							// 広告枠が見つかった場合、

							if (spaceIdSet.size() == 0
									|| rs.getInt("succession_flg") == 1) {
								// その広告枠がもともとの場所IDのものであるか、もしくは、親場所の枠でかつ子への相続が許されている場合、

								// その広告枠を使用する。
								adWindowId = rs.getInt("ad_window_id");
								spaceWidth = rs.getInt("width");
								spaceHeight = rs.getInt("height");
							} else {
								// その広告枠が子への相続が許されていない親の広告枠の場合、

								// 広告枠検索をあきらめる。
							}

							break;
						} else {
							// 広告枠が見つからなかった場合、

							spaceIdSet.add(searchSpaceId);
							searchSpaceId = ValueUtil.nullToStr(rs
									.getString("parent_space_id"));
							if (searchSpaceId.length() == 0
									|| spaceIdSet.contains(searchSpaceId)) {
								// 親場所IDが存在しないか、もしくは、既に検索した場所IDの場合、

								// 広告枠検索をあきらめる。
								break;
							} else {
								// 親場所IDがまだ検索していない場所IDの場合、

								// 広告枠検索をループで続ける。
							}
						}

					} else {
						// 場所情報自体が見つからない場合は、広告枠検索をあきらめる。
						break;
					}
				} finally {
					DBAccess.close(rs);
				}
			}

			String adId = "";
			int adSourceNo = 0;

			if (adWindowId != 0) {
				// 広告枠が見つかった場合、

				// インプレッション情報から該当の広告ソースを検索する。
				try {
					sql = new MessageFormat(SELECT_IMPRESSION_INFO)
							.format(new String[] { schmaName });
					dbAccess.prepareStatement(sql);
					dbAccess.setInt(1, adWindowId);
					rs = dbAccess.executeQuery();
					if (dbAccess.next(rs)) {
						adId = ValueUtil.nullToStr(rs.getString("ad_id"));
						adSourceNo = rs.getInt("ad_source_no");
					}
				} finally {
					DBAccess.close(rs);
				}

			}

			if (adId.length() == 0) {
				// 広告が見つからなかった場合(広告枠が見つからなかった場合含む)、

				// デフォルト広告情報から該当の広告ソースを検索する。
				try {
					sql = new MessageFormat(SELECT_DEFAULT_AD_INFO)
							.format(new String[] { schmaName });
					dbAccess.prepareStatement(sql);
					dbAccess.setString(1, spaceId);
					rs = dbAccess.executeQuery();
					if (dbAccess.next(rs)) {
						adId = ValueUtil.nullToStr(rs.getString("ad_id"));
						adSourceNo = rs.getInt("ad_source_no");
						spaceWidth = rs.getInt("width");
						spaceHeight = rs.getInt("height");
					} else {
						// デフォルトの広告も見つからなかった場合、nullを返す。
						return null;
					}
				} finally {
					DBAccess.close(rs);
				}
			}

			// 広告を検索する。
			try {
				sql = new MessageFormat(SELECT_AD)
						.format(new String[] { schmaName });
				dbAccess.prepareStatement(sql);
				dbAccess.setString(1, adId);
				dbAccess.setInt(2, adSourceNo);
				rs = dbAccess.executeQuery();
				if (dbAccess.next(rs)) {
					Map map = new HashMap();
					map.put("imgPathPrefix", imgPathPrefix);
					map.put("spaceId", spaceId);
					map.put("spaceWidth", new Integer(spaceWidth));
					map.put("spaceHeight", new Integer(spaceHeight));
					map.put("adWindowId", new Integer(adWindowId));
					map.put("adId", ValueUtil.nullToStr(rs.getString("ad_id")));
					map.put("adType", new Integer(rs.getInt("ad_type")));
					map.put("width", new Integer(rs.getInt("width")));
					map.put("height", new Integer(rs.getInt("height")));
					map.put("image1", ValueUtil.nullToStr(rs
							.getString("image1")));
					map.put("altText1", ValueUtil.nullToStr(rs
							.getString("alt_text1")));
					map.put("linkUrl1", ValueUtil.nullToStr(rs
							.getString("link_url1")));
					map.put("fixedHtml", ValueUtil.nullToStr(rs
							.getString("fixed_html")));
					return map;
				} else {
					return null;
				}
			} finally {
				DBAccess.close(rs);
			}

		} finally {
			DBAccess.close(dbAccess);
		}
	}

	/**
	 * インプレッション履歴を挿入する。
	 * 
	 * @param sessionId
	 * @param siteId
	 * @param adId
	 * @param adWindowId
	 * @param spaceId
	 * @throws SQLException
	 */
	public static void insertImpressionLog(String sessionId, int siteId,
			String adId, int adWindowId, String spaceId) throws SQLException {

		// スキーマ名の取得
		String schmaName = SystemPropertiesDb.getInstance().get(
				SCHEMA_NAME_PROP_KEY);

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = DBAccessUtil.getLogDB();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// 会員マスタを作成する。
			int i = 0;
			String sql = new MessageFormat(INSERT_IMPRESSION_LOG)
					.format(new String[] { schmaName });
			dbAccess.prepareStatement(sql);
			dbAccess.setString(++i, sessionId);
			dbAccess.setInt(++i, siteId);
			dbAccess.setString(++i, adId);
			dbAccess.setInt(++i, adWindowId);
			dbAccess.setString(++i, spaceId);
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * クリック履歴を挿入する。
	 * 
	 * @param sessionId
	 * @param siteId
	 * @param adId
	 * @param adWindowId
	 * @param spaceId
	 * @param userAgent
	 * @param ip
	 * @param referer
	 * @throws SQLException
	 */
	public static void insertClickLog(String sessionId, int siteId,
			String adId, String adWindowId, String spaceId, String userAgent,
			String ip, String referer) throws SQLException {

		// スキーマ名の取得
		String schmaName = SystemPropertiesDb.getInstance().get(
				SCHEMA_NAME_PROP_KEY);

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = DBAccessUtil.getLogDB();

			// トランザクションを開始する。
			dbAccess.setAutoCommit(false);

			// 会員マスタを作成する。
			int i = 0;
			String sql = new MessageFormat(INSERT_CLICK_LOG)
					.format(new String[] { schmaName });
			dbAccess.prepareStatement(sql);
			dbAccess.setString(++i, sessionId);
			dbAccess.setInt(++i, siteId);
			dbAccess.setString(++i, adId);
			dbAccess.setString(++i, adWindowId);
			dbAccess.setString(++i, spaceId);
			dbAccess.setString(++i, userAgent.substring(0, Math.min(userAgent
					.length(), 300)));
			dbAccess.setString(++i, ip);
			dbAccess.setString(++i, referer.substring(0, Math.min(referer
					.length(), 1000)));
			dbAccess.executeUpdate();

			// コミットする。
			dbAccess.commit();

		} catch (SQLException e) {
			// ロールバックする。
			dbAccess.rollback();
			throw e;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/** AD_MSTから広告の下に表示するコメントを取得するためのSQL */
  private static final String SELECT_AD_SUB_TEXT = ""
    + "SELECT ad_sub_text FROM {0}.ad_mst WHERE ad_id LIKE ?";
  
  /**
   * AD_MSTから広告の下に表示するコメントを取得する
   * 
   * @param adId
   * @return
   * @throws SQLException
   */
  public static String getAdSubText(String adId) throws SQLException {
    //スキーマ名の取得
    String schmaName = SystemPropertiesDb.getInstance().get(SCHEMA_NAME_PROP_KEY);

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      dbAccess = new DBAccess();

      // AD_MSTから広告の下に表示するコメントを取得する
      String sql = new MessageFormat(SELECT_AD_SUB_TEXT).format(new String[] { schmaName });

      dbAccess.prepareStatement(sql);
      dbAccess.setString(1, adId);
      
      rs = dbAccess.executeQuery();
      if (dbAccess.next(rs)) {
        return (rs.getString("ad_sub_text") == null) ? "" : rs.getString("ad_sub_text");
      } else {
        return ""; //コメントを取得出来なかった
      }
    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
}
