package jp.co.webcrew.login.common.db.util;

import java.util.HashMap;

public class DBMap extends HashMap {


	/**
	 * 
	 */
	private static final long serialVersionUID = 4264308564475218596L;

	// Stringの小文字大文字を区別しない。全て大文字で格納する
	public Object put(Object key, Object value){
		if(value != null && key instanceof String){
			key = ((String)key).toUpperCase();
		}
		return super.put(key,value);
	}
	
	// Stringの小文字大文字を区別しない。全て大文字で取得する
	public Object get(Object key){
		if(key instanceof String){
			key = ((String)key).toUpperCase();
		}		
		return super.get(key);
	}

}