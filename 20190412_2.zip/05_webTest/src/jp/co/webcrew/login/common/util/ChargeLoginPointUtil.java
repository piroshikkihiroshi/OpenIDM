package jp.co.webcrew.login.common.util;

import java.sql.ResultSet;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.point.PointUtilRenewal;

public class ChargeLoginPointUtil
{
	private static final Logger log = Logger.getLogger(ChargeLoginPointUtil.class);
	
	private DBAccess objDbAccess = null;
	private SystemProperties objSystemProperties = null;
	private String strFirstLoginPointCharge = "";
	
	public static final int CHARGE_SUCCESS       = 1;
	public static final int CHARGE_FIRST_FAILURE = -1;
	
	/**
	 * コンストラクタ
	 * 
	 * @param objDbAccess
	 * @param objSystemProperties
	 */
	public ChargeLoginPointUtil(DBAccess objDbAccess) throws Exception
	{
		this.objDbAccess = objDbAccess;
		
		this.objSystemProperties = new SystemProperties(objDbAccess);
		this.strFirstLoginPointCharge = ValueUtil.nullToStr(objSystemProperties.get("FIRST_LOGIN_POINT_CHARGE"));
	}
	
	//初回ログインかどうかチェックするためのSQL
	private static final String SELECT_FIRST_LOGIN = ""
		+ "SELECT CASE WHEN first_point_datetime IS NULL THEN 1 ELSE 0 END AS first FROM tonashiba.member_mst WHERE guid = ?";
	
	/**
	 * 初回ログインかどうかチェックする。
	 * 初回ボーナスポイントは、初回ログインのみ付与する。
	 * 過去に登録済みのユーザも対象。
	 * 
	 * @param objRequest
	 * @return
	 */
	public boolean checkFirstLogin(String strGuid)
	{
		ResultSet objResultSet = null;
		
		try
		{
			objDbAccess.prepareStatement(SELECT_FIRST_LOGIN);
			objDbAccess.setInt(1, Integer.parseInt(strGuid));
			
			objResultSet = objDbAccess.executeQuery();
			if (objDbAccess.next(objResultSet))
			{
				if (objResultSet.getInt("first") == 1)
				{
					return true; //初ログイン
				}
				else
				{
					return false; //初ログインじゃなし
				}
			}
			else
			{
				return false; //結果が取れない
			}
		}
		catch(Exception e)
		{
			log.error("初回ログインチェック処理で例外が発生しました。", e);
			return false;
		}
		finally
		{
			DBAccess.close(objResultSet);
		}
	}
	
	//初回ログインポーナスポイントを付与した日付を更新するためのSQL
	private static final String UPDATE_FIRST_POINT = ""
		+ "UPDATE tonashiba.member_mst SET first_point_datetime = TO_CHAR(sysdate, 'YYYYMMDDHH24MISS') WHERE guid = ?";
	
	/**
	 * 初回ログインボーナスポイント付与処理を行う
	 * 
	 * @param objRequest
	 * @return
	 */
	public int chargeFirstLoginPoint(String strGuid)
	{
		try
		{
			String strFirstLoginPoint = ValueUtil.nullToStr(objSystemProperties.get("FIRST_LOGIN_POINT"));
			
			// ポイント加算履歴に挿入する。
			PointUtilRenewal.chargeWithoutTxControl(objDbAccess, strGuid, Long.valueOf(strFirstLoginPoint).longValue(), 
					PointUtilRenewal.CHARGE_TYPE_BONUS, -1, -1, null, 
					PointUtilRenewal.CHARGE_REASON_BONUS, null, false, true, false);
			
			objDbAccess.prepareStatement(UPDATE_FIRST_POINT);
			objDbAccess.setInt(1, Integer.parseInt(strGuid));
			objDbAccess.executeUpdate();
			
			return CHARGE_SUCCESS;
		}
		catch(Exception e)
		{
			log.error("初回ログインボーナスポイント付与処理で例外が発生しました。", e);
			return CHARGE_FIRST_FAILURE;
		}
	}
	
	/**
	 * 初回ログインボーナスポイントの付与設定を取得する
	 * 
	 * @return
	 */
	public String getFirstLoginPointCharge()
	{
		return this.strFirstLoginPointCharge;
	}
	
	/**
	 * ログイン付与処理済みチェック
	 * 
	 * @param strGuid
	 */
	public static void checkFirstLoginPoint(String strGuid){

		DBAccess objDbAccess = null;
		int nResultFirst = 0;
		
		try
		{
			
			objDbAccess = new DBAccess();
			objDbAccess.setAutoCommit(false);
			
			ChargeLoginPointUtil objChargeLoginPoint = new ChargeLoginPointUtil(objDbAccess);
			
			//初回ログインボーナスポイント付与処理
			if (objChargeLoginPoint.getFirstLoginPointCharge().equals("true"))
			{
				if (objChargeLoginPoint.checkFirstLogin(strGuid))
				{
					nResultFirst = objChargeLoginPoint.chargeFirstLoginPoint(strGuid);
				}
			}
			
			if (nResultFirst == ChargeLoginPointUtil.CHARGE_FIRST_FAILURE)
			{
				//ポイント付与処理で例外が発生
				log.error("例外が発生したためポイントを付与出来ませんでした。GUID=" + strGuid);
				return;
			}
			else
			{
				//ポイント付与が正常に完了したのでコミットする
				objDbAccess.commit();
			}
		}
		catch(Exception e)
		{
			log.error("ポイント付与処理で例外が発生しました。", e);
		}
		finally
		{
			DBAccess.close(objDbAccess);
		}
	}
}


