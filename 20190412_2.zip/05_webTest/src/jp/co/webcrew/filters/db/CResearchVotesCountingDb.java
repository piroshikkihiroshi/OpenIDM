package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * クリックリサーチの投票数を管理するためのdbクラス。
 * 
 * @author 
 */
public class CResearchVotesCountingDb {
  
  /** ランキングデータを取得する */
  private static final String SELECT_VOTES_RANKING = ""
    + "SELECT enquete_id, count FROM cresearch_ranking_info ORDER BY count DESC, enquete_id";
  
  /**
   * ランキングデータ(過去1ヶ月間の各アンケートの投票件数)を取得する
   * 
   * @return
   * @throws SQLException
   */
  public static Map getCResearchRankingInfo() throws SQLException {
    
    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      Map voteStatusCountingMap = new HashMap();
      
      dbAccess = new DBAccess();

      rs = dbAccess.executeQuery(SELECT_VOTES_RANKING);
      
      while(dbAccess.next(rs)) {
        voteStatusCountingMap.put(rs.getString("enquete_id"), rs.getString("count"));
      }
      
      return voteStatusCountingMap;

    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
  
  /** 投票件数(全期間)を取得するためのSQL */
  private static final String SELECT_VOTE_COUNTING_SUM = ""
    + "SELECT enq_code, sum(count) AS count FROM vote_counting_info GROUP BY enq_code ORDER BY enq_code";
  
  /**
   * 各アンケートの投票数をマップで取得する。
   * キー=アンケートID、値=投票数
   * 
   * @return
   * @throws SQLException
   */
  public static Map getVoteCountingSum() throws SQLException {

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      Map voteCountingMap = new HashMap();
      
      dbAccess = new DBAccess();

      rs = dbAccess.executeQuery(SELECT_VOTE_COUNTING_SUM);
      while(dbAccess.next(rs)) {
        voteCountingMap.put(rs.getString("enq_code"), rs.getString("count"));
      }
      
      return voteCountingMap;

    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
  
  /** 投票件数(全期間)を取得するためのSQL */
  private static final String SELECT_VOTE_COUNTING_SUM_BY_ENQUETE_NO = ""
    + "SELECT enq_code, sum(count) AS count FROM vote_counting_info WHERE enq_code = ? GROUP BY enq_code";
  
  /**
   * 各アンケートの投票数をマップで取得する。
   * キー=アンケートID、値=投票数
   * 
   * @return
   * @throws SQLException
   */
  public static Map getVoteCountingSumByEnqueteNo(int enqueteNo) throws SQLException {

    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      Map voteCountingMap = new HashMap();
      
      dbAccess = new DBAccess();
      dbAccess.prepareStatement(SELECT_VOTE_COUNTING_SUM_BY_ENQUETE_NO);
      dbAccess.setInt(1, enqueteNo);
      
      rs = dbAccess.executeQuery();
      if(dbAccess.next(rs) == true) {
        voteCountingMap.put(rs.getString("enq_code"), rs.getString("count"));
      }
      
      return voteCountingMap;

    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
  
  /** 投票結果(アンケート項目毎)を取得するためのSQL */
  private static final String SELECT_VOTE_COUNTING_BY_ENQUETE_NO = ""
    + "SELECT enq_code, opt_code, count, last_update FROM vote_counting_info WHERE  enq_code = ? ORDER BY count desc, opt_code asc";
  
  /**
   * 投票結果(アンケート項目毎)を取得する
   * 
   * @param enqueteNo
   * @return
   * @throws SQLException
   */
  public static Map getVoteCountingByEnqueteNo(String enqueteNo) throws SQLException {
    
    DBAccess dbAccess = null;
    ResultSet rs = null;
    try {
      Map voteCountingMap = new LinkedHashMap();
      
      dbAccess = new DBAccess();
      dbAccess.prepareStatement(SELECT_VOTE_COUNTING_BY_ENQUETE_NO);
      dbAccess.setString(1, enqueteNo);
      
      rs = dbAccess.executeQuery();
      while(dbAccess.next(rs)) {
        voteCountingMap.put(rs.getString("opt_code"), rs.getString("count"));
      }
      
      return voteCountingMap;

    } finally {
      DBAccess.close(rs);
      DBAccess.close(dbAccess);
    }
  }
}
