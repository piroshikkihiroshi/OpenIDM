package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * ポイント発生条件を管理するdbクラス。
 * 
 * @author kurinami
 */
public class PointMstDb extends RefreshMstDb {

	/** ポイント発生条件一覧取得用SQL */
	private static final String POINT_MST_SELECT = "select * from point_mst where to_char(sysdate, 'YYYYMMDDHH24MISS') between bgn_datetime and end_datetime";

	/** ユーザタイプ限定指定 ： 誰でもOK */
	public static final String USER_TYPE_ALL = "0";

	/** ユーザタイプ限定指定 ： 新規登録ユーザのみ */
	public static final String USER_TYPE_NEW = "1";

	/** ユーザタイプ限定指定 ： 既登録ユーザのみ */
	public static final String USER_TYPE_REGISTED = "2";

	/** 唯一のインスタンス */
	private static PointMstDb pointMstDb = new PointMstDb();

	/** ポイント発生条件の一覧 */
	private List pointMstList = null;

	/**
	 * 生成不能コンストラクタ
	 */
	private PointMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static PointMstDb getInstance() {
		return pointMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			List pointMstList = new ArrayList();

			// ポイント発生条件一覧を検索する。
			rs = dbAccess.executeQuery(POINT_MST_SELECT);
			while (dbAccess.next(rs)) {
				Map element = new HashMap();
				element.put("point_id", new Integer(rs.getInt("point_id")));
				element.put("point_name", ValueUtil.nullToStr(rs
						.getString("point_name")));
				element.put("conversion_base_url", ValueUtil.nullToStr(rs
						.getString("conversion_base_url")));
				element.put("conversion_goal_url", ValueUtil.nullToStr(rs
						.getString("conversion_goal_url")));
				element.put("user_type", ValueUtil.nullToStr(rs
						.getString("user_type")));
				element.put("repeat_flag", new Boolean(ValueUtil.nullToStr(
						rs.getString("repeat_flag")).equals("1")));
				element.put("same_day_flag", new Boolean(ValueUtil.nullToStr(
						rs.getString("same_day_flag")).equals("1")));
				element.put("direct_point", new Integer(rs
						.getInt("direct_point")));
				element.put("intro_point",
						new Integer(rs.getInt("intro_point")));

				pointMstList.add(element);
			}

			this.pointMstList = pointMstList;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * ポイント発生条件の一覧を返す。
	 * 
	 * @return
	 */
	public List getPointMstList() {
		return pointMstList;
	}

}
