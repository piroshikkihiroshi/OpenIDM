package jp.co.webcrew.login.common.db;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.Record;

/**
 * CONTRACT_POINT_MSTテーブルを扱うクラス
 * 
 * @author Fu
 * 
 */
public class ContractPointMst extends DBEntity {
    /** ロガー */
    private static final Logger log = Logger.getLogger(ContractPointMst.class);

    /** テーブル名 */
    public static final String TABLE = "CONTRACT_POINT_MST";

    /** フラグ有効 */
    public static final String FLG_INVALID_ON = "1";
    /** フラグ無効 */
    public static final String FLG_INVALID_OFF = "0";

    /*
     * 列名定義
     */
    /** ステップサイトID */
    public static final String SITE_ID = "SITE_ID";
    /** 成約サイトID */
    public static final String CONTRACT_SITE_ID = "CONTRACT_SITE_ID";
    public static final String CONTRACT_POINT_NO = "CONTRACT_POINT_NO";
    public static final String POINT = "POINT";
    public static final String DESCRIPTION = "DESCRIPTION";
    public static final String INVALID_FLAG = "INVALID_FLAG";

    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
     */
    public void init() {
        setTable(TABLE);
    }

    /** 不可視 */
    private ContractPointMst() {
        super();
    }

    /**
     * コンストラクタ
     * 
     * @param siteId
     */
    public ContractPointMst(String siteId) {
        super();
        set(SITE_ID, siteId);
    }

    public void setContractSiteId(String val) {
        set(CONTRACT_SITE_ID, val);
    }

    public final String getContractSiteId() {
        return get(CONTRACT_SITE_ID);
    }

    /**
     * <pre>
     * 
     * CONTRACT_POINT_MSTテーブルの一行データを取得する。
     * 
     * CONTRACT_POINT_MSTを返す。
     * 
     * null : エラー
     * null : 処理中止（引数がNULLの場合など）
     * ContractPointMst : 成功
     * 
     * </pre>
     * 
     * @param db
     * @param pointNo
     * @return boo
     */
    public boolean load(DBAccess db, String pointNo) {

        // パラメータチェック
        if (db == null || pointNo == null) {
            return false;
        }
        if (pointNo.length() == 0) {
            return false;
        }

        try {
            // サイトIDより成約サイトIDを取得する
            SiteMst siteMst = new SiteMst(get(SITE_ID));
            if (siteMst.load(db)) {
                setContractSiteId(siteMst.get(SiteMst.CONTRACT_SITE_ID));
            }
            String contractSiteId = getContractSiteId();
            if (ValueUtil.nullToStr(contractSiteId).length() == 0) {
                return false;
            }

            // 検索SQL文を作成する
            StringBuffer sqlBuf = new StringBuffer();
            sqlBuf.append("SELECT ").append(TABLE).append(".* FROM ").append(TABLE);
            sqlBuf.append(" WHERE ").append(CONTRACT_SITE_ID).append(" = '").append(contractSiteId).append("'");
            sqlBuf.append(" AND ").append(CONTRACT_POINT_NO).append(" = '").append(pointNo).append("'");

            // PreparedStatementを作成する
            db.prepareStatement(sqlBuf.toString());

            // 最初のレコードを取得する
            Record rec = Record.getFirstRowOf(db);
            if (rec == null) {
                log.info(TABLE + "の情報を読み込めませんでした。");
                return false;
            } else {
                setRecord(rec);
                // 無効の場合設定しない
                if (isInvalid()) {
                    setRecord(null);
                    return false;
                }
                return true;
            }

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function ContractPointMst#load", e);
            return false;
        }

    }

    /**
     * <pre>
     * 該当サイトIDが成約対応CONTRACT_POINT_MSTテーブルに存在するか否かを返す
     * false サイト有効する true サイト有効しないまたは存在しない
     * </pre>
     * 
     * @return
     * @throws SQLException
     */
    public boolean isInvalid() {
        String invalidFlag = get(INVALID_FLAG);
        if (FLG_INVALID_OFF.equals(invalidFlag)) {
            return false;
        }
        return true;

    }

}
