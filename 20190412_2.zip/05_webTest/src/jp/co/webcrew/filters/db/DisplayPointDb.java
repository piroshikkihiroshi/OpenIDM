package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;

/**
 * 現在のポイント所持数、今月の取得ポイント数、順位、人数を管理するためのdbクラス。
 *
 * @author
 */
public class DisplayPointDb
{
	/** ロガー */
	private static final Logger log = Logger.getLogger(DisplayPointDb.class);
	
	//唯一のインスタンス
	private static DisplayPointDb objInstance = new DisplayPointDb();
	
	//人数
	private long lngTotalCount = 0;
	
	//次回更新年月日
	private String strNextRefreshDate = "";
	
	public static final String KEY_POINT   = "POINT";
	public static final String KEY_RANKING = "RANKING";
	
	/**
	 * コンストラクタ
	 */
	private DisplayPointDb()
	{
		try
		{
			createTotalCount();
		}
		catch(Exception e)
		{
			lngTotalCount = 0;
			
			log.error("ポイント情報取得処理でエラーが発生しました。", e);
		}
	}
	
	/**
	 * インスタンスを取得する
	 * 
	 * @return
	 */
	public static DisplayPointDb getInstance()
	{
		return objInstance;
	}
	
	/**
	 * データを再読み込みする
	 */
	public void refresh()
	{
		try
		{
			createTotalCount();
		}
		catch(Exception e)
		{
			lngTotalCount = 0;
			
			log.error("ポイント情報取得処理でエラーが発生しました。", e);
		}
	}
	
	/** 取得した全ポイント数を取得するためのSQL */
	private static final String SELECT_CHARGE_TOTAL= "SELECT NVL(SUM(point), 0) AS charge_total FROM tonashiba.point_charge_hist WHERE guid = ?";

	/**
	 * 取得した全ポイント数を取得する
	 *
	 * @return 取得した全ポイント数
	 * @throws SQLException
	 */
	public static long getChargeTotal(String strGuid) throws Exception
	{
		DBAccess objDbAccess = null;
		ResultSet objResultSet = null;
		try
		{
			objDbAccess = new DBAccess();

			objDbAccess.prepareStatement(SELECT_CHARGE_TOTAL);
			objDbAccess.setLong(1, Long.parseLong(strGuid));

			objResultSet = objDbAccess.executeQuery();

			long lngChargeTotal = 0;

			if (objResultSet.next())
			{
				lngChargeTotal = objResultSet.getLong("charge_total");
			}

			return lngChargeTotal;

		}
		finally
		{
			DBAccess.close(objResultSet);
			DBAccess.close(objDbAccess);
		}
	}

	/** 利用したポイント数を取得するためのSQL */
	private static final String SELECT_SPEND_TOTAL = "SELECT NVL(SUM(point), 0) AS spend_total FROM tonashiba.point_spend_hist WHERE guid = ?";

	/**
	 * 利用したポイント数を取得する
	 *
	 * @param nGuid
	 * @return 利用したポイント数
	 * @throws Exception
	 */
	public static long getSpendTotal(String strGuid) throws Exception
	{
		DBAccess objDbAccess = null;
		ResultSet objResultSet = null;
		try
		{
			objDbAccess = new DBAccess();

			objDbAccess.prepareStatement(SELECT_SPEND_TOTAL);
			objDbAccess.setLong(1, Long.parseLong(strGuid));

			objResultSet = objDbAccess.executeQuery();

			long lngChargeTotal = 0;

			if (objResultSet.next())
			{
				lngChargeTotal = objResultSet.getLong("spend_total");
			}

			return lngChargeTotal;
		}
		finally
		{
			DBAccess.close(objResultSet);
			DBAccess.close(objDbAccess);
		}
	}

	/** 今月の取得ポイント数、順位を取得するためのSQL */
	private static final String SELECT_CURRENT_MONTH_POINT = "SELECT guid, point, ranking FROM tonashiba.current_month_point_hist WHERE guid = ?";

	/**
	 * 今月の取得ポイント数、順位を取得する
	 *
	 * @param nGuid
	 * @return
	 * @throws Exception
	 */
	public static Map getCurrentMonthPoint(String strGuid) throws Exception
	{
		DBAccess objDbAccess = null;
		ResultSet objResultSet = null;
		try
		{
			objDbAccess = new DBAccess();

			objDbAccess.prepareStatement(SELECT_CURRENT_MONTH_POINT);
			objDbAccess.setLong(1, Long.parseLong(strGuid));

			objResultSet = objDbAccess.executeQuery();

			Map mapCurrentMonthPoint = new HashMap();

			if (objResultSet.next())
			{
				mapCurrentMonthPoint.put(KEY_POINT,   String.valueOf(objResultSet.getLong("point")));
				mapCurrentMonthPoint.put(KEY_RANKING, String.valueOf(objResultSet.getLong("ranking")));
			}

			return mapCurrentMonthPoint;
		}
		finally
		{
			DBAccess.close(objResultSet);
			DBAccess.close(objDbAccess);
		}
	}

	/** 人数を取得する */
	private static final String SELECT_TOTAL_COUNT = "SELECT count(1) AS total_count FROM tonashiba.current_month_point_hist";

	/**
	 * 人数を取得する
	 *
	 * @return
	 * @throws Exception
	 */
	private void createTotalCount() throws Exception
	{
		DBAccess objDbAccess = null;
		ResultSet objResultSet = null;
		try
		{
			objDbAccess = new DBAccess();

			objResultSet = objDbAccess.executeQuery(SELECT_TOTAL_COUNT);

			if (objResultSet.next())
			{
				lngTotalCount = objResultSet.getLong("total_count");
			}
		}
		finally
		{
			DBAccess.close(objResultSet);
			DBAccess.close(objDbAccess);
		}
	}
	
	/**
	 * 人数を取得する
	 * 
	 * @return lngTotalCount
	 */
	public long getTotalCount() throws Exception
	{
		return lngTotalCount;
	}
	
	/**
	 * 次回の再読み込み時間を設定する
	 * 
	 * @param strNextRefreshDate
	 */
	public void setNextRefreshTime(String strNextRefreshDate)
	{
		this.strNextRefreshDate = strNextRefreshDate;
	}
	
	/**
	 * 次回の再読み込み時間を取得する
	 * 
	 * @return
	 */
	public String getNextRefreshTime()
	{
		return strNextRefreshDate;
	}
}
