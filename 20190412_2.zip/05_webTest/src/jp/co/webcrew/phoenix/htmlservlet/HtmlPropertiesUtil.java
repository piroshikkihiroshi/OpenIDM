package jp.co.webcrew.phoenix.htmlservlet;

import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * プロパティファイルを管理するためのutilクラス。
 * 
 * @author kurinami
 */
public class HtmlPropertiesUtil {

    /** 内部保持しているプロパティ群 */
    private static Map propertiesHolder = new HashMap();

    /** プロパティ値を保持する */
    private Properties props = new Properties();

    public HtmlPropertiesUtil(String filename) {
        load(filename);
    }

    /**
     * プロパティ値を読み込む。
     * 
     * @throws IOException
     */
    private void load(String filename) {
        InputStream is = null;
        try {
            is = this.getClass().getClassLoader().getResourceAsStream(filename);
            props.clear();
            props.load(is);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e1) {
                }
            }
        }
    }

    /**
     * プロパティ値を返す。
     * 
     * @param key
     * @return
     */
    public String getProperty(String key) {
        return props.getProperty(key);
    }
    
    /**
     * プロパティの配列値を返す。
     * 
     * @param key
     * @return
     */
    public String[] getPropertyArray(String key) {
        String value = getProperty(key);
        return value != null ? value.split(",") : new String[0];
    }

    /**
     * 配列型のプロパティ値の指定indexの値を返す。
     * 
     * @param key
     * @param index
     * @return
     */
    public String getProperty(String key, int index) {
        String[] array = getPropertyArray(key);
        if(index >= 0 && index < array.length) {
            return array[index];
        } else {
            return "";
        }
    }

    /**
     * プロパティ値にパラメータを当てて返す。
     * 
     * @param key
     * @param params
     * @return
     */
    public String getProperty(String key, Object[] params) {
        String property = getProperty(key);
        MessageFormat mf = new MessageFormat(property);
        return mf.format(params);
    }

    /**
     * 指定されたファイルのPropertiesUtilを返す。
     * 
     * @param filename
     * @return
     */
    public static HtmlPropertiesUtil getPropertiesUtil(String filename) {
        HtmlPropertiesUtil propertiesUtil = (HtmlPropertiesUtil) propertiesHolder
                .get(filename);

        if (propertiesUtil == null) {
            propertiesUtil = new HtmlPropertiesUtil(filename);
            propertiesHolder.put(filename, propertiesUtil);
        }

        return propertiesUtil;
    }
}