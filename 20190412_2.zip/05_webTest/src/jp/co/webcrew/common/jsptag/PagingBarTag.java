/*
 * Webcrew runtime framework tools
 *
 * Copyright (c) 2004 Webcrew
 * All rights reserved
 */
package jp.co.webcrew.common.jsptag;

import generator.runtime.exception.ApplicationException;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.el.ELException;
import javax.servlet.jsp.el.ExpressionEvaluator;
import javax.servlet.jsp.el.VariableResolver;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;


/**
 * Used to make nice simple paging bar html for showing paged table lists.
 * Works well with the SearchEntityListAction.
 *
 * @author <a href="mailto:rick_knowles@hotmail.com">Rick Knowles</a>
 * @version $Id: PagingBarTag.java,v 1.3 2005-02-13 08:01:43 rickk Exp $
 */
public class PagingBarTag extends BodyTagSupport {

    // tag attribute variables
    private int maxPages;
    private int selectedPage;
    private boolean showBookEnds = true;
    private boolean googleStyle = true;
    private int width = 5;
    private String leftBookendLabel = "<";
    private String rightBookendLabel = ">";

    // working variables
    private int currentIndex;
    private int startIndex;
    private int endIndex;
    private int leftBookend = -1;
    private int rightBookend = -1;

    // tag attribute getters
    public String getMaxPages() {
        return "" + this.maxPages;
    }

    public String getSelectedPage() {
        return "" + this.selectedPage;
    }

    public String getWidth() {
        return "" + this.width;
    }

    public String getShowBookEnds() {
        return "" + this.showBookEnds;
    }

    public String getGoogleStyle() {
        return "" + this.googleStyle;
    }

    public String getLeftBookendLabel() {
        return this.leftBookendLabel;
    }

    public String getRightBookendLabel() {
        return this.rightBookendLabel;
    }

    // tag attribute setters
    public void setMaxPages(String value) {
        if (value == null) {
            throw new ApplicationException(
                "Error setting tag attribute maxPages: value=" + value);
        } else {
            try {
                ExpressionEvaluator ee = pageContext.getExpressionEvaluator();
                VariableResolver vr = pageContext.getVariableResolver();
                String elValue = (String) ee.evaluate(value, String.class, vr,
                        null);
                this.maxPages = Integer.parseInt(elValue);
            } catch (ELException err) {
                throw new ApplicationException(
                    "Error setting tag attribute maxPages: value=" + value);
            }
        }
    }

    public void setSelectedPage(String value) {
        if (value == null) {
            throw new ApplicationException(
                "Error setting tag attribute selectedPage: value=" + value);
        } else {
            try {
                ExpressionEvaluator ee = pageContext.getExpressionEvaluator();
                VariableResolver vr = pageContext.getVariableResolver();
                String elValue = (String) ee.evaluate(value, String.class, vr,
                        null);
                this.selectedPage = Integer.parseInt(elValue);
            } catch (ELException err) {
                throw new ApplicationException(
                    "Error setting tag attribute selectedPage: value=" + value);
            }
        }
    }

    public void setWidth(String value) {
        this.width = Integer.parseInt(value);
    }

    public void setShowBookEnds(String value) {
        this.showBookEnds = new Boolean(value).booleanValue();
    }

    public void setGoogleStyle(String value) {
        this.googleStyle = new Boolean(value).booleanValue();
    }

    public void setLeftBookendLabel(String value) {
        this.leftBookendLabel = value;
    }

    public void setRightBookendLabel(String value) {
        this.rightBookendLabel = value;
    }

    public int doStartTag() {
        // Abort the tag if we determine there's only one page here
        if (this.maxPages == 1) {
            return SKIP_BODY;
        }

        // Determine the startIndex and endIndex
        // (add one on each end for bookends if needed)
        this.startIndex = Math.max(1,
                Math.min(this.maxPages,
                    this.selectedPage + (int) Math.floor(this.width / 2)) -
                (this.width - 1));
        this.endIndex = Math.min(this.maxPages,
                Math.max(1, this.selectedPage -
                    (int) Math.floor(this.width / 2)) + (this.width - 1));

        // In google style, left bookend is selected - 1, right is selected + 1
        if (this.googleStyle) {
            if (this.selectedPage != 1) {
                this.leftBookend = this.selectedPage - 1;
                this.startIndex--;
            } else {
                this.leftBookend = -1;
            }

            if (this.selectedPage != this.maxPages) {
                this.endIndex++;
                this.rightBookend = this.selectedPage + 1;
            } else {
                this.rightBookend = -1;
            }
        }
        // In non-google style, left bookend is startIndex - 1, right is endIndex + 1
        else {
            // Decide whether to show left bookend
            if (this.showBookEnds && (this.startIndex > 1)) {
                this.startIndex--;
                this.leftBookend = this.startIndex;
            } else {
                this.leftBookend = -1;
            }

            // Decide whether to show right bookend
            if (this.showBookEnds && (this.endIndex < this.maxPages)) {
                this.endIndex++;
                this.rightBookend = this.endIndex;
            } else {
                this.rightBookend = -1;
            }
        }

        // Initialise currentIndex to startIndex
        this.currentIndex = this.startIndex;
        addBodyFields();

        return EVAL_BODY_BUFFERED;
    }

    protected void addBodyFields() {
        //log.info("currentIndex=" + this.currentIndex);
        // Set the body variables for this iteration
        String label = this.currentIndex + "";
        int displayIndex = this.currentIndex;

        if ((this.leftBookend != -1) && (this.currentIndex == this.startIndex)) {
            label = this.leftBookendLabel;
            displayIndex = this.leftBookend;
        } else if ((this.rightBookend != -1) &&
                (this.currentIndex == this.endIndex)) {
            label = this.rightBookendLabel;
            displayIndex = this.rightBookend;
        }

        pageContext.setAttribute("paging_label", label);
        pageContext.setAttribute("paging_isSelected",
            new Boolean(this.currentIndex == this.selectedPage));
        pageContext.setAttribute("paging_index", new Integer(displayIndex));
    }

    public int doAfterBody() throws JspException {
        this.currentIndex++;

        try {
            BodyContent body = getBodyContent();
            JspWriter out = body.getEnclosingWriter();
            out.println(body.getString());
            body.clearBody(); // Clear for next evaluation
        } catch (IOException err) {
            throw new JspTagException("Error during paging tag", err);
        }

        if (this.currentIndex <= this.endIndex) {
            addBodyFields();

            return EVAL_BODY_BUFFERED;
        } else {
            return SKIP_BODY;
        }
    }

    public int doEndTag() throws JspException {
        this.width = 5;
        this.leftBookendLabel = "<";
        this.rightBookendLabel = ">";
        this.leftBookend = -1;
        this.rightBookend = -1;
        this.showBookEnds = true;
        this.googleStyle = true;

        return super.doEndTag();
    }
}
