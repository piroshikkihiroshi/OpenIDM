/**
 * 
 */
package jp.co.webcrew.login.common.util;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.login.common.db.MagSubscribe;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.AppUtil;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.MelmagaUtil;

/**
 * <pre>
 * 09.01.29時点で未使用
 * 将来的にSStagUpdateUtilから呼び出す可能性あり
 * 
 * 2010.08.09時点で変更
 * 今後使う場合MelmagaUtil.javaを使ってください
 * 
 * </pre>
 * @deprecated 
 * @author Takahashi
 */
public class StepMelmagaUtil {
	
	/** ロガー */
	private static final Logger log = Logger.getLogger(StepMelmagaUtil.class);	

	/**
	 * <pre>
	 * 該当サイトIDに関連づけられた複数のメールマガジンに対し、購読状況を
	 * 「未読」「購読」のどちらかに更新する
	 * </pre>
	 * 
	 * 処理に成功したらtrue
	 * 失敗したらfalse
	 * 
	 * @param db
	 * @param guid        guid null不可
	 * @param siteId      サイトID null不可
	 * @param stepMagFlg  stepのメルマガ購読状況 (0:未購読 1:購読 ） null可
	 * @param email       配信先のemail null可
	 
	public static boolean updateMelmagaFlg (DBAccess db , String guid , String siteId , String stepMagFlg , String email) {
		if (db == null) {
			log.error("引数エラー：データベースコネクションが渡されませんでした。");
			return false;
		}
		
		if (! AppUtil.isValidGuid(guid) ) {
			log.error("引数エラー：guidが無効です。");
			return false;
		}

		if (siteId == null || siteId.equals("") ) {
			log.error("引数エラー：siteIdが無効です。");
			return false;
		}
		
		if (stepMagFlg == null ) {
			// 何もしない。
			return false;
		}
		
		if (stepMagFlg.equals("0")) {
/// del 080425 step側でメルマガフラグがオフの場合、メルマガ管理テーブルは触らない --
// 			// 全てのメルマガを未読とする
//			List targetMagList = MelmagaUtil.getMelmagaList (db , siteId);
//			
//			if (targetMagList == null) {
//				return false;
//			}
//			
//			for ( Iterator it = targetMagList.iterator(); it.hasNext();) { 
//
//				String targetMagId = (String)it.next();
//
//				if (! MelmagaUtil.clearMelmagaFlg (db , guid , targetMagId) ) {
//					return false;
//				}
//				
//			}
//			return true;
/// del end --		

			return true;
			
		} else if (stepMagFlg.equals("1")) {
			// 全てのメルマガを購読とする
			List targetMagList = MelmagaUtil.getMelmagaList (db , siteId);

			if (targetMagList == null) {
				return false;
			}
			
			for ( Iterator it = targetMagList.iterator(); it.hasNext();) { 

				String targetMagId = (String)it.next();

				if (! checkMelmagaFlg (db , guid , targetMagId , email) ) {
					return false;
				}
				
			}

			return true;

		} else {
			// 何もしない。
			return true;
		}
		
	}
	*/

	
	/**
	 * <pre>
	 * 該当のメルマガを「購読済み」とする
	 * 
	 * stepからメルマガテーブルを更新する際は、メールアドレスを更新しない。
	 * そのため共通ユーティリティではなく独自メソッドを呼び出す。
	 * 
	 * </pre>
	 * @param db
	 * @param guid   guid
	 * @param mag_id メールマガジンID
	 * @param email  メールアドレス
	 * @return
	 
	private static boolean checkMelmagaFlg (DBAccess db , String guid , String mag_id , String email) {
		
		if (db == null) {
			log.error("引数エラー：データベースコネクションが渡されませんでした。");
			return false;
		}
		
		if (! AppUtil.isValidGuid(guid) ) {
			log.error("引数エラー：guidが無効です。");
			return false;
		}

		if (mag_id == null || mag_id.equals("") ) {
			log.error("引数エラー：mag_idが無効です。");
			return false;
		}
		
		if (email == null) {
			email = "";
		}
	
		try {
			// mag_subscribeからデータを検索
			db.prepareStatement("SELECT GUID FROM MAG_SUBSCRIBE WHERE GUID = ? AND MAG_ID = ?");
			db.setString(1, guid);
			db.setString(2, mag_id);
			Record rec = Record.getFirstRowOf(db);
			
			if (rec == null) {
				// レコードが存在しない場合はinsert
				DBUpdater updater = new DBUpdater(MagSubscribe.TABLE);
				updater.addString(MagSubscribe.MAIL_ID, mag_id);
				updater.addString(MagSubscribe.EMAIL, email);
				updater.addString(MagSubscribe.INVALID_FLAG , MagSubscribe.MAG_INVALID_FLAG_OFF);
				//updater.addString(MagSubscribe.GUID         , guid);
				//updater.addString(MagSubscribe.MAG_ID       , mag_id);
				//updater.addString(MagSubscribe.EMAIL        , email);
				//updater.addString(MagSubscribe.BGN_DATETIME , DateUtil.currentDateTime());

				updater.insert(db);

				return true;
				
			} else {
				// stepの場合、レコードが存在する場合は、何もしない。
				// メールアドレスは更新しない。
				return true;

			}
			
		} catch (Exception e) {
			log.error ("メールマガジン購読状況の変更中に、例外エラーが発生しました。" , e);
			return false;
		}		
		
	}
	*/

	/**
	 * 購読しているメールID取得する
	 * 
	 * @param objDBAccess
	 * @param lstMailId
	 * @param strEmail
	 * @return
	 
	public static Map getSubscribeMailId(DBAccess objDBAccess, List lstMailId, String strEmail)
	{
		Map mapSubscribeInfo = new HashMap();
		
		ResultSet objResultSet = null;
		
		try
		{
			String strWhere = "";
			for (int i = 0; i < lstMailId.size(); i++)
			{
				strWhere = strWhere + "?,";
			}
			
			if (!strWhere.equals(""))
			{
				strWhere = "AND " + strWhere.substring(0, strWhere.lastIndexOf(","));
			}
			
			StringBuffer sbSQL = new StringBuffer();
			sbSQL.append("SELECT").append(" ");
			sbSQL.append("mail_id, invalid_flag").append(" ");
			sbSQL.append("FROM").append(" ");
			sbSQL.append("mail_subscribe").append(" ");
			sbSQL.append("WHERE").append(" ");
			sbSQL.append("email = ?" + strWhere).append(" ");
			
			objDBAccess.prepareStatement(sbSQL.toString());
			objDBAccess.setString(1, strEmail);
			
			for (int i = 0; i < lstMailId.size(); i++)
			{
				objDBAccess.setInt(i + 2, Integer.parseInt((String)lstMailId.get(i)));
			}
			
			objResultSet = objDBAccess.executeQuery();
			
			while (objResultSet.next())
			{
				mapSubscribeInfo.put(objResultSet.getString("mail_id"), objResultSet.getString("invalid_flag"));
			}
			
			return mapSubscribeInfo;
		}
		catch (Exception e)
		{
			log.error("購読メールID取得処理で例外が発生しました。email=" + strEmail, e);
			return mapSubscribeInfo;
		}
		finally
		{
			DBAccess.close(objResultSet);
		}
	}*/
	
	
	/**
	 * メールマスタ、メールサイトマップから指定したサイトID、メール種別のメールIDを取得する
	 * 
	 * @param objDBAccess
	 * @param strSiteId
	 * @param nMailType
	 * @return
	 
	public static List getMailId(DBAccess objDBAccess, String strSiteId, List lstMailType)
	{
		List lstMailId = new ArrayList();
		
		ResultSet objResultSet = null;
		
		try
		{
			String strWhere = "";
			for (int i = 0; i < lstMailType.size(); i++)
			{
				strWhere = strWhere + "?,";
			}
			
			if (!strWhere.equals(""))
			{
				strWhere = "AND mail_type IN (" + strWhere.substring(0, strWhere.lastIndexOf(",")) + ")";
			}
			
			StringBuffer sbSQL = new StringBuffer();
			sbSQL.append("SELECT").append(" ");
			sbSQL.append("mst.mail_id").append(" ");
			sbSQL.append("FROM").append(" ");
			sbSQL.append("mail_mst mst").append(" ");
			sbSQL.append("INNER JOIN").append(" ");
			sbSQL.append("mail_site_map map").append(" ");
			sbSQL.append("ON").append(" ");
			sbSQL.append("mst.mail_id = map.mail_id").append(" ");
			sbSQL.append("WHERE").append(" ");
			sbSQL.append("site_id = ?").append(" ");
			sbSQL.append(strWhere).append(" ");
			sbSQL.append("AND map.invalid_flag = 1").append(" ");
			sbSQL.append("AND mst.invalid_flag = 1").append(" ");
			
			objDBAccess.prepareStatement(sbSQL.toString());
			objDBAccess.setString(1, strSiteId);
			
			for (int i = 0; i < lstMailType.size(); i++)
			{
				objDBAccess.setInt(i + 2, Integer.parseInt((String)lstMailType.get(i)));
			}
			
			objResultSet = objDBAccess.executeQuery();
			
			while (objResultSet.next())
			{
				lstMailId.add(objResultSet.getString("mail_id"));
			}
			
			return lstMailId;
		}
		catch (Exception e)
		{
			log.error("メールID取得処理で例外が発生しました。site_id=" + strSiteId, e);
			return lstMailId;
		}
		finally
		{
			DBAccess.close(objResultSet);
		}
	}
	*/
}
