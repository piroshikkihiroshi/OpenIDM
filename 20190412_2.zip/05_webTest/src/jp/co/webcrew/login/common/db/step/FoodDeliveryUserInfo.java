package jp.co.webcrew.login.common.db.step;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.db.util.Record;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;



public class FoodDeliveryUserInfo extends StepUserInfoCommonDb
{
	/** スキーマ名　*/
	public static final String SCHEMA = "LIFE_SERVICE";
	/** テーブル名　*/
	public static final String TABLE = "ORDER_INFO";
	/** ORDER_HIST.ORDER_TEXTに転送する文字列　*/
	public static final String ORDER_TEXT_CAPTION = "ズバット食材宅配比較";
	/** 法人向けサイトであるか否か   */
	public static final boolean CORPORATE_SERVICE_FLG = false;

	/** PCサイトＩＤ*/
	public static final String PC_SITE_ID = "12400";

	/*
	 * 列名定義
	 */
	public static final String ORDER_ID       = "ORDER_ID";
	public static final String USER_ID       = "USER_ID";
	public static final String STEP_SITE_ID  = "STEP_SITE_ID";
	public static final String NAME_KANJI_1  = "NAME_KANJI_1";
	public static final String NAME_KANJI_2  = "NAME_KANJI_2";
	public static final String NAME_KANA_1   = "NAME_KANA_1";
	public static final String NAME_KANA_2   = "NAME_KANA_2";
	public static final String TEL           = "TEL";
	public static final String EMAIL         = "EMAIL";

	public static final String FINISH_FLG    = "FINISH_FLG";
	public static final String LAST_UPDATE   = "LAST_UPDATE";
	public static final String GUID          = "GUID";
	
	public static final String ZIP           = "ZIP";
	public static final String ADDRESS_1     = "ADDRESS_1";
	public static final String ADDRESS_2     = "ADDRESS_2";
	public static final String ADDRESS_3     = "ADDRESS_3";
	public static final String ADDRESS_4     = "ADDRESS_4";
	public static final String ADDRESS_5     = "ADDRESS_5";
	public static final String PREF_ID       = "PREF_ID";
	public static final String MOBILE_FLG    = "MOBILE_FLG";
	
	public static final String MAG_FLAG    = "MAG_FLAG";

	/** ロガー */
	private Logger log = Logger.getLogger(this.getClass());

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.db.DBEntity#doInit()
	 */
	public void doInit()
	{
		setSchema(SCHEMA);
		setTable(TABLE);
		setCorporateService(CORPORATE_SERVICE_FLG);
	}
	
	/* (non-Javadoc)
	 * @see jp.co.webcrew.login.common.db.step.StepUserInfoCommonDb#doLoad(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String, java.lang.String)
	 */
	public boolean doLoad(DBAccess db, String orderId, String userId) throws SQLException 
	{
		this.set(ORDER_ID, orderId);

		this.set(USER_ID, userId);
		
		log.info("[doLoad]"+orderId+":"+userId+":getUserId:"+this.getUserId());
		
		return super.doLoad(db, orderId, userId);

		
	}
	
	private FoodDeliveryUserInfo(){}

	/**
	 * コンストラクタ
	 * @param request
	 * @param siteId
	 */
	public FoodDeliveryUserInfo(HttpServletRequest request , String siteId )
	{
		setSiteId(siteId);
		setHttpRequest(request);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doCreateNewStepId(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	public void doCreateNewStepId(DBAccess db) throws SQLException
	{
	}	

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfoCommonDb#doPrepareStepDatabase(jp.co.webcrew.dbaccess.db.DBAccess)
	 */
	protected void doPrepareStepDatabase(DBAccess db) throws SQLException
	{
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doIsDifferentFromMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public boolean doIsDifferentFromMemberMst(MemberMst memberMst)
	{
		if(get(NAME_KANJI_1).equals(memberMst.get(MemberMst.NAME1))) return true;
		if(get(NAME_KANJI_2).equals(memberMst.get(MemberMst.NAME2))) return true;
		if(get(NAME_KANA_1).equals(memberMst.get(MemberMst.FURI1))) return true;
		if(get(NAME_KANA_2).equals(memberMst.get(MemberMst.FURI2))) return true;
		if(get(ZIP).equals(memberMst.get(MemberMst.ZIP))) return true;
		if(get(PREF_ID).equals(memberMst.get(MemberMst.PREF_ID))) return true;
		if(get(ADDRESS_1).equals(memberMst.get(MemberMst.ADDR1))) return true;
		if(get(ADDRESS_2).equals(memberMst.get(MemberMst.ADDR2))) return true;
		if(get(ADDRESS_3).equals(memberMst.get(MemberMst.ADDR3))) return true;
		if(get(ADDRESS_4).equals(memberMst.get(MemberMst.ADDR4))) return true;
		if(get(ADDRESS_5).equals(memberMst.get(MemberMst.ADDR5))) return true;
		if(get(TEL).equals(memberMst.get(MemberMst.TEL))) return true;
		if(get(EMAIL).equals(memberMst.get(MemberMst.EMAIL))) return true;
			
		return false;
	}


	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateFromMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public void doPopulateFromMemberMst(MemberMst member)
	{
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToMemberMst(jp.co.webcrew.login.util.db.MemberMst)
	 */
	public void doPopulateToMemberMst(MemberMst member)
	{
		// メンバーオブジェクトを自動生成する時は、データを切り捨ててでも、なるべく生かす。
		// （文字数制限を自動的に行う）

		member.setTrimData(MemberMst.NAME1, get(NAME_KANJI_1));
		member.setTrimData(MemberMst.NAME2, get(NAME_KANJI_2));
		member.setTrimData(MemberMst.FURI1, get(NAME_KANA_1));
		member.setTrimData(MemberMst.FURI2, get(NAME_KANA_2));
		member.setTrimData(MemberMst.ZIP, get(ZIP));
		member.setTrimData(MemberMst.PREF_ID, get(PREF_ID));
		member.setTrimData(MemberMst.ADDR1, get(ADDRESS_1));
		member.setTrimData(MemberMst.ADDR2, get(ADDRESS_2));
		member.setTrimData(MemberMst.ADDR3, get(ADDRESS_3));
		member.setTrimData(MemberMst.ADDR4, get(ADDRESS_4));
		member.setTrimData(MemberMst.ADDR5, get(ADDRESS_5));

		if(this.getSiteId().equals(PC_SITE_ID))
		{
			member.setTrimData(MemberMst.TEL, get(TEL));
		}
		else
		{
			member.setTrimData(MemberMst.MOBILE, get(TEL));
		}
	}
	

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doPopulateToOrderHist(jp.co.webcrew.login.util.db.OrderHist)
	 */
	public void doPopulateToOrderHist(OrderHist order)
	{
		
		order.setTrimData(OrderHist.ORDER_DATETIME,DateUtil.currentDateTime()); //発注日
		
		order.setTrimData(OrderHist.ORDER_TYPE, OrderHist.TYPE_SHIRYO_SEIKYU);
		order.setTrimData(OrderHist.SITE_ID, getSiteId());
		order.setTrimData(OrderHist.ORDER_ID, getRequestId());
		order.setTrimData(OrderHist.ORDER_TEXT, ORDER_TEXT_CAPTION);
		
		//サプライヤテキストの登録
		String selectSQL = "SELECT \n"
		                   + " data.key_data AS name \n"
		                   + " FROM life_service.clm_data data \n"
		                   + " WHERE data.tbl_id = 'company_mst' \n"
		                   + " AND data.clm_id = 'company_name' \n"
		                   + " AND EXISTS \n"
		                   + " ( \n"
		                   + " SELECT 1 FROM life_service.clm_data data1 \n"
		                   + " WHERE data1.tbl_id = 'company_mst' \n"
		                   + " AND data1.clm_id = 'company_id' \n"
		                   + " AND data.rec_id = data1.rec_id \n"
		                   + " AND EXISTS \n"
		                   + " ( \n"
		                   + " SELECT 1 FROM life_service.order_company_inter oci \n"
		                   + " WHERE oci.order_id = ? AND oci.company_id = data1.key_data \n"
		                   + " ) \n"
		                   + " ) \n";
		DBAccess db = null;
		try {
			db = new DBAccess();
			db.prepareStatement(selectSQL);
			db.setString(1, getRequestId());
			db.executeQuery();
			List suppliers = Record.getResultListOf(db);
			StringBuffer supplier_text = new StringBuffer("");
			for (int i = 0 ; i < suppliers.size() ; i++) {
				Record supinfo = (Record)suppliers.get(i);
				if (i != 0) {
					supplier_text.append(",");
				}
				supplier_text.append(supinfo.getString("name"));
			}
			order.setTrimData(OrderHist.SUPPLIER_TEXT, supplier_text.toString()); 
		} catch (Exception e) {
			log.error("Stepデータを会員情報の履歴データに転送する際にデータベースエラーが発生しました。",e);
		} finally {
			DBAccess.close(db);
		}
		
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doDeleteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public void doDeleteGuid(DBAccess db , String guid) throws SQLException
	{
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#doOverWriteGuid(jp.co.webcrew.dbaccess.db.DBAccess, java.lang.String)
	 */
	public boolean doOverWriteGuid (DBAccess db , String guid)
	{
		// UserInfoとOrderInfoのguidを更新する
		
		String orderId = ValueUtil.nullToStr(getRequestId());
		
		log.info ("ステップのデータベースに対し、guidの上書き処理を開始します。");
		log.info("[updateGuidCommon]order_id/user_id/"+this.getRequestId()+"/"+this.getUserId());

	// 入力チェック
		
		// GUIDが不正ならエラー
		if (! SessionFilterAlterUtil.isValidGuid(guid)){
			log.error("GUIDが不正です。");
			return false;
		}

		// ORDER_IDが不正ならエラー
		if (orderId.equals("")) 
		{
			log.error("ORDER_IDが不正です。");
			return false;
		}

		//更新
		try 
		{
			// ORDER_INFOのGUIDを更新する
			String sql = "UPDATE " + getSchema() + ".ORDER_INFO SET GUID = ? ";
			sql += "WHERE ORDER_ID = ? ";
			db.prepareStatement(sql);
			db.setString(1, guid);
			db.setString(2, orderId);
			db.executeUpdate();

			log.info("GUIDの上書き処理が完了しました。");
			return true;
		
		} catch (Exception e) {

			log.error("guid上書き処理中に例外エラーが発生しました。" , e);
			return false;
		}		
	    
		//住宅ローンにはUserInfoが存在しないので、以下の標準ルーチンは呼び出せない
		//return super.updateGuidCommon(db, guid);
	}


	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getPrefId()
	 */
	public String getPrefId()
	{
		return "";
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setPrefId(java.lang.String)
	 */
	public void setPrefId(String val)
	{
		set (PREF_ID , val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getUserId()
	 */
	public String getUserId()
	{
		return "";
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setUserId(java.lang.String)
	 */
	public void setUserId(String val)
	{
		set(USER_ID , val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getEmail()
	 */
	public String getEmail()
	{
		return get(EMAIL);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getSexId()
	 */
	public String getSexId()
	{
		return "";
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDate()
	 */
	public String getBirthDate()
	{
		//return get(BIRTH_DATE);
	    return null;
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthYear()
	 */
	public String getBirthYear()
	{
		return "";
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthMonth()
	 */
	public String getBirthMonth() 
	{
		return "";
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getBirthDay()
	 */
	public String getBirthDay()
	{
		//return get(BIRTH_DATE);
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getZip()
	 */
	public String getZip()
	{
		return get(ZIP);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setZip(java.lang.String)
	 */
	public void setZip(String val)
	{
		set(ZIP,val);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setSexId(java.lang.String)
	 */
	public void setSexId(String val){
		//set(SEX_ID,val);
		
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#setBirthDate(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void setBirthDate(String year,String month,String day)
	{
		//set(BIRTH_DATE , year + "-" + month + "-" + day);
	}


	/*
	 * private method
	 */

	/**
	 * クライアントのIPアドレスを取得する
	 * @return String IPアドレス
	 */
	private String getRemoteAddr() 
	{
		return "";
	}

	/**
	 * 誕生日をYYYYMMDD形式の文字列で取得する
	 * @return String 誕生日 YYYYMMDD
	 */
	private String charBirthDate()
	{
		//return get(BIRTH_DATE);
	    return null;
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getLastUpdateTime()
	 */
	public String getLastUpdate() 
	{
		//TODO ここで返すべきは、システム上の更新日時？それとも申込日時？
		return get(LAST_UPDATE);
	}

	/*
	 * (non-Javadoc)
	 * @see jp.co.webcrew.login.util.db.step.StepUserInfo#getMagFlag()
	 */
	public String getMagFlag() 
	{
		return "";

	}

}
