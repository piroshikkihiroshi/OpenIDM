/**
 * 
 */
package jp.co.webcrew.login.common;

/**
 * 仮登録処理の結果を格納するクラス
 * 
 * @author Takahashi
 *
 */
public class TempRegistResult {
	
	/** 仮登録成功を意味する定数 */
	public static final int REGIST_SUCCESS          = 0;

	/** 引数にエラーがあることを意味する定数 */
	public static final int REGIST_INPUT_ERROR      = 1;

	/** 既に登録済みであることを意味する定数 */
	public static final int REGIST_DUPLICATE_ERROR  = 2;

	/** データベースエラーが発生したことを意味する定数 */
	public static final int REGIST_DB_ERROR         = 3;

	/** その他の例外エラーが発生したことを意味する定数 */
	public static final int REGIST_OTHER_ERROR      = 4;

	/** ステータスコード */
	public int status = -1;

	/** 仮登録GUID */
	public String temporaryGuid;

	/** 仮登録パスワード */
	public String temporaryPassword;


	/**
	 * 仮登録処理が成功したかどうかを返す
	 * 
	 * true 成功
	 * false 失敗
	 * 
	 * @return
	 */
	public boolean isSuccess() {
		if (this.status == REGIST_SUCCESS) {
			return true;
		} else {
			return false;
		}
	}
	

	/**
	 * 仮登録時、二重登録エラーが発生したか否か
	 * 
	 * true  発生
	 * false 未発生
	 */
	public boolean isDupulicateError () {
		if (this.status == REGIST_DUPLICATE_ERROR) {
			return true;
		} else {
			return false;
		}		
	}
}

