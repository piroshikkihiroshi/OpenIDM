package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * ログイン状態・会員登録状態で、表示htmlを制御するsstag
 * 
 */
public class DisplayControlExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(DisplayControlExecuter.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

		try {
      //ログイン状態パラメータが指定されているか確認
      String loginFlag = ValueUtil.nullToStr(parameters.get("login_flag"));
      if(loginFlag.equals("")) {
        log.error("ログイン状態(login_flag)が未設定です。設定を確認して下さい。");
        return "";
      }
      
      //会員登録状態パラメータが指定されているか確認
      String formalFlag = ValueUtil.nullToStr(parameters.get("formal_flag"));
      if(formalFlag.equals("")) {
        log.error("会員登録状態(formal_flag)が未設定です。設定を確認して下さい。");
        return "";
      }
      
      //ログイン済み時に表示するＨＴＭＬが指定されているか確認
      String loginStateHtml = (parameters.get("login_state_html") == null) ? null : (String)parameters.get("login_state_html");
      if(loginStateHtml == null) {
        log.error("ログイン済み時に表示するHTML(login_state_html)が未設定です。設定を確認して下さい。");
        return "";
      }
      
      //ソフトログイン時に表示するＨＴＭＬが指定されているか確認
      String softLoginHtml = (parameters.get("soft_login_html") == null) ? null : (String)parameters.get("soft_login_html");
      if(softLoginHtml == null) {
        log.error("ソフトログイン時に表示するHTML(soft_login_html)が未設定です。設定を確認して下さい。");
        return "";
      }
      
      //会員登録していない時に表示するＨＴＭＬが指定されているか確認
      String noStateHtml = (parameters.get("no_state_html") == null) ? null : (String)parameters.get("no_state_html");
      if(noStateHtml == null) {
        log.error("会員登録していない時に表示するHTML(no_state_html)が未設定です。設定を確認して下さい。");
        return "";
      }
      
      //ログイン状態に応じて表示するHTMLを変える
      if(loginFlag.equals("t")) {
        //ログイン済み
        return loginStateHtml;
      } else {
        if(formalFlag.equals("t")) {
          //ソフトログイン（未ログイン＆会員登録済み）
          return softLoginHtml;
        } else {
          //会員登録してない
          return noStateHtml;
        }
      }

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			return "";
		}
	}
}
