﻿Imports System.Text 'stringbuilder用
Imports CRMForm.DeclareCs
Imports CRMForm.commonFunc
Imports CRMForm.sqlMng

Public Class InitForm

    Private Sub InitForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Location = New Point(10, 10)
        'Me.Size = New Point(glDispWidth - 70, glDispHeight - 70)    'フォームのサイズ(ディスプレイサイズから計算)

    End Sub

    Private Sub SearchInitBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchInitBtn.Click
        'SearchFormクラスのインスタンスを作成する
        Dim objSearchMain As New SearchMainForm()
        'SearchFormを表示する
        'ここではモーダルダイアログボックスとして表示する
        'オーナーウィンドウにMeを指定する
        '20170328 モーダルからモードレスウィンドウへ変更
        'f.ShowDialog(Me)
        objSearchMain.Show(Me)
    End Sub

    Private Sub PasteInitBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteInitBtn.Click
        Dim objPasteFormMain As New PasteForm()
        'PasteFormを表示する
        objPasteFormMain.Show(Me)
    End Sub

    Private Sub ProcKillInitBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProcKillInitBtn.Click
        'プロセスキル処理
        Dim objFnc As New commonFunc()
        objFnc.ProcKillMain()

    End Sub
End Class