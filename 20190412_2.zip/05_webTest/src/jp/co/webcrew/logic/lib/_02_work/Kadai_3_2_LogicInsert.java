package jp.co.webcrew.logic.lib._02_work;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.phoenix.common.db.PhoenixDBAccess;
import jp.co.webcrew.phoenix.logic.BindLogicExtStatus;
import jp.co.webcrew.phoenix.logic.BindLogicStdStatus;
import jp.co.webcrew.phoenix.logic.ItemConvLogicStatus;
import jp.co.webcrew.phoenix.logic.JudgementLogicStatus;
import jp.co.webcrew.phoenix.logic.SstagDynamicLogic;
import jp.co.webcrew.phoenix.logic.bean.FormInfo;
import jp.co.webcrew.phoenix.logic.bean.FormUseInfo;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.logic.bean.SortRequest;
import jp.co.webcrew.phoenix.logic.bean.SstagGlobalInfo;
import net.arnx.jsonic.JSON;

public class Kadai_3_2_LogicInsert extends SstagDynamicLogic {

	Logger logger = Logger.getLogger(Kadai_3_2_LogicInsert.class);

	@Override
	public BindLogicStdStatus stdLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam, List<String> userParam,
			FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo) {

		//member変数
		int intSiteId = 91076;
		PhoenixDBAccess objDbAccess = null;
		ResultSet objRs = null;
		int intMax = 0;

//		logger.info("サイトInfo：" + JSON.encode(sgInfo));
		logger.info("postInfo：" + JSON.encode(postInfo));

		String[] arrKanzi = postInfo.postItemMap.get("name_kanji");
		String[] arrkana = postInfo.postItemMap.get("name_kana");
		String[] arrEmail = postInfo.postItemMap.get("email");
		String[] arrEmailConfirm = postInfo.postItemMap.get("email_confirm");
		String[] arrTel = postInfo.postItemMap.get("tel");
		String[] arrInquiryInfo = postInfo.postItemMap.get("inquiry_info");

		//採番用sql作成
		String strSelectSql = "select MAX(order_id) as MAX from \"TATSUYA.UEDA\".ORDER_INFO";

		//採番値取得

		try {
			objDbAccess = new PhoenixDBAccess(intSiteId);
			objDbAccess.setAutoCommit(false);
			objRs = objDbAccess.executeQuery(strSelectSql);

			while (objRs.next())
			{
				String strActNum =	objRs.getString("MAX");
				intMax = Integer.parseInt(strActNum);
				intMax++;
			} //while

		} catch (SQLException e) {
			logger.error("SQL Error", e);
			e.printStackTrace();
		} catch (Exception e) {
			objDbAccess.rollback();
			logger.error("Unexpect Error", e);
			e.printStackTrace();
		} finally {
			DBAccess.close(objRs);
			DBAccess.close(objDbAccess);
		} //try



		//insertsql作成
		String strInsSql = "";
		strInsSql += "INSERT ";
		strInsSql += "INTO \"TATSUYA.UEDA\".ORDER_INFO(";
		strInsSql += "  ORDER_ID";
		strInsSql += "  , NAME_KANJI_1";
		strInsSql += "  , NAME_KANJI_2";
		strInsSql += "  , NAME_KANA_1";
		strInsSql += "  , NAME_KANA_2";
		strInsSql += "  , EMAIL";
		strInsSql += "  , TEL";
		strInsSql += "  , CONTACT ";
		strInsSql += "  , DELETE_FLG ";
		strInsSql += ") ";
		strInsSql += "VALUES ( ";
		strInsSql += "  ?,";
		strInsSql += "  ?,";
		strInsSql += "  ?,";
		strInsSql += "  ?,";
		strInsSql += "  ?,";
		strInsSql += "  ?,";
		strInsSql += "  ?,";
		strInsSql += "  ?,";
		strInsSql += "  ?";
		strInsSql += ")";

		try {

			objDbAccess = new PhoenixDBAccess(intSiteId);
			objDbAccess.setAutoCommit(false); //一応明示的にオートコミット切る
			objDbAccess.prepareStatement(strInsSql);

			objDbAccess.setInt(1, intMax);
			objDbAccess.setString(2, arrKanzi[0]);
			objDbAccess.setString(3, arrKanzi[1]);
			objDbAccess.setString(4, arrkana[0]);
			objDbAccess.setString(5, arrkana[1]);
			objDbAccess.setString(6, arrEmail[0]);
			objDbAccess.setString(7, arrTel[0] + arrTel[1] + arrTel[2]); //denwa
			objDbAccess.setInt(8, Integer.parseInt(arrInquiryInfo[0]));
			objDbAccess.setInt(9, 0);

			int intCnt = objDbAccess.executeUpdate();
			objDbAccess.commit();
			logger.info("commit success");

		} catch (SQLException e) {
			logger.error("SQL Error", e);
			e.printStackTrace();
		} catch (Exception e) {
			objDbAccess.rollback();
			logger.error("Unexpect Error", e);
			e.printStackTrace();
		} finally {
			//DBAccess.close(rs);
			DBAccess.close(objDbAccess);

		} //try

		//statusは必須
		BindLogicExtStatus objStatus = new BindLogicExtStatus();

		return objStatus;

	} // stdLogic

	@Override
	public BindLogicExtStatus validationLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public JudgementLogicStatus judgementLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo,
			SortRequest[] sortReq, Map<String, String[]> vResult, Map<String, Map<String, Object[]>> sResult,
			Map<String, Object[]> auxResult, boolean doValidation, boolean doScreening) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public ItemConvLogicStatus itemConvLogic(SstagGlobalInfo sgInfo, Map<String, String> sstagParam,
			List<String> userParam, FormInfo formInfo, PostInfo postInfo, FormUseInfo formUseInfo, String sub1,
			String sub2, String result) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
