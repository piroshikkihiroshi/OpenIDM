package jp.co.webcrew.phoenix.sstag.bean;

public class PromoDisplayBean
{
	
	private String strPromoCode = "";
	private int nSiteID = 0;
	private String strDescription = "";
	private String strHTML1 = "";
	private String strHTML2 = "";
	private String strHTML3 = "";
	private String strHTML4 = "";
	private String strHTML5 = "";
	private String strHTML6 = "";
	private String strHTML7 = "";
	private String strHTML8 = "";
	private String strHTML9 = "";
	private String strHTML10 = "";
	private String strHTML11 = "";
	private String strHTML12 = "";
	private String strHTML13 = "";
	private String strHTML14 = "";
	private String strHTML15 = "";
	private String strHTML16 = "";
	private String strHTML17 = "";
	private String strHTML18 = "";
	private String strHTML19 = "";
	private String strHTML20 = "";
	
	private String strLastUpdate = "";
	private String strUpdateAdmin = "";
	
	public String getStrPromoCode()
	{
		return strPromoCode;
	}
	public void setStrPromoCode(String strPromoCode)
	{
		this.strPromoCode = strPromoCode;
	}
	public int getnSiteID()
	{
		return nSiteID;
	}
	public void setnSiteID(int nSiteID)
	{
		this.nSiteID = nSiteID;
	}
	public String getStrDescription()
	{
		return strDescription;
	}
	public void setStrDescription(String strDescription)
	{
		this.strDescription = strDescription;
	}
	public String getStrHTML1()
	{
		return strHTML1;
	}
	public void setStrHTML1(String strHTML1)
	{
		this.strHTML1 = strHTML1;
	}
	public String getStrHTML2()
	{
		return strHTML2;
	}
	public void setStrHTML2(String strHTML2)
	{
		this.strHTML2 = strHTML2;
	}
	public String getStrHTML3()
	{
		return strHTML3;
	}
	public void setStrHTML3(String strHTML3)
	{
		this.strHTML3 = strHTML3;
	}
	public String getStrHTML4()
	{
		return strHTML4;
	}
	public void setStrHTML4(String strHTML4)
	{
		this.strHTML4 = strHTML4;
	}
	public String getStrHTML5()
	{
		return strHTML5;
	}
	public String getStrHTML6()
	{
		return strHTML6;
	}
	public void setStrHTML6(String strHTML6)
	{
		this.strHTML6 = strHTML6;
	}
	public String getStrHTML7()
	{
		return strHTML7;
	}
	public void setStrHTML7(String strHTML7)
	{
		this.strHTML7 = strHTML7;
	}
	public String getStrHTML8()
	{
		return strHTML8;
	}
	public void setStrHTML8(String strHTML8)
	{
		this.strHTML8 = strHTML8;
	}
	public String getStrHTML9()
	{
		return strHTML9;
	}
	public void setStrHTML9(String strHTML9)
	{
		this.strHTML9 = strHTML9;
	}
	public String getStrHTML10()
	{
		return strHTML10;
	}
	public void setStrHTML10(String strHTML10)
	{
		this.strHTML10 = strHTML10;
	}
	public String getStrHTML11()
	{
		return strHTML11;
	}
	public void setStrHTML11(String strHTML11)
	{
		this.strHTML11 = strHTML11;
	}
	public String getStrHTML12()
	{
		return strHTML12;
	}
	public void setStrHTML12(String strHTML12)
	{
		this.strHTML12 = strHTML12;
	}
	public String getStrHTML13()
	{
		return strHTML13;
	}
	public void setStrHTML13(String strHTML13)
	{
		this.strHTML13 = strHTML13;
	}
	public String getStrHTML14()
	{
		return strHTML14;
	}
	public void setStrHTML14(String strHTML14)
	{
		this.strHTML14 = strHTML14;
	}
	public String getStrHTML15()
	{
		return strHTML15;
	}
	public void setStrHTML15(String strHTML15)
	{
		this.strHTML15 = strHTML15;
	}
	public String getStrHTML16()
	{
		return strHTML16;
	}
	public void setStrHTML16(String strHTML16)
	{
		this.strHTML16 = strHTML16;
	}
	public String getStrHTML17()
	{
		return strHTML17;
	}
	public void setStrHTML17(String strHTML17)
	{
		this.strHTML17 = strHTML17;
	}
	public String getStrHTML18()
	{
		return strHTML18;
	}
	public void setStrHTML18(String strHTML18)
	{
		this.strHTML18 = strHTML18;
	}
	public String getStrHTML19()
	{
		return strHTML19;
	}
	public void setStrHTML19(String strHTML19)
	{
		this.strHTML19 = strHTML19;
	}
	public String getStrHTML20()
	{
		return strHTML20;
	}
	public void setStrHTML20(String strHTML20)
	{
		this.strHTML20 = strHTML20;
	}
	public void setStrHTML5(String strHTML5)
	{
		this.strHTML5 = strHTML5;
	}
	public String getStrLastUpdate()
	{
		return strLastUpdate;
	}
	public void setStrLastUpdate(String strLastUpdate)
	{
		this.strLastUpdate = strLastUpdate;
	}
	public String getStrUpdateAdmin()
	{
		return strUpdateAdmin;
	}
	public void setStrUpdateAdmin(String strUpdateAdmin)
	{
		this.strUpdateAdmin = strUpdateAdmin;
	}

}
