package jp.co.webcrew.filters.filters.accesslog;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.filters.util.DBAccessUtil;

/**
 * サイトアクセス履歴を管理するdbクラス。
 * 
 * @author fu
 */
public class SiteAccessHistDb {

    /** DBカラム定義 */
    public static final String ACCESS_COUNT = "access_count";
    public static final String FIRST_ACCESS_TIME = "first_access_time";
    public static final String LAST_ACCESS_TIME = "last_access_time";

    /** サイトアクセス履歴取得用SQL */
    private static final String SITE_ACCESS_HIST_SELECT = "select site_access_hist.* from site_access_hist where guid = ? and category_id = ?";

    /** サイトアクセス履歴挿入用SQL */
    private static final String SITE_ACCESS_HIST_INSERT = "insert into site_access_hist(guid, category_id, access_count, first_access_time, last_access_time) values(?, ?, ?, to_char(sysdate, 'YYYYMMDDHH24MISS'), to_char(sysdate, 'YYYYMMDDHH24MISS'))";

    /** サイトアクセス履歴更新用SQL */
    private static final String SITE_ACCESS_HIST_UPDATE = "update site_access_hist set access_count = ?, last_access_time = to_char(sysdate, 'YYYYMMDDHH24MISS') where guid = ? and category_id = ?";

    /** サイトセッションプロパティ:同じURLへ再アクセスする場合アクセス回数を更新する間隔時間 */
    public static final String SITE_ACCESS_HIST_UPDATE_LIMIT = "SITE_ACCESS_HIST_UPDATE_LIMIT";

    /** サイトセッションプロパティ:サイトアクセス履歴に登録必要なURLパターン */
    public static final String SITE_ACCESS_REGISTER_URL_PATTERN = "SITE_ACCESS_REGISTER_URL_PATTERN";

    /**
     * このユーザがこのカテゴリURLに記録したデータをMAPに返す
     * 
     * @param guid
     * @param categoryId
     * @return histMap KEYはDBカラムと同じ、例：access_count、first_access_time、last_access_time
     * @throws SQLException
     */
    public static Map getAccessHistMap(int guid, int categoryId) throws SQLException {

        Map histMap = null;
        DBAccess dbAccess = null;
        ResultSet rs = null;

        try {
            dbAccess = DBAccessUtil.getLogDB();

            // サイトアクセス履歴を検索する。
            dbAccess.prepareStatement(SITE_ACCESS_HIST_SELECT);
            dbAccess.setInt(1, guid);
            dbAccess.setInt(2, categoryId);
            rs = dbAccess.executeQuery();

            // データ存在する場合
            while (dbAccess.next(rs)) {
                histMap = new HashMap();
                histMap.put(ACCESS_COUNT, rs.getString(ACCESS_COUNT));
                histMap.put(FIRST_ACCESS_TIME, rs.getString(FIRST_ACCESS_TIME));
                histMap.put(LAST_ACCESS_TIME, rs.getString(LAST_ACCESS_TIME));
            }

            return histMap;

        } finally {
            DBAccess.close(rs);
            DBAccess.close(dbAccess);
        }

    }

    /**
     * サイトアクセス履歴を作成してdbに格納する。
     * 
     * @param guid
     * @param category_id
     * @param access_count
     * @throws SQLException
     */
    public static void insertSiteAccessHist(int guid, int category_id, int access_count) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = DBAccessUtil.getLogDB();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // サイトアクセス履歴を作成する。
            dbAccess.prepareStatement(SITE_ACCESS_HIST_INSERT);
            int i = 0;
            dbAccess.setInt(++i, guid);
            dbAccess.setInt(++i, category_id);
            dbAccess.setInt(++i, access_count);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

    /**
     * サイトアクセス履歴を更新する。
     * 
     * @param guid
     * @param category_id
     * @param access_count
     * @throws SQLException
     */
    public static void updateSiteAccessHist(int guid, int category_id, int access_count) throws SQLException {

        DBAccess dbAccess = null;
        try {
            dbAccess = DBAccessUtil.getLogDB();

            // トランザクションを開始する。
            dbAccess.setAutoCommit(false);

            // サイトアクセス履歴を更新する。
            dbAccess.prepareStatement(SITE_ACCESS_HIST_UPDATE);
            int i = 0;
            dbAccess.setInt(++i, access_count);
            dbAccess.setInt(++i, guid);
            dbAccess.setInt(++i, category_id);
            dbAccess.executeUpdate();

            // コミットする。
            dbAccess.commit();

        } catch (SQLException e) {
            // ロールバックする。
            dbAccess.rollback();
            throw e;

        } finally {
            DBAccess.close(dbAccess);
        }

    }

}
