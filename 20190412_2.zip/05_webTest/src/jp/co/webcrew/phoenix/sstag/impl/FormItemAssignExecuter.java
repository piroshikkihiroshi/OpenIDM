package jp.co.webcrew.phoenix.sstag.impl;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * フォーム項目に特定の値を設定するsstagクラス。
 * 
 * @author kurinami
 */
public class FormItemAssignExecuter extends SSTagExecuter {

    /** パラメータ名：post項目名とテーブルのカラム名の組み合わせと型変換 */
    private static final String ITEM_MAP_PARAM_KEY = "item_map";

    /** パラメータ名：item_map 内の任意文字を示すマーカー */
    private static final String MARKER_PARAM_KEY = "marker";

    /** デフォルトの任意文字を示すマーカー */
    private static final String DEFAULT_MARKER = "'";

    /** ロガー */
    private static final Logger log = Logger.getLogger(FormItemAssignExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    @SuppressWarnings("unchecked")
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            // パラメータの取得
            String[][] itemMap = SstagUtil.splitItemMap((String) parameters.get(ITEM_MAP_PARAM_KEY));
            String marker = ValueUtil.nullToStr(parameters.get(MARKER_PARAM_KEY));

            // 任意文字を示すマーカーが指定されていない場合、
            if (PhoenixUtil.isEmpty(marker)) {
                // デフォルトを使用する。
                marker = DEFAULT_MARKER;
            }

            // セッションストアで保持しているフォームデータを取得する。
            PostInfo postInfo = StoreUtil.getPostInfo(request);
            if (postInfo == null) {
                postInfo = new PostInfo();
            }

            // フォームデータに値を格納する。
            for (String[] item : itemMap) {
                String value = item[0].trim();
                String itemId = item[1].trim();

                // 引用符でくくられている場合、引用符をはずす。
                if (value.length() >= marker.length() * 2 && value.startsWith(marker) && value.endsWith(marker)) {
                    value = value.substring(marker.length(), value.length() - marker.length());
                }

                postInfo.postItemMap.put(itemId, new String[] { value });
            }

            // セッションストアにフォームデータを格納し直す。
            StoreUtil.setPostInfo(request, postInfo);

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

}
