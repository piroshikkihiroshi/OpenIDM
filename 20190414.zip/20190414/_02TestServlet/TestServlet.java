package _02TestServlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.logic.lib._02_work.Kadai_3_2_DbTest;
import jp.co.webcrew.phoenix.util.PhoenixRequestContext;

/**
 * Servlet implementation class TestServlet
 */
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestServlet() {
        super();


        // TODO Auto-generated constructor stub
    }

    public void init() {
        // Context 初期化パラメータ情報
        ServletConfig config = getServletConfig();
        ServletContext context = config.getServletContext();
//        directory = context.getInitParameter("directory");

        // Servlet 初期化パラメータ情報
//        image = config.getInitParameter("image");
      }

    public void test1() {
//        ServletConfig ServletConfig = this.getServletConfig();
//        ServletContext context = ServletConfig.getServletContext();
////        ServletConfig ServletConfiga = new ServletConfig();
//        Kadai_3_2_DbTest objTest = new Kadai_3_2_DbTest();
//        objTest.jspTest(ServletConfig);
    }


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        ServletConfig ServletConfig = this.getServletConfig();
        ServletContext context = ServletConfig.getServletContext();
		PhoenixRequestContext.bindServletObject(request, response);
        Kadai_3_2_DbTest objTest = new Kadai_3_2_DbTest();
        objTest.jspTest(ServletConfig);
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
