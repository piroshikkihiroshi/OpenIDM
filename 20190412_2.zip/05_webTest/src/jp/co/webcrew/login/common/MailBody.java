package jp.co.webcrew.login.common;

import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.SystemProperties;

public class MailBody
{
	private Map hmapBodyParam = null;
	
	/**
	 * コンストラクタ
	 */
	public MailBody()
	{
		hmapBodyParam = new HashMap();
	}
	
	/**
	 * コンストラクタ
	 * 
	 * @param objMemberMst
	 */
	public MailBody(MemberMst objMemberMst)
	{
		hmapBodyParam = new HashMap();
		
		setNickName(objMemberMst.get(MemberMst.NICKNAME));
		setMemberName1(objMemberMst.get(MemberMst.NAME1));
		setMemberName2(objMemberMst.get(MemberMst.NAME2));
	}
	
	/**
	 * コンストラクタ
	 * 
	 * @param objDbAccess
	 * @param strGuid
	 * @throws Exception
	 */
	public MailBody(DBAccess objDbAccess, String strGuid) throws Exception
	{
		hmapBodyParam = new HashMap();
		
		MemberMst objMemberMst = new MemberMst(strGuid);
		if (!objMemberMst.load(objDbAccess))
		{
			setNickName("");
			setMemberName1("");
			setMemberName2("");
		}
		else
		{
			setNickName(objMemberMst.get(MemberMst.NICKNAME));
			setMemberName1(objMemberMst.get(MemberMst.NAME1));
			setMemberName2(objMemberMst.get(MemberMst.NAME2));
		}
	}
	
	/**
	 * サイト名を保存する。
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strSiteName サイト名
	 */
//	public void setSiteName(String strSiteName)
//	{
//		hmapBodyParam.put("\\$\\$site_name\\$\\$", ValueUtil.strToNull(strSiteName));
//	}
	
	/**
	 * 氏名(姓)を保存する。
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strMemberName1 氏名(姓)
	 */
	public void setMemberName1(String strMemberName1)
	{
		hmapBodyParam.put("\\$\\$member_name1\\$\\$", ValueUtil.strToNull(strMemberName1));
	}
	
	/**
	 * 氏名(名)を保存する。
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strMemberName2 氏名(名)
	 */
	public void setMemberName2(String strMemberName2)
	{
		hmapBodyParam.put("\\$\\$member_name2\\$\\$", ValueUtil.strToNull(strMemberName2));
	}
	
	/**
	 * 氏名(セイ)を保存する。
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strMemberFuri1 氏名(セイ)
	 */
	public void setMemberFuri1(String strMemberFuri1)
	{
		hmapBodyParam.put("\\$\\$member_furi1\\$\\$", ValueUtil.strToNull(strMemberFuri1));
	}
	
	/**
	 * 氏名(メイ)を保存する。
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strMemberName2 氏名(メイ)
	 */
	public void setMemberFuri2(String strMemberFuri2)
	{
		hmapBodyParam.put("\\$\\$member_furi2\\$\\$", ValueUtil.strToNull(strMemberFuri2));
	}
	
	/**
	 * ニックネームを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strNickName
	 */
	public void setNickName(String strNickName)
	{
		hmapBodyParam.put("\\$\\$nickname\\$\\$", ValueUtil.strToNull(strNickName));
	}
	
	/**
	 * EMAILを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strEmail
	 */
	public void setEmail(String strEmail)
	{
		hmapBodyParam.put("\\$\\$email\\$\\$", ValueUtil.strToNull(strEmail));
	}
	
	/**
	 * EMAILを保存する
	 * UTF-8にエンコードされたEMAILが保存されます
	 * 
	 * @param strEmail
	 * @throws Exception
	 */
	public void setEncodeEmail(String strEmail) throws Exception
	{
		hmapBodyParam.put("\\$\\$encodeEmail\\$\\$", java.net.URLEncoder.encode(strEmail , "utf-8")); 
    hmapBodyParam.put("\\$\\$encode_email\\$\\$", java.net.URLEncoder.encode(strEmail , "utf-8"));
	}
	
	/**
	 * ワンタイムIDを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strOneTimeId
	 */
	public void setOneTimeId(String strOneTimeId)
	{
		hmapBodyParam.put("\\$\\$one_time_id\\$\\$", ValueUtil.strToNull(strOneTimeId));
	}
	
	/**
	 * ログイン画面のURLを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strAuthUrl
	 */
	public void setAuthUrl(String strAuthUrl)
	{
		hmapBodyParam.put("\\$\\$auth_url\\$\\$", ValueUtil.strToNull(strAuthUrl));
	}
	
	/**
	 * 指定したプロパティIDと一致するログイン画面へのURLを保存する
	 * 指定したプロパティIDが存在しない場合は例外を返す
	 * 
	 * @param objSystemProperties
	 * @param strPropId
	 * @param strMailTo
	 * @param strPasswd
	 * @throws Exception
	 */
	public void setMypageAuthUrl(SystemProperties objSystemProperties, String strPropId, String strMailTo, String strPasswd) throws Exception
	{
		String strAuthUrl = ValueUtil.nullToStr(objSystemProperties.get(strPropId));
    if (strAuthUrl.equals("")) {
        throw new Exception("システムプロパティ " + strPropId + " の取得に失敗しました。メール送信を中断します。");
    }
    strAuthUrl += "?email="  + java.net.URLEncoder.encode(strMailTo ,"utf-8"); // モバイルはsjisだが,e-mailに全角は入らないはず
    strAuthUrl += "&passwd=" + strPasswd;
    
    hmapBodyParam.put("\\$\\$auth_url\\$\\$", strAuthUrl);
	}
	
	/**
	 * ログイン画面のURLを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strLoginUrl
	 */
	public void setLoginUrl(String strLoginUrl)
	{
		hmapBodyParam.put("\\$\\$login_url\\$\\$", ValueUtil.strToNull(strLoginUrl));
	}
	
	/**
	 * 指定したプロパティIDと一致するログイン画面へのURLを保存する
	 * 指定したプロパティIDが存在しない場合は例外を返す
	 * 
	 * @param objSystemProperties
	 * @param strPropId
	 * @param strMailTo
	 * @param strPasswd
	 * @throws Exception
	 */
	public void setMypageLoginUrl(SystemProperties objSystemProperties, String strPropId, String strMailTo, String strPasswd) throws Exception
	{
		String strLoginUrl = ValueUtil.nullToStr(objSystemProperties.get(strPropId));
		if (strLoginUrl.equals(""))
		{
			throw new Exception("システムプロパティ " + strPropId + " の取得に失敗しました。メール送信を中断します。");
		}
		strLoginUrl += "?email="  + java.net.URLEncoder.encode(strMailTo ,"utf-8"); // モバイルはsjisだが,e-mailに全角は入らないはず
		strLoginUrl += "&passwd=" + strPasswd;

		hmapBodyParam.put("\\$\\$login_url\\$\\$", strLoginUrl);
		
		System.out.println("");
	}
	
	/**
	 * パスワードを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strAuthPass
	 */
	public void setAuthPass(String strAuthPass)
	{
		hmapBodyParam.put("\\$\\$auth_pass\\$\\$", ValueUtil.strToNull(strAuthPass));
	}
	
	/**
	 * パスワードを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strLoginPass
	 */
	public void setLoginPass(String strLoginPass)
	{
		hmapBodyParam.put("\\$\\$login_pass\\$\\$", ValueUtil.strToNull(strLoginPass));
	}
	
	/**
	 * パスワードを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strPassword
	 */
	public void setPassword(String strPassword)
	{
		hmapBodyParam.put("\\$\\$password\\$\\$", ValueUtil.strToNull(strPassword));
	}
	
	/**
	 * パスワードを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strPasswd
	 */
	public void setPass(String strPasswd)
	{
		hmapBodyParam.put("\\$\\$passwd\\$\\$", ValueUtil.strToNull(strPasswd));
	}
	
	/**
	 * リマインダ画面へのURLを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strReminderUrl
	 */
	public void setReminderUrl(String strReminderUrl)
	{
		hmapBodyParam.put("\\$\\$reminder_url\\$\\$", ValueUtil.strToNull(strReminderUrl));
	}
	
	/**
	 * 指定したプロパティIDと一致するリマインダ画面へのURLを保存する
	 * 指定したプロパティIDが存在しない場合は例外を返す
	 * 
	 * @param objSystemProperties
	 * @param strPropId
	 * @throws Exception
	 */
	public void setMypageReminderUrl(SystemProperties objSystemProperties, String strPropId) throws Exception
	{
		String strReminderUrl = ValueUtil.nullToStr(objSystemProperties.get(strPropId));
		if (strReminderUrl.equals(""))
		{
			throw new Exception("システムプロパティ " + strPropId + " の取得に失敗しました。メール送信を中断します。");
		}
		hmapBodyParam.put("\\$\\$reminder_url\\$\\$", strReminderUrl);
	}
	
	/**
	 * 会員登録解除画面へのURLを保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strDeleteMemberUrl
	 */
	public void setDeleteMemberUrl(String strDeleteMemberUrl)
	{
		hmapBodyParam.put("\\$\\$delete_member_url\\$\\$", ValueUtil.strToNull(strDeleteMemberUrl));
	}
	
	/**
	 * 指定したプロパティIDと一致する会員登録解除画面へのURLを保存する
	 * 指定したプロパティIDが存在しない場合は例外を返す
	 * 
	 * @param objSystemProperties
	 * @param strPropId
	 * @param strMailTo
	 * @param strOneTimeId
	 * @throws Exception
	 */
	public void setMypageDeleteMemberUrl(SystemProperties objSystemProperties, String strPropId, String strMailTo, String strOneTimeId) throws Exception
	{
		String strDeleteMemberUrl = ValueUtil.nullToStr(objSystemProperties.get(strPropId));
		if (strDeleteMemberUrl.equals(""))
		{
			throw new Exception("システムプロパティ " + strPropId + " の取得に失敗しました。メール送信を中断します。");
		}
		strDeleteMemberUrl += "?email="  + java.net.URLEncoder.encode(strMailTo ,"utf-8"); // モバイルはsjisだが,e-mailに全角は入らないはず
		strDeleteMemberUrl += "&one_time_id=" + strOneTimeId;

		hmapBodyParam.put("\\$\\$delete_member_url\\$\\$", strDeleteMemberUrl);
	}
	
	/**
	 * ポイント交換を行う景品の一覧を保存
	 * 
	 * @param strPointExcOrderListAdmin
	 */
	public void setPointExcOrderList(String strPointExcOrderList)
	{
		hmapBodyParam.put("\\$\\$point_exc_order_list\\$\\$", ValueUtil.strToNull(strPointExcOrderList));
	}
	
	/**
	 * ポイント交換を行う景品の一覧を保存
	 * 
	 * @param strPointExcOrderListAdmin
	 */
	public void setPointExcOrderListAdmin(String strPointExcOrderListAdmin)
	{
		hmapBodyParam.put("\\$\\$point_exc_order_list_admin\\$\\$", ValueUtil.strToNull(strPointExcOrderListAdmin));
	}
	
	/**
	 * GUIDを保存
	 * 
	 * @param strGuid
	 */
	public void setGuid(String strGuid)
	{
		hmapBodyParam.put("\\$\\$guid\\$\\$", strGuid);
	}
	
	/**
	 * 申込者番号を保存
	 * 
	 * @param strOrderId
	 */
	public void setOrderId(String strOrderId)
	{
		hmapBodyParam.put("\\$\\$order_id\\$\\$", strOrderId);
	}
	
	/**
	 * 申し込み日を保存
	 * 
	 * @param strOrderDate
	 */
	public void setOrderDate(String strOrderDate)
	{
		hmapBodyParam.put("\\$\\$order_date\\$\\$", strOrderDate);
	}
	
	/**
	 * サプライヤ名を保存
	 * 
	 * @param strSupplierText
	 */
	public void setSupplierText(String strSupplierText)
	{
		hmapBodyParam.put("\\$\\$supplier_text\\$\\$", strSupplierText);
	}
	
	/**
	 * 修正タイプを保存
	 * 
	 * @param strSupplierText
	 */
	public void setAmendType(String strAmendType)
	{
		hmapBodyParam.put("\\$\\$amend_type\\$\\$", strAmendType);
	}
	
	/**
	 * 修正内容を保存
	 * 
	 * @param strAmendContents
	 */
	public void setAmendContents(String strAmendContents)
	{
		hmapBodyParam.put("\\$\\$amend_contents\\$\\$", strAmendContents);
	}
	
	/**
	 * ご利用ポイントを保存
	 * 
	 * @param strUsedPoint
	 */
	public void setUsedPoint(String strUsedPoint)
	{
		hmapBodyParam.put("\\$\\$used_point\\$\\$", strUsedPoint);
	}
	
	/**
	 * 申し込み換金額を保存
	 * 
	 * @param strCashAmount
	 */
	public void setCashAmount(String strCashAmount)
	{
		hmapBodyParam.put("\\$\\$cash_amount\\$\\$", strCashAmount);
	}
	
	/**
	 * ご利用後の残ポイントを保存
	 * 
	 * @param strRemainingPoint
	 */
	public void setRemainingPoint(String strRemainingPoint)
	{
		hmapBodyParam.put("\\$\\$remaining_point\\$\\$", strRemainingPoint);
	}
	
	/**
	 * サイト固有文言1を保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strSiteVarContents1
	 */
//	public void setSiteVarContents1(String strSiteVarContents1)
//	{
//		hmapBodyParam.put("\\$\\$site_var_contents_1\\$\\$", ValueUtil.strToNull(strSiteVarContents1));
//	}
	
	/**
	 * サイト固有文言2を保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strSiteVarContents2
	 */
//	public void setSiteVarContents2(String strSiteVarContents2)
//	{
//		hmapBodyParam.put("\\$\\$site_var_contents_2\\$\\$", ValueUtil.strToNull(strSiteVarContents2));
//	}
	
	/**
	 * サイト固有文言3を保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strSiteVarContents3
	 */
//	public void setSiteVarContents3(String strSiteVarContents3)
//	{
//		hmapBodyParam.put("\\$\\$site_var_contents_3\\$\\$", ValueUtil.strToNull(strSiteVarContents3));
//	}
	
	/**
	 * サイト固有文言4を保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strSiteVarContents4
	 */
//	public void setSiteVarContents4(String strSiteVarContents4)
//	{
//		hmapBodyParam.put("\\$\\$site_var_contents_4\\$\\$", ValueUtil.strToNull(strSiteVarContents4));
//	}
	
	/**
	 * サイト固有文言5を保存する
	 * nullが指定された場合は、空文字がマップに保存されます。
	 * 
	 * @param strSiteVarContents5
	 */
//	public void setSiteVarContents5(String strSiteVarContents5)
//	{
//		hmapBodyParam.put("\\$\\$site_var_contents_5\\$\\$", ValueUtil.strToNull(strSiteVarContents5));
//	}
	
	/**
	 * タイトルの変数を置き換えるための値を保持するマップを返す
	 * 
	 * @return
	 */
	public Map getBodyParam()
	{
		return hmapBodyParam;
	}
	
	/**
	 * タイトルの変数を保持するマップを設定する
	 * 
	 * @param hmapSubjectParam
	 */
//	public void setBodyParam(HashMap hmapSubjectParam)
//	{
//		this.hmapBodyParam = hmapSubjectParam;
//	}
	
	/**
	 * パスワードを設定する
	 * 
	 */
	public void setPasswordAll(String strPassword)
	{
		setAuthPass(strPassword);
		setLoginPass(strPassword);
		setPassword(strPassword);
		setPass(strPassword);
	}
	
	/**
	 * 注文番号を保存する
	 * 
	 * @param lngPurchaseId
	 */
	public void setPurchaseId(long lngPurchaseId)
	{
		hmapBodyParam.put("\\$\\$purchase_id\\$\\$", String.valueOf(lngPurchaseId));
	}
	
	/**
	 * 姓を保存する
	 * 
	 * @param strFamilyName
	 */
	public void setFamilyName(String strFamilyName)
	{
		hmapBodyParam.put("\\$\\$family_name\\$\\$", strFamilyName);
	}
	
	/**
	 * 名を保存する
	 * 
	 * @param strFirstName
	 */
	public void setFirstName(String strFirstName)
	{
		hmapBodyParam.put("\\$\\$first_name\\$\\$", strFirstName);
	}

	/**
	 * 注文確認画面のURLを保存する
	 * 
	 * @param mypagePurchaseUrl
	 */
	public void setMypagePurchaseUrl(String mypagePurchaseUrl)
	{
		hmapBodyParam.put("\\$\\$mypage_purchase_url\\$\\$", mypagePurchaseUrl);
	}

	/**
	 * 注文日時を保存する
	 * 
	 * @param format
	 */
	public void setPurchaseDateTime(String format)
	{
		hmapBodyParam.put("\\$\\$purchase_datetime\\$\\$", format);
	}
	
	/**
	 * 取得ポイントを保存する
	 * 
	 * @param format
	 */
	public void setPointTotal(String addPoint)
	{
		hmapBodyParam.put("\\$\\$point_total\\$\\$", addPoint);
	}

	/**
	 * 注文内容を保存する
	 * 
	 * @param purchaseDetail
	 */
	public void setPurchaseDetail(String purchaseDetail)
	{
		hmapBodyParam.put("\\$\\$purchase_detail\\$\\$", purchaseDetail);
	}

	/**
	 * 住所を保存する
	 * 
	 * @param string
	 */
	public void setAddress(String address)
	{
		hmapBodyParam.put("\\$\\$address\\$\\$", address);
	}

	/**
	 * @param nullToStr
	 */
	public void setTel(String tel)
	{
		hmapBodyParam.put("\\$\\$tel\\$\\$", tel);
	}

	/**
	 * 配送先住所を保存する
	 * 
	 * @param string
	 */
	public void setDeliveryAddress(String address)
	{
		hmapBodyParam.put("\\$\\$delivery_address\\$\\$", address);
	}

	/**
	 * 配送先電話番号を保存する
	 * 
	 * @param nullToStr
	 */
	public void setDeliveryTel(String tel)
	{
		hmapBodyParam.put("\\$\\$delivery_tel\\$\\$", tel);
	}

	/**
	 * 配送に関するメッセージを保存する
	 * 
	 * @param nullToStr
	 */
	public void setDeliveryComment(String message)
	{
		hmapBodyParam.put("\\$\\$delivery_message\\$\\$", message);
	}

	/**
	 * メッセージを保存する
	 * 
	 * @param nullToStr
	 */
	public void setComment(String message)
	{
		hmapBodyParam.put("\\$\\$message\\$\\$", message);
	}

	/**
	 * 受付番号を保存する
	 * 
	 * @param cvsReceiptNo
	 */
	public void setAccountNumber(String cvsReceiptNo)
	{
		hmapBodyParam.put("\\$\\$account_number\\$\\$", cvsReceiptNo);
	}

	/**
	 * 支払い期限を保存する
	 * 
	 * @param format
	 */
	public void setPaymentDeadline(String limit)
	{
		hmapBodyParam.put("\\$\\$payment_deadline\\$\\$", limit);
	}

	/**
	 * @param strMypageInduceComment
	 */
	public void setMypageInduceComment(String strMypageInduceComment)
	{
		hmapBodyParam.put("\\$\\$mypage_induce_comment\\$\\$", strMypageInduceComment);
	}
	
	/**
	 * 
	 * @param strPlaneEatetime
	 */
	public void setPlanedDatetime(String strPlaneEatetime)
	{
		hmapBodyParam.put("\\$\\$planed_datetime\\$\\$", strPlaneEatetime);
	}
	
	/**
	 * 
	 * @param strFreeText1
	 */
	public void setFreeText1(String strFreeText1)
	{
		hmapBodyParam.put("\\$\\$free_text1\\$\\$", strFreeText1);
	}
	
	/**
	 * 
	 * @param strFreeText2
	 */
	public void setFreeText2(String strFreeText2)
	{
		hmapBodyParam.put("\\$\\$free_text2\\$\\$", strFreeText2);
	}

	/**
	 * @param nullToStr
	 */
	public void setDeliveryFamilyName(String strFamilyName)
	{
		hmapBodyParam.put("\\$\\$delivery_family_name\\$\\$", strFamilyName);
	}

	/**
	 * @param nullToStr
	 */
	public void setDeliveryFirstName(String strFirstName)
	{
		hmapBodyParam.put("\\$\\$delivery_first_name\\$\\$", strFirstName);
	}

	/**
	 * @param payMethodName
	 */
	public void setPayMethodName(String payMethodName)
	{
		hmapBodyParam.put("\\$\\$pay_method_name\\$\\$", payMethodName);
	}

	/**
	 * @param person
	 */
	public void setPerson(String person)
	{
		hmapBodyParam.put("\\$\\$person\\$\\$", person);
	}

	/**
	 * @param shippingTrader
	 */
	public void setShippingTrader(String shippingTrader)
	{
		hmapBodyParam.put("\\$\\$shipping_trader\\$\\$", shippingTrader);
	}

	/**
	 * @param voucherNo
	 */
	public void setVoucherNo(String voucherNo)
	{
		hmapBodyParam.put("\\$\\$voucher_no\\$\\$", voucherNo);
	}

	/**
	 * @param shippingDatetime
	 */
	public void setShippingDatetime(String shippingDatetime)
	{
		hmapBodyParam.put("\\$\\$shipping_datetime\\$\\$", shippingDatetime);
	}
}
