package jp.co.webcrew.login.common.db;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.login.common.db.util.Record;

public class SystemProperties {

	/** ロガー */
	private static final Logger log = Logger.getLogger(SystemProperties.class);
	/** 列名 キー */
	private static final String COL_NAME = "NAME";
	/** 列名 値 */
	private static final String COL_VALUE= "VALUE";
	
	/** SMTPホスト名 */
	public static final String MAIL_SMTP_HOST = "MAIL_SMTP_HOST";
	/** SMTPポート名 */
	public static final String MAIL_SMTP_PORT = "MAIL_SMTP_PORT";
	/** 仮登録メール送付者 */
	public static final String MAIL_SENDER_OF_TEMPORARY_REGIST = "MAIL_SENDER_OF_TEMPORARY_REGIST";
	/** 仮登録メール送付者 */
	public static final String MAIL_SENDER_OF_REGIST = "MAIL_SENDER_OF_REGIST";
	/** step_loginのURI先頭 */
	public static final String LOGIN_APP_URI_TOP = "LOGIN_APP_URI_TOP";
	/** step_loginのログイン画面 */
	public static final String STEP_LOGIN_LOGIN_PATH = "STEP_LOGIN_LOGIN_PATH";
	/** 本登録画面 */
	public static final String REGIST_AUTH_URI_PATH = "REGIST_AUTH_URI_PATH";
	/** 本登録までの有効期限（日） */
	public static final String LIMIT_FROM_TEMPORARY_REGIST = "LIMIT_FROM_TEMPORARY_REGIST";

	/** 本登録の際のコピー制限 */
	public static final String PAST_DATA_COPY_LIMIT = "PAST_DATA_COPY_LIMIT";

    /** ログイン時の制限時間 */
    public static final String LOGIN_TIMEOUT = "LOGIN_TIMEOUT"; //未使用
    
	/** テストの際に、進める日数（日） */
	public static final String TEST_MOVE_CURRENT_DATETIME = "TEST_MOVE_CURRENT_DATETIME";
	/** テストの際に、携帯電話からのアクセスであると見なす */
	public static final String TEST_MOBILE = "TEST_MOBILE";
	/** テストの際に、法人サイトからの登録であると見なす */
	public static final String TEST_COMPANY = "TEST_COMPANY";
	/** テストの際に、法人サイトからの登録であると見なす */
	public static final String TEST_SMTP_LOCALHOST = "TEST_SMTP_LOCALHOST";

	/** マイページ退会処理 メール送信者 */
	public static final String MAIL_SENDER_OF_MYPAGE_RESIGN = "MAIL_SENDER_OF_MYPAGE_RESIGN";

	/** マイページ退会処理 メール送信者 */
	public static final String MOBILE_MAIL_SUFFIXES = "MOBILE_MAIL_SUFFIXES";

    
	
	
	
	/** 会員サイトのトップページ(PC) */
	public static final String MEMBER_SITE_TOP_URI_PC = "MEMBER_SITE_TOP_URI_PC";

	/** 会員サイトのトップページ(携帯) */
	public static final String MEMBER_SITE_TOP_URI_MOBILE              = "MEMBER_SITE_TOP_URI_MOBILE";
//	public static final String REGIST_COPY_LIMIT_FROM_TEMPORARY_REGIST = "REGIST_COPY_LIMIT_FROM_TEMPORARY_REGIST";
	
	/** となしばのURI_TOP */
	public static final String TNS_URI_TOP         = "TNS_URI_TOP";

	/** となしばログインのURI_TOP */
	public static final String TNS_LOGIN_URI_TOP   = "TNS_LOGIN_URI_TOP";

	/** となしばログインの登録画面へのパス */
	public static final String TNS_REGIST_URI_PATH = "TNS_REGIST_URI_PATH";

	/** 本登録画面でデフォルトで使用するサイトID */
	public static final String DEFAULT_SITE_ID_FOR_REGIST = "DEFAULT_SITE_ID_FOR_REGIST";

    /** マイページ ログイン画面トップ */
    public static final String MYPAGE_LOGIN_TOP      = "MYPAGE_LOGIN_TOP";

    /** マイページ リマインダ画面トップ */
    public static final String MYPAGE_REMINDER_TOP   = "MYPAGE_REMINDER_TOP";

    /** マイページ なりすまし防止画面トップ */
    public static final String MYPAGE_DEL_MEMBER_TOP = "MYPAGE_DEL_MEMBER_TOP";

    
    
	private Map _propertyMap = new HashMap();

	/** ロガー */
//	private Logger log = Logger.getLogger(this.getClass());
	
	
	/** 不可視 */
	private SystemProperties(){}

	/**
	 * <prd>
	 * コンストラクタ
	 * <br/>このメソッドは常にDBから取得しています。DBAccessのSystemPropertiesDbにはキャッシュ（6分間ずつ更新）から取得できます（初期化が必要）。 <br/>
	 * もしそちら使えばそちらをお進めます。 詳しくはこちら{@link jp.co.webcrew.dbaccess.db.SystemPropertiesDb}
	 * <br/>なお、初期化保証できないクラスに、例えば本JARファイルにpropertiesの取得処理でこのメソッドを使ってもいいです。
	 * @param db DBアクセサ
	 * @throws SQLException DB読み込みに失敗した時
	 * </pre>
	 */
	public SystemProperties(DBAccess db) throws SQLException{
		load(db);
	}

	private void load(DBAccess db) throws SQLException{
		log.info("load start");
		ResultSet rs = null;
		try{

			String sql = "select * from " + db.getSchema(".") + "system_properties";
			db.prepareStatement(sql);
			rs = db.executeQuery();
			while(rs.next()){
				String key = Record.readDBStr(rs.getString(COL_NAME));
				String value = Record.readDBStr(rs.getString(COL_VALUE));
				getProperties().put(key, value);
			}

		} finally {
			DBAccess.close(rs);
		}
		
	}
	
	/**
	 * システムプロパティ読み込み
	 * @param key キー
	 * @return String 値
	 * @return 空文字列 キーに該当する値が無いとき
	 */
	public String get(String key) {
		String ret = getRawData(key);
		if (ret == null) {
			return "";
		} else {
			return ret;
		}
	}
	
	public String getSmtpHost() {
/*
 		SiteProperties props = new SiteProperties();
		if (props.isSetSmtpLocalHost()){
			return "localhost";
		} else {
			return get(MAIL_SMTP_HOST);			
		}
*/
		if (get(TEST_SMTP_LOCALHOST).equals("1")){
			return "localhost";
		} else {
			return get(MAIL_SMTP_HOST);
		}
	}

	public String getLoginServerUrlTop() {
//		SiteProperties props = new SiteProperties();
//		if(props.isSetLoginServerLocalHost()) {
//			return "http://localhost";
//		}
		return  get(SystemProperties.LOGIN_APP_URI_TOP);
	}

	/**
	 * システムプロパティ読み込み
	 * @param key キー
	 * @return String 値
	 * @return null キーに該当する値が無いとき
	 */
	public String getRawData(String key) {
		return (String)getProperties().get(key);
	}

	/**
	 * プロパティ配列をMap形式で返却する
	 * @return Map プロパティ配列
	 */
	private final Map getProperties(){
		return _propertyMap;
	}

	/**
	 * 文字列中に埋め込まれたシステムプロパティ変数をシステムプロパティ値で置き換える
	 * 
	 * システムプロパティのキーと値のペア (key , val) があったとすると、
	 * 文字列中に埋め込まれた文字列"$$key$$"を、全てvalに置き換える
	 * 
	 * 変換に失敗した場合や、置換対象のシステムプロパティが見つからない場合はnullを返す
	 * 
	 * @param props システムプロパティオブジェクト
	 * @param src   変換元文字列
	 * @param key   置換対象となるシステムプロパティのキー
	 * @return
	 */
	private static String replace (SystemProperties props , String src , String key) {
		if (src == null) return null;
		
		if (key == null) return null;

		if (key.equals("")) return null; // $$$$は置き換えない

		try {
			String val = ValueUtil.nullToStr(props.get(key));
			if (val.equals("")) {
				log.warn("変数" + key + "はシステムプロパティに見つかりませんでした。");
				return null;
			}
			String replaceTarget = "\\$\\$" + key + "\\$\\$";
			
			return src.replaceAll(replaceTarget, val);

		} catch (Exception e) {
			log.error("文字列の置き換え時に例外エラーが発生しました。" , e);
			return null;
		}		
	}
	
	/**
	 * 文字列中に埋め込まれたシステムプロパティ変数をシステムプロパティ値で置き換える
	 * 
	 * システムプロパティのキーと値のペア (key , val) があったとすると、
	 * 文字列中に埋め込まれた文字列"$$key$$"を、全てvalに置き換える
	 * 
	 * keyはどんな値を使ってもよいし、変数は何回使ってもよい。
	 * ただし、システムプロパティに登録されていないキーが指定されるなどして、
	 * 置換に失敗した変数が一つでもあれば、nullが返される
	 * 
	 * @param props システムプロパティオブジェクト
	 * @param src   システムプロパティ変数置換前の文字列
	 * @return      システムプロパティ変数置換後の文字列
	 */
	public static String replace (SystemProperties props , String src) {

		if (props == null) {
			log.info("SystemPropertiesオブジェクトがnullです");
			return null;
		}
		if (src == null) {
			log.info("srcにnullが渡されました。");
			return null;
		}
		
		Pattern pattern = Pattern.compile("\\$\\$(.*?)\\$\\$");
		Matcher matcher = pattern.matcher(src);
		if (matcher.find()) {
			String key = matcher.group(1);
			if (key.equals("")) {
				log.info("不正な変数が検知されました。$$$$");
				log.info("src = " + src);
				return null;
			}
			src = replace(props, src, key); // システムプロパティ変数を置き換える
			if (src == null) {
				return null;
			}
			return replace(props , src); // 再帰
			
		} else {
			return src;
		}
		
	}

	/**
	 * <pre>
	 * 文字列src中に埋め込まれたシステムプロパティ変数をシステムプロパティ値で置き換える
	 * 
	 * システムプロパティのキーと値のペア (key , val) があったとすると、
	 * 文字列中に埋め込まれた文字列"$$key$$"を、全てvalに置き換える
	 * 
	 * keyはどんな値を使ってもよいし、変数は何回使ってもよい。
	 * ただし、システムプロパティに登録されていないキーが指定されるなどして、
	 * 
	 * 置換に失敗した変数が一つでもあれば、nullが返される
	 * 
	 * </pre>
	 * @param props
	 * @param src
	 * @return
	 */
	public String replaceStr (String src) {
		return SystemProperties.replace(this, src);
	}
}
