package jp.co.webcrew.phoenix.store.util;

import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.db.SiteMstDb;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.phoenix.store.bean.SessionStoreBean;
import jp.co.webcrew.phoenix.store.db.SessionStoreDb;
import jp.co.webcrew.phoenix.util.PhoenixUtil;

/**
 * セッションストア情報関連の機能を使うためのutilクラス。
 * 
 * @author kurinami
 */
public class SessionStoreUtil {

    /** 属性名：カレントのショートID */
    private static final String CURRENT_SHORT_ID_ATTR_KEY = "phoenix.current_short_id";

    /** 属性名：カレントのセッションストア */
    private static final String CURRENT_STORE_ATTR_KEY = "phoenix.current_store";

    /**
     * 現リクエストでのセッションストアを設定する。
     * 
     * @param request
     * @param shortId
     * @throws SQLException
     */
    public static void setCurrentSessionStore(HttpServletRequest request, String shortId) throws SQLException {
        long ssid = ValueUtil.tolong(SessionFilterUtil.getSsid(request));

        request.setAttribute(CURRENT_SHORT_ID_ATTR_KEY, shortId);
        request.setAttribute(CURRENT_STORE_ATTR_KEY, SessionStoreDb.getSessionStore(ssid, shortId));
    }

    /**
     * 現リクエストでのセッションストアを返す。
     * 
     * @param request
     * @return
     */
    public static SessionStoreBean getCurrentSessionStore(HttpServletRequest request) {
        return (SessionStoreBean) request.getAttribute(CURRENT_STORE_ATTR_KEY);
    }

    /**
     * セッションストアに属性を設定する。
     * 
     * @param request
     * @param key
     * @param data
     * @throws SQLException
     */
    public static void setAttribute(HttpServletRequest request, String keyName, Object store) throws SQLException {
        setAttribute(request, keyName, store, null);
    }

    /**
     * セッションストアに属性を設定する。
     * 
     * @param request
     * @param key
     * @param data
     * @throws SQLException
     */
    public static void setAttribute(HttpServletRequest request, String keyName, Object store, String scope)
            throws SQLException {

        // 設定する値が空の場合は削除する。
        if (store == null) {
            removeAttribute(request, keyName);
            return;
        }

        if (scope == null) {
            scope = SessionStoreBean.SCOPE_SHORT;
        }

        long ssid = ValueUtil.tolong(SessionFilterUtil.getSsid(request));
        String shortId = getCurrentShortId(request);
        SessionStoreBean sessionStore = getCurrentSessionStore(request);
        if (sessionStore == null) {
            throw new SQLException("カレントセッションが存在しません。 sstag type=\"start_session\" を書き忘れていないか、ご確認ください。");
        }
        if (shortId == null) {
            throw new SQLException("書き込み先が存在しません。 sstag type=\"end_session\" 記述後は、ショートセッションへの更新処理は行えません。");
        }

        if (!isExist(request, keyName)) {
            long gsid = ValueUtil.tolong(SessionFilterUtil.getGsid(request));
            long guid = ValueUtil.tolong(SessionFilterUtil.getGuid(request));
            int siteId = SiteMstDb.getInstance().getSiteId(request.getRequestURL().toString());
            SessionStoreDb.insert(ssid, shortId, gsid, guid, keyName, store, siteId, scope);
        } else {
            SessionStoreDb.update(ssid, shortId, keyName, store);
        }

        sessionStore.set(keyName, store, scope);
    }

    /**
     * セッションストアから属性を取得する。
     * 
     * @param request
     * @param key
     * @param type
     * @return
     * @throws SQLException
     */
    public static Object getAttribute(HttpServletRequest request, String keyName) throws SQLException {
        SessionStoreBean sessionStore = getCurrentSessionStore(request);
        if (sessionStore == null) {
            throw new SQLException("カレントセッションが存在しません。 sstag type=\"start_session\" を書き忘れていないか、ご確認ください。");
        }
        return sessionStore.get(keyName);
    }

    /**
     * セッションストアから指定された接頭辞で始まるキー値を持つ全ての属性を返す。
     * 
     * @param request
     * @param prefix
     * @return
     * @throws SQLException
     */
    public static Map<String, Object> getAllAttribute(HttpServletRequest request, String prefix) throws SQLException {
        SessionStoreBean sessionStore = getCurrentSessionStore(request);
        if (sessionStore == null) {
            throw new SQLException("カレントセッションが存在しません。 sstag type=\"start_session\" を書き忘れていないか、ご確認ください。");
        }
        return sessionStore.getAll(prefix);
    }

    /**
     * セッションストアに属性が存在しているかを返す。
     * 
     * @param request
     * @param keyName
     * @return
     * @throws SQLException
     */
    public static boolean isExist(HttpServletRequest request, String keyName) throws SQLException {
        SessionStoreBean sessionStore = getCurrentSessionStore(request);
        if (sessionStore == null) {
            throw new SQLException("カレントセッションが存在しません。 sstag type=\"start_session\" を書き忘れていないか、ご確認ください。");
        }
        return sessionStore.isExist(keyName);
    }

    /**
     * セッションストアから属性を削除する。
     * 
     * @param request
     * @param keyName
     * @throws SQLException
     */
    public static void removeAttribute(HttpServletRequest request, String keyName) throws SQLException {

        long ssid = ValueUtil.tolong(SessionFilterUtil.getSsid(request));
        String shortId = getCurrentShortId(request);
        SessionStoreBean sessionStore = getCurrentSessionStore(request);
        if (sessionStore == null) {
            throw new SQLException("カレントセッションが存在しません。 sstag type=\"start_session\" を書き忘れていないか、ご確認ください。");
        }
        if (shortId == null) {
            throw new SQLException("書き込み先が存在しません。 sstag type=\"end_session\" 記述後は、ショートセッションへの更新処理は行えません。");
        }

        SessionStoreDb.delete(ssid, shortId, keyName);
        sessionStore.remove(keyName);
    }

    /**
     * セッションストアから属性をすべて削除する。
     * 
     * @param request
     * @param shortId
     * @throws SQLException
     */
    public static void removeAllAttribute(HttpServletRequest request, String shortId) throws SQLException {
        long ssid = ValueUtil.tolong(SessionFilterUtil.getSsid(request));
        SessionStoreDb.deleteAll(ssid, shortId);

        if (PhoenixUtil.isEmpty(shortId) || shortId.equals(getCurrentShortId(request))) {
            // dbから削除した場合は、これ以降dbへの更新ができないように、
            // カレントのショートIDを削除しておく。
            // 参照はできるようにするため、メモリ上のショートセッション情報自体は残しておく。
            request.removeAttribute(CURRENT_SHORT_ID_ATTR_KEY);
        }
    }

    /**
     * どのスコープに格納されているかを返す。
     * 
     * @param request
     * @param keyName
     * @return
     * @throws SQLException
     */
    public static String getScope(HttpServletRequest request, String keyName) throws SQLException {
        SessionStoreBean sessionStore = getCurrentSessionStore(request);
        if (sessionStore == null) {
            throw new SQLException("カレントセッションが存在しません。 sstag type=\"start_session\" を書き忘れていないか、ご確認ください。");
        }

        return sessionStore.getScope(keyName);
    }

    /**
     * 現ショートセッションのIDを返す。
     * 
     * @param request
     * @return
     */
    public static String getCurrentShortId(HttpServletRequest request) {
        return (String) request.getAttribute(CURRENT_SHORT_ID_ATTR_KEY);
    }
}
