package jp.co.webcrew.filters.batch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.DBConnectionException;
import jp.co.webcrew.dbaccess.util.Logger;

/**
 * 各batchクラスの基底クラス。
 * 
 * @author kurinami
 */
abstract public class BaseBatch {

	/** ロガー */
	private static final Logger log = Logger.getLogger(BaseBatch.class);

	/**
	 * 新しいコネクションを作成する。
	 * 
	 * @param jdbcDriver
	 * @param url
	 * @param username
	 * @param password
	 * @return
	 * @throws DBConnectionException
	 */
	private Connection getConnection(String jdbcDriver, String url,
			String username, String password) throws DBConnectionException {

		log.info("newConnection  DB接続作成 [jdbcDriver: " + jdbcDriver
				+ "]  [url: " + url + "]  [username: " + username
				+ "]  [password: " + password + "]");

		try {
			Class.forName(jdbcDriver);
			return DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			log.error("DB接続エラー", e);
			throw new DBConnectionException();
		}
	}

	/**
	 * バッチ処理を開始する。
	 * 
	 * @param argv
	 */
	protected void batch(String[] argv) {

		try {

			// 起動パラメータの数をチェックする。
			if (argv.length != 4) {
				throw new Exception("引数の数が不正です。");
			}

			// 起動パラメータを受け取る。
			String jdbcDriver = argv[0];
			String url = argv[1];
			String username = argv[2];
			String password = argv[3];

			Connection con = getConnection(jdbcDriver, url, username, password);
			DBAccess dbAccess = new DBAccess(con);
			execute(dbAccess);

		} catch (Throwable t) {
			log.error("", t);
		}

	}

	/**
	 * 不要になった会員マスタを削除する。
	 * 
	 * @param dbAccess
	 * @throws SQLException
	 */
	abstract protected void execute(DBAccess dbAccess) throws SQLException;

}
