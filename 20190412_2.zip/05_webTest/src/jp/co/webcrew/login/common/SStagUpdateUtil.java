/**
 * 
 */
package jp.co.webcrew.login.common;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.MailTemplateUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;
import jp.co.webcrew.login.common.db.SystemProperties;
import jp.co.webcrew.login.common.db.step.StepUserInfo;
import jp.co.webcrew.login.common.db.step.StepUserInfoFactory;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.util.DateUtil;
import jp.co.webcrew.login.common.util.SessionFilterAlterUtil;
import jp.co.webcrew.login.common.util.StepMelmagaUtil;

/**
 * <pre>
 * sstag 経由でユーザ情報を更新するクラス。
 * </pre>
 * @author Takahashi
 *
 */
public class SStagUpdateUtil {

    /** ロガー */
    private static final Logger log = Logger.getLogger(SStagRegistUtil.class);
    
    /**
     * <pre>
     * ユーザ情報を更新する。
     *                                                               内部コード 戻り値
     * 1) ユーザ情報更新とメール送信が両方とも成功した場合              0        TRUE
     * 2) ユーザ情報更新のDB処理が成功し、メール送信が失敗した場合      1        TRUE
     * 3) ユーザ情報に変化がなく、order_histだけ更新した場合            2        TRUE
     * 4) ロジカルエラーによって更新処理ができなかった場合             -1        FALSE
     * 5) ユーザ（メールアドレス）が本登録ユーザではなかった場合       -2        FALSE
     * 6) システム系のエラーによって更新処理ができなかった場合         -3        FALSE
     *  
     * </pre>
     * @param guid         必須 本登録済みのguid
     * @param email        必須 sstag.email    
     * @param site_id      必須 sstag.site_id  
     * @param order_id          sstag.order_id
     * @param user_id           sstag.user_id
     * @param mobile_flag       true=携帯端末 false=携帯以外
     */
    public static int updateUserReturnInt ( 
            String guid,
            String email,
            String site_id,
            String order_id,
            String user_id,
            boolean mobile_flag
      ) {

      // ---- 引数チェック
        
        log.info("ユーザ情報更新処理を開始します。");

        if (! SessionFilterAlterUtil.isValidGuid(guid) ) {
            log.error("guidが不正です。ユーザ情報更新処理を中止します。guid=" + guid);
            return -1;
        }

        if (email == null || email.equals("")) {
            log.error("emailが指定されていません。ユーザ情報更新処理を中止します。guid=" + guid);
            return -1;
        }

        if (site_id == null || site_id.equals("")) {
            log.error("site_idが指定されていません。ユーザ情報更新処理を中止します。guid=" + guid);
            return -1;
        }

        DBAccess db = null;

        try{
            // データベースに接続する
            db = new DBAccess();
            db.setAutoCommit(false);

          // ---- ユーザが更新可能かどうかをチェックする

            // siteIdを元にstepに登録されたユーザ情報をDBから読み込む
            StepUserInfo stepuser = getStepUserInfo(db, site_id, order_id, user_id);
            if (stepuser == null) {
                log.info("stepUserInfoの生成に失敗しました。処理を中止します。");
                return -1;
            }
           
            MemberMst member = new MemberMst(guid);
            OrderHist order = new OrderHist(guid);
            
            //既にレコードが存在する場合、データを読み込む
            if (! member.existsRecord(db)){
                log.info("MEMBER_MSTのユーザ情報読み込みに失敗したため、ユーザ情報更新処理をスキップします。guid=" + guid);
                return -1;         
            }
            log.info("MEMBER_MSTのユーザ情報を読み込みます");
            if (! member.load(db)){
                log.info("MEMBER_MSTのユーザ情報読み込みに失敗したため、ユーザ情報更新処理をスキップします。guid=" + guid);
                return -1;         
            }
            
            // 更新対象のguidと、Member_MSTのguidを比較する
            // Tomcatの不具合等によりPKを指定しても別のユーザを読み込むなどの事故から被害を防止するため
            
            String memberMstGuid = ValueUtil.nullToStr(member.get(MemberMst.GUID));
            
            if (! guid.equals(memberMstGuid)){
                log.info("更新対象のguidと、読み込んだMEMBER_MSTのguidが異なるため、更新処理をスキップします。");
                log.info("current_guid=" + guid + " , memberMstGuid=" + memberMstGuid);
                return -1;         
            }
            // 更新対象のguidとstepの対象ユーザguidとが異なっていた場合、処理を中断する
            if (! isSameGuid(guid , stepuser.getGuid())){
                log.info("更新対象のguidと、読み込んだstepのUSER_INFO.GUIDが異なるため、更新処理をスキップします。");
                return -1;         
            }
            
            // 本登録ユーザでなければ更新中止
            if (! member.isHontouroku()) {
                log.info("本登録ユーザではありません。更新処理を中止します。guid=" + guid);
                return -1;         
            }

          // ---- 更新対象のguidが本登録済みかつstepにも登録済みである場合、order履歴をコピー

            log.info("stepのorder記録を認証サーバに転送します");
            // オーダー情報をコピー
            stepuser.doPopulateToOrderHist(order);
            // オーダー情報を書き込み
            OrderHist.insertToDB(db , order);
            
          // ---- ユーザ情報に変化が無い場合、処理を終える

            // stepのユーザ情報と、認証サーバのユーザ情報を比較する
            log.info("stepで入力したユーザ情報と認証サーバのユーザ情報を比較します");
            if(! stepuser.doIsDifferentFromMemberMst(member)){
                log.info("ユーザ情報が変わらないため、ユーザ情報更新処理をスキップします");
                db.commit(); //オーダー情報だけ書き込む
                 return 2; //処理は成功している         
            }
             
          // ---- ユーザ情報に変化が検出された場合、データベースを更新する
            
            stepuser.doPopulateToMemberMst(member);
            
            updateMember(db,member);
            
            log.info("メルマガ管理テーブルを更新");
            // メルマガ統合対応、処理場所はMemberRegistExecuterに移しました
            // StepMelmagaUtil.updateMelmagaFlg(db , guid , site_id , stepuser.getMagFlag() , stepuser.getMagEmail());
            db.commit(); 
            
            log.info("ユーザ情報更新のデータベース処理が正常終了しました");
            
          // ---- データベースに成功したら、通知メールを送信する
            
            log.info("ユーザ情報更新通知をメール送付します");
            boolean sent = sendMail(email, member) ;
            if (sent == true) {
                return 0;
            } else {
                log.warn("ユーザ情報更新通知メールの送信に失敗しました。guid=" + guid + ", email=" + email);
                return 1;
            }
            
        } catch (SQLException e){
            db.rollback();
            log.error("ユーザ登録中にデータベースエラーが発生しました。",e);
            return -1; 
        } catch (Exception e){
            db.rollback();
            log.error("ユーザ登録中に予期せぬエラーが発生しました。",e);
            return -3; 
             
        } finally {
            DBAccess.close(db);
        }
             
    }

    
    /**
     * <pre>
     * ユーザ情報を更新する。
     *                                                               内部コード 戻り値
     * 1) ユーザ情報更新とメール送信が両方とも成功した場合              0        TRUE
     * 2) ユーザ情報更新のDB処理が成功し、メール送信が失敗した場合      1        TRUE
     * 3) ユーザ情報に変化がなく、order_histだけ更新した場合            2        TRUE
     * 4) ロジカルエラーによって更新処理ができなかった場合             -1        FALSE
     * 5) ユーザ（メールアドレス）が本登録ユーザではなかった場合       -2        FALSE
     * 6) システム系のエラーによって更新処理ができなかった場合         -3        FALSE
     * 
     * </pre>
     * @param guid         必須 ログイン済みのguid
     * @param email        必須 sstag.email    
     * @param site_id      必須 sstag.site_id  
     * @param order_id          sstag.order_id
     * @param user_id           sstag.user_id
     * @param mobile_flag       true=携帯端末 false=携帯以外
     * @return
     */
    public static boolean updateUser ( 
            String guid,
            String email,
            String site_id,
            String order_id,
            String user_id,
            boolean mobile_flag
      ) {

        int status = updateUserReturnInt( guid,
                email,
                site_id,
                order_id,
                user_id,
                mobile_flag
             );
        
        log.info("member update guid=" + guid + ", status = " + status);
        if( status >= 0 ) { 
            return true;
        } else { 
            return false;
        }
    
    }
    

    /**
     * <pre>
     * MEMBER_MST のデータを更新する。
     * </pre>
     * @param db
     * @param member
     * @throws SQLException
     */
    private static void updateMember(DBAccess db , MemberMst member) throws SQLException{

        /*
         * af_flgやpromo_codeなどを上書きしないよう注意する
         * 
         * email , cp_mail , mb_mail は上書きしない
         * 
         * 値が入っている場合のみ更新する。
         * 
         * （既存のデータを消すことはできない）
         * 
         * 強制上書きする列がある場合は　overWriteUnconditionally を使用する
         * 
         * 
         * 
         * cop_flag は初期登録値から触らないこととし、更新対象からはずした
         * 
         * 
         */
        
        DBUpdater updater = new DBUpdater(MemberMst.TABLE);
        
        overWriteIfExistsValues  (updater , member , MemberMst.NAME1);
        overWriteIfExistsValues  (updater , member , MemberMst.NAME2);
        overWriteIfExistsValues  (updater , member , MemberMst.FURI1);
        overWriteIfExistsValues  (updater , member , MemberMst.FURI2);
        overWriteIfExistsValues  (updater , member , MemberMst.ZIP);
        overWriteIfExistsValues  (updater , member , MemberMst.PREF_ID);
        overWriteIfExistsValues  (updater , member , MemberMst.ADDR1);
        overWriteIfExistsValues  (updater , member , MemberMst.ADDR2);
        overWriteIfExistsValues  (updater , member , MemberMst.ADDR3);
        overWriteIfExistsValues  (updater , member , MemberMst.ADDR4);
        overWriteIfExistsValues  (updater , member , MemberMst.ADDR5);
        overWriteIfExistsValues  (updater , member , MemberMst.BIRTHDAY);
        overWriteIfExistsValues  (updater , member , MemberMst.SEX_ID);
        
        overWriteIfExistsValues  (updater , member , MemberMst.TEL);
        overWriteIfExistsValues  (updater , member , MemberMst.MOBILE);
        overWriteIfExistsValues  (updater , member , MemberMst.COMPANY);
        overWriteIfExistsValues  (updater , member , MemberMst.CP_TEL);
        overWriteIfExistsValues  (updater , member , MemberMst.CP_ZIP);
        overWriteIfExistsValues  (updater , member , MemberMst.CP_PREF_ID);
        overWriteIfExistsValues  (updater , member , MemberMst.CP_ADDR1);
        overWriteIfExistsValues  (updater , member , MemberMst.CP_ADDR2);
        overWriteIfExistsValues  (updater , member , MemberMst.CP_ADDR3);
        overWriteIfExistsValues  (updater , member , MemberMst.CP_ADDR4);
        overWriteIfExistsValues  (updater , member , MemberMst.CP_ADDR5);
        // Issue0039056より　生活情報項目追加
        overWriteIfExistsValues  (updater , member , MemberMst.HOUSE_TYPE_ID);
        overWriteIfExistsValues  (updater , member , MemberMst.SUMAI_KEITAI_CODE);
        overWriteIfExistsValues  (updater , member , MemberMst.CAR_MAKER_NAME_DISP);
        overWriteIfExistsValues  (updater , member , MemberMst.CAR_SHASHU_NAME_DISP);
        overWriteIfExistsValues  (updater , member , MemberMst.CAR_KATASHIKI_NAME);
        overWriteIfExistsValues  (updater , member , MemberMst.SHODO_TOROKU_NENGETSU);
        overWriteIfExistsValues  (updater , member , MemberMst.HAVE_BIKE);

        overWriteUnconditionally (updater , MemberMst.UP_DATETIME , DateUtil.currentDateTime());

        updater.setCond("WHERE GUID=?");
        updater.addCondString(member.get(MemberMst.GUID));
        
        updater.update(db);
        
    }

    /**
     * <pre>
     * updater（テーブル更新用のオブジェクト）に対し、
     * 会員オブジェクトの中に列名に該当するデータが入っていた場合のみ、
     * updaterの列の値を更新する。
     * </pre>
     * @param updater
     * @param member     会員オブジェクト
     * @param columnName MEMBER_MSTの列名
     */
    private static void overWriteIfExistsValues (DBUpdater updater , MemberMst member , String columnName ) {
        String new_val = ValueUtil.nullToStr(member.get(columnName));
        if (! new_val.equals("")) {
            updater.addString(columnName, new_val);
        } else {
            // 何もしない
        }
    }
    
    /**
     * <pre>
     * updater（データベース更新用のオブジェクト）において、列の値を無条件に指定した値で上書きする。
     * </pre>
     * @param updater
     * @param columnName
     * @param val
     */
    private static void overWriteUnconditionally (DBUpdater updater , String columnName , String val) {
        updater.addString(columnName, val);
    }
   

    /**
     * <pre>
     * カレントのGUIDと、Step-DBの対象GUID（多くの場合はUSER_INFO.GUID) が同一ならtrue
     * 
     * そうでない場合はfalse
     * 
     * 引数のguid値がnullなどの不正値だった場合もfalse
     * 
     * </pre>
     * 
     * @param currentGuid
     * @param stepUserGuid
     * @return
     */
    private static boolean isSameGuid(String currentGuid , String stepUserGuid) {
  
        // currentGuidが不正ならfalse
        if (! SessionFilterAlterUtil.isValidGuid(currentGuid)){
            log.info("currentGuidが不正です。currentGuid=" + currentGuid);
            return false;
        }

        // ステップDBのUSER_INFO.GUIDとcurrentGuidが合致しない場合はfalse
        if (! ValueUtil.nullToStr(stepUserGuid).equals(currentGuid)) {
            log.info("currentGuid=" + currentGuid + " , stepUserGuid=" + stepUserGuid);
            return false;
        }
      
        return true;
    }

    /**
     * <pre>
     * ステップサイトで登録したユーザ情報などをデータベース
     * （STEP.USER_INFO,ORDER_INFO）から取得する。
     * 
     * </pre>
     * @param db
     * @param site_id
     * @param order_id
     * @param user_id
     * @return
     */
    private static StepUserInfo getStepUserInfo(DBAccess db , String site_id , String order_id , String user_id){ 

        StepUserInfo userinfo = StepUserInfoFactory.createStepUserInfo(null , site_id);
        
        if (userinfo == null) {
            log.error("ステップ側のクラス生成に失敗しました。siteId=" + site_id);
            return null;
        }
        
        try {
            if (! userinfo.doLoad(db , order_id , user_id) ) {
                
                // ユーザ情報が取得できない場合、エラーとする
                log.error("ステップ側のユーザ情報読み込みに失敗したか、情報が見つかりませんでした。");
                return null;

            }
            
            return userinfo;
            
        } catch (SQLException e) {
            log.error("ステップ側のユーザ情報読み込み時に、データベースエラーが発生しました。" , e);
            e.printStackTrace();
            return null;
        }        
    }

    /**
     * <pre>
     * 【メール送信処理共通化用】
     * ユーザ情報更新通知メールを送信する
     * 
     * 引数のうち、from はシステムプロパティの指定が可能($$で囲む)
     * 
     * 送信処理に成功したらtrue、失敗したらfalseを返す。
     * 
     * （falseなら確実に失敗していると思われるが、trueであっても、
     * 本当にメールが送信できたかどうかは分からない）
     * 
     * </pre>
     * 
     * @param mailto      本登録ユーザのメールアドレス(=本登録通知メールの宛先)。必須。SSTAGのパラメータから取得したEMAIL
     * @param member      本登録通知メールの送信者情報。null不可。
     * 
     */
    public static boolean sendMail(String strMailTo, MemberMst objMemberMst)
	{
		log.info ("ユーザ情報更新通知メールを送信します。");

		/*
		 * 送信処理開始
		 */
		DBAccess db = null;
		try
		{
			db = new DBAccess();

			// システムプロパティを取得
			SystemProperties props = new SystemProperties(db);

			// メールテンプレートを準備する
			MailTemplateUtil objMailTemplate = new MailTemplateUtil(MailTemplateUtil.SSTAG_UPDATE_MAIL_TEMPLATE_ID);
			if (! objMailTemplate.load(db)) {
				log.error("メールテンプレート" + MailTemplateUtil.SSTAG_UPDATE_MAIL_TEMPLATE_ID + " の読み込みに失敗しました。");
				return false;
			}

			// 送信元メールアドレスを取得
			String strMailFrom = getMailSender (objMailTemplate, props, null);
			if (strMailFrom == null)
			{
				log.error("メール送信者(from)の解釈に失敗しました。メール送信を中断します。");
				return false;
			}

			//パスワードを取得
			String passwd = objMemberMst.get(MemberMst.PASSWD);
			
			//メール送信情報を設定する
			MailInfo objMailInfo = new MailInfo();
			objMailInfo.setMailTo(strMailTo);
			objMailInfo.setMailFrom(strMailFrom);
			objMailInfo.setMobileFlag(MailTemplateUtil.isMobileEmail(db, strMailTo));
			objMailInfo.setSiteId(objMemberMst.get(MemberMst.SITE_ID));
			
			//タイトルへの変数の埋め込み
			MailSubject objMailSubject = new MailSubject(objMemberMst);

			//ボディへの変数の埋め込み
			MailBody objMailBody = new MailBody(objMemberMst);
			objMailBody.setEmail(strMailTo);
			objMailBody.setAuthPass(passwd);
			objMailBody.setLoginPass(passwd);
			objMailBody.setPassword(passwd);
			objMailBody.setPass(passwd);
			objMailBody.setEncodeEmail(strMailTo);
			objMailBody.setMypageReminderUrl(props, SystemProperties.MYPAGE_REMINDER_TOP);
			objMailBody.setMypageDeleteMemberUrl(props, SystemProperties.MYPAGE_DEL_MEMBER_TOP, strMailTo, passwd);
			objMailBody.setMypageAuthUrl(props, SystemProperties.MYPAGE_LOGIN_TOP, strMailTo, passwd);
			objMailBody.setMypageLoginUrl(props, SystemProperties.MYPAGE_LOGIN_TOP, strMailTo, passwd);
			
			//変数の置き換えと、メール送信を行う
			return objMailTemplate.doReplaceAndMail(objMailSubject, objMailBody, objMailInfo);
		}
		catch (Exception e)
		{
			log.error("メール送信中に例外エラーが発生しました。" , e);
			return false;
		}
		finally
		{
			DBAccess.close(db);
		}
	}

    /**
     * <pre>
     * 【メール送信処理共通化用】
     * メール送信者を取得する
     * </pre>
     * @param template
     * @param props
     * @param from
     * @return
     */
    private static String getMailSender(MailTemplateUtil template , SystemProperties props , String from) {

        if (props == null) {
            log.error("システムプロパティオブジェクトがnullです。呼び出しが不正です。");
            return null;
        }

        String sender = "";

        if (template != null) {
            sender  = ValueUtil.nullToStr(template.getFrom());  // メールテンプレートのfromを最優先とする
        }

        if (sender.equals("")) {
            // メールテンプレートから送信者を取得できなかった場合、指定されたfromを使用する
            sender = ValueUtil.nullToStr (from);
        }
        
        if (sender.equals("")) {
            // メールテンプレートにも指定が無い場合、デフォルト値を使う
            log.warn("MAIL_TEMPLテーブルにfromが指定されていないため、システムプロパティからデフォルト値を取得します。");
            sender = ValueUtil.nullToStr(props.get("MAIL_SENDER_OF_REGIST"));
        }
        
        if (! sender.equals("")) {
            return sender;
        } else {
            return null;
        }

    }   
}
