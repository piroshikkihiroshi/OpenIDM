package jp.co.webcrew.common.util.proc;

import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;


public class XMLStringUtils {
    private static char[] entitiesIn = {
            '\'', '<', '>', '"', '&', 0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 14, 15,
            16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31
        };
    private static String[] entitiesOut = {
            "&apos;", "&lt;", "&gt;", "&quot;", "&amp;", "&amp;#0;", "&amp;#1;",
            "&amp;#2;", "&amp;#3;", "&amp;#4;", "&amp;#5;", "&amp;#6;",
            "&amp;#7;", "&amp;#8;", "&amp;#11;", "&amp;#12;", "&amp;#14;",
            "&amp;#15;", "&amp;#16;", "&amp;#17;", "&amp;#18;", "&amp;#19;",
            "&amp;#20;", "&amp;#21;", "&amp;#22;", "&amp;#23;", "&amp;#24;",
            "&amp;#25;", "&amp;#26;", "&amp;#27;", "&amp;#28;", "&amp;#29;",
            "&amp;#30;", "&amp;#31;"
        };

    //private static DocumentBuilderFactory builderFactory;
    public static String entityReplace(String input) {
        if (input == null) {
            return null;
        }

        for (int n = 0; n < entitiesIn.length; n++) {
            int pos = input.indexOf(entitiesIn[n]);

            if (pos != -1) {
                return entityReplace(input.substring(0, pos)) + entitiesOut[n] +
                entityReplace(input.substring(pos + 1));
            }
        }

        return input;
    }

    public static String element(String tagName, Object value, Map attributes,
        boolean escapeContents) {
        StringBuffer out = new StringBuffer();
        String escapedTagName = entityReplace(tagName);
        out.append('<').append(escapedTagName);

        if (attributes != null) {
            for (Iterator i = attributes.keySet().iterator(); i.hasNext();) {
                String key = (String) i.next();
                out.append(" ").append(entityReplace(key)).append("=\"").append(entityReplace(
                        (String) attributes.get(key))).append("\"");
            }
        }

        if (value == null) {
            out.append("/>");
        } else {
            out.append('>')
               .append(escapeContents ? entityReplace(value + "") : (value +
                "")).append("</").append(escapedTagName).append('>');
        }

        return out.toString();
    }
    
    public static Document parseXML(String inputXML) {
        try {
            // Use JAXP to create a document builder
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setExpandEntityReferences(false);
            builderFactory.setValidating(false);
            builderFactory.setNamespaceAware(false);
            builderFactory.setIgnoringComments(true);
            builderFactory.setCoalescing(true);
            builderFactory.setIgnoringElementContentWhitespace(true);

            DocumentBuilder builder = builderFactory.newDocumentBuilder();

            // Get the XML as an input stream
            Reader input = new StringReader(inputXML);

            return builder.parse(new InputSource(input));
        } catch (Throwable err) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            err.printStackTrace(pw);
            throw new RuntimeException("Error - could not parseXML." +
                "\nStacktrace: " + sw.toString());
        }
    }

}
