package jp.co.webcrew.loader.util;

import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import jp.co.webcrew.loader.db.ClassRepositoryDb;
import jp.co.webcrew.loader.loader.LoadManager;

/**
 * webアプリでクラスのロードを行うためのutilクラス。
 * 
 * @author kurinami
 */
public class LoadUtil {

    /** アプリスコープ 属性名 */
    private static final String LOADER_ATTR_KEY = "phoenix.loader";

    /**
     * マネージャを初期化して、アプリスコープに格納する。
     * 
     * @param servletContext
     * @throws ServletException
     */
    public static synchronized void init(ServletContext servletContext) throws ServletException {
        LoadManager manager = getManager(servletContext);
        if (manager == null) {
            manager = new LoadManager(servletContext, true);
            setManager(servletContext, manager);
        }
    }

    /**
     * アプリスコープに格納されているマネージャを元に、クラスをインスタンス化する。
     * 
     * @param request
     * @param className
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws ClassNotFoundException
     */
    public static Object newInstance(HttpServletRequest request, String className) throws InstantiationException,
            IllegalAccessException, ClassNotFoundException {
        return newInstance(request.getSession().getServletContext(), className);
    }

    /**
     * アプリスコープに格納されているマネージャを元に、クラスをインスタンス化する。
     * 
     * @param servletContext
     * @param className
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws ClassNotFoundException
     */
    public static Object newInstance(ServletContext servletContext, String className) throws InstantiationException,
            IllegalAccessException, ClassNotFoundException {
        LoadManager manager = getManager(servletContext);
        return manager.newInstance(className);
    }

    /**
     * ロジックIDをもとにクラスをインスタンス化する。
     * 
     * @param request
     * @param logicId
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws ClassNotFoundException
     */
    public static Object newInstanceFromId(HttpServletRequest request, String logicId) throws InstantiationException,
            IllegalAccessException, ClassNotFoundException {

        try {
            String className = ClassRepositoryDb.getClassName(logicId);
            if (className.length() == 0) {
                throw new ClassNotFoundException("logic_id[" + logicId + "]に対応したクラスが存在しません。");
            }
            return newInstance(request, className);
        } catch (SQLException e) {
            throw new ClassNotFoundException("クラス名取得エラー", e);
        }

    }

    /**
     * sstagのtype名をもとにクラスをインスタンス化する。
     * 
     * @param request
     * @param type
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws ClassNotFoundException
     */
    public static Object newInstanceFromSstag(HttpServletRequest request, String type) throws InstantiationException,
            IllegalAccessException, ClassNotFoundException {

        try {
            String className = ClassRepositoryDb.getClassName(ClassRepositoryDb.PURPOSE_SSTAG, type);
            if (className.length() == 0) {
                throw new ClassNotFoundException("type[" + type + "]に対応したクラスが存在しません。");
            }
            return newInstance(request, className);
        } catch (SQLException e) {
            throw new ClassNotFoundException("クラス名取得エラー", e);
        }

    }

    /**
     * アプリスコープに格納されているマネージャンを返す。
     * 
     * @param servletContext
     * @return
     */
    private static LoadManager getManager(ServletContext servletContext) {
        return (LoadManager) servletContext.getAttribute(LOADER_ATTR_KEY);
    }

    /**
     * アプリスコープにマネージャを格納する。
     * 
     * @param servletContext
     * @param manager
     */
    private static void setManager(ServletContext servletContext, LoadManager manager) {
        servletContext.setAttribute(LOADER_ATTR_KEY, manager);
    }

}
