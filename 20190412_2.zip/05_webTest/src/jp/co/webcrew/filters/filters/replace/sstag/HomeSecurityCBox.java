package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.util.phoenix.PhoenixHomeSecurityUtil;
import jp.co.webcrew.filters.util.phoenix.RowData;


/**
 * 各ステップにてホームセキュリティ用のCBOXをsstag
 * 
 */
public class HomeSecurityCBox extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(HomeSecurityCBox.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

		DBAccess  db = null;
		ResultSet rs = null;
		
        try {
        	List compList = new ArrayList();
        	
        	db = new DBAccess();
        	
        	//都道府県ID
        	String prefId = ValueUtil.nullToStr(parameters.get("pref_id"));
        	//郵便番号
        	String zip    = ValueUtil.nullToStr(parameters.get("zip"));
        	//リターン用HTMLテンプレート
        	String htmlTemplate = ValueUtil.nullToStr(parameters.get("html_template"));
        	
        	if (prefId.equals("") || htmlTemplate.equals("")) {
        		throw new IllegalArgumentException("必須パラメータが指定されておりません。");
        	}
        	
        	//スクリーニングを実行し、対象の会社リストを取得する。
        	compList = PhoenixHomeSecurityUtil.returnCompanyList(db, zip, prefId);
        	

        	
        	
        	StringBuffer bf = new StringBuffer();
        	
        	//対象会社が存在しない場合
        	if (compList == null || compList.size() == 0) {
        		bf.append("<b>対象の地域に対応する会社は存在しませんでした。</b>");
        	}
        	
            //出力用HTMLの作成
        	Iterator iter = compList.iterator();        	
        	while (iter.hasNext()) {
        		String tmp = htmlTemplate;
        		
        		RowData compRow = (RowData)iter.next();
        		//会社名を変換
        		tmp = tmp.replaceAll("%%comp_name%%", compRow.get("company_name"));
        		//会社IDを変換
        		tmp = tmp.replaceAll("%%comp_id%%", compRow.get("company_id"));
        		
        		bf.append(tmp);
        	}
        	
        	return bf.toString();
        } catch (Exception e) {
			log.error("予期せぬエラー", e);
			return "";
		} finally {
			DBAccess.close(rs);
			DBAccess.close(db);
		}
	}
	
	
}
