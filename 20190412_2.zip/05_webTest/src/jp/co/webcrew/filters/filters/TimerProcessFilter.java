package jp.co.webcrew.filters.filters;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;

public class TimerProcessFilter implements Filter {

    private static final Logger log = Logger.getLogger(TimerProcessFilter.class);
    
    /**
     * 固有処理実行開始時間
     */
    private int fromHour;
    
    /**
     * 固有処理実行終了時間
     */    
    private int toHour;
    
    /**
     * リダイレクト先のURL
     */
    private String redirectUrl;
    
    /**
     * 現在時間が指定された時間の範囲内かどうかをチェックし、範囲内であれば指定された処理を実行する。
     */
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
        
        Calendar cal = Calendar.getInstance();
        int currentHour = cal.get(Calendar.HOUR_OF_DAY);
        
        if (currentHour >= fromHour && currentHour < toHour) {
            log.info("指定時間内なので、指定URLへリダイレクトします。");
            try {
                ((HttpServletResponse)response).sendRedirect(redirectUrl);
                return;
            } catch(Exception e) {
                e.printStackTrace();
                log.error("TimeProcessFilterのリダイレト処理でエラーが発生しました。", e);
            }
        }
        chain.doFilter(request, response);
    }

    /**
     * init処理。
     * コンテキストから、initパラメータを取得する。
     */
    public void init(FilterConfig config) throws ServletException {
        fromHour = new Integer(config.getInitParameter("fromHour")).intValue();
        toHour = new Integer(config.getInitParameter("toHour")).intValue();
        redirectUrl = config.getInitParameter("redirectUrl");
    }

    public void destroy() {
        // TODO Auto-generated method stub
    }
}
