package jp.co.webcrew.login.common.db;

import java.io.Serializable;
import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.login.common.db.util.DBEntity;
import jp.co.webcrew.login.common.db.util.DBUpdater;
import jp.co.webcrew.login.common.db.util.Record;

/**
 * SITE_CROSS_CAMPAIGN テーブルを扱うクラス
 * 
 * @author fu
 * 
 */
public class SiteCrossCampaign extends DBEntity implements Serializable {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    /** ロガー */
    private static final Logger log = Logger.getLogger(SiteCrossCampaign.class);

    public static final String TABLE = "SITE_CROSS_CAMPAIGN";

    /*
     * 列名定義
     */
    public static final String AUTH_KEY = "AUTH_KEY";
    public static final String ORDER_ID = "ORDER_ID";
    public static final String SITE_ID = "SITE_ID";
    public static final String GUID = "GUID";
    public static final String EMAIL = "EMAIL";
    public static final String APP_KIND = "APP_KIND";
    public static final String APP_FLG = "APP_FLG";
    public static final String LOT_TYPE = "LOT_TYPE";
    public static final String ALTERNATIVE_LOT_TYPE = "ALTERNATIVE_LOT_TYPE";
    public static final String APP_DATETIME = "APP_DATETIME"; // 応募日時（応募前はNULL）
    public static final String MK_DATETIME = "MK_DATETIME";
    public static final String UP_DATETIME = "UP_DATETIME";
    public static final String CAMPAIGN_ID = "CAMPAIGN_ID";

    /** 応募種別ID 0：初期値（登録の際） */
    public static final String APP_KIND_DEFAULT = "0"; // 初期値（登録の際）
    // 更新
    /** 応募種別ID 1：当り（更新の際） */
    public static final String APP_KIND_SUCCESS = "1"; // 当り
    /** 応募種別ID 2：外れ（更新の際） */
    public static final String APP_KIND_FAILURE = "2"; // 外れ

    // 応募フラグ
    /** 応募フラグ 0：初期値（登録の際） */
    public static final String APP_FLG_DEFAULT = "0"; // 初期値（登録の際）
    /** 応募フラグ 1：応募完了（更新の際） */
    public static final String APP_FLG_DONE = "1"; // 応募完了（更新の際）

    // AC条件サイトアタリ出目
    /** アタリ出目 0：初期値（登録の際） */
    public static final String LOT_TYPE_DEFAULT = "0"; // 初期値（登録の際）
    // 更新
    /** アタリ出目 1：巨大タラバガニ（更新の際） */
    public static final String LOT_TYPE_1 = "1"; // 巨大タラバガニ
    /** アタリ出目 2：新巻鮭　銀毛（更新の際） */
    public static final String LOT_TYPE_2 = "2"; // 新巻鮭　銀毛

    // お楽しみ賞アタリ出目
    /** アタリ出目 0：初期値（登録の際） */
    public static final String ALTERNATIVE_LOT_TYPE_DEFAULT = "0"; // 初期値（登録の際）
    // 更新
    /** アタリ出目 1：醤油いくら（更新の際） */
    public static final String ALTERNATIVE_LOT_TYPE_1 = "1"; // 醤油いくら
    /** アタリ出目 2：真ほっけ（更新の際） */
    public static final String ALTERNATIVE_LOT_TYPE_2 = "2"; // 真ほっけ
    /** アタリ出目 3：いか中（更新の際） */
    public static final String ALTERNATIVE_LOT_TYPE_3 = "3"; // いか中

    private static final String SELECT_SITE_CROSS_CAMPAIGN_MST = ""
      + "SELECT max_hit_number FROM tonashiba.site_cross_campaign_mst WHERE campaign_id = ?";
    private static final String SELECT_SITE_CROSS_CAMPAIGN_COUNT = ""
      + "SELECT count(1) as cnt FROM tonashiba.site_cross_campaign WHERE campaign_id = ? AND app_kind = ?";
    private static final String SELECT_CAMPAIGN_PERIOD = ""
      + "SELECT start_date, end_date FROM tonashiba.site_cross_campaign_mst WHERE campaign_id = ?";
    
    /*
     * (non-Javadoc)
     * 
     * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
     */
    public void init() {
        setTable(TABLE);
    }

    /**
     * コンストラクタ
     */
    public SiteCrossCampaign() {
        super();
    }

    /**
     * <pre>
     * 
     * SITE_CROSS_CAMPAIGNテーブルの主キーを元に一行データを取得する。
     * 
     * SITE_CROSS_CAMPAIGNを返す。
     * 
     * null : エラー
     * null : 処理中止（引数がNULLの場合など）
     * SiteCrossCampaign : 成功
     * 
     * </pre>
     * 
     * @param authKey
     * @param orderId
     * @param siteId
     * @return SiteCrossCampaign
     */
    public static SiteCrossCampaign getSiteCrossCampaign(String authKey, String orderId) {

        DBAccess db = null;

        try {

            db = new DBAccess();
            return getSiteCrossCampaign(db, authKey, orderId);

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function SiteCrossCampaign#getSiteCrossCampaign", e);
            return null;

        } finally {
            DBAccess.close(db);
        }
    }

    /**
     * <pre>
     * 
     * SITE_CROSS_CAMPAIGNテーブルの主キーを元に一行データを取得する。
     * 
     * SITE_CROSS_CAMPAIGNを返す。
     * 
     * null : エラー
     * null : 処理中止（引数がNULLの場合など）
     * SiteCrossCampaign : 成功
     * 
     * </pre>
     * 
     * @param db
     * @param authKey
     * @param orderId
     * @param siteId
     * @return SiteCrossCampaign
     */
    public static SiteCrossCampaign getSiteCrossCampaign(DBAccess db, String authKey, String orderId) {

        SiteCrossCampaign siteCrossCampaign = null;
        // パラメータチェック
        if (db == null || authKey == null || orderId == null) {
            return null;
        }
        if (authKey.length() == 0 || orderId.length() == 0) {
            return null;
        }

        try {

            // 検索SQL文を作成する
            StringBuffer sqlBuf = new StringBuffer();
            sqlBuf.append("SELECT ").append(TABLE).append(".* FROM ").append(TABLE);
            sqlBuf.append(" WHERE ").append(AUTH_KEY).append(" = '").append(authKey).append("'");
            sqlBuf.append(" AND ").append(ORDER_ID).append(" = '").append(orderId).append("'");

            // PreparedStatementを作成する
            db.prepareStatement(sqlBuf.toString());

            // 最初のレコードを取得する
            Record rec = Record.getFirstRowOf(db);
            if (rec == null) {
                log.info(TABLE + "の情報を読み込めませんでした。");
                return null;
            } else {
                siteCrossCampaign = new SiteCrossCampaign();
                siteCrossCampaign.set(AUTH_KEY, rec.getString(AUTH_KEY));
                siteCrossCampaign.set(ORDER_ID, rec.getString(ORDER_ID));
                siteCrossCampaign.set(SITE_ID, rec.getString(SITE_ID));
                siteCrossCampaign.set(GUID, rec.getString(GUID));
                siteCrossCampaign.set(EMAIL, rec.getString(EMAIL));
                siteCrossCampaign.set(APP_KIND, rec.getString(APP_KIND));
                siteCrossCampaign.set(APP_FLG, rec.getString(APP_FLG));
                siteCrossCampaign.set(LOT_TYPE, rec.getString(LOT_TYPE));
                siteCrossCampaign.set(ALTERNATIVE_LOT_TYPE, rec.getString(ALTERNATIVE_LOT_TYPE));
                siteCrossCampaign.set(APP_DATETIME, rec.getString(APP_DATETIME));
                siteCrossCampaign.set(MK_DATETIME, rec.getString(MK_DATETIME));
                siteCrossCampaign.set(UP_DATETIME, rec.getString(UP_DATETIME));
                siteCrossCampaign.set(CAMPAIGN_ID, rec.getString(CAMPAIGN_ID));
            }

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function SiteCrossCampaign#getSiteCrossCampaign", e);
            return null;
        }

        return siteCrossCampaign;
    }
    
    
    /**
     * <pre>
     * 
     * SITE_CROSS_CAMPAIGNテーブルに一行作成する。
     * 
     * 作成した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param campaign
     * @return 登録したレコード数
     */
    public static int insertToDB(SiteCrossCampaign campaign) {

        if (campaign == null) {
            return -1;
        }

        DBAccess db = null;
        try {

            db = new DBAccess();

            return SiteCrossCampaign.insertToDB(db, campaign);

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function SiteCrossCampaign#insertToDB", e);
            return -1;

        } finally {
            DBAccess.close(db);
        }

    }

    /**
     * <pre>
     * 
     * SITE_CROSS_CAMPAIGNテーブルに一行作成する。
     * 
     * 作成した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param db
     * @param campaign
     * @return 登録したレコード数
     */
    public static int insertToDB(DBAccess db, SiteCrossCampaign campaign) {

        if (db == null) {
            return -1;
        }

        if (campaign == null) {
            return -1;
        }

        try {

            return insert(db, campaign);

        } catch (SQLException e) {
            switch (e.getErrorCode()) {
            case 1:
                // ORA-00001: unique constraint (TONASHIBA.PK_SITE_CROSS_CAMPAIGN) violated
                log.info(TABLE + " テーブルに重複登録しようとしています。");
                return -1;
            default:
                log.error(TABLE + " テーブルに書き込み中に例外エラーが発生しました。Error in function SiteCrossCampaign#insertToDB", e);
                return -1;
            }
        } catch (Exception e) {
            log.error(TABLE + " テーブルに書き込み中に例外エラーが発生しました。Error in function SiteCrossCampaign#insertToDB", e);
            return -1;
        }

    }

    /**
     * <pre>
     * 
     * SITE_CROSS_CAMPAIGNテーブルに一行更新する。
     * 
     * 更新した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param campaign
     * @return 更新したレコード数
     */
    public static int updateToDB(SiteCrossCampaign campaign) {

        if (campaign == null) {
            return -1;
        }

        DBAccess db = null;
        try {

            db = new DBAccess();

            return SiteCrossCampaign.updateToDB(db, campaign);

        } catch (Exception e) {
            log.error("例外エラーが発生しました。Error in function SiteCrossCampaign#updateToDB", e);
            return -1;

        } finally {
            DBAccess.close(db);
        }

    }

    /**
     * <pre>
     * 
     * SITE_CROSS_CAMPAIGNテーブルに一行更新する。
     * 
     * 更新した行数を返す。
     * 
     * -1 : エラー
     * -1 : 処理中止（引数がNULLの場合など）
     *  1 : 成功
     * 
     * </pre>
     * 
     * @param db
     * @param campaign
     * @return 更新したレコード数
     */
    public static int updateToDB(DBAccess db, SiteCrossCampaign campaign) {

        if (db == null) {
            return -1;
        }

        if (campaign == null) {
            return -1;
        }

        try {
            DBUpdater updater = new DBUpdater(TABLE);

            // 更新対象
            // updater.addString(GUID, campaign.get(GUID));
            // updater.addString(EMAIL, campaign.get(EMAIL));
            updater.addString(APP_KIND, campaign.get(APP_KIND));
            updater.addString(APP_FLG, campaign.get(APP_FLG));
            updater.addString(LOT_TYPE, campaign.get(LOT_TYPE));
            updater.addString(ALTERNATIVE_LOT_TYPE, campaign.get(ALTERNATIVE_LOT_TYPE));
            updater.addString(APP_DATETIME, campaign.get(APP_DATETIME));
            updater.addString(UP_DATETIME, campaign.get(UP_DATETIME));

            // 主キー
            //updater.setCond("WHERE AUTH_KEY=? AND ORDER_ID=? AND SITE_ID=?");
            updater.setCond("WHERE AUTH_KEY=? AND ORDER_ID=?");
            updater.addCondString(campaign.get(AUTH_KEY));
            updater.addCondString(campaign.get(ORDER_ID));
            //updater.addCondString(campaign.get(SITE_ID));
            return updater.update(db);

        } catch (Exception e) {
            log.error(TABLE + " テーブルに書き込み中に例外エラーが発生しました。Error in function SiteCrossCampaign#updateToDB", e);
            return -1;
        }

    }

    /**
     * 指定したキャンペーンIDの最大当選者数を取得する
     * 
     * @param campaignId
     * @return
     */
    public static int getMaxHitNumber(String campaignId)
    {
        DBAccess db = null;
        try
        {
            db = new DBAccess();
            
            db.prepareStatement(SELECT_SITE_CROSS_CAMPAIGN_MST);
            db.setInt(1, Integer.parseInt(campaignId));
            
            Record rec = Record.getFirstRowOf(db);
            if (rec == null)
            {
                log.info("site_cross_campaign.max_hit_numberを取得出来ませんでした。campaign_id=" + campaignId);
                return 0;
            }
            else
            {
                return rec.getInt("max_hit_number");
            }
        }
        catch(Exception e)
        {
            log.error("site_cross_campaign_mstテーブル検索処理で例外が発生しました。", e);
            return -1;
        }
        finally
        {
            DBAccess.close(db);
        }
    }
    
    /**
     * 当選者数/落選者数を取得する
     * 
     * @param campaignId
     * @param appKind
     * @return
     */
    public static int getNumber(String campaignId, String appKind)
    {
        DBAccess db = null;
        
        try
        {
            db = new DBAccess();
            
            db.prepareStatement(SELECT_SITE_CROSS_CAMPAIGN_COUNT);
            db.setInt(1, Integer.parseInt(campaignId));
            db.setInt(2, Integer.parseInt(appKind));
            
            Record rec = Record.getFirstRowOf(db);
            if (rec == null)
            {
                log.info("site_cross_campaign_mst.max_hit_numberを取得出来ませんでした。");
                return -1;
            }
            else
            {
                return rec.getInt("cnt");
            }
        }
        catch(Exception e)
        {
            log.error("site_cross_campaignテーブル検索処理で例外が発生しました。", e);
            return -1;
        }
        finally
        {
            
        }
    }
    
    /**
     * キャンペーン期間を取得する
     * 開始:終了=YYYYMMDDHH24MISS:YYYYMMDDHH24MISS
     * 
     * @param campaignId
     * @return
     */
    public static String getPeriod(String campaignId)
    {
    	DBAccess db = null;
      
      try
      {
          db = new DBAccess();
          
          db.prepareStatement(SELECT_CAMPAIGN_PERIOD);
          db.setInt(1, Integer.parseInt(campaignId));
          
          Record rec = Record.getFirstRowOf(db);
          if (rec == null)
          {
              log.info("site_cross_campaign_mst.start_date/end_dateを取得出来ませんでした。");
              return "";
          }
          else
          {
              String strStart = ValueUtil.nullToStr(rec.getString("start_date"));
              String strEnd   = ValueUtil.nullToStr(rec.getString("end_date"));
              
              if (strStart.equals("") || strEnd.equals(""))
              {
                  log.error("キャンペーン開始日または終了日が設定されていません。設定を確認して下さい。start_date=" + strStart + " end_date=" + strEnd);
                  return "";
              }
              
              return strStart + ":" + strEnd;
          }
      }
      catch(Exception e)
      {
          log.error("site_cross_campaignテーブル検索処理で例外が発生しました。", e);
          return "";
      }
      finally
      {
          
      }
    }
}
