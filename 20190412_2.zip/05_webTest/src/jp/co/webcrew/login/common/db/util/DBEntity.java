package jp.co.webcrew.login.common.db.util;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;

public abstract class DBEntity implements RecordHandler{

	/** データベース文字コード */
	public static final String DB_ENCODING = "UTF-8"; 
	
	/** ロガー */
	private static Logger log = Logger.getLogger(DBEntity.class);

	/** 定数 テーブル名 */
	public static final String TABLE = ""; 

	/** DBデータ一行を保持 */
	private Map _record ;

	/** スキーマ名 */
	private String _schema; 

	/** テーブル名 */
	private String _tableName; 

	/** テーブル情報 */
	private TableInfo _tableinfo;
	
	/** プライマリキー */
	private List _pkColumns = new ArrayList();
	
	/** その他の列 */
	private List _columns = new ArrayList();

	protected void setTable(String val){
		_tableName = val;
	}
	protected void setSchema(String val){
		_schema = val;
	}
	
	public static void addPK(String columnName){
		
	}

	/**
	 * <pre>
	 * 次の二つのメソッドを呼び出すこと
	 *	setSchema([EntityClassName.]SCHEMA);
	 *	setTable([EntityClassName.]TABLE);
	 * </pre>
	 */ 
	public abstract void init();
	
	
	/**
	 * テーブル名を取得する
	 * @return String テーブル名
	 */
 	public final String getFullTableName(){
		return DBInfo.getFullTableName(getSchema() , getTableName());
	}

 	public final String getSchema(){
 		return _schema;
 	}

 	public final String getTableName(){
 		return _tableName;
 	}
	

	/**
	 * コンストラクタ
	 */
	public DBEntity(){
		init();
		_pkColumns = DBInfo.getPkColumns(getFullTableName());
		_columns = DBInfo.getColumns(getFullTableName());
		_tableinfo = DBInfo.getTableInfo(getFullTableName());
	}
	

	/**
	 * PKに値がセットされているか否か
	 * @return true セットされている
	 * @return false セットされていないキーがある
	 */
	public boolean isSetPK() {

		List pk = getPkColumns();
		for (int i = 0 ; i < pk.size(); i++) {
			String key = (String)pk.get(i);
			String val = get(key);
			if (val.equals("")) {
				return false;
			}
		}
		
		return true;
		
	}
	
	/**
	 * INSERT文を生成する
	 * @return String INSERT-SQL文
	 */
	private String makeInsertSql(){
		StringBuffer buf = new StringBuffer();
		buf.append("INSERT INTO ");
		buf.append(getFullTableName());
		buf.append(" (");
		for (int i = 0 ; i < _pkColumns.size(); i++){
			String columnName = (String)_pkColumns.get(i);
			buf.append(columnName);
			buf.append(",");
		}
		for (int i = 0 ; i < _columns.size(); i++){
			String columnName = (String)_columns.get(i);
			if (i != 0) {
				buf.append(",");
			}
			buf.append(" ");
			buf.append(columnName);
		}
		buf.append(") VALUES (");
		for (int i = 0 ; i < _pkColumns.size(); i++){
			buf.append("?,");
		}
		for (int i = 0 ; i < _columns.size(); i++){
			if (i != 0) {
				buf.append(",");
			}
			buf.append("?");
		}
		buf.append(") ");
		
		return buf.toString();
	}
	
	/**
	 * PKの列名を取得する
	 * @return
	 */
	public  List getPkColumns(){
		return _pkColumns;
	}
	
	/**
	 * PK以外の列名を取得する
	 * @return
	 */
	public List getColumns(){
		return _columns;
	}
	
	/**
	 * テーブルオブジェクトに応じてDBのテーブルに一行挿入する
	 * @param db DBアクセサ
	 * @param entity テーブルオブジェクト
	 * @return int 更新行数
	 * @throws SQLException データベースエラーが発生した時
	 */
	public static int insert(DBAccess db , DBEntity entity)  throws SQLException{
		try{
			db.prepareStatement(entity.makeInsertSql());
			List pkColumns = entity.getPkColumns();
			List columns = entity.getColumns();
			int pk_num = pkColumns.size();
			for (int i = 0 ; i < pk_num ; i++) {
				String columnName = (String)pkColumns.get(i);
//				db.setString((i + 1), entity.get(columnName) );
				Object val = entity.getObject(columnName);
				if ( val == null) {
					db.setNull(i + 1);
				} else {
					db.setObject((i + 1), entity.getObject(columnName) );
				}
			}
			for (int i = 0 ; i < columns.size(); i++) {
				String columnName = (String)columns.get(i);
//				db.setObject((i + 1 + pk_num ), entity.getObject(columnName) );
				Object val = entity.getObject(columnName);
				if ( val == null) {
					db.setNull(i + 1 + pk_num );
				} else {
					db.setObject((i + 1 + pk_num ), entity.getObject(columnName) );
				}

			}

			return db.executeUpdate();
		} finally {
			
		}
	}
	
	/**
	 * オブジェクトの中身をDBのテーブルに一行挿入する
	 * @param db DBアクセサ
	 * @return int 更新行数
	 * @throws SQLException エラーが発生した時
	 * @deprecated SQLもしくはDBInserterの使用を推奨
	 */
	public int insertDB(DBAccess db) throws SQLException{
		return insert(db,this);
	}

	/**
	 * データ抽出用のSELECT文を生成する
	 * @return String SELECT文
	 */
	public String makeSelectSql(){
		StringBuffer buf = new StringBuffer();
		buf.append("select * from ");
		buf.append(getFullTableName());
		List pk = getPkColumns();
		if (pk.size() > 0) {
			buf.append(" where ");
		}
		
		for (int i = 0 ; i < pk.size() ; i++){
			if (i != 0) {
				buf.append(",");
			}
			buf.append((String)pk.get(i));
			buf.append("=?");
		}
		return buf.toString();
	}
	
//	public boolean load(DBAccess db , String email) throws SQLException{
//		//TODO Takahashi 実装
//		return false;
//	}
	
	/**
	 * データベースからデータを一行読み込む
	 * PKが指定されていない場合は全件のうち最初の一行を読み込む
	 * @param db
	 * @return true 一行読み込みに成功した時
	 * @return false 読み込みに失敗した時
	 * @throws SQLException
	 */
	public boolean load(DBAccess db) throws SQLException{
		log.info("start load()");

		// PK情報を元にSQLを生成
		String sql = makeSelectSql();
		try{
			db.prepareStatement(sql);
			List pk = getPkColumns();
			for (int i = 0 ; i < pk.size() ; i++){
				String column = (String)pk.get(i);
				db.setString(i + 1, get(column));
			}

			Record rec = Record.getFirstRowOf(db);
			if (rec == null) {
				log.info(getFullTableName() + "の情報を読み込めませんでした。");
				return false;
			} else {
				this._record = rec;
			}
			
		} catch(SQLException e){
			// 例外エラー
			log.error("DBエラーが発生しました。",e);
			throw e;
			
		} finally {
			;
		}
		return true;
	}

	/**
	 * @deprecated DBUpdaterを使う
	 */
	public String makeUpdateSql() {
		StringBuffer buf = new StringBuffer();
		buf.append("UPDATE ");
		buf.append(getFullTableName());
		buf.append(" SET ");
		List columns = getColumns();
		for (int i = 0 ; i < columns.size(); i++){
			String columnName = (String)columns.get(i);
			if (i != 0) {
				buf.append(",");
			}
			buf.append(" ");
			buf.append(columnName);
			buf.append("=? ");
		}
		buf.append("\n");
		buf.append("WHERE \n ");
		
		List pk = getPkColumns();
		for (int i = 0 ; i < pk.size() ; i++){
			if (i != 0) {
				buf.append(",");
			}
			buf.append((String)pk.get(i));
			buf.append("=?");
		}
		
		return buf.toString();
	}
	
	/**
	 * レコードが存在するか否かを調べる
	 * @param db
	 * @return true 存在する
	 * @return false 存在しない
	 * @throws SQLException
	 */
	public boolean existsRecord(DBAccess db) throws SQLException{
		// PK情報を元にSQLを生成
		String sql = makeSelectSql();
		try{
			db.prepareStatement(sql);
			List pk = getPkColumns();
			for (int i = 0 ; i < pk.size() ; i++){
				String column = (String)pk.get(i);
				db.setString(i + 1, get(column));
			}

			Record rec = Record.getFirstRowOf(db);
			if (rec == null) {
				return false;
			} else {
				return true;
			}
			
		} catch(SQLException e){
			// 例外エラー
			log.error("DBエラーが発生しました。",e);
			throw e;
			
		} finally {
			;
		}
	}
	
	/**
	 * 列名に該当する値を取得する
	 * @param columnName 列名
	 * @return String 値
	 */
	public String get(String columnName){
		return ((Record)getRecord()).getString(columnName);
	}
	
	/**
	 * 列名に該当する値を取得する
	 * @param columnName 列名
	 * @return String 値
	 */
	public Object getObject (String columnName){
		return getRecord().get(columnName);
	}
    
    /**
     * 列名に該当する値を取得する
     * @param columnName 列名
     * @return String 値
     */
    public void setObject (String columnName , Object val){
        ((Record)getRecord()).setValue(columnName , val);
    }    

	/**
	 * 値をセットする
	 * @param columnName 列名
	 * @param value 値
	 */
	public void set(String columnName , String value){
		getRecord().put(columnName , value);
	}

	/**
	 * 値をセットする
	 * @param columnName 列名
	 * @param value 値
	 */
	public void put(String columnName , String value){
		set(columnName,value);
	}
	
	/**
	 * 数値をセットする
	 * @param columnName 列名
	 * @param value 値
	 * @throws NumberFormatException
	 */
	public void setBigDecimal (String columnName , String value){
		if (value == null || value.equals("")) {
			getRecord().put(columnName , "");			
		} else {
			BigDecimal d = new BigDecimal(value);
			getRecord().put(columnName , d);
		}
	}
	
	
	/**
	 * DB定義のサイズに合わせて値を強制的に切り詰めてセットする
	 * @param columnName 列名
	 * @param val 値
	 */
	public void setTrimData(String columnName , String val){
		val = rtrim(val , columnName);
		getRecord().put(columnName , val);
	}
	
	/**
	 * 行データを取得する
	 * @return Map 行データ
	 */
	private Map getRecord(){
		if (this._record == null) {
			this._record = new Record();
			return _record;
		} else {
			return this._record; 
		}
	}

	/**
	 * DBエンコーディングを返す。
	 * @return String エンコーディング
	 */
	public String getDBEncoding(){
		// 文字コードはDB_ENCODINGで指定すること。

		// TODO takahashi DB_ENCODINGはスキーマに依存すると見なし、TableInfoから可変に設定・取得できるようにする
		// return getTableInfo().getDbEncoding()

		// TODO takahashi 可能ならメタデータから自動的に取得する
		return DB_ENCODING;
	}
	
	/**
	 * シングルバイトの文字列のみで構成されているか否かを調べる
	 * @param str 対象文字列
	 * @return false 対象がnullの時
	 * @return false ダブルバイトの文字列が含まれる時
	 * @return true 対象が空文字列の時
	 * @return true ダブルバイトの文字列が一つも含まれない時
	 */
	public final boolean isSingleByte(String str){

		String encoding = getDBEncoding();
		if(str == null){
			return false;
		}
		if(str.equals("")){
			return true;
		}

		try{
			byte[] bytes = str.getBytes(encoding);
			int beams = str.length();
			if (beams == bytes.length) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			log.error("半角チェック中にエラーが発生しました。",e);
			return false;
		}
	}
	
	/**
	 * データの右側を、列データに応じて切り詰める。
	 * 列名から列サイズを求め、列サイズに応じてデータの右側を切る。
	 * 現在は、UTF-8でダブルバイト以上の文字が一つでも入っていたら
	 * 対象データを対象列サイズの1/3に縮めるというロジックを用いている
	 * @param val 対象の値
	 * @param columnName 列名
	 * @return
	 */
	public final String rtrim (String val , String columnName) {
		if (val == null) return null;

		int maxsize = getSizeOf(columnName);

		if (maxsize <= 0 ) {
			// サイズ制限なし
			return val;
		}

/*
 		int type = getTypeOf(columnName);
		if (type == java.sql.Types.NUMERIC) {
			BigDecimal d = new BigDecimal(val);
			String l = String.valueOf(d.longValue());
			
		}
*/
		if (!isSingleByte(val)) {
			// 日本語が入る場合、UTF-8なので1文字最大3バイトと換算する
			maxsize = maxsize / 3;
		}
		
		if ( val.length() > maxsize) {
			val = val.substring(0,maxsize);
		}
		
		return val;
	}
	
	/**
	 * テーブル情報を取得する
	 * @return TableInfo テーブル情報オブジェクト
	 */
	private TableInfo getTableInfo(){
		return _tableinfo;
	}
	
	/**
	 * 列の文字数（バイト数）を返す
	 * @param columnName 列名
	 * @return 0 制限なし
	 * @return int 列の最大文字列数
	 */
	public final int getSizeOf(String columnName) {
		ColumnInfo info = (ColumnInfo)getTableInfo().getColumnInfoHolder().get(columnName);
		if (info == null) {
			return 0;
		}
		
		int size = info.getColumnPrecision(); //TODO takahashi 小数点対応など
		
		return size;
	}

	/**
	 * 列の文字数（バイト数）を返す
	 * @param columnName 列名
	 * @return 0 制限なし
	 * @return int 列の最大文字列数
	 */
	public final int getTypeOf(String columnName) {
		ColumnInfo info = (ColumnInfo)getTableInfo().getColumnInfoHolder().get(columnName);
		if (info == null) {
			return java.sql.Types.OTHER;
		}
		
		return info.getColumnType();
	}
	/**
	 * INSERT文を生成する
	 * @return
	 */
	public static String makeInsertSql(TableInfo info , List pk , List columns){
		StringBuffer buf = new StringBuffer();
		buf.append("INSERT INTO ");
		buf.append(info.getFullTableName());
		buf.append(" (");
		for (int i = 0 ; i < pk.size(); i++){
			String columnName = (String)pk.get(i);
			buf.append(columnName);
			buf.append(",");
		}
		for (int i = 0 ; i < columns.size(); i++){
			String columnName = (String)columns.get(i);
			if (i != 0) {
				buf.append(",");
			}
			buf.append(" ");
			buf.append(columnName);
		}
		buf.append(") VALUES (");
		for (int i = 0 ; i < columns.size(); i++){
			buf.append("?,");
		}
		for (int i = 0 ; i < columns.size(); i++){
			if (i != 0) {
				buf.append(",");
			}
			buf.append("?");
		}
		buf.append(") ");
		
		return buf.toString();
	}
	
	public void populate(ResultSet rs) throws SQLException{
		Record rec = new Record(rs);
		setRecord(rec);
	}
	
	public void populate(Record rec) throws SQLException{
		setRecord(rec);
	}
	
	/**
	 * サブクラス以外の外部クラスからは変更不可とする
	 * @param record
	 */
	protected void setRecord(Record record) {
		_record = record;
	}
	
    public List getResultListOf(DBAccess db) throws SQLException{
    	List list = new ArrayList();
    	ResultSet rs = null;
		try{
			rs = db.executeQuery();
			while(rs.next()) {
				RecordHandler recordHandler = (RecordHandler)this.getClass().newInstance();
				recordHandler.populate(rs);
				list.add(recordHandler);
			}
		} catch(Exception e) {
			throw new DBException("レコード読み込みに失敗しました。");
		} finally {
			DBAccess.close(rs);
		}
		return list;
    }	

    public Timestamp getTimeStamp (String columnName) {
    	return ((Record)getRecord()).getTimestamp(columnName);
    }
    
    public void setTimeStamp (String columnName , Timestamp ts) {
        setObject(columnName, ts);
    }
 
//    public Date getDate (String columnName) {
//    	return ((Record)getRecord()).getDate(columnName);
//    }
//    import java.sql.Timestamp;
    public String getDateStr(String columnName) {
    	return ((Record)getRecord()).getDateStr(columnName);
     }

     public String getDateTimeStr(String columnName) {
     	return ((Record)getRecord()).getDateTimeStr(columnName);
     }
     
     /**
      * 内部保持しているデータを全て削除する
      *
      */
     public void clear() {
    	 Map rec = getRecord();
    	 
    	 if (rec != null) {
    		 rec.clear();
    	 }
     }
 
 	/**
 	 * 列名に対応するデータを、列サイズに切り落としてから取得する
 	 * @param columnName
 	 * @return
 	 */
 	public String trimGet(String columnName){
 		String val = get (columnName);
 		return rtrim(val, columnName);
 	}     
}
