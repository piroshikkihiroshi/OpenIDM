package jp.co.webcrew.login.common.util.twitter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import twitter4j.Tweet;

/**
 * つぶやきの表示内容を格納
 *
 * @author shintaro.kurihara
 *
 */
public class TweetBean implements Comparable{

	Tweet tweet = null; //Twitter4jのつぶやき保持クラス
	java.util.Date timeTweeted = null;
	String profileImageUrl = null;
	String tweetText = null;
	String screenName = null;
	long id = 0; //つぶやきID
	
	/**
	 * メインコンストラクタ
	 *
	 */
	public TweetBean(Tweet tweet){
		this.tweet = tweet;
		this.timeTweeted = tweet.getCreatedAt();
		this.profileImageUrl = this.tweet.getProfileImageUrl();
		this.tweetText =  this.tweet.getText();
		this.screenName =  this.tweet.getFromUser();
		this.id =  this.tweet.getId();
	}
	
	/**
	 * APIタイムラグ対応のための手動作成コンストラクタ
	 *
	 */
	public TweetBean(java.util.Date timeTweeted,String prifileImageURL,String tweetText,String screenName ){
		this.timeTweeted = timeTweeted;
		this.profileImageUrl = prifileImageURL;
		this.tweetText = tweetText;
		this.screenName =  screenName;
		this.id = 0;
	}
	
	/**
	 * デフォルトコンストラクタ
	 *
	 */
	public TweetBean(){	
	}

	
	/**
	 * @return tweet
	 */
	public Tweet getTweet() {
		return tweet;
	}
	
	/**
	 * @param tweet
	 */
	public void setTweet(Tweet tweet) {
		this.tweet = tweet;
	}
	
	/**
	 * @return timeTweeted
	 */
	public java.util.Date  getTimeTweeted() {
		return this.timeTweeted;
	}
	
	
	/**
	 * @param timeTweeted
	 */
	public void setTimeTweeted(java.util.Date timeTweeted) {
		this.timeTweeted = timeTweeted;
	}
	
	/**
	 * @return screenName
	 */
	public String getScreenName() {
		return screenName;
	}
	
	/**
	 * @param screenName
	 */
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	
	
	/**
	 * @return profileImageUrl
	 */
	public String getProfileImageURL(){
		return this.profileImageUrl;
	}
	
	/**
	 * @return tweetText
	 */
	public String getTweetText() throws Exception{
		return this.tweetText;
	}
	
	/**
	 * @param tweetText
	 */
	public void setTweetText(String tweetText) throws Exception{
		this.tweetText = tweetText;
	}
	
	/**
	 * @return id
	 */
	public long getTwitterID(){
		return this.id;
	}
	
	/**
	 *  自動入力テキストを除去して表示する
	 * 
	 *  @param twitterInfo
	 */
	public String geTweetText(AbstractTwitterInfo twitterInfo) throws Exception{
		//
		String text = this.tweetText.replaceAll(twitterInfo.getAutoTweetText(), "");
		text = text.trim();
		return text;
	}
	
	/**
	 *  自動挿入テキストからURLリンクだけを削除する
	 * 
	 *  @param twitterInfo
	 */
	public String geTweetTextWithoutUrl(AbstractTwitterInfo twitterInfo) throws Exception{
		
		String autoTweetdText = twitterInfo.getAutoTweetText();
		
		//URLリンクをマッチング
	    Pattern pattern = Pattern.compile("http[s]*.+");
	    Matcher matcher = pattern.matcher(autoTweetdText);
	    
	    String ablationText = "";

	    if(matcher.find()); ablationText = matcher.group();
		
	    //tweetから、URLリンクを除去
		String text = tweet.getText().replaceAll(ablationText, "");
		text = text.trim();
		return text;
	}
	
	
	/**
	 *  つぶやかれた時間を　表示用形式に変換して取得する
	 * 
	 *  @return String
	 */
	public String getFormatedDateStr(int elapsedTimeFormatID){
		return TwitterUtil.getStrFormatElapsedTimeDate(this.timeTweeted, elapsedTimeFormatID);
	}
	
	
	/**
	 *  sort条件指定
	 */
	public int compareTo(Object o){
		if(o instanceof TweetBean){
			TweetBean tweetBean = (TweetBean)o;
			return tweetBean.getTimeTweeted().compareTo(timeTweeted);
		}
		else{
			return 0;
		}
	}
	
}
