package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.mailmaga.MailMagaRegistForm;
import jp.co.webcrew.login.common.util.AppConstants;

/**
 * レコメンデーション用のExceuerクラス。
 * 
 * @author Amit Parmar
 */
public class MailMagaExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(MailMagaExecuter.class);
	
	private static final String HTML_TAG 			= "\\$\\$input\\$\\$";
	private static final String MESSAGE_TAG 		= "\\$\\$message\\$\\$";
	
	public String execute(Map mapParameters, HttpServletRequest objRequest, HttpServletResponse objResponse)
	{
		String strHtml = "";
		DBAccess db = null;
		try
		{
			// パラメータを取得
			strHtml = ValueUtil.nullToStr((String)mapParameters.get("html"));
			if (strHtml == null || "".equals(strHtml)) {
				throw new Exception("HTMLが無効です。");
			}
			
			String strSiteId = ValueUtil.nullToStr((String)mapParameters.get("siteid"));
			
			HttpSession session = objRequest.getSession(false);
	        if (session == null) 
	        {
	            log.info("セッションタイムアウトエラーが発生しました。");
	            throw new Exception("セッションタイムアウトエラーが発生しました。");
	        }
	        
			MailMagaRegistForm objMailMagaRegistForm = (MailMagaRegistForm)session.getAttribute(AppConstants.MAIL_MAGA_REGIST_FORM);
			if (objMailMagaRegistForm != null && objMailMagaRegistForm.isMessageFlag()) 
			{
				strHtml = strHtml.replaceAll(MESSAGE_TAG, objMailMagaRegistForm.getMessage());
				session.removeAttribute(AppConstants.MAIL_MAGA_REGIST_FORM);
			}
			else 
			{
				strHtml = strHtml.replaceAll(MESSAGE_TAG, "");
			}
			StringBuffer sbufHtml = new StringBuffer();
			// ログイン状態判断
			boolean blnLoginFlg = SessionFilterUtil.isLogined(objRequest);
			if (blnLoginFlg && AppConstants.SITE_ID_MYPAGE.equals(strSiteId)) {
				// GUIDを取得
				String strGuid = SessionFilterUtil.getGuid(objRequest);
				if(!SessionFilterUtil.isValidGuid(strGuid))	
				{
					log.info("GUIDが無効です。GUID=" + strGuid);
					throw new Exception("GUIDが無効です。GUID=" + strGuid);
				}
				
				// 会員マスタを格納する。
				db = new DBAccess();
				MemberMst objMemberMst = new MemberMst(strGuid);
				if (!objMemberMst.load(db))
				{
					log.info("メンバーマスタ情報を取得できませんでした。GUID=" + strGuid);
					throw new Exception("メンバーマスタ情報を取得できませんでした。GUID=" + strGuid);
				}
				
				if (objMemberMst != null )
				{
					List lstEmails = new ArrayList();
					sbufHtml.append("<select name=\"email\">");

					String strEmail = objMemberMst.get(MemberMst.EMAIL);
					if (strEmail != null && !"".equals(strEmail))
					{	
						lstEmails.add(strEmail);
						sbufHtml.append("<option value=\"" + strEmail + "\">").append(strEmail).append("</option>");
					}
					
					String strMbEmail = objMemberMst.get(MemberMst.MB_MAIL);
					if (strMbEmail != null && !"".equals(strMbEmail) && !lstEmails.contains(strMbEmail))
					{	
						lstEmails.add(strMbEmail);
						sbufHtml.append("<option value=\"" + strMbEmail + "\">").append(strMbEmail).append("</option>");
					}
					
					String strCpEmail = objMemberMst.get(MemberMst.CP_MAIL);
					if (strCpEmail != null && !"".equals(strCpEmail) && !lstEmails.contains(strCpEmail))
					{	
						sbufHtml.append("<option value=\"" + strCpEmail + "\">").append(strCpEmail).append("</option>");
					}
					sbufHtml.append("</select>");
				}	
			}	
			else 
			{
				sbufHtml.append("<input type=\"text\" name=\"email\" size=\"30\" maxlength=\"100\"");
			}
			
			strHtml = strHtml.replaceAll(HTML_TAG, sbufHtml.toString());

		}
		catch (Exception objExp)
		{
			log.error("予期せぬエラー", objExp);
			return "";
		}
		
		return strHtml;
	}
}
