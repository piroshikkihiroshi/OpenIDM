package jp.co.webcrew.phoenix.logic.bean;

import java.util.List;

/**
 * FORM情報保持用
 * 
 * @author kurinami
 */
public class FormInfo {
    public FormDef formDef;
    public List<FormItem> formItemList;
}
