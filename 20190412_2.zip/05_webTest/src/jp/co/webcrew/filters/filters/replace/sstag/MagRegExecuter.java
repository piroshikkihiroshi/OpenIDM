package jp.co.webcrew.filters.filters.replace.sstag;

import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.StepDb;
import jp.co.webcrew.filters.filters.session.UserInfo;
import jp.co.webcrew.filters.util.SessionFilterUtil;
import jp.co.webcrew.login.common.db.MemberMst;

/**
 * メルマガ登録を行うsstag
 * 
 * @author kurinami
 */
public class MagRegExecuter extends SSTagExecuter {

	/** ロガー */
	private static final Logger log = Logger.getLogger(MagRegExecuter.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java.util.Map,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public String execute(Map parameters, HttpServletRequest request,
			HttpServletResponse response) {

		try {
			String siteId = ValueUtil.nullToStr(parameters.get("site_id"));
			String email = ValueUtil.nullToStr(parameters.get("email"));
			String magId = ValueUtil.nullToStr(parameters.get("mag_id"));
			boolean loginRequiredFlag = !ValueUtil.nullToStr(
					parameters.get("login_required_flag")).equals("0");

			// --------------------------------------------------------------------------------
			// sstagのパラメータをチェックする。

			// サイトIDがパラメータで指定されなかった場合は、filterで保持するサイトIDを使用する。
			if (siteId.length() == 0) {
				siteId = (String) request
						.getAttribute(UserInfo.SITE_ID_ATTR_KEY);
			}

			// emailが指定されていない場合、
			if (email.length() == 0) {
				// パラメータエラーとする
				log.error("パラメータエラー パラメータ[email]が指定されていません。");
				return "";
			}

			String guid = "";

			if (loginRequiredFlag) {
				if (SessionFilterUtil.isLogined(request)) {
					// ログインしている場合、

					// カレントセッションのguidをそのまま使用する。
					guid = ValueUtil.nullToStr(request
							.getAttribute(UserInfo.GUID_ATTR_KEY));
				} else {
					// ログインしていない場合、
					// メルマガ登録しない。
				}
			} else {

				// emailを元にメンバマスタを検索する。
				guid = getGuidFromMemberMst(email);

				// メンバマスタからguidが見つからなかった場合、
				if (guid.length() == 0) {
					// メルマガ購読情報からguidを検索する。
					guid = StepDb.getGuid(email);
				}

				// メルマガ購読情報からguidが見つからなかった場合、
				if (guid.length() == 0) {
					// guidを"0"とする。
					guid = "0";
				}

			}

			if (guid.length() > 0) {

				if (magId.length() == 0) {
					log.info("サイトIDを元にメルマガ管理テーブルを更新 [site_id:" + siteId + "]");
					StepDb.updateMelmagaFlg(guid, email, siteId);
				} else {
					log.info("メルマガIDを元にメルマガ管理テーブルを更新 [mag_id:" + magId + "]");
					StepDb.insertMelmagaFlg(guid, email, magId.split(","));
				}

			}

		} catch (SQLException e) {
			log.error("DBエラー", e);
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
		}

		return "";
	}

	/**
	 * emailを元にメンバマスタを検索して、guidを返す。
	 * 
	 * @param email
	 * @return
	 * @throws SQLException
	 */
	private String getGuidFromMemberMst(String email) throws SQLException {

		DBAccess db = null;
		try {
			db = new DBAccess();
			MemberMst member = new MemberMst();
			if (member.load(db, email)) {
				return member.getGuid();
			} else {
				return "";
			}

		} finally {
			DBAccess.close(db);
		}

	}

}
