package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * コンバージョン発生条件を管理するdbクラス。
 * 
 * @author kurinami
 */
public class ConversionMstDb extends RefreshMstDb {

	/** コンバージョン発生条件一覧取得用SQL */
	private static final String CONVERSION_MST_SELECT = ""
			+ "select conv_mst.conv_id, "
			+ "       conv_mst.conv_name, "
			+ "       conv_mst.user_type, "
			+ "       conv_mst.repeat_flag, "
			+ "       conv_mst.same_day_flag, "
			+ "       conv_url_mst.conv_url_id, "
			+ "       conv_url_mst.url_type, "
			+ "       conv_url_mst.conv_url "
			+ "  from conv_mst inner join conv_url_mst on conv_mst.conv_id = conv_url_mst.conv_id "
			+ " where to_char(sysdate, 'YYYYMMDDHH24MISS') between conv_mst.bgn_datetime and conv_mst.end_datetime "
			+ " order by conv_mst.conv_id, conv_url_mst.conv_url_id";

	/** ユーザタイプ限定指定 ： 誰でもOK */
	public static final String USER_TYPE_ALL = "0";

	/** ユーザタイプ限定指定 ： 新規登録ユーザのみ */
	public static final String USER_TYPE_NEW = "1";

	/** ユーザタイプ限定指定 ： 既登録ユーザのみ */
	public static final String USER_TYPE_REGISTED = "2";

	/** 通過URLタイプ ： 未通過 */
	public static final String URL_TYPE_NONE = "0";

	/** 通過URLタイプ ： 成果達成URL */
	public static final String URL_TYPE_GOAL = "9";

	/** 唯一のインスタンス */
	private static ConversionMstDb conversionMstDb = new ConversionMstDb();

	/** コンバージョン発生条件の一覧 */
	private List conversionMstList = null;

	/** コンバージョンIDごとのURL_TYPEの一覧 */
	private Map urlTypeMap = null;

	/**
	 * 生成不能コンストラクタ
	 */
	private ConversionMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static ConversionMstDb getInstance() {
		return conversionMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			List conversionMstList = new ArrayList();
			Map urlTypeMap = new HashMap();

			// コンバージョン発生条件を検索する。
			rs = dbAccess.executeQuery(CONVERSION_MST_SELECT);
			while (dbAccess.next(rs)) {
				Integer convId = new Integer(rs.getInt("conv_id"));
				String urlType = ValueUtil.nullToStr(rs.getString("url_type"));

				// コンバージョン発生条件一覧に追加する。
				Map element = new HashMap();
				element.put("conv_id", convId);
				element.put("conv_name", ValueUtil.nullToStr(rs
						.getString("conv_name")));
				element.put("user_type", ValueUtil.nullToStr(rs
						.getString("user_type")));
				element.put("repeat_flag", new Boolean(ValueUtil.nullToStr(
						rs.getString("repeat_flag")).equals("1")));
				element.put("same_day_flag", new Boolean(ValueUtil.nullToStr(
						rs.getString("same_day_flag")).equals("1")));
				element.put("conv_url_id",
						new Integer(rs.getInt("conv_url_id")));
				element.put("url_type", urlType);
				element.put("conv_url", ValueUtil.nullToStr(rs
						.getString("conv_url")));

				conversionMstList.add(element);

				// コンバージョンIDごとのURL_TYPEの一覧に追加する。
				SortedSet urlTypeSet = (SortedSet) urlTypeMap.get(convId);
				if (urlTypeSet == null) {
					urlTypeSet = new TreeSet();
					urlTypeMap.put(convId, urlTypeSet);
				}
				urlTypeSet.add(urlType);

			}

			this.conversionMstList = conversionMstList;
			this.urlTypeMap = urlTypeMap;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * コンバージョン発生条件の一覧を返す。
	 * 
	 * @return
	 */
	public List getConversionMstList() {
		return conversionMstList;
	}

	/**
	 * 次通過するべきURL_TYPEを返す。
	 * 
	 * @param convId
	 * @param currentUrlType
	 * @return
	 */
	public String getNextUrlType(int convId, String currentUrlType) {

		SortedSet urlTypeSet = (SortedSet) urlTypeMap.get(new Integer(convId));

		// コンバージョンIDに対応するものがない場合、
		if (urlTypeSet == null) {
			return URL_TYPE_NONE;
		}

		Iterator i = urlTypeSet.iterator();

		if (!currentUrlType.equals(URL_TYPE_NONE)) {
			// 現在の経過状況が未通過でない場合、
			// 現在の経過状況まで一覧を進める。
			while (i.hasNext()) {
				String urlType = (String) i.next();
				if (urlType.equals(currentUrlType)) {
					break;
				}
			}
		}

		if (!i.hasNext()) {
			return URL_TYPE_NONE;
		}

		return (String) i.next();
	}

}
