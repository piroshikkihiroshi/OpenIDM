package jp.co.webcrew.filters.filters.replace.sstag;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * システムエラー制御用のExecuterクラス。
 * 
 * @author kurinami
 */
public class SystemErrorMsgExecuter extends SSTagExecuter {

    /** リクエスト属性名：エラーメッセージを表示するかしないかのフラグ */
    private static final String DISPLAY_FLAG_REQ_ATTR_KEY = "webcrew.replace_filter.sstag.display_flag";

    /** パラメータ名：エラーメッセージを表示するかしないかのフラグ */
    private static final String DISPLAY_PARAM_KEY = "display";

    /** システムエラーを表示する */
    private static final String DISPLAY_ON = "on";

    /** システムエラーを表示しない。 */
    private static final String DISPLAY_OFF = "off";

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        // パラメータの取得
        String display = ValueUtil.nullToStr(parameters.get(DISPLAY_PARAM_KEY)).toLowerCase();

        if (display.length() == 0) {
            return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + DISPLAY_PARAM_KEY + "]");
        }

        if (!display.equals(DISPLAY_ON) && !display.equals(DISPLAY_OFF)) {
            return onerror(request, response, parameters, "パラメータ[" + DISPLAY_PARAM_KEY + "]は" + DISPLAY_ON + "か"
                    + DISPLAY_OFF + "で指定してください。");
        }

        request.setAttribute(DISPLAY_FLAG_REQ_ATTR_KEY, display);
        return "";
    }

    /**
     * エラーメッセージを画面に表示するかを返す。
     * 
     * @param request
     * @return
     */
    public static boolean isDisplayOn(HttpServletRequest request) {
        return !ValueUtil.nullToStr(request.getAttribute(DISPLAY_FLAG_REQ_ATTR_KEY)).equals(DISPLAY_OFF);
    }

}
