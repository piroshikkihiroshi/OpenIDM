package jp.co.webcrew.phoenix.sstag.impl;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;
import jp.co.webcrew.filters.filters.replace.replacer.KeywordReplacer;
import jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter;
import jp.co.webcrew.phoenix.logic.bean.PostInfo;
import jp.co.webcrew.phoenix.sstag.bean.FormItemBean;
import jp.co.webcrew.phoenix.sstag.db.FormItemDb;
import jp.co.webcrew.phoenix.sstag.util.ClmMetaMstUtil;
import jp.co.webcrew.phoenix.sstag.util.SstagUtil;
import jp.co.webcrew.phoenix.sstag.util.StoreUtil;
import jp.co.webcrew.phoenix.util.PhoenixUtil;
import jp.co.webcrew.phoenix.vtable.bean.ClmDataBean;
import jp.co.webcrew.phoenix.vtable.bean.ConditionBean;
import jp.co.webcrew.phoenix.vtable.db.VDb;

/**
 * カレントレコード設定を行うためのsstagクラス。
 * 
 * @author kurinami
 */
public class RecordIdExecuter extends SSTagExecuter {

    /** パラメータ名：サイトID */
    private static final String SITE_ID_PARAM_KEY = "site_id";

    /** パラメータ名：対象テーブル */
    private static final String TABLE_ID_PARAM_KEY = "table_id";

    /** パラメータ名：カレントにしたいレコード番号 または "default" */
    private static final String RECORD_ID_PARAM_KEY = "record_id";

    /** パラメータ名：物理テーブルの場合の、特定レコードを示すキー */
    private static final String RECORD_KEY_PARAM_KEY = "record_key";

    /** パラメータ名：公開フラグと公開期間を無視して出力する指定 */
    private static final String IGNORE_PUBFLAG_PARAM_KEY = "ignore_pubflag";

    /** パラメータ名：カレントレコードがない時のリダイレクト先URL */
    private static final String NOT_FOUND_URL_PARAM_KEY = "not_found_url";

    /** パラメータ名：カレントレコードがない時に出力する HTML */
    private static final String NOT_FOUND_HTML_PARAM_KEY = "not_found_html";

    /** パラメータ名：カレントレコードが存在する時のリダイレクト先URL */
    private static final String FOUND_URL_PARAM_KEY = "found_url";

    /** パラメータ名：カレントレコードが存在する時に出力する HTML */
    private static final String FOUND_HTML_PARAM_KEY = "found_html";

    /** パラメータ名：フォームID */
    private static final String FORM_ID_PARAM_KEY = "form_id";

    /** パラメータ名：グループID */
    private static final String GROUP_ID_PARAM_KEY = "group_id";

    /** パラメータ名：含めない項目 */
    private static final String EXCLUDE_PARAM_KEY = "exclude";

    /** パラメータ名：フォーム項目に任意のテーブル項目を割り当てる */
    private static final String ITEM_MAP_PARAM_KEY = "item_map";

    /** パラメータ名：item_map 内の任意文字を示すマーカー */
    private static final String MARKER_PARAM_KEY = "marker";

    /** デフォルトの任意文字を示すマーカー */
    private static final String DEFAULT_MARKER = "'";

    /** ロガー */
    private static final Logger log = Logger.getLogger(RecordIdExecuter.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * jp.co.webcrew.filters.filters.replace.sstag.SSTagExecuter#execute(java
     * .util.Map, javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String execute(Map parameters, HttpServletRequest request, HttpServletResponse response) {

        try {

            String[] requires = { TABLE_ID_PARAM_KEY };
            List<String> errorList = SstagUtil.requireErrorList(parameters, requires);
            if (!PhoenixUtil.isEmpty(errorList)) {
                return onerror(request, response, parameters, "必須パラメータが指定されていません。[" + ValueUtil.concat(errorList, ",")
                        + "]");
            }

            // パラメータの取得
            int siteId = SstagUtil.getSiteId(parameters.get(SITE_ID_PARAM_KEY), request);
            String tableId = ValueUtil.nullToStr(parameters.get(TABLE_ID_PARAM_KEY));
            // TODO kurinami 【確認】 レコードIDのデフォルトってなんだ？
            String recordId = ValueUtil.nullToStr((String) parameters.get(RECORD_ID_PARAM_KEY));
            String recordKey = ValueUtil.nullToStr(parameters.get(RECORD_KEY_PARAM_KEY));
            boolean ignorePubflag = SstagUtil.getIgnorePubflag(request, (String) parameters
                    .get(IGNORE_PUBFLAG_PARAM_KEY));
            String notFoundUrl = ValueUtil.nullToStr(parameters.get(NOT_FOUND_URL_PARAM_KEY));
            String notFoundHtml = ValueUtil.nullToStr(parameters.get(NOT_FOUND_HTML_PARAM_KEY));
            String foundUrl = ValueUtil.nullToStr(parameters.get(FOUND_URL_PARAM_KEY));
            String foundHtml = ValueUtil.nullToStr(parameters.get(FOUND_HTML_PARAM_KEY));
            String formId = ValueUtil.nullToStr(parameters.get(FORM_ID_PARAM_KEY));
            String[] groupId = PhoenixUtil.split((String) parameters.get(GROUP_ID_PARAM_KEY), ",");
            String[] exclude = PhoenixUtil.split((String) parameters.get(EXCLUDE_PARAM_KEY), ",");
            String[][] itemMap = SstagUtil.splitItemMap((String) parameters.get(ITEM_MAP_PARAM_KEY));
            String marker = ValueUtil.nullToStr(parameters.get(MARKER_PARAM_KEY));

            // 任意文字を示すマーカーが指定されていない場合、
            if (PhoenixUtil.isEmpty(marker)) {
                // デフォルトを使用する。
                marker = DEFAULT_MARKER;
            }

            // 現在登録されているものをクリアしておく。
            String prefix = MessageFormat.format("cont.{0}.", tableId);
            KeywordReplacer.removeDynamicKeyword(request, prefix);

            // フォーム項目一覧を取得する。
            List<FormItemBean> formItemList = null;
            if (!PhoenixUtil.isEmpty(formId)) {
                formItemList = FormItemDb.getList(siteId, formId, groupId, null, exclude, null);
                if (PhoenixUtil.isEmpty(formItemList)) {
                    String message = MessageFormat.format("フォーム項目が存在しません。[{0}:{1}]", FORM_ID_PARAM_KEY, formId);
                    return onerror(request, response, parameters, message);
                }
            }

            // カレントレコードを読み込む。
            boolean res = readRecord(request, siteId, tableId, recordId, recordKey, formItemList, itemMap, marker,
                    ignorePubflag);
            if (res == false) {
                if (!PhoenixUtil.isEmpty(notFoundUrl)) {
                    response.sendRedirect(notFoundUrl);
                    return "";
                } else if (!PhoenixUtil.isEmpty(notFoundHtml)) {
                    return notFoundHtml;
                }
            } else {
                if (!PhoenixUtil.isEmpty(foundUrl)) {
                    response.sendRedirect(foundUrl);
                    return "";
                } else if (!PhoenixUtil.isEmpty(foundHtml)) {
                    return foundHtml;
                }
            }

            return "";

        } catch (Exception e) {
            log.error("予期せぬエラー", e);
            return onerror(request, response, parameters, e);
        }

    }

    /**
     * カレントレコードの読込
     * 
     * @param request
     * @param siteId
     * @param tableId
     * @param recordId
     * @param recordKey
     * @param formItemList
     * @param itemMap
     * @param marker
     * @param ignorePubflag
     * @return
     * @throws SQLException
     * @throws InstantiationException
     */
    public static boolean readRecord(HttpServletRequest request, int siteId, String tableId, String recordId,
            String recordKey, List<FormItemBean> formItemList, String[][] itemMap, String marker, boolean ignorePubflag)
            throws SQLException, InstantiationException {

        Long fromRecId = null;
        Long toRecId = null;
        List<ConditionBean> conditions = null;

        if (!PhoenixUtil.isEmpty(recordId)) {
            fromRecId = ValueUtil.toLong(recordId);
            toRecId = ValueUtil.toLong(recordId);
        } else if (!PhoenixUtil.isEmpty(recordKey)) {
            conditions = ConditionBean.parse(recordKey);
        }

        List<Map<String, ClmDataBean>> list = VDb.getList(siteId, tableId, fromRecId, toRecId, conditions, null, null,
                ignorePubflag);
        if (PhoenixUtil.isEmpty(list)) {
            return false;
        }

        Map<String, ClmDataBean> record = list.get(0);

        SstagUtil.setCurrentRecordReplaceParam(request, tableId, record);

        // フォームが指定されている場合、該当フォームに値をセットする。
        if (!PhoenixUtil.isEmpty(formItemList)) {

            // セッションストアで保持しているフォームデータを取得する。
            PostInfo postInfo = StoreUtil.getPostInfo(request);

            for (FormItemBean formItem : formItemList) {
                String key = formItem.getItemId();
                String value[] = makeFormValue(key, itemMap, marker, request, record);
                postInfo.postItemMap.put(key, value);
            }

            // セッションストアにフォームデータを格納し直す。
            StoreUtil.setPostInfo(request, postInfo);

        }

        return true;

    }

    private static String[] makeFormValue(String key, String[][] itemMap, String marker, HttpServletRequest request,
            Map<String, ClmDataBean> record) throws InstantiationException {

        String format = null;
        for (String[] item : itemMap) {
            if (item[1].equals(key)) {
                format = item[0];
                break;
            }
        }

        if (PhoenixUtil.isEmpty(format)) {
            format = key;
        }

        List<String[]> formValueList = new ArrayList<String[]>();

        int beginIndex = 0;
        int endIndex = 0;

        while (true) {

            // postデータの部分を組み立てる。
            endIndex = format.indexOf(marker, beginIndex);
            if (endIndex < 0) {
                endIndex = format.length();
            }

            String[] clmIds = PhoenixUtil.split(format.substring(beginIndex, endIndex), " ");
            for (String clmId : clmIds) {
                if (record.containsKey(clmId)) {
                    ClmMetaMstUtil clmMetaMstUtil = ClmMetaMstUtil.getInstance(request, record.get(clmId));
                    formValueList.add(clmMetaMstUtil.getFormValue());
                }
            }

            if (endIndex >= format.length()) {
                break;
            }

            beginIndex = endIndex + marker.length();

            // 任意文字列の部分を組み立てる。
            endIndex = format.indexOf(marker, beginIndex);
            if (endIndex < 0) {
                endIndex = format.length();
            }

            formValueList.add(new String[] { format.substring(beginIndex, endIndex) });

            if (endIndex >= format.length()) {
                break;
            }

            beginIndex = endIndex + marker.length();
        }

        // フォーム設定値を結果の件数によって作成する。
        if (formValueList.size() == 0) {
            return null;
        } else if (formValueList.size() == 1) {
            return formValueList.get(0);
        } else {
            StringBuffer sb = new StringBuffer();
            for (String[] formValue : formValueList) {
                sb.append(PhoenixUtil.concat(formValue, ""));
            }
            return new String[] { sb.toString() };
        }
    }
}
