package jp.co.webcrew.phoenix.sstag.bean;

/**
 * フォーム項目登録テーブル情報を保持するbeanクラス。
 * 
 * @author kurinami
 */
public class FormItemWriteMapBean {

    /** サイトID */
    private int siteId = 0;

    /** フォームID */
    private String formId = "";

    /** 連番 */
    private int num = 0;

    /** 項目ID */
    private String[] itemId = new String[0];

    /** 書き込み先サイトID */
    private int mapSiteId = 0;

    /** 書き込み先テーブルID */
    private String mapTblId = "";

    /** 書き込み先カラムID */
    private String mapClmId = "";

    /** キー指定 */
    private boolean keyFlag = false;

    /** 連結セパレータ */
    private String sep = "";

    // 以下、アクセッサ。

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String[] getItemId() {
        return itemId;
    }

    public void setItemId(String[] itemId) {
        this.itemId = itemId;
    }

    public int getMapSiteId() {
        return mapSiteId;
    }

    public void setMapSiteId(int mapSiteId) {
        this.mapSiteId = mapSiteId;
    }

    public String getMapTblId() {
        return mapTblId;
    }

    public void setMapTblId(String mapTblId) {
        this.mapTblId = mapTblId;
    }

    public String getMapClmId() {
        return mapClmId;
    }

    public void setMapClmId(String mapClmId) {
        this.mapClmId = mapClmId;
    }

    public boolean isKeyFlag() {
        return keyFlag;
    }

    public void setKeyFlag(boolean keyFlag) {
        this.keyFlag = keyFlag;
    }

    public String getSep() {
        return sep;
    }

    public void setSep(String sep) {
        this.sep = sep;
    }

}
