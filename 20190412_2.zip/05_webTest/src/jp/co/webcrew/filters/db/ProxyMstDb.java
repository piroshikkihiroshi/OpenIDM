package jp.co.webcrew.filters.db;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.dbaccess.db.RefreshMstDb;
import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * プロキシ情報を管理するdbクラス。
 * 
 * @author kurinami
 */
public class ProxyMstDb extends RefreshMstDb {

	/** プロキシ情報マスタ情報取得用SQL */
	private static final String PROXY_MST_SELECT = "select * from proxy_mst";

	/** ロガー */
	private static final Logger log = Logger.getLogger(ProxyMstDb.class);

	/** 唯一のインスタンス */
	private static ProxyMstDb proxyMstDb = new ProxyMstDb();

	/** プロキシ情報の一覧 */
	private Map proxyMap;

	/**
	 * 生成不能コンストラクタ
	 */
	private ProxyMstDb() {
	}

	/**
	 * 唯一のインスタンスを返す。
	 * 
	 * @return
	 */
	public static ProxyMstDb getInstance() {
		return proxyMstDb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.webcrew.filters.db.RefreshMstDb#init()
	 */
	public void init() throws SQLException {

		DBAccess dbAccess = null;
		ResultSet rs = null;
		try {
			dbAccess = new DBAccess();

			Map proxyMap = new HashMap();

			// プロキシ情報一覧を検索する。
			dbAccess.prepareStatement(PROXY_MST_SELECT);
			rs = dbAccess.executeQuery();
			while (dbAccess.next(rs)) {

				String proxyCode = ValueUtil.nullToStr(rs
						.getString("proxy_code"));

				Map element = new HashMap();

				element.put("proxy_code", proxyCode);
				element.put("url", ValueUtil.nullToStr(rs.getString("url")));
				element.put("param_enc", ValueUtil.nullToStr(rs
						.getString("param_enc")));
				element.put("description", ValueUtil.nullToStr(rs
						.getString("description")));

				proxyMap.put(proxyCode, element);
			}

			this.proxyMap = proxyMap;

		} finally {
			DBAccess.close(rs);
			DBAccess.close(dbAccess);
		}

	}

	/**
	 * リクエストを送るURLを求める。
	 * 
	 * @param originalQueryString
	 * @return
	 */
	public String getUrl(String proxyCode, String queryString) {
		Map proxyMap = this.proxyMap;

		Map element = (Map) proxyMap.get(proxyCode);
		if (element == null) {
			log.error("該当するプロキシ情報が存在しません。[proxy_code: " + proxyCode + "]");
			return null;
		}

		String url = (String) element.get("url");
		String paramEnc = (String) element.get("param_enc");

		// エンコードに指定する文字コードが正しいかチェックする。
		try {
			if (paramEnc.length() > 0) {
				URLEncoder.encode("", paramEnc);
			}
		} catch (UnsupportedEncodingException e) {
			log.error("URLエンコード用の文字コードが不正です。[proxy_code: " + proxyCode
					+ " param_enc: " + paramEnc + "]", e);
			paramEnc = "";
		}

		// プロキシ情報のurlをurl部分とパラメータ部分に分割する。
		int index = url.indexOf('?');
		String dbQueryString = "";
		if (index >= 0) {
			dbQueryString = url.substring(index + 1);
			url = url.substring(0, index);
		}

		// パラメータ部分をURLエンコードする。
		if (dbQueryString.length() > 0 && paramEnc.length() > 0) {
			dbQueryString = encodeParameter(dbQueryString, paramEnc);
		}

		String resultQueryString = dbQueryString;
		resultQueryString += (resultQueryString.length() > 0
				&& queryString.length() > 0 ? "&" : "")
				+ queryString;

		return url + (resultQueryString.length() > 0 ? "?" : "")
				+ resultQueryString;
	}

	/**
	 * URLエンコード前のquery stringをURLエンコードする。
	 * 
	 * @param queryString
	 * @param paramEnc
	 * @return
	 */
	private static String encodeParameter(String queryString, String paramEnc) {

		StringBuffer sb = new StringBuffer();
		String[] parameters = queryString.split("&");
		for (int i = 0; i < parameters.length; i++) {
			String[] parameter = parameters[i].split("=", 2);
			String name = parameter[0];
			String value = (parameter.length == 2 ? parameter[1] : "");

			String tmp = urlDecode(value, paramEnc);
			value = urlEncode(tmp, paramEnc);

			if (i != 0) {
				sb.append("&");
			}
			sb.append(name);
			if (value.length() > 0) {
				sb.append("=");
				sb.append(value);
			}

		}

		return sb.toString();
	}

	/**
	 * urlデコードを行う。(エンコード処理が行われていない部分はそのまま使う。)
	 * 
	 * @param str
	 * @param enc
	 * @return
	 */
	private static String urlDecode(String str, String enc) {

		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			for (int i = 0; i < str.length(); i++) {
				char c = str.charAt(i);
				switch (c) {
				case '+':
					baos.write(' ');
					break;
				case '%':
					if (i + 2 < str.length()) {
						try {
							byte code = (byte) Integer.parseInt(str.substring(
									i + 1, i + 3), 16);
							baos.write(code);
							i += 2;
						} catch (NumberFormatException e) {
							baos.write(Character.toString(c).getBytes(enc));
							break;
						}
					} else {
						baos.write(Character.toString(c).getBytes(enc));
						break;
					}
					break;
				default:
					baos.write(Character.toString(c).getBytes(enc));
					break;
				}
			}

			return baos.toString(enc);
		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			return str;
		}
	}

	/**
	 * urlエンコードを行う。
	 * 
	 * @param str
	 * @param enc
	 * @return
	 */
	private static String urlEncode(String str, String enc) {

		try {
			StringBuffer out = new StringBuffer();

			for (int i = 0; i < str.length(); i++) {
				int c = (int) str.charAt(i);
				if ("1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_.*"
						.indexOf(Character.toString((char) c)) >= 0) {
					out.append((char) c);
				} else if (c == ' ') {
					out.append('+');
				} else {
					ByteArrayOutputStream buf = new ByteArrayOutputStream();
					try {

						OutputStreamWriter writer = new OutputStreamWriter(buf,
								enc);
						writer.write(c);
						writer.flush();
					} catch (IOException e) {
						continue;
					}
					byte[] ba = Character.toString((char) c).getBytes(enc);
					for (int j = 0; j < ba.length; j++) {
						out.append('%');
						char ch = Character.forDigit((ba[j] >> 4) & 0xF, 16);
						if (Character.isLetter(ch)) {
							ch -= ('a' - 'A');
						}
						out.append(ch);
						ch = Character.forDigit(ba[j] & 0xF, 16);
						if (Character.isLetter(ch)) {
							ch -= ('a' - 'A');
						}
						out.append(ch);
					}
				}
			}

			return out.toString();

		} catch (Exception e) {
			log.error("予期せぬエラー", e);
			return str;
		}

	}

	public static void main(String[] args) {
		{
			String[] test = new String[] { "栗並優次郎", "うーん どうだろう。。",
					" . _ - % & ? = ! # $ ( ) ", " abcdefg hijklmn ",
					"日本語を混ぜてみよう 栗並優次郎 間に%を混ぜるってのはどーだ。最後に%", };
			String enc = "Shift_JIS";

			for (int i = 0; i < test.length; i++) {
				try {
					String tmp = test[i];
					System.out.println("[" + tmp + "]");
					System.out.println(" " + URLEncoder.encode(tmp, enc));
					System.out.println(" " + urlEncode(tmp, enc));
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
			System.out
					.println("-------------------------------------------------------");
		}
		{
			String[] test = new String[] { "栗並優次郎", "うーん どうだろう。。",
					" . _ - % & ? = ! # $ ( ) ", " abcdefg hijklmn ",
					"日本語を混ぜてみよう 栗並優次郎 間に%を混ぜるってのはどーだ。最後に%", };
			String enc = "Shift_JIS";

			for (int i = 0; i < test.length; i++) {
				try {
					String tmp = URLEncoder.encode(test[i], enc);
					System.out.println("[" + tmp + "] -> ["
							+ URLDecoder.decode(tmp, enc) + "]:["
							+ urlDecode(tmp, enc) + "]");
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
			System.out
					.println("-------------------------------------------------------");
		}
		{
			String[] test = new String[] {
					"%8C%49%95%C0%97%44%8E%9F%98%59",
					"%82%A4%81%5B%82%F1+%82%C7%82%A4%82%BE%82%EB%82%A4%81%42%81%42",
					"+.+_+-+%25+%26+%3F+%3D+%21+%23+%24+%28+%29+",
					"+abcdefg+hijklmn+",
					"日本語を混ぜてみよう %8C%49%95%C0%97%44%8E%9F%98%59 間に%を混ぜるってのはどーだ。最後に%", };

			for (int i = 0; i < test.length; i++) {
				// try {
				String tmp = test[i];
				System.out.println("[" + tmp + "] -> ["/*
														 * +
														 * URLDecoder.decode(tmp,
														 * "Shift_JIS") + "]:["
														 */
						+ urlDecode(tmp, "Shift_JIS") + "]");
				// } catch(UnsupportedEncodingException e) {
				// e.printStackTrace();
				// }
			}
			System.out
					.println("-------------------------------------------------------");
		}

		String[][] check = new String[][] {
				{ "gegege=kurinami", "Shift_JIS" },
				{ "gegege=栗並%3Dgegege", "Shift_JIS" },
				{ "gegege=栗並%3Dgegege&bibibi=栗並%3Dgegege", "Shift_JIS" },
				{ "gegege=栗並%3Dgegege&bibibi=栗並%3Dgegege&dadada=栗並%3Dgegege",
						"Shift_JIS" },
				{ "gegege=栗並%3Dgegege&bibibi=栗並%3Dgegege&dadada=", "Shift_JIS" },
				{ "gegege=栗並%3Dgegege&bibibi=栗並%3Dgegege&dadada", "Shift_JIS" },
				{ "gegege=栗並%3Dgegege&bibibi=栗並%3Dgegege&", "Shift_JIS" },
				{ "gegege=栗並%3Dgegege&bibibi=&dadada=栗並%3Dgegege", "Shift_JIS" },
				{ "gegege=栗並%3Dgegege&bibibi&dadada=栗並%3Dgegege", "Shift_JIS" },
				{ "gegege=栗並%3Dgegege&&dadada=栗並%3Dgegege", "Shift_JIS" },
				{ "gegege=&bibibi=栗並%3Dgegege&dadada=栗並%3Dgegege", "Shift_JIS" },
				{ "gegege&bibibi=栗並%3Dgegege&dadada=栗並%3Dgegege", "Shift_JIS" },
				{ "&bibibi=栗並%3Dgegege&dadada=栗並%3Dgegege", "Shift_JIS" },
				{ "gegege=%8C%49%95%C0", "Shift_JIS" }, };

		for (int i = 0; i < check.length; i++) {
			System.out.println("[" + check[i][0] + "] [" + check[i][1]
					+ "] => [" + encodeParameter(check[i][0], check[i][1])
					+ "]");
		}
	}
}
