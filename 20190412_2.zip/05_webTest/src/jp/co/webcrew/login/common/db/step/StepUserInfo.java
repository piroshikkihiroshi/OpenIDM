package jp.co.webcrew.login.common.db.step;

import java.sql.SQLException;

import jp.co.webcrew.dbaccess.db.DBAccess;
import jp.co.webcrew.login.common.db.MemberMst;
import jp.co.webcrew.login.common.db.OrderHist;


/**
 * Stepのユーザ登録情報と、グローバルな会員情報を相互変換するためのインタフェース
 * 
 */
public interface StepUserInfo {

/*-------------------------------------------------------------------------------
 * 
 * Stepのユーザ情報を制御するインタフェース
 *
 * -----------------------------------------------------------------------------*/

	/**
	 * <pre>
	 * 
	 * orderId , userId の二つのIDを元に、Stepサイト側のユーザ情報等をDBから読み込む
	 * 
	 * 通常は USER_INFO テーブルの情報を読み込めば十分だが、MemberMst と連携する内容によっては、
	 * （サイトによって）ORDER_INFO等の情報を読み込む必要がある。
	 * 
	 * </pre>
	 * @param db
	 * @param orderId
	 * @param userId
	 */
	public boolean doLoad(DBAccess db , String orderId , String userId) throws SQLException;

	/**
	 * <pre>
	 * guidから直近のorder_id,user_idのペアを得る
	 * 
	 * String[0] order_id
	 * String[1] user_id
	 * 
	 * エラーの場合・取得できなかった場合・もしくはIDが存在しない場合などは、
	 * nullを返す
	 * 
	 * StepUserInfoCommonDbを継承した場合は、ID取得のための汎用SQL
	 * "SELECT ORDER_ID , USER_ID FROM " + getSchema() + ".ORDER_INFO WHERE GUID=? ORDER BY LAST_UPDATE DESC"
	 * が実行されるので、特にサブクラス側で実装する必要は無い。
	 * ただし、
	 * ・ORDER_INFO テーブルの中に ORDER_ID と USER_ID が存在する
	 * ・ORDER_ID と stepで言うRequestIdが等しい
	 * 等の通常パターンからはずれる特殊なステップサイトの場合は、サブクラス側でメソッドをオーバーライドすること
	 * 
	 * </pre>
	 * 
	 * @param db
	 * @param guid
	 */
	public String[]  getOrderIDs(DBAccess db , String guid);
	
//	/**
//	 * <pre>
//	 * guidから直近のorder_idを得る
//	 * 
//	 * nullは返さないこと
//	 * 
//	 * エラーの場合・取得できなかった場合・もしくはIDが存在しない場合などは、
//	 * 空文字を返す
//	 * 
//	 * </pre>
//	 * 
//	 * @param db
//	 * @param guid
//	 */
//	public String  getOrderId(DBAccess db , String guid);
//
//	/**
//	 * <pre>
//	 * guidから直近のuser_idを得る
//     *
//	 * nullは返さないこと
//	 * 
//	 * エラーの場合・取得できなかった場合・もしくはIDが存在しない場合などは、
//	 * 空文字を返す
//	 * 
//	 * </pre>
//	 * 
//	 * @param db
//	 * @param guid
//	 */
//	public String  getUserId(DBAccess db , String guid) ;
	public String getSiteId();
	public void setSiteId(String id);
	public String getUserId();
	public void setUserId(String id);
	public String getRequestId();
	public void setRequestId(String id);
	
	/**
	 * <pre>
	 * 最終更新日をYYYYMMDD形式で得る
	 * </pre>
	 * 
	 * @return
	 */
	public String getLastUpdate();
	
	/**
	 * <pre>
	 * メールマガジン用のメールアドレスを取得する
	 * </pre>
	 */
	public String getMagEmail();
	
	/**
	 * <pre>
	 * メルマガ購読状態を取得する
	 * 
	 * 戻り値
	 * 0      : 購読しない
	 * 1      : 購読する
	 * その他 : メルマガ購読情報無し
	 * </pre> 
	 */
	public String getMagFlag();



	/**
	 * <pre>
	 * 会員情報を変換して、自分自身のオブジェクトにセットする
	 * 
	 * <呼出条件>
	 * 特に無し
	 * 
	 * <使用箇所>
	 * ログイン処理の中で使われる
	 * {@link StepUserInfo#doPrepareStepDatabase(DBAccess, String, String)}
	 * 
	 * <実装方法>
	 * MemberMstオブジェクトmemberの必要なプロパティを取得・変換し、
	 * 自分自身の属性にコピーするコードを記述する
	 * 
	 * </pre>
	 * @param member 会員情報
	 */
	public void doPopulateFromMemberMst(MemberMst member);

	public void doPrepareStepDatabase(DBAccess db , String guid , String gsid) throws SQLException;
	/*-------------------------------------------------------------------------------
	 * 
	 * ログイン機能がStep側のデータベースを制御するためのインタフェース
	 *
	 * -----------------------------------------------------------------------------*/

	/**
	 * <pre>
	 * ある特定のguidに関する情報を、データベースから全て削除する。
	 * 
	 * <呼び出し条件>
	 * 特に無し
	 * 
	 * <実装方法>
	 * 該当guidを持つレコードに対し、guid列の値をnullにする。
	 * 
	 * ただし、guid列を持つテーブルは、その数も名前もstepによって異なるため、具体的処理は
	 * サブクラス側で実装する。
	 * 
	 * 具体的な実装方法はdbを使用すること以外は自由。
	 * ただし、データベースコミットをしてはいけない。
	 * </pre>
	 * @param db DBアクセサ
	 * @param guid 新しいGUID
	 * @return 成功したらtrue　失敗したらfalse
	 */
	public void doDeleteGuid(DBAccess db , String guid) throws SQLException;

	/**
	 * <pre>
	 * 会員情報とステップのユーザ情報に違いがあるか否かを判別する
	 * 
	 * true ：違いがある
	 * false：違いが無い
	 * 
	 * [実装上の注意]
	 * 
	 * メールアドレスは比較対象としないこと。
	 * 
	 * </pre>
	 * @param member 会員情報
	 */
	public boolean doIsDifferentFromMemberMst(MemberMst member);

	/**
	 * <pre>
	 * step側のデータベースのguidを、新しいguidで上書きする
	 * 
	 * <呼出条件>
	 * このメソッドを呼び出す前に、doLoadを先に実行して内部変数をセットしておく必要がある。
	 * 
	 * <実装方法>
	 * guidの更新対象のテーブルは、その数も名前もstepによって異なるため、サブクラス側が
	 * 自由に実装する。ただし、データベースコミットをしてはいけない。
	 * 
	 * </pre>
	 * @param guid 新しいGUID
	 * @return 成功したらtrue　失敗したらfalse
	 */
	public boolean doOverWriteGuid(DBAccess db , String guid);








/*-------------------------------------------------------------------------------
 * 
 * 共通ユーザ情報インタフェース
 * MemberMst（会員情報）とStepユーザの共通属性にアクセスするためのインタフェース
 * 
 * -----------------------------------------------------------------------------*/
	public String getPrefId();
	public void setPrefId(String val);
	public String getSexId();
	public void setSexId(String val);

	/**
	 * 法人サイトであればtrue
	 * そうでなければfalse
	 */
	public boolean isCorporateService();
	public String getEmail();
	public String getBirthYear();
	public String getBirthMonth();
	public String getBirthDay();
	public String getZip();
	public void setZip(String val);
	
	/**
	 * 誕生日をYYYY-MM-DD形式で返す
	 * 
	 * @return
	 */
	public String getBirthDate();
	public void setBirthDate(String year,String month,String day);


/*-------------------------------------------------------------------------------
 * 
 * Stepのユーザ情報と会員情報を相互変換するためのインタフェース
 * 
 * -----------------------------------------------------------------------------*/	

	
	/**
	 * <pre>
	 *ステップのユーザ情報を会員情報オブジェクトにコピーする
	 * </pre>
	 * @param member
	 */
	public void doPopulateToMemberMst(MemberMst member);
	
	/**
	 * <pre>
	 * ステップのOrderInfoデータを履歴情報オブジェクトにコピーする
	 * </pre>
	 * @param order
	 */
	public void doPopulateToOrderHist(OrderHist order);

/*-------------------------------------------------------------------------------
 * 
 * その他のインタフェース
 * 
 * -----------------------------------------------------------------------------*/	
	/**
	 * 携帯からのアクセスであればtrue
	 * 
	 * そうでなければfalse
	 */
	public boolean isMobileAccess();
    
    /**
     * <pre>
     * ログイン対応したStepは、仮登録時にUSER_INFO・ORDER_INFOに
     * アクセスしたGUIDが書き込まれているので、それを返す
     * 
     * 通常は、USER_INFO.GUID を返せば良い。
     * 
     * StepUserInfoの具象クラスがStepUserInfoCommonDb を継承している場合、
     * StepUserInfoCommonDbに既に USER_INFO.GUID を返却する汎用コードが実装
     * 済みなので、新たに実装する必要はない。
     * （USER_INFO テーブルが存在しない等の特殊な場合のみ、StepUserInfoCommonDb
     * のサブクラスでこのメソッドをオーバーライドする必要がある）
     * 
     * </pre>
     */
    public String getGuid();

//  /**
//  * <pre>
//  * ステップ側で読み込まれたユーザ情報のguidが妥当であるかを判断する。
//  * 
//  * カレントGUID（ブラウザで認識されたguid）と、ステップ側で読み込まれた
//  * ユーザ情報のguidが合致していればtrue、そうでなければfalseを返す
//  * 
//  * カレントGUIDが不正ならfalse
//  * 
//  * </pre>
//  * 
//  * @param currentGuid ユーザのカレントGUID（ブラウザで認識されたGUID）
//  * @return
//  */
// public boolean doValidateGuid(String currentGuid);
}
