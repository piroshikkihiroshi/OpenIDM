package jp.co.webcrew.login.common.db;

import jp.co.webcrew.dbaccess.db.DBConnectionFactory;
import jp.co.webcrew.login.common.db.util.DBEntity;

/**
 * サイト固有のメールコンテンツを扱うクラス
 * 
 * @author Tobe
 *
 */
public class MailPerSiteContents extends DBEntity{
    
    /** スキーマ */
    public static final String SCHEMA = DBConnectionFactory.getSchemaFromPropeties();

    /** テーブル名 */
    public static final String TABLE  = "MAIL_PER_SITE_CONTENTS";
    
    /*
     * 列名定義 （定数定義）
     */ 
    public static final String SITE_ID          = "SITE_ID";
    public static final String SITE_NAME        = "SITE_NAME";
    public static final String VAR_CONTENTS_1  = "VAR_CONTENTS_1";
    public static final String VAR_CONTENTS_2  = "VAR_CONTENTS_2";
    public static final String VAR_CONTENTS_3  = "VAR_CONTENTS_3";
    public static final String VAR_CONTENTS_4  = "VAR_CONTENTS_4";
    public static final String VAR_CONTENTS_5  = "VAR_CONTENTS_5"; 
    public static final String UP_DATETIME      = "UP_DATETIME"; 
    public static final String UP_ADMIN         = "UP_ADMIN"; 

    /*
     * (non-Javadoc)
     * @see jp.co.webcrew.login.common.db.util.DBEntity#init()
     */
    public void init(){
        setSchema(SCHEMA);
        setTable(TABLE);
    }

    /**
      * コンストラクタ
      * 
      * @param templ_id メールテンプレートID
      * @param siteId   サイトID
      */
     public MailPerSiteContents(String siteId){
         set(SITE_ID, siteId);
     }

     /**
      * サイト名を取得する。
      * @return サイト名を取得する。
      */
     public String getSiteName() {
         return get(SITE_NAME);
     }
     
    /**
     * 固有コンテンツ1を取得する。
     * 
     * @return 固有コンテンツ1
     */
    public String getVarContents1() {
        return get(VAR_CONTENTS_1);
    }
    
    /**
     * 固有コンテンツ2を取得する。
     * 
     * @return 固有コンテンツ2
     */
    public String getVarContents2() {
        return get(VAR_CONTENTS_2);
    }
    
    /**
     * 固有コンテンツ3を取得する。
     * 
     * @return 固有コンテンツ3
     */
    public String getVarContents3() {
        return get(VAR_CONTENTS_3);
    }
    
    /**
     * 固有コンテンツ4を取得する。
     * 
     * @return 固有コンテンツ4
     */
    public String getVarContents4() {
        return get(VAR_CONTENTS_4);
    }   
    
    /**
     * 固有コンテンツ5を取得する。
     * 
     * @return 固有コンテンツ5
     */
    public String getVarContents5() {
        return get(VAR_CONTENTS_5);
    }
}
