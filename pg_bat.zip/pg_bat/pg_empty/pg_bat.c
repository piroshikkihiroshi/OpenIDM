/*
* Copyright (c) 2015	SQIG Inc.
*
* Permission to use, copy, modify, and distribute this software and its documentation
* for any purpose, without fee, and without a written agreement is hereby granted,
* provided that the above copyright notice and this paragraph and the following two paragraphs
* appear in all copies.
*
* IN NO EVENT SHALL SQIG Inc. BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL,
* OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
* DOCUMENTATION, EVEN IF SQIG Inc. HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* SQIG Inc. SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* THE SOFTWARE PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND SQIG Inc. HAS NO OBLIGATIONS TO PROVIDE
* MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
*/
#include "postgres.h"
#include "catalog/pg_type.h"
#include "fmgr.h"
#include <stdio.h>
#include <stdlib.h>


#ifdef PG_MODULE_MAGIC
PG_MODULE_MAGIC;
#endif

//cmdAction
//Returns null
PGDLLEXPORT Datum cmdAction(PG_FUNCTION_ARGS);
PG_FUNCTION_INFO_V1(cmdAction);

PGDLLEXPORT Datum cmdAction(PG_FUNCTION_ARGS) {

	//PG_GETARG_TEXT_P(0)��(0)������1
	text *argText1 = PG_GETARG_TEXT_P(0);
	char argText1_buff[128];

	memset(argText1_buff, '\0', sizeof(argText1_buff));
	memcpy(argText1_buff, VARDATA(argText1), VARSIZE(argText1) - VARHDRSZ);
	// ������\��
	elog(INFO, "argText1=[%s]", argText1_buff);

	if (system(argText1_buff) == -1) {
		elog(INFO, "Command not Action");
		PG_GETARG_INT32(-1);
	}
	elog(INFO, "Command Action");
	PG_GETARG_INT32(0);

}




