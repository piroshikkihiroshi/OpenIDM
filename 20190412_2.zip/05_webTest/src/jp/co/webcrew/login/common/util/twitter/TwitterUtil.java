
package jp.co.webcrew.login.common.util.twitter;


import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.webcrew.dbaccess.util.Logger;
import twitter4j.DirectMessage;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.ResponseList;
import twitter4j.Status;
import twitter4j.Tweet;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
//import twitter4j.http.AccessToken;
//import twitter4j.http.RequestToken;
//t_ueda 修正
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;

/**
 * TwitterAPI利用クラス
 * @author shintaro.kurihara
 *
 */

public class TwitterUtil {

	private static Logger log = Logger.getLogger(TwitterUtil.class);

	//requestTokenのパラメータ名
	private static final String REQUEST_TOKEN_PARAM_NAME = "requestToken";

	//oauth_verifierのパラメータ名　Aouth認証許可時にURLパラメータに付加される
	private static final String OAUTH_VERIFIER_PARAM_NAME = "oauth_verifier";

	//deniedのパラメータ名　Aouth認証拒否時にURLパラメータに付加される
	private static final String DENIED_PARAM_NAME = "denied";

	/**
	 * デフォルトコンストラクタ
	 *
	 */
	public TwitterUtil(){
	}

	/**
	 * OAuth認証ページへのリダイレクト
	 *
	 * @params HttpServletRequest req　
	 * @params　HttpServletResponse res
	 * @params　AbstractTwitterInfo twitteInfo　サイト固有のTwitterInfo
	 */
	public static void redirectOAuthPage(HttpServletRequest req,HttpServletResponse res, AbstractTwitterInfo twitterInfo)throws Exception {

		//認可前のRequest Token
		RequestToken requestToken = null;

		//Consumerオブジェクトの取得
		Twitter _appTwitter = twitterInfo.getConsumerTwiter();

		try {
			//戻り先URL引数にして、リクエストトークンを取得する。
			requestToken = _appTwitter.getOAuthRequestToken(twitterInfo.getCallBackURL());

		} catch (TwitterException e) {
			log.error("例外エラーが発生しました。" , e);
			//ここでこけたら、そのまま戻す
			return;
		}
		//Consumerは未認可のRequest TokenをURL Parameterに付加する
		req.getSession().setAttribute(REQUEST_TOKEN_PARAM_NAME, requestToken);
		//twitter(Service Provider)にリダイレクト
		res.sendRedirect(requestToken.getAuthenticationURL());
	}


	/**
	 * OAuth認証の結果を返す
	 * TwitterがNULLだったら、認証失敗、または拒否されたと判断
	 *
	 * @return Twitter
	 * @params HttpServletRequest req
	 * @params AbstractTwitterInfo twitterInfo　サイト固有のTwitterInfo
	 */
	public static TwitterBean isOAuthAttestation(HttpServletRequest req, AbstractTwitterInfo twitterInfo) throws Exception{

		//Service Providerは認可済のRequest Tokenを取得する
    	RequestToken reqToken = (RequestToken) req.getSession().getAttribute(REQUEST_TOKEN_PARAM_NAME);

    	TwitterBean twitterBean = null;

    	//認証を許可された際に付与されるParameter
        final String verifier = req.getParameter(OAUTH_VERIFIER_PARAM_NAME);
        //認証を拒否されたときに付与されるParameter
        final String denied = req.getParameter(DENIED_PARAM_NAME);

        //認証拒否時の処理
        if(denied != null){
        	return null;
        }

        try{
        	   //Consumerオブジェクトの作成
        	Twitter _counsumerTwitter = twitterInfo.getConsumerTwiter();

    		//認可済のRequest Tokenより、実際のアクセス権を示すAccess Tokenと交換する
        	AccessToken accessToken = _counsumerTwitter.getOAuthAccessToken(reqToken, verifier);

        	//Access Tokenを基にユーザTwitterの設定
        	////t_ueda 修正
//        	Twitter _twitter = new TwitterFactory().getOAuthAuthorizedInstance( twitterInfo.getConsumerKey(), twitterInfo.getConsumerSecret(), accessToken );
        	Twitter _twitter = new TwitterFactory().getInstance();
        	twitterBean = new TwitterBean(_twitter);

        }catch (TwitterException e) {
        	log.error("OAuth認証中にエラーが発生しました。" , e);
        	return null;
		}
        return twitterBean;
	}



	/**
	 * ユーザに投稿させる
	 *
	 * @params targetTwitter tweets[]
	 * TwitterException発生時は0を返す
	 * @return tweetID
	 */
	public static long updateTwitt(TwitterBean targetTwitter,String[] strs){

		StringBuffer buf = new StringBuffer();
		Status status = null;
		//つぶやきの内容を生成
		for(int i = 0; i < strs.length; i++){
			buf.append(strs[i]);
		}

		if(targetTwitter == null || buf.length() == 0){
			return 0;
		}else{
			try{
				status = targetTwitter.getTwitter().updateStatus(buf.toString());
			}catch(TwitterException e){
				log.error("例外エラーが発生しました。" , e);
				return 0;
			}
		}
		return status.getId();
	}


	/**
	 * 引数で取得した文字列のつぶやきを検索する
	 *
	 * @params searchQuery 検索文字列
	 * @params limit　最大取得数
	 * TwitterException発生時はnullを返す
	 */
	public static List searchTweets(String searchQuery, Integer limit) {

	    List tweetList = new ArrayList();
	    try{
	    	// APIにてツイートを取得
	    	TwitterFactory factory = new TwitterFactory();
	    	Twitter twitter = factory.getInstance();
	    	Query query = new Query();
	    	query.setQuery(searchQuery);

	    	// rpp: Optional. The number of tweets to return per page, up to a max of 100.
	    	query.setRpp(100);
	    	// page: Optional. The page number (starting at 1) to return, up to a max of roughly 1500 results (based on rpp * page.
	    	query.setPage(1);

	    	long max_id = 0;
	    	while(true){
	    		// ツイートを取得
	    		QueryResult qr = twitter.search(query);

	    		List statusList = qr.getTweets();
	    		// ツイートが取得できなくなったら終了
	    		if(statusList.size() == 0){
	    			break;
	    		}
	    		tweetList.addAll(statusList);

	    		// ツイートが欲しい最大数以上になったら終了
	    		if(limit != null && limit.intValue() <= tweetList.size()){
	    			break;
	    		}
	    		// 次にAPIをたたくときは、いま取得したツイートより昔のを取得するように
	    		max_id = ((Tweet)(statusList.get(statusList.size() - 1) )).getId() - 1;
			    query.setMaxId(max_id);
	    	}
	    }catch(Exception e){
	    	log.error("つぶやき取得中にエラーが発生しました。" , e);
	    }
	    return tweetList;
	}

//	/**
//	 * Tweetを、表示形式に成型する
//	 * @return List<TweetBean>
//	 * TwitterException発生時はnullを返す
//	 */
	/*public static List getTweetsList(String searchQuery, Integer limit){
		List resultList = new ArrayList();

		List _tempList = searchTweets(searchQuery,limit);

		//nullだった場合、取得クラスでTwitterExceptionが発生している
		if(_tempList == null){
			return null;
		}

		TweetBean _bean = null;
		Tweet _tweet = null;

		//Tweetを表示用に成型
		for(Iterator it = _tempList.iterator(); it.hasNext();){
			_tweet = (Tweet)it.next();
			_bean = new TweetBean(_tweet);
			resultList.add(_bean);
		}

		return resultList;
	}*/

	/**
	 * Tweetを、表示形式に成型する 検索文字列が複数ある場合
	 * @return List<TweetBean>
	 * TwitterException発生時はnullを返す
	 */
	public static List getTweetsList(String[] searchQuery, Integer limit){

		List resultList = new ArrayList();
		List _tempList = null;
		Tweet _tweet = null;

		for(int i = 0; i < searchQuery.length; i++){
			_tempList = searchTweets(searchQuery[i],limit);

			if( _tempList != null){
				//Tweetを表示用に成型
				for(Iterator it = _tempList.iterator(); it.hasNext();){
					_tweet = (Tweet)it.next();
					resultList.add(new TweetBean(_tweet));
				}
			//nullだった場合、取得クラスでTwitterExceptionが発生している
			}else{
				return null;
			}
		}
		//時間の降順でソート
		java.util.Collections.sort(resultList);
		return resultList;
	}

	/**
	 *　 つぶやきを書き込み後、検索に反映されるまでのタイムラグがあるので
	 * 　Tweetを、手動で生成するメソッド
	 *
	 * @trows TwitterException
	 * @return TweetBean
	 * TwitterException発生時はnullを返す
	 */
	public static TweetBean manuallyMakeTweet(TwitterBean userTwitter, String[] strs, java.util.Date date){

		TweetBean tweetBean = null;

		try{
			String profileImageUrl = "";
			//プロフィール画像のパスを取得する
			//Twitterクラスからパスを取得できないので、一度TimeLineを取得して、そこから取ってくる必要がある
			ResponseList statuses  = userTwitter.getTwitter().getUserTimeline();
			if(statuses != null && statuses.size() != 0){
				Status state = (Status)statuses.get(0);
				profileImageUrl = state.getUser().getProfileImageURL().toString();
			}

			String tweetText = "";
			StringBuffer buf = new StringBuffer();
			//つぶやきの内容を生成
			for(int i = 0; i < strs.length; i++){
				buf.append(strs[i]);
			}
			tweetText = buf.toString();

			//tweetBeanを手動で作成
			tweetBean = new TweetBean(date,profileImageUrl,
			                                    tweetText,userTwitter.getTwitter().getScreenName());
		}catch (TwitterException e){
			log.error("例外エラーが発生しました。" , e);
			return null;
		}
		return tweetBean;
	}


	/**
	 * 経過時間の表示フォーマット設定メソッド
	 *
	 */
	public static String getStrFormatElapsedTimeDate(Date targetDate,int elapsedTimeFormatID){

		String timeStr = null;
		switch(elapsedTimeFormatID){

			case 1:
				timeStr = formatPatern01(targetDate);
				break;
			case 2:
				timeStr = formatPatern02(targetDate);
				break;
			default:
				timeStr = targetDate.toString();
		}
		return timeStr;
	}


	/**
	 * 前回の更新時間から、つぶやきListの更新の可否を判別する
	 *
	 * @params previosUpdateDate 前回の更新時間
	 * @params updateGapMin　更新間隔（/分）
	 */
	public static boolean isTwitteListUpdate(Date previosUpdateDate, int updateGapMin){

		Date _nowDate  = new Date();

		// 1ms = 1/1000s
		long s = _nowDate.getTime() - previosUpdateDate.getTime();

		//ミリ秒
		s = s / 1000;
		//秒
		s = s / 60;
		long min = s % 60;

		return ( min >= updateGapMin );
	}


	/**
	 * 経過時間フォーマットその１
	 * 時間表示
	 *　●minits ago
	 *　●days ago
	 *　●hours ago
	 *
	 */

	private static String formatPatern01(Date targetDate){

		Date _nowDate  = new Date();

		// 1ms = 1/1000s
		long s = _nowDate.getTime() - targetDate.getTime();
		//ミリ秒
		long milli = s % 1000;
		s = s / 1000;
		//秒数
		long sec = s % 60;
		s = s / 60;
		//分
		long min = s % 60;
		s = s / 60;
		//時間
		long hour = s % 24;
		//経過日にち
		long days = s / 24;
		StringBuffer sb =  new StringBuffer();

		sb.append("about");

		if(days > 0){
			sb.append(" "+days+"days ago");
		}
		//経過時間
		else if(hour > 0){
			sb.append(" "+hour+"hour ago");
		}else{
			sb.append(" "+min+"min ago");
		}
		return sb.toString();
	}

	/**
	 * 経過時間フォーマットその２　about ○days ○hours ○min ago
	 *
	 */
	private static String formatPatern02(Date targetDate){

		Date _nowDate  = new Date();

		// 1ms = 1/1000s
		long s = _nowDate.getTime() - targetDate.getTime();
		//ミリ秒
		long milli = s % 1000;
		s = s / 1000;
		//秒数
		long sec = s % 60;
		s = s / 60;
		//分
		long min = s % 60;
		s = s / 60;
		//時間
		long hour = s % 24;
		//経過日にち
		long days = s / 24;
		StringBuffer sb =  new StringBuffer();

		sb.append("about");

		if(days > 0){
			sb.append(" "+days+"days");
		}
		//経過時間
		if(hour > 0){
			sb.append(" "+hour+"hour");
		}
		sb.append(" "+min+"min ago");

		return sb.toString();
	}


	/**
	 * フォローされているかの確認
	 * @params　fromScreenName フォローを確認する側のScreenName（Twitterのアカウント）
	 * @params　toScreenName　対象となるScreenName（Twitterのアカウント）
	 *
	 */
	private boolean isFriendShip(String fromScreenName, String toScreenName){

		boolean result = false;
		try{
			//APIにてツイートを取得
	    	TwitterFactory factory = new TwitterFactory();
	    	Twitter twitter = factory.getInstance();
	    	result = twitter.existsFriendship(fromScreenName, toScreenName);
		}catch(TwitterException e){
			log.error("フォロー確認中エラー。" , e);
		}
		return result;
	}


	/**
	 * フォローする
	 *
	 * @params　fromScreenName フォローを申請する側のTwitterクラス
	 * @params　toScreenName　フォローをお願いする側のScreenName（Twitterのアカウント）
	 */
	public boolean makeFriendShip(Twitter fromTwitter, String toScreenName){

		boolean result = false;
		try{
			if(isFriendShip(fromTwitter.getScreenName(),toScreenName)){
				User user = fromTwitter.createFriendship(toScreenName);
				if(user != null){
					result = true;
				}
			}
		}catch(TwitterException e){
			log.error("フォロー登録中にエラー" , e);
		}
		return result;
	}

	/**
	 * ダイレクトメッセージの送信
	 * @params　fromTwitter 　メッセージを送る側のTwitterクラス
	 * @params　toScreenName　対象となるScreenName（Twitterのアカウント）
	 * @params　message　メッセージの内容
	 *
	 */
	public boolean sendDirectMessage(Twitter fromTwitter,String toScreenName, String message) throws TwitterException{

		boolean isSend = false;

		//アプリのユーザのダイレクトメッセージを送信させる
		//※おたがいフォロー済みでないとエラーになるので注意
		try{
			DirectMessage directMessage =  fromTwitter.sendDirectMessage(toScreenName, message);

			if(directMessage != null){
				isSend  =  true;
			}
		}catch (TwitterException e){
			log.error("ダイレクトメッセージの送信中エラー。" , e);
		}
		return isSend;
	}


}