package jp.co.webcrew.filters.util.httputil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import jp.co.webcrew.dbaccess.util.Logger;
import jp.co.webcrew.dbaccess.util.ValueUtil;

/**
 * 結果htmlを最終的に置換できるように、出力をバッファリングするresponseクラス。
 * 
 * @author kurinami
 */
public class CustomHttpServletResponse extends HttpServletResponseWrapper {

	/** ロガー */
	private static final Logger log = Logger
			.getLogger(CustomHttpServletResponse.class);

	/** もともとの結果htmlを格納するバッファ */
	private ByteArrayOutputStream htmlContents = new ByteArrayOutputStream();

	/** 出力をバッファに格納するようにしたoutputStream */
	private CustomServletOutputStream outputStream = null;

	/** 出力をバッファに格納するようにしたwriter */
	private PrintWriter writer = null;

	/** 設定された文字エンコーディング */
	private String characterEncoding = "Shift_JIS";

	/** リダイレクト先URL */
	private String location = null;

	/** 状態コード */
	private int status = HttpServletResponse.SC_OK;

	public CustomHttpServletResponse(HttpServletResponse response, String characterEncoding) {
		super(response);
		this.characterEncoding = characterEncoding;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletResponseWrapper#getOutputStream()
	 */
	public ServletOutputStream getOutputStream() throws IOException {
		if (outputStream == null) {
			outputStream = new CustomServletOutputStream(htmlContents);
		}

		return outputStream;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletResponseWrapper#getWriter()
	 */
	public PrintWriter getWriter() throws IOException {
		if (writer == null) {
			writer = new PrintWriter(new OutputStreamWriter(htmlContents,
					getCharacterEncoding()));
		}

		return writer;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletResponseWrapper#setContentLength(int)
	 */
	public void setContentLength(int length) {
		// 置換した結果ContentLengthが元と変わる可能性があるので、
		// アプリ側で明示的に指定されたContentLengthは無視するようにOverRide
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletResponseWrapper#getCharacterEncoding()
	 */
	public String getCharacterEncoding() {
		return characterEncoding;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletResponseWrapper#setCharacterEncoding(java.lang.String)
	 */
	public void setCharacterEncoding(String characterEncoding) {
		super.setCharacterEncoding(characterEncoding);

		// 明示的に指定された文字エンコーディングを自分でも保持しておく。
		this.characterEncoding = characterEncoding;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletResponseWrapper#setContentType(java.lang.String)
	 */
	public void setContentType(String contentType) {
		super.setContentType(contentType);

		// content-typeの中でcharsetも指定されてあった場合、
		if (ValueUtil.nullToStr(contentType).toLowerCase().indexOf("charset") >= 0) {
			characterEncoding = super.getCharacterEncoding();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServletResponseWrapper#sendRedirect(java.lang.String)
	 */
	public void sendRedirect(String location) throws IOException {
		log.info("転送先指定 [status:302:location: " + location + "]");
		this.location = location;

		this.status = HttpServletResponse.SC_MOVED_TEMPORARILY;
	}
	
	public void send301Redirect(String location) throws IOException {
		log.info("転送先指定 [status:301:location: " + location + "]");
		this.location = location;
		this.status = HttpServletResponse.SC_MOVED_PERMANENTLY;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServletResponseWrapper#sendError(int,
	 *      java.lang.String)
	 */
	public void sendError(int sc, String msg) throws IOException {
		this.status = sc;
		super.sendError(sc, msg);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServletResponseWrapper#sendError(int)
	 */
	public void sendError(int sc) throws IOException {
		this.status = sc;
		super.sendError(sc);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServletResponseWrapper#setStatus(int,
	 *      java.lang.String)
	 */
	public void setStatus(int sc, String msg) {
		this.status = sc;
		super.setStatus(sc, msg);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServletResponseWrapper#setStatus(int)
	 */
	public void setStatus(int sc) {
		this.status = sc;
		super.setStatus(sc);
	}

	/**
	 * バッファリングした結果htmlを返す。
	 * 
	 * @throws IOException
	 */
	public String getHtml() throws IOException {
		if (outputStream != null) {
			outputStream.flush();
		}
		if (writer != null) {
			writer.flush();
		}

		// 結果htmlを返す。
		String characterEncoding = getCharacterEncoding();
		return htmlContents.toString(characterEncoding);
	}

	/**
	 * バッファリングした結果をバイト配列で返す。
	 * 
	 * @return
	 * @throws IOException
	 */
	public byte[] getByte() throws IOException {
		if (outputStream != null) {
			outputStream.flush();
		}
		if (writer != null) {
			writer.flush();
		}

		return htmlContents.toByteArray();
	}

	/**
	 * リダイレクト先を返す。リダイレクト先が指定されていない場合はnullが返る。
	 * 
	 * @return
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * リダイレクト先を設定する。
	 * 
	 * @param location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * 状態コードを返す。
	 * 
	 * @return
	 */
	public int getStatus() {
		return this.status;
	}

}
