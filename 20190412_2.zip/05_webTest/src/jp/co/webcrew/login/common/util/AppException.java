package jp.co.webcrew.login.common.util;
import java.sql.SQLException;


public class AppException extends SQLException{


	private static final long serialVersionUID = -875940777046149383L;

	public AppException(){
		super();
	}
	
	public AppException(String s){
		super(s);
	}

	public AppException(Throwable e){
		super(e.getMessage());
	}

}

