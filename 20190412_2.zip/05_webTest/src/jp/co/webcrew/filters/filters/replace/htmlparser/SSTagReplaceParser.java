package jp.co.webcrew.filters.filters.replace.htmlparser;

public class SSTagReplaceParser {

	/**
	 * htmlの内容を解析しながら置換する。
	 * 
	 * @param contents
	 *            元のhtml
	 * @param cb
	 *            置換ルールを持つパーサーコールバック
	 * @return 置換後のhtml
	 */
	public static String parse(String contents, HtmlReplaceParserCallback cb) {

		StringBuffer sb = new StringBuffer();

		int fromIndex = 0;
		int toIndex = 0;
		String temp;

		while (true) {

			// --------------------------------------------------
			// sstagのタグを探す
			boolean startTagFlag = true;
			
			while (toIndex < contents.length()) {
				toIndex = contents.indexOf("<", toIndex);
				toIndex = toIndex >= 0 ? toIndex : contents.length();

				if (toIndex == contents.length()) {
					break;
				}
				
				// 次のトークンを取得する。
				int tokenStart = HtmlReplaceParser.nextTokenPos(contents,
						toIndex, HtmlReplaceParser.TOKEN_SEP_CHARS);
				if (tokenStart == contents.length()) {
					toIndex = contents.length();
					break;
				}
				int tokenEnd = HtmlReplaceParser.nextTokenPos(contents,
						tokenStart, HtmlReplaceParser.TOKEN_SEP_CHARS);
				String token = contents.substring(tokenStart, tokenEnd)
						.trim();
				if (token
						.equalsIgnoreCase(SSTagReplaceParserCallback.TARGET_TAG_NAME)) {
					// sstagの開始タグの場合、
					startTagFlag = true;
					break;
				} else if(token.equals("/")) {
					// 終了タグの場合、

					// タグ名を取得する。
					int tagNameStart = tokenEnd;
					if (tagNameStart == contents.length()) {
						toIndex = contents.length();
						break;
					}
					int tagNameEnd = HtmlReplaceParser.nextTokenPos(contents,
							tagNameStart, HtmlReplaceParser.TOKEN_SEP_CHARS);
					String tagName = contents.substring(tagNameStart, tagNameEnd)
							.trim();

					// タグ名がsstagの場合、
					if (tagName
							.equalsIgnoreCase(SSTagReplaceParserCallback.TARGET_TAG_NAME)) {
						startTagFlag = false;
						break;
					}

				}

				toIndex++;
			}

			// 次のタグまでにテキストが存在していた場合、
			if (fromIndex != toIndex) {
				temp = contents.substring(fromIndex, toIndex);
				temp = cb.handleText(temp);
				sb.append(temp);
				fromIndex = toIndex;
			}

			// htmlの内容をすべて処理した場合、解析/置換を終了する。
			if (fromIndex == contents.length()) {
				break;
			}

			// タグの終了位置を求める。
			toIndex = contents.indexOf(">", fromIndex + 1);
			toIndex = toIndex >= 0 ? toIndex + 1 : contents.length();

			// タグ部分のみを抜き出す。
			temp = contents.substring(fromIndex, toIndex);
            if (startTagFlag) {
                if (temp.endsWith("/>")) {
                    temp = cb.handleSimpleTag(temp);
                } else {
                    temp = cb.handleStartTag(temp);
                }
            } else {
                temp = cb.handleEndTag(temp);
            }

			sb.append(temp);
			fromIndex = toIndex;

			// htmlの内容をすべて処理した場合、解析/置換を終了する。
			if (fromIndex == contents.length()) {
				break;
			}

		}

		// 最終チェックを行う。
		sb.append(cb.finalCheck());
		
		return sb.toString();
	}

}
