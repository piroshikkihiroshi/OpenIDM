package jp.co.webcrew.filters.db;

import java.sql.ResultSet;
import java.util.regex.Pattern;

import jp.co.webcrew.dbaccess.db.DBAccess;

/**
 * AuthMailSendExecuter用DBクラス
 *
 */
public class AuthMailSendingDb
{
	/* 認証メール送信日時を取得する */
	private static final String SELECT_SENDING_FLG = "SELECT CASE WHEN (auth_mail_sending_datetime IS NULL OR auth_mail_sending_datetime < sysdate - (?/1440)) THEN 0 ELSE 1 END AS sending_flg FROM ###table### WHERE ###cond_1### = ? AND ###cond_2### = ?";
	
	/* 条件に一致する利用者情報の件数を取得する */
	private static final String SELECT_USER        = "SELECT COUNT(1) AS cnt FROM ###table### WHERE ###cond_1### = ? AND ###cond_2### = ?";
	
	/* 認証メール送信日時を更新する */
	private static final String UPDATE_DATETIME    = "UPDATE ###table### SET auth_mail_sending_datetime = sysdate WHERE ###cond_1### = ? AND ###cond_2### = ?";
	
	/* 認証メール送信日時とパスワードを更新する */
	private static final String UPDATE_DATETIME_PW = "UPDATE ###table### SET auth_mail_sending_datetime = sysdate, auth_password = ? WHERE ###cond_1### = ? AND ###cond_2### = ?";

	/**
	 * 生成不能コンストラクタ
	 */
	public AuthMailSendingDb()
	{
	}
	
	/**
	 * 認証メール送信済み(1)/未送信(0)を取得する
	 * 
	 * @param strColumn
	 * @param strTableName
	 * @param strCond_1
	 * @param nRequestId
	 * @param strSK
	 * @return
	 * @throws Exception
	 */
	public static boolean isSent(DBAccess objDBAccess, String strTableName, String strCond_1, String strCond_2, String strParam_1, String strParam_2, int nInterval) throws Exception
	{
		ResultSet objResultSet = null;
		
		try
		{
			//検索するテーブルを設定
			Pattern objPattern = Pattern.compile("###table###");
			String strSQL = objPattern.matcher(SELECT_SENDING_FLG).replaceFirst(strTableName);
		
			//検索条件を設定
			objPattern = Pattern.compile("###cond_1###");
			strSQL = objPattern.matcher(strSQL).replaceFirst(strCond_1);
			objPattern = Pattern.compile("###cond_2###");
			strSQL = objPattern.matcher(strSQL).replaceFirst(strCond_2);
		
			objDBAccess.prepareStatement(strSQL);
			objDBAccess.setInt(1, nInterval);
			objDBAccess.setString(2, strParam_1);
			objDBAccess.setString(3, strParam_2);
		
			objResultSet = objDBAccess.executeQuery();
		
			if (objResultSet.next())
			{
				if (objResultSet.getInt("sending_flg") == 0)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
		
			throw new Exception("認証メール送信日時を取得出来ませんでした。");
		}
		finally
		{
			DBAccess.close(objResultSet);
		}
	}

	/**
	 * 利用者情報が存在する(true)/存在しない(false)を取得する
	 * 
	 * @param strTableName
	 * @param strCond_1
	 * @return
	 */
	public static boolean isExists(DBAccess objDBAccess, String strTableName, String strCond_1, String strCond_2, String strParam_1, String strParam_2) throws Exception
	{
		ResultSet objResultSet = null;
		
		try
		{
			//検索するテーブルを設定
			Pattern objPattern = Pattern.compile("###table###");
			String strSQL = objPattern.matcher(SELECT_USER).replaceFirst(strTableName);
		
			//検索条件を設定
			objPattern = Pattern.compile("###cond_1###");
			strSQL = objPattern.matcher(strSQL).replaceFirst(strCond_1);
			objPattern = Pattern.compile("###cond_2###");
			strSQL = objPattern.matcher(strSQL).replaceFirst(strCond_2);
			
			objDBAccess.prepareStatement(strSQL);
			objDBAccess.setString(1, strParam_1);
			objDBAccess.setString(2, strParam_2);
			
			objResultSet = objDBAccess.executeQuery();
			if (objResultSet.next())
			{
				if (objResultSet.getInt("cnt") > 0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			
			throw new Exception("利用者情報を取得出来ませんでした。");
		}
		finally
		{
			DBAccess.close(objResultSet);
		}
	}

	/**
	 * 指定したテーブル(strTableName)の認証メール送信日時、認証パスワードを更新する
	 * 
	 * @param objDBAccess
	 * @param strTableName
	 * @param strParam_1
	 * @param strParam_2
	 * @param strCond_1
	 * @param strCond_2
	 * @param strPassword
	 * @return
	 * @throws Exception
	 */
	public static boolean updateTable(DBAccess objDBAccess, String strTableName, String strParam_1, String strParam_2, String strCond_1, String strCond_2, String strPassword) throws Exception
	{
		//検索するテーブルを設定
		Pattern objPattern = Pattern.compile("###table###");
		String strSQL = objPattern.matcher((strPassword.equals("")) ? UPDATE_DATETIME : UPDATE_DATETIME_PW).replaceFirst(strTableName);
	
		//検索条件を設定
		objPattern = Pattern.compile("###cond_1###");
		strSQL = objPattern.matcher(strSQL).replaceFirst(strCond_1);
		objPattern = Pattern.compile("###cond_2###");
		strSQL = objPattern.matcher(strSQL).replaceFirst(strCond_2);
		
		objDBAccess.prepareStatement(strSQL);
		
		if (strPassword.equals(""))
		{
			objDBAccess.setString(1, strParam_1);
			objDBAccess.setString(2, strParam_2);
		}
		else
		{
			objDBAccess.setString(1, strPassword);
			objDBAccess.setString(2, strParam_1);
			objDBAccess.setString(3, strParam_2);
		}
		
		if (objDBAccess.executeUpdate() == 1)
		{
			return true;
		}
		
		return false;
	}
}
