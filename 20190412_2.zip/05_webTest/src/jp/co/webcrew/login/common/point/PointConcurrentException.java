/**
 * 
 */
package jp.co.webcrew.login.common.point;

/**
 * @author kazuto.yano
 *
 */
public class PointConcurrentException
//TODO RuntimeExceptionのサブクラスでよいか？
extends RuntimeException
{
	private final String guid;
	
	
	public PointConcurrentException(String message,String guid)
	{
		super(message);
		this.guid=guid;
	}

	public String getGuid() 
	{
		return guid;
	}


	
	
	
}
