package jp.co.webcrew.common.mail;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import generator.runtime.db.DBConnectionWrapper;
import generator.runtime.db.DBConnectionWrapperSource;
import generator.runtime.exception.ApplicationException;
import generator.runtime.mail.ReplacingEmail;
import generator.runtime.servlet.BaseServlet;
import generator.runtime.utils.ApplicationProperties;
import generator.runtime.utils.Logger;
import generator.runtime.utils.ParamUtils;
import generator.runtime.utils.StringUtils;
import jp.co.webcrew.common.mail.proc.CalculationSet;
import jp.co.webcrew.common.mail.proc.WildcardValue;
import jp.co.webcrew.common.util.WcString;

public class MailExecutorServlet extends BaseServlet
{
  private final int RETRY_PERIOD = 30;
  private String jobTable;
  private String jobIdField;
  private String stepSiteIdField;
  private String customerIdField;
  private String companyIdField;
  private String mailRulesetIdField;
  private String overrideAddressFromField;
  private String overrideAddressToField;
  private String overrideAddressCcField;
  private String overrideAddressBccField;
  private String overrideSubjectField;
  private String overrideBodyTextField;
  private String overrideBodyHtmlField;
  private String startedDateField;
  private String retriesField;
  private String nextRetryField;
  private String stepSiteInfoTable;
  private String stepSitePKField;
  private String stepSiteMailRuleTableField;
  private String stepSiteMailLogTableField;
  private String stepSiteMailLogSequenceField;
  private String defaultMailRulesetTable;
  private String mailRulesetPKField;
  private String mailRulesetField;
  private String defaultMailLogIdSequence;
  private String defaultMailLogTable;
  private String mailLogPKField;
  private String mailLogMailRuleIdField;
  private String mailLogStepSiteIdField;
  private String mailLogSenderField;
  private String mailLogToField;
  private String mailLogCcField;
  private String mailLogBccField;
  private String mailLogSubjectField;
  private String mailLogTextBodyField;
  private String mailLogHtmlBodyField;
  private String mailLogSentDateField;

  public void init(ServletConfig config)
    throws ServletException
  {
    super.init(config);

    this.jobTable = ParamUtils.nvl(config.getInitParameter("jobTable"), "mail_pending_job_info");

    this.jobIdField = ParamUtils.nvl(config.getInitParameter("jobIdField"), "mail_pending_job_id");

    this.stepSiteIdField = ParamUtils.nvl(config.getInitParameter("stepSiteIdField"), "NULL");

    this.customerIdField = ParamUtils.nvl(config.getInitParameter("customerIdField"), "source_id");

    this.companyIdField = ParamUtils.nvl(config.getInitParameter("companyIdField"), "company_id");

    this.mailRulesetIdField = ParamUtils.nvl(config.getInitParameter("mailRulesetIdField"), "mail_rule_id");

    this.overrideAddressToField = ParamUtils.nvl(config.getInitParameter("overrideAddressToField"), "override_address_to");

    this.overrideAddressCcField = ParamUtils.nvl(config.getInitParameter("overrideAddressCcField"), "override_address_cc");

    this.overrideAddressBccField = ParamUtils.nvl(config.getInitParameter("overrideAddressBccField"), "override_address_bcc");

    this.overrideAddressFromField = ParamUtils.nvl(config.getInitParameter("overrideAddressFromField"), "override_address_from");

    this.overrideSubjectField = ParamUtils.nvl(config.getInitParameter("overrideSubjectField"), "override_subject");

    this.overrideBodyTextField = ParamUtils.nvl(config.getInitParameter("overrideBodyTextField"), "override_body_text");

    this.overrideBodyHtmlField = ParamUtils.nvl(config.getInitParameter("overrideBodyHtmlField"), "override_body_html");

    this.startedDateField = ParamUtils.nvl(config.getInitParameter("startedDateField"), "started_date");

    this.retriesField = ParamUtils.nvl(config.getInitParameter("retriesField"), "retries_remaining");

    this.nextRetryField = ParamUtils.nvl(config.getInitParameter("nextRetryField"), "next_retry_date");

    this.stepSiteInfoTable = ParamUtils.nvl(config.getInitParameter("stepSiteInfoTable"), "step_site_info");

    this.stepSitePKField = ParamUtils.nvl(config.getInitParameter("stepSitePKField"), this.stepSiteIdField);

    this.stepSiteMailRuleTableField = ParamUtils.nvl(config.getInitParameter("stepSiteMailRuleTableField"), "mail_rule_table");

    this.stepSiteMailLogTableField = ParamUtils.nvl(config.getInitParameter("stepSiteMailLogTableField"), "mail_log_table");

    this.stepSiteMailLogSequenceField = ParamUtils.nvl(config.getInitParameter("stepSiteMailLogSequenceField"), "mail_log_sequence");

    this.defaultMailRulesetTable = ParamUtils.nvl(config.getInitParameter("mailRulesetTable"), "mail_rule_mst");

    this.mailRulesetPKField = ParamUtils.nvl(config.getInitParameter("mailRulesetPKField"), this.mailRulesetIdField);

    this.mailRulesetField = ParamUtils.nvl(config.getInitParameter("mailRulesetField"), "mail_rule_xml");

    this.defaultMailLogIdSequence = ParamUtils.nvl(config.getInitParameter("mailLogIdSequence"), "seq_mail_sent_log_id");

    this.defaultMailLogTable = ParamUtils.nvl(config.getInitParameter("mailSendingLogTable"), "mail_sent_log_info");

    this.mailLogPKField = ParamUtils.nvl(config.getInitParameter("mailLogPKField"), "mail_sent_log_id");

    this.mailLogStepSiteIdField = ParamUtils.nvl(config.getInitParameter("mailLogStepSiteIdField"), "step_site_id");

    this.mailLogMailRuleIdField = ParamUtils.nvl(config.getInitParameter("mailLogMailRuleIdField"), "mail_rule_id");

    this.mailLogSenderField = ParamUtils.nvl(config.getInitParameter("mailLogSenderField"), "address_from");

    this.mailLogToField = ParamUtils.nvl(config.getInitParameter("mailLogToField"), "address_to");

    this.mailLogCcField = ParamUtils.nvl(config.getInitParameter("mailLogCcField"), "address_cc");

    this.mailLogBccField = ParamUtils.nvl(config.getInitParameter("mailLogBccField"), "address_bcc");

    this.mailLogSubjectField = ParamUtils.nvl(config.getInitParameter("mailLogSubjectField"), "subject");

    this.mailLogTextBodyField = ParamUtils.nvl(config.getInitParameter("mailLogTextBodyField"), "body_text");

    this.mailLogHtmlBodyField = ParamUtils.nvl(config.getInitParameter("mailLogHtmlBodyField"), "body_html");

    this.mailLogSentDateField = ParamUtils.nvl(config.getInitParameter("mailLogSentDateField"), "sent_date");
  }

  protected void doAction(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    ApplicationProperties props = (ApplicationProperties)ParamUtils.nvl(getServletContext().getAttribute("applicationProperties"), ResourceBundle.getBundle("automatedMailer"));

    String mailServer = ParamUtils.nvl(request.getParameter("smtpServer"), props.get("automatedMailer/@serverAddress"));

    Logger.log(Logger.DEBUG, "MailExecutor: starting");

    long startTime = System.currentTimeMillis();

    Throwable error = null;
    Connection connection = null;
    try
    {
      DBConnectionWrapperSource ds = (DBConnectionWrapperSource)getServletContext().getAttribute("connectionPool");

      DBConnectionWrapper dbConn = ds.createConnectionWrapper();
      connection = dbConn.getConnection(true);

      if (connection != null) {
        boolean oldAutocommit = connection.getAutoCommit();
        connection.setAutoCommit(false);

        long jobsProcessed = processJobs(connection, mailServer, request, props);

        connection.setAutoCommit(oldAutocommit);
        connection.close();
        connection = null;
        Logger.log(Logger.DEBUG, "MailExecutor: Processed " + jobsProcessed + " jobs");
      } else {
        Logger.log(Logger.WARNING, "MailExecutor: Failed to get a jdbc connection");
      }
    } catch (SQLException err) {
      if (connection != null) {
        try {
          connection.rollback();
        } catch (SQLException err2) {
          Logger.log(Logger.ERROR, "MailExecutor: Error rolling back jdbc connection", err2);
        }

      }

      error = err;
      Logger.log(Logger.ERROR, "MailExecutor: Error closing jdbc connection", err);
    } finally {
      if (connection != null) {
        try {
          connection.close();
        } catch (SQLException err2) {
          Logger.log(Logger.ERROR, "MailExecutor: Error closing jdbc connection", err2);
        }
      }

    }

    long period = System.currentTimeMillis() - startTime;
    Logger.log(Logger.DEBUG, "MailExecutor: finished in " + period + "ms");
    response.setContentType("text/plain");

    PrintWriter out = response.getWriter();
    out.println("MailExecutor: finished in " + period + "ms");

    if (error != null) {
      out.println("Error: ");
      error.printStackTrace(out);
    }

    out.close();
  }

  protected long processJobs(Connection connection, String mailServer, HttpServletRequest request, ApplicationProperties props)
  {
    long jobsProcessed = 0L;

    String sysdate = props.stringProperty("automatedMailer/@dbDateExpression", "sysdate");
    String sequenceQuery = props.stringProperty("automatedMailer/@sequenceSQL", "SELECT ###sequenceName###.nextval FROM dual");
    String retryPeriodExpression = props.stringProperty("automatedMailer/@retryPeriodExpression", "###retryPeriod### / (24 * 60)");
    String mailEncoding = props.get("automatedMailer/@encoding");
    Session mailSession = ReplacingEmail.makeSession(mailServer, ":");
    String mailServerOhikkoshi=System.getProperty("ohikkoshi.mailsvr");
    Session ohikkoshiMailSession = ReplacingEmail.makeSession(mailServerOhikkoshi, ":");

    PreparedStatement qryJobs = null;
    PreparedStatement qryFlagStarted = null;
    PreparedStatement qryDeleteJob = null;
    PreparedStatement qryUpdateRetries = null;
    PreparedStatement qryLookupMailTables = null;

    Long stepSiteId = null;
    Long jobId = null;
    Long customerId = null;
    Long companyId = null;
    Long mailRulesetId = null;
    Long retriesRemaining = null;

    String overrideAddressFrom = null;
    String overrideAddressTo = null;
    String overrideAddressCc = null;
    String overrideAddressBcc = null;
    String overrideSubject = null;
    String overrideBodyText = null;
    String overrideBodyHtml = null;
    String jobSQL = null;
    try
    {
      qryFlagStarted = connection.prepareStatement("UPDATE " + this.jobTable + " " + "SET " + this.startedDateField + " = " + sysdate + " WHERE " + this.jobIdField + " = ? " + "AND " + this.startedDateField + " IS NULL");

      qryLookupMailTables = connection.prepareStatement("SELECT " + this.stepSiteMailRuleTableField + " AS rule_table, " + this.stepSiteMailLogTableField + " AS log_table, " + this.stepSiteMailLogSequenceField + " AS log_sequence FROM " + this.stepSiteInfoTable + " WHERE " + this.stepSitePKField + " = ?");

      qryDeleteJob = connection.prepareStatement("DELETE FROM " + this.jobTable + " " + "WHERE " + this.jobIdField + " = ?");

      qryUpdateRetries = connection.prepareStatement("UPDATE " + this.jobTable + " " + "SET " + this.retriesField + " = ?, " + this.nextRetryField + " = " + this.startedDateField + " + " + StringUtils.stringReplace(retryPeriodExpression, "###retryPeriod###", "30") + ", " + this.startedDateField + " = NULL " + "WHERE " + this.jobIdField + " = ? " + "AND " + this.startedDateField + " IS NOT NULL");

      overrideAddressFrom = null;
      overrideAddressTo = null;
      overrideAddressCc = null;
      overrideAddressBcc = null;
      overrideSubject = null;
      overrideBodyText = null;
      overrideBodyHtml = null;

      jobSQL = "SELECT j." + this.jobIdField + " AS jobId, j." + this.stepSiteIdField + " AS stepSiteId, j." + this.customerIdField + " AS customerId, j." + this.companyIdField + " AS companyId, j." + this.mailRulesetIdField + " AS mailRulesetId, j." + this.overrideAddressFromField + " AS overrideAddressFrom, j." + this.overrideAddressToField + " AS overrideAddressTo, j." + this.overrideAddressCcField + " AS overrideAddressCc, j." + this.overrideAddressBccField + " AS overrideAddressBcc, j." + this.overrideSubjectField + " AS overrideSubject, j." + this.overrideBodyTextField + " AS overrideBodyText, j." + this.overrideBodyHtmlField + " AS overrideBodyHtml, j." + this.startedDateField + " AS startedDateField, j." + this.retriesField + " AS retriesRemaining, j." + this.nextRetryField + " AS nextRetryDate FROM " + this.jobTable + " j WHERE j." + this.startedDateField + " IS NULL " + "AND j." + this.retriesField + " > 0 " + "AND (j." + this.nextRetryField + " IS NULL OR j." + this.nextRetryField + " < " + sysdate + ")";

      Logger.log(Logger.FULL_DEBUG, "Executing job lookup SQL: " + jobSQL);
      qryJobs = connection.prepareStatement(jobSQL);

      ResultSet rstJobs = qryJobs.executeQuery();
      if (rstJobs.next()) {
        jobId = new Long(rstJobs.getLong("jobId"));
        retriesRemaining = new Long(rstJobs.getLong("retriesRemaining"));

        overrideAddressFrom = rstJobs.getString("overrideAddressFrom");
        overrideAddressTo = rstJobs.getString("overrideAddressTo");
        overrideAddressCc = rstJobs.getString("overrideAddressCc");
        overrideAddressBcc = rstJobs.getString("overrideAddressBcc");
        overrideSubject = rstJobs.getString("overrideSubject");
        overrideBodyText = rstJobs.getString("overrideBodyText");
        overrideBodyHtml = rstJobs.getString("overrideBodyHtml");

        if (rstJobs.getObject("mailRulesetId") != null)
          mailRulesetId = new Long(rstJobs.getLong("mailRulesetId"));
        else {
          mailRulesetId = null;
        }

        if (rstJobs.getObject("stepSiteId") != null)
          stepSiteId = new Long(rstJobs.getLong("stepSiteId"));
        else {
          stepSiteId = null;
        }

        if (rstJobs.getObject("customerId") != null)
          customerId = new Long(rstJobs.getLong("customerId"));
        else {
          customerId = null;
        }

        if (rstJobs.getObject("companyId") != null)
          companyId = new Long(rstJobs.getLong("companyId"));
        else {
          companyId = null;
        }

      }
      else
      {
        jobId = null;
        stepSiteId = null;
        customerId = null;
        companyId = null;
        mailRulesetId = null;
        retriesRemaining = null;

        overrideAddressFrom = null;
        overrideAddressTo = null;
        overrideAddressCc = null;
        overrideAddressBcc = null;
        overrideSubject = null;
        overrideBodyText = null;
        overrideBodyHtml = null;
      }
      rstJobs.close();
    } catch (SQLException err) {
      throw new ApplicationException("Couldn't set up queries", err);
    }

    while (jobId != null) {
      try {
        jobsProcessed += 1L;
        Logger.log(Logger.DEBUG, "MailExecutor: Found job: id=" + jobId + ",customerId=" + customerId + ",companyId=" + companyId + ",stepSiteId=" + stepSiteId + ",mailRuleId=" + mailRulesetId);

        qryFlagStarted.setLong(1, jobId.longValue());
        int rowsAffected = qryFlagStarted.executeUpdate();
        if (rowsAffected == 0) {
          Logger.log(Logger.DEBUG, "MailExecutor: Detected job that was already started - ignoring: id=" + jobId + ",customerId=" + customerId + ",companyId=" + companyId + ",stepSiteId=" + stepSiteId + ",mailRuleId=" + mailRulesetId);
        }
        else {
          if (rowsAffected != 1) {
            throw new ApplicationException("Setting job " + jobId + " as started affected " + rowsAffected + " rows");
          }

          connection.commit();

          String stepSiteMailRuleTable = null;
          String stepSiteMailLogTable = null;
          String stepSiteMailLogSequence = null;
          if (stepSiteId != null)
          {
            qryLookupMailTables.setLong(1, stepSiteId.longValue());
            ResultSet rstLookupMailTables = qryLookupMailTables.executeQuery();

            if (rstLookupMailTables.next()) {
              stepSiteMailRuleTable = rstLookupMailTables.getString("rule_table");
              stepSiteMailLogTable = rstLookupMailTables.getString("log_table");
              stepSiteMailLogSequence = rstLookupMailTables.getString("log_sequence");
            }
            rstLookupMailTables.close();
          }

          if (stepSiteMailLogSequence == null) {
            stepSiteMailLogSequence = this.defaultMailLogIdSequence;
          }
          PreparedStatement qryLogSequence = connection.prepareStatement(StringUtils.stringReplace(sequenceQuery, "###sequenceName###", stepSiteMailLogSequence));

          ResultSet rstLogSequence = qryLogSequence.executeQuery();
          rstLogSequence.next();
          Long successLogId = new Long(rstLogSequence.getLong(1));
          rstLogSequence.close();
          qryLogSequence.close();

          String logInsertSQL = null;
          PreparedStatement qryLogInsert = null;
          if (stepSiteMailLogTable == null) {
            stepSiteMailLogTable = this.defaultMailLogTable;
            logInsertSQL = "INSERT INTO " + stepSiteMailLogTable + " (" + this.mailLogPKField + ", " + this.mailLogMailRuleIdField + ", " + this.mailLogSentDateField + ", " + this.mailLogStepSiteIdField + ") VALUES (?, ?, " + sysdate + ", ?)";

            qryLogInsert = connection.prepareStatement(logInsertSQL);
            if (stepSiteId != null)
              qryLogInsert.setLong(3, stepSiteId.longValue());
            else
              qryLogInsert.setNull(3, -5);
          }
          else {
            logInsertSQL = "INSERT INTO " + stepSiteMailLogTable + " (" + this.mailLogPKField + ", " + this.mailLogMailRuleIdField + ", " + this.mailLogSentDateField + ") VALUES (?, ?, " + sysdate + ")";

            qryLogInsert = connection.prepareStatement(logInsertSQL);
          }
          Logger.log(Logger.FULL_DEBUG, "Log row insert SQL: " + logInsertSQL);
          qryLogInsert.setLong(1, successLogId.longValue());
          if (mailRulesetId != null)
            qryLogInsert.setLong(2, mailRulesetId.longValue());
          else {
            qryLogInsert.setNull(2, -5);
          }
          qryLogInsert.executeUpdate();
          qryLogInsert.close();

          PreparedStatement qryGetMailRuleset = null;
          if (stepSiteMailRuleTable != null) {
            qryGetMailRuleset = connection.prepareStatement("SELECT " + this.mailRulesetField + " FROM " + stepSiteMailRuleTable + " WHERE " + this.mailRulesetPKField + " = ?");
          }
          else
          {
            qryGetMailRuleset = connection.prepareStatement("SELECT " + this.mailRulesetField + " FROM " + this.defaultMailRulesetTable + " WHERE " + this.mailRulesetPKField + " = ?");
          }

          String fromAddress = null;
          String toAddress = null;
          String ccAddress = null;
          String bccAddress = null;
          String subject = null;
          String textBody = null;
          String htmlBody = null;

          if (mailRulesetId != null)
          {
            String rulesetXML = null;
            qryGetMailRuleset.setLong(1, mailRulesetId.longValue());
            ResultSet rstGetMailRuleset = qryGetMailRuleset.executeQuery();
            if (rstGetMailRuleset.next()) {
              Reader content = rstGetMailRuleset.getCharacterStream(1);
              if (content != null) {
                StringWriter out = new StringWriter();
                char[] buffer = new char[512];
                int readChars = 0;

                while ((readChars = content.read(buffer)) != -1) {
                  out.write(buffer, 0, readChars);
                }
                content.close();
                rulesetXML = out.toString();
                rstGetMailRuleset.close();
              }
            } else {
              rstGetMailRuleset.close();
              throw new ApplicationException("Mail ruleset id " + mailRulesetId + " not found in table: " + ParamUtils.nvl(stepSiteMailRuleTable, this.defaultMailRulesetTable));
            }

            Map inputVars = new HashMap();
            inputVars.put("successLogId", successLogId);
            inputVars.put("companyId", companyId);
            inputVars.put("sourceId", customerId);
            String wildcardXML = CalculationSet.makeXMLWildcards(inputVars);
            List wildcardRows = CalculationSet.applicationServerEvaluate(connection, rulesetXML, wildcardXML);

            Map wildcards = wildcardRows.isEmpty() ? new HashMap() : (Map)wildcardRows.iterator().next();

            if (!wildcards.isEmpty()) {
              Logger.log(Logger.DEBUG, "Results: " + wildcards);

              fromAddress = getStringFromWildcards(wildcards, "addressFrom");
              toAddress = getStringFromWildcards(wildcards, "addressTo");
              ccAddress = getStringFromWildcards(wildcards, "addressCc");
              bccAddress = getStringFromWildcards(wildcards, "addressBcc");

              subject = getStringFromWildcards(wildcards, "subject");
              textBody = getStringFromWildcards(wildcards, "bodyText");
              htmlBody = getStringFromWildcards(wildcards, "bodyHtml");
            } else {
              throw new ApplicationException("Mail calculator returned zero rows");
            }

          }

          if (overrideAddressFrom != null) {
            fromAddress = overrideAddressFrom;
          }
          if (overrideAddressTo != null) {
            toAddress = overrideAddressTo;
          }
          if (overrideAddressCc != null) {
            ccAddress = overrideAddressCc;
          }
          if (overrideAddressBcc != null) {
            bccAddress = overrideAddressBcc;
          }
          if (overrideSubject != null) {
            subject = overrideSubject;
          }
          if (overrideBodyText != null) {
            textBody = overrideBodyText;
          }
          if (overrideBodyHtml != null) {
            htmlBody = overrideBodyHtml;
          }

          String targetDomain = System.getProperty("ohikkoshi.target.domain");
          ReplacingEmail email = null;
          if (fromAddress != null && fromAddress.indexOf(targetDomain) != -1)
          {
        	  Logger.log(Logger.INFO, "�x�[�V�b�N���[���T�[�o�F" + fromAddress);
        	  email = new ReplacingEmail(ohikkoshiMailSession, mailEncoding);
          }
          else
          {
        	  Logger.log(Logger.INFO, "���K���[���T�[�o�F" + fromAddress);
        	  email = new ReplacingEmail(mailSession, mailEncoding);
          }

          setEmailParameters(email, props, fromAddress, toAddress, ccAddress, bccAddress, subject, textBody, htmlBody, mailEncoding);

          email.send();

          qryDeleteJob.setLong(1, jobId.longValue());

          if (qryDeleteJob.executeUpdate() != 1) {
            throw new ApplicationException("Error deleting job");
          }

          String logUpdateSQL = "UPDATE " + stepSiteMailLogTable + " SET " + this.mailLogSenderField + " = ?, " + this.mailLogToField + " = ?, " + this.mailLogCcField + " = ?, " + this.mailLogBccField + " = ?, " + this.mailLogSubjectField + " = ?, " + this.mailLogTextBodyField + " = ?, " + this.mailLogHtmlBodyField + " = ? WHERE " + this.mailLogPKField + " = ?";

          Logger.log(Logger.FULL_DEBUG, "Log update SQL = " + logUpdateSQL);
          PreparedStatement qryLogUpdate = connection.prepareStatement(logUpdateSQL);
          qryLogUpdate.setString(1, fromAddress);
          qryLogUpdate.setString(2, toAddress);
          qryLogUpdate.setString(3, ccAddress);
          qryLogUpdate.setString(4, bccAddress);
          if (subject != null)
            qryLogUpdate.setCharacterStream(5, new StringReader(subject), subject.length());
          else {
            qryLogUpdate.setNull(5, 12);
          }
          if (textBody != null)
            qryLogUpdate.setCharacterStream(6, new StringReader(textBody), textBody.length());
          else {
            qryLogUpdate.setNull(6, 12);
          }
          if (htmlBody != null)
            qryLogUpdate.setCharacterStream(7, new StringReader(htmlBody), htmlBody.length());
          else {
            qryLogUpdate.setNull(7, 12);
          }
          qryLogUpdate.setLong(8, successLogId.longValue());
          qryLogUpdate.executeUpdate();
          qryLogUpdate.close();

          connection.commit();
        }
      } catch (Throwable err) {
        Logger.log(Logger.ERROR, "MailExecutor: Sending failed", err);
      //t_ueda コメントアウト
//        try {
//          new ErrorNotificationMail(err, request, props).send();
//
//        } catch (IOException err2) {
//          Logger.log(Logger.ERROR, "MailExecutor: Error email failed", err2);
//        }
        try
        {
          connection.rollback();
        } catch (SQLException err2) {
          Logger.log(Logger.ERROR, "MailExecutor: Error rolling back the job processing", err2);
        }

        try
        {
          qryUpdateRetries.setLong(1, retriesRemaining.longValue() - 1L);

          if (!retriesRemaining.equals(new Long(1L))) {
            Logger.log(Logger.DEBUG, "MailExecutor: Postponing retry for job: " + jobId + " for " + 30 + " minutes (" + (retriesRemaining.longValue() - 1L) + " retries remaining)");
          }
          else
          {
            Logger.log(Logger.DEBUG, "Job " + jobId + " has been abandoned, no more retries allowed");
          }

          qryUpdateRetries.setLong(2, jobId.longValue());

          if (qryUpdateRetries.executeUpdate() != 1) {
            throw new SQLException("Could not update retry count for job " + jobId);
          }

          connection.commit();
        } catch (SQLException err2) {
          Logger.log(Logger.ERROR, "MailExecutor: Error marking the job complete with error", err2);
        }

      }

      try
      {
        Logger.log(Logger.FULL_DEBUG, "Executing job lookup SQL: " + jobSQL);
        ResultSet rstJobs = qryJobs.executeQuery();

        if (rstJobs.next()) {
          jobId = new Long(rstJobs.getLong("jobId"));
          retriesRemaining = new Long(rstJobs.getLong("retriesRemaining"));

          overrideAddressFrom = rstJobs.getString("overrideAddressFrom");
          overrideAddressTo = rstJobs.getString("overrideAddressTo");
          overrideAddressCc = rstJobs.getString("overrideAddressCc");
          overrideAddressBcc = rstJobs.getString("overrideAddressBcc");
          overrideSubject = rstJobs.getString("overrideSubject");
          overrideBodyText = rstJobs.getString("overrideBodyText");
          overrideBodyHtml = rstJobs.getString("overrideBodyHtml");

          if (rstJobs.getObject("mailRulesetId") != null)
            mailRulesetId = new Long(rstJobs.getLong("mailRulesetId"));
          else {
            mailRulesetId = null;
          }

          if (rstJobs.getObject("stepSiteId") != null)
            stepSiteId = new Long(rstJobs.getLong("stepSiteId"));
          else {
            stepSiteId = null;
          }

          if (rstJobs.getObject("customerId") != null)
            customerId = new Long(rstJobs.getLong("customerId"));
          else {
            customerId = null;
          }

          if (rstJobs.getObject("companyId") != null)
            companyId = new Long(rstJobs.getLong("companyId"));
          else {
            companyId = null;
          }

        }
        else
        {
          jobId = null;
          stepSiteId = null;
          customerId = null;
          companyId = null;
          mailRulesetId = null;
          retriesRemaining = null;

          overrideAddressFrom = null;
          overrideAddressTo = null;
          overrideAddressCc = null;
          overrideAddressBcc = null;
          overrideSubject = null;
          overrideBodyText = null;
          overrideBodyHtml = null;
        }

        rstJobs.close();
      } catch (SQLException err) {
        throw new ApplicationException("Couldn't get next job", err);
      }
    }
    try
    {
      qryJobs.close();
      qryFlagStarted.close();
      qryDeleteJob.close();
      qryLookupMailTables.close();
    }
    catch (SQLException err) {
      Logger.log(Logger.ERROR, "Error closing queries", err);
    }

    return jobsProcessed;
  }

  protected void setEmailParameters(ReplacingEmail email, ApplicationProperties props, String fromAddress, String toAddress, String ccAddress, String bccAddress, String subject, String textBody, String htmlBody, String encoding)
  {
    Logger.log(Logger.DEBUG, "Initialising email with params: \nto: " + toAddress + "\nfrom: " + fromAddress + "\ncc: " + ccAddress + "\nbcc: " + bccAddress + "\nsubject: " + subject + "\ntextBody: " + textBody + "\nhtmlBody: " + htmlBody);

    String targetDomain = System.getProperty("ohikkoshi.target.domain");
    if (fromAddress != null && fromAddress.indexOf(targetDomain) != -1)
    {
    	Logger.log(Logger.INFO, "�x�[�V�b�N���[���T�[�o�F" + fromAddress);
    	email.setMailerHeader("automated mailer");
    }
    else
    {
    	email.setMailerHeader(props.get("automatedMailer/@mailerHeader"));
    }
    email.setContentTransferEncoding(props.get("automatedMailer/@contentTransferEncoding"));

    InternetAddress[] to = ReplacingEmail.parseAddressList(WcString.convertMS932(toAddress), ";", encoding);
    InternetAddress[] from = ReplacingEmail.parseAddressList(WcString.convertMS932(fromAddress), ";", encoding);
    InternetAddress[] cc = ReplacingEmail.parseAddressList(WcString.convertMS932(ccAddress), ";", encoding);
    InternetAddress[] bcc = ReplacingEmail.parseAddressList(WcString.convertMS932(bccAddress), ";", encoding);

    for (int n = 0; n < to.length; n++) {
      email.addTo(to[n]);
    }

    email.setFrom(from[0]);

    for (int n = 0; n < cc.length; n++) {
      email.addCc(cc[n]);
    }

    for (int n = 0; n < bcc.length; n++) {
      email.addBcc(bcc[n]);
    }

    email.setSubject(WcString.convertMS932(subject));
    email.setTextPart(WcString.convertMS932(textBody));
    email.setHtmlPart(WcString.convertMS932(htmlBody));
  }

  private static String getStringFromResults(ResultSet rst, String column)
    throws SQLException
  {
    Reader inValue = rst.getCharacterStream(column);
    try {
      StringWriter sw = new StringWriter();
      int inChar = 0;
      if (inValue != null) {
        while ((inChar = inValue.read()) != -1) {
          sw.write(inChar);
        }
      }
      return WcString.convertSJIS(sw.toString());
  	} catch (IOException err) {
  		throw new SQLException("Error converting results: " + err);
  	}
  }

  private static String getStringFromWildcards(Map wildcards, String key)
  {
    WildcardValue wc = (WildcardValue)wildcards.get(key.toLowerCase());
    return wc == null ? null : (String)wc.getValue();
  }
}